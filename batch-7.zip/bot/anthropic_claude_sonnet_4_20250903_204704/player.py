from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.position = None
        self.opponent_stats = {
            'aggression': 0.5,  # 0-1 scale
            'fold_frequency': 0.5,
            'hands_played': 0,
            'raises': 0,
            'calls': 0,
            'folds': 0
        }
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players
        
        # Determine position
        if self.id == big_blind_player_id:
            self.position = "BB"
        elif self.id == small_blind_player_id:
            self.position = "SB"
        else:
            self.position = "BTN"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.round_state = round_state

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds if facing a bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        pot_odds = self._calculate_pot_odds(round_state.pot, call_amount) if call_amount > 0 else 0
        
        # Determine action based on hand strength and situation
        return self._decide_action(round_state, hand_strength, pot_odds, remaining_chips)
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                self.opponent_stats['hands_played'] += 1
                if action.lower() == 'raise':
                    self.opponent_stats['raises'] += 1
                elif action.lower() == 'call':
                    self.opponent_stats['calls'] += 1
                elif action.lower() == 'fold':
                    self.opponent_stats['folds'] += 1
                
                # Update aggression level
                total_actions = max(1, self.opponent_stats['raises'] + self.opponent_stats['calls'] + self.opponent_stats['folds'])
                self.opponent_stats['aggression'] = (self.opponent_stats['raises'] * 2 + self.opponent_stats['calls']) / (total_actions * 2)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hand or len(self.hand) < 2:
            return 0.1
            
        card1, card2 = self.hand[0], self.hand[1]
        
        # Parse cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        max_val, min_val = max(val1, val2), min(val1, val2)
        
        # Base strength
        strength = 0.0
        
        # Pair bonus
        if val1 == val2:
            if val1 >= 10:  # TT+
                strength = 0.85
            elif val1 >= 7:  # 77-99
                strength = 0.65
            else:  # 22-66
                strength = 0.45
        else:
            # High card combinations
            if max_val == 14:  # Ace high
                if min_val >= 10:  # AK, AQ, AJ, AT
                    strength = 0.75
                elif min_val >= 7:  # A9-A7
                    strength = 0.55
                else:  # A6-A2
                    strength = 0.35
            elif max_val >= 12:  # King high
                if min_val >= 10:  # KQ, KJ, KT
                    strength = 0.65
                elif min_val >= 8:  # K9-K8
                    strength = 0.45
                else:
                    strength = 0.25
            elif max_val >= 10:  # Queen/Jack high
                if min_val >= 9:  # QJ, QT, JT
                    strength = 0.55
                else:
                    strength = 0.25
            else:
                strength = 0.15
        
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
            
        # Connected bonus
        if abs(val1 - val2) == 1:
            strength += 0.05
        elif abs(val1 - val2) <= 3:
            strength += 0.02
            
        # Position adjustment
        if self.position == "BTN":
            strength += 0.05
        elif self.position == "SB":
            strength -= 0.02
            
        return min(1.0, strength)
    
    def _calculate_pot_odds(self, pot_size: int, call_amount: int) -> float:
        if call_amount <= 0:
            return 0.0
        return call_amount / (pot_size + call_amount + 0.001)  # Avoid division by zero
    
    def _decide_action(self, round_state: RoundStateClient, hand_strength: float, pot_odds: float, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # If no bet to call
        if call_amount == 0:
            if hand_strength >= 0.7:
                # Strong hand - bet for value
                bet_size = min(int(round_state.pot * 0.75), round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength >= 0.4:
                # Medium hand - sometimes bet, sometimes check
                if round_state.round == "Preflop" and hand_strength >= 0.55:
                    bet_size = min(int(round_state.pot * 0.5), round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        
        # Facing a bet
        else:
            # All-in situation
            if call_amount >= remaining_chips * 0.8:
                if hand_strength >= 0.6:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Strong hands - raise or call
            if hand_strength >= 0.75:
                if remaining_chips > call_amount * 3:
                    raise_size = min(int(call_amount * 2.5 + round_state.pot * 0.5), round_state.max_raise)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
            
            # Good hands - usually call, sometimes raise
            elif hand_strength >= 0.55:
                # Consider opponent aggression
                if self.opponent_stats['aggression'] < 0.3 and remaining_chips > call_amount * 4:
                    raise_size = min(int(call_amount * 2 + round_state.pot * 0.3), round_state.max_raise)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
            
            # Marginal hands - call if pot odds are good
            elif hand_strength >= 0.35:
                if pot_odds <= 0.33:  # Getting 2:1 or better
                    return (PokerAction.CALL, 0)
                elif round_state.round == "Preflop" and self.position == "BB":
                    # Big blind gets discount
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Weak hands
            else:
                if pot_odds <= 0.25 and hand_strength >= 0.25:  # Getting 3:1 with some equity
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.game_history.append({
            'round': round_state.round,
            'pot': round_state.pot,
            'result': remaining_chips - self.remaining_chips
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset stats for next game
        self.opponent_stats = {
            'aggression': 0.5,
            'fold_frequency': 0.5,
            'hands_played': 0,
            'raises': 0,
            'calls': 0,
            'folds': 0
        }
        self.game_history = []