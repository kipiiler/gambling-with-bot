from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.hand_history = []
        self.opponent_aggression = 0.5  # Track opponent aggression level
        self.games_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.games_played += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        
    def get_hand_strength(self, hole_cards: List[str], community_cards: List[str] = None) -> float:
        """Calculate hand strength from 0 to 1"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        card1, card2 = hole_cards[0], hole_cards[1]
        
        # Parse card values and suits
        def get_card_value(card):
            if card[0] == 'A':
                return 14
            elif card[0] == 'K':
                return 13
            elif card[0] == 'Q':
                return 12
            elif card[0] == 'J':
                return 11
            elif card[0] == 'T':
                return 10
            else:
                return int(card[0])
        
        val1, val2 = get_card_value(card1), get_card_value(card2)
        suit1, suit2 = card1[1], card2[1]
        
        # Base strength calculation
        if val1 == val2:  # Pocket pair
            if val1 >= 10:  # High pairs (TT+)
                return 0.85 + (val1 - 10) * 0.03
            elif val1 >= 7:  # Medium pairs (77-99)
                return 0.65 + (val1 - 7) * 0.05
            else:  # Low pairs (22-66)
                return 0.45 + (val1 - 2) * 0.04
        
        # High cards
        high_val = max(val1, val2)
        low_val = min(val1, val2)
        
        if high_val == 14:  # Ace high
            if low_val >= 10:  # AK, AQ, AJ, AT
                base = 0.75 + (low_val - 10) * 0.05
            elif low_val >= 7:  # A9-A7
                base = 0.55 + (low_val - 7) * 0.05
            else:  # A6-A2
                base = 0.35 + (low_val - 2) * 0.04
        elif high_val >= 13:  # King or Queen high
            if low_val >= 10:  # KQ, KJ, KT, QJ, QT, JT
                base = 0.65 + (low_val - 10) * 0.03
            elif low_val >= 8:
                base = 0.4 + (low_val - 8) * 0.05
            else:
                base = 0.2 + (low_val - 2) * 0.03
        else:  # Lower cards
            base = 0.1 + (high_val - 2) * 0.02 + (low_val - 2) * 0.01
        
        # Suited bonus
        if suit1 == suit2:
            base += 0.1
            
        # Connected bonus
        if abs(val1 - val2) == 1:
            base += 0.05
        elif abs(val1 - val2) <= 3:
            base += 0.02
            
        return min(base, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get current betting information
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot_size = round_state.pot
            
            # Get our current bet in this round
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_current_bet
            
            # Calculate hand strength
            hand_strength = self.get_hand_strength(self.hole_cards, round_state.community_cards)
            
            # Adjust strategy based on game stage
            if round_state.round == "Preflop":
                return self._preflop_strategy(hand_strength, call_amount, min_raise, max_raise, pot_size, remaining_chips)
            else:
                return self._postflop_strategy(hand_strength, call_amount, min_raise, max_raise, pot_size, remaining_chips, round_state)
                
        except Exception as e:
            # Fallback to safe action
            if current_bet > my_current_bet and remaining_chips >= call_amount:
                if hand_strength > 0.6:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def _preflop_strategy(self, hand_strength: float, call_amount: int, min_raise: int, max_raise: int, pot_size: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Preflop strategy based on hand strength"""
        
        # If we can check, do so with weak hands
        if call_amount == 0:
            if hand_strength >= 0.7:
                # Strong hand - bet for value
                bet_size = min(pot_size // 2, max_raise)
                if bet_size >= min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        pot_odds = call_amount / (pot_size + call_amount + 0.001)  # Avoid division by zero
        
        if hand_strength >= 0.8:  # Premium hands
            # Raise with strong hands
            raise_size = min(call_amount + pot_size // 2, max_raise)
            if raise_size >= min_raise and remaining_chips >= raise_size:
                return (PokerAction.RAISE, raise_size)
            elif remaining_chips >= call_amount:
                return (PokerAction.CALL, 0)
        elif hand_strength >= 0.6:  # Good hands
            if pot_odds < 0.3:  # Good pot odds
                return (PokerAction.CALL, 0) if remaining_chips >= call_amount else (PokerAction.FOLD, 0)
        elif hand_strength >= 0.4:  # Marginal hands
            if pot_odds < 0.2:  # Very good pot odds
                return (PokerAction.CALL, 0) if remaining_chips >= call_amount else (PokerAction.FOLD, 0)
        
        return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, hand_strength: float, call_amount: int, min_raise: int, max_raise: int, pot_size: int, remaining_chips: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        """Postflop strategy with more conservative approach"""
        
        # If we can check
        if call_amount == 0:
            if hand_strength >= 0.6:
                # Bet with decent hands
                bet_size = min(pot_size // 3, max_raise)
                if bet_size >= min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        pot_odds = call_amount / (pot_size + call_amount + 0.001)
        
        if hand_strength >= 0.7:  # Strong postflop hand
            if pot_odds < 0.5:  # Reasonable pot odds
                return (PokerAction.CALL, 0) if remaining_chips >= call_amount else (PokerAction.FOLD, 0)
        elif hand_strength >= 0.5:  # Decent hand
            if pot_odds < 0.3:  # Good pot odds
                return (PokerAction.CALL, 0) if remaining_chips >= call_amount else (PokerAction.FOLD, 0)
        
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round"""
        self.remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        # Update opponent analysis for future games
        if len(all_scores) > 1:
            my_score = player_score
            opponent_scores = [score for pid, score in all_scores.items() if int(pid) != self.id]
            if opponent_scores:
                avg_opponent_score = sum(opponent_scores) / len(opponent_scores)
                if avg_opponent_score > my_score:
                    self.opponent_aggression = min(1.0, self.opponent_aggression + 0.1)
                else:
                    self.opponent_aggression = max(0.0, self.opponent_aggression - 0.05)