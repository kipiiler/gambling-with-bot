from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.position_aggression = {}
        self.opponent_stats = {}
        self.hand_history = []
        self.current_round_actions = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.hand = player_hands
        
        # Initialize opponent stats tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'vpip': 0,  # voluntarily put money in pot
                    'pfr': 0,   # preflop raise
                    'aggression': 0,
                    'showdowns': 0,
                    'wins': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.current_round_actions = []
            for player_id in self.all_players:
                if player_id != self.id and player_id in self.opponent_stats:
                    self.opponent_stats[player_id]['hands_played'] += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats based on actions
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Calculate pot odds
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = self._calculate_pot_odds(call_amount, round_state.pot)
        
        # Get position and opponent info
        position_factor = self._get_position_factor(round_state)
        opponent_aggression = self._get_opponent_aggression()
        
        # Calculate betting decision
        action, amount = self._make_decision(
            hand_strength, pot_odds, position_factor, opponent_aggression,
            round_state, remaining_chips, call_amount
        )
        
        # Record our action
        self.current_round_actions.append({
            'round': round_state.round,
            'action': action,
            'amount': amount,
            'pot': round_state.pot
        })
        
        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hand history for learning
        self.hand_history.append({
            'hand': self.hand.copy(),
            'actions': self.current_round_actions.copy(),
            'final_pot': round_state.pot,
            'community_cards': round_state.community_cards.copy()
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Update win/loss stats for opponents
        for player_id, score in all_scores.items():
            if int(player_id) != self.id and int(player_id) in self.opponent_stats:
                if score > 0:
                    self.opponent_stats[int(player_id)]['wins'] += 1
                self.opponent_stats[int(player_id)]['showdowns'] += 1

    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate hand strength based on hole cards and community cards"""
        if not self.hand:
            return 0.0
            
        # Parse cards
        hole_cards = self._parse_cards(self.hand)
        community_cards = self._parse_cards(round_state.community_cards)
        
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(hole_cards)
        else:
            return self._postflop_hand_strength(hole_cards, community_cards)

    def _parse_cards(self, cards: List[str]) -> List[Tuple[int, str]]:
        """Parse card strings into (rank, suit) tuples"""
        parsed = []
        for card in cards:
            if len(card) != 2:
                continue
            rank_char, suit = card[0], card[1]
            if rank_char == 'A':
                rank = 14
            elif rank_char == 'K':
                rank = 13
            elif rank_char == 'Q':
                rank = 12
            elif rank_char == 'J':
                rank = 11
            elif rank_char == 'T':
                rank = 10
            else:
                rank = int(rank_char)
            parsed.append((rank, suit))
        return parsed

    def _preflop_hand_strength(self, hole_cards: List[Tuple[int, str]]) -> float:
        """Calculate preflop hand strength"""
        if len(hole_cards) != 2:
            return 0.0
            
        card1, card2 = hole_cards
        rank1, suit1 = card1
        rank2, suit2 = card2
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 13:  # AA, KK, QQ
                return 0.95
            elif rank1 >= 10:  # JJ, TT
                return 0.85
            elif rank1 >= 7:   # 99, 88, 77
                return 0.75
            else:
                return 0.65
        
        # Suited cards
        suited = suit1 == suit2
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        # Premium hands
        if (high_rank == 14 and low_rank >= 10) or (high_rank == 13 and low_rank >= 11):
            return 0.9 if suited else 0.8
        
        # Good hands
        if high_rank >= 12 and low_rank >= 9:
            return 0.75 if suited else 0.65
        
        # Connected cards
        if abs(rank1 - rank2) <= 1 and high_rank >= 8:
            return 0.7 if suited else 0.6
        
        # Suited connectors and one-gappers
        if suited and abs(rank1 - rank2) <= 2 and high_rank >= 7:
            return 0.65
        
        # Face cards
        if high_rank >= 11:
            return 0.6 if suited else 0.5
        
        return 0.3

    def _postflop_hand_strength(self, hole_cards: List[Tuple[int, str]], community_cards: List[Tuple[int, str]]) -> float:
        """Calculate postflop hand strength"""
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.5
            
        hand_rank = self._evaluate_hand(all_cards)
        
        # Normalize hand rank to 0-1 scale
        # 8 = straight flush, 7 = four of a kind, etc.
        strength_map = {
            8: 0.99,  # Straight flush
            7: 0.95,  # Four of a kind
            6: 0.90,  # Full house
            5: 0.85,  # Flush
            4: 0.75,  # Straight
            3: 0.65,  # Three of a kind
            2: 0.55,  # Two pair
            1: 0.45,  # One pair
            0: 0.25   # High card
        }
        
        return strength_map.get(hand_rank, 0.25)

    def _evaluate_hand(self, cards: List[Tuple[int, str]]) -> int:
        """Evaluate the best 5-card hand from available cards"""
        if len(cards) < 5:
            return 0
            
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                is_straight = True
                break
        
        # Check for A-2-3-4-5 straight (wheel)
        if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
            is_straight = True
            
        counts = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            return 8  # Straight flush
        elif counts[0] == 4:
            return 7  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 6  # Full house
        elif is_flush:
            return 5  # Flush
        elif is_straight:
            return 4  # Straight
        elif counts[0] == 3:
            return 3  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 2  # Two pair
        elif counts[0] == 2:
            return 1  # One pair
        else:
            return 0  # High card

    def _calculate_pot_odds(self, call_amount: int, pot: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 1e-6)

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor"""
        if not round_state.current_player:
            return 0.5
            
        our_position = 0
        for i, player_id in enumerate(round_state.current_player):
            if player_id == self.id:
                our_position = i
                break
                
        num_players = len(round_state.current_player)
        # Later position is better (higher factor)
        return (our_position + 1) / (num_players + 1e-6)

    def _get_opponent_aggression(self) -> float:
        """Get average opponent aggression level"""
        if not self.opponent_stats:
            return 0.5
            
        total_aggression = 0
        count = 0
        for stats in self.opponent_stats.values():
            if stats['hands_played'] > 0:
                total_aggression += stats['aggression']
                count += 1
                
        return total_aggression / (count + 1e-6) if count > 0 else 0.5

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics based on their actions"""
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id != self.id and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                
                if action in ['Raise', 'Bet']:
                    stats['aggression'] = min(1.0, stats['aggression'] + 0.1)
                elif action in ['Call']:
                    if round_state.round == 'Preflop':
                        stats['vpip'] = min(1.0, stats['vpip'] + 0.05)
                elif action in ['Check']:
                    stats['aggression'] = max(0.0, stats['aggression'] - 0.02)

    def _make_decision(self, hand_strength: float, pot_odds: float, position_factor: float, 
                      opponent_aggression: float, round_state: RoundStateClient, 
                      remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        """Make the final betting decision"""
        
        # Adjust hand strength based on position and opponents
        adjusted_strength = hand_strength * (0.8 + 0.4 * position_factor)
        adjusted_strength *= (1.1 - 0.2 * opponent_aggression)
        
        # Current bet we need to match
        current_bet = round_state.current_bet
        our_bet = round_state.player_bets.get(str(self.id), 0)
        
        # If no bet to us, we can check
        if current_bet == our_bet:
            if adjusted_strength >= 0.7:
                # Strong hand - bet for value
                bet_size = min(round_state.pot // 2, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            elif adjusted_strength >= 0.5:
                # Decent hand - check
                return PokerAction.CHECK, 0
            else:
                # Weak hand - check and see
                return PokerAction.CHECK, 0
        
        # There's a bet to us
        if call_amount >= remaining_chips:
            # All-in situation
            if adjusted_strength >= 0.6:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        
        # Normal betting situation
        if adjusted_strength >= 0.8:
            # Very strong hand - raise
            raise_size = min(round_state.pot, round_state.max_raise)
            if raise_size >= round_state.min_raise:
                return PokerAction.RAISE, raise_size
            else:
                return PokerAction.CALL, 0
        elif adjusted_strength >= 0.6:
            # Good hand - call or small raise
            if position_factor > 0.7 and round_state.min_raise <= remaining_chips // 4:
                return PokerAction.RAISE, round_state.min_raise
            else:
                return PokerAction.CALL, 0
        elif adjusted_strength >= 0.4 and pot_odds < 0.3:
            # Marginal hand with good pot odds
            return PokerAction.CALL, 0
        else:
            # Weak hand or bad pot odds
            return PokerAction.FOLD, 0