from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = None
        self.opponent_tendencies = {}
        self.hand_history = []
        self.game_stage = 'early'
        self.bluff_frequency = 0.15
        self.aggression_factor = 1.2

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id:
                self.opponent_tendencies[player] = {
                    'vpip': 0.5,  # Voluntary put in pot
                    'pfr': 0.3,   # Pre-flop raise
                    'aggression': 1.0,
                    'hands_played': 0,
                    'hands_raised': 0,
                    'total_hands': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            # Extract hole cards from community cards representation if needed
            self.hole_cards = []
        self.remaining_chips = remaining_chips
        
        # Update game stage based on blinds and remaining chips
        if remaining_chips < self.starting_chips * 0.5:
            self.game_stage = 'late'
            self.aggression_factor = 1.5
        elif remaining_chips < self.starting_chips * 0.8:
            self.game_stage = 'middle'
            self.aggression_factor = 1.3
        else:
            self.game_stage = 'early'
            self.aggression_factor = 1.2

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Safety check for remaining chips
            if remaining_chips <= 0:
                return (PokerAction.FOLD, 0)
            
            # Calculate position and hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            position_factor = self._get_position_factor(round_state)
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Get opponent aggression level
            opponent_aggression = self._estimate_opponent_aggression(round_state)
            
            # Calculate the amount we need to call
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            
            # All-in threshold - go all-in if short-stacked with decent hand
            if remaining_chips <= round_state.current_bet * 3 and hand_strength > 0.6:
                return (PokerAction.ALL_IN, 0)
            
            # Pre-flop strategy
            if round_state.round == 'Preflop':
                return self._preflop_strategy(round_state, remaining_chips, hand_strength, position_factor)
            
            # Post-flop strategy
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, opponent_aggression)
            
        except Exception as e:
            # Fallback to safe action if any error occurs
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        # This is a simplified hand evaluation
        # In a real implementation, you'd want more sophisticated hand evaluation
        
        if round_state.round == 'Preflop':
            # Simple pre-flop hand strength based on community cards as proxy
            return 0.5  # Default medium strength
        
        # Post-flop evaluation based on community cards
        community_cards = round_state.community_cards
        if not community_cards:
            return 0.5
        
        # Simple heuristic based on high cards and potential
        high_cards = sum(1 for card in community_cards if card[0] in 'AKQJT')
        suited_potential = len(set(card[1] for card in community_cards)) <= 2
        
        base_strength = 0.3 + (high_cards * 0.15)
        if suited_potential:
            base_strength += 0.1
            
        return min(1.0, base_strength)

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor"""
        total_players = len(round_state.current_player) + len([p for p in round_state.player_actions.values() if p != 'Fold'])
        if total_players <= 1:
            return 1.0
        
        # In heads-up, position is very important
        if total_players == 2:
            return 1.3 if self.id == self.big_blind_player else 0.8
        
        return 1.0

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        if call_amount == 0:
            return float('inf')
        
        pot_after_call = round_state.pot + call_amount
        return pot_after_call / (call_amount + 1e-6)  # Add small epsilon to avoid division by zero

    def _estimate_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Estimate opponent aggression level"""
        aggressive_actions = sum(1 for action in round_state.player_actions.values() 
                               if action in ['Raise', 'All-in'])
        total_actions = max(1, len(round_state.player_actions))
        return aggressive_actions / total_actions

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_factor: float) -> Tuple[PokerAction, int]:
        """Pre-flop decision making"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        # Adjust hand strength by position
        adjusted_strength = hand_strength * position_factor
        
        # If no bet to us, check or bet based on hand strength
        if round_state.current_bet == 0:
            if adjusted_strength > 0.7:
                # Strong hand - bet for value
                bet_size = int(round_state.pot * 0.75)
                bet_size = max(round_state.min_raise, min(bet_size, round_state.max_raise))
                return (PokerAction.RAISE, bet_size)
            elif adjusted_strength > 0.4:
                # Medium hand - check to see flop cheaply
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check and hope to improve
                return (PokerAction.CHECK, 0)
        
        # There's a bet to us
        if call_amount > remaining_chips:
            return (PokerAction.FOLD, 0)
        
        # Calculate call threshold based on stack and position
        call_threshold = 0.3
        if self.game_stage == 'late':
            call_threshold = 0.5  # Tighter when short-stacked
        
        if adjusted_strength > 0.8:
            # Very strong hand - raise
            raise_size = int(call_amount * 2.5 + round_state.pot * 0.3)
            raise_size = max(round_state.min_raise, min(raise_size, round_state.max_raise))
            return (PokerAction.RAISE, raise_size)
        elif adjusted_strength > 0.6:
            # Good hand - call or small raise
            if call_amount <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                raise_size = max(round_state.min_raise, min(call_amount * 2, round_state.max_raise))
                return (PokerAction.RAISE, raise_size)
        elif adjusted_strength > call_threshold and call_amount <= remaining_chips * 0.15:
            # Marginal hand - call if cheap
            return (PokerAction.CALL, 0)
        else:
            # Weak hand - fold
            return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, opponent_aggression: float) -> Tuple[PokerAction, int]:
        """Post-flop decision making"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        # Adjust strategy based on opponent aggression
        aggression_adjustment = 1.0 - (opponent_aggression * 0.3)
        adjusted_strength = hand_strength * aggression_adjustment
        
        # If no bet to us
        if round_state.current_bet == 0:
            if adjusted_strength > 0.75:
                # Strong hand - bet for value
                bet_size = int(round_state.pot * 0.6)
                bet_size = max(round_state.min_raise, min(bet_size, round_state.max_raise))
                return (PokerAction.RAISE, bet_size)
            elif adjusted_strength > 0.5:
                # Medium hand - small bet or check
                if round_state.round == 'River':
                    return (PokerAction.CHECK, 0)  # Check-call river with medium hands
                else:
                    bet_size = int(round_state.pot * 0.4)
                    bet_size = max(round_state.min_raise, min(bet_size, round_state.max_raise))
                    return (PokerAction.RAISE, bet_size)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        
        # There's a bet to us
        if call_amount > remaining_chips:
            return (PokerAction.FOLD, 0)
        
        # Use pot odds for calling decisions
        required_equity = 1.0 / (pot_odds + 1) if pot_odds > 0 else 1.0
        
        if adjusted_strength > 0.8:
            # Very strong hand - raise
            raise_size = int(call_amount * 2 + round_state.pot * 0.4)
            raise_size = max(round_state.min_raise, min(raise_size, round_state.max_raise))
            return (PokerAction.RAISE, raise_size)
        elif adjusted_strength > required_equity + 0.1:
            # Good hand or good pot odds - call
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips * 0.05:
            # Very cheap call - take it
            return (PokerAction.CALL, 0)
        else:
            # Fold
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Track results and update opponent models"""
        # Update hand history
        self.hand_history.append({
            'round': round_state.round_num,
            'final_pot': round_state.pot,
            'remaining_chips': remaining_chips,
            'community_cards': round_state.community_cards.copy()
        })
        
        # Update opponent tendencies based on their actions
        for player_id, action in round_state.player_actions.items():
            player_id_int = int(player_id) if player_id.isdigit() else None
            if player_id_int and player_id_int in self.opponent_tendencies:
                self.opponent_tendencies[player_id_int]['total_hands'] += 1
                if action in ['Raise', 'Call', 'All-in']:
                    self.opponent_tendencies[player_id_int]['hands_played'] += 1
                if action in ['Raise', 'All-in']:
                    self.opponent_tendencies[player_id_int]['hands_raised'] += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Game analysis and learning"""
        # Analyze performance
        total_hands = len(self.hand_history)
        if total_hands > 0:
            # Adjust strategy based on results
            if player_score < 0:
                # Lost money - be more conservative
                self.bluff_frequency *= 0.9
                self.aggression_factor *= 0.95
            else:
                # Won money - maintain or slightly increase aggression
                self.bluff_frequency = min(0.25, self.bluff_frequency * 1.05)
                self.aggression_factor = min(1.5, self.aggression_factor * 1.02)
        
        # Reset for next game
        self.hand_history = []
        for player in self.opponent_tendencies:
            # Decay old information
            self.opponent_tendencies[player]['vpip'] *= 0.9
            self.opponent_tendencies[player]['pfr'] *= 0.9
            self.opponent_tendencies[player]['aggression'] *= 0.9