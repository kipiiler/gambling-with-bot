from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player = None
        self.small_blind_player = None
        self.game_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get betting context
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_size = round_state.pot
        
        # Calculate pot odds if we need to call
        if call_amount > 0:
            pot_odds = call_amount / (pot_size + call_amount + 0.01)  # Small epsilon to avoid division by zero
        else:
            pot_odds = 0
        
        # Determine action based on hand strength and situation
        if round_state.current_bet == 0:
            # No bet to us - we can check or bet
            if hand_strength >= 0.7:
                # Strong hand - bet for value
                bet_size = max(round_state.min_raise, min(pot_size // 2, remaining_chips))
                return (PokerAction.RAISE, bet_size)
            elif hand_strength >= 0.4:
                # Medium hand - sometimes bet, sometimes check
                if len(round_state.community_cards) <= 3:  # Preflop or flop
                    bet_size = max(round_state.min_raise, min(pot_size // 3, remaining_chips))
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to us
            if hand_strength >= 0.8:
                # Very strong hand - raise
                raise_size = max(round_state.min_raise, min(round_state.current_bet * 2, remaining_chips))
                if raise_size <= remaining_chips and raise_size >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength >= 0.6:
                # Good hand - call
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif hand_strength >= 0.3 and pot_odds <= 0.3:
                # Decent hand with good pot odds - call
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand - fold
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.2
        
        # Parse hole cards
        card1_rank, card1_suit = self._parse_card(self.hole_cards[0])
        card2_rank, card2_suit = self._parse_card(self.hole_cards[1])
        
        # Base strength from hole cards
        strength = self._evaluate_preflop_strength(card1_rank, card2_rank, card1_suit == card2_suit)
        
        # Adjust based on community cards
        if round_state.community_cards:
            all_cards = self.hole_cards + round_state.community_cards
            strength = self._evaluate_postflop_strength(all_cards)
        
        return min(1.0, max(0.0, strength))
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string like 'As' into rank and suit"""
        if len(card) != 2:
            return (2, 'h')
        
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_char, 2)
        return (rank, suit)
    
    def _evaluate_preflop_strength(self, rank1: int, rank2: int, suited: bool) -> float:
        """Evaluate preflop hand strength"""
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        # Pocket pairs
        if rank1 == rank2:
            if high_rank >= 13:  # AA, KK
                return 0.9
            elif high_rank >= 11:  # QQ, JJ
                return 0.8
            elif high_rank >= 9:   # TT, 99
                return 0.7
            elif high_rank >= 7:   # 88, 77
                return 0.6
            else:                  # 66 and below
                return 0.5
        
        # High cards
        if high_rank == 14:  # Ace
            if low_rank >= 12:  # AK, AQ
                return 0.75 if suited else 0.7
            elif low_rank >= 10:  # AJ, AT
                return 0.65 if suited else 0.6
            elif low_rank >= 8:   # A9, A8
                return 0.55 if suited else 0.45
            else:
                return 0.4 if suited else 0.3
        
        if high_rank == 13:  # King
            if low_rank >= 11:  # KQ, KJ
                return 0.65 if suited else 0.6
            elif low_rank >= 9:   # KT, K9
                return 0.55 if suited else 0.45
            else:
                return 0.35 if suited else 0.25
        
        if high_rank >= 11 and low_rank >= 10:  # QJ, QT, JT
            return 0.6 if suited else 0.5
        
        # Connected cards
        if abs(high_rank - low_rank) == 1 and low_rank >= 6:  # Connected 6+ high
            return 0.45 if suited else 0.35
        
        # Default for weak hands
        return 0.25 if suited else 0.15

    def _evaluate_postflop_strength(self, all_cards: List[str]) -> float:
        """Evaluate hand strength with community cards"""
        if len(all_cards) < 5:
            return 0.3
        
        # Parse all cards
        parsed_cards = [self._parse_card(card) for card in all_cards]
        ranks = [card[0] for card in parsed_cards]
        suits = [card[1] for card in parsed_cards]
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        sorted_ranks = sorted(ranks, reverse=True)
        
        # Check for various hands
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        rank_count_values = sorted(rank_counts.values(), reverse=True)
        
        # Four of a kind
        if 4 in rank_count_values:
            return 0.95
        
        # Full house
        if rank_count_values == [3, 2] or (rank_count_values[0] == 3 and len(rank_count_values) >= 2):
            return 0.9
        
        # Flush
        if max_suit_count >= 5:
            return 0.85
        
        # Straight (simplified check)
        if self._has_straight(sorted_ranks):
            return 0.8
        
        # Three of a kind
        if 3 in rank_count_values:
            return 0.75
        
        # Two pair
        if rank_count_values.count(2) >= 2:
            return 0.65
        
        # One pair
        if 2 in rank_count_values:
            pair_rank = max([rank for rank, count in rank_counts.items() if count == 2])
            if pair_rank >= 11:  # JJ+
                return 0.6
            elif pair_rank >= 8:   # 88+
                return 0.5
            else:
                return 0.4
        
        # High card
        if sorted_ranks[0] >= 13:  # A or K high
            return 0.35
        else:
            return 0.2
    
    def _has_straight(self, sorted_ranks: List[int]) -> bool:
        """Check if ranks contain a straight"""
        unique_ranks = list(set(sorted_ranks))
        unique_ranks.sort(reverse=True)
        
        # Check for A-2-3-4-5 straight (wheel)
        if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
        
        # Check for regular straights
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                return True
        
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.game_history.append({
            'score': player_score,
            'all_scores': all_scores,
            'hands': active_players_hands
        })