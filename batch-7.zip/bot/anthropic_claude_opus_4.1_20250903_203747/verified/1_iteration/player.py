from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_stats = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hand_count += 1
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id and player not in self.opponent_stats:
                self.opponent_stats[player] = {
                    'vpip': 0,  # Voluntarily put in pot
                    'pfr': 0,   # Pre-flop raise
                    'hands': 0,
                    'aggression': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)  # Avoid division by zero
        
        # Get hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Position awareness
        is_late_position = self.is_late_position(round_state)
        
        # Stack size considerations
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self.get_preflop_action(round_state, remaining_chips, hand_strength, is_late_position)
        else:
            return self.get_postflop_action(round_state, remaining_chips, hand_strength, pot_odds, stack_to_pot_ratio)

    def get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, is_late_position: bool) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Premium hands (AA, KK, QQ, AK)
        if hand_strength > 0.85:
            if round_state.current_bet > 0:
                # 3-bet or 4-bet with premium hands
                raise_amount = min(round_state.current_bet * 3, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif remaining_chips > to_call:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Open raise
                raise_amount = min(self.blind_amount * 3, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0) if to_call <= remaining_chips else (PokerAction.ALL_IN, 0)
        
        # Good hands (JJ, TT, AQ, AJ)
        elif hand_strength > 0.70:
            if round_state.current_bet > self.blind_amount * 4:
                # Fold to large raises unless we have position
                if not is_late_position and to_call > remaining_chips * 0.2:
                    return (PokerAction.FOLD, 0)
            if round_state.current_bet == 0:
                raise_amount = min(self.blind_amount * 2.5, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif to_call <= remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Playable hands in position
        elif hand_strength > 0.50 and is_late_position:
            if round_state.current_bet == 0:
                # Steal blinds
                if random.random() < 0.4:
                    raise_amount = min(self.blind_amount * 2, remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount and hand_strength > 0.35:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, spr: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot = round_state.pot
        
        # Very strong hands (sets, two pair+, strong draws)
        if hand_strength > 0.75:
            if round_state.current_bet > 0:
                # Value raise
                raise_amount = min(int(pot * 0.75), remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif remaining_chips > to_call:
                    return (PokerAction.CALL, 0)
            else:
                # Bet for value
                bet_amount = min(int(pot * 0.6), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands (top pair, overpair)
        elif hand_strength > 0.60:
            if round_state.current_bet > 0:
                # Call if pot odds are good
                if pot_odds < hand_strength - 0.1:
                    return (PokerAction.CALL, 0) if to_call <= remaining_chips else (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Bet for value/protection
                if random.random() < 0.7:
                    bet_amount = min(int(pot * 0.5), remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Marginal hands
        elif hand_strength > 0.40:
            if round_state.current_bet > 0:
                # Only call small bets
                if to_call <= pot * 0.3 and pot_odds < hand_strength:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Check or occasional bluff
                if random.random() < 0.15 and round_state.round == 'River':
                    bet_amount = min(int(pot * 0.4), remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Weak hands
        else:
            if round_state.current_bet == 0:
                # Bluff occasionally
                if random.random() < 0.1:
                    bet_amount = min(int(pot * 0.3), remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        if not self.hole_cards:
            return 0.5
        
        # Convert cards to values for evaluation
        card1_rank = self.card_rank(self.hole_cards[0])
        card2_rank = self.card_rank(self.hole_cards[1])
        suited = self.hole_cards[0][-1] == self.hole_cards[1][-1]
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 12:  # AA, KK, QQ
                    return 0.95
                elif card1_rank >= 10:  # JJ, TT
                    return 0.80
                elif card1_rank >= 8:  # 99, 88
                    return 0.70
                else:
                    return 0.60
            
            # High cards
            high_card = max(card1_rank, card2_rank)
            low_card = min(card1_rank, card2_rank)
            gap = high_card - low_card
            
            if high_card == 14:  # Ace high
                if low_card >= 11:  # AK, AQ, AJ
                    return 0.85 if suited else 0.80
                elif low_card >= 9:  # AT, A9
                    return 0.70 if suited else 0.65
                else:
                    return 0.55 if suited else 0.50
            elif high_card == 13:  # King high
                if low_card >= 11:  # KQ, KJ
                    return 0.70 if suited else 0.65
                else:
                    return 0.55 if suited else 0.50
            elif high_card >= 11:  # Queen or Jack high
                if gap <= 2:
                    return 0.60 if suited else 0.55
                else:
                    return 0.45 if suited else 0.40
            else:
                if gap <= 1 and suited:
                    return 0.50
                elif gap <= 2:
                    return 0.45 if suited else 0.40
                else:
                    return 0.35
        
        # Postflop hand strength (simplified)
        else:
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for pairs, sets, etc.
            ranks = [self.card_rank(card) for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            # Check for flush potential
            suits = [card[-1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            max_same_rank = max(rank_counts.values())
            max_same_suit = max(suit_counts.values())
            
            # Simplified strength evaluation
            if max_same_rank >= 4:  # Four of a kind
                return 0.98
            elif max_same_rank == 3:  # Three of a kind
                if len([v for v in rank_counts.values() if v >= 2]) >= 2:  # Full house
                    return 0.95
                return 0.80
            elif max_same_suit >= 5:  # Flush
                return 0.85
            elif self.has_straight(ranks):  # Straight
                return 0.75
            elif max_same_rank == 2:  # Pair(s)
                pairs = len([v for v in rank_counts.values() if v == 2])
                if pairs >= 2:  # Two pair
                    return 0.70
                else:  # One pair
                    # Check if we have top pair
                    paired_rank = max([k for k, v in rank_counts.items() if v == 2])
                    if paired_rank == max(ranks):
                        return 0.65
                    return 0.55
            else:  # High card
                return 0.35 + (max(card1_rank, card2_rank) / 14) * 0.15

    def card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)

    def has_straight(self, ranks: List[int]) -> bool:
        """Check if we have a straight"""
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) < 5:
            return False
        
        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5 straight
        if 14 in unique_ranks and set([2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
        
        return False

    def is_late_position(self, round_state: RoundStateClient) -> bool:
        """Determine if we're in late position"""
        active_players = len(round_state.current_player)
        if active_players <= 2:
            return True
        # Simplified position check
        return random.random() < 0.5

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass