from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.blind_amount = 0
        self.starting_chips = 0
        self.game_count = 0
        self.is_big_blind = False
        self.is_small_blind = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.game_count += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current state information
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot_size + to_call + 0.001)
        else:
            pot_odds = 0
        
        # Position-based strategy adjustments
        num_active = len([p for p in round_state.current_player])
        position_factor = 1.0
        if self.is_small_blind:
            position_factor = 0.9  # Worse position
        elif self.is_big_blind:
            position_factor = 0.95
        
        # Adjust hand strength based on position
        adjusted_strength = hand_strength * position_factor
        
        # Decision logic based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(adjusted_strength, to_call, pot_size, 
                                         min_raise, max_raise, remaining_chips, pot_odds)
        else:
            return self._postflop_strategy(adjusted_strength, to_call, pot_size, 
                                         min_raise, max_raise, remaining_chips, pot_odds, round_state)

    def _preflop_strategy(self, hand_strength, to_call, pot_size, min_raise, 
                         max_raise, remaining_chips, pot_odds):
        # Premium hands (AA, KK, QQ, AK)
        if hand_strength > 0.85:
            if to_call > 0:
                # Strong reraise with premium hands
                raise_amount = min(max(min_raise, pot_size), max_raise)
                if raise_amount >= min_raise and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Open raise
                raise_amount = min(self.blind_amount * 3, max_raise)
                if raise_amount >= min_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands (JJ, TT, AQ, AJ)
        elif hand_strength > 0.7:
            if to_call <= self.blind_amount * 3:
                if to_call > 0:
                    return (PokerAction.CALL, 0)
                else:
                    raise_amount = min(self.blind_amount * 2, max_raise)
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Playable hands
        elif hand_strength > 0.5:
            if to_call <= self.blind_amount:
                if to_call > 0:
                    return (PokerAction.CALL, 0)
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif self.is_big_blind and to_call <= self.blind_amount:
                # Defend big blind with reasonable odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, hand_strength, to_call, pot_size, min_raise, 
                          max_raise, remaining_chips, pot_odds, round_state):
        community_cards = round_state.community_cards
        
        # Very strong hands (likely best hand)
        if hand_strength > 0.8:
            if to_call > 0:
                # Value raise
                raise_amount = min(max(min_raise, pot_size // 2), max_raise)
                if raise_amount >= min_raise and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            else:
                # Bet for value
                bet_amount = min(pot_size // 2, max_raise)
                if bet_amount >= min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands
        elif hand_strength > 0.6:
            if to_call > 0:
                if pot_odds < 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Small bet or check
                if round_state.round == 'River':
                    return (PokerAction.CHECK, 0)
                bet_amount = min(pot_size // 3, max_raise)
                if bet_amount >= min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Marginal hands
        elif hand_strength > 0.4:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                # Occasional bluff
                if pot_size > 0 and remaining_chips > pot_size * 2:
                    bluff_frequency = 0.1
                    import random
                    if random.random() < bluff_frequency:
                        bluff_amount = min(pot_size // 2, max_raise)
                        if bluff_amount >= min_raise:
                            return (PokerAction.RAISE, bluff_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        if len(self.hole_cards) < 2:
            return 0.5
        
        card1 = self.hole_cards[0]
        card2 = self.hole_cards[1]
        
        rank1 = self._card_rank(card1)
        rank2 = self._card_rank(card2)
        suited = (card1[1] == card2[1])
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # AA, KK, QQ
                    return 0.95
                elif rank1 >= 10:  # JJ, TT
                    return 0.80
                elif rank1 >= 8:  # 99, 88
                    return 0.70
                elif rank1 >= 6:  # 77, 66
                    return 0.60
                else:  # Small pairs
                    return 0.55
            
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            gap = high_rank - low_rank
            
            # Ace high
            if high_rank == 14:
                if low_rank >= 11:  # AK, AQ, AJ
                    return 0.85 if suited else 0.80
                elif low_rank >= 9:  # AT, A9
                    return 0.70 if suited else 0.65
                else:
                    return 0.55 if suited else 0.50
            
            # King high
            elif high_rank == 13:
                if low_rank >= 11:  # KQ, KJ
                    return 0.70 if suited else 0.65
                elif low_rank >= 9:
                    return 0.60 if suited else 0.55
                else:
                    return 0.45
            
            # Connected cards
            elif gap <= 1:
                if high_rank >= 10:
                    return 0.65 if suited else 0.60
                elif high_rank >= 7:
                    return 0.55 if suited else 0.50
                else:
                    return 0.45 if suited else 0.40
            
            # Other hands
            else:
                if high_rank >= 10:
                    return 0.50 if suited else 0.45
                else:
                    return 0.40 if suited else 0.35
        
        # Postflop evaluation
        else:
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Simple postflop evaluation
            has_pair = self._has_pair(all_cards)
            has_two_pair = self._has_two_pair(all_cards)
            has_trips = self._has_trips(all_cards)
            has_straight = self._has_straight(all_cards)
            has_flush = self._has_flush(all_cards)
            
            if has_flush:
                return 0.90
            elif has_straight:
                return 0.85
            elif has_trips:
                return 0.80
            elif has_two_pair:
                return 0.70
            elif has_pair:
                # Check if we have top pair
                if self._has_top_pair(self.hole_cards, community):
                    return 0.65
                return 0.55
            else:
                # High card
                if self._has_high_card(self.hole_cards, community):
                    return 0.45
                return 0.35

    def _card_rank(self, card: str) -> int:
        """Convert card rank to numeric value"""
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)

    def _has_pair(self, cards: List[str]) -> bool:
        ranks = [self._card_rank(card) for card in cards]
        for i in range(len(ranks)):
            for j in range(i + 1, len(ranks)):
                if ranks[i] == ranks[j]:
                    return True
        return False

    def _has_two_pair(self, cards: List[str]) -> bool:
        ranks = [self._card_rank(card) for card in cards]
        pairs = 0
        used = set()
        for i in range(len(ranks)):
            if ranks[i] not in used:
                for j in range(i + 1, len(ranks)):
                    if ranks[i] == ranks[j]:
                        pairs += 1
                        used.add(ranks[i])
                        break
        return pairs >= 2

    def _has_trips(self, cards: List[str]) -> bool:
        ranks = [self._card_rank(card) for card in cards]
        for i in range(len(ranks)):
            count = 1
            for j in range(i + 1, len(ranks)):
                if ranks[i] == ranks[j]:
                    count += 1
            if count >= 3:
                return True
        return False

    def _has_straight(self, cards: List[str]) -> bool:
        if len(cards) < 5:
            return False
        ranks = sorted(set([self._card_rank(card) for card in cards]))
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        # Check for A-2-3-4-5
        if 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
            return True
        return False

    def _has_flush(self, cards: List[str]) -> bool:
        if len(cards) < 5:
            return False
        suits = {}
        for card in cards:
            suit = card[1]
            suits[suit] = suits.get(suit, 0) + 1
            if suits[suit] >= 5:
                return True
        return False

    def _has_top_pair(self, hole_cards: List[str], community: List[str]) -> bool:
        if not community:
            return False
        hole_ranks = [self._card_rank(card) for card in hole_cards]
        comm_ranks = [self._card_rank(card) for card in community]
        max_comm = max(comm_ranks) if comm_ranks else 0
        for rank in hole_ranks:
            if rank == max_comm:
                return True
        return False

    def _has_high_card(self, hole_cards: List[str], community: List[str]) -> bool:
        hole_ranks = [self._card_rank(card) for card in hole_cards]
        max_hole = max(hole_ranks) if hole_ranks else 0
        return max_hole >= 12  # Q or higher

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass