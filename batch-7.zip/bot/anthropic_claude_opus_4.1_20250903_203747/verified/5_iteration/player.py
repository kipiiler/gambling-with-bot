from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_fold_rate = {}
        self.opponent_raise_count = {}
        self.opponent_call_count = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hand_count = 0
        
        for player in all_players:
            if player != self.id:
                self.opponent_fold_rate[str(player)] = 0.5
                self.opponent_raise_count[str(player)] = 0
                self.opponent_call_count[str(player)] = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.hand_count += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get position info
        is_button = self._is_button(round_state)
        is_big_blind = (self.id == self.big_blind_player)
        
        # Adjust strategy based on round
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, hand_strength, is_button, is_big_blind)
        else:
            return self._get_postflop_action(round_state, remaining_chips, hand_strength, pot_odds, to_call)

    def _get_preflop_action(self, round_state, remaining_chips, hand_strength, is_button, is_big_blind):
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot = round_state.pot
        
        # Premium hands - always raise aggressively
        if hand_strength >= 0.85:
            raise_amount = min(int(pot * 3.5), remaining_chips)
            if raise_amount >= round_state.min_raise:
                return (PokerAction.RAISE, raise_amount)
            elif remaining_chips > 0:
                return (PokerAction.ALL_IN, 0)
                
        # Strong hands - raise or call
        elif hand_strength >= 0.70:
            if round_state.current_bet == self.blind_amount:  # No one raised
                raise_amount = min(int(self.blind_amount * 3), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            if to_call <= remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
                
        # Good hands in position
        elif hand_strength >= 0.55 and is_button:
            if round_state.current_bet == self.blind_amount:
                raise_amount = min(int(self.blind_amount * 2.5), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            if to_call <= remaining_chips * 0.10:
                return (PokerAction.CALL, 0)
                
        # Decent hands - call small bets
        elif hand_strength >= 0.45:
            if to_call <= remaining_chips * 0.08:
                return (PokerAction.CALL, 0)
                
        # Weak hands in big blind - check if possible
        elif is_big_blind and to_call == 0:
            return (PokerAction.CHECK, 0)
            
        return (PokerAction.FOLD, 0)

    def _get_postflop_action(self, round_state, remaining_chips, hand_strength, pot_odds, to_call):
        pot = round_state.pot
        
        # Very strong hands - bet/raise aggressively
        if hand_strength >= 0.85:
            if round_state.current_bet == 0:
                bet_amount = min(int(pot * 0.75), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            else:
                raise_amount = min(int(pot * 0.8), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                    
        # Strong hands - bet/call
        elif hand_strength >= 0.70:
            if round_state.current_bet == 0:
                bet_amount = min(int(pot * 0.6), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength - 0.2:
                return (PokerAction.CALL, 0)
                
        # Medium hands - check/call if good odds
        elif hand_strength >= 0.50:
            if round_state.current_bet == 0:
                # Sometimes bluff
                if random.random() < 0.15:
                    bet_amount = min(int(pot * 0.4), remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength - 0.15:
                return (PokerAction.CALL, 0)
                
        # Weak hands but drawing
        elif hand_strength >= 0.35:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.20:  # Good pot odds
                return (PokerAction.CALL, 0)
                
        # Very weak hands
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
            
        return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state):
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.5
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = (card1[-1] == card2[-1])
        
        if round_state.round == 'Preflop':
            # Premium pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                elif rank1 >= 6:  # 66-77
                    return 0.65
                else:  # 22-55
                    return 0.55
                    
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            gap = high_rank - low_rank
            
            # High cards
            if high_rank == 14:  # Ace
                if low_rank >= 12:  # AQ+
                    return 0.85 if suited else 0.80
                elif low_rank >= 10:  # AT-AJ
                    return 0.75 if suited else 0.70
                elif low_rank >= 8:
                    return 0.65 if suited else 0.55
                else:
                    return 0.50 if suited else 0.40
                    
            # King high
            elif high_rank == 13:
                if low_rank >= 11:  # KJ+
                    return 0.75 if suited else 0.70
                elif low_rank >= 9:
                    return 0.65 if suited else 0.55
                else:
                    return 0.45 if suited else 0.35
                    
            # Queen/Jack high
            elif high_rank >= 11:
                if gap <= 2:
                    return 0.65 if suited else 0.55
                else:
                    return 0.45 if suited else 0.35
                    
            # Connectors
            if gap == 1:
                return 0.55 if suited else 0.45
            elif gap == 2:
                return 0.45 if suited else 0.35
                
            return 0.30
            
        else:
            # Postflop evaluation
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for pairs, sets, etc.
            ranks = [self._card_rank(c) for c in all_cards]
            rank_counts = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1
                
            hole_ranks = [rank1, rank2]
            
            # Check for made hands
            max_count = max(rank_counts.values())
            
            # Four of a kind
            if max_count == 4:
                for hr in hole_ranks:
                    if rank_counts.get(hr, 0) == 4:
                        return 0.99
                return 0.95
                
            # Full house or three of a kind
            if max_count == 3:
                has_pair = len([c for c in rank_counts.values() if c >= 2]) >= 2
                if has_pair:  # Full house
                    return 0.95
                # Three of a kind
                for hr in hole_ranks:
                    if rank_counts.get(hr, 0) == 3:
                        return 0.85
                return 0.70
                
            # Check for flush
            suits = [c[-1] for c in all_cards]
            suit_counts = {}
            for s in suits:
                suit_counts[s] = suit_counts.get(s, 0) + 1
            if max(suit_counts.values()) >= 5:
                hole_suits = [card1[-1], card2[-1]]
                for hs in hole_suits:
                    if suit_counts.get(hs, 0) >= 5:
                        return 0.90
                        
            # Check for straight
            unique_ranks = sorted(set(ranks))
            if 14 in unique_ranks:  # Ace can be low
                unique_ranks.append(1)
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    if rank1 in unique_ranks[i:i+5] or rank2 in unique_ranks[i:i+5]:
                        return 0.85
                        
            # Two pair or pair
            pairs = [r for r, c in rank_counts.items() if c == 2]
            if len(pairs) >= 2:  # Two pair
                if rank1 in pairs or rank2 in pairs:
                    return 0.75
                return 0.60
            elif len(pairs) == 1:  # One pair
                if rank1 in pairs or rank2 in pairs:
                    if pairs[0] >= 12:  # High pair
                        return 0.70
                    return 0.60
                return 0.45
                
            # High card only
            if max(rank1, rank2) >= 13:  # Ace or King
                return 0.40
            return 0.30

    def _card_rank(self, card):
        if not card or len(card) < 1:
            return 0
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0

    def _is_button(self, round_state):
        active_players = round_state.current_player
        if len(active_players) == 2:
            return self.id == self.small_blind_player
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track opponent tendencies
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action == 'Fold':
                    self.opponent_fold_rate[player_id] = self.opponent_fold_rate.get(player_id, 0.5) * 0.9 + 0.1
                elif action == 'Raise' or action == 'All-in':
                    self.opponent_raise_count[player_id] = self.opponent_raise_count.get(player_id, 0) + 1
                elif action == 'Call':
                    self.opponent_call_count[player_id] = self.opponent_call_count.get(player_id, 0) + 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass