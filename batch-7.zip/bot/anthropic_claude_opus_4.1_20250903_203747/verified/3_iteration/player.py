from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.opponent_stats = {}  # Track opponent behavior
        self.hands_played = 0
        self.position = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                if player_id not in self.opponent_stats:
                    self.opponent_stats[player_id] = {
                        'fold_count': 0,
                        'raise_count': 0,
                        'call_count': 0,
                        'total_actions': 0,
                        'aggression_factor': 0.5
                    }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        # Determine position
        if self.id == self.big_blind_player:
            self.position = 'BB'
        elif self.id == self.small_blind_player:
            self.position = 'SB'
        else:
            self.position = 'BTN'
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate pot odds
        pot = round_state.pot
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot_odds = to_call / (pot + to_call + 0.001) if to_call > 0 else 0
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get opponent aggression
        avg_aggression = self._get_average_opponent_aggression()
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, avg_aggression)
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, 
                          hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        
        # Premium hands - always raise/reraise
        if hand_strength > 0.85:
            if to_call == 0:
                raise_amount = min(remaining_chips, round_state.pot * 3)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.3:
                raise_amount = min(remaining_chips, to_call * 3)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
        
        # Strong hands - raise or call
        elif hand_strength > 0.7:
            if to_call == 0:
                raise_amount = min(remaining_chips, round_state.pot * 2)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.2:
                if random.random() < 0.6:
                    raise_amount = min(remaining_chips, to_call * 2.5)
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands - sometimes raise, call small bets
        elif hand_strength > 0.5:
            if to_call == 0:
                if random.random() < 0.4:
                    raise_amount = min(remaining_chips, round_state.pot * 1.5)
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount * 3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - fold or check
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif self.position == 'BB' and to_call <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int,
                           hand_strength: float, pot_odds: float, avg_aggression: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        
        # Adjust strategy based on opponent aggression
        aggression_adjustment = 1.0 + (0.5 - avg_aggression) * 0.3
        
        # Very strong hands - bet/raise aggressively
        if hand_strength > 0.8:
            if to_call == 0:
                bet_size = min(remaining_chips, int(pot * 0.75 * aggression_adjustment))
                return (PokerAction.RAISE, bet_size)
            elif to_call < remaining_chips * 0.5:
                raise_amount = min(remaining_chips, int(to_call * 2.5))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
        
        # Good hands - bet for value or call
        elif hand_strength > 0.6:
            if to_call == 0:
                if random.random() < 0.7:
                    bet_size = min(remaining_chips, int(pot * 0.5 * aggression_adjustment))
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength - 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Drawing hands or medium strength
        elif hand_strength > 0.4:
            if to_call == 0:
                # Semi-bluff occasionally
                if random.random() < 0.3 * aggression_adjustment:
                    bet_size = min(remaining_chips, int(pot * 0.4))
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - check or fold
        else:
            if to_call == 0:
                # Bluff occasionally
                if random.random() < 0.15 * aggression_adjustment and pot < remaining_chips * 0.3:
                    bet_size = min(remaining_chips, int(pot * 0.3))
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        if round_state.round == 'Preflop':
            # Preflop hand strength evaluation
            is_pair = rank1 == rank2
            is_suited = suit1 == suit2
            high_card = max(rank1, rank2)
            low_card = min(rank1, rank2)
            gap = high_card - low_card
            
            # Premium pairs
            if is_pair:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                elif rank1 >= 5:  # 55-77
                    return 0.65
                else:  # 22-44
                    return 0.55
            
            # High cards
            if high_card == 14:  # Ace
                if low_card >= 11:  # AJ+
                    return 0.85 if is_suited else 0.80
                elif low_card >= 9:  # A9-AT
                    return 0.70 if is_suited else 0.65
                else:
                    return 0.60 if is_suited else 0.50
            
            # Broadway cards
            if high_card >= 11 and low_card >= 10:  # JT+
                return 0.75 if is_suited else 0.70
            
            # Suited connectors
            if is_suited and gap == 1:
                if high_card >= 9:
                    return 0.65
                else:
                    return 0.55
            
            # Other hands
            if high_card >= 11:
                return 0.55
            elif high_card >= 9:
                return 0.45
            else:
                return 0.35
        
        else:
            # Postflop evaluation
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for made hands
            has_pair = self._has_pair(all_cards)
            has_two_pair = self._has_two_pair(all_cards)
            has_trips = self._has_trips(all_cards)
            has_straight = self._has_straight(all_cards)
            has_flush = self._has_flush(all_cards)
            
            if has_flush:
                return 0.85
            elif has_straight:
                return 0.80
            elif has_trips:
                return 0.75
            elif has_two_pair:
                return 0.65
            elif has_pair:
                # Check if we have top pair
                if self._has_top_pair(self.hole_cards, community):
                    return 0.60
                else:
                    return 0.50
            else:
                # High card or draws
                if self._has_flush_draw(all_cards):
                    return 0.45
                elif self._has_straight_draw(all_cards):
                    return 0.40
                else:
                    return 0.30
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank and suit"""
        if len(card) < 2:
            return (2, 's')
        
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
    
    def _has_pair(self, cards: List[str]) -> bool:
        ranks = [self._parse_card(card)[0] for card in cards]
        for rank in set(ranks):
            if ranks.count(rank) >= 2:
                return True
        return False
    
    def _has_two_pair(self, cards: List[str]) -> bool:
        ranks = [self._parse_card(card)[0] for card in cards]
        pairs = 0
        for rank in set(ranks):
            if ranks.count(rank) >= 2:
                pairs += 1
        return pairs >= 2
    
    def _has_trips(self, cards: List[str]) -> bool:
        ranks = [self._parse_card(card)[0] for card in cards]
        for rank in set(ranks):
            if ranks.count(rank) >= 3:
                return True
        return False
    
    def _has_straight(self, cards: List[str]) -> bool:
        if len(cards) < 5:
            return False
        ranks = sorted(set([self._parse_card(card)[0] for card in cards]))
        if 14 in ranks:
            ranks.append(1)
        
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        return False
    
    def _has_flush(self, cards: List[str]) -> bool:
        if len(cards) < 5:
            return False
        suits = [self._parse_card(card)[1] for card in cards]
        for suit in set(suits):
            if suits.count(suit) >= 5:
                return True
        return False
    
    def _has_top_pair(self, hole_cards: List[str], community: List[str]) -> bool:
        if not community:
            return False
        community_ranks = [self._parse_card(card)[0] for card in community]
        max_community = max(community_ranks) if community_ranks else 0
        hole_ranks = [self._parse_card(card)[0] for card in hole_cards]
        return max_community in hole_ranks
    
    def _has_flush_draw(self, cards: List[str]) -> bool:
        if len(cards) < 4:
            return False
        suits = [self._parse_card(card)[1] for card in cards]
        for suit in set(suits):
            if suits.count(suit) == 4:
                return True
        return False
    
    def _has_straight_draw(self, cards: List[str]) -> bool:
        if len(cards) < 4:
            return False
        ranks = sorted(set([self._parse_card(card)[0] for card in cards]))
        if 14 in ranks:
            ranks.append(1)
        
        for i in range(len(ranks) - 3):
            if ranks[i+3] - ranks[i] <= 4:
                return True
        return False
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics based on their actions"""
        for player_id, action in round_state.player_actions.items():
            player_id_int = int(player_id)
            if player_id_int != self.id and player_id_int in self.opponent_stats:
                stats = self.opponent_stats[player_id_int]
                stats['total_actions'] += 1
                
                if action == 'Fold':
                    stats['fold_count'] += 1
                elif action == 'Raise' or action == 'All-in':
                    stats['raise_count'] += 1
                elif action == 'Call':
                    stats['call_count'] += 1
                
                # Calculate aggression factor
                if stats['total_actions'] > 0:
                    stats['aggression_factor'] = (stats['raise_count'] + 0.5 * stats['call_count']) / (stats['total_actions'] + 0.001)
    
    def _get_average_opponent_aggression(self) -> float:
        """Get average aggression factor of active opponents"""
        if not self.opponent_stats:
            return 0.5
        
        active_aggression = []
        for player_id, stats in self.opponent_stats.items():
            if stats['total_actions'] > 0:
                active_aggression.append(stats['aggression_factor'])
        
        if active_aggression:
            return sum(active_aggression) / len(active_aggression)
        return 0.5
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass