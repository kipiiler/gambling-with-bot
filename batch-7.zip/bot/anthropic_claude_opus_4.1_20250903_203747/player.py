from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.game_count = 0
        self.position = None  # 'small_blind', 'big_blind', or 'other'
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand_cards = player_hands
        self.game_count += 1
        
        # Determine our position
        if self.id == small_blind_player_id:
            self.position = 'small_blind'
        elif self.id == big_blind_player_id:
            self.position = 'big_blind'
        else:
            self.position = 'other'
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current betting situation
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Get pot odds
        pot_odds = self.calculate_pot_odds(round_state, amount_to_call)
        
        # Decision logic based on round
        if round_state.round == 'Preflop':
            return self.preflop_strategy(hand_strength, round_state, remaining_chips, amount_to_call)
        else:
            return self.postflop_strategy(hand_strength, round_state, remaining_chips, amount_to_call, pot_odds)
    
    def preflop_strategy(self, hand_strength: float, round_state: RoundStateClient, 
                         remaining_chips: int, amount_to_call: int) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # If we can check (no one raised), be selective
        if amount_to_call == 0:
            if hand_strength >= 0.6:  # Good hand, raise
                raise_amount = min(round_state.pot * 2, remaining_chips)
                # Make sure raise is valid
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            # Medium hands or if we can't raise properly, just check
            return (PokerAction.CHECK, 0)
        
        # Someone raised, we need to decide whether to call/raise/fold
        if hand_strength >= 0.75:  # Very strong hand
            # Re-raise if we can
            raise_amount = min(amount_to_call * 3, remaining_chips)
            total_bet_after_raise = my_current_bet + raise_amount
            if total_bet_after_raise > round_state.current_bet and raise_amount >= round_state.min_raise:
                return (PokerAction.RAISE, raise_amount)
            # If we can't raise properly, just call
            return (PokerAction.CALL, 0)
        elif hand_strength >= 0.5:  # Decent hand
            # Call if pot odds are good
            if amount_to_call <= round_state.pot * 0.5:
                return (PokerAction.CALL, 0)
        
        # Weak hand, fold
        return (PokerAction.FOLD, 0)
    
    def postflop_strategy(self, hand_strength: float, round_state: RoundStateClient,
                         remaining_chips: int, amount_to_call: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Post-flop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # If we can check
        if amount_to_call == 0:
            if hand_strength >= 0.7:  # Strong hand, bet for value
                bet_amount = min(int(round_state.pot * 0.75), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            elif hand_strength >= 0.4:  # Medium hand, check
                return (PokerAction.CHECK, 0)
            else:  # Weak hand but free to check
                return (PokerAction.CHECK, 0)
        
        # Someone bet, we need to respond
        if hand_strength >= 0.8:  # Very strong hand
            # Raise for value
            raise_amount = min(amount_to_call * 2, remaining_chips)
            total_bet_after_raise = my_current_bet + raise_amount
            if total_bet_after_raise > round_state.current_bet and raise_amount >= round_state.min_raise:
                return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        elif hand_strength >= 0.5:  # Decent hand
            # Call if pot odds are favorable
            if pot_odds >= hand_strength:
                return (PokerAction.CALL, 0)
        
        # Weak hand and bad pot odds
        return (PokerAction.FOLD, 0)
    
    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """
        Evaluate hand strength on a scale of 0 to 1.
        Simple heuristic based on high cards and pairs.
        """
        if not self.hand_cards:
            return 0.3
        
        # Convert cards to values
        card_values = []
        for card in self.hand_cards:
            rank = card[0]
            if rank == 'A':
                card_values.append(14)
            elif rank == 'K':
                card_values.append(13)
            elif rank == 'Q':
                card_values.append(12)
            elif rank == 'J':
                card_values.append(11)
            elif rank == 'T':
                card_values.append(10)
            else:
                try:
                    card_values.append(int(rank))
                except:
                    card_values.append(5)  # Default for parsing errors
        
        if len(card_values) < 2:
            return 0.3
        
        # Check for pair
        is_pair = card_values[0] == card_values[1]
        
        # Check for suited (if we have suit info)
        is_suited = False
        if len(self.hand_cards[0]) > 1 and len(self.hand_cards[1]) > 1:
            is_suited = self.hand_cards[0][-1] == self.hand_cards[1][-1]
        
        # Calculate base strength
        high_card = max(card_values)
        low_card = min(card_values)
        
        # Preflop hand strength estimation
        strength = 0.0
        
        if is_pair:
            # Pocket pairs are strong
            strength = 0.6 + (high_card / 14) * 0.3
        else:
            # High cards
            strength = (high_card / 14) * 0.4 + (low_card / 14) * 0.2
            
            # Bonus for suited
            if is_suited:
                strength += 0.05
            
            # Bonus for connected cards (straight potential)
            gap = abs(high_card - low_card)
            if gap == 1:
                strength += 0.05
            elif gap == 2:
                strength += 0.03
        
        # Adjust based on community cards if post-flop
        if round_state.community_cards:
            # Simple adjustment: reduce strength slightly as more cards come
            # (since opponent could have improved)
            community_count = len(round_state.community_cards)
            strength *= (1 - 0.05 * min(community_count, 3))
        
        return min(1.0, max(0.0, strength))
    
    def calculate_pot_odds(self, round_state: RoundStateClient, amount_to_call: int) -> float:
        """Calculate pot odds as a ratio"""
        if amount_to_call <= 0:
            return 1.0
        
        total_pot = round_state.pot + amount_to_call
        return total_pot / (amount_to_call + 0.001)  # Avoid division by zero
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hand_cards = []