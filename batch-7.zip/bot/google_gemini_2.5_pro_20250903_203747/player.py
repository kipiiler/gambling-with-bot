import collections
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot for Husky Hold'em that implements a robust, Tight-Aggressive (TAG) strategy.

    Core features:
    - Corrected Raise Logic: Ensures all bets and raises are within the game's legal limits,
      fixing the critical error from the previous iteration.
    - Hand Evaluation: A complete, self-contained hand evaluator for determining the best
      5-card hand from 7 cards.
    - Equity-Based Decisions: Actions are driven by an estimated equity (win probability),
      which combines the strength of the current made hand with the potential of draws.
    - Strategic Betting: Implements context-aware betting based on pre-flop hand charts,
      post-flop hand strength, and pot odds.
    """

    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.big_blind_amount: int = 0
        self.all_players: List[int] = []

        self.RANKS_MAP = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.RANK_NAMES_MAP = {v: k for k, v in self.RANKS_MAP.items()}
        
        # Pre-flop hand strength tiers (0.0 to 1.0)
        self.preflop_hand_ranks = {
            ('A', 'A'): 1.0, ('K', 'K'): 0.95, ('Q', 'Q'): 0.9, ('J', 'J'): 0.85,
            ('A', 'K'): 0.82, ('T', 'T'): 0.8,
            ('A', 'Q'): 0.78, ('A', 'J'): 0.76, ('K', 'Q'): 0.75, ('9', '9'): 0.7,
            ('A', 'T'): 0.68, ('K', 'J'): 0.66, ('Q', 'J'): 0.65, ('8', '8'): 0.64,
            ('K', 'T'): 0.62, ('Q', 'T'): 0.60, ('J', 'T'): 0.58, ('7', '7'): 0.56,
            ('A', '9'): 0.55, ('A', '8'): 0.54, ('A', '7'): 0.53, ('6', '6'): 0.50,
            ('K', '9'): 0.48, ('5', '5'): 0.45, ('4', '4'): 0.4, ('3', '3'): 0.35, ('2', '2'): 0.3
        }
        self.suited_bonus = 0.05

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once per hand before the first action."""
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of a new betting round."""
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player based on a robust strategic framework."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet

        can_check = to_call == 0
        can_raise = round_state.min_raise > 0 and round_state.min_raise <= round_state.max_raise

        # 1. Evaluate hand strength/equity
        if round_state.round == 'Pre-flop':
            strength = self._get_preflop_strength()
        else:
            made_rank, draw_outs = self._get_postflop_strength(round_state.community_cards)
            strength = self._calculate_equity(made_rank, draw_outs, round_state.round)

        # 2. Basic decision thresholds
        fold_threshold = 0.35
        call_threshold = 0.60
        
        # 3. Handle specific game situations (pot odds)
        if not can_check:
            if strength < call_threshold:
                pot_odds = to_call / (round_state.pot + to_call + 1e-9)
                if strength < pot_odds:
                    return PokerAction.FOLD, 0
            
            if strength < 0.7 and to_call > remaining_chips * 0.3:
                return PokerAction.FOLD, 0
        
        # 4. Determine Action
        if strength < fold_threshold:
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
            
        if strength >= call_threshold and can_raise:
            raise_amount = self._get_bet_amount(round_state, remaining_chips, strength)
            
            if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                if raise_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, int(raise_amount)

        # Default to Call/Check for medium hands or if a raise is not possible/advisable
        if can_check:
            return PokerAction.CHECK, 0
        
        if to_call < remaining_chips * 0.15 or strength > 0.5: # Call small bets or with decent strength
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    # --- Helper Methods ---

    def _parse_card(self, card: str) -> tuple[int, str]:
        """Parses 'Kh' into (13, 'h')."""
        return self.RANKS_MAP[card[:-1]], card[-1]

    def _get_preflop_strength(self) -> float:
        """Calculates hand strength pre-flop using a stored chart."""
        c1, c2 = self._parse_card(self.hand[0]), self._parse_card(self.hand[1])
        r1, s1 = c1
        r2, s2 = c2
        
        is_suited = s1 == s2
        
        rn1, rn2 = (self.RANK_NAMES_MAP[r1], self.RANK_NAMES_MAP[r2])
        
        lookup_key = tuple(sorted((rn1, rn2), key=lambda r: self.RANKS_MAP[r], reverse=True))
        
        strength = self.preflop_hand_ranks.get(lookup_key, 0.1)

        if is_suited and not r1 == r2:
            strength += self.suited_bonus
        
        return min(strength, 1.0)

    def _get_postflop_strength(self, community_cards: List[str]) -> tuple[int, int]:
        """Calculates made hand rank and draw outs."""
        all_cards_str = self.hand + community_cards
        parsed_cards = [self._parse_card(c) for c in all_cards_str]
        
        made_hand_rank, _ = self._get_best_hand_from_cards(parsed_cards) if len(parsed_cards) >= 5 else (0, [])

        outs = 0
        if made_hand_rank < 5:  # Not a flush
            suits = collections.Counter(c[1] for c in parsed_cards)
            if 4 in suits.values():
                outs += 9  # Flush draw
        
        if made_hand_rank < 4:  # Not a straight
            ranks = sorted(list(set(c[0] for c in parsed_cards)))
            if len(ranks) >= 4:
                for i in range(len(ranks) - 3):
                    if ranks[i+3] - ranks[i] == 3 and not (ranks[i+3] - ranks[i+2] != 1 and ranks[i+1] - ranks[i] != 1): # Check for consecutive
                        if ranks[i] > 1 and ranks[i+3] < 14: outs += 8; break # OESD
                        elif ranks[i] == 1 or ranks[i+3] == 14: outs+=4; break # One-sided straight draw
                if outs == 0: # Check for gutshot if no OESD
                    for i in range(len(ranks) - 3):
                        if ranks[i+3] - ranks[i] == 4: outs += 4; break # Gutshot

        return made_hand_rank, outs

    def _calculate_equity(self, made_rank: int, draw_outs: int, round_name: str) -> float:
        """Approximates win probability."""
        made_equity = (made_rank + 1) / 10.0
        
        if round_name == 'River': return made_equity
            
        multiplier = 4 if round_name == 'Flop' else 2
        hitting_chance = draw_outs * multiplier / 100.0
            
        return made_equity + (1 - made_equity) * hitting_chance

    def _get_bet_amount(self, round_state: RoundStateClient, remaining_chips: int, strength: float) -> float:
        """Calculates a valid and strategically sized bet or raise amount."""
        if round_state.round == 'Pre-flop':
            if round_state.current_bet > self.big_blind_amount:
                amount = round_state.current_bet * (2.2 + strength) 
            else:
                amount = self.big_blind_amount * (2.5 + strength)
        else:
            size_fraction = 0.4 + (strength * 0.5) 
            amount = round_state.pot * size_fraction
            
        bet_amount = max(round_state.min_raise, amount)
        bet_amount = min(round_state.max_raise, bet_amount)
        
        return bet_amount

    def _get_best_hand_from_cards(self, cards: list[tuple[int, str]]) -> tuple[int, list[int]]:
        """Finds the best 5-card hand from a list of cards."""
        best_rank = (-1, [])
        for five_card_combo in combinations(cards, 5):
            rank = self._evaluate_5_card_hand(list(five_card_combo))
            if rank[0] > best_rank[0] or (rank[0] == best_rank[0] and rank[1] > best_rank[1]):
                best_rank = rank
        return best_rank

    def _evaluate_5_card_hand(self, cards: list[tuple[int, str]]) -> tuple[int, list[int]]:
        """Evaluates a 5-card hand and returns its rank."""
        ranks = sorted([c[0] for c in cards], reverse=True)
        suits = [c[1] for c in cards]

        is_flush = len(set(suits)) == 1
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        effective_ranks = [5, 4, 3, 2, 1] if is_ace_low_straight else ranks
        is_straight = all(effective_ranks[i] == effective_ranks[i+1] + 1 for i in range(4))
        
        if is_straight and is_flush: return 8, effective_ranks

        counts = collections.Counter(ranks)
        count_vals = sorted(counts.values(), reverse=True)
        
        if count_vals[0] == 4:
            four = [r for r, c in counts.items() if c == 4][0]
            kicker = [r for r, c in counts.items() if c == 1][0]
            return 7, [four, kicker]
        
        if count_vals == [3, 2]:
            three = [r for r, c in counts.items() if c == 3][0]
            pair = [r for r, c in counts.items() if c == 2][0]
            return 6, [three, pair]
        
        if is_flush: return 5, ranks

        if is_straight: return 4, effective_ranks
            
        if count_vals[0] == 3:
            three = [r for r, c in counts.items() if c == 3][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return 3, [three] + kickers

        if count_vals == [2, 2, 1]:
            pairs = sorted([r for r, c in counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in counts.items() if c == 1][0]
            return 2, pairs + [kicker]
            
        if count_vals == [2, 1, 1, 1]:
            pair = [r for r, c in counts.items() if c == 2][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return 1, [pair] + kickers
            
        return 0, ranks