import collections
import itertools
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Hand Evaluation Utilities ---

RANKS = '23456789TJQKA'
SUITS = 'shdc'
CARD_RANK_MAP = {rank: i for i, rank in enumerate(RANKS, 2)}
RANK_CARD_MAP = {i: rank for rank, i in CARD_RANK_MAP.items()}

# Hand rank constants
HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8

def parse_card(card_str: str) -> Tuple[int, str]:
    """Parses a card string like 'Ah' into (14, 'h')."""
    rank = CARD_RANK_MAP[card_str[0]]
    suit = card_str[1]
    return rank, suit

def get_hand_rank_5_cards(hand: List[Tuple[int, str]]) -> Tuple:
    """Evaluates a 5-card hand and returns a comparable tuple (rank, high_cards...)."""
    if len(hand) != 5:
        return (-1,)

    ranks = sorted([card[0] for card in hand], reverse=True)
    suits = [card[1] for card in hand]

    is_flush = len(set(suits)) == 1

    # Check for straight, handling Ace-low case
    is_straight = False
    unique_ranks = sorted(list(set(ranks)), reverse=True)
    if len(unique_ranks) >= 5:
        if unique_ranks[0] - unique_ranks[4] == 4:
            is_straight = True
            # The high card of the straight is unique_ranks[0]
            straight_high_card = unique_ranks[0]
    
    # Check for Ace-low straight A,2,3,4,5
    if not is_straight and set(unique_ranks).issuperset({14, 2, 3, 4, 5}):
        is_straight = True
        straight_high_card = 5 
        # For comparison, treat the Ace as low card
        ranks = [r if r != 14 else 1 for r in ranks]
        ranks.sort(reverse=True)


    if is_straight and is_flush:
        return (STRAIGHT_FLUSH, straight_high_card)

    rank_counts = collections.Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    main_ranks = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)

    if counts[0] == 4:
        return (FOUR_OF_A_KIND, main_ranks[0], main_ranks[1])

    if counts == [3, 2]:
        return (FULL_HOUSE, main_ranks[0], main_ranks[1])

    if is_flush:
        return (FLUSH, tuple(ranks))
        
    if is_straight:
        return (STRAIGHT, straight_high_card)

    if counts[0] == 3:
        kickers = tuple(sorted([r for r in main_ranks if r != main_ranks[0]], reverse=True))
        return (THREE_OF_A_KIND, main_ranks[0], kickers)

    if counts == [2, 2, 1]:
        return (TWO_PAIR, main_ranks[0], main_ranks[1], main_ranks[2])

    if counts[0] == 2:
        kickers = tuple(sorted([r for r in main_ranks if r != main_ranks[0]], reverse=True))
        return (ONE_PAIR, main_ranks[0], kickers)

    return (HIGH_CARD, tuple(ranks))

def evaluate_best_hand(hole_cards: List[str], community_cards: List[str]) -> Tuple:
    """Evaluates the best 5-card hand from hole cards and community cards."""
    parsed_hole = [parse_card(c) for c in hole_cards]
    parsed_community = [parse_card(c) for c in community_cards]
    all_cards = parsed_hole + parsed_community
    
    if len(all_cards) < 5:
        all_cards += [(0, 'x')] * (5 - len(all_cards))
        return get_hand_rank_5_cards(all_cards)

    best_rank = (-1,)
    for combo in itertools.combinations(all_cards, 5):
        rank = get_hand_rank_5_cards(list(combo))
        if rank > best_rank:
            best_rank = rank
            
    return best_rank

def count_outs(hole_cards: List[Tuple[int, str]], community_cards: List[Tuple[int, str]]):
    """Counts outs for flush and straight draws."""
    all_cards = hole_cards + community_cards
    my_ranks = {c[0] for c in all_cards}
    my_suits = collections.Counter(c[1] for c in all_cards)
    
    flush_outs = 0
    flush_draw_suit = None
    for suit, count in my_suits.items():
        if count == 4:
            flush_outs = 9
            flush_draw_suit = suit
            break
            
    straight_outs = 0
    possible_straights = [set(range(i, i + 5)) for i in range(2, 11)]
    possible_straights.append({14, 2, 3, 4, 5}) # Ace-low
    
    outs_for_straight = 0
    for straight in possible_straights:
        have = my_ranks.intersection(straight)
        if len(have) == 4:
            missing_cards = straight - have
            current_outs = 0
            for rank in missing_cards:
                is_overlap = flush_outs > 0 and any(card[0] == rank and card[1] == flush_draw_suit for card in all_cards) is False
                if not is_overlap:
                    current_outs += 1
            outs_for_straight = max(outs_for_straight, current_outs)

    if flush_outs > 0 and outs_for_straight > 0:
        return 15 # Combo draw approximation

    return flush_outs + outs_for_straight

class SimplePlayer(Bot):
    
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount: int = 0
        self.initial_stack: int = 0
        self.all_players: List[int] = []
        self.preflop_strength_map = self._create_preflop_strength_map()

    def _create_preflop_strength_map(self):
        strength_map = {}
        ranks_ordered = "AKQJT98765432"
        for i, r1_char in enumerate(ranks_ordered):
            for j, r2_char in enumerate(ranks_ordered):
                hand_str_base = r1_char + r2_char if i <= j else r2_char + r1_char
                if i > j:
                    strength_map[hand_str_base + 'o'] = self._get_hand_score(r1_char, r2_char, False)
                elif i < j:
                    strength_map[hand_str_base + 's'] = self._get_hand_score(r1_char, r2_char, True)
                else: 
                    strength_map[hand_str_base] = self._get_hand_score(r1_char, r2_char, False)
        return strength_map

    def _get_hand_score(self, r1_char, r2_char, suited):
        r1, r2 = CARD_RANK_MAP[r1_char], CARD_RANK_MAP[r2_char]
        if r1 == r2:
            if r1 >= CARD_RANK_MAP['J']: return 1 # JJ+
            if r1 >= CARD_RANK_MAP['T']: return 2 # TT
            if r1 >= CARD_RANK_MAP['7']: return 3 # 77-99
            return 4 # Small pairs
        if (r1_char, r2_char) in (('A','K'), ('K','A')):
            return 1 if suited else 2
        
        if suited:
            if max(r1,r2) >= CARD_RANK_MAP['Q'] and min(r1,r2) >= CARD_RANK_MAP['J']: return 2 # KQs, QJs
            if r1_char == 'A' and r2_char in 'QJT98': return 2
            if abs(r1 - r2) <= 2: return 3 # Suited connectors/gappers
            if r1_char == 'A': return 4 
        else: # offsuit
            if max(r1,r2) >= CARD_RANK_MAP['Q'] and min(r1,r2) >= CARD_RANK_MAP['T']: return 4
        return 5

    def _get_preflop_hand_string(self, hand: List[str]):
        c1, c2 = hand[0], hand[1]
        r1_char, s1 = c1[0], c1[1]
        r2_char, s2 = c2[0], c2[1]
        r1, r2 = CARD_RANK_MAP[r1_char], CARD_RANK_MAP[r2_char]
        if r1 == r2:
            return r1_char + r2_char
        suited_str = 's' if s1 == s2 else 'o'
        return (r1_char + r2_char + suited_str) if r1 > r2 else (r2_char + r1_char + suited_str)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.initial_stack = starting_chips
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        pot_size = round_state.pot
        can_check = amount_to_call == 0

        if amount_to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0 # Effectively a call, but safer to use ALL_IN

        if round_state.round == 'Preflop':
            hand_str = self._get_preflop_hand_string(self.hole_cards)
            strength_group = self.preflop_strength_map.get(hand_str, 5)
            is_raised = round_state.current_bet > self.big_blind_amount
            
            if strength_group == 1:
                raise_amount = 4 * self.big_blind_amount if not is_raised else 3 * round_state.current_bet
                if raise_amount > remaining_chips / 2: return PokerAction.ALL_IN, 0
                raise_amount = max(round_state.min_raise, min(round_state.max_raise, raise_amount))
                return PokerAction.RAISE, int(raise_amount)

            if strength_group == 2:
                if not is_raised:
                    raise_amount = 3 * self.big_blind_amount
                    raise_amount = max(round_state.min_raise, min(round_state.max_raise, raise_amount))
                    return PokerAction.RAISE, int(raise_amount)
                if amount_to_call < remaining_chips * 0.1: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            
            if strength_group <= 4:
                pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9)
                if is_raised and pot_odds < 0.1: return PokerAction.CALL, 0
                if amount_to_call <= self.big_blind_amount: return PokerAction.CALL, 0
                if can_check: return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
            
            return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

        best_hand_rank = evaluate_best_hand(self.hole_cards, round_state.community_cards)
        hand_type = best_hand_rank[0] if best_hand_rank[0] != -1 else HIGH_CARD
        
        pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9) if amount_to_call > 0 else 0
        
        if round_state.round == 'River':
            if hand_type >= THREE_OF_A_KIND:
                bet_amount = min(remaining_chips, int(pot_size * 0.75))
                if not can_check: bet_amount = min(remaining_chips, int(round_state.current_bet * 2.5))
                if bet_amount >= round_state.min_raise: return PokerAction.RAISE, bet_amount
                return PokerAction.CALL, 0 if not can_check else (PokerAction.CHECK, 0)
            elif hand_type >= ONE_PAIR:
                if can_check: return PokerAction.CHECK, 0
                if pot_odds < 0.25: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

        parsed_hole = [parse_card(c) for c in self.hole_cards]
        parsed_community = [parse_card(c) for c in round_state.community_cards]
        outs = count_outs(parsed_hole, parsed_community)
        equity = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100.0
        
        if hand_type >= THREE_OF_A_KIND:
            bet_amount = min(remaining_chips, int(pot_size * 0.7))
            if not can_check: bet_amount = min(remaining_chips, int(round_state.current_bet * 2.5))
            if bet_amount >= round_state.min_raise: return PokerAction.RAISE, bet_amount           
            return PokerAction.CALL if not can_check else (PokerAction.CHECK, 0)

        if outs >= 8:
            if can_check:
                bet_amount = int(pot_size * 0.6)
                if bet_amount >= round_state.min_raise: return PokerAction.RAISE, min(remaining_chips, bet_amount)
                return PokerAction.CHECK, 0
            if equity > pot_odds: return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        if hand_type >= ONE_PAIR:
            if can_check:
                bet_amount = int(pot_size * 0.5)
                if bet_amount >= round_state.min_raise: return PokerAction.RAISE, min(remaining_chips, bet_amount)
                return PokerAction.CHECK, 0
            if pot_odds < 0.3: return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass