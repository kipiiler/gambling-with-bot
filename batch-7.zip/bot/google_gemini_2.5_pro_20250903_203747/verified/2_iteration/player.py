from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import Counter

# --- Hand Evaluation & Strategy Utilities ---

RANKS = '23456789TJQKA'

def _parse_card(card_str: str) -> Tuple[int, str]:
    """Parses a card string like 'Ah' into a tuple (rank_index, suit_char)."""
    if not card_str or len(card_str) < 2:
        return -1, ''
    rank = RANKS.index(card_str[0])
    suit = card_str[1]
    return rank, suit

def _evaluate_hand(hole_cards: List[str], community_cards: List[str]) -> Tuple:
    """
    Evaluates the best 5-card hand from the given hole and community cards.
    Returns a a tuple representing hand rank for comparison, e.g., (8, 12) for a Royal Flush.
    Higher tuples are better hands.
    Rank mapping:
    8: Straight Flush, 7: Four of a Kind, 6: Full House, 5: Flush, 4: Straight,
    3: Three of a Kind, 2: Two Pair, 1: One Pair, 0: High Card.
    """
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        return (-1,)

    best_rank_tuple = (-1,)

    for combo in combinations(all_cards, 5):
        parsed_combo = sorted([_parse_card(c) for c in combo], key=lambda x: x[0], reverse=True)
        ranks = [c[0] for c in parsed_combo]
        suits = [c[1] for c in parsed_combo]

        is_flush = len(set(suits)) == 1
        
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        is_straight = False
        straight_high_rank = 0
        if len(unique_ranks) == 5:
            if unique_ranks[0] - unique_ranks[4] == 4:
                is_straight = True
                straight_high_rank = unique_ranks[0]
            # Ace-low straight (A, 2, 3, 4, 5)
            elif unique_ranks == [12, 3, 2, 1, 0]:
                is_straight = True
                straight_high_rank = 3  # '5' is the high card for ranking

        rank_counts = Counter(ranks)
        count_values = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)

        current_rank_tuple = (-1,)
        if is_straight and is_flush:
            current_rank_tuple = (8, straight_high_rank)
        elif count_values[0] == 4:
            current_rank_tuple = (7, main_ranks[0], main_ranks[1])
        elif count_values == [3, 2]:
            current_rank_tuple = (6, main_ranks[0], main_ranks[1])
        elif is_flush:
            current_rank_tuple = (5,) + tuple(ranks)
        elif is_straight:
            current_rank_tuple = (4, straight_high_rank)
        elif count_values[0] == 3:
            kickers = tuple(r for r in main_ranks if r != main_ranks[0])
            current_rank_tuple = (3, main_ranks[0]) + kickers
        elif count_values == [2, 2, 1]:
            pairs = (main_ranks[0], main_ranks[1])
            kicker = main_ranks[2]
            current_rank_tuple = (2, pairs[0], pairs[1], kicker)
        elif count_values[0] == 2:
            pair_rank = main_ranks[0]
            kickers = tuple(r for r in main_ranks if r != pair_rank)
            current_rank_tuple = (1, pair_rank) + kickers
        else:
            current_rank_tuple = (0,) + tuple(ranks)

        if current_rank_tuple > best_rank_tuple:
            best_rank_tuple = current_rank_tuple
            
    return best_rank_tuple

def _preflop_strength(hole_cards: List[str]) -> float:
    """Returns a score from 0 to 1 for pre-flop hand strength using a Chen-based formula."""
    c1_str, c2_str = hole_cards[0], hole_cards[1]
    r1, s1 = _parse_card(c1_str)
    r2, s2 = _parse_card(c2_str)

    high_r, low_r = max(r1, r2), min(r1, r2)
    is_suited = s1 == s2
    is_pair = r1 == r2
    
    score = 0
    high_card_rank = RANKS[high_r]
    if high_card_rank == 'A': score = 10
    elif high_card_rank == 'K': score = 8
    elif high_card_rank == 'Q': score = 7
    elif high_card_rank == 'J': score = 6
    else: score = (high_r + 2) / 2.0
    
    if is_pair: score = max(5, score * 2)
    if is_suited: score += 2

    gap = high_r - low_r - 1
    if gap == 0: pass
    elif gap == 1: score -= 1
    elif gap == 2: score -= 2
    elif gap == 3: score -= 4
    else: score -= 5
    
    if not is_pair and gap < 2 and high_r < RANKS.index('Q'):
        score += 1
        
    return score / 20.0

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.blind_amount: int = 10

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Most logic is deferred to get_action to ensure it's based on the most current state.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # --- Basic Information ---
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0

        # --- Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            strength = _preflop_strength(self.hole_cards)
            num_players = len(round_state.player_bets)
            
            # Adjust thresholds based on number of players (play tighter with more players)
            raise_thresh = 0.55 + (0.05 * (num_players - 2))
            call_thresh = 0.40 + (0.05 * (num_players - 2))

            if strength > raise_thresh:
                if round_state.current_bet <= self.blind_amount:
                    # Open with a 3x BB raise
                    raise_amount = 3 * self.blind_amount
                else:
                    # Re-raise pot size
                    raise_amount = round_state.pot + 2 * to_call
                return self._get_validated_action(raise_amount, to_call, round_state, remaining_chips)
            
            elif strength > call_thresh:
                # Call small raises, fold to large ones
                if to_call < remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
                
            else:
                # Fold weak hands unless we can check for free
                return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

        # --- Post-flop Strategy (Flop, Turn, River) ---
        else:
            hand_rank_tuple = _evaluate_hand(self.hole_cards, round_state.community_cards)
            hand_type = hand_rank_tuple[0] if hand_rank_tuple else -1

            # Strong Hands (Trips or better): Bet/Raise for value
            if hand_type >= 3:
                # Bet 50-75% of the pot
                bet_amount = int(round_state.pot * 0.6)
                return self._get_validated_action(bet_amount, to_call, round_state, remaining_chips)
            
            # Medium Hands (One or Two Pair): Play cautiously
            elif hand_type >= 1:
                if can_check:
                    # Bet for value/protection if no one has bet yet
                    bet_amount = int(round_state.pot * 0.5)
                    return self._get_validated_action(bet_amount, to_call, round_state, remaining_chips)
                else:
                    # Call if the odds are good, otherwise fold
                    pot_odds = to_call / (round_state.pot + to_call + 1e-9)
                    if pot_odds < 0.35:  # Call if it's less than ~1/3rd of the pot
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            
            # Weak Hands/Draws: Check or Fold
            else:
                return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

    def _get_validated_action(self, desired_amount: int, to_call: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Validates a desired bet/raise amount and returns the best legal action.
        This function prevents invalid action errors.
        If a raise is intended, it returns a RAISE. If not possible, it falls back to CALL.
        """
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # If we can't afford to call, our only move is to go all-in.
        if remaining_chips <= to_call:
            return PokerAction.ALL_IN, 0

        # If we are here, we can at least call.
        # If no raise is desired (i.e. check/call situation), just call.
        if desired_amount <= 0:
            return PokerAction.CALL, 0

        # Check if a raise is legally possible.
        if min_raise is None or min_raise > max_raise:
            # Cannot raise, so just call.
            return PokerAction.CALL, 0
            
        # We want to raise. Clamp the desired amount into the legal range.
        actual_raise = max(desired_amount, min_raise)
        actual_raise = min(actual_raise, max_raise)
        
        # If the clamped raise is equal to our stack, it's an ALL_IN.
        if actual_raise >= max_raise:
            return PokerAction.ALL_IN, 0
        
        return PokerAction.RAISE, int(actual_raise)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # This method is called at the end of each betting round.
        # Can be used for opponent modeling in future iterations.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This method is called at the end of each hand.
        # Can be used to log results and refine strategy.
        pass