from typing import List, Tuple
from collections import Counter
from itertools import combinations
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot for No-Limit Texas Hold'em.

    Strategy Overview:
    - Pre-flop: Uses a tiered hand-ranking system to decide whether to raise, call, or fold.
      It plays more aggressively in short-handed situations (especially heads-up).
    - Post-flop: A robust hand evaluator determines the strength of the made hand.
      - Monster Hands (Full House+): Played very aggressively to get the stack in.
      - Strong Hands (Two Pair, Trips, Straight, Flush): Bet/raise for value. Will not fold easily.
      - Medium Hands (Top Pair): Cautious value betting and bluff catching.
      - Drawing Hands: Uses pot odds to decide whether to call or fold.
      - Weak Hands: Check/fold unless the pot odds are exceptionally good.
    - Bet Sizing: Uses pot-proportional betting to maximize value and apply pressure.
    """

    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.all_players: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called at the start of each hand. The 'game' seems to be equivalent to a 'hand'.
        """
        self.my_hand = player_hands
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of a betting round (Pre-flop, Flop, etc.).
        State tracking for the round can be done here.
        """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is where the bot decides on an action.
        """
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet_in_round
        
        active_players = [p for p_id, p_info in round_state.player_actions.items() if 'Fold' not in p_info['action']]
        num_active_players = len(active_players)

        if not self.my_hand:
            return PokerAction.FOLD, 0

        # Pre-flop Strategy
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, to_call, num_active_players)
        
        # Post-flop Strategy
        else:
            return self._get_postflop_action(round_state, remaining_chips, to_call)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each betting round. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the hand. """
        pass

    # --------------------------------------------------------------------------
    # Helper Functions for Strategy
    # --------------------------------------------------------------------------

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, num_players: int) -> Tuple[PokerAction, int]:
        tier = self._get_preflop_tier(self.my_hand)
        
        is_heads_up = (num_players <= 2)
        can_check = (to_call == 0)

        # Tier 1-2: Premium hands. Always play aggressively.
        if tier <= 2:
            if round_state.min_raise > 0:
                raise_amount = int(round_state.pot * 1.5) if not is_heads_up else int(round_state.pot * 2)
                # Make a pot-sized 3-bet or a large raise
                final_raise = max(round_state.min_raise, raise_amount)
                return PokerAction.RAISE, min(remaining_chips, final_raise)
            else:
                 # Standard open raise: 3x BB, +1 per limper
                limpers = len([p for p_id, p_bet in round_state.player_bets.items() if p_bet > 0 and p_bet < round_state.current_bet])
                raise_amount = round_state.min_raise * (3 + limpers)
                return PokerAction.RAISE, min(remaining_chips, raise_amount)
        
        # Tier 3: Strong but not premium.
        if tier == 3:
            if to_call < remaining_chips * 0.1: # Call small raises
                return PokerAction.CALL, 0
            if can_check:
                raise_amount = round_state.min_raise * 3
                return PokerAction.RAISE, min(remaining_chips, raise_amount)

        # Tier 4: Good speculative hands.
        if tier == 4:
            if to_call < remaining_chips * 0.05: # Call very small raises
                return PokerAction.CALL, 0
            if can_check:
                return PokerAction.CHECK, 0
        
        # Tiers 5 and below: Weak hands.
        # Only play if we can check or the call is very cheap (e.g. completing SB)
        if to_call == round_state.min_raise / 2 and can_check is False: # Completing SB
            if tier <= 5:
                return PokerAction.CALL, 0

        if can_check:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state, remaining_chips, to_call):
        all_cards = self.my_hand + round_state.community_cards
        hand_rank, tie_breakers = self._evaluate_7_card_hand(all_cards)

        # Monster Hands: Full House or better. Be very aggressive.
        if hand_rank >= 7:
            if to_call > 0:
                return PokerAction.ALL_IN, 0
            else: # Bet pot-size to build pot
                bet_amount = min(remaining_chips, max(round_state.min_raise, round_state.pot))
                return PokerAction.RAISE, bet_amount
        
        # Strong Made Hands: Two Pair to Straight. Bet for value.
        if hand_rank >= 3:
            if to_call > 0: # Facing a bet
                # Call unless bet is enormous. Re-raise if not a huge bet.
                if to_call < remaining_chips * 0.4:
                    raise_amount = to_call * 2 + round_state.pot
                    final_raise = max(round_state.min_raise, raise_amount)
                    return PokerAction.RAISE, min(remaining_chips, final_raise)
                return PokerAction.CALL, 0 
            else: # We can check or bet
                # Bet 2/3 pot for value
                bet_amount = int(round_state.pot * 0.66)
                final_bet = max(round_state.min_raise, bet_amount)
                return PokerAction.RAISE, min(remaining_chips, final_bet)

        # Medium Hand: One Pair
        if hand_rank == 2:
            # Check if it's top pair or an overpair for more confidence
            pair_rank = tie_breakers[0]
            board_ranks = sorted([self._parse_card(c)[0] for c in round_state.community_cards], reverse=True)
            is_top_pair = board_ranks and pair_rank >= board_ranks[0]
            
            if is_top_pair: # Cautious value betting / bluff catching
                if to_call > remaining_chips * 0.3: return PokerAction.FOLD, 0 # Fold to huge overbets
                if to_call > 0: return PokerAction.CALL, 0
                bet_amount = int(round_state.pot * 0.5) 
                final_bet = max(round_state.min_raise, bet_amount)
                return PokerAction.RAISE, min(remaining_chips, final_bet)
            else: # Middle or bottom pair, play as check/fold
                if to_call == 0: return PokerAction.CHECK, 0
                # Call only if getting very good odds
                pot_odds = to_call / (round_state.pot + to_call + 1e-9)
                if pot_odds < 0.2: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Drawing Hands / Air
        if round_state.round != 'River':
            outs = self._calculate_outs(self.my_hand, round_state.community_cards)
            if outs > 0:
                pot_odds = to_call / (round_state.pot + to_call + 1e-9)
                # Equity is approx outs / unknown cards. 47 on flop, 46 on turn.
                equity = outs / (46 if round_state.round == 'Turn' else 47)
                if to_call > 0 and equity > pot_odds:
                    return PokerAction.CALL, 0
        
        # No made hand, no good draw. Check/Fold.
        if to_call == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Converts a card string like 'Th' to a tuple (10, 'h')."""
        rank_str = card[:-1]
        suit = card[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return rank, suit

    def _evaluate_7_card_hand(self, cards: List[str]) -> Tuple[int, List[int]]:
        """Evaluates the best 5-card hand from a list of 7 cards."""
        if len(cards) < 5: return 0, []
        
        parsed_cards = [self._parse_card(c) for c in cards]
        best_score = (0, [])

        for combo in combinations(parsed_cards, 5):
            score = self._evaluate_5_card_hand(list(combo))
            # Tuple comparison works element by element, so this is correct.
            if score > best_score:
                best_score = score
        
        return best_score

    def _evaluate_5_card_hand(self, five_cards: List[Tuple[int, str]]) -> Tuple:
        """Scores a 5-card hand and returns a tuple for comparison."""
        ranks = sorted([c[0] for c in five_cards], reverse=True)
        suits = [c[1] for c in five_cards]

        is_flush = len(set(suits)) == 1
        
        # Check for ace-low straight
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)) or is_ace_low_straight

        if is_ace_low_straight:
            # For scoring, treat Ace as 1 in a wheel
            hand_ranks_for_scoring = [5, 4, 3, 2, 1]
        else:
            hand_ranks_for_scoring = ranks

        if is_straight and is_flush:
            return (9, hand_ranks_for_scoring[0])  # Straight Flush

        rank_counts = Counter(ranks)
        count_values = sorted(rank_counts.values(), reverse=True)
        
        if count_values[0] == 4:
            quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r in ranks if r != quad_rank][0]
            return (8, quad_rank, kicker)  # Four of a Kind

        if count_values == [3, 2]:
            trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return (7, trip_rank, pair_rank)  # Full House

        if is_flush:
            return (6, tuple(ranks))  # Flush

        if is_straight:
            return (5, hand_ranks_for_scoring[0])  # Straight

        if count_values[0] == 3:
            trip_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)
            return (4, trip_rank, tuple(kickers))  # Three of a Kind

        if count_values == [2, 2, 1]:
            pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (3, tuple(pair_ranks), kicker)  # Two Pair

        if count_values[0] == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return (2, pair_rank, tuple(kickers))  # One Pair

        return (1, tuple(ranks))  # High Card

    def _get_preflop_tier(self, hand: List[str]) -> int:
        """Categorizes a starting hand into a tier from 1 (best) to 6 (worst)."""
        c1r, c1s = self._parse_card(hand[0])
        c2r, c2s = self._parse_card(hand[1])
        r1, r2 = sorted([c1r, c2r], reverse=True)
        suited = (c1s == c2s)
        is_pair = (r1 == r2)

        # Tier 1: AA, KK, QQ, JJ, AKs
        if is_pair and r1 >= 11: return 1
        if suited and r1 == 14 and r2 == 13: return 1

        # Tier 2: TT, AQs, AJs, KQs, AKo
        if is_pair and r1 == 10: return 2
        if suited and r1 == 14 and r2 >= 11: return 2
        if suited and r1 == 13 and r2 == 12: return 2
        if not suited and r1 == 14 and r2 == 13: return 2
        
        # Tier 3: 99, 88, KJs, QJs, JTs, ATs, AQo
        if is_pair and r1 >= 8: return 3
        if suited and r1 in [13, 12, 11] and r2 >= 10: return 3
        if suited and r1 == 14 and r2 == 10: return 3
        if not suited and r1 == 14 and r2 == 12: return 3

        # Tier 4: Mid-pairs, suited connectors, good aces
        if is_pair and r1 >= 5: return 4
        if suited and r1 >= 9 and r2 >= 8: return 4
        if suited and r1 == 14 and r2 >= 8: return 4
        
        # Tier 5: Small pairs, suited gappers
        if is_pair: return 5
        if suited: return 5

        # Tier 6: Offsuit junk
        return 6
        
    def _calculate_outs(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Calculates flush and open-ended straight draw outs."""
        all_cards = [self._parse_card(c) for c in hole_cards + community_cards]
        
        # Flush outs
        suits_count = Counter(c[1] for c in all_cards)
        flush_outs = 0
        if suits_count and suits_count.most_common(1)[0][1] == 4:
            flush_outs = 9
    
        # Straight outs
        straight_outs = 0
        ranks = sorted(list(set(c[0] for c in all_cards)))
        if len(ranks) >= 4:
            # Check for 4 consecutive ranks (OESD)
            for i in range(len(ranks) - 3):
                if ranks[i+3] - ranks[i] == 3:
                    # Exclude ends of the deck and internal cards for a true OESD
                    if ranks[i] > 1 and ranks[i+3] < 14:
                        straight_outs = 8
                        break
            # Check for gutshot (4 out of 5 ranks for a straight)
            if straight_outs == 0:
                for i in range(len(ranks) - 3):
                    if ranks[i+3] - ranks[i] == 4:
                      straight_outs = 4
                      break
        
        # This is a simplification and doesn't handle combined draws perfectly, but it's a good estimate.
        return flush_outs + straight_outs