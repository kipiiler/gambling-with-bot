import random
from typing import List, Tuple, Dict, Set
from itertools import combinations

# These files are provided by the competition server, so we can import them.
# The actual files will be in the execution environment.
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for hand evaluation
RANKS = '23456789TJQKA'
HAND_RANK_ NAMES = {
    9: "Royal Flush",
    8: "Straight Flush",
    7: "Four of a Kind",
    6: "Full House",
    5: "Flush",
    4: "Straight",
    3: "Three of a Kind",
    2: "Two Pair",
    1: "One Pair",
    0: "High Card"
}

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand strength, post-flop hand evaluation,
    and basic strategic concepts like pot odds and position.
    """
    def __init__(self):
        super().__init__()
        self.hand = []
        self.all_players_at_table = []
        # Hand strength tiers based on Sklansky-Malmuth rankings (simplified)
        # Using canonical representation: AKs, KQs, 77, T8o
        self.tier1 = {'AA', 'KK', 'QQ', 'JJ', 'AKs'}
        self.tier2 = {'TT', 'AQs', 'AJs', 'KQs', 'AKo'}
        self.tier3 = {'99', 'JTs', 'QJs', 'KJs', 'ATs', 'AQo'}
        self.tier4 = {'88', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'AJo', 'KQo'}
        self.tier5 = {'77', '66', '55', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 'K9s', 'KTo', 'QJo'}
        # All other hands are considered weaker

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called at the start of a new hand. Store hand and player info.
        """
        self.hand = player_hands
        if not self.all_players_at_table:
            self.all_players_at_table = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of a betting round (Preflop, Flop, Turn, River).
        This can be used for more complex, round-specific logic.
        """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the core function where the bot decides on its action.
        """
        try:
            legal_actions = self._get_legal_actions(round_state, remaining_chips)
            
            # FIX: This is the fix for the traceback error from the previous iteration.
            # It correctly calculates the number of active (not folded) players in the hand.
            num_players_dealt_in = len(round_state.player_bets)
            num_folded = list(round_state.player_actions.values()).count('Fold')
            active_players = num_players_dealt_in - num_folded
            if active_players <= 0: active_players = 1 # Avoid division by zero, should not happen if we are active

            if round_state.round == 'Preflop':
                return self._get_preflop_action(round_state, remaining_chips, legal_actions)
            else:
                return self._get_postflop_action(round_state, remaining_chips, active_players, legal_actions)

        except Exception:
            # Fallback in case of any unexpected error to avoid crashing and auto-folding.
            amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if amount_to_call > 0:
                return PokerAction.FOLD, 0
            return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the hand. Reset hand-specific state. """
        self.hand = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the entire game. Can be used for analysis. """
        pass

    # --------------------------------------------------------------------------
    # Helper functions for strategy and game logic
    # --------------------------------------------------------------------------

    def _get_legal_actions(self, round_state: RoundStateClient, remaining_chips: int) -> Set[PokerAction]:
        """ Determines the set of legal actions for the current turn. """
        actions = {PokerAction.FOLD}
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        if amount_to_call == 0:
            actions.add(PokerAction.CHECK)
        
        if amount_to_call > 0 and remaining_chips >= amount_to_call:
            actions.add(PokerAction.CALL)

        if remaining_chips > 0:
            actions.add(PokerAction.ALL_IN)

        if remaining_chips > amount_to_call and round_state.min_raise is not None and remaining_chips >= round_state.min_raise:
             actions.add(PokerAction.RAISE)

        return actions
    
    def _get_preflop_strength(self, hand: List[str]) -> int:
        """Categorizes hand into a strength tier (1-6, 1 is strongest)."""
        card1, card2 = hand[0], hand[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]

        r1_val = RANKS.index(rank1)
        r2_val = RANKS.index(rank2)

        if r1_val < r2_val:
            rank1, rank2 = rank2, rank1

        is_suited = 's' if suit1 == suit2 else 'o'
        is_pair = (rank1 == rank2)

        hand_key = f"{rank1}{rank2}"
        if not is_pair:
            hand_key += is_suited

        if hand_key in self.tier1: return 1
        if hand_key in self.tier2: return 2
        if hand_key in self.tier3: return 3
        if hand_key in self.tier4: return 4
        if hand_key in self.tier5: return 5
        return 6

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, legal_actions: Set[PokerAction]) -> Tuple[PokerAction, int]:
        """Determines pre-flop action based on hand strength."""
        strength_tier = self._get_preflop_strength(self.hand)
        amount_to_call = round_state.current_bet - round_state.playerbets.get(str(self.id), 0)
        
        # Estimate big blind. If we are in round 0, it's the current bet. Otherwise, it's the max bet so far.
        big_blind_amount = round_state.current_bet
        if any(v > big_blind_amount for v in round_state.player_bets.values()):
             big_blind_amount = max(round_state.player_bets.values())

        is_raised = round_state.current_bet > big_blind_amount

        # Tier 1-2 hands: Be aggressive.
        if strength_tier <= 2:
            if PokerAction.RAISE in legal_actions:
                raise_amount = int(round_state.pot * 1.5 + round_state.current_bet) if is_raised else int(big_blind_amount * 3)
                # Clamp raise to be valid
                raise_amount = min(round_state.max_raise, max(round_state.min_raise or 0, raise_amount))
                if raise_amount >= remaining_chips:
                    return PokerAction.ALL_IN, remaining_chips
                return PokerAction.RAISE, raise_amount
            if PokerAction.ALL_IN in legal_actions:
                 return PokerAction.ALL_IN, remaining_chips
            if PokerAction.CALL in legal_actions:
                return PokerAction.CALL, 0
            return PokerAction.CHECK, 0

        # Tier 3-4 hands: Playable, but with caution.
        if strength_tier <= 4:
            if not is_raised: # If no one raised, we can limp or make a small raise
                if PokerAction.RAISE in legal_actions:
                    raise_amount = int(big_blind_amount * 2.5)
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise or 0, raise_amount))
                    return PokerAction.RAISE, raise_amount
                if PokerAction.CALL in legal_actions:
                    return PokerAction.CALL, 0
            else: # If raised, call only if the price is right
                if PokerAction.CALL in legalactions and amount_to_call < remaining_chips * 0.15:
                    return PokerAction.CALL, 0
        
        # Tier 5-6 hands (and weaker Tier 3-4 hands facing a raise): be passive or fold
        # Check for free if possible (e.g. from Big Blind)
        if PokerAction.CHECK in legal_actions:
            return PokerAction.CHECK, 0
        # Fold to any bet        
        return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, active_players: int, legal_actions: Set[PokerAction]) -> Tuple[PokerAction, int]:
        """Determines post-flop action based on hand strength and potential."""
        hand_power, _ = self._evaluate_hand(self.hand, round_state.community_cards)
        pot_odds = self._calculate_pot_odds(round_state)
        
        # Strong Hands (Two Pair or better)
        if hand_power >= 2:
            if PokerAction.RAISE in legal_actions:
                bet_amount = int(round_state.pot * random.uniform(0.6, 0.9)) # Value bet
                bet_amount = min(round_state.max_raise, max(round_state.min_raise or 0, bet_amount))
                if bet_amount >= remaining_chips:
                    return PokerAction.ALL_IN, remaining_chips
                return PokerAction.RAISE, bet_amount
            if PokerAction.ALL_IN in legal_actions: return PokerAction.ALL_IN, remaining_chips
            if PokerAction.CALL in legal_actions: return PokerAction.CALL, 0
            return PokerAction.CHECK, 0

        # Medium Hands (One Pair)
        if hand_power == 1:
            if PokerAction.CHECK in legal_actions: return PokerAction.CHECK, 0
            amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if PokerAction.CALL in legal_actions and amount_to_call < remaining_chips * 0.2:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Drawing hands / Bluffs
        outs = self._count_outs(self.hand, round_state.community_cards)
        if outs >= 8 and round_state.round != 'River': # Good draw (flush or open-ended straight)
            equity = self._calculate_equity_from_outs(outs, round_state.round)
            if pot_odds is not None and equity > pot_odds and PokerAction.CALL in legal_actions:
                return PokerAction.CALL, 0
        
        # Bluff if heads-up and everyone checked
        if active_players <= 2 and round_state.current_bet == 0 and PokerAction.RAISE in legal_actions:
            if random.random() < 0.3: # Bluff 30% of the time
                bluff_amount = int(round_state.pot * 0.5)
                bluff_amount = min(round_state.max_raise, max(round_state.min_raise or 0, bluff_amount))
                if bluff_amount > 0: return PokerAction.RAISE, bluff_amount

        if PokerAction.CHECK in legal_actions: return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def _calculate_pot_odds(self, round_state: RoundStateClient) -> float or None:
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if amount_to_call <= 0: return None
        pot_total = round_state.pot + amount_to_call
        return amount_to_call / (pot_total + 1e-9) # Epsilon to prevent division by zero

    def _calculate_equity_from_outs(self, outs: int, round_name: str) -> float:
        """Approximates equity. Flop-to-river: outs*4. Turn-to-river: outs*2."""
        if round_name == 'River': return 0.0
        multiplier = 4 if round_name == 'Flop' else 2
        return (outs * multiplier) / 100.0

    def _parse_cards(self, cards: List[str]) -> List[Tuple[int, str]]:
        return [(RANKS.index(c[0]) + 2, c[1]) for c in cards]

    def _get_hand_details(self, parsed_cards: List[Tuple[int, str]]):
        ranks = sorted([c[0] for c in parsed_cards], reverse=True)
        suits = [c[1] for c in parsed_cards]
        is_flush = len(set(suits)) == 1
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)
        if not is_straight and ranks[0] == 14 and ranks[1] == 5 and ranks[2] == 4 and ranks[3] == 3 and ranks[4] == 2:
            is_straight = True
            ranks = [5, 4, 3, 2, 1] # For Ace-low straight ranking
        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        counts = sorted(rank_counts.values(), reverse=True)
        return ranks, is_flush, is_straight, counts, rank_counts

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, Tuple]:
        """Evaluates the best 5-card hand from 2 hole cards and community cards."""
        all_cards = self._parse_cards(hole_cards + community_cards)
        best_hand_rank = -1
        best_hand_kickers = ()

        if len(all_cards) < 5:
            return 0, tuple(sorted([c[0] for c in all_cards], reverse=True))

        for hand_combo in combinations(all_cards, 5):
            ranks, is_flush, is_straight, counts, rank_counts = self._get_hand_details(list(hand_combo))
            
            major_kickers = sorted([r for r, c in rank_counts.items() if c >= 2], reverse=True)
            kicker_ranks = sorted([r for r, c in rank_counts.items()], reverse=True)
            
            current_rank = 0
            current_kickers = tuple(kicker_ranks)

            if is_straight and is_flush:
                current_rank = 9 if ranks[0] == 14 else 8
            elif counts[0] == 4:
                current_rank = 7
                kicker = [r for r, c in rank_counts.items() if c == 1][0]
                current_kickers = (major_kickers[0], kicker)
            elif counts == [3, 2]:
                current_rank = 6
                current_kickers = (major_kickers[0], major_kickers[1])
            elif is_flush:
                current_rank = 5
            elif is_straight:
                current_rank = 4
            elif counts[0] == 3:
                current_rank = 3
            elif counts == [2, 2, 1]:
                current_rank = 2
            elif counts[0] == 2:
                current_rank = 1
            
            if current_rank > best_hand_rank:
                best_hand_rank = current_rank
                best_hand_kickers = current_kickers
            elif current_rank == best_hand_rank and current_kickers > best_hand_kickers:
                best_hand_kickers = current_kickers
        
        return best_hand_rank, best_hand_kickers

    def _count_outs(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Counts outs for non-made straight and flush draws."""
        if len(community_cards) >= 5: return 0
        
        # Evaluate current hand. If it's already good, don't play for a draw.
        current_strength, _ = self._evaluate_hand(hole_cards, community_cards)
        if current_strength >= 2: # Two pair or better
            return 0

        all_cards = self._parse_cards(hole_cards + community_cards)
        all_ranks = {c[0] for c in all_cards}
        all_suits = [c[1] for c in all_cards]
        
        # Flush draw outs
        suit_counts = {s: all_suits.count(s) for s in set(all_suits)}
        flush_draw_outs = 0
        if 4 in suit_counts.values():
            flush_draw_outs = 9

        # Straight draw outs
        straight_draw_outs = 0
        possible_straights = []
        for i in range(1, 11): # A-5 to T-A
            possible_straights.append(set(range(i, i+5)))
        possible_straights.append({14, 2, 3, 4, 5}) # Ace-low

        for straight in possible_straights:
            if len(all_ranks.intersection(straight)) == 4:
                missing_rank = list(straight.difference(all_ranks))[0]
                if missing_rank == 1: missing_rank = 14 # Ace special case
                straight_draw_outs += 4 # Gutshot
                # crude way to check for open-ended
                if missing_rank > min(all_ranks) and missing_rank < max(all_ranks):
                    pass # gutshot
                else:
                    straight_draw_outs = 8 # open-ended
                break
        
        # Don't double count outs for straight flushes
        # This is a simplification; we just take the max draw.
        return max(flush_draw_outs, straight_draw_outs)