# player.py
from __future__ import annotations

import random
import math
from collections import defaultdict
from typing import Dict, List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# -------------  3rd-party fast evaluator (pure-python, MIT licence) -------------
# We rely on the tiny, pure-python library “treys” for hand evaluation.
from treys import Card, Deck, Evaluator


def _normalise(card: str) -> str:
    """
    Normalise card string that may contain '10' → 'T'
    Accepts e.g. '10h', 'Th', 'Ks' etc.
    """
    card = card.strip()
    if card[0:2] == "10":
        card = "T" + card[2:]
    return card


def _to_treys(card: str) -> int:
    """Convert human readable card e.g. 'Ah' to treys integer."""
    return Card.new(_normalise(card))


def chen_formula(cards: List[str]) -> float:
    """
    Quick estimation of pre-flop strength using a simplified
    Chen formula (https://en.wikipedia.org/wiki/Texas_hold_%27em_starting_hands#Sklansky_table)
    """
    ranks = "23456789TJQKA"
    vals = {
        "A": 10,
        "K": 8,
        "Q": 7,
        "J": 6,
        "T": 5,
        "9": 4.5,
        "8": 4,
        "7": 3.5,
        "6": 3,
        "5": 2.5,
        "4": 2,
        "3": 1.5,
        "2": 1,
    }

    card1, card2 = _normalise(cards[0])[0], _normalise(cards[1])[0]
    suited = cards[0][-1] == cards[1][-1]

    points = max(vals[card1], vals[card2])

    # pocket pair
    if card1 == card2:
        points = max(5, points * 2)
        if card1 in "2345":
            points -= 1
        return points + 0.0

    # suited
    if suited:
        points += 2

    # gap adjustment
    gap = abs(ranks.index(card1) - ranks.index(card2)) - 1
    if gap == 1:
        points -= 1
    elif gap == 2:
        points -= 2
    elif gap == 3:
        points -= 4
    elif gap >= 4:
        points -= 5

    # small bonus for connected / near connected
    high_rank = max(ranks.index(card1), ranks.index(card2))
    if gap == 0 and high_rank >= ranks.index("T"):
        points += 1

    return points


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.evaluator = Evaluator()
        self.preflop_cache: Dict[str, float] = {}
        self.win_prob_cache: Dict[Tuple[Tuple[str, ...], Tuple[str, ...], int], float] = {}
        self.my_hole_cards: List[str] = []
        self.random = random.Random()
        self.random.seed(42)  # Determinism helps reproducibility.

    # ----------  Game-lifecycle callbacks ----------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        # Hole cards for the very first hand are provided here.
        if player_hands:
            self.my_hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Attempt to fetch fresh hole cards from round_state if provided by server.
        We store them for later decisions.
        """
        try:
            self.my_hole_cards = round_state.player_hands[str(self.id)]
        except Exception:
            pass  # Not all environments provide hole cards in round_state.

    # ----------  Core decision routine ----------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Main decision engine.
        Uses fast Monte-Carlo simulation post-flop and Chen formula pre-flop.
        Always returns a legal action.
        """
        community_cards = round_state.community_cards or []
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_already_put = round_state.player_bets.get(str(self.id), 0)
        need_to_call = max(0, current_bet - my_already_put)

        # Safety – if we are all-in already.
        if remaining_chips <= 0:
            return PokerAction.CHECK, 0

        # If we somehow don't have hole cards, default to fold/passive strategy
        if len(self.my_hole_cards) != 2:
            if need_to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Identify number of opponents still in hand
        num_active_players = len([p for p, act in round_state.player_actions.items() if act != "Fold"])
        num_opponents = max(1, num_active_players - 1)

        # Decide stage-dependent
        if len(community_cards) == 0:
            # -------- PRE-FLOP --------
            return self._preflop_decision(need_to_call, pot, round_state)
        else:
            # -------- POST-FLOP --------
            return self._postflop_decision(
                community_cards,
                need_to_call,
                pot,
                remaining_chips,
                round_state,
                num_opponents,
            )

    # ----------  End-of-round/game routines ----------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No persistent learning implemented (stateless over rounds).
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # =============================================================================
    #                               Helper methods
    # =============================================================================
    # -------- Pre-flop logic ------------------------------------------------------
    def _preflop_decision(
        self, need_to_call: int, pot: int, round_state: RoundStateClient
    ) -> Tuple[PokerAction, int]:
        key = "".join(sorted(self.my_hole_cards))
        if key not in self.preflop_cache:
            self.preflop_cache[key] = chen_formula(self.my_hole_cards)
        strength = self.preflop_cache[key]

        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        # Define simple tier thresholds
        if strength >= 10:
            # Premium – raise big
            raise_amt = max(min_raise, int(pot * 0.75))
            raise_amt = min(raise_amt, max_raise)
            if raise_amt >= min_raise:
                return PokerAction.RAISE, raise_amt
            else:
                return (
                    PokerAction.CALL if need_to_call > 0 else PokerAction.CHECK,
                    0,
                )

        if 8 <= strength < 10:
            # Good – raise or call depending on price
            if need_to_call == 0:
                raise_amt = max(min_raise, int(pot * 0.5))
                raise_amt = min(raise_amt, max_raise)
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CHECK, 0
            if need_to_call <= pot * 0.25:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        if 6 <= strength < 8:
            # Speculative – limp/call cheap
            if need_to_call == 0:
                return PokerAction.CHECK, 0
            if need_to_call <= pot * 0.15:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Trash hand – fold unless we are in big blind with no raise
        if need_to_call == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    # -------- Post-flop logic -----------------------------------------------------
    def _postflop_decision(
        self,
        community_cards: List[str],
        need_to_call: int,
        pot: int,
        remaining_chips: int,
        round_state: RoundStateClient,
        num_opponents: int,
    ) -> Tuple[PokerAction, int]:
        win_prob = self._estimate_win_prob(
            tuple(self.my_hole_cards), tuple(community_cards), num_opponents
        )

        # Pot odds
        cost = need_to_call
        pot_odds = cost / (pot + cost + 1e-9) if cost > 0 else 0

        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Aggressive when strong
        if win_prob > 0.8:
            # Push for value
            if remaining_chips <= min_raise or win_prob > 0.9:
                return PokerAction.ALL_IN, 0
            raise_amt = max(min_raise, int(pot * 0.75))
            raise_amt = min(raise_amt, max_raise)
            return PokerAction.RAISE, raise_amt

        # Value bet if ahead
        if win_prob > 0.55:
            if cost == 0:
                bet = max(min_raise, int(pot * 0.5))
                bet = min(bet, max_raise)
                if bet >= min_raise:
                    return PokerAction.RAISE, bet
                return PokerAction.CHECK, 0
            # Facing a bet – call if profitable
            if win_prob > pot_odds:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Marginal – seek cheap showdown
        if win_prob > 0.35:
            if cost == 0:
                return PokerAction.CHECK, 0
            if win_prob > pot_odds:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Weak – bluff occasionally when first to act
        if cost == 0 and self.random.random() < 0.1:
            bluff_amt = max(min_raise, int(pot * 0.5))
            bluff_amt = min(bluff_amt, max_raise)
            if bluff_amt >= min_raise:
                return PokerAction.RAISE, bluff_amt
        # Otherwise fold/check
        if cost == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    # -------- Win-probability estimation (Monte-Carlo) ----------------------------
    def _estimate_win_prob(
        self,
        hole_cards: Tuple[str, str],
        community_cards: Tuple[str, ...],
        num_opponents: int,
        iterations: int = 400,
    ) -> float:
        """
        Monte-Carlo estimation of winning probability using treys Evaluator.
        Caches results keyed by (hole, board, opponents) to save CPU.
        """
        key = (tuple(sorted(hole_cards)), tuple(sorted(community_cards)), num_opponents)
        if key in self.win_prob_cache:
            return self.win_prob_cache[key]

        known_cards = list(hole_cards) + list(community_cards)
        known_treys = [_to_treys(c) for c in known_cards]

        wins = 0
        ties = 0
        total = iterations

        for _ in range(iterations):
            deck = Deck()
            # Remove known cards from deck
            for card in known_treys:
                deck.cards.remove(card)

            # Opponents' hole cards
            opp_holes = [
                (deck.draw(1)[0], deck.draw(1)[0]) for _ in range(num_opponents)
            ]
            # Complete community cards
            board_needed = 5 - len(community_cards)
            board_drawn = deck.draw(board_needed)
            full_board = [_to_treys(c) for c in community_cards] + board_drawn

            my_hand_treys = [_to_treys(hole_cards[0]), _to_treys(hole_cards[1])]
            my_score = self.evaluator.evaluate(full_board, my_hand_treys)

            opp_best = None
            opp_scores = []
            for c1, c2 in opp_holes:
                score = self.evaluator.evaluate(full_board, [c1, c2])
                opp_scores.append(score)
                opp_best = score if opp_best is None else min(opp_best, score)

            if my_score < opp_best:
                wins += 1
            elif my_score == opp_best:
                ties += 1

        win_prob = (wins + ties * 0.5) / total
        # Cache – but keep cache size under control
        if len(self.win_prob_cache) < 10000:
            self.win_prob_cache[key] = win_prob
        return win_prob