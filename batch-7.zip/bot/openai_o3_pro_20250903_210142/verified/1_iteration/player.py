# player.py
from typing import List, Tuple, Dict, Any
import random
import math
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# ------------- optional, fast hand-evaluator ---------------- #
try:
    from treys import Card, Evaluator, Deck          # pure-python, no C extensions
    HAVE_TREYS = True
except Exception:                                     # failsafe – still works, just weaker
    HAVE_TREYS = False
# ------------------------------------------------------------ #

# --- simple helper functions -------------------------------- #
RANK_ORDER = "23456789TJQKA"


def _card_int(card: str) -> int:
    """Convert string card representation to treys int, fall back to hash."""
    if HAVE_TREYS:
        return Card.new(card)
    # cheap unique integer (not for evaluation, only to remove from deck)
    return hash(card)


def _build_deck(exclude: List[str]) -> List[str]:
    """Return a list of card strings that are not in *exclude*."""
    suits = "shdc"
    deck = [r + s for r in RANK_ORDER for s in suits]
    return [c for c in deck if c not in exclude]


# ---- pre-flop starting hand chart -------------------------- #
# very compact – just enough to beat a pure random bot
PREMIUM = {
    "AA", "KK", "QQ", "JJ", "TT",
    "AKs", "AQs", "AJs", "KQs"
}
GOOD = {
    "99", "88", "77",
    "AKo", "AQo", "AJo",
    "ATs", "KJs", "QJs", "JTs"
}
PLAYABLE = {
    "66", "55", "44", "33", "22",
    "KQo", "QJo", "T9s", "98s", "87s"
}


def _hand_descriptor(card1: str, card2: str) -> str:
    """Return compact descriptor like 'AKs', 'QJo', '77'."""
    r1, s1 = card1[0], card1[1]
    r2, s2 = card2[0], card2[1]

    # pair
    if r1 == r2:
        return r1 + r2
    # ordered by rank strength
    if RANK_ORDER.index(r1) < RANK_ORDER.index(r2):
        r1, r2 = r2, r1
        s1, s2 = s2, s1
    suited = "s" if s1 == s2 else "o"
    return f"{r1}{r2}{suited}"


# ------------------------------------------------------------ #
class SimplePlayer(Bot):
    """
    A reasonably strong, resource-constrained No-Limit Texas Hold’em bot.

    – Pre-flop uses a simple starting-hand chart.
    – Post-flop uses Monte-Carlo equity estimation (treys) versus random ranges.
    – Risk / reward is compared against current pot odds to decide actions.
    – Always returns legal actions; includes multiple fallback layers to ensure
      no exceptions are raised even if upstream message format changes.
    """

    # ----- configuration knobs you can tweak safely ---------- #
    MC_ITER_PREFLOP = 300     # simulations when no board
    MC_ITER_FLOP = 200
    MC_ITER_TURN = 80
    MC_ITER_RIVER = 15
    AGGRESSION = 0.75         # fraction of pot we raise when strong
    CALL_THRESHOLD = 0.50     # minimum equity to call if bet facing us
    RAISE_THRESHOLD = 0.70    # minimum equity to raise
    # --------------------------------------------------------- #

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.hole_cards: List[str] = []
        self.evaluator = Evaluator() if HAVE_TREYS else None
        self.round_num = 0

    # ------------------------------------------------------------------ #
    # interface methods required by the framework                         #
    # ------------------------------------------------------------------ #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # we cannot trust that the server gives our hole cards here
        self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self.hole_cards = self._extract_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Main decision function. Always returns a legal (action, amount) pair.
        """

        # ---------- sanity & helper variables ------------------------- #
        my_id = str(self.id)
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = max(0, current_bet - my_bet)
        pot = max(round_state.pot, 1)  # avoid divide-by-zero
        can_check = to_call == 0
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        stage = round_state.round.lower()  # 'preflop', 'flop', etc.

        # ---------- if we have no hole cards (should not happen) ------- #
        if len(self.hole_cards) != 2:
            # fail-safe policy: fold if facing bet, otherwise check
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

        # ---------- compute equity estimate --------------------------- #
        num_players = max(len(round_state.current_player), 2)

        try:
            equity = self._estimate_equity(
                self.hole_cards,
                round_state.community_cards,
                num_players,
                stage,
            )
        except Exception:
            # something went wrong, play super safe
            equity = 0.0

        # ---------- decision logic ------------------------------------ #
        # Compare equity to pot odds when facing a bet
        pot_odds = to_call / (pot + to_call) if to_call > 0 else 0.0

        if to_call > 0:  # someone bet already
            if equity < max(pot_odds, self.CALL_THRESHOLD):
                return (PokerAction.FOLD, 0)

            # strong enough to continue
            if (
                equity >= self.RAISE_THRESHOLD
                and remaining_chips > min_raise
                and min_raise > 0
            ):
                raise_amt = int(
                    min(
                        max_raise,
                        max(min_raise, int(self.AGGRESSION * pot)),
                    )
                )
                # ensure raise_amt increases current bet adequately
                if raise_amt > to_call and raise_amt <= remaining_chips:
                    return (PokerAction.RAISE, raise_amt)
            # else: call
            return (PokerAction.CALL, 0)

        # we are not facing a bet – decide whether to bet/raise or just check
        if equity >= self.RAISE_THRESHOLD and remaining_chips > min_raise:
            bet_amt = int(min(max_raise, max(min_raise, int(self.AGGRESSION * pot))))
            if bet_amt > 0:
                return (PokerAction.RAISE, bet_amt)

        # mediocre hand: just check
        return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # nothing to do – could store statistics for later learning
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # optional logging / printouts
        pass

    # ------------------------------------------------------------------ #
    # --------------------- internal utility methods ------------------- #
    # ------------------------------------------------------------------ #
    def _extract_hole_cards(self, rs: RoundStateClient) -> List[str]:
        """
        Try multiple attribute names to retrieve our hole cards.
        Returns [] if nothing found.
        """
        my_id = str(self.id)
        for key in ("player_hands", "hole_cards", "hands"):
            if hasattr(rs, key):
                data = getattr(rs, key)
                if isinstance(data, dict) and my_id in data:
                    return data[my_id]
                if isinstance(data, (list, tuple)) and len(data) == 2 and isinstance(
                    data[0], str
                ):
                    return list(data)
        # could be included in side pots message (unlikely)
        return []

    # ------------------------------------------------------------ #
    def _estimate_equity(
        self,
        hole_cards: List[str],
        board: List[str],
        num_players: int,
        stage: str,
    ) -> float:
        """
        Monte-Carlo equity estimation against random opponent ranges.
        Requires treys; if unavailable returns heuristic guess.
        """

        if not HAVE_TREYS:
            # simple heuristic without evaluator
            desc = _hand_descriptor(*hole_cards)
            if desc in PREMIUM:
                return 0.75
            if desc in GOOD:
                return 0.55
            if desc in PLAYABLE:
                return 0.40
            return 0.20

        iterations = {
            "preflop": self.MC_ITER_PREFLOP,
            "flop": self.MC_ITER_FLOP,
            "turn": self.MC_ITER_TURN,
            "river": self.MC_ITER_RIVER,
        }.get(stage, self.MC_ITER_PREFLOP)

        evaluator: Evaluator = self.evaluator

        # convert our cards & current board to treys ints
        my_cards_int = [_card_int(c) for c in hole_cards]
        board_int = [_card_int(c) for c in board]

        wins = ties = 0.0
        total = iterations

        # pre-build exclusion set for fast membership checks
        excluded = set(hole_cards + board)

        for _ in range(iterations):
            deck_cards_str = _build_deck(list(excluded))
            random.shuffle(deck_cards_str)

            # draw remaining board cards first
            remaining_board_cards_needed = 5 - len(board_int)
            sampled_board = board_int.copy()
            for _i in range(remaining_board_cards_needed):
                card = deck_cards_str.pop()
                sampled_board.append(_card_int(card))

            # draw opponents hands
            opp_hands = []
            for _p in range(num_players - 1):
                c1 = deck_cards_str.pop()
                c2 = deck_cards_str.pop()
                opp_hands.append((_card_int(c1), _card_int(c2)))

            my_rank = evaluator.evaluate(sampled_board, my_cards_int)
            best_rank = my_rank
            best_ct = 1  # how many tied for best

            for h1, h2 in opp_hands:
                r = evaluator.evaluate(sampled_board, [h1, h2])
                if r < best_rank:
                    best_rank = r
                    best_ct = 1
                elif r == best_rank:
                    best_ct += 1

            if best_rank == my_rank:
                if best_ct == 1:
                    wins += 1.0
                else:
                    ties += 1.0 / best_ct  # split pot equity

        equity = (wins + ties) / max(total, 1)
        return equity

    # ------------------------------------------------------------------ #


# ------------------------- END FILE ---------------------------------- #