from typing import List, Tuple, Dict
from collections import Counter
import itertools

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_TO_VALUE = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}

VALUE_TO_RANK = {v: k for k, v in RANK_TO_VALUE.items()}


def card_rank(card: str) -> int:
    return RANK_TO_VALUE[card[0]]


def card_suit(card: str) -> str:
    return card[1]


def is_straight(values: List[int]) -> Tuple[bool, int]:
    """Return (is_straight, high_card_of_straight).  values are unique and sorted desc."""
    # Wheel straight (A-5)
    if {14, 5, 4, 3, 2}.issubset(values):
        return True, 5
    # Normal straights
    for i in range(len(values) - 4):
        window = values[i:i + 5]
        if all(window[j] - window[j + 1] == 1 for j in range(4)):
            return True, window[0]
    return False, 0


def evaluate_five_cards(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Evaluate a 5-card poker hand.
    Returns (category, tiebreaker list).  Higher is better.
    Categories:
      8 – Straight flush
      7 – Four of a kind
      6 – Full house
      5 – Flush
      4 – Straight
      3 – Three of a kind
      2 – Two pair
      1 – One pair
      0 – High card
    """
    ranks = sorted([card_rank(c) for c in cards], reverse=True)
    suits = [card_suit(c) for c in cards]
    rank_counter = Counter(ranks)
    freq_to_ranks: Dict[int, List[int]] = {}
    for r, cnt in rank_counter.items():
        freq_to_ranks.setdefault(cnt, []).append(r)
    for v in freq_to_ranks.values():
        v.sort(reverse=True)

    is_flush = len(set(suits)) == 1
    unique_ranks_desc = sorted(set(ranks), reverse=True)
    straight, straight_high = is_straight(unique_ranks_desc)

    # Straight flush
    if is_flush and straight:
        return 8, [straight_high]

    # Four of a kind
    if 4 in freq_to_ranks:
        four = freq_to_ranks[4][0]
        kicker = max([r for r in ranks if r != four])
        return 7, [four, kicker]

    # Full house
    if 3 in freq_to_ranks and 2 in freq_to_ranks:
        trip = freq_to_ranks[3][0]
        pair = freq_to_ranks[2][0]
        return 6, [trip, pair]

    # Flush
    if is_flush:
        return 5, ranks

    # Straight
    if straight:
        return 4, [straight_high]

    # Three of a kind
    if 3 in freq_to_ranks:
        trip = freq_to_ranks[3][0]
        kickers = [r for r in ranks if r != trip][:2]
        return 3, [trip] + kickers

    # Two pair
    if freq_to_ranks.get(2, []).__len__() >= 2:
        high_pair, low_pair = freq_to_ranks[2][:2]
        kicker = max([r for r in ranks if r not in (high_pair, low_pair)])
        return 2, [high_pair, low_pair, kicker]

    # One pair
    if 2 in freq_to_ranks:
        pair = freq_to_ranks[2][0]
        kickers = [r for r in ranks if r != pair][:3]
        return 1, [pair] + kickers

    # High card
    return 0, ranks


def evaluate_seven_cards(cards: List[str]) -> Tuple[int, List[int]]:
    """Return best (category, tiebreakers) for 7-card hand."""
    best: Tuple[int, List[int]] = (-1, [])
    for combo in itertools.combinations(cards, 5):
        rank = evaluate_five_cards(list(combo))
        if rank > best:
            best = rank
    return best


def compare_hands(h1: Tuple[int, List[int]], h2: Tuple[int, List[int]]) -> int:
    """Return 1 if h1>h2, 0 if equal, -1 if worse."""
    if h1[0] != h2[0]:
        return 1 if h1[0] > h2[0] else -1
    # Compare tiebreakers lexicographically
    for a, b in itertools.zip_longest(h1[1], h2[1], fillvalue=0):
        if a != b:
            return 1 if a > b else -1
    return 0


def preflop_strength(hand: List[str]) -> float:
    """
    Very simple numeric score for 2-card hand.
    Pairs & high cards get high scores, suited/connected adds value.
    """
    r1, r2 = card_rank(hand[0]), card_rank(hand[1])
    suited = card_suit(hand[0]) == card_suit(hand[1])
    pair = r1 == r2
    high = max(r1, r2)
    low = min(r1, r2)
    score = 0.0
    if pair:
        score = 40 + r1 * 2
    else:
        score = high + low
        if suited:
            score += 4
        gap = abs(r1 - r2)
        if gap == 0:
            score += 3
        elif gap == 1:
            score += 2
        elif gap == 2:
            score += 1
    # Slight bonus for very high cards
    if high >= 12:
        score += (high - 11)  # +1 for Q, +2 for K, +3 for A
    return score


class SimplePlayer(Bot):
    """
    A conservative / semi-aggressive rule-based poker bot.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.hole_cards: List[str] = []
        self.total_players: int = 0

    # ----------------------------------------------------
    # Game lifecycle callbacks
    # ----------------------------------------------------
    def on_start(self, starting_chips: int, player_hands: List[str],
                 blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.total_players = len(all_players)
        # In some frameworks the engine might pass us the first hand here
        if player_hands:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Store our new hole cards if they are present in the message."""
        # Try several possible attribute names to be engine-agnostic
        hand_found = False
        for attr in ['player_hands', 'hole_cards', 'playerCards']:
            if hasattr(round_state, attr):
                attr_val = getattr(round_state, attr)
                if isinstance(attr_val, dict):
                    self.hole_cards = attr_val.get(str(self.id), [])
                elif isinstance(attr_val, list):
                    self.hole_cards = attr_val
                hand_found = True
                break
        if not hand_found:
            self.hole_cards = []

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float,
                    all_scores: dict, active_players_hands: dict):
        pass

    # ----------------------------------------------------
    # Core decision logic
    # ----------------------------------------------------
    def get_action(self, round_state: RoundStateClient,
                   remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Decide an action based on stage, hand strength and bet sizing.
        Always returns a valid action/amount pair.
        """
        try:
            stage = round_state.round  # Expected strings: 'Preflop', 'Flop', 'Turn', 'River'
        except AttributeError:
            stage = 'Preflop'

        # Betting information
        current_bet = round_state.current_bet  # Amount to match
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, current_bet - my_bet)

        min_raise_to = current_bet + round_state.min_raise
        max_raise_to = min(round_state.max_raise, remaining_chips + my_bet)

        # Utility: can we check?
        can_check = call_amount == 0

        # ************************************************************
        # Stage specific evaluation
        # ************************************************************
        action: PokerAction
        amount: int = 0

        # ---------------------- PREFLOP -----------------------------
        if stage.lower() in ('preflop', 'prefloP', 'PREFLOP'):
            strength = preflop_strength(self.hole_cards) if self.hole_cards else 0

            if can_check:
                # No bet to us
                if strength >= 36 and min_raise_to <= remaining_chips:
                    action, amount = PokerAction.RAISE, min_raise_to
                elif strength >= 26:
                    action = PokerAction.CHECK
                else:
                    action = PokerAction.CHECK
            else:
                # Facing a bet
                # All-in short stack
                if remaining_chips <= call_amount:
                    action = PokerAction.ALL_IN
                elif strength >= 34:
                    # Re-raise with strong hand if stack allows
                    if min_raise_to <= max_raise_to and min_raise_to - my_bet <= remaining_chips:
                        action, amount = PokerAction.RAISE, min(min_raise_to, max_raise_to)
                    else:
                        action = PokerAction.ALL_IN
                elif strength >= 28 and call_amount <= 0.15 * remaining_chips:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD

        # ---------------------- POST-FLOP (Flop / Turn / River) -----
        else:
            # Evaluate current best hand
            community = round_state.community_cards
            if self.hole_cards:
                my_best = evaluate_seven_cards(self.hole_cards + community)
                category = my_best[0]
            else:
                category = 0  # Unknown hand -> be cautious

            if can_check:
                if category >= 3 and min_raise_to <= remaining_chips:
                    # Strong (Trips+) – build pot
                    action, amount = PokerAction.RAISE, min_raise_to
                else:
                    action = PokerAction.CHECK
            else:
                if remaining_chips <= call_amount:
                    # Calling puts us all-in
                    if category >= 1:
                        action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.FOLD
                elif category >= 5:
                    # Very strong (Flush, Straight, Full house, etc.)
                    if min_raise_to <= max_raise_to:
                        action, amount = PokerAction.RAISE, min(min_raise_to, max_raise_to)
                    else:
                        action = PokerAction.ALL_IN
                elif category >= 3:
                    # Medium-strong (Trips / Two pair)
                    if call_amount <= 0.5 * remaining_chips:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                elif category >= 1:
                    # Weak made hand – call small bets only
                    if call_amount <= 0.1 * remaining_chips:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

        # Make sure amount is within our stack and action validity
        if action == PokerAction.RAISE:
            # Ensure amount is at least min_raise_to and not more than we can afford
            amount = max(min_raise_to, amount)
            amount = min(amount, max_raise_to)
            if amount <= my_bet or amount - current_bet < round_state.min_raise:
                # Invalid raise sizing – downgrade to CALL or CHECK
                if can_check:
                    action, amount = PokerAction.CHECK, 0
                elif call_amount < remaining_chips:
                    action, amount = PokerAction.CALL, 0
                else:
                    action, amount = PokerAction.FOLD, 0

        # Final safety checks
        if action == PokerAction.CALL and call_amount == 0:
            action = PokerAction.CHECK  # Prefer CHECK when no chips are needed

        return action, amount