from typing import List, Dict, Any, Tuple, Optional
from enum import Enum
import itertools
from collections import Counter
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for hand ranks
HAND_RANKS = {
    "High Card": 0,
    "One Pair": 1,
    "Two Pair": 2,
    "Three of a Kind": 3,
    "Straight": 4,
    "Flush": 5,
    "Full House": 6,
    "Four of a Kind": 7,
    "Straight Flush": 8,
    "Royal Flush": 9
}

RANK_STR_TO_VALUE = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.initialized = False
        self.starting_chips = 0
        self.all_players = []
        self.aggressor = False
        self.hole_cards = []
        self.current_round = None
        self.player_chips = {}
        self.preflop_raise = False
        self.last_aggressor = None
        self.opponent_actions = []
        
    def _card_rank_val(self, card: str) -> int:
        return RANK_STR_TO_VALUE[card[0]]
    
    def _get_chen_score(self, c1: str, c2: str) -> float:
        """Compute the Chen formula score for a starting hand."""
        rank_vals = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10, 
                     '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        point_vals = {14: 10, 13: 8, 12: 7, 11: 6, 10: 5, 
                      9: 4.5, 8: 4, 7: 3.5, 6: 3, 5: 2.5, 4: 2, 3: 2, 2: 1}
        
        r1 = rank_vals[c1[0]]
        r2 = rank_vals[c2[0]]
        high_rank = max(r1, r2)
        low_rank = min(r1, r2)
        
        is_suited = c1[1] == c2[1]
        is_pair = r1 == r2
        
        if is_pair:
            score = 2 * point_vals[high_rank]
            if score > 10:
                score = 10
        else:
            gap = high_rank - low_rank - 1
            penalty = 0
            if gap == 1:
                penalty = 0
            elif gap == 2:
                penalty = 1
            elif gap == 3:
                penalty = 2
            elif gap >= 4:
                penalty = 4
            
            score = point_vals[high_rank] - penalty
            
            if is_suited:
                score += 2
                
            if high_rank <= 11:  # Jack or lower
                if gap >= 2:
                    score -= 1
        
        return min(10, score)
    
    def _combinations(self, hand, r):
        """Helper to generate combinations of cards"""
        return itertools.combinations(hand, r)
    
    def _five_card_eval(self, hand):
        """Evaluate 5-card hand and return (rank, primary, secondary, kickers)"""
        suits = [c[1] for c in hand]
        ranks = sorted([self._card_rank_val(c) for c in hand], reverse=True)
        rank_counter = Counter(ranks)
        most_common = rank_counter.most_common()
        
        # Check for flush and straight
        is_flush = len(set(suits)) == 1
        is_straight = self._is_consecutive(ranks)
        
        # Special case for A-high straight with A as 1
        if ranks == [14, 5, 4, 3, 2]:
            ranks = [5, 4, 3, 2, 1]
            is_straight = True
        
        # Royal and straight flush
        if is_flush and is_straight:
            if ranks[0] == 14:
                return (HAND_RANKS["Royal Flush"], 14, 0, 0, 0)
            return (HAND_RANKS["Straight Flush"], ranks[0], 0, 0, 0)
        
        # Four of a kind
        if most_common[0][1] == 4:
            return (HAND_RANKS["Four of a Kind"], most_common[0][0], 
                    most_common[1][0], 0, 0)
        
        # Full house
        if most_common[0][1] == 3 and most_common[1][1] == 2:
            return (HAND_RANKS["Full House"], most_common[0][0], 
                    most_common[1][0], 0, 0)
        
        # Flush
        if is_flush:
            return (HAND_RANKS["Flush"], *ranks, 0, 0)
        
        # Straight
        if is_straight:
            return (HAND_RANKS["Straight"], ranks[0], 0, 0, 0)
        
        # Three of a kind
        if most_common[0][1] == 3:
            # Remove the trips to get kickers
            kickers = [r for r in ranks if r != most_common[0][0]]
            return (HAND_RANKS["Three of a Kind"], most_common[0][0], 
                    kickers[0], kickers[1], 0)
        
        # Two pair
        if most_common[0][1] == 2 and most_common[1][1] == 2:
            pair_ranks = [most_common[0][0], most_common[1][0]]
            kicker = [r for r in ranks if r not in pair_ranks][0]
            sorted_pairs = sorted(pair_ranks, reverse=True)
            return (HAND_RANKS["Two Pair"], sorted_pairs[0], 
                    sorted_pairs[1], kicker, 0)
        
        # One pair
        if most_common[0][1] == 2:
            pair_rank = most_common[0][0]
            kickers = [r for r in ranks if r != pair_rank]
            return (HAND_RANKS["One Pair"], pair_rank, 
                    kickers[0], kickers[1], kickers[2])
        
        # High card
        return (HAND_RANKS["High Card"], *ranks, 0, 0)
    
    def _is_consecutive(self, ranks):
        sorted_ranks = sorted(ranks)
        return all(sorted_ranks[i] == sorted_ranks[i-1] + 1 
                  for i in range(1, len(sorted_ranks)))
    
    def _seven_card_eval(self, hole_cards, community_cards):
        """Evaluate best 5-card hand from 7 cards"""
        all_cards = hole_cards + community_cards
        best_rank = (-1,)
        
        for combo in self._combinations(all_cards, 5):
            hand_rank = self._five_card_eval(combo)
            if hand_rank > best_rank:
                best_rank = hand_rank
                
        return best_rank
    
    def _hand_potential(self, hole, community, villain_range=0.5):
        """Estimate winning probability (simplified for speed)"""
        our_strength = self._seven_card_eval(hole, community)[0] / 9.0
        
        # Adjust for game stage
        if len(community) == 0:  # Pre-flop
            return our_strength * 0.5 + self._get_chen_score(*hole) * 0.1
        
        return our_strength * (1 + 0.1 * len(community))
    
    def _decide_pot_odds_action(self, call_amt, pot_amt, pot_equity):
        if call_amt < 1:
            return PokerAction.CALL, 0
            
        odds_break_even = call_amt / (pot_amt + call_amt)
        odds_safety_margin = 0.15
        
        if pot_equity > odds_break_even + odds_safety_margin:
            return PokerAction.RAISE, min(call_amt + max(call_amt, int(pot_amt * 0.25)))
        elif pot_equity > odds_break_even:
            return PokerAction.CALL, call_amt
        else:
            return PokerAction.FOLD, 0
    
    def _bluff_opportunity(self, round_state, community_len, hole_connected, aggressor):
        """Bluff in good spots"""
        if not aggressor:
            return False
        
        # Semi-bluff on flush/straight draws
        if hole_connected and community_len == 3:
            return True
        
        # Bluff on scare cards
        if community_len == 4 or community_len == 5:
            community_ranks = [self._card_rank_val(c) for c in round_state.community_cards]
            last_card = community_ranks[-1] if community_ranks else 0
            if last_card > 10:  # High card may have missed opponents
                return True
        
        return False
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.initialized = True
        self.all_players = all_players
        index = all_players.index(self.id) if self.id in all_players else 0
        self.hole_cards = [player_hands[index*2], player_hands[index*2+1]]
        self.player_chips = {player: starting_chips for player in all_players}
        self.preflop_raise = False
        self.last_aggressor = None
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.current_round = round_state.round
        self.aggressor = False
        self.opponent_actions = []
        self.player_chips[self.id] = remaining_chips
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            players_in_hand = len([p for p in round_state.player_actions if p != self.id and round_state.player_actions[p] != "Fold"])
            is_heads_up = players_in_hand == 1
            
            # Fold if extremely poor hand and opponents strong
            chen_score = self._get_chen_score(*self.hole_cards) if self.hole_cards else 0
            community_length = len(round_state.community_cards) if round_state.community_cards else 0
            hole_connected = False
            
            if self.hole_cards and community_length == 3:  # Check if hole cards connect with flop
                hole_ranks = sorted([self._card_rank_val(c) for c in self.hole_cards])
                comm_ranks = sorted([self._card_rank_val(c) for c in round_state.community_cards])
                hole_diff = abs(hole_ranks[0] - hole_ranks[1])
                hole_connected = any(hole_ranks[0] - 1 <= r <= hole_ranks[0] + 1 or 
                                     hole_ranks[1] - 1 <= r <= hole_ranks[1] + 1 
                                     for r in comm_ranks) or hole_diff <= 4
            
            if not self.hole_cards or chen_score < 2.5:
                if self.current_round == "Preflop" and len(round_state.player_actions) > 2 and not is_heads_up:
                    return PokerAction.FOLD, 0
                    
            hand_potential, hand_strength = self.get_hand_strength_potential()
            
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            pot_odds = call_amount / (round_state.pot + call_amount + 1e-9)
            min_raise = round_state.min_raise
            max_raise = min(remaining_chips, round_state.max_raise)
            
            # Aggressive strategy as previous aggressor    
            if self.aggressor and call_amount == 0:
                if hand_potential > 0.6:
                    raise_amt = min(max(min_raise, int(round_state.pot * 0.5)), max_raise)
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CHECK, 0
            elif self.aggressor and call_amount > 0:
                if hand_potential > 0.7:
                    raise_amt = min(max(min_raise, call_amount * 2), max_raise)
                    return PokerAction.RAISE, raise_amt
                elif hand_potential > 0.4:
                    return PokerAction.CALL, call_amount
                else:
                    return PokerAction.FOLD, 0
                    
            # Defensive play in limped pots
            if hand_potential > 0.5:
                if call_amount > 0:
                    pot_odds_action = self._decide_pot_odds_action(call_amount, round_state.pot, hand_potential)
                    return pot_odds_action
                # When checked to, bet if confident
                if hand_potential > 0.5:
                    bet_amt = min(max(int(round_state.pot * 0.33), min_raise), max_raise)
                    return PokerAction.RAISE, bet_amt
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
                    
        except Exception as e:
            return PokerAction.FOLD, 0
    
    def get_hand_strength_potential(self):
        """Simplified strength and potential evaluator"""
        if hasattr(self, 'hole_cards') and self.hole_cards:
            hand_rank = self._seven_card_eval(self.hole_cards, 
                                             getattr(self, 'community_cards', []))[0]
            hand_strength = hand_rank / 9.0  # Normalize to 0-1 scale
            return hand_strength, hand_strength
        return 0.0, 0.0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        if self.aggressor and round_state.round == "River" and self.last_aggressor:
            # Record opponent behavior for future reads
            self.opponent_actions.append(round_state.player_actions)
        elif not self.aggressor and 'Raise' in round_state.player_actions.values():
            self.last_aggressor = list(round_state.player_actions.keys())[0]
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                   all_scores: dict, active_players_hands: dict) -> None:
        pass