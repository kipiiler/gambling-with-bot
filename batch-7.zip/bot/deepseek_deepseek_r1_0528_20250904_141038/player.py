import itertools
from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.big_blind_amount = 0
        self.starting_chips = 0
        self.id = None
        self.player_list = []
        self.hole_str = None

    def set_id(self, player_id: int) -> None:
        self.id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.player_list = all_players
        self.hole_str = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def _normalize_hole_cards(self):
        card0, card1 = self.hole_cards
        rank_str = '23456789TJQKA'
        rank_map = {chr: i for i, chr in enumerate(rank_str)}
        rank0 = rank_map[card0[0]]
        rank1 = rank_map[card1[0]]
        if rank0 < rank1:
            rank0, rank1 = rank1, rank0
        suited = card0[1] == card1[1]
        if rank0 == rank1:
            return f"{rank_str[rank0]}{rank_str[rank1]}", rank0, rank1, suited
        else:
            return f"{rank_str[rank0]}{rank_str[rank1]}{'s' if suited else 'o'}", rank0, rank1, suited

    def _preflop_hand_strength(self):
        hand_str, high, low, suited = self._normalize_hole_cards()
        if high == low:
            index = high
        else:
            high = high
            low = low
            n = high * (high - 1) // 2 + low
            if suited:
                index = 13 + n
            else:
                index = 13 + 78 + n
        return (index + 1) / 169.0

    def _evaluate_5card(self, cards):
        suits = [card[1] for card in cards]
        rank_str = '23456789TJQKA'
        rank_map = {chr: i for i, chr in enumerate(rank_str)}
        ranks = sorted([rank_map[c[0]] for c in cards], reverse=True)
        
        flush = len(set(suits)) == 1
        
        straight = False
        straight_high = None
        if ranks[0] - ranks[4] == 4 and len(set(ranks)) == 5:
            straight = True
            straight_high = ranks[0]
        elif ranks == [12, 3, 2, 1, 0] and len(set(ranks)) == 5:
            straight = True
            straight_high = 3
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        sorted_counts = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        
        if straight and flush:
            return 8 * 1000000 + straight_high * 10000
        if len(sorted_counts) > 0 and sorted_counts[0][1] == 4:
            return 7 * 1000000 + sorted_counts[0][0] * 10000 + sorted_counts[1][0]
        if len(sorted_counts) > 1 and sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
            return 6 * 1000000 + sorted_counts[0][0] * 10000 + sorted_counts[1][0]
        if flush:
            return 5 * 1000000 + ranks[0] * 10000 + ranks[1] * 1000 + ranks[2] * 100 + ranks[3] * 10 + ranks[4]
        if straight:
            return 4 * 1000000 + straight_high * 10000
        if len(sorted_counts) > 0 and sorted_counts[0][1] == 3:
            others = [item[0] for item in sorted_counts[1:]]
            others.sort(reverse=True)
            return 3 * 1000000 + sorted_counts[0][0] * 10000 + others[0] * 100 + others[1]
        if len(sorted_counts) > 1 and sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
            pair1, pair2 = sorted_counts[0][0], sorted_counts[1][0]
            if pair1 < pair2:
                pair1, pair2 = pair2, pair1
            others = [item[0] for item in sorted_counts[2:]]
            return 2 * 1000000 + pair1 * 10000 + pair2 * 100 + others[0]
        if len(sorted_counts) > 0 and sorted_counts[0][1] == 2:
            pair_rank = sorted_counts[0][0]
            others = [item[0] for item in sorted_counts[1:]]
            others.sort(reverse=True)
            return 1 * 1000000 + pair_rank * 10000 + others[0] * 100 + others[1] * 10 + others[2]
        return 0 * 1000000 + ranks[0] * 10000 + ranks[1] * 1000 + ranks[2] * 100 + ranks[3] * 10 + ranks[4]

    def _evaluate_hand(self, cards):
        n = len(cards)
        if n < 5:
            return 0
        if n == 5:
            return self._evaluate_5card(cards)
        else:
            best_rank = -1
            for combo in itertools.combinations(cards, 5):
                rank_val = self._evaluate_5card(combo)
                if rank_val > best_rank:
                    best_rank = rank_val
            return best_rank

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        player_bets_dict = round_state.player_bets
        my_bet_in_round = player_bets_dict.get(str(self.id), 0)
        call_amount = current_bet - my_bet_in_round
        
        if round_state.round == 'Preflop':
            strength = self._preflop_hand_strength()
            if call_amount == 0:
                if strength > 0.7:
                    min_raise = round_state.min_raise
                    total_bet_amount = current_bet + min_raise
                    if total_bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, total_bet_amount)
                elif strength > 0.5:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if strength > 0.8:
                    min_raise = round_state.min_raise
                    total_bet_amount = current_bet + min_raise
                    if total_bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, total_bet_amount)
                elif strength > 0.6:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        all_cards = self.hole_cards + round_state.community_cards
        hand_value = self._evaluate_hand(all_cards)
        hand_category = hand_value // 1000000
        
        if call_amount == 0:
            if hand_category >= 5:
                min_raise = round_state.min_raise
                total_bet_amount = current_bet + min_raise
                if total_bet_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, total_bet_amount)
            elif hand_category >= 3:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            total_pot = call_amount + round_state.pot
            pot_odds = call_amount / (total_pot + 1e-6)
            if hand_category >= 5:
                min_raise = round_state.min_raise
                total_bet_amount = current_bet + min_raise
                if total_bet_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, total_bet_amount)
            elif hand_category >= 3:
                return (PokerAction.CALL, 0)
            else:
                if pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass