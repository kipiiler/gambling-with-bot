from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.position_rank = 0  # 0 = early, 1 = middle, 2 = late
        self.hand_strength = 0.0
        self.tight_aggressive = True
        self.volatility_factor = 0.1
        self.previous_round_state = None
        self.hand_count = 0
        self.win_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_count = 0
        self.win_history = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        self._update_position(round_state)
        if round_state.round == "Preflop":
            self.hand_strength = self._evaluate_preflop_hand(self.player_hands[self.hand_count % len(self.player_hands)])
        else:
            self.hand_strength = self._evaluate_postflop_hand(self.player_hands[self.hand_count % len(self.player_hands)], round_state.community_cards)

    def _update_position(self, round_state: RoundStateClient):
        current_player_index = self.all_players.index(self.id) if self.id in self.all_players else 0
        total_players = len(self.all_players)
        if total_players <= 1:
            self.position_rank = 2  # Only one player left, assume best position
            return
        # Later positions act later — more information
        if current_player_index >= total_players - 2:
            self.position_rank = 2  # Late position
        elif current_player_index >= total_players // 2:
            self.position_rank = 1  # Middle
        else:
            self.position_rank = 0  # Early

    def _evaluate_preflop_hand(self, hand: str) -> float:
        """Evaluate hole cards strength using Chen Formula approximation."""
        if not hand or len(hand) < 4:
            return 0.1
        
        cards = [hand[0:2], hand[2:4]]
        values = []
        suits = []
        for card in cards:
            rank = card[0]
            suit = card[1]
            if rank == 'A': v = 14
            elif rank == 'K': v = 13
            elif rank == 'Q': v = 12
            elif rank == 'J': v = 11
            elif rank == 'T': v = 10
            else: v = int(rank)
            values.append(v)
            suits.append(suit)
        
        high_card = max(values)
        low_card = min(values)
        score = 0.0

        # High card points
        if high_card == 14: score = 10
        elif high_card == 13: score = 8
        elif high_card == 12: score = 7
        elif high_card == 11: score = 6
        else: score = high_card / 2.0

        # Pair bonus
        if values[0] == values[1]:
            score = max(5, score * 2)

        # Suit bonus (suited)
        if suits[0] == suits[1]:
            score += 2

        # Gap penalty
        gap = high_card - low_card - 1
        if gap == 1: score -= 1
        elif gap == 2: score -= 2
        elif gap == 3: score -= 4
        elif gap >= 4: score -= 5

        # Connected bonus for close cards
        if gap == 0 and high_card >= 11:  # Broadways connected
            score += 1
        
        # Ensure connectors like JT, QJ get slight bump
        if gap == 1 and high_card >= 11:
            score += 1

        # Normalize to [0,1]
        score = max(0, min(20, score)) / 20.0
        return score

    def _evaluate_postflop_hand(self, hand: str, community_cards: List[str]) -> float:
        """Very basic postflop hand strength estimator (can be improved with equity simulation)."""
        if not community_cards:
            return self._evaluate_preflop_hand(hand)
        
        all_cards = [hand[0:2], hand[2:4]] + community_cards
        ranks = [self._card_rank(c[0]) for c in all_cards]
        suits = [c[1] for c in all_cards]

        # Count pairs, draws, etc.
        rank_count = {}
        suit_count = {}
        for r in ranks: rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits: suit_count[s] = suit_count.get(s, 0) + 1

        has_pair = any(v >= 2 for v in rank_count.values())
        has_two_pair = sum(1 for v in rank_count.values() if v >= 2) >= 2
        has_set = any(v >= 3 for v in rank_count.values())
        has_flush_draw = any(v >= 4 for v in suit_count.values())
        has_flush = any(v >= 5 for v in suit_count.values())

        # Straight potential
        sorted_ranks = sorted(set(ranks))
        gap_runs = 0
        max_run = 1
        for i in range(1, len(sorted_ranks)):
            if sorted_ranks[i] - sorted_ranks[i-1] == 1:
                gap_runs += 1
                max_run = max(max_run, gap_runs + 1)
            else:
                gap_runs = 0
        has_straight_draw = max_run >= 4
        has_straight = max_run >= 5

        # Strength score
        strength = 0.0
        if has_flush: strength = 0.9
        elif has_straight: strength = 0.8
        elif has_set: strength = 0.7
        elif has_two_pair: strength = 0.6
        elif has_pair: strength = 0.3 + (max(ranks) / 100)  # High card kicker
        else: strength = max(ranks) / 100

        if not has_flush and has_flush_draw: strength = max(strength, 0.5)
        if not has_straight and has_straight_draw: strength = max(strength, 0.45)

        # Improve with overcards to board, etc.
        hole_ranks = [self._card_rank(hand[0]), self._card_rank(hand[2])]
        board_ranks = [self._card_rank(c[0]) for c in community_cards]
        if board_ranks:
            overcards = sum(1 for hr in hole_ranks if hr > max(board_ranks))
            strength += overcards * 0.05

        # Don't exceed 1
        return min(1.0, strength)

    def _card_rank(self, r: str) -> int:
        if r == 'A': return 14
        if r == 'K': return 13
        if r == 'Q': return 12
        if r == 'J': return 11
        if r == 'T': return 10
        return int(r)

    def _count_active_players(self, round_state: RoundStateClient) -> int:
        active = 0
        for pid in self.all_players:
            pid_str = str(pid)
            if pid_str in round_state.player_bets and pid in round_state.current_player:
                active += 1
        return active

    def _is_in_position(self, round_state: RoundStateClient) -> bool:
        try:
            acting_players = round_state.current_player
            if len(acting_players) <= 1:
                return True
            current_index = acting_players.index(self.id)
            return current_index == len(acting_players) - 1
        except:
            return True  # default safe

    def _get_position_multiplier(self) -> float:
        if self.position_rank == 2:  # Late
            return 1.3
        elif self.position_rank == 1:  # Middle
            return 1.0
        else:  # Early
            return 0.7

    def _get_stack_status(self, remaining_chips: int) -> str:
        avg_stack = self.starting_chips
        if remaining_chips > avg_stack * 1.5:
            return "big"
        elif remaining_chips > avg_stack * 0.5:
            return "medium"
        else:
            return "short"

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Extract info
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            active_players = self._count_active_players(round_state)
            is_in_position = self._is_in_position(round_state)
            position_mult = self._get_position_multiplier()
            stack_status = self._get_stack_status(remaining_chips)

            # Amount to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_current_bet

            # Avoid division by zero
            epsilon = 1e-8

            # Default fold if cannot act
            if remaining_chips <= 0:
                return (PokerAction.FOLD, 0)

            # Precomputed hand strength already set in on_round_start
            strength = self.hand_strength

            # Adjust strength by position and stack
            adjusted_strength = strength * position_mult
            if stack_status == "short":
                adjusted_strength *= 1.2  # Play tighter unless strong
            elif stack_status == "big":
                adjusted_strength *= 1.0

            # Random volatility to avoid predictability
            adjusted_strength *= (1 + random.uniform(-self.volatility_factor, self.volatility_factor))

            # Determine action based on round
            if round_state.round == "Preflop":
                return self._preflop_action(round_state, adjusted_strength, to_call, min_raise, max_raise, pot, active_players, remaining_chips, is_in_position)
            else:
                return self._postflop_action(round_state, adjusted_strength, to_call, min_raise, max_raise, pot, active_players, remaining_chips, is_in_position)

        except Exception as e:
            # Error in logic defaults to fold
            return (PokerAction.FOLD, 0)

    def _preflop_action(self, round_state: RoundStateClient, strength: float, to_call: int, min_raise: int, max_raise: int, pot: int, active_players: int, remaining_chips: int, is_in_position: bool) -> Tuple[PokerAction, int]:
        # Adjust calling range based on position and players
        call_threshold = 0.4 + (self.position_rank * 0.15)
        raise_threshold = 0.55 + (self.position_rank * 0.2)

        if to_call == 0:
            if strength > call_threshold:
                # Open raise
                raise_amount = min(4 * self.blind_amount, remaining_chips)
                if raise_amount >= min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            call_cost_percent = to_call / (pot + epsilon)
            if strength >= raise_threshold and to_call > 0 and remaining_chips >= min_raise:
                # Re-raise or move in
                if strength > 0.85:
                    # Strong hand, raise big or all-in
                    if remaining_chips <= 4 * pot or strength > 0.95:
                        return (PokerAction.ALL_IN, remaining_chips)
                    else:
                        raise_amount = min(pot, max(min_raise, to_call * 3))
                        return (PokerAction.RAISE, raise_amount)
                else:
                    # Moderate re-raise
                    raise_amount = min(pot, max(min_raise, to_call * 2))
                    return (PokerAction.RAISE, raise_amount)
            elif strength >= call_threshold and to_call <= 0.3 * remaining_chips:
                return (PokerAction.CALL, 0)
            elif strength >= 0.8 and to_call <= remaining_chips:
                # Premium hand, call even large bets
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_action(self, round_state: RoundStateClient, strength: float, to_call: int, min_raise: int, max_raise: int, pot: int, active_players: int, remaining_chips: int, is_in_position: bool) -> Tuple[PokerAction, int]:
        call_threshold = 0.3
        raise_threshold = 0.5
        bluff_threshold = 0.2  # Probability of bluffing when weak

        if to_call == 0:
            if strength > raise_threshold:
                bet_size = min(pot, max(min_raise, remaining_chips * 0.5))
                if bet_size >= min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Bluff occasionally in position
                if is_in_position and strength < 0.2 and random.random() < bluff_threshold:
                    bet_size = min(pot, max(min_raise, remaining_chips * 0.3))
                    if bet_size >= min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
        else:
            effective_strength = strength
            if is_in_position:
                effective_strength *= 1.1  # Slight edge for being in position

            call_cost_percent = to_call / (pot + to_call + epsilon)
            pot_odds = to_call / (pot + to_call + epsilon)

            if effective_strength >= 0.8:
                # Very strong hand
                if to_call >= 0.5 * remaining_chips:
                    return (PokerAction.ALL_IN, remaining_chips)
                elif to_call * 3 <= remaining_chips:
                    raise_amount = min(remaining_chips, max(min_raise, to_call * 2, pot))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            elif effective_strength >= 0.5:
                # Medium strength
                if call_cost_percent <= 0.3 or pot_odds <= 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif effective_strength >= 0.3:
                # Weak draw, maybe call small bets
                if call_cost_percent <= 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Very weak, fold unless bluffing
                if is_in_position and random.random() < bluff_threshold * 0.5 and pot < remaining_chips:
                    bluff_size = min(pot, max(min_raise, remaining_chips * 0.3))
                    if bluff_size >= min_raise:
                        return (PokerAction.RAISE, bluff_size)
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can analyze outcome if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or logging (no file I/O allowed)
        pass