from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.hand_count = 0
        self.hand_strength = 0.0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_count = 0
        self.hand_strength = 0.0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Use available hand based on hand count
        if self.hand_count >= len(self.player_hands):
            self.hand_strength = 0.5  # Default strength if hand list is exhausted
        else:
            hole_cards = self.player_hands[self.hand_count % len(self.player_hands)]
            # Validate hole_cards: must be a list of exactly 2 non-empty strings
            if not isinstance(hole_cards, list) or len(hole_cards) != 2 or not all(
                    isinstance(c, str) and len(c) >= 2 for c in hole_cards):
                self.hand_strength = 0.5
            else:
                self.hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)

        self.hand_count += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # If no valid action can be determined, default to FOLD
        try:
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot_size = round_state.pot

            # Check if current player can check
            can_check = current_bet == 0

            # Make decision based on round, hand strength, and game context
            if round_state.round == 'Preflop':
                action, amount = self._preflop_strategy(round_state, remaining_chips, can_check, current_bet, pot_size,
                                                        min_raise, max_raise)
            else:
                action, amount = self._postflop_strategy(round_state, remaining_chips, can_check, current_bet, pot_size,
                                                         min_raise, max_raise)

            # Validate action bounds
            if action == PokerAction.RAISE:
                if amount <= current_bet or amount < current_bet + min_raise:
                    # If raise is invalid, fallback to CALL if possible, else FOLD
                    if remaining_chips >= current_bet:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                # Ensure raise amount doesn't exceed max_raise
                if amount > max_raise:
                    amount = max_raise
                return action, amount

            elif action == PokerAction.ALL_IN:
                # ALL_IN uses all remaining chips; amount is ignored
                return PokerAction.ALL_IN, 0

            elif action == PokerAction.CALL:
                # CALL amount is implicit; just call the current bet
                return PokerAction.CALL, 0

            elif action == PokerAction.CHECK and not can_check:
                # If cannot check, fallback to CALL or FOLD
                if remaining_chips >= current_bet:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                return PokerAction.CHECK, 0

            # Default to FOLD if anything goes wrong
            return PokerAction.FOLD, 0

        except Exception as e:
            # On any error, fold safely
            return PokerAction.FOLD, 0

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int,
                          can_check: bool, current_bet: int, pot_size: int,
                          min_raise: int, max_raise: int) -> Tuple[PokerAction, int]:
        # Preflop strategy based on hole cards strength
        hand_rank = self.hand_strength

        # Adjust min_raise to be at least 2x current bet if needed
        min_raise = max(min_raise, 2 * current_bet) if current_bet > 0 else min_raise

        # Tight-aggressive preflop play
        if hand_rank >= 0.8:
            # Premium hands: always raise or 3-bet
            if current_bet == 0:
                return PokerAction.RAISE, min(2 * min_raise, remaining_chips)
            elif current_bet < remaining_chips:
                return PokerAction.RAISE, min(current_bet + min_raise, remaining_chips)
            else:
                return PokerAction.CALL, 0

        elif hand_rank >= 0.6:
            # Medium strength: raise if no bet, call otherwise
            if current_bet == 0:
                return PokerAction.RAISE, min(2 * min_raise, remaining_chips)
            elif current_bet <= min_raise * 2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        elif hand_rank >= 0.4:
            # Marginal: only call small bets
            if current_bet == 0:
                return PokerAction.CHECK if can_check else PokerAction.CALL, 0
            elif current_bet <= min_raise:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        else:
            # Weak hands: fold unless checking
            if can_check:
                return PokerAction.CHECK, 0
            elif current_bet == 0 or (current_bet <= min_raise and remaining_chips >= current_bet):
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int,
                           can_check: bool, current_bet: int, pot_size: int,
                           min_raise: int, max_raise: int) -> Tuple[PokerAction, int]:
        hand_rank = self.hand_strength

        # Pot odds: required equity to call
        call_amount = current_bet
        pot_odds = call_amount / (pot_size + call_amount + 1e-9)  # Avoid division by zero

        # Expected value decision
        if hand_rank > pot_odds * 1.5:
            # Strong hand: raise or bet
            if current_bet == 0:
                bet_size = min(int(0.5 * pot_size), remaining_chips)
                if bet_size == 0:
                    return PokerAction.CHECK if can_check else PokerAction.CALL, 0
                return PokerAction.RAISE, max(bet_size, min_raise)
            else:
                raise_amount = min(current_bet + int(0.75 * pot_size), remaining_chips)
                return PokerAction.RAISE, max(raise_amount, current_bet + min_raise)
        elif hand_rank > pot_odds:
            # Decent hand: call or check
            if current_bet == 0:
                return PokerAction.CHECK if can_check else PokerAction.CALL, 0
            elif remaining_chips >= call_amount:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # Weak hand: fold
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluate the strength of the hand.
        Returns a float between 0 and 1.
        """
        try:
            if not isinstance(hole_cards, list) or len(hole_cards) != 2:
                return 0.5

            # Preflop: use static hand ranking
            if not community_cards:
                return self._preflop_hand_rank(hole_cards)

            # Postflop: evaluate actual hand strength
            all_cards = hole_cards + community_cards
            ranks = []
            suits = []

            for card in all_cards:
                if not card or not isinstance(card, str) or len(card) < 2:
                    continue
                rank_char = card[0]
                suit = card[-1]
                rank = self._card_rank(rank_char)
                if rank is not None:
                    ranks.append(rank)
                    suits.append(suit)

            if len(ranks) < 2:
                return 0.1

            # Check for made hands
            hand_score = self._evaluate_hand_score(ranks, suits)
            # Normalize score to [0,1]
            return min(hand_score / 9.0, 1.0)

        except Exception as e:
            return 0.5  # Default value on error

    def _preflop_hand_rank(self, hole_cards: List[str]) -> float:
        """Return a static preflop hand strength estimate."""
        try:
            r1 = self._card_rank(hole_cards[0][0])
            r2 = self._card_rank(hole_cards[1][0])
            s1 = hole_cards[0][-1]
            s2 = hole_cards[1][-1]
            suited = (s1 == s2)

            # Sort ranks descending
            high, low = max(r1, r2), min(r1, r2)

            # Normalize ranks (A=14, K=13, ..., 2=2)
            if high == low:  # Pairs
                return 0.3 + (high - 2) * 0.05
            elif suited:
                return 0.15 + (high - 2) * 0.03 + (low - 2) * 0.01
            else:
                return 0.1 + (high - 2) * 0.03 + (low - 2) * 0.005

        except Exception as e:
            return 0.5

    def _card_rank(self, rank_char: str) -> int:
        """Convert card rank character to numerical value."""
        if not rank_char:
            return 2
        if rank_char in 'Tt':
            return 10
        if rank_char in 'Jj':
            return 11
        if rank_char in 'Qq':
            return 12
        if rank_char in 'Kk':
            return 13
        if rank_char in 'Aa':
            return 14
        try:
            return int(rank_char)
        except ValueError:
            return 2  # Default to 2 if invalid

    def _evaluate_hand_score(self, ranks: List[int], suits: List[str]) -> float:
        """
        Evaluate the best 5-card poker hand.
        Returns a score where higher is better.
        """
        try:
            from collections import Counter

            if len(ranks) + len(suits) < 5:
                return 0

            # Count ranks and suits
            rank_count = Counter(ranks)
            suit_count = Counter(suits)

            # Sort ranks by frequency, then by value (high card first)
            sorted_ranks = sorted(rank_count.keys(), key=lambda x: (rank_count[x], x), reverse=True)

            # Group ranks by frequency
            freq_groups = {}
            for r, c in rank_count.items():
                freq_groups.setdefault(c, []).append(r)

            for group in freq_groups.values():
                group.sort(reverse=True)

            # Check flush
            flush_suit = None
            for suit, count in suit_count.items():
                if count >= 5:
                    flush_suit = suit
                    break

            # Get all cards of flush suit if exists
            flush_ranks = []
            if flush_suit:
                flush_ranks = [r for r, s in zip(ranks, suits) if s == flush_suit]
                flush_ranks = sorted(set(flush_ranks), reverse=True)[:5]

            # Check straight
            unique_ranks = sorted(set(ranks), reverse=True)
            # Check for A-5-4-3-2 straight
            if 14 in unique_ranks and 5 in unique_ranks and 4 in unique_ranks and 3 in unique_ranks and 2 in unique_ranks:
                straight_high = 5
            else:
                straight_high = None
                for i in range(len(unique_ranks) - 4):
                    if all(unique_ranks[i + j] == unique_ranks[i] - j for j in range(5)):
                        straight_high = unique_ranks[i]
                        break

            # Hand rankings:
            # 8: Straight flush
            # 7: Four of a kind
            # 6: Full house
            # 5: Flush
            # 4: Straight
            # 3: Three of a kind
            # 2: Two pair
            # 1: One pair
            # 0: High card

            # Check straight flush
            if flush_suit and flush_ranks:
                flush_unique = sorted(flush_ranks, reverse=True)
                if 14 in flush_unique and 5 in flush_unique and 4 in flush_unique and 3 in flush_unique and 2 in flush_unique:
                    return 8.5  # Ace-low straight flush
                for i in range(len(flush_unique) - 4):
                    if all(flush_unique[i + j] == flush_unique[i] - j for j in range(5)):
                        return 8.0 + flush_unique[i] / 100.0

            # Four of a kind
            if 4 in freq_groups:
                quad_rank = freq_groups[4][0]
                kicker = freq_groups[1][0] if 1 in freq_groups else quad_rank
                return 7.0 + quad_rank / 100.0 + kicker / 10000.0

            # Full house
            if 3 in freq_groups and (2 in freq_groups or len(freq_groups.get(3, [])) >= 2):
                trips = freq_groups[3][0]
                pair = freq_groups[2][0] if 2 in freq_groups else freq_groups[3][1]
                return 6.0 + trips / 100.0 + pair / 10000.0

            # Flush
            if flush_suit:
                score = 5.0
                for i, r in enumerate(flush_ranks[:5]):
                    score += r / (100.0 ** (i + 1))
                return score

            # Straight
            if straight_high:
                return 4.0 + straight_high / 100.0

            # Three of a kind
            if 3 in freq_groups:
                trips = freq_groups[3][0]
                kickers = sorted(freq_groups.get(1, []) + freq_groups.get(2, []), reverse=True)[:2]
                score = 3.0 + trips / 100.0
                for i, k in enumerate(kickers):
                    score += k / (10000.0 * (100 ** i))
                return score

            # Two pair
            if 2 in freq_groups and len(freq_groups[2]) >= 2:
                pairs = sorted(freq_groups[2], reverse=True)[:2]
                kicker = freq_groups.get(1, [0])[0]
                return 2.0 + pairs[0] / 100.0 + pairs[1] / 10000.0 + kicker / 1000000.0

            # One pair
            if 2 in freq_groups:
                pair = freq_groups[2][0]
                kickers = sorted(freq_groups.get(1, []), reverse=True)[:3]
                score = 1.0 + pair / 100.0
                for i, k in enumerate(kickers):
                    score += k / (10000.0 * (100 ** i))
                return score

            # High card
            hc_ranks = sorted(unique_ranks, reverse=True)[:5]
            score = 0.0
            for i, r in enumerate(hc_ranks):
                score += r / (100.0 ** (i + 1))
            return score

        except Exception as e:
            return 0.0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: Track round results for adaptive play
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict,
                    active_players_hands: dict):
        # Optional: Clean up or analyze final results
        pass