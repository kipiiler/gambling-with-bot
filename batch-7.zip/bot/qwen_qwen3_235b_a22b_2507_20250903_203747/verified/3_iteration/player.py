from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.game_phase = None  # To track game-wide phase
        self.positional_importance = {}
        self.hand_strength_cache = {}
        self.opp_aggression = {}  # Track opponent aggression frequency
        self.total_actions = {}  # Track total actions per opponent
        self.tight_aggressive_threshold = 0.3  # How often opponents raise before adjusting
        self.voluntary_played = {}  # Did player voluntarily put in chips
        self.voluntary_count = {}  # Count of voluntary actions
        self.total_hands_seen = 0
        self.table_tightness = 0.6  # Estimate of average fold rate by table

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_hands = {}
        self.opp_aggression = {pid: 0 for pid in all_players}
        self.total_actions = {pid: 0 for pid in all_players}
        self.voluntary_played = {pid: 0 for pid in all_players}
        self.voluntary_count = {pid: 0 for pid in all_players}
        self.total_hands_seen = 0
        self.table_tightness = 0.6

        # Estimate position importance based on IDs (simplified)
        self.update_positions()

    def update_positions(self):
        """Update positional awareness (early/middle/late based on player IDs)."""
        if not self.all_players or self.id is None:
            return
        try:
            player_index = self.all_players.index(self.id)
            total = len(self.all_players)
            if total <= 2:
                self.positional_importance[self.id] = "BTN/SB"
            else:
                if player_index == (self.all_players.index(self.big_blind_player_id) - 1) % total:
                    pos = "BTN"
                elif player_index == self.all_players.index(self.big_blind_player_id):
                    pos = "BB"
                elif player_index == (self.all_players.index(self.big_blind_player_id) + 1) % total:
                    pos = "SB"
                else:
                    pos = "MP" if player_index < total * 0.6 else "LAG"
                self.positional_importance[self.id] = pos
        except:
            self.positional_importance[self.id] = "UNK"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.update_opp_statistics(round_state)

    def update_opp_statistics(self, round_state: RoundStateClient):
        """Track opponents' playing styles across hands."""
        self.total_hands_seen += 1
        current_round = round_state.round
        # Use player_actions to detect aggressive/voluntary actions
        for pid_str in round_state.player_actions:
            try:
                pid = int(pid_str)
                if pid == self.id:
                    continue
                action = round_state.player_actions[pid_str]

                self.total_actions[pid] = self.total_actions.get(pid, 0) + 1

                # Voluntary actions: CALL, RAISE, CHECK when bet is on, etc.
                if action in ['RAISE', 'CALL'] or (action == 'CHECK' and round_state.current_bet > 0):
                    self.voluntary_count[pid] = self.voluntary_count.get(pid, 0) + 1
                if action == 'RAISE':
                    self.opp_aggression[pid] = self.opp_aggression.get(pid, 0) + 1
            except:
                continue

        # Recalculate table tightness: average fold rate
        total_fold = 0
        total_actions = 0
        for pid in self.all_players:
            if pid == self.id:
                continue
            total_fold += max(0, self.total_actions.get(pid, 0) - self.voluntary_count.get(pid, 0))
            total_actions += self.total_actions.get(pid, 0)
        self.table_tightness = (total_fold / (total_actions + 1e-8)) if total_actions > 0 else 0.6

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Reset cache for this hand
            if round_state.round_num not in self.hand_strength_cache:
                self.hand_strength_cache[round_state.round_num] = {}
            
            # Validate self.id has been assigned
            if self.id is None:
                return PokerAction.FOLD, 0

            # Get current player ID
            current_pid = str(self.id)
            pot = round_state.pot
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)
            player_bet = round_state.player_bets.get(current_pid, 0)
            call_amount = current_bet - player_bet
            in_pot = player_bet

            # Available actions based on state
            can_check = current_bet == player_bet
            can_call = call_amount > 0 and call_amount <= remaining_chips
            can_raise = remaining_chips > 0 and min_raise <= remaining_chips and current_bet < 2 * max(remaining_chips, min_raise)
            has_enough_to_raise = max_raise >= min_raise

            # Extract hole cards and community cards
            hole_cards = self.player_hands.get(self.id, [])
            community_cards = round_state.community_cards

            # Get hand strength and equity estimation
            hand_ranking, hand_type = self.evaluate_hand_strength(hole_cards, community_cards)
            equity = self.estimate_equity(hole_cards, community_cards, num_players=len(round_state.player_bets))
            position = self.positional_importance.get(self.id, "MP")

            # Positional adjustment: early position plays tighter
            if position == "BTN":
                equity += 0.1
            elif position == "BB":
                equity += 0.05
            elif "early" in position.lower():
                equity -= 0.05

            # Opponent modeling: adjust if table is tight
            if self.table_tightness > 0.5:  # Tight table, bluff more, steal more
                equity = min(1.0, equity + 0.1)
            else:  # Loose table, value bet more
                equity = max(0.0, equity - 0.1)

            # Round-based decision logic
            round_name = round_state.round
            pot_odds = call_amount / (pot + call_amount + 1e-8)
            implied_odds_multiplier = 2.0 if len(community_cards) < 5 else 1.0
            required_equity_to_call = pot_odds / (1 + implied_odds_multiplier * pot_odds)

            # Pre-flop strategy
            if round_name == 'Preflop':
                preflop_score = self.preflop_hand_strength(hole_cards)
                is_in_position = position in ["BTN", "LAG"]

                # Adjust for position
                if is_in_position:
                    preflop_score += 0.1
                else:
                    preflop_score = max(0.0, preflop_score - 0.1)

                # Raising from late position
                if preflop_score > 0.5 and can_raise and has_enough_to_raise:
                    raise_amount = min(min_raise + 50, remaining_chips // 3, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                elif preflop_score > 0.3 and (can_call or can_check):
                    if can_call and call_amount <= self.blind_amount * 4:
                        return PokerAction.CALL, 0
                    if can_check:
                        return PokerAction.CHECK, 0
                else:
                    if in_pot >= self.blind_amount * 2:
                        return PokerAction.FOLD, 0
                    else:
                        if can_call and call_amount <= self.blind_amount * 2:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0

            # Post-flop strategy
            else:
                # Bluffing opportunity if missed draw but high card
                is_draw = 'Draw' in hand_type
                is_made_hand = hand_ranking > 0.5
                is_bluff_worthy = hand_ranking > 0.3 and len([c for c in hole_cards if c[0] in 'AKQJT']) >= 1

                # Aggressive if strong hand
                if equity > 0.7:
                    if can_raise and has_enough_to_raise:
                        raise_amount = min(
                            max(pot // 2, min_raise),
                            max_raise
                        )
                        return PokerAction.RAISE, raise_amount
                    elif can_call:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CHECK, 0
                elif equity > required_equity_to_call:
                    if can_raise and has_enough_to_raise and random.random() < 0.3:
                        raise_amount = min(
                            max(pot // 4, min_raise),
                            max_raise
                        )
                        return PokerAction.RAISE, raise_amount
                    elif can_call:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CHECK, 0
                elif equity > 0.2 and random.random() < 0.3 and is_bluff_worthy and self.table_tightness > 0.5:
                    # Light bluff on tight table
                    if can_raise and has_enough_to_raise and pot > 0:
                        bluff_raise = min(pot, max_raise)
                        return PokerAction.RAISE, bluff_raise
                    else:
                        return PokerAction.CALL, 0 if can_call and call_amount < remaining_chips else PokerAction.FOLD, 0
                else:
                    if can_call and call_amount < remaining_chips * 0.2 and random.random() < 0.2:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

        except Exception as e:
            # On any error, fold safely
            return PokerAction.FOLD, 0

    def preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """Compute preflop hand strength score."""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0

        r1, s1 = hole_cards[0][0], hole_cards[0][1]
        r2, s2 = hole_cards[1][0], hole_cards[1][1]

        value_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        v1, v2 = value_map[r1], value_map[r2]

        score = 0.0
        high_card = max(v1, v2)
        low_card = min(v1, v2)

        # Premium pairs
        if r1 == r2:
            score += 0.3 + (high_card - 2) / 100 * 0.5
        # Suited
        if s1 == s2:
            score += 0.1
        # Connected
        if abs(v1 - v2) == 1:
            score += 0.05
        elif abs(v1 - v2) == 2:
            score += 0.03
        elif abs(v1 - v2) == 3:
            score += 0.02

        # High cards
        if high_card >= 11:  # J+
            score += 0.1
        if low_card >= 10:  # T+
            score += 0.05

        # Gap penalty
        gap = high_card - low_card
        if gap == 1 and r1 != r2:
            score += 0.1
        elif gap > 4:
            score -= 0.05

        return min(score, 1.0)

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[float, str]:
        """Evaluate hand strength and return a score (0-1) and type."""
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self.estimate_preflop_equity(hole_cards), "Unresolved"

        # Simplified hand evaluation
        ranks = [self.card_rank(c) for c in all_cards]
        suits = [c[1] for c in all_cards]
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        is_flush = max(suit_count.values()) >= 5
        sorted_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i] == sorted_ranks[i+1]+1 == sorted_ranks[i+2]+2 == sorted_ranks[i+3]+3 == sorted_ranks[i+4]+4:
                is_straight = True
                break

        pairs = sum(1 for v in rank_count.values() if v == 2)
        trips = sum(1 for v in rank_count.values() if v == 3)
        quads = sum(1 for v in rank_count.values() if v == 4)

        # Hand type scoring
        if quads:
            return 0.95, "Four of a kind"
        elif trips and pairs >= 1:
            return 0.9, "Full house"
        elif is_flush and is_straight:
            return 0.99, "Straight flush"
        elif is_flush:
            return 0.75, "Flush"
        elif is_straight:
            return 0.7, "Straight"
        elif trips:
            return 0.6, "Three of a kind"
        elif pairs >= 2:
            return 0.5, "Two pair"
        elif pairs == 1:
            return 0.4, "One pair"
        else:
            return 0.1 + max(ranks) / 100, "High card"

    def card_rank(self, card: str) -> int:
        """Convert card rank to numeric value."""
        r = card[0]
        return {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}[r]

    def estimate_equity(self, hole_cards: List[str], community_cards: List[str], num_players: int = 2) -> float:
        """Estimate equity using Monte Carlo simulation or heuristic."""
        if len(community_cards) == 0:
            return self.estimate_preflop_equity(hole_cards)

        # Heuristic-based equity for post-flop
        hand_strength, hand_type = self.evaluate_hand_strength(hole_cards, community_cards)
        num_known = len(community_cards) + 2
        unknown = 52 - num_known
        opponents = num_players - 1

        # Basic adjustment for number of opponents and hand strength
        if 'Pair' in hand_type:
            equity = 0.6 - (opponents * 0.15)
        elif 'Two' in hand_type:
            equity = 0.55 - (opponents * 0.1)
        elif 'Three' in hand_type:
            equity = 0.7 - (opponents * 0.12)
        elif 'Straight' in hand_type:
            equity = 0.8 - (opponents * 0.1)
        elif 'Flush' in hand_type:
            equity = 0.82 - (opponents * 0.1)
        elif 'Full' in hand_type:
            equity = 0.9 - (opponents * 0.08)
        else:
            equity = 0.4 - (opponents * 0.15)

        # Improve equity with draws
        if self.has_draw(hole_cards, community_cards):
            equity += 0.1

        return max(0.05, min(0.95, equity))

    def estimate_preflop_equity(self, hole_cards: List[str]) -> float:
        """Fast heuristic preflop equity."""
        score = self.preflop_hand_strength(hole_cards)
        return 0.3 + score * 0.5

    def has_draw(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        """Check if there's an open-ended straight or flush draw."""
        all_cards = hole_cards + community_cards
        ranks = [c[0] for c in all_cards]
        suits = [c[1] for c in all_cards]

        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        if max(suit_count.values()) >= 4:
            return True

        rank_vals = sorted(set([{'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}[r] for r in ranks]))
        for i in range(len(rank_vals) - 3):
            if rank_vals[i]+1 in rank_vals and rank_vals[i]+2 in rank_vals and rank_vals[i]+3 in rank_vals:
                return True
            if rank_vals[i]+1 in rank_vals and rank_vals[i]+2 in rank_vals and rank_vals[i]+4 in rank_vals:
                return True
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: Update strategy based on outcome
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game completed, clean up or learn
        pass