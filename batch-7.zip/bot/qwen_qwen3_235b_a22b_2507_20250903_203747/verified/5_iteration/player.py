from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.current_hand = []  # Store current hole cards
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.position_in_hand = None  # Early=0, Mid=1, Late=2
        self.hand_strength_estimation = 0.0
        self.acted_this_round = False
        self.previous_bet = 0
        self.game_phase = "preflop"

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_id = self.id
        self.current_hand = player_hands
        self.acted_this_round = False
        self.previous_bet = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.acted_this_round = False
        self.previous_bet = 0
        self.game_phase = round_state.round.lower()
        # Update position if possible (late if last 2, mid if middle, early if first half)
        active_players = round_state.current_player
        if self.player_id in active_players:
            pos_index = active_players.index(self.player_id)
            total = len(active_players)
            if pos_index >= total - 2:
                self.position_in_hand = 2  # Late position
            elif pos_index < total // 2:
                self.position_in_hand = 0  # Early
            else:
                self.position_in_hand = 1  # Mid

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            player_bet = round_state.player_bets.get(str(self.player_id), 0)

            # Avoid zero division
            epsilon = 1e-8

            # Determine hand strength (simplified)
            hand_score = self.evaluate_hand_strength(self.current_hand, community_cards)
            self.hand_strength_estimation = hand_score

            # Determine effective stack to pot ratio
            SPR = remaining_chips / (pot + epsilon)

            # Get how much to call
            to_call = current_bet - player_bet
            can_raise = min_raise <= max_raise and remaining_chips >= min_raise

            # Preflop logic
            if round_state.round == 'Preflop':
                opening_score = self.preflop_hand_ranking(self.current_hand)
                aggro_factor = self.calculate_aggression_factor(round_state, remaining_chips)

                # Fold weak hands
                if opening_score < 0.3:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)

                # Strong hands: raise or 3-bet
                if opening_score > 0.7:
                    if to_call == 0:
                        raise_amount = min(max(int(pot * 0.7), min_raise), max_raise)
                        if can_raise and raise_amount >= min_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.CALL, 0)
                    elif to_call > 0:
                        if to_call <= remaining_chips * 0.5 or SPR < 10:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)

                # Medium hands
                if 0.3 <= opening_score <= 0.7:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif to_call <= blind_amount * 4:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)

            # Post-flop logic
            else:
                hand_category = self.categorize_hand(hand_score)
                pot_odds = to_call / (pot + to_call + epsilon)
                equity = hand_score

                # Bluffing adjustment based on position and board texture
                bluff_boost = 0.1 if self.position_in_hand == 2 and random.random() < 0.3 else 0.0
                adjusted_equity = min(equity + bluff_boost, 1.0)

                if adjusted_equity > pot_odds * 1.5 and can_raise:
                    # Value bet: bet size = pot * equity (semi-polarized)
                    bet_size = min(int(pot * adjusted_equity), max_raise)
                    bet_size = max(bet_size, min_raise)
                    return (PokerAction.RAISE, bet_size)

                elif adjusted_equity > pot_odds:
                    if to_call == 0:
                        # Donk bet or check-back
                        if random.random() < 0.3:
                            bet_size = min(int(pot * 0.5), max_raise)
                            bet_size = max(bet_size, min_raise)
                            return (PokerAction.RAISE, bet_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        if to_call <= remaining_chips * 0.4 or SPR < 3:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        # Small probability bluff or float
                        if self.position_in_hand == 2 and random.random() < 0.1 and SPR > 5:
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)

            # Default to fold if all else fails (should not happen)
            return (PokerAction.FOLD, 0)

        except Exception as e:
            # Safety fallback
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-specific state
        self.acted_this_round = False
        self.previous_bet = 0

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: log performance or adjust long-term strategy
        pass

    # -------------------
    # Utility Functions
    # -------------------

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple heuristic-based hand strength estimation."""
        if not hole_cards:
            return 0.0

        if len(community_cards) == 0:
            return self.preflop_hand_ranking(hole_cards)

        all_cards = hole_cards + community_cards
        ranks = [self.card_rank(card) for card in all_cards]
        suits = [card[-1] for card in all_cards]

        # Count pairs, draws, etc.
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        max_rank_count = max(rank_count.values()) if rank_count else 0

        # Check flush draw
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        flush_draw = max(suit_count.values()) >= 4
        made_flush = max(suit_count.values()) >= 5

        # Check straight draw
        unique_ranks = sorted(set(ranks))
        straight_draw = any(
            all(r + i in unique_ranks for i in range(4)) for r in unique_ranks
        )

        # Made hand?
        made_straight = any(
            all(r + i in unique_ranks for i in range(5)) for r in unique_ranks
        )

        # Hand strength scores
        score = 0.0
        if max_rank_count == 4:
            score = 0.95  # Quads
        elif max_rank_count == 3 and 2 in rank_count.values():
            score = 0.85  # Full house
        elif made_flush:
            score = 0.8
        elif made_straight:
            score = 0.75
        elif max_rank_count == 3:
            score = 0.65  # Trips
        elif list(rank_count.values()).count(2) >= 2:
            score = 0.6  # Two pair
        elif max_rank_count == 2:
            # Pocket pair or one pair
            pair_rank = max(k for k, v in rank_count.items() if v == 2)
            if pair_rank >= 10:
                score = 0.5 + (pair_rank - 10) * 0.03  # High pair
            else:
                score = 0.4  # Low pair
        else:
            # High card
            top_kicker = max(ranks)
            if top_kicker >= 12:
                score = 0.2 + (top_kicker - 12) * 0.1
            else:
                score = 0.1

        # Draw bonuses
        if flush_draw and not made_flush:
            score += 0.1
        if straight_draw and not made_straight:
            score += 0.08
        if max_rank_count == 3 and not made_straight and not made_flush:
            score += 0.05  # Set value
        if max_rank_count == 1 and top_kicker >= 12:
            score += 0.03  # High card draw

        # Reduce score if overcard danger on board (for weak pairs)
        board_high = max([self.card_rank(c) for c in community_cards])
        if max_rank_count == 2 and board_high > max(ranks):
            score -= 0.1

        return min(score, 1.0)

    def preflop_hand_ranking(self, hole_cards: List[str]) -> float:
        """Simple preflop hand strength table."""
        if len(hole_cards) != 2:
            return 0.0

        r1, s1 = self.card_rank(hole_cards[0]), hole_cards[0][-1]
        r2, s2 = self.card_rank(hole_cards[1]), hole_cards[1][-1]

        is_suited = s1 == s2
        is_pair = r1 == r2
        gap = abs(r1 - r2)
        high_card = max(r1, r2)
        low_card = min(r1, r2)

        score = 0.0
        if is_pair:
            score = 0.3 + (r1 * 0.04)
        else:
            if high_card >= 12:  # A or K
                score = 0.15 + (high_card - 11) * 0.05
                if low_card >= 10:
                    score += 0.05
                if is_suited:
                    score += 0.03
                if gap <= 1:
                    score += 0.02
            elif high_card >= 10:  # Q, J, T
                score = 0.1 + (high_card - 9) * 0.03
                if is_suited:
                    score += 0.03
                if gap <= 1:
                    score += 0.04
                if low_card >= 8:
                    score += 0.02

        if gap > 2 and not is_suited:
            score *= 0.7
        if gap == 1 and is_suited:
            score *= 1.1

        return min(score, 1.0)

    def categorize_hand(self, score: float) -> str:
        if score >= 0.8:
            return "nuts"
        elif score >= 0.6:
            return "strong"
        elif score >= 0.4:
            return "medium"
        elif score >= 0.2:
            return "weak"
        else:
            return "junk"

    def calculate_aggression_factor(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        total_actions = 0
        raises = 0
        for actions in round_state.player_actions.values():
            total_actions += 1
            if "Raise" in actions or "AllIn" in actions:
                raises += 1
        return raises / (total_actions + 1e-8)

    def card_rank(self, card: str) -> int:
        """Convert card rank to numeric value: 2=2, ..., T=10, J=11, Q=12, K=13, A=14"""
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                   'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        # Extract rank: handle 10 as 'T' in messages
        rank_char = re.search(r'[2-9TJQKA]', card)
        if rank_char:
            return mapping.get(rank_char.group(), 0)
        return 0