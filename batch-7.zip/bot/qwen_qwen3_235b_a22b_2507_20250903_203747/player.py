from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.current_hand_strength = 0.0
        self.position = None
        self.player_stack = 10000
        self.opponent_stack = 10000
        self.is_big_blind = False
        self.is_small_blind = False
        self.blind_amount = 10
        self.round_num = 0
        self.player_hands = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_stack = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.opponent_stack = starting_chips
        player_id = self.id if self.id is not None else all_players[0]
        self.is_big_blind = (player_id == big_blind_player_id)
        self.is_small_blind = (player_id == small_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.player_stack = remaining_chips
        self.round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.player_stack = remaining_chips
        round_type = round_state.round
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_bets = round_state.player_bets
        current_player_id = str(self.id) if self.id is not None else "0"

        # Handle side pots: check if we are eligible
        if round_state.side_pots:
            eligible = False
            for pot_info in round_state.side_pots:
                if self.id in pot_info.get('eligible_players', []):
                    eligible = True
                    break
            if not eligible:
                # Already all-in or excluded, but just in case
                return PokerAction.CHECK, 0

        # Get our current bet in this round
        our_current_bet = player_bets.get(current_player_id, 0)

        # Calculate amount needed to call
        to_call = current_bet - our_current_bet

        # Defensive programming: ensure values are non-negative
        to_call = max(0, to_call)
        min_raise = max(2 * to_call, min_raise) if to_call > 0 else max_raise
        min_raise = min(min_raise, max_raise)

        # Determine hand strength based on game stage
        hand_strength = self.assess_hand_strength(self.player_hands, community_cards)

        # Preflop strategy
        if round_type == 'Preflop':
            action, amount = self.preflop_strategy(hand_strength, to_call, pot, min_raise, max_raise, remaining_chips)
        
        # Postflop strategy
        else:
            board_danger = self.assess_board_danger(community_cards)
            action, amount = self.postflop_strategy(hand_strength, board_danger, to_call, pot, min_raise, max_raise, remaining_chips)

        # Validate action and amount
        if action == PokerAction.RAISE:
            total_bet = our_current_bet + amount
            if amount < min_raise or total_bet <= current_bet:
                # Invalid raise, fallback to call if possible
                if to_call > 0:
                    if to_call < remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.CHECK, 0
        
        if action == PokerAction.CALL:
            if to_call == 0:
                action = PokerAction.CHECK
            elif to_call >= remaining_chips:
                action = PokerAction.ALL_IN

        if action == PokerAction.CHECK:
            if to_call > 0:
                # Cannot check when facing a bet
                if to_call < remaining_chips:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.ALL_IN

        return action, amount

    def preflop_strategy(self, hand_strength: float, to_call: int, pot: int, min_raise: int, max_raise: int, stack: int) -> Tuple[PokerAction, int]:
        # Strong hands: AA, KK, AKs, QQ
        if hand_strength >= 0.9:
            if to_call == 0:
                # Open raise
                raise_amount = min(int(0.05 * pot) + 2 * self.blind_amount, max_raise)
                return PokerAction.RAISE, max(min_raise, raise_amount)
            else:
                if to_call < stack * 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0

        # Medium hands: JJ, AQ, TT, 99, etc.
        elif hand_strength >= 0.7:
            if to_call == 0:
                # Limp or small raise
                if random.random() < 0.7:
                    return PokerAction.RAISE, max(min_raise, min(3 * self.blind_amount, max_raise))
                else:
                    return PokerAction.CALL, 0
            else:
                if to_call <= 3 * self.blind_amount:
                    return PokerAction.CALL, 0
                elif to_call < stack * 0.15:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Weak hands
        else:
            if to_call == 0:
                # Small chance to limp with weak hand in late position
                if self.is_big_blind or self.is_small_blind:
                    if random.random() < 0.3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Fold most weak hands
                if hand_strength > 0.4 and to_call <= self.blind_amount * 2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

    def postflop_strategy(self, hand_strength: float, board_danger: float, to_call: int, pot: int, min_raise: int, max_raise: int, stack: int) -> Tuple[PokerAction, int]:
        equity = hand_strength * (1 - board_danger)

        if hand_strength > 0.7:  # Strong hand (top pair or better)
            if to_call == 0:
                bet_size = min(int(0.6 * pot), max_raise)
                return PokerAction.RAISE, max(min_raise, bet_size)
            else:
                if to_call < 0.5 * pot:
                    # Call or raise
                    if equity > 0.8 and pot > stack * 0.2:
                        return PokerAction.ALL_IN, 0
                    else:
                        raise_size = min(int(0.75 * pot), max_raise)
                        return PokerAction.RAISE, max(min_raise, raise_size)
                else:
                    if equity > 0.85:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

        elif hand_strength > 0.4:  # Medium hand (middle pair, gutshot)
            if to_call == 0:
                if random.random() < 0.6:
                    bet_size = min(int(0.5 * pot), max_raise)
                    return PokerAction.RAISE, max(min_raise, bet_size)
                else:
                    return PokerAction.CHECK, 0
            else:
                if to_call <= 0.4 * pot:
                    return PokerAction.CALL, 0
                else:
                    if equity > 0.45 and random.random() < 0.3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

        else:  # Weak hand
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                if to_call > 0.5 * pot:
                    return PokerAction.FOLD, 0
                else:
                    # Small chance to bluff or float
                    if random.random() < 0.1:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

    def assess_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0

        # Simplified hand strength evaluation
        ranks = "23456789TJKQA"
        suits = "CDHS"

        hole_ranks = [card[0] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]

        # Check for pairs
        if hole_ranks[0] == hole_ranks[1]:
            rank_value = ranks.index(hole_ranks[0])
            if rank_value >= 12:  # A
                return 0.95
            elif rank_value >= 11:  # K
                return 0.90
            elif rank_value >= 10:  # Q
                return 0.85
            elif rank_value >= 9:  # J
                return 0.80
            elif rank_value >= 8:  # T
                return 0.75
            elif rank_value >= 6:  # 9-7
                return 0.70
            else:
                return 0.55

        # Not paired
        high_rank = max(ranks.index(hole_ranks[0]), ranks.index(hole_ranks[1]))
        low_rank = min(ranks.index(hole_ranks[0]), ranks.index(hole_ranks[1]))
        gap = high_rank - low_rank

        # Suited?
        is_suited = hole_suits[0] == hole_suits[1]

        # Premium unpaired hands
        if high_rank >= 12:  # Ace
            if low_rank >= 10:  # AK, AQ, AJ
                return 0.85 if is_suited else 0.75
            elif low_rank >= 8:  # AT down to A9
                return 0.70 if is_suited else 0.60
            elif low_rank >= 5:  # A8 down to A6
                return 0.60 if is_suited else 0.50
            else:
                return 0.50 if is_suited else 0.40

        elif high_rank >= 11:  # King
            if low_rank >= 10:  # KQ, KJ
                return 0.75 if is_suited else 0.65
            elif low_rank >= 8:  # KT down to K9
                return 0.65 if is_suited else 0.55
            elif gap <= 1 and is_suited:  # Connected and suited
                return 0.60
            else:
                return 0.45 if is_suited else 0.35

        elif high_rank >= 9:  # Jack or Ten
            if gap <= 1 and is_suited:  # Connectors
                return 0.60
            elif gap <= 2 and is_suited:  # Suited one-gappers
                return 0.55
            elif gap <= 1:  # Connected
                return 0.50
            else:
                return 0.35 if is_suited else 0.25

        else:
            # Lower cards
            if gap <= 1 and is_suited:
                return 0.45
            elif gap <= 1:
                return 0.40
            elif is_suited:
                return 0.35
            else:
                return 0.25

    def assess_board_danger(self, community_cards: List[str]) -> float:
        if not community_cards or len(community_cards) < 3:
            return 0.0

        ranks = "23456789TJKQA"
        board_ranks = [card[0] for card in community_cards]
        board_suits = [card[1] for card in community_cards]

        # Check for pairs on board
        rank_counts = {}
        for r in board_ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        paired = any(count > 1 for count in rank_counts.values())

        # Check for flush potential
        suit_counts = {}
        for s in board_suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_draw = any(count >= 3 for count in suit_counts.values())

        # Check for straight potential
        unique_ranks = sorted(set(ranks.index(r) for r in board_ranks))
        gap_sum = 0
        for i in range(len(unique_ranks) - 1):
            gap_sum += unique_ranks[i + 1] - unique_ranks[i] - 1
        straight_potential = gap_sum <= 2 and len(unique_ranks) >= 3

        danger_score = 0.0
        if paired:
            danger_score += 0.3
        if flush_draw:
            danger_score += 0.3
        if straight_potential:
            danger_score += 0.3

        return min(danger_score, 1.0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.player_stack = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Cleanup if needed
        pass