from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import itertools

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class HandEvaluator:
    """A simple hand evaluator for Texas Hold'em using lookup tables"""
    def __init__(self):
        self.rank_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        self.suit_values = {'s':4, 'h':3, 'd':2, 'c':1}
        
    def evaluate_hand(self, cards: List[str]) -> int:
        """Evaluate a 5+ card hand and return a strength score (lower is better)"""
        suits = [card[-1] for card in cards]
        ranks = sorted([self.rank_values[card[:-1]] for card in cards], reverse=True)
        
        is_flush = len(set(suits)) <= 1
        is_straight = self._is_straight(ranks)
        rank_counts = self._count_ranks(ranks)
        
        # High card
        hand_rank = 1
        tiebreaker = ranks
        
        if is_straight and is_flush:
            hand_rank = 8  # Straight flush
            tiebreaker = [max(ranks)]
        elif 4 in rank_counts.values():
            hand_rank = 7  # Four of a kind
            tiebreaker = self._get_tiebreaker(rank_counts, ranks, [4, 1])
        elif 3 in rank_counts.values() and 2 in rank_counts.values():
            hand_rank = 6  # Full house
            tiebreaker = self._get_tiebreaker(rank_counts, ranks, [3, 2])
        elif is_flush:
            hand_rank = 5  # Flush
            tiebreaker = ranks
        elif is_straight:
            hand_rank = 4  # Straight
            tiebreaker = [max(ranks)]
        elif 3 in rank_counts.values():
            hand_rank = 3  # Three of a kind
            tiebreaker = self._get_tiebreaker(rank_counts, ranks, [3, 1, 1])
        elif list(rank_counts.values()).count(2) >= 2:
            hand_rank = 2  # Two pair
            tiebreaker = self._get_tiebreaker(rank_counts, ranks, [2, 2, 1])
        elif 2 in rank_counts.values():
            hand_rank = 1  # One pair
            tiebreaker = self._get_tiebreaker(rank_counts, ranks, [2, 1, 1, 1])
        
        # Create a unique score
        score = hand_rank * 1000000
        for i, val in enumerate(tiebreaker):
            score += val * (100 ** (4-i))
        return score
    
    def _is_straight(self, ranks: List[int]) -> bool:
        """Check if ranks form a straight (including A-2-3-4-5)"""
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        if len(unique_ranks) < 5:
            return False
            
        # Check regular straight
        for i in range(len(unique_ranks)-4):
            if unique_ranks[i] - unique_ranks[i+4] == 4 and len(set(unique_ranks[i:i+5])) == 5:
                return True
                
        # Check A-2-3-4-5 straight
        if set(unique_ranks[-5:]) == {14, 2, 3, 4, 5}:
            return True
            
        return False
    
    def _count_ranks(self, ranks: List[int]) -> Dict[int, int]:
        """Count occurrences of each rank"""
        count = {}
        for r in ranks:
            count[r] = count.get(r, 0) + 1
        return count
    
    def _get_tiebreaker(self, rank_counts: Dict[int, int], ranks: List[int], pattern: List[int]) -> List[int]:
        """Get tiebreaker values for a given pattern"""
        tiebreaker = []
        value_map = {}
        for rank, count in rank_counts.items():
            value_map.setdefault(count, []).append(rank)
            
        for p in pattern:
            if p in value_map and value_map[p]:
                value_map[p].sort(reverse=True)
                tiebreaker.append(value_map[p].pop(0))
                
        # Fill remaining with highest kickers
        remaining = []
        for count, ranks_list in value_map.items():
            remaining.extend(ranks_list)
        remaining.sort(reverse=True)
        tiebreaker.extend(remaining)
        
        return tiebreaker[:5]
    
    def evaluate(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Evaluate best 5-card hand from 7 cards"""
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return max(self.evaluate_hand(all_cards), 1000000)  # Incomplete hand
            
        best_score = float('inf')
        # Iterate all 5-card combinations
        for combo in itertools.combinations(all_cards, 5):
            score = self.evaluate_hand(list(combo))
            if score < best_score:
                best_score = score
        return best_score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.hand_evaluator = HandEvaluator()
        self.opponent_model = {}  # Track opponent tendencies
        self.bluff_odds = 0.15    # Bluff 15% of the time
        self.pot_odds_threshold = 0.3  # Minimum pot odds to call
        self.raise_threshold = 0.7     # Equity threshold to raise
        self.all_in_threshold = 0.8    # Equity threshold to go all-in
        self.bluff_raised = False
        self.simulation_count = 50     # Number of Monte Carlo simulations
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts"""
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round"""
        # Hole cards are not provided in round_state, so we assume they remain the same
        # For real implementation, the server should provide hole cards here
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player"""
        try:
            # Get current bet information
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            our_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - our_bet
            
            # Ensure we have hole cards (should be set by server)
            if not self.hole_cards:
                return (PokerAction.FOLD, 0)
                
            # Calculate hand strength
            hand_strength = self._calculate_hand_strength(round_state)
            
            # Determine action based on game round
            if round_state.round == 'Preflop':
                action = self._preflop_strategy(round_state, hand_strength, to_call, remaining_chips)
            else:
                action = self._postflop_strategy(round_state, hand_strength, to_call, remaining_chips)
                
            return action
            
        except Exception as e:
            # Fail-safe: fold on any error
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round"""
        self.bluff_raised = False
        # Update opponent model based on actions
        for player_id, action in round_state.player_actions.items():
            if player_id not in self.opponent_model:
                self.opponent_model[player_id] = {'aggression': 0, 'total_actions': 0}
            if action in ['Raise', 'All-in']:
                self.opponent_model[player_id]['aggression'] += 1
            self.opponent_model[player_id]['total_actions'] += 1
            
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        pass
        
    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate hand equity using Monte Carlo simulations"""
        if not self.hole_card:
            return 0.0
            
        community = round_state.community_cards
        if len(community) == 0:  # Preflop
            return self._preflop_hand_strength()
            
        # Postflop equity calculation
        wins = 0
        simulations = 0
        deck = self._create_deck(self.hole_cards + community)
        
        # Determine number of opponents
        num_opponents = len(round_state.current_player) - 1
        if num_opponents <= 0:
            return 1.0
            
        for _ in range(self.simulation_count):
            # Shuffle deck
            random.shuffle(deck)
            
            # Deal remaining community cards
            simulated_community = community[:]
            needed = 5 - len(community)
            simulated_community.extend(deck[:needed])
            
            # Deal opponent hands
            opponent_hands = []
            start = needed
            for i in range(num_opponents):
                opponent_hands.append(deck[start:start+2])
                start += 2
                
            # Evaluate hands
            our_score = self.hand_evaluator.evaluate(self.hole_cards, simulated_community)
            win = True
            for opp_hand in opponent_hands:
                opp_score = self.hand_evaluator.evaluate(opp_hand, simulated_community)
                if opp_score < our_score:  # Lower score is better
                    win = False
                    break
                    
            if win:
                wins += 1
            simulations += 1
            
        return wins / simulations if simulations > 0 else 0.5
        
    def _create_deck(self, exclude_cards: List[str]) -> List[str]:
        """Create a deck excluding specified cards"""
        suits = ['s', 'h', 'd', 'c']
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        deck = [rank + suit for suit in suits for rank in ranks]
        return [card for card in deck if card not in exclude_cards]
        
    def _preflop_hand_strength(self) -> float:
        """Get preflop hand strength based on Sklansky-Chubukov rankings"""
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        r1, r2 = card1[:-1], card2[:-1]
        s1, s2 = card1[-1], card2[-1]
        
        # Sort ranks high to low
        if self.hand_evaluator.rank_values[r1] < self.hand_evaluator.rank_values[r2]:
            r1, r2 = r2, r1
            
        # Premium hands
        if r1 == 'A' and r2 == 'A': return 0.95
        if r1 == 'K' and r2 == 'K': return 0.92
        if r1 == 'A' and r2 == 'K': return 0.89
        if r1 == 'A' and r2 == 'Q': return 0.86
        if r1 == 'A' and r2 == 'J': return 0.83
        if r1 == 'K' and r2 == 'Q': return 0.80
        
        # Strong hands
        if r1 == 'A' and r2 == 'T': return 0.76
        if r1 == 'K' and r2 == 'J': return 0.73
        if r1 == 'A' and s1 == s2: return 0.70  # Suited ace
        if r1 == 'Q' and r2 == 'Q': return 0.68
        if r1 == 'K' and r2 == 'T': return 0.65
        
        # Medium hands
        if r1 == 'J' and r2 == 'J': return 0.62
        if r1 == 'A' and r2 == '9': return 0.59
        if r1 == 'K' and r2 == '9': return 0.56
        if r1 == 'Q' and r2 == 'J': return 0.53
        if r1 == 'T' and r2 == 'T': return 0.50
        
        # Weak hands
        return 0.3
        
    def _preflop_strategy(self, round_state: RoundStateClient, hand_strength: float, to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine preflop action"""
        # Position calculation (simplified)
        players_remaining = len(round_state.current_player)
        players_acting = players_remaining - 1  # Approximate position
        
        # Aggression factor based on position
        position_aggression = players_acting / players_remaining if players_remaining > 0 else 0.5
        
        # Bluff occasionally
        if random.random() < self.bluff_odds and to_call == 0:
            self.bluff_raised = True
            raise_amount = min(round_state.pot * 0.8, remaining_chips)
            return (PokerAction.RAISE, int(raise_amount))
            
        # All-in with premium hands when short-stacked
        if hand_strength > self.all_in_threshold and remaining_chips < 20 * round_state.pot:
            return (PokerAction.ALL_IN, 0)
            
        # Raising thresholds
        raise_threshold = self.raise_threshold - (position_aggression * 0.1)
        
        if to_call == 0:  # No bet to call
            if hand_strength > raise_threshold:
                raise_amount = min(round_state.pot * 0.7 + to_call, remaining_chips)
                return (PokerAction.RAISE, int(raise_amount))
            else:
                return (PokerAction.CHECK, 0)
        
        # Facing a bet
        pot_odds = to_call / (round_state.pot + to_call + 1e-9)
        
        if hand_strength > self.all_in_threshold and to_call < remaining_chips * 0.7:
            return (PokerAction.ALL_IN, 0)
            
        if hand_strength > raise_threshold:
            raise_size = min(round_state.pot * 1.2 + to_call, remaining_chips)
            return (PokerAction.RAISE, int(raise_size))
            
        if hand_strength > pot_odds + 0.1:
            return (PokerAction.CALL, 0)
            
        return (PokerAction.FOLD, 0)
        
    def _postflop_strategy(self, round_state: RoundStateClient, hand_strength: float, to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine postflop action"""
        pot = round_state.pot
        
        # Bluff occasionally when we were the aggressor preflop
        if self.bluff_raised and random.random() < self.bluff_odds:
            self.bluff_raised = False
            raise_amount = min(pot * 1.2 + to_call, remaining_chips)
            return (PokerAction.RAISE, int(raise_amount))
            
        # Pot odds calculation
        pot_odds = to_call / (pot + to_call + 1e-9)
        
        # All-in for very strong hands
        if hand_strength > self.all_in_threshold and remaining_chips < 15 * pot:
            return (PokerAction.ALL_IN, 0)
            
        # Raising thresholds
        raise_threshold = self.raise_threshold - (0.05 * (5 - len(round_state.community_cards)))
        min_raise_amount = round_state.current_bet + round_state.min_raise
        
        if to_call == 0:  # No bet to call
            if hand_strength > raise_threshold:
                raise_amount = min(pot * 0.8, remaining_chips)
                return (PokerAction.RAISE, int(raise_amount))
            else:
                return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if hand_strength > self.all_in_threshold and to_call < remaining_chips * 0.8:
            return (PokerAction.ALL_IN, 0)
            
        if hand_strength > raise_threshold:
            raise_size = min(pot * 1.0 + to_call, remaining_chips)
            raise_size = max(raise_size, min_raise_amount)
            return (PokerAction.RAISE, int(raise_size))
            
        if hand_strength > pot_odds + self.pot_odds_threshold:
            return (PokerAction.CALL, 0)
            
        return (PokerAction.FOLD, 0)