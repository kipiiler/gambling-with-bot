from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 0
        self.position = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.big_blind = blind_amount
        try:
            my_index = all_players.index(self.id)
            my_hole_cards_str = player_hands[my_index]
            self.hole_cards = my_hole_cards_str.split()
        except (ValueError, AttributeError):
            self.hole_cards = []
        
        # Determine position (simplified - not using sophisticated position tracking)
        self.position = "late"  # Default to late position

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            round_name = round_state.round
            community_cards = round_state.community_cards
            
            # Get my current bet in this round
            my_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = max(0, current_bet - my_bet)
            
            # Evaluate hand strength based on game round
            if round_name == 'Preflop':
                hand_value = self._preflop_hand_value(self.hole_cards)
            else:
                hand_value = self._postflop_hand_strength(self.hole_cards, community_cards)
            
            # Pre-flop strategy
            if round_name == 'Preflop':
                if hand_value >= 16:
                    raise_amount = min(max_raise, current_bet + min_raise * 2)
                    return (PokerAction.RAISE, raise_amount)
                elif hand_value >= 10:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif amount_to_call <= pot // 4:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Post-flop strategy
            else:
                if hand_value >= 6.0:
                    return (PokerAction.ALL_IN, 0)
                elif hand_value >= 3.0:
                    raise_amount = min(max_raise, current_bet + pot // 2)
                    return (PokerAction.RAISE, raise_amount)
                elif hand_value >= 1.0:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif amount_to_call <= pot // 5:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        except Exception:
            # Fallback to fold if any error occurs
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
    
    def _rank_to_number(self, rank_char):
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            return int(rank_char)
    
    def _get_rank_suit(self, card_str):
        return card_str[0], card_str[1]
    
    def _preflop_hand_value(self, hole_cards):
        if not hole_cards or len(hole_cards) < 2:
            return 0
        
        rank1, suit1 = self._get_rank_suit(hole_cards[0])
        rank2, suit2 = self._get_rank_suit(hole_cards[1])
        
        num1 = self._rank_to_number(rank1)
        num2 = self._rank_to_number(rank2)
        
        # Start with highest card value
        points = max(num1, num2)
        
        # Adjust for pairs
        if num1 == num2:
            points = num1 * 2
        else:
            if suit1 == suit2:
                points += 2
            if abs(num1 - num2) == 1:
                points += 2
        return points
    
    def _postflop_hand_strength(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0.0
        
        rank_count = {}
        for card in all_cards:
            rank, _ = self._get_rank_suit(card)
            num = self._rank_to_number(rank)
            rank_count[num] = rank_count.get(num, 0) + 1
        
        counts = sorted(rank_count.values(), reverse=True)
        
        if counts[0] == 4:
            return 7.0
        elif counts[0] == 3 and (len(counts) > 1 and counts[1] >= 2):
            return 6.0
        elif counts[0] == 3:
            return 3.0
        elif len(counts) > 1 and counts[0] == 2 and counts[1] == 2:
            return 2.0
        elif counts[0] == 2:
            return 1.0
        else:
            max_rank = max(rank_count.keys()) if rank_count else 0
            return min(max_rank / 14.0, 0.9)