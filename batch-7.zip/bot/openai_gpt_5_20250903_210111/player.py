import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game config/state
        self.starting_chips = 0
        self.small_blind = 5
        self.big_blind = 10
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []

        # Per-hand state
        self.hand_round_num = -1
        self.had_initiative = False
        self.was_preflop_raiser = False

        # Opponent modeling (lightweight)
        self.stats = {}  # player_id -> dict
        self.rng = random.Random()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize overall game parameters
        self.starting_chips = starting_chips
        self.small_blind = int(blind_amount) if blind_amount is not None else 5
        self.big_blind = max(2 * self.small_blind, 2)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players is not None else []

        # Seed RNG with our id to be deterministic across runs for fairness
        try:
            seed_val = int(self.id) if self.id is not None else 12345
        except Exception:
            seed_val = 12345
        self.rng.seed(seed_val)

        # Initialize simple stats for all players
        for pid in self.all_players:
            self._ensure_player_stats(pid)

        # Reset hand flags
        self._reset_hand_state()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Detect start of a new hand by round number
        if round_state is None:
            return
        if round_state.round_num != self.hand_round_num:
            self.hand_round_num = round_state.round_num
            self._reset_hand_state()

        # Very simple opponent action tracking
        try:
            for pid_str, act in (round_state.player_actions or {}).items():
                pid = self._safe_int(pid_str)
                self._ensure_player_stats(pid)
                if act:
                    act_low = act.lower()
                    self.stats[pid]['actions'] += 1
                    if act_low == 'raise':
                        self.stats[pid]['raises'] += 1
                    elif act_low == 'call':
                        self.stats[pid]['calls'] += 1
                    elif act_low == 'fold':
                        self.stats[pid]['folds'] += 1
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Safety defaults
        if round_state is None:
            return PokerAction.CHECK, 0

        EPS = 1e-9
        try:
            stage = self._stage_from_round(round_state.round)
            pot = max(int(round_state.pot), 0)
            our_bet = self._get_our_bet(round_state)
            current_bet = max(int(round_state.current_bet), 0)
            to_call = max(current_bet - our_bet, 0)
            min_raise_to = self._compute_min_raise_to(round_state)
            max_raise_to = max(int(round_state.max_raise), 0)

            # If we cannot cover a call and calling would consume all chips, we must all-in to continue
            if to_call >= max(remaining_chips, 0) and to_call > 0:
                # If we can't call fully, either fold or all-in. Favor all-in only if price is good.
                # In absence of private cards in interface, be cautious and fold multiway, shove HU sometimes.
                num_active = self._estimate_active_players(round_state)
                if num_active <= 2 and pot > 0:
                    # Short and heads-up: shove reasonably often
                    if self.rng.random() < 0.5:
                        return PokerAction.ALL_IN, 0
                # Default: fold to preserve chips
                return PokerAction.FOLD, 0

            can_check = (to_call <= 0)

            # Simple multiway tightening
            num_active = self._estimate_active_players(round_state)
            is_heads_up = (num_active <= 2)

            # Preflop strategy (without private cards available in interface)
            if stage == 'preflop':
                # If unopened pot (we can check), prefer to open-raise especially heads-up
                if can_check:
                    # Open to ~2.5-3x
                    target = max(self.big_blind * (3 if is_heads_up else 2), self.big_blind + current_bet)
                    raise_to = self._clamp_raise_to(round_state, max(min_raise_to, target), max_raise_to)
                    # Randomize opens a bit
                    if is_heads_up:
                        # Open raise most of the time heads-up
                        if raise_to > current_bet and self.rng.random() < 0.85:
                            self.was_preflop_raiser = True
                            self.had_initiative = True
                            return PokerAction.RAISE, raise_to
                        else:
                            return PokerAction.CHECK, 0
                    else:
                        # In multiway pots, open less frequently
                        if raise_to > current_bet and self.rng.random() < 0.35:
                            self.was_preflop_raiser = True
                            self.had_initiative = True
                            return PokerAction.RAISE, raise_to
                        else:
                            return PokerAction.CHECK, 0
                else:
                    # Facing an open/raise: call small, fold big; occasionally 3-bet vs small raises heads-up
                    # Use pot odds threshold
                    call_price = float(to_call)
                    call_odds = call_price / (pot + call_price + EPS) if pot + call_price > 0 else 1.0
                    threshold = 0.22 if is_heads_up else 0.15
                    # Prefer tightness if raise is large relative to BB
                    is_small_raise = (to_call <= 2.5 * self.big_blind)
                    if is_small_raise and is_heads_up and self.rng.random() < 0.08:
                        # Occasional light 3-bet
                        target = current_bet + max(self.big_blind * 3, to_call * 2)
                        raise_to = self._clamp_raise_to(round_state, max(min_raise_to, target), max_raise_to)
                        if raise_to > current_bet and raise_to > our_bet + to_call:
                            self.was_preflop_raiser = True
                            self.had_initiative = True
                            return PokerAction.RAISE, raise_to
                    # Default call/fold decision
                    if call_odds <= threshold or is_small_raise:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

            # Postflop strategy (no private cards available; rely on initiative and pot control)
            if can_check:
                # If we have initiative, continuation-bet sometimes when checked to
                if self.had_initiative and is_heads_up:
                    # Choose c-bet size around 50-60% pot
                    if self.rng.random() < (0.55 if stage == 'flop' else 0.35):
                        target_bet_size = int(0.55 * max(pot, 1))
                        # Compute raise_to to put in a bet of target_bet_size above current_bet (which is 0 here)
                        desired_raise_to = our_bet + target_bet_size
                        raise_to = self._clamp_raise_to(round_state, max(min_raise_to, desired_raise_to), max_raise_to)
                        if raise_to > current_bet and raise_to > our_bet:
                            return PokerAction.RAISE, raise_to
                # Without initiative or multiway, prefer checking
                return PokerAction.CHECK, 0
            else:
                # Facing a bet postflop: call small bets, fold to large bets; raise only rarely
                call_price = float(to_call)
                # Pot odds
                call_odds = call_price / (pot + call_price + EPS) if pot + call_price > 0 else 1.0
                # Thresholds by street and table size
                if is_heads_up:
                    base_thr = 0.33 if stage == 'flop' else (0.28 if stage == 'turn' else 0.25)
                else:
                    base_thr = 0.22 if stage == 'flop' else (0.18 if stage == 'turn' else 0.16)

                # If bet is tiny relative to pot, call very often
                tiny_bet = call_price <= max(1, 0.2 * max(pot, 1))
                if tiny_bet:
                    if self.rng.random() < 0.9:
                        return PokerAction.CALL, 0

                # If we were the aggressor and bet is modest, sometimes float/call
                if self.had_initiative and call_odds <= (base_thr + 0.05):
                    return PokerAction.CALL, 0

                # Otherwise, fold to bigger bets frequently
                if call_odds > base_thr:
                    return PokerAction.FOLD, 0

                # Rare check-raise or raise bluff heads-up on flop
                if is_heads_up and stage == 'flop' and self.rng.random() < 0.07:
                    target_raise = int(call_price + 0.9 * max(pot, 1))
                    desired_raise_to = our_bet + to_call + target_raise
                    raise_to = self._clamp_raise_to(round_state, max(min_raise_to, desired_raise_to), max_raise_to)
                    if raise_to > current_bet and raise_to > our_bet + to_call:
                        # Continue aggression flag
                        self.had_initiative = True
                        return PokerAction.RAISE, raise_to

                # Default: call within pot odds
                return PokerAction.CALL, 0

        except Exception:
            # Any unexpected issue: fall back conservatively to avoid invalid move
            # If we can check, do so; else fold if call is too expensive, otherwise call small
            try:
                our_bet = self._get_our_bet(round_state)
                current_bet = max(int(round_state.current_bet), 0)
                to_call = max(current_bet - our_bet, 0)
                pot = max(int(round_state.pot), 0)
                if to_call <= 0:
                    return PokerAction.CHECK, 0
                if to_call <= max(1, int(0.2 * max(pot, 1))):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand flags at end of round (hand)
        self._reset_hand_state()

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could log or adjust long-term strategy; keep no-op for robustness
        pass

    # ---------------- Helper methods ----------------

    def _reset_hand_state(self):
        self.had_initiative = False
        self.was_preflop_raiser = False

    def _ensure_player_stats(self, pid: int):
        if pid is None:
            return
        if pid not in self.stats:
            self.stats[pid] = {
                'actions': 0,
                'raises': 0,
                'calls': 0,
                'folds': 0
            }

    def _safe_int(self, val: Any) -> int:
        try:
            return int(val)
        except Exception:
            return 0

    def _stage_from_round(self, r: str) -> str:
        if not r:
            return 'unknown'
        rs = r.strip().lower()
        if 'pre' in rs:
            return 'preflop'
        if 'flop' == rs:
            return 'flop'
        if 'turn' == rs:
            return 'turn'
        if 'river' == rs:
            return 'river'
        # Try exact matches
        if rs in ('preflop', 'flop', 'turn', 'river'):
            return rs
        return 'unknown'

    def _get_our_bet(self, round_state: RoundStateClient) -> int:
        try:
            key = str(self.id)
            return int(round_state.player_bets.get(key, 0))
        except Exception:
            return 0

    def _compute_min_raise_to(self, round_state: RoundStateClient) -> int:
        """
        Compute a safe 'raise_to' target. Some engines define min_raise as the minimum total bet required,
        others as the minimum raise amount. We favor safety by ensuring returned value exceeds current_bet.
        """
        try:
            current_bet = max(int(round_state.current_bet), 0)
            mr = int(round_state.min_raise)
            # Ensure monotonicity: we want a 'raise_to' strictly > current_bet
            if mr <= current_bet:
                # Fall back to at least a BB over the current bet
                return current_bet + max(self.big_blind, 1)
            return mr
        except Exception:
            # Fallback: at least one big blind above current bet
            try:
                current_bet = max(int(round_state.current_bet), 0)
            except Exception:
                current_bet = 0
            return current_bet + max(self.big_blind, 1)

    def _clamp_raise_to(self, round_state: RoundStateClient, desired_raise_to: int, max_raise_to: int) -> int:
        """
        Clamp the 'raise_to' value within valid boundaries. Ensures it's greater than current bet and meets min raise.
        """
        try:
            current_bet = max(int(round_state.current_bet), 0)
            min_raise_to = self._compute_min_raise_to(round_state)
            # Respect bounds
            raise_to = max(desired_raise_to, min_raise_to)
            raise_to = min(raise_to, max_raise_to)
            # Must strictly exceed current bet to be a valid raise
            if raise_to <= current_bet:
                raise_to = min_raise_to
            if raise_to <= current_bet:
                # No valid raise possible
                return current_bet
            return raise_to
        except Exception:
            # Safe fallback: no raise
            try:
                return int(round_state.current_bet)
            except Exception:
                return 0

    def _estimate_active_players(self, round_state: RoundStateClient) -> int:
        """
        Estimate number of active (non-folded) players using player_actions if available;
        fallback to current_player list length; fallback to all_players length.
        """
        try:
            actions = round_state.player_actions or {}
            if actions:
                # Count those not explicitly folded
                active = 0
                for _, act in actions.items():
                    if act is None:
                        active += 1
                    else:
                        a = str(act).lower()
                        if a != 'fold':
                            active += 1
                if active > 0:
                    return active
            # Fallbacks
            if round_state.current_player:
                return max(len(round_state.current_player), 1)
            if self.all_players:
                return max(len(self.all_players), 1)
            return 2
        except Exception:
            return 2