from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _rank_value(card: str) -> int:
    """Return rank value 2..14 for '2'..'A'."""
    if not card or len(card) < 2:
        return 0
    r = card[0].upper()
    mapping = {
        '2': 2, '3': 3, '4': 4, '5': 5,
        '6': 6, '7': 7, '8': 8, '9': 9,
        'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
    }
    return mapping.get(r, 0)


def _suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()


def _is_suited(c1: str, c2: str) -> bool:
    return _suit(c1) != '' and _suit(c1) == _suit(c2)


def _chen_score(c1: str, c2: str) -> float:
    """Approximate Chen score for preflop two-card hand."""
    if not c1 or not c2:
        return 0.0
    r1 = _rank_value(c1)
    r2 = _rank_value(c2)
    if r1 == 0 or r2 == 0:
        return 0.0
    high = max(r1, r2)
    low = min(r1, r2)

    base_map = {14: 10.0, 13: 8.0, 12: 7.0, 11: 6.0, 10: 5.0, 9: 4.5, 8: 4.0, 7: 3.5,
                6: 3.0, 5: 2.5, 4: 2.0, 3: 1.5, 2: 1.0}
    score = base_map.get(high, 0.0)
    pair = (r1 == r2)
    if pair:
        score = max(score * 2.0, 5.0)

    suited = _is_suited(c1, c2)
    if suited:
        score += 2.0

    gap = max(0, high - low - 1)
    # Gap penalties
    if gap == 1:
        score -= 1.0
    elif gap == 2:
        score -= 2.0
    elif gap == 3:
        score -= 4.0
    elif gap >= 4:
        score -= 5.0

    # Bonus if both >= 10
    if r1 >= 10 and r2 >= 10:
        score += 1.0

    # Small bonus for A5s type (wheel potential)
    if suited and {r1, r2} == {14, 5}:
        score += 0.5

    return max(score, 0.0)


def _unique_sorted_ranks(cards: List[str]) -> List[int]:
    ranks = sorted({ _rank_value(c) for c in cards if c }, reverse=True)
    return ranks


def _count_ranks(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        rv = _rank_value(c)
        if rv == 0:
            continue
        counts[rv] = counts.get(rv, 0) + 1
    return counts


def _has_flush(cards: List[str], require_own: Optional[List[str]] = None) -> bool:
    """Return True if there is a 5+ card flush that includes at least one of our hole cards."""
    suits: Dict[str, List[str]] = {}
    for c in cards:
        s = _suit(c)
        suits.setdefault(s, []).append(c)
    for s, cs in suits.items():
        if len(cs) >= 5:
            if require_own:
                own_suited = any(_suit(c) == s for c in require_own)
                if own_suited:
                    return True
            else:
                return True
    return False


def _has_flush_draw(board: List[str], hand: List[str]) -> bool:
    """Return True if we have 4 to a flush including at least one of our hole cards."""
    suits: Dict[str, int] = {}
    for c in board + hand:
        s = _suit(c)
        if not s:
            continue
        suits[s] = suits.get(s, 0) + 1
    for s, cnt in suits.items():
        if cnt == 4 and any(_suit(h) == s for h in hand):
            return True
    return False


def _straight_windows(ranks: List[int]) -> List[List[int]]:
    """Generate windows relevant for straight detection including A as low."""
    uniq = sorted(set(ranks))
    # add Ace as low 1 if Ace present
    if 14 in uniq:
        uniq_low = sorted(set(uniq + [1]))
    else:
        uniq_low = uniq[:]

    windows = []
    # Create all 5-length windows of consecutive numbers
    seq = uniq_low
    for i in range(len(seq)):
        cur = [seq[i]]
        for j in range(i + 1, len(seq)):
            if seq[j] == cur[-1] + 1:
                cur.append(seq[j])
            elif seq[j] > cur[-1] + 1:
                # break the consecutive chain
                if len(cur) >= 2:
                    windows.append(cur[:])
                cur = [seq[j]]
            # else same number - but uniq removes dups
            if len(cur) >= 5:
                windows.append(cur[:])
        if len(cur) >= 2:
            windows.append(cur[:])
    # Filter unique windows
    uniq_windows = []
    seen = set()
    for w in windows:
        key = tuple(w)
        if key not in seen:
            uniq_windows.append(w)
            seen.add(key)
    return uniq_windows


def _has_straight(cards: List[str], require_own: Optional[List[str]] = None) -> bool:
    ranks = [_rank_value(c) for c in cards if c]
    all_windows = _straight_windows(ranks)
    for w in all_windows:
        if len(w) >= 5 and w[-1] - w[0] == len(w) - 1:
            # Must include at least one of our hole cards if require_own
            if require_own:
                own_ranks = {_rank_value(c) for c in require_own}
                # Account for Ace low as 1
                own_ranks_with_ace_low = set(own_ranks)
                if 14 in own_ranks:
                    own_ranks_with_ace_low.add(1)
                if any(r in own_ranks_with_ace_low for r in w):
                    return True
            else:
                return True
    return False


def _has_oesd(board: List[str], hand: List[str]) -> bool:
    """Open-ended straight draw detection: any 4 consecutive ranks window including at least one hole card."""
    ranks = [_rank_value(c) for c in board + hand if c]
    uniq = sorted(set(ranks))
    if 14 in uniq:
        uniq = sorted(set(uniq + [1]))
    # scan consecutive sequences of length 4
    for i in range(len(uniq) - 3):
        window = uniq[i:i + 4]
        if window[-1] - window[0] == 3:
            # check at least one of our hole cards inside window (consider A as 1)
            own_ranks = {_rank_value(c) for c in hand}
            own_ranks_low = set(own_ranks)
            if 14 in own_ranks:
                own_ranks_low.add(1)
            if any(r in own_ranks_low for r in window):
                return True
    return False


def _has_gutshot(board: List[str], hand: List[str]) -> bool:
    """Very rough gutshot detection: 4-card windows within gap 4 but not consecutive."""
    ranks = [_rank_value(c) for c in board + hand if c]
    uniq = sorted(set(ranks))
    if 14 in uniq:
        uniq = sorted(set(uniq + [1]))
    for i in range(len(uniq) - 3):
        window = uniq[i:i + 4]
        if window[-1] - window[0] == 4:
            # one missing in the middle -> gutshot potential
            own_ranks = {_rank_value(c) for c in hand}
            own_ranks_low = set(own_ranks)
            if 14 in own_ranks:
                own_ranks_low.add(1)
            if any(r in own_ranks_low for r in window):
                return True
    return False


def _hand_strength_postflop(hand: List[str], board: List[str], street: str) -> Tuple[float, Dict[str, bool]]:
    """Return (strength in 0..1, features) using simple heuristics."""
    features = {
        'pair': False,
        'two_pair': False,
        'trips': False,
        'set': False,
        'overpair': False,
        'top_pair': False,
        'second_pair': False,
        'underpair': False,
        'flush': False,
        'flush_draw': False,
        'straight': False,
        'oesd': False,
        'gutshot': False,
        'top_kicker': False
    }
    if not hand or len(hand) < 2:
        return 0.1, features

    all_cards = board + hand
    counts = _count_ranks(all_cards)
    board_counts = _count_ranks(board)
    hand_counts = _count_ranks(hand)
    board_ranks_sorted = sorted({ _rank_value(c) for c in board if c }, reverse=True)
    board_max = board_ranks_sorted[0] if board_ranks_sorted else 0
    hand_ranks = [_rank_value(c) for c in hand if c]
    high_hand = max(hand_ranks) if hand_ranks else 0
    low_hand = min(hand_ranks) if hand_ranks else 0
    pocket_pair = any(v == 2 for v in hand_counts.values())

    # Made hands
    # Flush / Straight
    features['flush'] = _has_flush(all_cards, require_own=hand)
    features['straight'] = _has_straight(all_cards, require_own=hand)
    # Draws
    features['flush_draw'] = _has_flush_draw(board, hand)
    features['oesd'] = _has_oesd(board, hand)
    features['gutshot'] = _has_gutshot(board, hand)

    # Pairs logic
    # Overpair
    if pocket_pair and board:
        pp_rank = next((r for r, cnt in hand_counts.items() if cnt == 2), 0)
        if pp_rank > board_max:
            features['overpair'] = True

    # Set / Trips
    if pocket_pair and any(board_counts.get(r, 0) >= 1 for r, cnt in hand_counts.items() if cnt == 2):
        features['set'] = True
    if any(cnt >= 3 and (r in hand_counts) for r, cnt in counts.items()):
        features['trips'] = True

    # Two pair: each hole card pairs a different board rank
    matches = [r for r in set(hand_ranks) if board_counts.get(r, 0) >= 1]
    if len(matches) >= 2:
        features['two_pair'] = True

    # Single pair detection with board
    if any(board_counts.get(r, 0) >= 1 for r in hand_ranks) or pocket_pair:
        features['pair'] = True

    # Top/Second pair
    if board:
        if any(r == board_max for r in hand_ranks):
            features['top_pair'] = True
            # Check if we have top kicker when pairing top rank not applicable; for top pair boards, kicker is other hole card
            other = low_hand if high_hand == board_max else high_hand
            if other >= 13:
                features['top_kicker'] = True
        # second highest board rank if exists
        if len(board_ranks_sorted) >= 2:
            second_high = board_ranks_sorted[1]
            if any(r == second_high for r in hand_ranks):
                features['second_pair'] = True

    # Underpair: pocket pair lower than board max
    if pocket_pair and board and not features['overpair'] and not features['set']:
        pp_rank = next((r for r, cnt in hand_counts.items() if cnt == 2), 0)
        if pp_rank < board_max:
            features['underpair'] = True

    # Strength scoring
    strength = 0.1  # baseline high-card

    if features['flush'] or features['straight']:
        strength = 0.93
    if features['set']:
        strength = max(strength, 0.88)
    if features['trips']:
        strength = max(strength, 0.78)
    if features['two_pair']:
        strength = max(strength, 0.72)
    if features['overpair']:
        strength = max(strength, 0.68)
    if features['top_pair'] and features['top_kicker']:
        strength = max(strength, 0.60)
    elif features['top_pair']:
        strength = max(strength, 0.55)
    elif features['second_pair']:
        strength = max(strength, 0.48)
    elif features['underpair'] or features['pair']:
        strength = max(strength, 0.42)

    # Draw adjustments (higher on flop, lower on turn)
    street_lower = street.lower()
    if street_lower == 'flop':
        if features['flush_draw'] and features['oesd']:
            strength = max(strength, 0.70)
        elif features['flush_draw']:
            strength = max(strength, 0.50)
        elif features['oesd']:
            strength = max(strength, 0.48)
        elif features['gutshot']:
            strength = max(strength, 0.32)
    elif street_lower == 'turn':
        if features['flush_draw'] and features['oesd']:
            strength = max(strength, 0.62)
        elif features['flush_draw']:
            strength = max(strength, 0.46)
        elif features['oesd']:
            strength = max(strength, 0.44)
        elif features['gutshot']:
            strength = max(strength, 0.28)

    return min(max(strength, 0.0), 1.0), features


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.small_blind: int = 0
        self.big_blind: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.current_hand: Optional[List[str]] = None  # our hole cards if provided
        self.round_num_seen: int = -1
        self.rng = random.Random(1337)
        self.table_size: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.small_blind = max(1, int(blind_amount))
        self.big_blind = max(2, int(self.small_blind * 2))
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.table_size = len(self.all_players) if self.all_players else 0
        # If we get our starting hand here (depends on engine), store it.
        if player_hands and len(player_hands) >= 2:
            self.current_hand = [player_hands[0], player_hands[1]]
        else:
            self.current_hand = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # If a new hand starts (Preflop and no community cards), reset any per-hand state.
        try:
            if (round_state.round_num != self.round_num_seen) and (round_state.round.lower() == 'preflop'):
                self.round_num_seen = round_state.round_num
                # We may or may not receive our hole cards elsewhere; keep current_hand if provided via on_start only.
                # Some engines may pass hole cards in other callbacks; if not provided, we play cautiously.
                # No-op for now.
        except Exception:
            # Defensive: never allow exceptions to propagate
            pass

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _call_amount(self, round_state: RoundStateClient) -> int:
        try:
            cur = int(round_state.current_bet)
            mine = self._get_my_bet(round_state)
            return max(0, cur - mine)
        except Exception:
            return 0

    def _legal_raise_amount(self, desired: int, round_state: RoundStateClient, remaining_chips: int) -> Optional[int]:
        try:
            min_r = int(max(0, round_state.min_raise))
            max_r = int(max(0, round_state.max_raise))
            upper = min(max_r, int(remaining_chips))
            if min_r <= 0 or upper < min_r:
                return None
            amt = int(max(min_r, min(desired, upper)))
            if amt < min_r or amt > upper:
                return None
            return amt
        except Exception:
            return None

    def _safe_action(self, action: PokerAction, amount: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Ensure we never return an invalid action; fallback gracefully."""
        call_amt = self._call_amount(round_state)
        can_check = (call_amt == 0)

        if action == PokerAction.CHECK:
            if can_check:
                return PokerAction.CHECK, 0
            else:
                # Fallback to CALL if affordable, else FOLD
                if call_amt > 0 and call_amt <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        if action == PokerAction.CALL:
            if call_amt == 0:
                # Calling 0 is equivalent to check
                return PokerAction.CHECK, 0
            if call_amt <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        if action == PokerAction.RAISE:
            legal = self._legal_raise_amount(amount, round_state, remaining_chips)
            if legal is not None:
                return PokerAction.RAISE, legal
            else:
                # Fallback: if can check -> CHECK; else CALL if affordable; else FOLD
                if can_check:
                    return PokerAction.CHECK, 0
                elif call_amt <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        if action == PokerAction.ALL_IN:
            # All-in is always allowed if we have chips; if 0 chips, treat as CHECK or FOLD
            if remaining_chips > 0:
                return PokerAction.ALL_IN, 0
            else:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        if action == PokerAction.FOLD:
            if can_check:
                # Prefer check over fold when free
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        # Default safety
        if can_check:
            return PokerAction.CHECK, 0
        return (PokerAction.FOLD, 0) if call_amt > remaining_chips else (PokerAction.CALL, 0)

    def _decide_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amt = self._call_amount(round_state)
        can_check = (call_amt == 0)
        pot = max(0, int(round_state.pot))
        min_r = max(0, int(round_state.min_raise))
        max_r = max(0, int(round_state.max_raise))

        # Estimate strength using Chen if we have hole cards; otherwise assume weak
        if self.current_hand and len(self.current_hand) >= 2:
            chen = _chen_score(self.current_hand[0], self.current_hand[1])
        else:
            chen = 4.0  # neutral/weak if unknown

        strong = chen >= 10.0
        medium = chen >= 7.0
        marginal = chen >= 5.5

        # If we can check (unraised pot)
        if can_check:
            # Open-raise with strong or medium+ randomly
            if strong or (medium and self.rng.random() < 0.8) or (marginal and self.rng.random() < 0.35):
                # Target 2.5-3.5x BB as raise size (raise_by, not raise_to)
                desired = int(max(self.big_blind * 2.5, 1))
                # Incorporate some pot-based sizing if pot already has blinds
                if pot > 0:
                    desired = max(desired, int(pot * 0.6))
                legal = self._legal_raise_amount(desired, round_state, remaining_chips)
                if legal is None:
                    # Try min raise
                    legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
                if legal is not None:
                    return PokerAction.RAISE, legal
                # Fallback to check if cannot raise
            return PokerAction.CHECK, 0

        # Facing a bet
        # All-in consideration if stack short relative to pot/call
        if call_amt >= remaining_chips:
            # Only go with it if very strong
            if strong:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        # Decide between fold/call/raise
        if strong:
            # 3-bet / isolate
            desired = max(min_r, int(call_amt * 2.5))
            # Cap also by some multiple of BB to avoid absurdly large early
            desired = max(desired, int(self.big_blind * 3))
            legal = self._legal_raise_amount(desired, round_state, remaining_chips)
            if legal is None:
                legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
            if legal is not None:
                return PokerAction.RAISE, legal
            # If can't raise, call
            return PokerAction.CALL, 0

        if medium:
            # Call reasonable raises; fold to huge ones
            if call_amt <= max(self.big_blind * 6, int(0.08 * remaining_chips)):
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        if marginal:
            # Call small raises cheaply, else fold
            if call_amt <= max(self.big_blind * 3, int(0.03 * remaining_chips)):
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Weak hand: overfold unless very cheap
        if call_amt <= max(self.small_blind, int(0.01 * max(1, remaining_chips))):
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def _pot_odds_call_ok(self, call_amt: int, pot: int, needed_equity: float) -> bool:
        eps = 1e-9
        return (call_amt / (pot + call_amt + eps)) <= needed_equity + 1e-6

    def _decide_postflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amt = self._call_amount(round_state)
        can_check = (call_amt == 0)
        pot = max(0, int(round_state.pot))
        min_r = max(0, int(round_state.min_raise))

        board = round_state.community_cards or []
        hand = self.current_hand if self.current_hand else []

        street = round_state.round
        strength, feats = _hand_strength_postflop(hand, board, street)

        # Determine target bet size fraction
        bet_frac = 0.0
        if strength >= 0.90:
            bet_frac = 0.85
        elif strength >= 0.75:
            bet_frac = 0.70
        elif strength >= 0.60:
            bet_frac = 0.60
        elif strength >= 0.50 and (feats.get('flush_draw') or feats.get('oesd') or feats.get('gutshot')):
            bet_frac = 0.55
        elif strength >= 0.48 and can_check:
            # marginal made hands: small protection bet
            bet_frac = 0.40

        # Semi-bluff frequency control
        if bet_frac == 0.0 and can_check and (feats.get('flush_draw') or feats.get('oesd')):
            if self.rng.random() < 0.45:
                bet_frac = 0.50

        # If we can check
        if can_check:
            if bet_frac > 0 and pot > 0:
                desired = int(max(min_r, bet_frac * pot))
                legal = self._legal_raise_amount(desired, round_state, remaining_chips)
                if legal is None:
                    legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
                if legal is not None:
                    return PokerAction.RAISE, legal
            # Otherwise take the free card
            return PokerAction.CHECK, 0

        # Facing a bet: decide call/raise/fold
        # All-in decision for very strong hands or short stacks
        if call_amt >= remaining_chips:
            if strength >= 0.80:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        # Very strong hands: raise for value
        if strength >= 0.85:
            desired = int(max(min_r, 0.8 * pot))
            legal = self._legal_raise_amount(desired, round_state, remaining_chips)
            if legal is None:
                legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
            if legal is not None:
                return PokerAction.RAISE, legal
            return PokerAction.CALL, 0

        # Strong hands: mix between call and raise
        if strength >= 0.70:
            if self.rng.random() < 0.5:
                desired = int(max(min_r, 0.6 * pot))
                legal = self._legal_raise_amount(desired, round_state, remaining_chips)
                if legal is None:
                    legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
                if legal is not None:
                    return PokerAction.RAISE, legal
            return PokerAction.CALL, 0

        # Draws: use pot odds
        if feats.get('flush_draw') or feats.get('oesd') or feats.get('gutshot'):
            # Needed equity approximation
            street_lower = street.lower()
            if feats.get('flush_draw') and feats.get('oesd'):
                need = 0.30 if street_lower == 'flop' else 0.22
            elif feats.get('flush_draw'):
                need = 0.35 if street_lower == 'flop' else 0.19
            elif feats.get('oesd'):
                need = 0.31 if street_lower == 'flop' else 0.17
            else:
                need = 0.22 if street_lower == 'flop' else 0.12  # gutshot
            if self._pot_odds_call_ok(call_amt, pot, need):
                # Occasionally semi-bluff raise
                if self.rng.random() < 0.25:
                    desired = int(max(min_r, 0.5 * pot))
                    legal = self._legal_raise_amount(desired, round_state, remaining_chips)
                    if legal is None:
                        legal = self._legal_raise_amount(min_r, round_state, remaining_chips)
                    if legal is not None:
                        return PokerAction.RAISE, legal
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Marginal made hands: call small bets, fold to large
        if strength >= 0.50:
            # Call if bet is <= 60% pot, else fold
            if pot <= 0:
                # If pot zero (edge), just call small
                return PokerAction.CALL, 0 if call_amt <= remaining_chips else (PokerAction.FOLD, 0)
            if call_amt <= 0.60 * pot:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Weak hand: bluff sometimes if bet small and on flop
        if round_state.round.lower() == 'flop' and call_amt <= 0.25 * max(1, pot) and self.rng.random() < 0.12:
            desired = int(max(min_r, 0.5 * pot))
            legal = self._legal_raise_amount(desired, round_state, remaining_chips)
            if legal is not None:
                return PokerAction.RAISE, legal

        # Otherwise fold or call if very small
        if call_amt <= max(self.small_blind, int(0.01 * max(1, remaining_chips))):
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Attempt to keep current_hand updated if engine leaks it via on_start only; if None, we proceed with robust defaults.
            stage = (round_state.round or '').lower()

            # Decision branch by stage
            if stage == 'preflop':
                action, amount = self._decide_preflop(round_state, remaining_chips)
            else:
                action, amount = self._decide_postflop(round_state, remaining_chips)

            # Validate and sanitize before returning
            return self._safe_action(action, amount, round_state, remaining_chips)
        except Exception:
            # Absolute safety: never crash, default to safe action
            call_amt = self._call_amount(round_state)
            if call_amt == 0:
                return PokerAction.CHECK, 0
            if call_amt <= remaining_chips:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Clear per-hand reads; we don't carry results into next hand except bankroll.
        self.current_hand = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally, we could adapt strategy here; for now, no-op to remain deterministic/stable.
        pass