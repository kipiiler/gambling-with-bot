from typing import List, Tuple, Optional, Dict, Any
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.current_hole_cards: Optional[List[str]] = None
        self.rng = random.Random()
        self.hand_history: List[Dict[str, Any]] = []
        self.round_num: int = 0
        self.last_round_num: int = -1

        # Rank mapping utilities
        self.RANKS = "23456789TJQKA"
        self.RANK_TO_VAL = {r: i + 2 for i, r in enumerate(self.RANKS)}
        self.RANK_TO_VAL["10"] = 10  # handle '10' format if used

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount if isinstance(blind_amount, int) else 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players is not None else []
        self.current_hole_cards = None  # will update per round if available
        # Seed RNG with a combination of players and blinds for determinism across runs
        seed_val = starting_chips + blind_amount + len(self.all_players)
        if self.id is not None:
            seed_val += int(self.id)
        self.rng.seed(seed_val)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand state
        self.round_num = getattr(round_state, "round_num", self.last_round_num + 1)
        self.current_hole_cards = self._extract_my_hole_cards(round_state)
        self.last_round_num = self.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Defensive defaults
            my_bet = self._get_my_bet(round_state)
            current_bet = getattr(round_state, "current_bet", 0) or 0
            pot = getattr(round_state, "pot", 0) or 0
            min_raise = getattr(round_state, "min_raise", 0) or 0
            max_raise = getattr(round_state, "max_raise", 0) or 0
            community_cards = getattr(round_state, "community_cards", []) or []
            can_raise = min_raise > 0 and max_raise >= min_raise

            call_amount = max(0, current_bet - my_bet)
            is_check_allowed = call_amount == 0

            # Compute strength estimate
            hole = self.current_hole_cards
            preflop = (len(community_cards) == 0)
            if hole and len(hole) == 2:
                preflop_strength = self._preflop_strength(hole)
                if preflop:
                    equity = preflop_strength
                else:
                    equity = self._postflop_equity_estimate(hole, community_cards)
            else:
                # If hole cards unknown, use conservative defaults
                if preflop:
                    equity = 0.33
                else:
                    # Slightly lower if we can't see our cards postflop
                    equity = 0.30

            # Draw detection for marginal calls
            draws = self._draw_info(hole, community_cards)
            flush_draw = draws.get("flush_draw", False)
            oesd = draws.get("oesd", False)
            gutshot = draws.get("gutshot", False)

            # Pot odds for call decisions
            denom = pot + call_amount
            pot_odds = (call_amount / (denom + 1e-9)) if call_amount > 0 else 0.0

            # Aggression thresholds
            very_strong = equity >= 0.78
            strong = equity >= 0.65
            medium = equity >= 0.5
            marginal_draw = (flush_draw or oesd or gutshot)

            # Action logic with strict validity checks
            if is_check_allowed:
                # No bet to call
                if preflop:
                    if very_strong and can_raise:
                        return (PokerAction.RAISE, self._safe_raise_amount(min_raise, max_raise))
                    elif strong and can_raise and self.rng.random() < 0.35:
                        return (PokerAction.RAISE, self._safe_raise_amount(min_raise, max_raise))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if very_strong and can_raise:
                        return (PokerAction.RAISE, self._safe_raise_amount(min_raise, max_raise))
                    elif strong and can_raise and self.rng.random() < 0.30:
                        return (PokerAction.RAISE, self._safe_raise_amount(min_raise, max_raise))
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                # If the call would put us all-in, decide carefully
                if call_amount >= remaining_chips:
                    # Only go with it with reasonably strong equity
                    if equity >= 0.60:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)

                # Consider raises when very strong
                if very_strong:
                    if can_raise:
                        # Keep it simple: minimum valid raise
                        raise_amt = self._safe_raise_amount(min_raise, max_raise)
                        if raise_amt >= min_raise:
                            return (PokerAction.RAISE, raise_amt)
                    # If can't raise, call
                    return (PokerAction.CALL, 0)

                # Pot odds call
                # Add a small edge threshold to account for multiway and rake-like dynamics
                if equity >= pot_odds + 0.07:
                    return (PokerAction.CALL, 0)

                # Semi-bluff with draws occasionally if can raise and not too expensive
                if marginal_draw and can_raise and self.rng.random() < 0.15 and call_amount < max(remaining_chips * 0.15, 50):
                    raise_amt = self._safe_raise_amount(min_raise, max_raise)
                    if raise_amt >= min_raise:
                        return (PokerAction.RAISE, raise_amt)

                # Call small bets with decent hands/draws
                if (medium or marginal_draw) and call_amount <= max(remaining_chips * 0.08, 30):
                    return (PokerAction.CALL, 0)

                # Otherwise fold
                return (PokerAction.FOLD, 0)

        except Exception:
            # Fail-safe: never crash; fold safely
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track simple round result for potential future adjustments (not used aggressively to avoid overfitting)
        try:
            pot = getattr(round_state, "pot", 0) or 0
            self.hand_history.append(
                {
                    "round_num": getattr(round_state, "round_num", None),
                    "pot": pot,
                    "remaining_chips": remaining_chips,
                }
            )
        except Exception:
            pass
        finally:
            self.current_hole_cards = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent state needed; just ensure no exceptions
        return

    # -------------- Helper Methods --------------

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            bets = getattr(round_state, "player_bets", {}) or {}
            # Try string key first
            if self.id is None:
                # No id known, try fallback (sum of values / players?) -> default 0
                return 0
            sid = str(self.id)
            if sid in bets:
                return int(bets[sid])
            # Try raw int key
            if self.id in bets:
                return int(bets[self.id])
        except Exception:
            pass
        return 0

    def _safe_raise_amount(self, min_raise: int, max_raise: int) -> int:
        # Choose a conservative raise amount within bounds (min_raise)
        if min_raise <= 0 or max_raise < min_raise:
            return 0
        return int(min_raise)

    def _extract_my_hole_cards(self, round_state: RoundStateClient) -> Optional[List[str]]:
        # Try to obtain my current hole cards from round_state if present
        try:
            # Common patterns
            if hasattr(round_state, "player_hands"):
                ph = getattr(round_state, "player_hands")
                if isinstance(ph, dict):
                    # Keys might be strings or ints
                    if self.id is not None:
                        sid = str(self.id)
                        if sid in ph and isinstance(ph[sid], list) and len(ph[sid]) >= 2:
                            return [str(ph[sid][0]), str(ph[sid][1])]
                        if self.id in ph and isinstance(ph[self.id], list) and len(ph[self.id]) >= 2:
                            return [str(ph[self.id][0]), str(ph[self.id][1])]
                elif isinstance(ph, list):
                    # Might align with all_players order
                    if self.all_players and self.id in self.all_players:
                        idx = self.all_players.index(self.id)
                        if 0 <= idx < len(ph):
                            cards = ph[idx]
                            if isinstance(cards, list) and len(cards) >= 2:
                                return [str(cards[0]), str(cards[1])]
            # Some servers may pass hole cards in RoundStateClient as "hand" or "hole_cards"
            for attr in ["hand", "hole_cards", "my_cards"]:
                if hasattr(round_state, attr):
                    cards = getattr(round_state, attr)
                    if isinstance(cards, list) and len(cards) >= 2:
                        return [str(cards[0]), str(cards[1])]
        except Exception:
            pass
        return None

    def _parse_card(self, card: str) -> Tuple[int, str]:
        # Accept formats like 'Ah', 'Ks', '3d', '10c', 'Td'
        c = card.strip()
        if len(c) < 2:
            return (0, "")
        suit = c[-1].lower()
        rank_str = c[:-1].upper()
        if rank_str == "T":
            rank = 10
        else:
            rank = self.RANK_TO_VAL.get(rank_str, 0)
        return (rank, suit)

    def _preflop_strength(self, hole: List[str]) -> float:
        # Approximate Chen-like scoring for preflop strength, scaled to [0,1]
        try:
            r1, s1 = self._parse_card(hole[0])
            r2, s2 = self._parse_card(hole[1])
            if r1 < r2:
                r1, r2 = r2, r1
                s1, s2 = s2, s1
            suited = (s1 == s2)
            pair = (r1 == r2)
            gap = max(0, r1 - r2 - 1)

            if pair:
                # Pair baseline
                base = 20.0 + (r1 - 2) * 0.8  # 22 ~ 20.0, AA ~ 30.4
                score = base
            else:
                score = float(r1) + 0.5 * float(r2)  # high card weighted
                if suited:
                    score += 2.0
                # Gap penalty
                score -= 2.0 * gap
                # Small connectors slight bonus
                if gap == 0:
                    score += 1.0
                # Low ranks penalty
                if r1 < 10 and r2 < 10:
                    score -= 1.5

            # Clip and scale
            score = max(0.0, min(score, 32.0))
            strength = score / 32.0
            # Slight bump for premium pairs
            if pair and r1 >= 11:
                strength = min(1.0, strength + 0.05)
            return float(max(0.0, min(1.0, strength)))
        except Exception:
            return 0.33

    def _postflop_equity_estimate(self, hole: List[str], board: List[str]) -> float:
        # Compute a coarse equity estimate based on made hand category and common draws
        try:
            ranks_all, suits_all = self._ranks_suits(hole + board)
            counts = self._rank_counts(ranks_all)
            suits_count = self._suit_counts(suits_all)

            has_flush, flush_suit = self._has_flush(suits_count, hole, board)
            has_straight, straight_high = self._has_straight(set(ranks_all))
            quads = any(v == 4 for v in counts.values())
            trips = any(v == 3 for v in counts.values())
            pairs = [r for r, v in counts.items() if v == 2]
            two_pair = len(pairs) >= 2
            pair = len(pairs) >= 1
            full_house = trips and (len(pairs) >= 1 or any(v == 3 for r, v in counts.items() if v == 3 and r != max([rk for rk, v in counts.items() if v == 3], default=0)))

            # Determine if our hole cards meaningfully contribute
            hole_ranks = [self._parse_card(c)[0] for c in hole]
            board_ranks = [self._parse_card(c)[0] for c in board]
            board_max = max(board_ranks) if board_ranks else 0
            pocket_pair = (hole_ranks[0] == hole_ranks[1])

            # Board pair and use of hole cards
            using_hole_pair = any(counts.get(hr, 0) >= 2 for hr in hole_ranks)
            using_hole_trips = any(counts.get(hr, 0) >= 3 for hr in hole_ranks)
            using_hole_two_pair = sum(1 for hr in set(hole_ranks) if counts.get(hr, 0) >= 2) >= 1

            # Top pair / overpair determination
            top_pair = False
            overpair = False
            if len(board_ranks) >= 3:
                if pair:
                    # top pair if we paired highest board rank with a hole card
                    if board_ranks:
                        highest_board = max(board_ranks)
                        top_pair = (highest_board in hole_ranks) and (counts.get(highest_board, 0) >= 2)
                if pocket_pair and hole_ranks[0] > board_max:
                    overpair = True

            # Flush draw and straight draw detection
            draw_info = self._draw_info(hole, board)
            flush_draw = draw_info.get("flush_draw", False)
            oesd = draw_info.get("oesd", False)
            gutshot = draw_info.get("gutshot", False)

            # Category-to-equity heuristic
            if quads:
                return 0.99
            if has_straight and has_flush:
                # Not necessarily straight flush; but extremely strong if both made
                return 0.97
            if full_house:
                return 0.95
            if has_flush:
                return 0.90
            if has_straight:
                return 0.86
            if trips:
                return 0.80 if using_hole_trips else 0.68
            if two_pair:
                return 0.76 if using_hole_two_pair else 0.62
            if overpair:
                return 0.68
            if top_pair:
                kicker = max(hole_ranks) if board_ranks and (max(board_ranks) in hole_ranks) else max(hole_ranks)
                if kicker >= 11:
                    return 0.60
                else:
                    return 0.56
            if pair:
                return 0.54 if using_hole_pair else 0.38
            # Draws
            if flush_draw and oesd:
                return 0.46
            if flush_draw:
                return 0.38
            if oesd:
                return 0.36
            if gutshot:
                return 0.28
            # High card evaluation
            hi = max(hole_ranks) if hole_ranks else 0
            if hi >= 14:
                return 0.25
            if hi >= 13:
                return 0.22
            return 0.18
        except Exception:
            return 0.35

    def _ranks_suits(self, cards: List[str]) -> Tuple[List[int], List[str]]:
        ranks = []
        suits = []
        for c in cards:
            r, s = self._parse_card(c)
            if r > 0 and s != "":
                ranks.append(r)
                suits.append(s)
        return ranks, suits

    def _rank_counts(self, ranks: List[int]) -> Dict[int, int]:
        d: Dict[int, int] = {}
        for r in ranks:
            d[r] = d.get(r, 0) + 1
        return d

    def _suit_counts(self, suits: List[str]) -> Dict[str, int]:
        d: Dict[str, int] = {}
        for s in suits:
            d[s] = d.get(s, 0) + 1
        return d

    def _has_flush(self, suit_counts: Dict[str, int], hole: List[str], board: List[str]) -> Tuple[bool, Optional[str]]:
        for s, cnt in suit_counts.items():
            if cnt >= 5:
                return True, s
        return False, None

    def _has_straight(self, unique_ranks: set) -> Tuple[bool, Optional[int]]:
        if not unique_ranks:
            return False, None
        rks = sorted(unique_ranks)
        # Handle A as low (1) for A-2-3-4-5
        if 14 in unique_ranks:
            rks = sorted(unique_ranks | {1})
        best = 1
        cur = 1
        best_high = None
        rks_sorted = sorted(rks)
        for i in range(1, len(rks_sorted)):
            if rks_sorted[i] == rks_sorted[i - 1] + 1:
                cur += 1
                if cur >= 5:
                    best = cur
                    best_high = rks_sorted[i]
            else:
                cur = 1
        return (best >= 5, best_high)

    def _draw_info(self, hole: Optional[List[str]], board: List[str]) -> Dict[str, bool]:
        try:
            ranks_all, suits_all = self._ranks_suits((hole or []) + board)
            suit_counts = self._suit_counts(suits_all)
            flush_draw = any(cnt == 4 for cnt in suit_counts.values())

            # Straight draw detection: OESD or gutshot across 7 cards
            unique = sorted(set(ranks_all))
            # Ace low handling
            if 14 in unique:
                unique_with_ace_low = sorted(set(unique) | {1})
            else:
                unique_with_ace_low = unique[:]

            def straight_gaps(rlist: List[int]) -> Tuple[bool, bool]:
                if not rlist:
                    return (False, False)
                rlist = sorted(set(rlist))
                oe = False
                gut = False
                # Check 5-length windows and count gaps
                for i in range(len(rlist)):
                    window = []
                    curr = rlist[i]
                    window.append(curr)
                    for j in range(i + 1, len(rlist)):
                        if rlist[j] == curr + 1:
                            curr = rlist[j]
                            window.append(curr)
                        elif rlist[j] > curr + 1:
                            break
                        if len(window) >= 5:
                            break
                    # Already a straight
                    if len(window) >= 5:
                        oe = True
                        break
                # OESD/gutshot estimation by looking for 4 cards in a 5-rank span with 1 gap
                # Evaluate every 5-card span from 1..14
                present = set(rlist)
                for start in range(1, 11):
                    span = {start + k for k in range(5)}
                    have = len(span & present)
                    if have == 4:
                        # If missing interior card -> gutshot; if missing at ends -> OESD
                        missing = list(span - present)
                        if missing:
                            m = missing[0]
                            if m == start or m == start + 4:
                                oe = True
                            else:
                                gut = True
                return (oe, gut)

            oe1, gut1 = straight_gaps(unique)
            oe2, gut2 = straight_gaps(unique_with_ace_low)
            oesd = oe1 or oe2
            gutshot = gut1 or gut2
            return {"flush_draw": flush_draw, "oesd": oesd, "gutshot": gutshot}
        except Exception:
            return {"flush_draw": False, "oesd": False, "gutshot": False}