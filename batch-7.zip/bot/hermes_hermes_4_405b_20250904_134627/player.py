from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.blind_amount = 0
        self.strong_hand_set = {
            'AA', 'KK', 'QQ', 'JJ', 'TT', '99', '88',
            'AKs', 'AQs', 'AJs', 'ATs', 'KQs',
            'AK', 'AQ', 'AJ', 'AT'
        }
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
            '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            idx = all_players.index(self.id)
            hand_str = player_hands[idx]
            self.hole_cards = [hand_str[:2], hand_str[2:]]
        except (ValueError, IndexError):
            self.hole_cards = None
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if self.hole_cards is None:
                return PokerAction.FOLD, 0

            if round_state.round == 'Preflop':
                return self._preflop_action(round_state, remaining_chips)
            else:
                return self._postflop_action(round_state, remaining_chips)
        except Exception:
            return PokerAction.FOLD, 0

    def _preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hand_str = self._get_hand_string(self.hole_cards)
        if hand_str in self.strong_hand_set:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            if amount_to_call > 0:
                return PokerAction.CALL, 0
            else:
                min_raise = max(round_state.min_raise, 2 * self.blind_amount)
                if min_raise > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(min_raise, remaining_chips)
        else:
            return PokerAction.FOLD, 0

    def _postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self._has_at_least_pair(self.hole_cards, round_state.community_cards):
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            if amount_to_call > 0:
                if amount_to_call <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            else:
                return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _get_hand_string(self, hole_cards: List[str]) -> str:
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        r1_val = self.rank_map[rank1]
        r2_val = self.rank_map[rank2]
        
        if r1_val > r2_val:
            higher, lower = rank1, rank2
        else:
            higher, lower = rank2, rank1
        
        suited = suit1 == suit2
        return higher + lower + ('s' if suited else '')

    def _has_at_least_pair(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        all_cards = hole_cards + community_cards
        ranks = []
        for card in all_cards:
            rank_char = card[0]
            ranks.append(self.rank_map[rank_char])
        
        from collections import Counter
        count = Counter(ranks)
        return any(v >= 2 for v in count.values())

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass