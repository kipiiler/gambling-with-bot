from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.ranks = "23456789TJQKA"
        self.suits = "shdc"
        self.rank_map = {r: i for i, r in enumerate(self.ranks)}
    
    def canonical_hand(self, hand: List[str]) -> str:
        if len(hand) != 2:
            return ""
        card1, card2 = hand
        r1 = card1[0]
        r2 = card2[0]
        s1 = card1[1]
        s2 = card2[1]
        
        r1_val = self.rank_map[r1]
        r2_val = self.rank_map[r2]
        
        if r1_val > r2_val:
            primary = card1
            secondary = card2
        elif r1_val < r2_val:
            primary = card2
            secondary = card1
        else:
            primary = card1
            secondary = card2
        
        suited = (s1 == s2)
        suffix = 's' if suited else 'o'
        
        if r1_val == r2_val:
            return primary[0] + secondary[0]
        else:
            return primary[0] + secondary[0] + suffix

    def eval_hand(self, hand: List[str], community: List[str]) -> int:
        all_cards = hand + community
        if len(all_cards) < 5:
            return 0
        best_score = 0
        for combo in itertools.combinations(all_cards, 5):
            score = self.evaluate_combo(combo)
            if score > best_score:
                best_score = score
        return best_score

    def evaluate_combo(self, combo: Tuple[str]) -> int:
        ranks = []
        suits = []
        for card in combo:
            rank_char = card[0]
            suit_char = card[1]
            rank_val = self.rank_map[rank_char]
            ranks.append(rank_val)
            suits.append(suit_char)
        
        ranks.sort()
        unique_ranks = sorted(list(set(ranks)))
        flush = len(set(suits)) == 1
        straight = False
        high_card = 0
        
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    straight = True
                    high_card = unique_ranks[i+4]
                    break
            if not straight and set(unique_ranks).issuperset([0, 1, 2, 3, 12]):  # Ace-low straight
                straight = True
                high_card = 3  # 5-high straight
        
        from collections import Counter
        count = Counter(ranks)
        counts = sorted(count.values(), reverse=True)
        if straight and flush:
            if high_card == 12:  # Royal flush
                return 900000
            else:
                return 800000 + high_card
        elif counts[0] == 4:
            quad_rank = [r for r, c in count.items() if c == 4][0]
            kicker = [r for r in ranks if r != quad_rank][0]
            return 700000 + quad_rank * 100 + kicker
        elif counts[0] == 3 and counts[1] == 2:
            trip_rank = [r for r, c in count.items() if c == 3][0]
            pair_rank = [r for r, c in count.items() if c == 2][0]
            return 600000 + trip_rank * 100 + pair_rank
        elif flush:
            return 500000 + max(ranks)
        elif straight:
            return 400000 + high_card
        elif counts[0] == 3:
            trip_rank = [r for r, c in count.items() if c == 3][0]
            kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)[:2]
            return 300000 + trip_rank * 1000 + kickers[0] * 100 + kickers[1]
        elif counts[0] == 2 and counts[1] == 2:
            pairs = sorted([r for r, c in count.items() if c == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return 200000 + pairs[0] * 1000 + pairs[1] * 100 + kicker
        elif counts[0] == 2:
            pair_rank = [r for r, c in count.items() if c == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
            return 100000 + pair_rank * 1000 + kickers[0] * 100 + kickers[1] * 10 + kickers[2]
        else:
            return max(ranks)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        my_index = all_players.index(self.id)
        hand_str = player_hands[my_index]
        self.hand = [hand_str[:2], hand_str[2:4]]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            
            if round_state.round == "Preflop":
                canonical = self.canonical_hand(self.hand)
                premium = {'AA', 'KK', 'QQ', 'JJ', 'AKs', 'AK'}
                strong = {'TT', 'AQs', 'AQ', 'AJs', 'KQs'}
                medium = {'ATs', 'AT', 'KQ', 'KJs', 'QJs', 'JTs', 'T9s', '99', '88', '77'}
                
                if canonical in premium:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.RAISE, round_state.min_raise)
                elif canonical in strong:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif canonical in medium:
                    if amount_to_call == 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                hand_score = self.eval_hand(self.hand, round_state.community_cards)
                if hand_score >= 700000:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.RAISE, round_state.min_raise)
                elif hand_score >= 600000:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.RAISE, round_state.min_raise)
                elif hand_score >= 500000:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_score >= 400000:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_score >= 300000:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-5)
                        if pot_odds < 0.2:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif hand_score >= 200000:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-5)
                        if pot_odds < 0.25:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif hand_score >= 100000:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-5)
                        if pot_odds < 0.3:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass