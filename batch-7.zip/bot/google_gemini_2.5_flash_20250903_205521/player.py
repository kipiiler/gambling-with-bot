from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = -1
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []

        # Card ranks for strength calculation (2-14, where Ace is 14)
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        self.suit_map = {
            'h': 0, 'd': 1, 'c': 2, 's': 3
        }

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        # player_hands are the hole cards for the current bot.
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards at the start of a new round
        # The game engine implicitly sends new hole cards with the "Game Start" message
        # and on_start is called. on_round_start is for subsequent rounds (Flop, Turn, River)
        # where hole cards don't change.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Ensure correct type for player_bets keys if they are strings
        player_id_str = str(self.player_id)
        current_player_bet = round_state.player_bets.get(player_id_str, 0)
        
        # Sanity check for hole cards
        if not self.hole_cards or len(self.hole_cards) < 2:
            return PokerAction.FOLD, 0

        # Calculate hand strength
        strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic strategy:
        # Pre-flop:
        #   - Premium hands (AA, KK, QQ, AKs): Raise
        #   - Medium hands (JJ, TT, AQ, KQ, suited connectors): Call/Small Raise
        #   - Weak hands: Fold or check if no bet
        # Post-flop:
        #   - Strong hands: Bet/Raise
        #   - Medium hands: Check/Call
        #   - Weak hands: Fold or check

        if round_state.round == PokerRound.PREFLOP.name:
            card1_rank = self.rank_map.get(self.hole_cards[0][:-1], 0)
            card2_rank = self.rank_map.get(self.hole_cards[1][:-1], 0)
            is_suited = self.hole_cards[0][-1] == self.hole_cards[1][-1]
            is_pair = card1_rank == card2_rank

            # Premium hands
            if (is_pair and card1_rank >= self.rank_map['Q']) or \
               (card1_rank == self.rank_map['A'] and card2_rank == self.rank_map['K'] and is_suited):
                # Aggressive play: Raise high
                raise_amount = min(max_raise, min_raise * 2) 
                if remaining_chips >= current_bet_to_match + raise_amount and raise_amount > 0:
                    return PokerAction.RAISE, raise_amount
                elif remaining_chips >= current_bet_to_match:
                    return PokerAction.CALL, current_bet_to_match  # If cannot raise, call
                else:
                    return PokerAction.ALL_IN, 0 # Push if pot is attractive and we have a monster
            # Medium hands
            elif (is_pair and card1_rank >= self.rank_map['8']) or \
                 (card1_rank >= self.rank_map['Q'] and card2_rank >= self.rank_map['T']) or \
                 (card1_rank >= self.rank_map['T'] and card2_rank >= self.rank_map['T'] and is_suited) or \
                 (abs(card1_rank - card2_rank) == 1 and max(card1_rank, card2_rank) >= self.rank_map['8'] and is_suited): # Suited connectors 89s+
                
                # Check if it's possible to raise, if not, call, if not, check.
                if current_bet_to_match == 0:  # No bet yet, can raise or check
                    raise_amount = min_raise 
                    if remaining_chips >= raise_amount:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                elif remaining_chips >= current_bet_to_match:
                    return PokerAction.CALL, current_bet_to_match
                else:
                    return PokerAction.FOLD, 0  # Cannot afford to call, fold
            # Weak hands
            else:
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        else:  # Flop, Turn, River
            # Simple post-flop strategy:
            # If we have a strong hand (pair or better), consider raising or betting.
            # If we have a drawing hand, consider calling or checking.
            # Otherwise, fold if facing a bet, or check.

            if strength >= 3:  # Corresponds to a pair or better in a 0-6 scale (placeholder for actual hand ranking)
                if current_bet_to_match == 0:
                    # Bet 1/2 to 3/4 pot
                    bet_amount = int(round_state.pot * 0.6) 
                    bet_amount = max(bet_amount, min_raise)  # Ensure bet is at least min_raise
                    if bet_amount > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, bet_amount
                elif remaining_chips >= current_bet_to_match:
                    # Re-raise or call
                    raise_amount = min(max_raise, current_bet_to_match + min_raise)
                    if remaining_chips >= raise_amount:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CALL, current_bet_to_match
                else:
                    return PokerAction.ALL_IN, 0 # All-in if current bet is less than remaining chips
            elif strength >= 1: # Some form of high card or weaker pair
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif remaining_chips >= current_bet_to_match:
                    return PokerAction.CALL, current_bet_to_match
                else:
                    return PokerAction.ALL_IN, 0 # All-in if current bet is very small
            else:  # No hand or very weak hand
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
                    
    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """
        Calculates a simplified hand strength score.
        This is a placeholder and should be replaced by a proper poker hand evaluator.
        For now, it returns:
        6: Two pair or better (very strong)
        5: One pair (strong)
        4: High card (medium)
        3: Suited cards, connectors (potential)
        2: Unsuited connectors, high cards (some potential)
        1: Trash (no potential)
        0: Default/error
        """
        all_cards = hole_cards + community_cards
        
        # If there aren't enough cards to form a hand (e.g., pre-flop), use hole cards only
        if len(all_cards) < 5:
            # Pre-flop or early street hand strength logic
            if len(hole_cards) != 2:
                return 0 # Should always have 2 hole cards
            
            card1_rank = self.rank_map.get(hole_cards[0][:-1], 0)
            card2_rank = self.rank_map.get(hole_cards[1][:-1], 0)
            is_suited = hole_cards[0][-1] == hole_cards[1][-1]
            is_pair = card1_rank == card2_rank

            if is_pair:
                if card1_rank >= self.rank_map['A']: return 6 # AA
                if card1_rank >= self.rank_map['K']: return 6 # KK
                if card1_rank >= self.rank_map['Q']: return 6 # QQ
                if card1_rank >= self.rank_map['J']: return 5 # JJ
                if card1_rank >= self.rank_map['T']: return 5 # TT
                return 4 # Other pairs

            if is_suited:
                if card1_rank >= self.rank_map['A'] and card2_rank >= self.rank_map['K']: return 6 # AKs
                if card1_rank >= self.rank_map['A'] and card2_rank >= self.rank_map['Q']: return 5 # AQs
                if card1_rank >= self.rank_map['K'] and card2_rank >= self.rank_map['Q']: return 5 # KQs
                if abs(card1_rank - card2_rank) <= 1 and max(card1_rank, card2_rank) >= self.rank_map['J']: return 5 # Suited broadway connectors e.g., QJs
                if abs(card1_rank - card2_rank) <= 2 and max(card1_rank, card2_rank) >= self.rank_map['T']: return 4 # Suited connectors with gap
                return 3 # Generic suited (potential flush draw)
            
            # Non-suited hands
            if card1_rank >= self.rank_map['A'] and card2_rank >= self.rank_map['K']: return 5 # AKo
            if card1_rank >= self.rank_map['A'] and card2_rank >= self.rank_map['Q']: return 4 # AQo
            if card1_rank >= self.rank_map['K'] and card2_rank >= self.rank_map['Q']: return 4 # KQo
            if max(card1_rank, card2_rank) >= self.rank_map['J'] and min(card1_rank, card2_rank) >= self.rank_map['9']: return 3 # High unsuited cards
            
            if abs(card1_rank - card2_rank) <= 1 and max(card1_rank, card2_rank) >= self.rank_map['T']: return 3 # Unsuited connectors
            
            return 1 # Weakest 
        
        # Post-flop hand strength (simple evaluation)
        # This is a very rudimentary hand evaluator. For a real bot, you'd use a robust library.
        ranks = [self.rank_map[card[:-1]] for card in all_cards]
        suits = [card[-1] for card in all_cards]

        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}

        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for numbers of pairs and three-of-a-kind
        num_pairs = sum(1 for count in rank_counts.values() if count == 2)
        num_trips = sum(1 for count in rank_counts.values() if count == 3)
        has_quads = any(count == 4 for count in rank_counts.values())

        if has_quads: return 6 # Four of a kind
        if num_trips >= 1 and num_pairs >= 1: return 6 # Full House
        if is_flush: return 5 # Flush (Need to check for straight flush too, but simple for now)

        # Check for straight (very basic, needs improvement)
        sorted_ranks = sorted(list(set(ranks)))
        is_straight = False
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    is_straight = True
                    break
        if is_straight: return 5 # Straight
        
        if num_trips >= 1: return 4 # Three of a kind
        if num_pairs >= 2: return 4 # Two Pair
        if num_pairs >= 1: return 3 # One Pair
        
        return 1 # High Card or worse

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []  # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass