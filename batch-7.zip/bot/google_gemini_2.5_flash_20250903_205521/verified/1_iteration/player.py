from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.player_id = None

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id
        super().set_id(player_id)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands contains only our hands, so we need to store it
        # However, player_hands is a list of strings, so it's likely a misnomer
        # The hole cards are typically provided in on_round_start or get_action
        # This parameter seems designed for a scenario where hands are distributed at game start,
        # but in Hold'em, they are per-round.
        # We will assume get_action or on_round_start will provide the hole cards.
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Hole cards are not given here, but should be available via get_action.
        # This method is good for resetting per-round state if necessary.
        # We already get player_hands in get_action, so no need to store here.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Hole cards are provided here within the round_state for the current player
        # We assume our hole cards are accessed via `round_state.player_hands[str(self.player_id)]`
        # However, the RoundStateClient definition doesn't include player_hands.
        # This is a critical missing piece. We will assume the bot framework
        # will provide player-specific hole cards in some way, or assume
        # contextually they are known to the bot when get_action is called.
        # For competitive programming, usually player-specific data like hole cards
        # are explicitly passed or available. Given the template, it's likely
        # they are implicitly known or available through a different mechanism not
        # shown in the RoundStateClient definition (e.g., as part of the Bot instance).
        # Let's assume for now that if player_hands is part of on_start, it's effectively
        # a placeholder and real hole cards come through a different mechanism.
        # If not, this bot will just play based on community cards and general strategy.

        # ***Critical Assumption for Hole Cards:***
        # The prompt says `player_hands: List[str]` to `on_start`. This implies hands are shared.
        # BUT typical poker bots only know *their own* hole cards.
        # Since `RoundStateClient` doesn't have `player_hands`, I will assume that the actual
        # hole cards for *this player* are passed to the `get_action` method,
        # or that a mechanism exists to retrieve them, e.g., `self.hole_cards` would be set
        # by the framework, or implicitly available.
        # Since the `Bot` class itself does not have `hole_cards` property, I will have to
        # use a dummy strategy if hole cards cannot be accessed.

        # Let's check `self.id` which should be set by the framework.
        # No, the `player_hands` in `on_start` is likely ALL players' hands if known,
        # or it's a placeholder. The standard way is for `get_action` to implicitly
        # have knowledge of *your own* hole cards when it's your turn.
        # Without explicit access to hole cards, a bot cannot play optimally.
        # Let's assume a function `_get_my_hole_cards()` exists or they are set externally.

        # For this bot, the strategy will be very basic without knowing hole cards.
        # If I *had* access to hole cards, I'd determine hand strength.
        # Due to the lack of clear hole card access, I'll implement a simple strategy:
        # - Aggressive pre-flop (raises/calls more)
        # - Cautious post-flop (checks/folds more if no strong community cards)
        # - Always call if the bet is small compared to my stack.
        # - Consider current pot size and betting history.

        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        pot = round_state.pot

        # Heuristic for action based on current round and community cards
        num_community_cards = len(round_state.community_cards)

        # Pre-flop strategy (num_community_cards == 0)
        if num_community_cards == 0:
            # If current bet is 0 (first to act or all checks so far)
            if current_bet_to_match == 0:
                if remaining_chips >= self.blind_amount * 3: # Raise 3x big blind base
                    amount_to_raise = max(round_state.min_raise, self.blind_amount * 3)
                    if amount_to_raise > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, amount_to_raise
                else: # Not enough to raise, just check
                    return PokerAction.CHECK, 0
            else: # There's a bet to match
                # If current_bet_to_match is small relative to our stack, call.
                # Threshold for calling: e.g., if bet is less than 10% of remaining chips
                # or if the pot odds are good. Pot odds calculation is complex without
                # explicit probability of winning (which requires hole cards).
                # Simple heuristic: if bet is <= 2*blind, or less than 5% of stack, call.
                if current_bet_to_match <= self.blind_amount * 2 or current_bet_to_match < remaining_chips * 0.05:
                    if current_bet_to_match >= remaining_chips: # If calling means going all-in
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else: # Otherwise, consider calling, raising or folding.
                    # Aggressively raise if amount is reasonable (e.g., 2.5x current bet)
                    if remaining_chips > current_bet_to_match + round_state.min_raise:
                        amount_to_raise = max(round_state.min_raise, current_bet_to_match * 2.5) # Raise 2.5x the current bet
                        if amount_to_raise > remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, amount_to_raise
                    elif remaining_chips >= current_bet_to_match: # Can call
                        return PokerAction.CALL, 0
                    else: # Cannot even call the amount, must fold
                        return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        # Without hole cards, this is very speculative. We'll play cautiously
        # unless our opponent has checked, or the pot is very small.
        # This strategy is based on pot control and not overcommitting.

        # If current bet is 0 (can check)
        if current_bet_to_match == 0:
            # If after flop, turn, river, we can check, checking is often safe to see next card.
            return PokerAction.CHECK, 0
        else:
            # There's a bet. Pot odds heuristic (simplified):
            # Calculate what percentage of the pot we need to call to stay in.
            # `pot_after_call = pot + current_bet_to_match`
            # `cost_to_call_percentage_of_pot = current_bet_to_match / pot_after_call`
            # If the cost to call is too high (e.g., > 30% of pot), we might fold.
            # This is a very rough estimate without knowing our expected value.
            # Given that we don't know our hand strength, we should be more conservative.

            # If the bet is small relatively to the pot (e.g., less than 20% of the pot)
            # and not too much of our stack, we might call.
            # Avoid divide by zero for pot.
            effective_pot = pot + current_bet_to_match + 0.001 # Add small delta for safety
            if current_bet_to_match / effective_pot < 0.20: # If bet is less than 20% of effective pot
                if current_bet_to_match < remaining_chips * 0.1: # And less than 10% of our stack
                    if current_bet_to_match >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else: # Bet is small, but still a significant part of our stack
                    # Be cautious; if it's not pre-flop and we have no hand info, fold unless pot is huge
                    # Or try a small raise if we have chips, bluffing.
                    if random.random() < 0.1 and remaining_chips > current_bet_to_match + round_state.min_raise: # Small chance to bluff raise
                        amount_to_raise = max(round_state.min_raise, current_bet_to_match * 2)
                        if amount_to_raise > remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, amount_to_raise
                    else:
                        if current_bet_to_match >= remaining_chips: # Call if all-in
                            return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0
            else: # Bet is large relative to the pot, be very cautious
                # Only call if we are pot-committed (calling only a small fraction of our remaining chips effectively makes us all-in)
                if current_bet_to_match >= remaining_chips: # If calling means going all-in
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any per-round state if necessary.
        # For this simple bot, there isn't much to update here.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game has ended. Good place for final logging or cleanup.
        pass