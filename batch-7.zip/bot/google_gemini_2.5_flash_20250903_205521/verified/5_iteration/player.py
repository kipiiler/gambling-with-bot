from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random

class HandRank(Enum):
    HIGH_CARD = 1
    ONE_PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9
    ROYAL_FLUSH = 10

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_chips = {}
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hand_evaluator = HandEvaluator()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_chips = {p_id: starting_chips for p_id in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update our chips for the new round
        self.player_chips[self.id] = remaining_chips
        # Reset hole cards as they are dealt each round
        # The hole cards for the current round are given in the on_start method that is called ONCE at the beginning of the game.
        # This means that player_hands is only available at the start, not per round.
        # However, the bot needs to know its hole cards for the current round.
        # For a competition, the server would send this information.
        # Assuming for now that self.hole_cards is updated externally or on_start is called per round in the actual system.
        # If not, this is a major disconnect. For this template, we'll assume it's set correctly.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - our_bet_in_round
        
        community_cards = round_state.community_cards
        all_cards = self.hole_cards + community_cards

        # Basic hand evaluation
        if len(all_cards) >= 5: # We have enough cards to form a 5-card poker hand
            current_overall_strength, _ = self.hand_evaluator.evaluate_hand(all_cards)
        else: # Pre-flop or not enough community cards to form a 5-card hand
            current_overall_strength = self.hand_evaluator.evaluate_preflop_hand(self.hole_cards)

        num_active_players = sum(1 for p_id in round_state.current_player if round_state.player_chips.get(str(p_id), 0) > 0 or p_id == self.id) # Include players who might have 0 chips but are still "in" due to prior betting.
        
        # Adjust num_active_players more accurately for betting purposes
        num_active_players = 0
        for p_id_str in round_state.player_bets.keys():
            # Check if player is still eligible to act (not folded and not all-in before their turn)
            # This is a simplification; a full game engine would track who folded
            if p_id_str in [str(p) for p in round_state.current_player] and p_id_str != str(self.id):
                 num_active_players += 1
        num_active_players += 1 # Add self
        num_active_players = max(2, num_active_players) # At least 2 active players (you + opponent)

        # Strategy based on hand strength and betting round
        if round_state.round == 'PREFLOP':
            return self._preflop_strategy(round_state, remaining_chips, amount_to_call, current_overall_strength, num_active_players)
        elif round_state.round == 'FLOP':
            return self._postflop_strategy(round_state, remaining_chips, amount_to_call, current_overall_strength, num_active_players)
        elif round_state.round == 'TURN':
            return self._postflop_strategy(round_state, remaining_chips, amount_to_call, current_overall_strength, num_active_players, is_turn=True)
        elif round_state.round == 'RIVER':
            return self._postflop_strategy(round_state, remaining_chips, amount_to_call, current_overall_strength, num_active_players, is_river=True)
        
        # Default fallback (should not be reached if rounds are handled)
        return PokerAction.FOLD, 0

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, hand_strength: HandRank, num_active_players: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        # Define ranges for preflop
        if hand_strength == HandRank.ROYAL_FLUSH: # This would be if we had specific 5-card combos, but preflop, this means A,K suited
            if amount_to_call == 0:
                raise_amount = min(remaining_chips, current_bet * 4) # Open with large raise
                return PokerAction.RAISE, max(min_raise, raise_amount)
            else:
                return PokerAction.ALL_IN, 0 # All-in with premium
        elif hand_strength == HandRank.STRAIGHT_FLUSH or hand_strength == HandRank.FOUR_OF_A_KIND: # AA, KK, QQ, JJ, AKs
            if amount_to_call <= remaining_chips / 2: # Don't commit too much if opponent already all-in
                if amount_to_call == 0:
                    raise_amount = min(remaining_chips, current_bet * 3) # Open raise 3bb
                    return PokerAction.RAISE, max(min_raise, raise_amount)
                else:
                    return PokerAction.RAISE, max(min_raise, current_bet * 2) # Re-raise 2x current bet
            else:
                return PokerAction.ALL_IN, 0 if amount_to_call >= remaining_chips else amount_to_call # Call if too expensive, consider all-in
        elif hand_strength == HandRank.FULL_HOUSE or hand_strength == HandRank.FLUSH: # AQ+, AJs, KQs, pairs 99-TT
            if amount_to_call <= remaining_chips / 3:
                if amount_to_call == 0:
                    raise_amount = min(remaining_chips, current_bet * 2) # Open raise 2bb
                    return PokerAction.RAISE, max(min_raise, raise_amount)
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif hand_strength == HandRank.STRAIGHT or hand_strength == HandRank.THREE_OF_A_KIND: # Suited connectors, smaller pairs, any Broadways
            if amount_to_call <= remaining_chips / 5:
                return PokerAction.CALL, 0
            elif amount_to_call == 0: # If we are the aggressor or no bet
                if random.random() < 0.3: # Occasionally open raise
                    raise_amount = min(remaining_chips, current_bet * 2) # Open raise 2bb
                    return PokerAction.RAISE, max(min_raise, raise_amount)
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        else: # Weak hands
            if amount_to_call == 0: # No bet, check
                return PokerAction.CHECK, 0
            elif amount_to_call <= self.blind_amount: # Call small blinds
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, hand_strength: HandRank, num_active_players: int, is_turn=False, is_river=False) -> Tuple[PokerAction, int]:
        
        pot_size = round_state.pot
        bet_proportion = min(max(0.3, pot_size / remaining_chips), 0.7) # Bet 30-70% of pot

        if hand_strength >= HandRank.TWO_PAIR: # Strong hand: Two Pair or better
            if amount_to_call == 0: # No bet, act aggressively
                bet_amount = min(max(round_state.min_raise, int(pot_size * bet_proportion)), remaining_chips)
                return PokerAction.RAISE, bet_amount
            else: # Opponent bet, consider raising or calling
                if amount_to_call < remaining_chips / 3 and remaining_chips > round_state.min_raise: # Re-raise if not too expensive
                    raise_amount = min(max(round_state.min_raise, amount_to_call * 2), remaining_chips)
                    return PokerAction.RAISE, raise_amount
                elif amount_to_call < remaining_chips / 2: # Call if too expensive to re-raise
                    return PokerAction.CALL, 0
                else: # Commit with all-in if very strong relative to stack
                    return PokerAction.ALL_IN, 0
        
        elif hand_strength == HandRank.ONE_PAIR: # Medium hand: One Pair
            if amount_to_call == 0: # No bet, check or small bet
                if random.random() < 0.4: # Bet occasionally (e.g., 40% of the time)
                    bet_amount = min(max(round_state.min_raise, int(pot_size * 0.3)), remaining_chips)
                    return PokerAction.RAISE, bet_amount
                else:
                    return PokerAction.CHECK, 0
            else: # Opponent bet, call if reasonable
                if amount_to_call <= remaining_chips / 4: # Call up to 25% of stack
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        elif hand_strength == HandRank.HIGH_CARD and is_river: # Weak hand on river, bluff or fold
            if amount_to_call == 0:
                # Bluffing on river
                if random.random() < 0.2 and num_active_players == 2: # Small chance to bluff if heads-up
                    bet_amount = min(max(round_state.min_raise, int(pot_size * 0.25)), remaining_chips)
                    return PokerAction.RAISE, bet_amount
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        
        else: # Weak hand
            if amount_to_call == 0: # No bet, check
                return PokerAction.CHECK, 0
            else: # Opponent bet, fold
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.player_chips[self.id] = remaining_chips
        # Further update player chips based on `player_bets` and `side_pots` for all players
        for p_id_str, bet_amount in round_state.player_bets.items():
            try:
                p_id = int(p_id_str)
                # This doesn't directly give final chip counts after pot distribution.
                # The remaining_chips for self is accurate. For others, it's more complex.
                # A more robust solution would track player stack changes after each round's payout.
                # For this competition, simply tracking self-chips might be sufficient if
                # on_round_start provides the actual current remaining_chips.
                pass
            except ValueError:
                pass


    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass


class HandEvaluator:
    def __init__(self):
        self.card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.rank_to_char = {v: k for k, v in self.card_ranks.items()}

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        rank_char = card_str[0]
        suit = card_str[1]
        return self.card_ranks[rank_char], suit

    def _get_rank_counts(self, ranks: List[int]) -> Dict[int, int]:
        counts = {}
        for r in ranks:
            counts[r] = counts.get(r, 0) + 1
        return counts

    def _is_flush(self, hand: List[str]) -> bool:
        suits = [self._parse_card(c)[1] for c in hand]
        return len(set(suits)) == 1 and len(hand) >= 5

    def _has_straight(self, ranks: List[int]) -> bool:
        unique_ranks = sorted(list(set(ranks)))
        if len(unique_ranks) < 5:
            return False

        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        
        # Check for A-5 straight (Ace low)
        if 14 in unique_ranks: # If Ace is present
            low_ace_ranks = unique_ranks + [1] # Treat Ace as 1
            low_ace_ranks.sort()
            for i in range(len(low_ace_ranks) - 4):
                if low_ace_ranks[i+4] - low_ace_ranks[i] == 4 and all(r in low_ace_ranks for r in [1,2,3,4,5]):
                    return True
        return False
    
    def _get_straight_high_card(self, ranks: List[int]) -> int:
        unique_ranks = sorted(list(set(ranks)))
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return unique_ranks[i+4] # Return highest card in the straight
        
        # Check for A-5 straight (Ace low)
        if 14 in unique_ranks: # Ace is 14
            low_ace_ranks = sorted(list(set([1 if r == 14 else r for r in ranks])))
            if 1 in low_ace_ranks and 2 in low_ace_ranks and 3 in low_ace_ranks and 4 in low_ace_ranks and 5 in low_ace_ranks:
                return 5 # High card is 5 for A-5 straight
        return 0 # No straight

    def evaluate_hand(self, cards: List[str]) -> Tuple[HandRank, List[int]]:
        if not cards:
            return HandRank.HIGH_CARD, []

        all_ranks = [self._parse_card(c)[0] for c in cards]
        all_suits = [self._parse_card(c)[1] for c in cards]

        best_rank = HandRank.HIGH_CARD
        best_kickers = []

        # Iterate through all 5-card combinations
        from itertools import combinations
        for combo_cards in combinations(cards, 5):
            ranks = sorted([self._parse_card(c)[0] for c in combo_cards], reverse=True)
            suits = [self._parse_card(c)[1] for c in combo_cards]
            rank_counts = self._get_rank_counts(ranks)
            counts = sorted(rank_counts.values(), reverse=True)
            unique_ranks = sorted(rank_counts.keys(), reverse=True)

            is_flush = (len(set(suits)) == 1)
            is_straight = self._has_straight(ranks)

            current_rank = HandRank.HIGH_CARD
            current_kickers = []

            if is_straight and is_flush:
                if set(ranks) == {10, 11, 12, 13, 14}:
                    current_rank = HandRank.ROYAL_FLUSH
                else:
                    current_rank = HandRank.STRAIGHT_FLUSH
                current_kickers = [self._get_straight_high_card(ranks)]
            elif counts[0] == 4:
                current_rank = HandRank.FOUR_OF_A_KIND
                current_kickers = [r for r, count in rank_counts.items() if count == 4] + [r for r, count in rank_counts.items() if count == 1] # Quad rank + kicker
            elif counts[0] == 3 and counts[1] == 2:
                current_rank = HandRank.FULL_HOUSE
                current_kickers = [r for r, count in rank_counts.items() if count == 3] + [r for r, count in rank_counts.items() if count == 2] # Triplet rank + pair rank
            elif is_flush:
                current_rank = HandRank.FLUSH
                current_kickers = ranks
            elif is_straight:
                current_rank = HandRank.STRAIGHT
                current_kickers = [self._get_straight_high_card(ranks)]
            elif counts[0] == 3:
                current_rank = HandRank.THREE_OF_A_KIND
                current_kickers = [r for r, count in rank_counts.items() if count == 3] + sorted([r for r, count in rank_counts.items() if count == 1], reverse=True)[:2] # Triplet rank + 2 kickers
            elif counts[0] == 2 and counts[1] == 2:
                current_rank = HandRank.TWO_PAIR
                pairs = sorted([r for r, count in rank_counts.items() if count == 2], reverse=True)
                kicker = sorted([r for r, count in rank_counts.items() if count == 1], reverse=True)[:1]
                current_kickers = pairs + kicker # Two pair ranks + 1 kicker
            elif counts[0] == 2:
                current_rank = HandRank.ONE_PAIR
                pair_rank = [r for r, count in rank_counts.items() if count == 2]
                kickers = sorted([r for r, count in rank_counts.items() if count == 1], reverse=True)[:3]
                current_kickers = pair_rank + kickers # Pair rank + 3 kickers
            else:
                current_rank = HandRank.HIGH_CARD
                current_kickers = ranks[:5] # Top 5 high cards

            # Compare current combination with best found so far
            if current_rank.value > best_rank.value:
                best_rank = current_rank
                best_kickers = current_kickers
            elif current_rank.value == best_rank.value:
                # Tie-breaking with kickers - a simple lexical comparison might be enough for ordered kickers.
                # This needs to be robust for different hand types.
                # For simplicity, we just take the one that evaluates higher on the kicker array, assuming it's sorted descending.
                # A full poker eval logic would compare kickers recursively.
                if current_kickers > best_kickers: # This comparison works for lists of numbers
                    best_kickers = current_kickers

        # Special casing for Royal Flush vs Straight Flush kicker logic, this is implicitly handled if ranks correctly distinguish.
        # Ensure kickers are always a list of high-to-low ranked cards.
        return best_rank, best_kickers

    def evaluate_preflop_hand(self, hole_cards: List[str]) -> HandRank:
        if not hole_cards or len(hole_cards) != 2:
            return HandRank.HIGH_CARD

        r1, s1 = self._parse_card(hole_cards[0])
        r2, s2 = self._parse_card(hole_cards[1])

        # Pocket pairs
        if r1 == r2:
            if r1 >= 14: return HandRank.FOUR_OF_A_KIND # AA (treating as highest possible preflop strong)
            if r1 >= 12: return HandRank.FULL_HOUSE # KK, QQ
            if r1 >= 10: return HandRank.FLUSH # JJ, TT
            return HandRank.ONE_PAIR # 99-22
        
        # Suited cards
        if s1 == s2:
            if r1 >= 13 and r2 >= 12: return HandRank.STRAIGHT_FLUSH # AKs, AQs, KQs
            if r1 >= 10 and r2 >= 9: return HandRank.STRAIGHT # AJs, KJs, QJs, JTs
            if r1 >= 7 and r2 >= 6: return HandRank.TWO_PAIR # Suited connectors above average (76s, 87s, etc)
            return HandRank.ONE_PAIR # Lower suited connectors and suited gappers (e.g., A2s, K3s)

        # Offsuit cards
        else:
            if r1 >= 13 and r2 >= 12: return HandRank.THREE_OF_A_KIND # AKo, AQo (broadways)
            if r1 >= 10 and r2 >= 9: return HandRank.ONE_PAIR # KJo, QJo
            return HandRank.HIGH_CARD # Other hands