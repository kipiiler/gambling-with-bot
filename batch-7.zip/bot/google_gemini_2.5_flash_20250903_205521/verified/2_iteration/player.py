from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.community_cards = []
        self.all_players = []
        self.starting_chips = 0
        self.my_player_id = None
        self.big_blind_amount = 0
        self.small_blind_amount = 0

    def set_id(self, player_id: int) -> None:
        self.my_player_id = player_id
        super().set_id(player_id)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands 
        # For simplicity, assuming blind_amount is the big blind
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2 if blind_amount >= 2 else 0
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.community_cards = round_state.community_cards
        # Update hole cards if they are provided at the start of a round (though typically they are set once on_start)
        if hasattr(round_state, 'player_hands') and str(self.my_player_id) in round_state.player_hands:
            self.hole_cards = round_state.player_hands[str(self.my_player_id)]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.my_player_id), 0)
        
        # Calculate the amount needed to call
        amount_to_call = current_bet_to_match - my_current_bet

        # Ensure we don't try to call more chips than we have
        actual_amount_to_call = min(amount_to_call, remaining_chips)

        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Simple Hand Strength Evaluation (Pre-flop example)
        # This is a very basic heuristic.
        # Ranks: 2-10, J(11), Q(12), K(13), A(14)
        # Suited: s, h, d, c
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        card1_rank = rank_map[self.hole_cards[0][:-1]]
        card2_rank = rank_map[self.hole_cards[1][:-1]]
        card1_suit = self.hole_cards[0][-1]
        card2_suit = self.hole_cards[1][-1]

        is_suited = (card1_suit == card2_suit)
        is_paired = (card1_rank == card2_rank)

        # Pre-flop strategy
        if round_state.round == PokerRound.PREFLOP.name:
            if is_paired and card1_rank >= 10:  # AA, KK, QQ, JJ, TT
                # Aggressive play for strong pairs
                if remaining_chips >= current_bet_to_match * 2 and min_raise > 0:
                    raise_amount = max(min_raise, current_bet_to_match * 2)
                    if raise_amount + my_current_bet > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif remaining_chips >= actual_amount_to_call:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            elif (card1_rank >= 12 and card2_rank >= 12) or \
                 (is_suited and max(card1_rank, card2_rank) >= 12 and min(card1_rank, card2_rank) >= 10): # AKs, AQs, KQs, etc. or unsuited high cards
                # Moderate play for good starting hands
                if amount_to_call == 0: # Can check
                    return PokerAction.CHECK, 0
                elif remaining_chips >= actual_amount_to_call:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            elif is_paired or \
                 (is_suited and max(card1_rank, card2_rank) >= 10) or \
                 (max(card1_rank, card2_rank) >= 10 and min(card1_rank, card2_rank) >= 7 and not is_suited): # Medium pairs, suited connectors, high unsuited
                # Cautious play, call small bets
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= self.big_blind_amount * 2 and remaining_chips >= actual_amount_to_call:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hands, fold unless it's a check
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Placeholder - extremely simplified)
        # This will need significant improvement for a competitive bot.
        if round_state.round in [PokerRound.FLOP.name, PokerRound.TURN.name, PokerRound.RIVER.name]:
            # For now, if we have community cards, just check/call conservatively
            # This logic needs to be replaced with proper hand evaluation.
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            elif remaining_chips >= actual_amount_to_call:
                # Always call small bets, fold large bets
                if amount_to_call <= self.big_blind_amount * 3: # Adjust threshold as needed
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # If we can't even call, we might as well fold, or all_in if we believe we have a strong hand
                # For this simple bot, we'll fold.
                return PokerAction.FOLD, 0


        # Fallback: If no specific strategy, simply check if possible, otherwise fold.
        # This should ideally not be reached if the strategy covers all cases.
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset for the next round
        self.hole_cards = []
        self.community_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass