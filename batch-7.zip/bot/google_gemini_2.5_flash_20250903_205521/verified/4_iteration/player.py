from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class CardRank(Enum):
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8
    NINE = 9
    TEN = 10
    JACK = 11
    QUEEN = 12
    KING = 13
    ACE = 14

class CardSuit(Enum):
    HEARTS = 'h'
    DIAMONDS = 'd'
    CLUBS = 'c'
    SPADES = 's'

class Card:
    def __init__(self, card_str: str):
        self.card_str = card_str
        self.rank = self._parse_rank(card_str[:-1])
        self.suit = CardSuit(card_str[-1])

    def _parse_rank(self, rank_str: str) -> CardRank:
        if rank_str == 'A':
            return CardRank.ACE
        elif rank_str == 'K':
            return CardRank.KING
        elif rank_str == 'Q':
            return CardRank.QUEEN
        elif rank_str == 'J':
            return CardRank.JACK
        elif rank_str == 'T':
            return CardRank.TEN
        else:
            return CardRank(int(rank_str))

    def __repr__(self):
        return self.card_str

class HandStrength(Enum):
    HIGH_CARD = 1
    ONE_PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9
    ROYAL_FLUSH = 10

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.my_player_id = None
        self.hole_cards = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # Assuming player_hands contains only the hole cards for this specific player for the first round
        # In subsequent rounds, on_round_start will be called with the actual hole cards.
        # This initial player_hands seems to be for all players, not just my bot.
        # We'll rely on on_round_start to get my true hole cards.

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # RoundStateClient does not pass player_hands, so this is where we get our hole cards.
        # We assume the player_hands passed in on_start is indeed our hole cards for the first hand.
        # For subsequent hands, the game server implicitly deals new cards which are only known by get_action.
        # This is a limitation based on the provided API. For a real game, hole cards would be passed here.
        # To make a decision, we need to know that we are Player X and we got cards Y and Z.
        # For now, we'll assume player_hands from on_start are our first hand.
        # Subsequent hands, the bot will play randomly or conservatively if it doesn't know its cards.
        # This needs clarification in a real competition.

        # A more robust approach given the existing API would be to store the received 'player_hands'
        # from on_start, and if it's the first time on_round_start is called, use those.
        # However, the problem states `player_hands: List[str]` implies it is *this* player's hands.
        # If the structure of player_hands is indeed just our set of cards for the *current* round,
        # then we should update our hole cards here.
        if hasattr(self, 'player_hands') and self.player_hands:
            self.hole_cards = [Card(c) for c in self.player_hands]
        else:
            # If player_hands is not directly available, this is where the bot is handicapped.
            # For this iteration, we'll assume it's available or default to conservative play.
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.my_player_id = self.id
        community_cards = [Card(c) for c in round_state.community_cards]

        # In a real scenario, self.hole_cards would be updated at the beginning of each round.
        # Since it's not explicitly in `RoundStateClient`, we'll assume it's set once per game initialization
        # or that the competition framework updates it implicitly for `get_action`.
        # For evaluation, a robust bot needs access to its current hole cards here.
        # For this iteration and based on previous logs where bot performance was negative,
        # let's assume `self.player_hands` holds our current hole cards for this specific round.
        # This is a critical assumption based on the ambiguous API.
        # If `player_hands` from `on_start` is ONLY for the very first hand and not updated,
        # then we are playing blind without proper hole cards after the first hand.

        # Let's try to get the hole cards from a more reliable source if possible, or assume they are maintained.
        # Since `on_start` passes `player_hands`, and `on_round_start` does not,
        # a reasonable interpretation is that `player_hands` is *our* initial hand.
        # Assuming the system handles persistent hole cards for `get_action` or `player_hands` is for current round.
        # Let's try to infer hole cards. If they are not set, it's a critical flaw in API.
        if not self.hole_cards and hasattr(self, 'player_hands') and self.player_hands:
            self.hole_cards = [Card(c) for c in self.player_hands]
        
        # If hole cards are still not set, this is a major problem. Play very conservatively.
        if not self.hole_cards:
            return self._decide_action_without_hole_cards(round_state, remaining_chips)

        current_hand_cards = self.hole_cards + community_cards
        strength = self._evaluate_hand_strength(current_hand_cards)

        my_current_bet = round_state.player_bets.get(str(self.my_player_id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        can_check = amount_to_call == 0

        # General strategy:
        # Pre-flop: Play strong hands more aggressively, fold weak hands.
        # Post-flop: Re-evaluate hand strength with community cards.
        # Consider position, number of active players, and pot size.

        # Simple strategy improvements:
        # 1. Be more aggressive with strong starting hands pre-flop.
        # 2. Be more conservative post-flop if hand strength doesn't improve.
        # 3. Consider opponents' actions.

        # Define thresholds for hand strength
        # These are subjective and can be tuned
        strong_hand_threshold = HandStrength.TWO_PAIR # Could be higher for pre-flop
        medium_hand_threshold = HandStrength.ONE_PAIR
        weak_hand_threshold = HandStrength.HIGH_CARD # Any hand below one pair

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Evaluate hole card strength
            hole_card_strength = self._evaluate_hole_cards_strength(self.hole_cards)

            # Aggressive play for premium hands (AA, KK, QQ, AKs, etc.)
            if hole_card_strength >= HandStrength.THREE_OF_A_KIND.value: # Using value as arbitrary scale
                # Raise significantly
                raise_amount = min(remaining_chips, round_state.min_raise * 3) # Aggressive pre-flop raise
                if raise_amount > amount_to_call:
                    return PokerAction.RAISE, raise_amount
                elif amount_to_call > 0:
                    return PokerAction.CALL, 0
                return PokerAction.CHECK, 0
            
            # Medium hands (suited connectors, high pairs, broadways)
            elif hole_card_strength >= HandStrength.ONE_PAIR.value:
                # Call or small raise
                if amount_to_call == 0:
                    # If no one raised, make a small raise to test waters or build pot
                    raise_amount = min(remaining_chips, round_state.min_raise * 2)
                    if raise_amount > round_state.current_bet:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 5: # Call if not too expensive
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Weak hands (low unsuited, garbage)
            else:
                # Fold unless blind check or very small call
                if can_check:
                    return PokerAction.CHECK, 0
                elif amount_to_call < self.blind_amount: # Call if small blind difference etc.
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            # Re-evaluate hand strength with community cards
            current_overall_strength = self._evaluate_hand_strength(current_hand_cards)

            # Very strong hands (e.g., straight, flush, full house, quads)
            if current_overall_strength >= HandStrength.FLUSH:
                # Value bet aggressively or go all-in
                if amount_to_call == 0:
                    raise_amount = min(remaining_chips, round_state.pot) # Bet pot size
                    if raise_amount > round_state.current_bet:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips: # If someone bet, call or raise
                    # If strong, consider re-raising all-in to maximize value
                    if remaining_chips > amount_to_call:
                        return PokerAction.RAISE, min(remaining_chips, round_state.max_raise)
                    return PokerAction.ALL_IN, 0 # Go all-in if cannot raise higher
                else:
                    # Should not happen if amount_to_call <= remaining_chips check is true
                    return PokerAction.FOLD, 0

            # Medium strong hands (e.g., top pair, two pair, three of a kind)
            elif current_overall_strength >= HandStrength.THREE_OF_A_KIND:
                if amount_to_call == 0:
                    # Small to medium value bet
                    bet_amount = min(remaining_chips, round_state.pot // 2)
                    if bet_amount > round_state.current_bet:
                        return PokerAction.RAISE, bet_amount
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 2: # Call if not too expensive
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Weak to medium hands (e.g., one pair)
            elif current_overall_strength >= HandStrength.ONE_PAIR:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 4: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # High card or nothing
            else:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Fallback for unexpected states or if strength evaluation fails
        if can_check:
            return PokerAction.CHECK, 0
        elif amount_to_call <= max(round_state.min_raise, self.blind_amount * 2):
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0


    def _decide_action_without_hole_cards(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Fallback strategy when hole cards are unknown (due to API limitations).
        Play very conservatively.
        """
        my_current_bet = round_state.player_bets.get(str(self.my_player_id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        can_check = amount_to_call == 0

        if can_check:
            return PokerAction.CHECK, 0
        elif amount_to_call == 0: # This case is redundant with can_check
            return PokerAction.CHECK, 0
        elif amount_to_call <= self.blind_amount: # Call minimal blinds or previous checks
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def _evaluate_hole_cards_strength(self, hole_cards: List[Card]) -> int:
        # A very basic static evaluation for pre-flop
        # This can be greatly expanded with poker hand probability tables
        if len(hole_cards) != 2:
            return HandStrength.HIGH_CARD.value # Should not happen

        card1, card2 = hole_cards[0], hole_cards[1]

        # Pair
        if card1.rank == card2.rank:
            if card1.rank.value >= CardRank.ACE.value: return HandStrength.FOUR_OF_A_KIND.value # AA
            if card1.rank.value >= CardRank.KING.value: return HandStrength.FULL_HOUSE.value # KK
            if card1.rank.value >= CardRank.QUEEN.value: return HandStrength.FLUSH.value # QQ
            if card1.rank.value >= CardRank.JACK.value: return HandStrength.STRAIGHT.value # JJ
            if card1.rank.value >= CardRank.NINE.value: return HandStrength.THREE_OF_A_KIND.value # 99
            return HandStrength.ONE_PAIR.value

        # Suited connectors/gappers
        if card1.suit == card2.suit:
            # High suited cards (AKs, AQs, KQs, etc.)
            if card1.rank.value >= CardRank.ACE.value and card2.rank.value >= CardRank.TEN.value:
                return HandStrength.FULL_HOUSE.value
            if card1.rank.value >= CardRank.KING.value and card2.rank.value >= CardRank.JACK.value:
                return HandStrength.FLUSH.value
            # Suited connectors (e.g., 87s, 65s) might give straight/flush potential
            if abs(card1.rank.value - card2.rank.value) <= 2:
                return HandStrength.STRAIGHT.value
            if abs(card1.rank.value - card2.rank.value) < 5:
                return HandStrength.THREE_OF_A_KIND.value

        # Connectors / broadways
        if abs(card1.rank.value - card2.rank.value) == 1 and max(card1.rank.value, card2.rank.value) >= CardRank.JACK.value:
            return HandStrength.TWO_PAIR.value # e.g., KQo, JTo

        # High cards
        if max(card1.rank.value, card2.rank.value) >= CardRank.ACE.value:
            return HandStrength.ONE_PAIR.value # Ax

        return HandStrength.HIGH_CARD.value

    def _evaluate_hand_strength(self, cards: List[Card]) -> HandStrength:
        if len(cards) < 2:
            return HandStrength.HIGH_CARD

        # Sort cards by rank
        sorted_cards = sorted(cards, key=lambda c: c.rank.value, reverse=True)

        # Helper to get ranks and suits
        ranks = [card.rank.value for card in sorted_cards]
        suits = [card.suit for card in sorted_cards]

        # 1. Royal Flush, Straight Flush, Straight, Flush
        is_flush, flush_suit = self._check_flush(suits)
        is_straight, high_straight_rank = self._check_straight(ranks)

        if is_flush and is_straight:
            # Check for royal flush (T, J, Q, K, A of same suit)
            if high_straight_rank == CardRank.ACE.value:
                return HandStrength.ROYAL_FLUSH
            return HandStrength.STRAIGHT_FLUSH
        elif is_flush:
            return HandStrength.FLUSH
        elif is_straight:
            return HandStrength.STRAIGHT

        # Count occurrences of ranks
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1

        # Extract counts. Values are counts, keys are ranks.
        counts = list(rank_counts.values())
        unique_ranks = list(rank_counts.keys())
        
        # 2. Four of a Kind
        if 4 in counts:
            return HandStrength.FOUR_OF_A_KIND

        # 3. Full House
        if 3 in counts and 2 in counts:
            return HandStrength.FULL_HOUSE

        # 4. Three of a Kind
        if 3 in counts:
            return HandStrength.THREE_OF_A_KIND

        # 5. Two Pair
        if counts.count(2) >= 2:
            return HandStrength.TWO_PAIR

        # 6. One Pair
        if 2 in counts:
            return HandStrength.ONE_PAIR

        # 7. High Card
        return HandStrength.HIGH_CARD

    def _check_flush(self, suits: List[CardSuit]) -> Tuple[bool, CardSuit or None]:
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        for suit, count in suit_counts.items():
            if count >= 5:
                return True, suit
        return False, None

    def _check_straight(self, ranks: List[int]) -> Tuple[bool, int or None]:
        # Remove duplicates and sort descending
        unique_ranks = sorted(list(set(ranks)), reverse=True)

        # Handle Ace-low straight (A, 2, 3, 4, 5)
        if CardRank.ACE.value in unique_ranks and \
           CardRank.TWO.value in unique_ranks and \
           CardRank.THREE.value in unique_ranks and \
           CardRank.FOUR.value in unique_ranks and \
           CardRank.FIVE.value in unique_ranks:
            return True, CardRank.FIVE.value # Indicate end of straight

        for i in range(len(unique_ranks) - 4):
            # Check for 5 consecutive ranks
            if unique_ranks[i] - 1 == unique_ranks[i+1] and \
               unique_ranks[i+1] - 1 == unique_ranks[i+2] and \
               unique_ranks[i+2] - 1 == unique_ranks[i+3] and \
               unique_ranks[i+3] - 1 == unique_ranks[i+4]:
                return True, unique_ranks[i]
        return False, None

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass