from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import collections
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank_str = card[0]
        suit = card[1]
        rank_map = {'2':0, '3':1, '4':2, '5':3, '6':4, '7':5, '8':6, '9':7, 'T':8, 'J':9, 'Q':10, 'K':11, 'A':12}
        rank = rank_map[rank_str]
        return rank, suit

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, List[int]]:
        best_category = 0
        best_tiebreak = []
        for hand in itertools.combinations(cards, 5):
            ranks = []
            suits = []
            for c in hand:
                r, s = self.parse_card(c)
                ranks.append(r)
                suits.append(s)
            ranks.sort(reverse=True)
            is_flush = all(s == suits[0] for s in suits)
            is_straight = False
            if ranks == [12, 3, 2, 1, 0]:
                is_straight = True
                straight_high = 3
            else:
                straight_high = ranks[0]
                is_straight = all(ranks[i] == ranks[0] - i for i in range(5))
            if is_straight and is_flush:
                category = 8
                tiebreak = [straight_high]
            elif is_straight:
                category = 4
                tiebreak = [straight_high]
            elif is_flush:
                category = 5
                tiebreak = ranks[:]
            else:
                count = collections.Counter(ranks)
                freqs = sorted(count.values(), reverse=True)
                if freqs[0] == 4:
                    category = 7
                    quad_rank = [r for r, c in count.items() if c == 4][0]
                    kicker = [r for r, c in count.items() if c == 1][0]
                    tiebreak = [quad_rank, kicker]
                elif freqs == [3, 2]:
                    category = 6
                    trip = [r for r, c in count.items() if c == 3][0]
                    pair = [r for r, c in count.items() if c == 2][0]
                    tiebreak = [trip, pair]
                elif freqs[0] == 3:
                    category = 3
                    trip = [r for r, c in count.items() if c == 3][0]
                    kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
                    tiebreak = [trip] + kickers
                elif freqs == [2, 2]:
                    category = 2
                    pairs = sorted([r for r, c in count.items() if c == 2], reverse=True)
                    kicker = [r for r, c in count.items() if c == 1][0]
                    tiebreak = pairs + [kicker]
                elif freqs[0] == 2:
                    category = 1
                    pair = [r for r, c in count.items() if c == 2][0]
                    kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
                    tiebreak = [pair] + kickers
                else:
                    category = 0
                    tiebreak = ranks[:]
            if category > best_category or (category == best_category and tiebreak > best_tiebreak):
                best_category = category
                best_tiebreak = tiebreak
        return best_category, best_tiebreak

    def get_preflop_strength(self, hole: List[str]) -> float:
        r1, s1 = self.parse_card(hole[0])
        r2, s2 = self.parse_card(hole[1])
        if r1 < r2:
            r1, r2 = r2, r1
        paired = r1 == r2
        suited = s1 == s2
        strength = r1 + r2
        if paired:
            strength *= 2
        if suited:
            strength += 2
        gap = r1 - r2
        if gap < 2:
            strength += 2
        elif gap < 3:
            strength += 1
        strength = strength / 50.0
        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        amount_to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        stack = remaining_chips
        if round_state.round == 'Preflop':
            strength = self.get_preflop_strength(self.hole_cards)
        else:
            cards = self.hole_cards + round_state.community_cards
            if len(cards) < 5:
                strength = 0.0
            else:
                category, _ = self.evaluate_hand(cards)
                strength = category / 8.0
        if amount_to_call == 0:
            if strength > 0.5:
                bet_amount = max(round_state.min_raise, pot // 2)
                bet_amount = min(bet_amount, stack)
                if bet_amount >= stack:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            else:
                return PokerAction.CHECK, 0
        else:
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-6)
            if strength > pot_odds + 0.2 or strength > 0.7:
                if stack <= amount_to_call:
                    return PokerAction.ALL_IN, 0
                else:
                    if strength > 0.8 and amount_to_call < 0.2 * stack:
                        raise_amount = max(round_state.min_raise, amount_to_call * 2)
                        raise_amount = min(raise_amount, stack)
                        if raise_amount >= stack:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass