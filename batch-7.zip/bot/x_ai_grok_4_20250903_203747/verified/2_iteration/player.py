from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import collections
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank_str = card[0]
        suit = card[1]
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map[rank_str]
        return rank, suit

    def evaluate_five(self, hand: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        ranks = [r for r, s in hand]
        suits = [s for r, s in hand]
        sorted_ranks = sorted(ranks, reverse=True)
        unique_ranks = sorted(set(ranks), reverse=True)
        rank_count = collections.Counter(ranks)
        suit_count = collections.Counter(suits)
        is_flush = max(suit_count.values()) == 5

        is_straight = False
        straight_high = 0
        if len(unique_ranks) == 5:
            if unique_ranks[0] - unique_ranks[4] == 4:
                is_straight = True
                straight_high = unique_ranks[0]
            elif unique_ranks == [14, 5, 4, 3, 2]:
                is_straight = True
                straight_high = 5

        if is_flush and is_straight:
            return 8, [straight_high]

        if 4 in rank_count.values():
            quad_r = [r for r, c in rank_count.items() if c == 4][0]
            kicker = [r for r, c in rank_count.items() if c == 1][0]
            return 7, [quad_r, kicker]

        if 3 in rank_count.values() and 2 in rank_count.values():
            trip_r = [r for r, c in rank_count.items() if c == 3][0]
            pair_r = [r for r, c in rank_count.items() if c == 2][0]
            return 6, [trip_r, pair_r]

        if is_flush:
            return 5, sorted_ranks

        if is_straight:
            return 4, [straight_high]

        if 3 in rank_count.values():
            trip_r = [r for r, c in rank_count.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 3, [trip_r] + kickers

        pairs = [r for r, c in rank_count.items() if c == 2]
        if len(pairs) == 2:
            sorted_pairs = sorted(pairs, reverse=True)
            kicker = [r for r, c in rank_count.items() if c == 1][0]
            return 2, sorted_pairs + [kicker]

        if len(pairs) == 1:
            pair_r = pairs[0]
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 1, [pair_r] + kickers

        return 0, sorted_ranks

    def get_best_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole + community
        parsed = [self.parse_card(c) for c in all_cards]
        n = len(parsed)
        if n < 5:
            # Pad with dummies or handle differently, but since min 2, but for strength, perhaps approximate
            return 0, []
        elif n == 5:
            candidates = [parsed]
        else:
            candidates = itertools.combinations(parsed, 5)

        best_rank = -1
        best_tie = []
        for combo in candidates:
            rank, tie = self.evaluate_five(list(combo))
            if rank > best_rank or (rank == best_rank and tie > best_tie):
                best_rank = rank
                best_tie = tie
        return best_rank, best_tie

    def get_preflop_strength(self, hole: List[str]) -> float:
        if len(hole) != 2:
            return 0.0
        r1, s1 = self.parse_card(hole[0])
        r2, s2 = self.parse_card(hole[1])
        if r1 < r2:
            r1, r2 = r2, r1
            s1, s2 = s2, s1
        suited = s1 == s2
        if r1 == r2:
            if r1 >= 11:
                return 0.8 + (r1 - 11) / 3.0 * 0.2
            elif r1 >= 7:
                return 0.6 + (r1 - 7) / 4.0 * 0.2
            else:
                return 0.4 + (r1 - 2) / 5.0 * 0.2
        elif suited:
            if r1 == 14:
                return 0.5 + r2 / 14.0 * 0.2
            elif r1 - r2 <= 4 and r1 >= 8:
                return 0.4 + r1 / 14.0 * 0.2
            else:
                return 0.2
        else:
            if r1 == 14 and r2 >= 10:
                return 0.5 + (r2 - 10) / 4.0 * 0.1
            elif r1 - r2 <= 3 and r1 >= 10:
                return 0.3
            else:
                return 0.1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot

        if round_state.round == 'Preflop':
            strength = self.get_preflop_strength(self.hole_cards)
        else:
            rank, _ = self.get_best_hand(self.hole_cards, round_state.community_cards)
            strength = rank / 8.0

        min_total = round_state.current_bet + round_state.min_raise
        min_add = max(1, min_total - my_bet)
        max_add = remaining_chips

        if to_call > 0:
            if to_call > remaining_chips:
                pot_after = pot + remaining_chips
                odds = remaining_chips / (pot + remaining_chips + 0.0001)
                if strength > odds:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            pot_after = pot + to_call
            odds = to_call / (pot + to_call + 0.0001)
            if strength > odds + 0.1:
                if strength > 0.7 and min_add <= max_add:
                    additional = max(min_add, min(max_add, int(pot * 0.5)))
                    return PokerAction.RAISE, additional
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if strength > 0.3 and min_add <= max_add:
                additional = max(min_add, min(max_add, int(pot * 0.5)))
                return PokerAction.RAISE, additional
            else:
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass