from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.my_position = 0
        self.num_players = 0
        self.is_small_blind = False
        self.is_big_blind = False
        self.round_count = 0
        self.aggression_factor = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.my_hand = player_hands
        self.is_small_blind = (self.id == small_blind_player_id)
        self.is_big_blind = (self.id == big_blind_player_id)
        self.round_count = 0
        self.aggression_factor = 1.0 + (random.random() * 0.5) # Add some randomness to play style

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1
        # Adjust aggression based on stack size relative to starting chips
        stack_ratio = remaining_chips / max(self.starting_chips, 1)
        self.aggression_factor = max(0.5, min(2.0, stack_ratio))

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        # Very basic hand strength evaluator
        # In a real implementation, this would be much more sophisticated
        rank_order = '23456789TJQKA'
        
        if not hand:
            return 0.0
            
        # High card strength
        high_card_value = 0
        for card in hand:
            if card and len(card) > 0:
                rank = card[0]
                high_card_value = max(high_card_value, rank_order.index(rank))
        
        strength = high_card_value / len(rank_order)
        
        # Pocket pair bonus
        if len(hand) == 2 and hand[0][0] == hand[1][0]:
            strength += 0.3
            
        # Connectors bonus
        if len(hand) == 2:
            rank1 = rank_order.index(hand[0][0])
            rank2 = rank_order.index(hand[1][0])
            if abs(rank1 - rank2) == 1:
                strength += 0.1
                
        return min(1.0, strength)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Parse the game state
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(self.my_hand, community_cards)
        
        # Positional adjustment (simplified)
        positional_factor = 1.0
        if round_state.round == 'Preflop' and not self.is_small_blind and not self.is_big_blind:
            # Late position adjustment
            positional_factor = 1.1
            
        # Aggression based on hand strength and position
        action_threshold = 0.3 * self.aggression_factor * positional_factor
        
        # Special case: Big blind check
        if call_amount == 0 and my_current_bet == current_bet:
            if round_state.round == 'Preflop' and self.is_big_blind:
                # We're big blind and can check
                if hand_strength > action_threshold:
                    return (PokerAction.RAISE, min(max_raise, max(min_raise, int(remaining_chips * 0.05 * hand_strength))))
                else:
                    return (PokerAction.CHECK, 0)
        
        # All-in situations
        if remaining_chips <= call_amount:
            if hand_strength > 0.4:  # We have at least some reasonable hand
                return (PokerAction.CALL, 0)  # This will be converted to ALL_IN by the engine
            else:
                return (PokerAction.FOLD, 0)
                
        if remaining_chips <= min_raise:
            if hand_strength > 0.5:  # Strong hand, go all-in
                return (PokerAction.RAISE, remaining_chips)  # This will be converted to ALL_IN by the engine
            elif call_amount > 0 and hand_strength > 0.3:  # Decent hand, call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Normal decision making
        if call_amount == 0:
            # We can check
            if hand_strength > action_threshold:
                raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.05 * hand_strength * self.aggression_factor)))
                if raise_amount >= min_raise and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            pot_odds = call_amount / max(1, round_state.pot + call_amount)
            
            if hand_strength > 0.8:  # Very strong hand
                if random.random() < 0.5:  # Sometimes slow play
                    return (PokerAction.CALL, 0)
                else:
                    raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.15 * hand_strength)))
                    return (PokerAction.RAISE, raise_amount)
            elif hand_strength > pot_odds * 1.5:  # Good implied odds
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.6 and round_state.round in ['Flop', 'Turn']:  # Semi-bluff territory
                if random.random() < 0.3:  # Occasionally bluff
                    raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.1)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # Hand is weak relative to pot odds
                if pot_odds > 0.3:  # Pot is offering bad odds
                    return (PokerAction.FOLD, 0)
                elif hand_strength > 0.25:  # Marginal hand but not terrible pot odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could implement learning or adjustment here based on round results
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could implement learning from the game results
        pass