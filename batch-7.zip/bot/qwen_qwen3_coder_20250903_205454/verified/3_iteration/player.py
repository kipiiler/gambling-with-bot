from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_remaining_chips = 10000
        self.big_blind_amount = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.position = 0
        self.num_active_players = 2

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_remaining_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.position = all_players.index(self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips
        self.num_active_players = len(round_state.current_player)

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards:
            return 0.0
            
        # Convert cards to ranks and suits
        ranks = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Basic hand strength based on pocket pairs and high cards
        strength = 0.0
        
        # Pocket pair
        if hole_ranks[0] == hole_ranks[1]:
            strength += 0.3 + (hole_ranks[0] / 100)
        else:
            # Two high cards
            high_card_value = max(hole_ranks) / 15.0
            kicker_value = min(hole_ranks) / 30.0
            strength += high_card_value + kicker_value
            
            # suited
            if hole_suits[0] == hole_suits[1]:
                strength += 0.1
                
        # Adjust based on community cards
        if community_cards:
            # Simple straight/flush potential
            all_ranks = hole_ranks[:]
            all_suits = hole_suits[:]
            for card in community_cards:
                all_ranks.append(ranks[card[0]])
                all_suits.append(card[1])
                
            # Flush potential
            suit_counts = {}
            for suit in all_suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            if max_suit_count >= 4:
                strength += 0.2
                
            # Straight potential (simplified)
            unique_ranks = list(set(all_ranks))
            unique_ranks.sort()
            consecutive = 1
            max_consecutive = 1
            for i in range(1, len(unique_ranks)):
                if unique_ranks[i] == unique_ranks[i-1] + 1:
                    consecutive += 1
                    max_consecutive = max(max_consecutive, consecutive)
                else:
                    consecutive = 1
            if max_consecutive >= 4:
                strength += 0.15
                
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.my_remaining_chips = remaining_chips
        
        # Get current bet amounts
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Positional adjustment (late position is better)
        position_factor = min(1.0, (self.position + 1) / self.num_active_players)
        
        # Number of players still in hand
        players_in_hand = len(round_state.current_player)
        
        # Preflop strategy
        if round_state.round == "Preflop":
            # Use hand strength with position adjustment
            threshold = 0.4 - (0.15 * (1 - position_factor))  # Looser in late position
            
            if self.is_big_blind and to_call == 0:
                # We are big blind and can check
                if hand_strength > 0.3:
                    return (PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.03 * (hand_strength + 0.2)))))
                else:
                    return (PokerAction.CHECK, 0)
            elif to_call > 0:
                # Facing a bet or raise
                call_ratio = to_call / (remaining_chips + my_current_bet + 1)  # Add 1 to prevent division by zero
                
                if hand_strength > 0.7 or (hand_strength > 0.5 and call_ratio < 0.3):
                    if hand_strength > 0.8 and round_state.min_raise > 0:
                        raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(to_call + (to_call * 2 * hand_strength))))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > 0.3 and call_ratio < 0.15:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Open raising
                if hand_strength > threshold:
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.03 * (hand_strength + 0.5))))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Post-flop strategy
            pot_odds = to_call / (round_state.pot + to_call + 1)  # Add 1 to prevent division by zero
            
            # Adjust hand strength based on number of players
            adjusted_strength = hand_strength * (1.2 - (players_in_hand * 0.1))
            adjusted_strength = max(0, adjusted_strength)
            
            if to_call == 0:
                # We can check
                if adjusted_strength > 0.5:
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * 0.5 * adjusted_strength)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                if adjusted_strength > 0.8 or (adjusted_strength > pot_odds and adjusted_strength > 0.4):
                    if adjusted_strength > 0.9 and round_state.min_raise > 0:
                        raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(to_call + (to_call * 2 * adjusted_strength))))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Fallback action if nothing else triggered
        if to_call <= 0:
            return (PokerAction.CHECK, 0)
        elif to_call <= remaining_chips * 0.1:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass