from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.num_active_players = 2
        self.player_id = None
        self.all_players = []
        self.small_blind = 0
        self.big_blind = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.all_players = all_players
        self.small_blind = blind_amount
        self.big_blind = blind_amount * 2
        self.num_active_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update number of active players
        self.num_active_players = len(round_state.current_player)
        if self.num_active_players == 0:
            self.num_active_players = 1  # Prevent division by zero
            
        # Calculate position (lower is better)
        if self.id is not None and round_state.current_player:
            try:
                self.position = round_state.current_player.index(self.id)
            except ValueError:
                self.position = 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Prevent division by zero
        if self.num_active_players <= 0:
            self.num_active_players = 1
            
        # Default position factor to avoid division by zero
        position_factor = 1.0
        if self.num_active_players > 0:
            position_factor = min(1.0, (self.position + 1) / self.num_active_players)
        else:
            position_factor = 1.0
            
        # Parse hole cards
        card1 = self.hole_cards[0] if len(self.hole_cards) > 0 else ""
        card2 = self.hole_cards[1] if len(self.hole_cards) > 1 else ""
        
        # Extract ranks and suits
        rank1 = card1[:-1] if len(card1) > 1 else ""
        suit1 = card1[-1] if len(card1) > 1 else ""
        rank2 = card2[:-1] if len(card2) > 1 else ""
        suit2 = card2[-1] if len(card2) > 1 else ""
        
        # Hand strength evaluation
        is_pair = rank1 == rank2 and rank1 != ""
        is_suited = suit1 == suit2 and suit1 != ""
        
        # Basic hand ranking
        high_ranks = ['A', 'K', 'Q', 'J']
        medium_ranks = ['T', '9', '8', '7']
        
        strong_hand = False
        playable_hand = False
        
        if is_pair:
            if rank1 in high_ranks or rank1 in ['A', 'K']:
                strong_hand = True
                playable_hand = True
            elif rank1 in medium_ranks or rank1 in ['6', '5', '4', '3', '2']:
                playable_hand = True
        elif rank1 in high_ranks and rank2 in high_ranks:
            strong_hand = True
            playable_hand = True
        elif (rank1 in high_ranks and rank2 in medium_ranks) or (rank2 in high_ranks and rank1 in medium_ranks):
            playable_hand = True
        elif is_suited and (rank1 in high_ranks or rank2 in high_ranks):
            playable_hand = True
            
        # Position adjustment - play tighter in early position
        early_position = position_factor < 0.5
        
        if early_position and not strong_hand:
            playable_hand = False
            
        # Current bet and pot odds
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        
        # Pot odds calculation
        pot_odds = to_call / (round_state.pot + to_call) if (round_state.pot + to_call) > 0 else 0
        
        # Stack size consideration
        stack_ratio = remaining_chips / self.big_blind if self.big_blind > 0 else 100
        
        # Action decision logic
        if round_state.round == "Preflop":
            if strong_hand:
                if to_call <= 0:
                    # No bet to call, raise
                    raise_amount = min(remaining_chips, max(round_state.min_raise, self.big_blind * 3))
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
                elif to_call <= remaining_chips * 0.1:  # Small call relative to stack
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif playable_hand:
                if to_call <= 0:
                    # No bet to call, check or small raise
                    if round_state.min_raise > 0 and round_state.min_raise <= remaining_chips * 0.05:
                        raise_amount = min(remaining_chips, round_state.min_raise)
                        if raise_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                elif pot_odds > 0.2:  # Good pot odds
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if to_call <= 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.02:  # Very small call
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:  # Post-flop
            # Simplified post-flop logic
            if to_call <= 0:
                # No bet to call, check or small bet
                if round_state.min_raise > 0 and round_state.min_raise <= remaining_chips * 0.1:
                    raise_amount = min(remaining_chips, round_state.min_raise)
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # There is a bet to call
                if pot_odds > 0.15:  # Decent pot odds
                    if to_call <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Fallback - if we get here, check/fold
        if to_call <= 0:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset for next round if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, cleanup if needed
        pass