from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_position = 0
        self.num_players = 2
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards:
            return 0.0
            
        # Convert cards to ranks and suits
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Basic hand strength based on pairings and high cards
        strength = 0.0
        
        # Pair bonus
        if hole_ranks[0] == hole_ranks[1]:
            strength += 0.3 + (hole_ranks[0] / 50.0)  # Pair bonus
        else:
            # High card bonus
            max_rank = max(hole_ranks)
            strength += max_rank / 50.0
            
            # Connected cards bonus
            if abs(hole_ranks[0] - hole_ranks[1]) == 1:
                strength += 0.1
            elif abs(hole_ranks[0] - hole_ranks[1]) == 2:
                strength += 0.05
                
            # Suited bonus
            if hole_suits[0] == hole_suits[1]:
                strength += 0.15
                
        # Scale to 0-1
        strength = min(strength, 1.0)
        
        return strength
        
    def calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        return pot_size / (pot_size + call_amount)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate how much we need to call
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Adjust strategy based on game stage
        if round_state.round == "Preflop":
            # Preflop strategy
            return self.preflop_strategy(round_state, remaining_chips, hand_strength, call_amount)
        else:
            # Postflop strategy
            return self.postflop_strategy(round_state, remaining_chips, hand_strength, call_amount)
            
    def preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        pot_size = round_state.pot
        
        # Define raising thresholds based on position and hand strength
        if hand_strength > 0.7:  # Premium hands
            if call_amount == 0:
                # We can raise
                raise_amount = min(max(round_state.min_raise, int(pot_size * 0.6)), round_state.max_raise)
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # We need to call or fold
                pot_odds = self.calculate_pot_odds(call_amount, pot_size)
                if hand_strength > 0.6 or pot_odds > 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        elif hand_strength > 0.4:  # Medium hands
            if call_amount == 0:
                raise_amount = min(max(round_state.min_raise, int(pot_size * 0.4)), round_state.max_raise)
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                pot_odds = self.calculate_pot_odds(call_amount, pot_size)
                if pot_odds > 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:  # Weak hands
            if call_amount == 0:
                # Check if possible
                return (PokerAction.CHECK, 0)
            else:
                # Fold weak hands
                return (PokerAction.FOLD, 0)
                
    def postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        pot_size = round_state.pot
        
        # Aggressive with strong hands, conservative with weak ones
        if hand_strength > 0.6:
            if call_amount == 0:
                # We can bet
                raise_amount = min(max(round_state.min_raise, int(pot_size * 0.5)), round_state.max_raise)
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # We need to call or raise
                pot_odds = self.calculate_pot_odds(call_amount, pot_size)
                if pot_odds > 0.2 or hand_strength > 0.7:
                    # Re-raise with very strong hands
                    if hand_strength > 0.8 and round_state.max_raise > call_amount:
                        raise_amount = min(max(round_state.min_raise, call_amount + int(pot_size * 0.7)), round_state.max_raise)
                        if raise_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        elif hand_strength > 0.3:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                pot_odds = self.calculate_pot_odds(call_amount, pot_size)
                if pot_odds > 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Fold weak hands when facing a bet
                return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass