from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength_threshold = 0.5
        self.aggression_factor = 0.7
        self.positional_advantage = 0.1

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players
        self.position = 0  # Position relative to dealer button (0 = dealer, 1 = SB, 2 = BB)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """A simple hand strength evaluator based on card ranks and potential straights/flushes"""
        # Convert cards to ranks and suits for evaluation
        ranks = '23456789TJQKA'
        rank_values = [ranks.index(card[0]) for card in hand + community_cards]
        
        # Simple strength calculation based on high cards and pairs
        if len(community_cards) == 0:
            # Preflop evaluation
            high_card_value = max(rank_values[:2])
            if hand[0][0] == hand[1][0]:  # Pocket pair
                return min(0.9, (high_card_value / 12) * 0.7 + 0.3)
            elif hand[0][1] == hand[1][1]:  # Suited cards
                return min(0.8, (high_card_value / 12) * 0.6 + 0.2)
            else:  # Unsuited cards
                return min(0.6, (high_card_value / 12) * 0.4 + 0.1)
        else:
            # Postflop evaluation
            # Count pairs
            rank_counts = {}
            for rank in rank_values:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            pairs = sum(1 for count in rank_counts.values() if count >= 2)
            trips = sum(1 for count in rank_counts.values() if count >= 3)
            quads = sum(1 for count in rank_counts.values() if count >= 4)
            
            # Evaluate straight possibilities
            sorted_ranks = sorted(set(rank_values))
            straight_potential = 0
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] <= 4:
                    straight_potential = 1
                    break
            
            # Evaluate flush possibilities
            suits = [card[1] for card in hand + community_cards]
            flush_potential = max(suits.count(suit) for suit in 'hscd') >= 4
            
            # Calculate strength
            strength = 0.2
            if quads > 0:
                strength = 0.95
            elif trips > 0 and pairs > 0:
                strength = 0.9
            elif trips > 0:
                strength = 0.8
            elif pairs >= 2:
                strength = 0.7
            elif pairs == 1:
                strength = 0.5
            elif straight_potential:
                strength = 0.6
            elif flush_potential:
                strength = 0.65
            
            return min(0.95, strength)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        community_cards = round_state.community_cards
        hand_strength = self.evaluate_hand_strength(self.my_hand, community_cards)
        
        # Positional adjustment
        # Later position is better (more information)
        position_bonus = self.position * self.positional_advantage
        
        # Adjust strategy based on hand strength and position
        effective_strength = hand_strength + position_bonus
        
        # Aggressive play when we have a strong hand
        if effective_strength > self.aggression_factor:
            # We want to raise or go all-in
            if to_call > 0:
                # There's a bet to call
                if effective_strength > 0.8:  # Very strong hand
                    # Go all-in or make a large raise
                    raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.5)))
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
                else:  # Moderately strong hand
                    # Make a standard raise
                    raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.25)))
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
            else:
                # No bet to call, we can make a bet
                if effective_strength > 0.8:  # Very strong hand
                    bet_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.4)))
                    if bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, bet_amount)
                else:  # Moderately strong hand
                    bet_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.2)))
                    if bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, bet_amount)
        elif effective_strength > 0.3:  # Marginal hand
            # Call small bets, fold to large ones
            if to_call <= remaining_chips * 0.1:  # Only call small bets
                if to_call > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hand
            # Fold unless there's no bet
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass