from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 50
        self.player_hands = []
        self.all_players = []
        self.hand_strength_cache = {}
        self.opponent_tendencies = {}
        self.our_bet = 0
        self.round_bets = {}
        self.position = 0
        self.players_in_hand = []
        self.aggression_factor = 1.0
        self.tightness_factor = 0.5
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.player_hands = player_hands
        self.all_players = all_players
        self.hand_strength_cache = {}
        self.opponent_tendencies = {player_id: {'vpip': 0, 'pfr': 0, 'aggression': 0, 'hands_played': 0} for player_id in all_players}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.our_bet = round_state.player_bets.get(str(self.id), 0)
        self.players_in_hand = [int(pid) for pid in round_state.current_player]
        self.position = self.players_in_hand.index(self.id) if self.id in self.players_in_hand else 0
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            hole_cards = self.player_hands
            if not hole_cards or len(hole_cards) < 2:
                return PokerAction.FOLD, 0
                
            community_cards = round_state.community_cards
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            
            # Calculate hand strength
            hand_strength = self._calculate_hand_strength(hole_cards, community_cards)
            
            # Calculate pot odds
            call_amount = max(0, current_bet - self.our_bet)
            pot_odds = call_amount / (pot + call_amount + 1e-6) if call_amount > 0 else 0
            
            # Position factor
            position_factor = self._get_position_factor()
            
            # Opponent tendencies
            opponent_aggression = self._get_opponent_aggression()
            
            # Adjust hand strength based on position and opponents
            adjusted_strength = hand_strength * position_factor * (1 + 0.1 * opponent_aggression)
            
            # Decision making
            if round_state.round == 'Preflop':
                return self._preflop_strategy(hole_cards, current_bet, min_raise, max_raise, pot, remaining_chips, adjusted_strength)
            else:
                return self._postflop_strategy(hole_cards, community_cards, current_bet, min_raise, max_raise, pot, remaining_chips, adjusted_strength, pot_odds)
                
        except Exception as e:
            return PokerAction.FOLD, 0
            
    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0
            
        # Simple hand strength calculation
        card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        card_suits = {'h': 0, 'd': 1, 'c': 2, 's': 3}
        
        # Extract ranks and suits
        ranks = []
        suits = []
        for card in hole_cards + community_cards:
            if len(card) >= 2:
                rank = card[0]
                suit = card[1]
                ranks.append(card_ranks.get(rank, 0))
                suits.append(card_suits.get(suit, 0))
        
        # Basic hand evaluation
        strength = 0.0
        
        # High card value
        if len(hole_cards) >= 2:
            hole_ranks = [card_ranks.get(card[0], 0) for card in hole_cards[:2]]
            strength += max(hole_ranks) / 14.0 * 0.3
            
        # Pair value
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        pairs = [rank for rank, count in rank_counts.items() if count >= 2]
        if pairs:
            strength += len(pairs) * 0.2 + max(pairs) / 14.0 * 0.1
            
        # Suited cards
        if len(hole_cards) >= 2:
            if hole_cards[0][1] == hole_cards[1][1]:
                strength += 0.1
                
        # Connected cards
        if len(hole_cards) >= 2:
            hole_ranks = sorted([card_ranks.get(card[0], 0) for card in hole_cards[:2]])
            if abs(hole_ranks[0] - hole_ranks[1]) <= 4:
                strength += 0.05
                
        return min(strength, 1.0)
        
    def _get_position_factor(self) -> float:
        # Later position is better
        if len(self.players_in_hand) <= 2:
            return 1.2 if self.position == 1 else 0.8
        else:
            return 1.0 + (len(self.players_in_hand) - self.position - 1) * 0.1
            
    def _get_opponent_aggression(self) -> float:
        if not self.opponent_tendencies:
            return 0.0
            
        total_aggression = 0
        count = 0
        for pid, stats in self.opponent_tendencies.items():
            if pid != self.id and stats['hands_played'] > 0:
                total_aggression += stats['aggression']
                count += 1
                
        return total_aggression / max(count, 1)
        
    def _preflop_strategy(self, hole_cards: List[str], current_bet: int, min_raise: int, max_raise: int, pot: int, remaining_chips: int, strength: float) -> Tuple[PokerAction, int]:
        # Premium hands
        if strength > 0.8:
            if current_bet == 0:
                raise_amount = min(max(min_raise, int(pot * 0.75)), max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                if current_bet <= remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                else:
                    raise_amount = min(max(min_raise, int(pot * 1.5)), max_raise)
                    return PokerAction.RAISE, raise_amount
                    
        # Good hands
        elif strength > 0.5:
            if current_bet == 0:
                raise_amount = min(max(min_raise, int(pot * 0.5)), max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                call_amount = max(0, current_bet - self.our_bet)
                if call_amount <= pot * 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
        # Marginal hands
        elif strength > 0.3:
            if current_bet == 0:
                return PokerAction.CHECK, 0
            else:
                call_amount = max(0, current_bet - self.our_bet)
                if call_amount <= self.blind_amount:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
        # Weak hands
        else:
            if current_bet == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
                
    def _postflop_strategy(self, hole_cards: List[str], community_cards: List[str], current_bet: int, min_raise: int, max_raise: int, pot: int, remaining_chips: int, strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        # Strong hand
        if strength > 0.7:
            if current_bet == 0:
                bet_amount = min(max(min_raise, int(pot * 0.75)), max_raise)
                return PokerAction.RAISE, bet_amount
            else:
                if pot_odds < 0.3:
                    return PokerAction.CALL, 0
                else:
                    raise_amount = min(max(min_raise, int(pot * 1.2)), max_raise)
                    return PokerAction.RAISE, raise_amount
                    
        # Medium strength
        elif strength > 0.4:
            if current_bet == 0:
                return PokerAction.CHECK, 0
            else:
                if pot_odds < 0.25:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
        # Weak hand
        else:
            if current_bet == 0:
                return PokerAction.CHECK, 0
            else:
                if pot_odds < 0.15 and len(community_cards) < 5:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent tendencies
        for pid, action in round_state.player_actions.items():
            pid_int = int(pid)
            if pid_int in self.opponent_tendencies:
                self.opponent_tendencies[pid_int]['hands_played'] += 1
                if action in ['Raise', 'All-in']:
                    self.opponent_tendencies[pid_int]['aggression'] += 1
                if action in ['Call', 'Raise', 'All-in']:
                    self.opponent_tendencies[pid_int]['vpip'] += 1
                    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_strength_cache = {}
        self.our_bet = 0
        self.round_bets = {}