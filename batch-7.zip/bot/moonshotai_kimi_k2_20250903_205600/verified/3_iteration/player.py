from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_id = None
        self.my_hand = []
        self.position = None
        self.players = []
        self.blind_amount = 0
        self.round_count = 0
        self.aggression_factor = 1.0
        self.tightness = 0.7
        self.opponent_stats = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.players = all_players
        self.my_id = self.id
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_bets = round_state.player_bets
        
        my_current_bet = player_bets.get(str(self.my_id), 0)
        to_call = max(0, current_bet - my_current_bet)
        
        # Basic hand strength evaluation
        hand_strength = self.evaluate_hand_strength(self.my_hand, community_cards)
        position_strength = self.evaluate_position_strength(round_state)
        
        # Adjust aggression based on stack size
        stack_ratio = remaining_chips / self.starting_chips
        if stack_ratio < 0.3:
            self.aggression_factor = 0.8
        elif stack_ratio > 2.0:
            self.aggression_factor = 1.2
        
        # Calculate pot odds
        pot_odds = to_call / (pot + to_call + 1e-5)
        
        # Decision making
        if round_state.round == 'Preflop':
            return self.preflop_action(hand_strength, to_call, pot_odds, min_raise, max_raise, remaining_chips)
        else:
            return self.postflop_action(hand_strength, position_strength, to_call, pot_odds, min_raise, max_raise, remaining_chips, community_cards)
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0
        
        # Simple hand strength based on card ranks and suitedness
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        
        # High card bonus
        strength = max(hole_ranks) / 14.0
        
        # Pair bonus
        if hole_ranks[0] == hole_ranks[1]:
            strength = 0.7 + (hole_ranks[0] / 14.0) * 0.3
        
        # Suited bonus
        if suits[0] == suits[1]:
            strength += 0.1
        
        # Connected cards bonus
        gap = abs(hole_ranks[0] - hole_ranks[1])
        if gap <= 1:
            strength += 0.15
        elif gap <= 2:
            strength += 0.05
        
        # Adjust for community cards
        if community_cards:
            all_cards = hole_cards + community_cards
            # Simple flush draw detection
            flush_suit = None
            suit_counts = {}
            for card in all_cards:
                suit = card[1]
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
                if suit_counts[suit] >= 4:
                    flush_suit = suit
            
            if flush_suit and suits[0] == suits[1] == flush_suit:
                strength += 0.2
            
            # Simple straight draw detection
            all_ranks = [ranks[card[0]] for card in all_cards]
            unique_ranks = sorted(list(set(all_ranks)))
            straight_count = 0
            for i in range(len(unique_ranks) - 1):
                if unique_ranks[i+1] - unique_ranks[i] == 1:
                    straight_count += 1
                else:
                    straight_count = 0
                if straight_count >= 3:
                    strength += 0.15
        
        return min(strength, 1.0)
    
    def evaluate_position_strength(self, round_state: RoundStateClient) -> float:
        current_players = len(round_state.current_player)
        if current_players <= 2:
            return 1.0
        return 1.0 / current_players
    
    def preflop_action(self, hand_strength: float, to_call: int, pot_odds: float, min_raise: int, max_raise: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if to_call == 0:
            # Can check
            if hand_strength > 0.6:
                raise_amount = min(max(min_raise, int(remaining_chips * 0.03)), max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            # Need to call or raise
            threshold = 0.4
            if hand_strength > threshold + pot_odds:
                if hand_strength > 0.8 and to_call < remaining_chips * 0.1:
                    raise_amount = min(max(min_raise, int(to_call * 3)), max_raise)
                    return PokerAction.RAISE, raise_amount
                elif hand_strength > threshold + pot_odds * 2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0
    
    def postflop_action(self, hand_strength: float, position_strength: float, to_call: int, pot_odds: float, min_raise: int, max_raise: int, remaining_chips: int, community_cards: List[str]) -> Tuple[PokerAction, int]:
        effective_strength = hand_strength * position_strength
        
        if to_call == 0:
            # Can check
            if effective_strength > 0.5:
                raise_amount = min(max(min_raise, int(remaining_chips * 0.05)), max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            # Need to call or raise
            threshold = 0.3
            if effective_strength > threshold + pot_odds:
                if effective_strength > 0.7 and to_call < remaining_chips * 0.15:
                    raise_amount = min(max(min_raise, int(to_call * 2.5)), max_raise)
                    return PokerAction.RAISE, raise_amount
                elif effective_strength > threshold + pot_odds * 1.5:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass