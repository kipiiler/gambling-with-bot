from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_strength_cache = {}
        self.player_stats = {}
        self.tightness_factor = 0.7
        self.aggression_factor = 0.6
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands[0] if player_hands else None
        for player_id in all_players:
            if player_id != self.id:
                self.player_stats[player_id] = {
                    'hands_played': 0,
                    'aggression': 1.0,
                    'last_action': None
                }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.current_round = round_state.round
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.hole_cards
        if not hole_cards or len(hole_cards) < 2:
            return (PokerAction.FOLD, 0)
        
        # Parse hole cards
        card1, card2 = hole_cards.split()[:2]
        rank1 = self.get_card_rank(card1)
        rank2 = self.get_card_rank(card2)
        suit1 = card1[-1]
        suit2 = card2[-1]
        
        # Basic hand strength calculation
        is_pair = rank1 == rank2
        is_suited = suit1 == suit2
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        # Starting hand evaluation
        strength = 0
        if is_pair:
            strength = 8 + high_rank / 14.0
            if high_rank >= 12:  # JJ+
                strength += 2
        elif is_suited:
            if high_rank >= 12 and low_rank >= 10:  # AKs, AQs, etc
                strength = 7 + (high_rank + low_rank) / 28.0
            elif high_rank - low_rank <= 3:  # Suited connectors
                strength = 4 + (high_rank + low_rank) / 28.0
            else:
                strength = 2 + high_rank / 14.0
        else:
            if high_rank - low_rank == 1:  # Offsuit connectors
                strength = 3 + high_rank / 14.0
            elif high_rank >= 12 and low_rank >= 10:  # AKo, AQo
                strength = 5 + (high_rank + low_rank) / 28.0
            else:
                strength = 1 + high_rank / 20.0
        
        # Pot odds calculation
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        pot_SIZE = round_state.pot
        if to_call > 0:
            pot_odds = to_call / (pot_SIZE + to_call)
        else:
            pot_odds = 0
        
        # Community cards impact
        com_cards = round_state.community_cards
        if com_cards:
            com_count = len(com_cards)
            if com_count >= 3:
                strength = self.evaluate_with_community(hole_cards, com_cards, strength)
        
        # Position adjustment
        num_players = len(round_state.current_player)
        position = round_state.current_player.index(self.id)
        position_factor = 1 + (position / max(num_players, 1))
        
        # Betting decision
        adjusted_strength = strength * position_factor * self.tightness_factor
        
        if adjusted_strength >= 7.5 and round_state.max_raise > 0:
            # Strong hand - bet/raise
            bet_size = min(round_state.pot // 2, remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, max(bet_size, round_state.min_raise))
            else:
                return (PokerAction.ALL_IN, 0)
        elif adjusted_strength >= 5.0 and to_call > 0:
            # Decent hand - call if pot odds justify it
            required_odds = 0.3 if self.current_round == 'Preflop' else 0.25
            if pot_odds <= required_odds:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        elif adjusted_strength >= 3.0 and pot_odds <= 0.15:
            # Weak hand but good odds - call
            if to_call <= 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CALL, 0) if to_call < remaining_chips * 0.1 else (PokerAction.FOLD, 0)
        else:
            # Fold weak hands
            if to_call <= 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)
    
    def evaluate_with_community(self, hole_cards: str, community_cards: List[str], original_strength: float) -> float:
        com_ranks = [self.get_card_rank(c) for c in community_cards]
        com_suits = [c[-1] for c in community_cards]
        
        hand_ranks = [self.get_card_rank(c) for c in hole_cards.split()[:2]]
        hand_suits = [c[-1] for c in hole_cards.split()[:2]]
        
        all_ranks = hand_ranks + com_ranks
        all_suits = hand_suits + com_suits
        
        # Count pairs/trips/quads
        rank_counts = {}
        for r in all_ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        # Check for flush
        suit_counts = {}
        for s in all_suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        max_suit = max(suit_counts.values()) if suit_counts else 0
        flush_potential = max_suit >= 5
        
        # Check for straight
        unique_ranks = sorted(list(set(all_ranks)))
        straight_check = self.has_straight_potential(unique_ranks)
        
        enhanced_strength = original_strength
        
        if flush_potential or straight_check:
            enhanced_strength += 3
        
        if 4 in rank_counts.values():
            enhanced_strength += 8
        elif 3 in rank_counts.values():
            enhanced_strength += 4
        elif 2 in rank_counts.values():
            pairs = list(rank_counts.values()).count(2)
            enhanced_strength += pairs * 2
        
        return min(enhanced_strength, 10)
    
    def has_straight_potential(self, ranks: List[int]) -> bool:
        if len(ranks) < 5:
            return False
        
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        # Check for wheel (A-2-3-4-5)
        if 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
            return True
        
        return False
    
    def get_card_rank(self, card: str) -> int:
        rank = card[0]
        rank_map = {
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        return rank_map.get(rank, int(rank))
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass