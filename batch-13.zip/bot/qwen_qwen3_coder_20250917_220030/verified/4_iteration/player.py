from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.all_players = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.position = "middle"  # default position
        self.preflop_stats = {}
        self.game_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.game_count = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Determine our position relative to blinds
        players_in_hand = list(round_state.player_bets.keys())
        if len(players_in_hand) >= 3:
            # Simple position estimation
            try:
                my_index = players_in_hand.index(str(self.id))
                if my_index == len(players_in_hand) - 1:
                    self.position = "button"
                elif my_index == len(players_in_hand) - 2:
                    self.position = "cut_off"
                elif my_index == 0 or my_index == 1:
                    self.position = "early"
                else:
                    self.position = "middle"
            except ValueError:
                self.position = "middle"
        
        # Initialize preflop stats tracking
        if round_state.round == 'Preflop':
            for pid in players_in_hand:
                if pid not in self.preflop_stats:
                    self.preflop_stats[pid] = {'fold_to_3bet': 0, 'total_3bet_opportunities': 0}

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """
        Simple hand strength evaluation based on hole cards and board.
        Returns a value between 0 and 1.
        """
        # Simplified hand evaluation - in practice you'd want a real poker hand evaluator
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        if not self.my_hand:
            return 0.0
            
        ranks = [card[0] for card in self.my_hand]
        suits = [card[1] for card in self.my_hand]
        
        # Convert ranks to numeric values
        rank_nums = [rank_values[r] for r in ranks]
        
        # Pair strength
        pair_bonus = 0
        if len(set(ranks)) == 1:
            pair_bonus = rank_nums[0] / 14.0  # Pocket pairs
        
        # Connected cards bonus
        connected_bonus = 0
        if abs(rank_nums[0] - rank_nums[1]) == 1 or abs(rank_nums[0] - rank_nums[1]) == 12:  # Connected or A-2
            connected_bonus = 0.1
            
        # Suited cards bonus
        suited_bonus = 0
        if len(set(suits)) == 1:
            suited_bonus = 0.15
            
        # High card bonus
        high_card_bonus = max(rank_nums) / 14.0 * 0.2
            
        # Base strength with some randomness to avoid predictability
        base_strength = (pair_bonus + connected_bonus + suited_bonus + high_card_bonus) / 2.0
        randomness = random.uniform(-0.1, 0.1)
        strength = min(1.0, max(0.0, base_strength + randomness))
        
        # Adjust based on community cards if available
        if round_state.community_cards:
            # Very simple board texture analysis
            board_ranks = [card[0] for card in round_state.community_cards]
            board_suits = [card[1] for card in round_state.community_cards]
            
            # Reduce strength if board has high cards and we don't have high cards
            high_board_cards = sum(1 for r in board_ranks if r in ['T', 'J', 'Q', 'K', 'A'])
            if high_board_cards >= 2 and max(rank_nums) < 10:
                strength *= 0.8
                
            # Increase strength if we have flush potential
            if len(set(suits + board_suits)) <= 2:
                strength *= 1.1
        
        return min(1.0, max(0.0, strength))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Current bet and pot information
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - my_current_bet
        
        # Evaluate hand strength
        strength = self.evaluate_hand_strength(round_state)
        
        # Determine round multiplier for aggression
        round_multiplier = {
            'Preflop': 1.0,
            'Flop': 1.2,
            'Turn': 1.4,
            'River': 1.6
        }.get(round_state.round, 1.0)
        
        # Position-based adjustment
        position_multiplier = {
            "button": 1.2,
            "cut_off": 1.1,
            "middle": 1.0,
            "early": 0.9
        }.get(self.position, 1.0)
        
        # Adjust strategy based on stack size relative to blinds
        stack_to_blind_ratio = remaining_chips / (self.blind_amount * 2) if self.blind_amount > 0 else 100
        stack_adjustment = min(2.0, max(0.5, stack_to_blind_ratio / 20.0))
        
        # Calculate thresholds for actions
        fold_threshold = 0.3 * position_multiplier * (1.0 / stack_adjustment)
        call_threshold = (0.5 + 0.1 * round_state.round_num) * round_multiplier * position_multiplier
        raise_threshold = (0.7 + 0.15 * round_state.round_num) * round_multiplier * position_multiplier * stack_adjustment
        
        # All-in consideration when low on chips
        if remaining_chips <= self.blind_amount * 5:  # Less than 5 big blinds
            if strength > fold_threshold:
                return (PokerAction.ALL_IN, 0)
            else:
                # Even with weak hand, consider all-in with some probability
                if strength > 0.2 or random.random() < 0.1:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # No betting yet in this round
        if current_bet == 0:
            if strength > raise_threshold:
                # Raise with strong hands
                raise_amount = min(
                    round_state.max_raise,
                    max(round_state.min_raise, int(remaining_chips * (0.5 + random.random()) * strength))
                )
                return (PokerAction.RAISE, raise_amount)
            elif strength > fold_threshold:
                # Open with moderate hands
                raise_amount = min(
                    round_state.max_raise,
                    max(round_state.min_raise, int(remaining_chips * 0.3 * strength))
                )
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Check with weak hands
                return (PokerAction.CHECK, 0)
        
        # There is a bet to call
        else:
            pot_odds = amount_to_call / (round_state.pot + amount_to_call) if (round_state.pot + amount_to_call) > 0 else 0
            
            # Adjust required strength based on position and pot odds
            required_strength = fold_threshold + pot_odds * 0.5
            
            if strength > raise_threshold:
                # 3-bet with strong hands
                raise_amount = min(
                    round_state.max_raise,
                    max(round_state.min_raise, int((current_bet + amount_to_call) * 2 + (remaining_chips * 0.5 * strength)))
                )
                return (PokerAction.RAISE, raise_amount)
            elif strength > required_strength:
                # Call with hands that have enough equity
                return (PokerAction.CALL, 0)
            else:
                # Fold with weak hands
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update statistics for opponents
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and action == 'Fold' and round_state.round == 'Preflop':
                if player_id in self.preflop_stats:
                    self.preflop_stats[player_id]['fold_to_3bet'] += 1
                else:
                    self.preflop_stats[player_id] = {'fold_to_3bet': 1, 'total_3bet_opportunities': 1}

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.game_count += 1
        # Could use this information to adjust strategy, but keeping it simple for now
        pass