from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.remaining_chips = 0
        self.round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.remaining_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation based on card ranks and potential straights/flushes"""
        if not hole_cards:
            return 0.0
            
        # Convert card strings to ranks and suits
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        community_ranks = [ranks[card[0]] for card in community_cards] if community_cards else []
        all_ranks = hole_ranks + community_ranks
        
        # Simple strength based on high cards and pairs
        strength = 0.0
        
        # Check for pairs, two pairs, trips, etc.
        rank_counts = {}
        for rank in all_ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        # Evaluate strength based on pairs and high cards
        max_count = max(rank_counts.values()) if rank_counts else 0
        unique_ranks = len(rank_counts)
        
        if max_count == 4:
            strength = 0.9  # Four of a kind
        elif max_count == 3 and unique_ranks == 2:
            strength = 0.8  # Full house
        elif max_count == 3:
            strength = 0.7  # Three of a kind
        elif max_count == 2 and list(rank_counts.values()).count(2) == 2:
            strength = 0.6  # Two pair
        elif max_count == 2:
            strength = 0.5  # One pair
        else:
            # High card strength based on highest cards
            sorted_ranks = sorted(all_ranks, reverse=True)
            strength = min(0.4 + (sorted_ranks[0] / 14) * 0.3, 0.49)  # Scale high card strength
            
        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get current bet and player's current bet
        current_bet = round_state.current_bet
        player_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - player_bet
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Position awareness (simplified)
        is_preflop = round_state.round == "Preflop"
        is_in_blind = (self.id == self.big_blind_player_id or self.id == self.small_blind_player_id)
        
        # Aggression factor based on hand strength
        if round_state.round == "Preflop":
            # Preflop strategy
            if hand_strength > 0.7:  # Strong hands
                if to_call <= remaining_chips * 0.1:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.RAISE, min(round_state.min_raise * 3, round_state.max_raise))
                elif to_call <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    if hand_strength > 0.8:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:  # Medium hands
                if to_call <= remaining_chips * 0.05:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.RAISE, min(round_state.min_raise, round_state.max_raise))
                elif to_call <= remaining_chips * 0.15:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Weak hands
                if to_call == 0 and is_in_blind:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.02:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Postflop strategy
            if hand_strength > 0.7:  # Strong hands
                if to_call <= remaining_chips * 0.2:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.RAISE, min(round_state.min_raise * 2, round_state.max_raise))
                elif to_call <= remaining_chips * 0.5:
                    return (PokerAction.CALL, 0)
                else:
                    if hand_strength > 0.85:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:  # Medium hands
                if to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                elif to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Weak hands
                if to_call == 0:
                    # Bluff occasionally with weak hands
                    if random.random() < 0.1 and round_state.round == "River":
                        return (PokerAction.RAISE, min(round_state.min_raise, round_state.max_raise))
                    else:
                        return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.round_state = round_state
        # No action needed here