from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_id = None
        self.is_big_blind = False
        self.is_small_blind = False
        self.preflop_aggressor = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_id = str(self.id)
        if self.my_id == str(big_blind_player_id):
            self.is_big_blind = True
        else:
            self.is_big_blind = False
            
        if self.my_id == str(small_blind_player_id):
            self.is_small_blind = True
        else:
            self.is_small_blind = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset flags for new hand
        self.preflop_aggressor = False

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards:
            return 0.0
            
        # Convert cards to ranks and suits
        ranks = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Basic hand strength based on pairs and high cards
        strength = 0.0
        
        # Pair bonus
        if hole_ranks[0] == hole_ranks[1]:
            strength += hole_ranks[0] / 20.0  # Pair strength
        
        # High card value
        strength += max(hole_ranks) / 30.0
        strength += min(hole_ranks) / 60.0
        
        # suited bonus
        if hole_suits[0] == hole_suits[1]:
            strength += 0.1
            
        # Connectors bonus (straight potential)
        if abs(hole_ranks[0] - hole_ranks[1]) == 1:
            strength += 0.05
        elif abs(hole_ranks[0] - hole_ranks[1]) == 2:
            strength += 0.03
            
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(self.my_id, 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Preflop strategy
        if round_state.round == "Preflop":
            # Position-based play
            is_bb = self.is_big_blind
            is_sb = self.is_small_blind
            
            # Opening or responding to open
            if current_bet == 0 or (is_bb and my_bet == 10):  # We're BB and getting action
                # Open/3-bet ranges
                if hand_strength > 0.6:  # Premium hands
                    raise_amount = min(max_raise, max(min_raise, int(3 * current_bet + 20)))
                    self.preflop_aggressor = True
                    return (PokerAction.RAISE, raise_amount)
                elif hand_strength > 0.4:  # playable hands
                    raise_amount = min(max_raise, max(min_raise, int(2.5 * current_bet + 15)))
                    self.preflop_aggressor = True
                    return (PokerAction.RAISE, raise_amount)
                elif hand_strength > 0.25:  # marginal hands
                    if random.random() < 0.3:
                        raise_amount = min(max_raise, max(min_raise, int(2 * current_bet + 10)))
                        self.preflop_aggressor = True
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)  # Just call
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Facing a bet/raise
                if hand_strength > 0.7:  # Strong hands
                    if to_call <= remaining_chips * 0.1:  # Reasonable call
                        raise_amount = min(max_raise, max(min_raise, int(3 * to_call + 20)))
                        self.preflop_aggressor = True
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)  # Just call if raise is too big
                elif hand_strength > 0.5:  # Medium strength
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif hand_strength > 0.3:  # Weak but playable
                    if to_call <= remaining_chips * 0.02:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Postflop strategy
        else:
            # Simplified postflop decision making
            if hand_strength > 0.7:  # Strong made hands or strong draws
                if current_bet == 0:
                    raise_amount = min(max_raise, max(min_raise, int(0.5 * round_state.pot)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    if to_call <= remaining_chips * 0.15:  # Reasonable bet
                        # Value bet or call for value
                        if random.random() < 0.7:
                            return (PokerAction.CALL, 0)
                        else:
                            raise_amount = min(max_raise, max(min_raise, int(2 * to_call)))
                            return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:  # Medium strength
                if current_bet == 0:
                    if random.random() < 0.5:
                        return (PokerAction.CHECK, 0)
                    else:
                        raise_amount = min(max_raise, max(min_raise, int(0.3 * round_state.pot)))
                        return (PokerAction.RAISE, raise_amount)
                else:
                    if to_call <= remaining_chips * 0.07:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength > 0.2:  # Weak draws or marginal hands
                if current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    if to_call <= remaining_chips * 0.03:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:  # Very weak
                if current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Default fallback - check if possible, otherwise fold
        if current_bet == 0:
            return (PokerAction.CHECK, 0)
        elif to_call >= remaining_chips:
            return (PokerAction.ALL_IN, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset position flags after each round
        self.is_big_blind = False
        self.is_small_blind = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, no specific action needed
        pass