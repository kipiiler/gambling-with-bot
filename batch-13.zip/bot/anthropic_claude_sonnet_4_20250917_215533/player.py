from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.games_played = 0
        self.total_profit = 0
        self.position = "unknown"
        self.blind_amount = 10
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        
        # Determine position
        if self.id == big_blind_player_id:
            self.position = "big_blind"
        elif self.id == small_blind_player_id:
            self.position = "small_blind"
        else:
            self.position = "button"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Get current betting situation
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - my_current_bet
        
        # Pot odds calculation
        pot_size = round_state.pot + amount_to_call
        pot_odds = amount_to_call / (pot_size + 0.001)  # Add small epsilon to avoid division by zero
        
        # Position factor
        position_factor = 1.0
        if self.position == "button":
            position_factor = 1.1
        elif self.position == "small_blind":
            position_factor = 0.9
            
        # Adjust hand strength based on position and betting round
        adjusted_strength = hand_strength * position_factor
        
        # Betting round adjustments
        if round_state.round == "Preflop":
            adjusted_strength *= 0.8  # Be more conservative preflop
        elif round_state.round == "River":
            adjusted_strength *= 1.2  # Be more confident on river
            
        # Decision logic
        if current_bet == 0:
            # No one has bet yet
            if adjusted_strength >= 0.75:
                # Strong hand - bet for value
                bet_size = max(round_state.min_raise, self.blind_amount * 2)
                bet_size = min(bet_size, remaining_chips)
                if bet_size > 0 and bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif adjusted_strength >= 0.4:
                # Medium hand - check
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # Someone has bet
            if amount_to_call == 0:
                # We've already matched the bet
                return (PokerAction.CHECK, 0)
            elif adjusted_strength >= 0.8:
                # Very strong hand - raise
                raise_amount = max(round_state.min_raise, current_bet)
                total_bet = my_current_bet + raise_amount
                if total_bet <= remaining_chips and raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif adjusted_strength >= 0.5:
                # Good hand - call if pot odds are favorable
                if pot_odds <= 0.3 and amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif adjusted_strength >= 0.3:
                # Marginal hand - call only with great pot odds
                if pot_odds <= 0.15 and amount_to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand - fold
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards or len(hole_cards) != 2:
            return 0.2
            
        all_cards = hole_cards + community_cards
        
        # Parse cards
        parsed_cards = []
        for card in all_cards:
            if len(card) >= 2:
                rank = card[0]
                suit = card[1]
                parsed_cards.append((rank, suit))
        
        if len(parsed_cards) < 2:
            return 0.2
            
        # Preflop evaluation
        if len(community_cards) == 0:
            return self._evaluate_preflop_strength(hole_cards)
        
        # Post-flop evaluation
        return self._evaluate_postflop_strength(parsed_cards)
    
    def _evaluate_preflop_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.2
            
        card1, card2 = hole_cards[0], hole_cards[1]
        if len(card1) < 2 or len(card2) < 2:
            return 0.2
            
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 7)
        val2 = rank_values.get(rank2, 7)
        
        # Premium pairs
        if rank1 == rank2:
            if val1 >= 10:  # TT+
                return 0.9
            elif val1 >= 7:  # 77-99
                return 0.7
            else:  # 22-66
                return 0.5
        
        # Suited hands
        is_suited = suit1 == suit2
        high_val = max(val1, val2)
        low_val = min(val1, val2)
        gap = high_val - low_val
        
        # High card combinations
        if high_val == 14:  # Ace
            if low_val >= 10:  # AK, AQ, AJ, AT
                return 0.85 if is_suited else 0.75
            elif low_val >= 7:  # A9-A7
                return 0.6 if is_suited else 0.4
            else:  # A6-A2
                return 0.5 if is_suited else 0.3
        elif high_val == 13:  # King
            if low_val >= 10:  # KQ, KJ, KT
                return 0.7 if is_suited else 0.6
            elif low_val >= 8:  # K9-K8
                return 0.5 if is_suited else 0.35
        elif high_val >= 11:  # Queen, Jack
            if gap <= 2 and low_val >= 8:
                return 0.6 if is_suited else 0.45
        
        # Connected and suited
        if is_suited:
            if gap <= 1:  # Suited connectors
                return 0.55
            elif gap <= 3:  # Suited one-gappers
                return 0.45
        
        # Default for weak hands
        return 0.25

    def _evaluate_postflop_strength(self, parsed_cards: List[Tuple[str, str]]) -> float:
        if len(parsed_cards) < 5:
            return 0.4
            
        ranks = [card[0] for card in parsed_cards]
        suits = [card[1] for card in parsed_cards]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for strong hands
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Four of a kind
        if max_rank_count >= 4:
            return 0.95
        
        # Full house or three of a kind
        if max_rank_count >= 3:
            if len([count for count in rank_counts.values() if count >= 2]) >= 2:
                return 0.9  # Full house
            else:
                return 0.75  # Three of a kind
        
        # Flush
        if max_suit_count >= 5:
            return 0.8
        
        # Two pair or pair
        pairs = [rank for rank, count in rank_counts.items() if count >= 2]
        if len(pairs) >= 2:
            return 0.65  # Two pair
        elif len(pairs) == 1:
            pair_rank = pairs[0]
            pair_value = rank_values.get(pair_rank, 7)
            if pair_value >= 10:  # High pair
                return 0.6
            else:  # Low pair
                return 0.45
        
        # Check for straight potential
        values = sorted([rank_values.get(rank, 7) for rank in ranks])
        for i in range(len(values) - 4):
            if values[i+4] - values[i] == 4:
                return 0.7  # Straight
        
        # High card
        max_card = max([rank_values.get(rank, 7) for rank in ranks])
        if max_card >= 12:  # King or Ace high
            return 0.4
        else:
            return 0.25

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.games_played += 1
        self.total_profit += player_score