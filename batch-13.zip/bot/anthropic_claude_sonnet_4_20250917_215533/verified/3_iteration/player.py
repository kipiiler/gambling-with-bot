from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.hole_cards = []
        self.game_history = []
        self.opponent_tendencies = {}
        self.position_aggression = {}
        self.hand_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.hole_cards = player_hands
        self.hand_count = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate what we need to call
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        position_factor = self._get_position_factor(round_state)
        pot_odds = self._calculate_pot_odds(round_state, call_amount)
        
        # Adjust strategy based on stack size
        stack_ratio = remaining_chips / max(self.starting_chips, 1)
        
        # More aggressive strategy adjustments
        if round_state.round == "Preflop":
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, position_factor, stack_ratio)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, position_factor, stack_ratio)
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_factor: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # More aggressive preflop ranges
        if hand_strength >= 0.85:  # Premium hands (AA, KK, QQ, AK)
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.8))
                raise_amount = min(raise_amount, round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount < remaining_chips * 0.2:
                if round_state.max_raise > call_amount * 3:
                    raise_amount = max(round_state.min_raise, call_amount * 3)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
                
        elif hand_strength >= 0.7:  # Strong hands (JJ, TT, AQ, AJ, KQ)
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.6))
                raise_amount = min(raise_amount, round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount < remaining_chips * 0.15:
                if position_factor > 0.5 and round_state.max_raise > call_amount * 2:
                    raise_amount = max(round_state.min_raise, call_amount * 2)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.55:  # Decent hands (99, 88, AT, KJ, suited connectors)
            if call_amount == 0:
                if position_factor > 0.3:
                    raise_amount = max(round_state.min_raise, int(round_state.pot * 0.4))
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.08:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.4:  # Marginal hands
            if call_amount == 0:
                if position_factor > 0.7:  # Late position steal attempt
                    raise_amount = max(round_state.min_raise, int(round_state.pot * 0.3))
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.03 and position_factor > 0.5:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            # Weak hands
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, position_factor: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # More aggressive postflop play
        if hand_strength >= 0.8:  # Very strong hands
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.75))
                raise_amount = min(raise_amount, round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount < remaining_chips * 0.3:
                if round_state.max_raise > call_amount * 2:
                    raise_amount = max(round_state.min_raise, call_amount * 2)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
                
        elif hand_strength >= 0.65:  # Strong hands
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.6))
                raise_amount = min(raise_amount, round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif pot_odds > 0.3 or call_amount < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.5:  # Medium hands
            if call_amount == 0:
                if position_factor > 0.5:
                    raise_amount = max(round_state.min_raise, int(round_state.pot * 0.4))
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds > 0.25 or call_amount < remaining_chips * 0.08:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.3:  # Draws and weak pairs
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds > 0.2 or call_amount < remaining_chips * 0.04:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            # Very weak hands
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Basic preflop hand strength
        if round_state.round == "Preflop":
            # Pocket pairs
            if val1 == val2:
                if val1 >= 13:  # AA, KK
                    return 0.95
                elif val1 >= 11:  # QQ, JJ
                    return 0.85
                elif val1 >= 9:  # TT, 99
                    return 0.75
                elif val1 >= 7:  # 88, 77
                    return 0.65
                else:  # 66 and below
                    return 0.55
            
            # Suited cards
            elif suit1 == suit2:
                high_card = max(val1, val2)
                low_card = min(val1, val2)
                
                if high_card == 14:  # Ace suited
                    if low_card >= 12:  # AK, AQ suited
                        return 0.85
                    elif low_card >= 10:  # AJ, AT suited
                        return 0.75
                    elif low_card >= 8:  # A9, A8 suited
                        return 0.65
                    else:
                        return 0.55
                elif high_card >= 12 and low_card >= 10:  # KQ, KJ, QJ suited
                    return 0.7
                elif abs(val1 - val2) <= 1 and low_card >= 8:  # Suited connectors 8+
                    return 0.6
                elif abs(val1 - val2) <= 2 and low_card >= 6:  # Suited one-gappers
                    return 0.5
                else:
                    return 0.4
            
            # Offsuit cards
            else:
                high_card = max(val1, val2)
                low_card = min(val1, val2)
                
                if high_card == 14 and low_card >= 12:  # AK, AQ offsuit
                    return 0.8
                elif high_card == 14 and low_card >= 10:  # AJ, AT offsuit
                    return 0.65
                elif high_card >= 12 and low_card >= 11:  # KQ, KJ offsuit
                    return 0.6
                elif high_card >= 11 and low_card >= 9:  # QJ, QT, JT offsuit
                    return 0.5
                else:
                    return 0.35
        
        # Postflop evaluation with community cards
        else:
            all_cards = self.hole_cards + round_state.community_cards
            return self._evaluate_postflop_strength(all_cards)
    
    def _evaluate_postflop_strength(self, all_cards: List[str]) -> float:
        if len(all_cards) < 5:
            return 0.5
            
        # Simple postflop evaluation
        ranks = []
        suits = []
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in all_cards:
            if len(card) >= 2:
                ranks.append(rank_values.get(card[0], 2))
                suits.append(card[1])
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for various hands
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Four of a kind
        if max_rank_count >= 4:
            return 0.95
        
        # Full house
        if max_rank_count >= 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
            return 0.9
        
        # Flush
        if max_suit_count >= 5:
            return 0.85
        
        # Straight check (simplified)
        sorted_ranks = sorted(set(ranks))
        straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                straight = True
                break
        
        if straight:
            return 0.8
        
        # Three of a kind
        if max_rank_count >= 3:
            return 0.75
        
        # Two pair
        pairs = [rank for rank, count in rank_counts.items() if count >= 2]
        if len(pairs) >= 2:
            return 0.7
        
        # One pair
        if len(pairs) == 1:
            if pairs[0] >= 11:  # High pair
                return 0.65
            else:
                return 0.55
        
        # High card
        high_card = max(ranks) if ranks else 2
        if high_card >= 13:
            return 0.45
        elif high_card >= 11:
            return 0.35
        else:
            return 0.25
    
    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        num_players = len(round_state.current_player)
        if num_players <= 1:
            return 0.5
        
        # In heads-up, position alternates
        if num_players == 2:
            return 0.7  # Assume good position in heads-up
        
        # For multi-way, estimate position based on player order
        return 0.5  # Default middle position
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        if call_amount <= 0:
            return 1.0
        
        total_pot = round_state.pot + call_amount
        if total_pot <= 0:
            return 0.0
            
        return min(1.0, call_amount / total_pot)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track results for learning
        delta = remaining_chips - self.starting_chips
        self.game_history.append({
            'round_num': round_state.round_num,
            'final_pot': round_state.pot,
            'delta': delta,
            'hand': self.hole_cards.copy() if self.hole_cards else []
        })
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, could analyze performance here
        pass