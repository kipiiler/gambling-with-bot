from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.opponent_actions = []
        self.opponent_aggression = 0.5
        self.position_advantage = False
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.position_advantage = (big_blind_player_id == self.id)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            # Extract our hole cards from community cards or tracking
            self.remaining_chips = remaining_chips
            self.opponent_actions = []
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent modeling
        self._update_opponent_model(round_state)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001) if round_state.pot > 0 else 0
        
        # Determine action based on hand strength and situation
        if hand_strength >= 0.85:  # Very strong hand
            return self._aggressive_action(round_state, remaining_chips)
        elif hand_strength >= 0.65:  # Strong hand
            return self._value_bet_action(round_state, remaining_chips, call_amount)
        elif hand_strength >= 0.4:  # Medium hand
            return self._medium_hand_action(round_state, remaining_chips, call_amount, pot_odds)
        elif hand_strength >= 0.25 and self._should_bluff(round_state):  # Bluff opportunity
            return self._bluff_action(round_state, remaining_chips)
        else:  # Weak hand
            return self._weak_hand_action(round_state, call_amount, pot_odds)
    
    def _update_opponent_model(self, round_state: RoundStateClient):
        # Track opponent aggression
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression = min(1.0, self.opponent_aggression + 0.1)
                elif action in ['Check', 'Call']:
                    self.opponent_aggression = max(0.0, self.opponent_aggression - 0.05)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        # This is a simplified hand evaluation
        # In a real implementation, you'd want proper hand evaluation
        
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength()
        else:
            return self._postflop_hand_strength(round_state.community_cards)
    
    def _preflop_hand_strength(self) -> float:
        # Simplified preflop hand evaluation
        # This would need to be enhanced with actual hole cards
        return 0.5  # Placeholder - would evaluate based on actual hole cards
    
    def _postflop_hand_strength(self, community_cards: List[str]) -> float:
        # Simplified postflop evaluation
        # This would need proper hand ranking logic
        if len(community_cards) >= 3:
            # Basic evaluation based on community cards
            suits = [card[1] for card in community_cards]
            ranks = [card[0] for card in community_cards]
            
            # Check for potential strong hands
            if len(set(suits)) <= 2:  # Flush potential
                return 0.6
            if len(set(ranks)) <= 2:  # Pair potential
                return 0.55
            
        return 0.4  # Default medium strength
    
    def _aggressive_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # With very strong hands, bet aggressively
        if round_state.current_bet == 0:
            bet_size = min(round_state.pot * 0.75, remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, int(bet_size))
            else:
                return (PokerAction.CHECK, 0)
        else:
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if call_amount < remaining_chips * 0.3:
                # Raise if not too expensive
                raise_size = min(round_state.current_bet * 2, remaining_chips)
                if raise_size >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
    
    def _value_bet_action(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        # With strong hands, bet for value
        if round_state.current_bet == 0:
            bet_size = min(round_state.pot * 0.6, remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, int(bet_size))
            else:
                return (PokerAction.CHECK, 0)
        else:
            if call_amount < remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _medium_hand_action(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        # With medium hands, play more cautiously
        if round_state.current_bet == 0:
            if round_state.round == 'Preflop' and self.position_advantage:
                bet_size = min(round_state.pot * 0.4, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, int(bet_size))
            return (PokerAction.CHECK, 0)
        else:
            if pot_odds < 0.3 and call_amount < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _should_bluff(self, round_state: RoundStateClient) -> bool:
        # Bluff occasionally, especially in late rounds with passive opponents
        if round_state.round in ['Turn', 'River'] and self.opponent_aggression < 0.4:
            return len(round_state.current_player) <= 2  # Only in heads-up
        return False
    
    def _bluff_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Execute a bluff
        if round_state.current_bet == 0:
            bet_size = min(round_state.pot * 0.8, remaining_chips * 0.3)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, int(bet_size))
        return (PokerAction.CHECK, 0)
    
    def _weak_hand_action(self, round_state: RoundStateClient, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        # With weak hands, fold unless pot odds are very favorable
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        else:
            if pot_odds < 0.2 and call_amount <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game results for learning
        delta = remaining_chips - self.remaining_chips
        self.game_history.append({
            'round': round_state.round_num,
            'delta': delta,
            'opponent_aggression': self.opponent_aggression
        })
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Adjust strategy based on game results
        if player_score < 0:
            # If we lost, become slightly more aggressive
            self.opponent_aggression = max(0.3, self.opponent_aggression - 0.1)
        else:
            # If we won, maintain current strategy
            pass