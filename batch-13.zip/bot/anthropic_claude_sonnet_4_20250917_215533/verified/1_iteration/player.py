from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.opponent_stats = {}
        self.position_stats = {}
        self.game_history = []
        self.current_round_actions = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'vpip': 0.5,  # Voluntarily put money in pot
                    'pfr': 0.3,   # Pre-flop raise
                    'aggression': 0.4,
                    'hands_played': 0,
                    'total_hands': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.current_round_actions = []
            for player_id in self.all_players:
                if player_id != self.id and player_id in self.opponent_stats:
                    self.opponent_stats[player_id]['total_hands'] += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate how much we need to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Hand strength evaluation
            hand_strength = self._evaluate_hand_strength(round_state)
            pot_odds = self._calculate_pot_odds(round_state, call_amount, remaining_chips)
            position_factor = self._get_position_factor(round_state)
            opponent_aggression = self._analyze_opponent_aggression(round_state)
            
            # Betting decision logic
            decision_score = hand_strength + pot_odds + position_factor - opponent_aggression
            
            # Bluff factor
            bluff_chance = self._calculate_bluff_probability(round_state, hand_strength)
            
            if random.random() < bluff_chance and hand_strength < 0.3:
                decision_score += 0.4
            
            # Action selection based on decision score
            if call_amount == 0:
                # We can check
                if decision_score > 0.6:
                    # Strong hand, bet/raise
                    bet_size = max(round_state.min_raise, int(round_state.pot * 0.3))
                    if bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif decision_score > 0.2:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)  # Check with weak hands when possible
            else:
                # Need to call or fold
                if decision_score > 0.7:
                    # Very strong hand, raise
                    raise_amount = max(round_state.min_raise, call_amount + int(round_state.pot * 0.5))
                    if raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif decision_score > 0.4 or pot_odds > 0.3:
                    # Good hand or good pot odds, call
                    if call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    # Weak hand, fold
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Emergency fallback
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hand:
            return 0.3
            
        try:
            # Pre-flop hand evaluation
            if round_state.round == 'Preflop':
                return self._evaluate_preflop_hand()
            
            # Post-flop evaluation
            return self._evaluate_postflop_hand(round_state.community_cards)
            
        except:
            return 0.3

    def _evaluate_preflop_hand(self) -> float:
        if len(self.hand) < 2:
            return 0.3
            
        try:
            card1, card2 = self.hand[0], self.hand[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Convert face cards to numbers
            rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
            val1 = rank_values.get(rank1, int(rank1)) if rank1.isdigit() else rank_values.get(rank1, 10)
            val2 = rank_values.get(rank2, int(rank2)) if rank2.isdigit() else rank_values.get(rank2, 10)
            
            high_val = max(val1, val2)
            low_val = min(val1, val2)
            
            # Premium hands
            if (val1 >= 10 and val2 >= 10):  # High cards
                if val1 == val2:  # Pocket pair
                    return 0.9
                elif suit1 == suit2:  # Suited
                    return 0.8
                else:
                    return 0.7
            
            # Pocket pairs
            if val1 == val2:
                if val1 >= 8:
                    return 0.8
                elif val1 >= 5:
                    return 0.6
                else:
                    return 0.4
            
            # Suited hands
            if suit1 == suit2:
                if high_val >= 12:  # High suited
                    return 0.7
                elif high_val >= 9:
                    return 0.5
                else:
                    return 0.3
            
            # Connected cards
            if abs(val1 - val2) <= 3:
                if high_val >= 10:
                    return 0.5
                else:
                    return 0.3
            
            # Default for weak hands
            return 0.2
            
        except:
            return 0.3

    def _evaluate_postflop_hand(self, community_cards: List[str]) -> float:
        if not community_cards:
            return self._evaluate_preflop_hand()
            
        try:
            all_cards = self.hand + community_cards
            return self._calculate_hand_strength(all_cards)
        except:
            return 0.3

    def _calculate_hand_strength(self, cards: List[str]) -> float:
        if len(cards) < 5:
            return 0.3
            
        try:
            # Simple hand strength calculation
            ranks = []
            suits = []
            
            rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
            
            for card in cards:
                rank = card[0]
                suit = card[1]
                val = rank_values.get(rank, int(rank)) if rank.isdigit() else rank_values.get(rank, 10)
                ranks.append(val)
                suits.append(suit)
            
            rank_counts = {}
            suit_counts = {}
            
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            # Check for various hands
            max_rank_count = max(rank_counts.values()) if rank_counts else 0
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            
            # Four of a kind
            if max_rank_count >= 4:
                return 0.95
            
            # Full house or three of a kind
            if max_rank_count >= 3:
                if len([count for count in rank_counts.values() if count >= 2]) >= 2:
                    return 0.9  # Full house
                else:
                    return 0.7  # Three of a kind
            
            # Flush
            if max_suit_count >= 5:
                return 0.8
            
            # Straight check (simplified)
            sorted_ranks = sorted(set(ranks), reverse=True)
            if len(sorted_ranks) >= 5:
                for i in range(len(sorted_ranks) - 4):
                    if sorted_ranks[i] - sorted_ranks[i+4] == 4:
                        return 0.75
            
            # Two pair or pair
            pair_count = len([count for count in rank_counts.values() if count >= 2])
            if pair_count >= 2:
                return 0.6  # Two pair
            elif pair_count == 1:
                max_pair_rank = max([rank for rank, count in rank_counts.items() if count >= 2])
                if max_pair_rank >= 10:
                    return 0.5  # High pair
                else:
                    return 0.3  # Low pair
            
            # High card
            return min(0.4, max(ranks) / 35.0) if ranks else 0.2
            
        except:
            return 0.3

    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int, remaining_chips: int) -> float:
        if call_amount <= 0:
            return 0.3
            
        try:
            pot_size = round_state.pot + call_amount
            if pot_size <= 0:
                return 0.0
                
            pot_odds = call_amount / (pot_size + 1e-6)
            
            # Adjust for stack size
            if call_amount > remaining_chips * 0.5:
                return pot_odds * 0.5  # Reduce value for large bets
            elif call_amount < remaining_chips * 0.1:
                return pot_odds * 1.5  # Increase value for small bets
            
            return min(0.5, 1.0 - pot_odds)
            
        except:
            return 0.0

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        try:
            num_players = len(self.all_players)
            if num_players <= 1:
                return 0.0
                
            # Simple position evaluation
            if self.id == self.big_blind_player:
                return -0.1  # Big blind is generally bad position
            elif self.id == self.small_blind_player:
                return -0.05  # Small blind is also bad position
            else:
                return 0.1  # Other positions are better
                
        except:
            return 0.0

    def _analyze_opponent_aggression(self, round_state: RoundStateClient) -> float:
        try:
            aggression_factor = 0.0
            
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    if action in ['Raise', 'All-in']:
                        aggression_factor += 0.2
                    elif action == 'Call':
                        aggression_factor += 0.05
            
            return min(0.4, aggression_factor)
            
        except:
            return 0.0

    def _calculate_bluff_probability(self, round_state: RoundStateClient, hand_strength: float) -> float:
        try:
            # Bluff more on later streets with weak hands
            if round_state.round == 'River' and hand_strength < 0.3:
                return 0.2
            elif round_state.round == 'Turn' and hand_strength < 0.25:
                return 0.15
            elif round_state.round == 'Flop' and hand_strength < 0.2:
                return 0.1
            else:
                return 0.05
                
        except:
            return 0.05

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent statistics based on actions
        try:
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    if action in ['Call', 'Raise', 'All-in']:
                        self.opponent_stats[player_id]['hands_played'] += 1
                    
                    if action in ['Raise', 'All-in']:
                        self.opponent_stats[player_id]['aggression'] = min(1.0, 
                            self.opponent_stats[player_id]['aggression'] * 0.9 + 0.1)
        except:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Store game results for future analysis
        try:
            self.game_history.append({
                'score': player_score,
                'final_round': round_state.round_num
            })
        except:
            pass