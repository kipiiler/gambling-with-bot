from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.big_blind_amount = 0
        self.opponent_id = None
        self.game_history = []
        self.hand_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        # Find opponent ID
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_id = player_id
                break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round_num == 1:  # New hand
            self.hand_count += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate current bet we need to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # If we can check (no bet to call), prefer checking or small bets
            if call_amount == 0:
                hand_strength = self._evaluate_hand_strength(round_state)
                
                if hand_strength >= 0.7:  # Strong hand
                    # Make a reasonable bet (pot-sized or smaller)
                    bet_amount = max(round_state.min_raise, round_state.pot // 2)
                    bet_amount = min(bet_amount, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                
                return (PokerAction.CHECK, 0)
            
            # We need to call some amount
            if call_amount > remaining_chips:
                # We can't afford the call, go all-in if hand is decent
                hand_strength = self._evaluate_hand_strength(round_state)
                if hand_strength >= 0.4:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Decide action based on hand strength and pot odds
            hand_strength = self._evaluate_hand_strength(round_state)
            pot_odds = call_amount / (round_state.pot + call_amount + 1e-6)  # Avoid division by zero
            
            # Conservative play - only play strong hands aggressively
            if hand_strength >= 0.8:  # Very strong hand
                # Raise with strong hands
                raise_amount = max(round_state.min_raise, call_amount * 2)
                raise_amount = min(raise_amount, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
                    
            elif hand_strength >= 0.5:  # Decent hand
                # Call with decent hands if pot odds are reasonable
                if pot_odds <= 0.3:  # Good pot odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif hand_strength >= 0.3:  # Marginal hand
                # Only call if pot odds are very good
                if pot_odds <= 0.15:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand - fold
                return (PokerAction.FOLD, 0)
                
        except Exception as e:
            # Fallback: play conservatively
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 10:  # Small bet
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        try:
            # Parse hole cards
            card1, card2 = self.hole_cards[0], self.hole_cards[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Convert ranks to numerical values
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                          '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            
            val1 = rank_values.get(rank1, 7)
            val2 = rank_values.get(rank2, 7)
            
            # Base strength calculation
            strength = 0.0
            
            # Pair bonus
            if val1 == val2:
                if val1 >= 10:  # High pair (T, J, Q, K, A)
                    strength = 0.8
                elif val1 >= 7:  # Medium pair
                    strength = 0.6
                else:  # Low pair
                    strength = 0.4
            else:
                # High cards
                high_card = max(val1, val2)
                low_card = min(val1, val2)
                
                if high_card == 14:  # Ace
                    if low_card >= 10:
                        strength = 0.7  # A-K, A-Q, A-J, A-T
                    elif low_card >= 7:
                        strength = 0.5  # A-9, A-8, A-7
                    else:
                        strength = 0.3  # Low ace
                elif high_card >= 12:  # King or Queen
                    if low_card >= 10:
                        strength = 0.5  # K-Q, K-J, etc.
                    else:
                        strength = 0.3
                elif high_card >= 10:  # Jack or Ten
                    if low_card >= 8:
                        strength = 0.4
                    else:
                        strength = 0.2
                else:
                    strength = 0.1  # Low cards
                
                # Suited bonus
                if suit1 == suit2:
                    strength += 0.1
                
                # Connected cards bonus
                if abs(val1 - val2) == 1:
                    strength += 0.1
            
            # Adjust based on position and game stage
            if round_state.round == "Preflop":
                pass  # Use base strength
            elif round_state.round in ["Flop", "Turn", "River"]:
                # On later streets, be more conservative without specific hand evaluation
                strength *= 0.8
            
            return min(1.0, max(0.0, strength))
            
        except Exception:
            return 0.3  # Conservative default

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game history for learning
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Store game results for future improvement
        self.game_history.append({
            'score': player_score,
            'hands_played': self.hand_count
        })