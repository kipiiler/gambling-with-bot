from __future__ import annotations

import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_STR_TO_INT = {
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "T": 10,
    "J": 11,
    "Q": 12,
    "K": 13,
    "A": 14,
}

INT_TO_RANK_STR = {v: k for k, v in RANK_STR_TO_INT.items()}


class SimplePlayer(Bot):
    """
    A very light-weight rule based Texas Hold’em bot.

    The bot tries to (1) avoid making illegal moves, (2) play a sensible
    pre-flop range heads-up, and (3) use a simple hand evaluator post-flop to
    decide whether to be aggressive or fold/check.  All computation is pure
    Python and respects the very small memory / time limits of the contest
    backend.
    """

    # ----- LIFE-CYCLE HOOKS -------------------------------------------------
    def __init__(self) -> None:
        super().__init__()
        self.starting_chips: int | None = None
        self.big_blind: int | None = None
        self.small_blind: int | None = None
        self.all_players: List[int] | None = None

        # hand information updated every round
        self.hole_cards: List[str] = []

    #
    # Called exactly once at the beginning of the entire match
    #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.all_players = all_players
        # The very first hand is also transmitted here
        self.hole_cards = list(player_hands)

    #
    # Called at the beginning of every new hand
    #
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Retrieve fresh hole cards if provided in the round_state
        self.hole_cards = self._extract_hole_cards(round_state) or self.hole_cards

    #
    # MAIN DECISION FUNCTION -------------------------------------------------
    #
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision logic.  The bot first builds a list of *valid* actions
        given the server’s current game state and then chooses an action
        according to a hand-strength heuristic.
        """
        # --- determine our current investment --------------------------------
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = max(0, round_state.current_bet - my_bet)

        # ----------------------------------------------------------------------
        # Determine our wanted action given the phase
        # ----------------------------------------------------------------------
        desired_action: PokerAction
        raise_to_amount: int = 0  # default for non-raise actions

        if round_state.round.lower() == "preflop":
            desired_action, raise_to_amount = self._decide_preflop(
                to_call, round_state
            )
        else:
            community = round_state.community_cards
            desired_action, raise_to_amount = self._decide_postflop(
                to_call, community, round_state
            )

        # ----------------------------------------------------------------------
        # Validate the chosen action; fallback safely if invalid
        # ----------------------------------------------------------------------
        valid_action = self._ensure_valid_action(
            desired_action, raise_to_amount, round_state, to_call, remaining_chips
        )
        return valid_action

    #
    # Called at showdown / hand end
    #
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing to record for this very light bot
        pass

    #
    # Called once when the table breaks
    #
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict[str, List[str]],
    ):
        # No persistent state to keep
        pass

    # ======================================================================
    # ------------------------  STRATEGY PART  ------------------------------
    # ======================================================================

    # ----------------------------------------------------------------------
    # Pre-flop
    # ----------------------------------------------------------------------
    def _decide_preflop(
        self, to_call: int, round_state: RoundStateClient
    ) -> Tuple[PokerAction, int]:
        """Very rough heads-up opening strategy using a Chen-like score."""
        chen = self._chen_score(self.hole_cards)

        # Determine aggressive / tight thresholds
        strong_threshold = 10  # raise / 3-bet
        medium_threshold = 7   # call / small raise
        weak_threshold = 5     # limp if free; otherwise fold

        # current pot odds simple
        cheap = to_call <= self.big_blind

        # raise sizing heuristic
        pot_before = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        target_raise = round_state.current_bet + max(
            min_raise, int(self.big_blind * 3)
        )
        target_raise = min(target_raise, max_raise)

        if chen >= strong_threshold:  # strong hand
            if to_call == 0:
                return PokerAction.RAISE, target_raise
            if target_raise <= max_raise:
                return PokerAction.RAISE, target_raise
            else:
                return PokerAction.CALL, 0
        elif chen >= medium_threshold:
            if to_call == 0:
                # take initiative sometimes
                if random.random() < 0.5:
                    return PokerAction.RAISE, target_raise
                return PokerAction.CHECK, 0
            elif cheap:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif chen >= weak_threshold:
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif cheap and random.random() < 0.2:
                # defend blinds a little
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # Very weak
            if to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    # ----------------------------------------------------------------------
    # Post-flop
    # ----------------------------------------------------------------------
    def _decide_postflop(
        self,
        to_call: int,
        community_cards: List[str],
        round_state: RoundStateClient,
    ) -> Tuple[PokerAction, int]:
        complete_cards = self.hole_cards + community_cards
        category = self._hand_category(complete_cards)

        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        target_raise = round_state.current_bet + max(
            min_raise, int(round_state.pot * 0.7)  # ~pot raise
        )
        target_raise = min(target_raise, max_raise)

        # Aggression table by category
        # 8: straight flush, 7: quads, 6: full house, etc.
        if category >= 6:  # boat or better
            if target_raise < max_raise * 0.5:
                return PokerAction.RAISE, target_raise
            else:
                return PokerAction.ALL_IN, 0
        elif category == 5:  # flush
            if to_call == 0:
                return PokerAction.RAISE, target_raise
            elif to_call <= round_state.pot * 0.25:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif category == 4 or category == 3:  # straight or trips
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= round_state.pot * 0.2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif category == 2:  # two pair
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= round_state.pot * 0.15:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif category == 1:  # single pair
            if to_call == 0:
                # occasionally stab
                if random.random() < 0.3 and round_state.current_bet == 0:
                    return PokerAction.RAISE, target_raise
                return PokerAction.CHECK, 0
            elif to_call <= round_state.pot * 0.1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:  # high card
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    # ======================================================================
    # ----------------------  RULE COMPLIANCE HELPERS -----------------------
    # ======================================================================

    def _ensure_valid_action(
        self,
        desired_action: PokerAction,
        raise_to_amount: int,
        round_state: RoundStateClient,
        to_call: int,
        remaining_chips: int,
    ) -> Tuple[PokerAction, int]:
        """
        Validate desired action against the current game rules and fallback
        safely to the next-best legal alternative if required.
        """
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Helper lambdas -------------------------------------------------------
        def can_check() -> bool:
            return to_call == 0

        def legal_raise(amount: int) -> bool:
            # amount must be within [current_bet + min_raise, max_raise]
            return (
                amount is not None
                and current_bet + min_raise <= amount <= max_raise
                and amount <= remaining_chips
            )

        # ----------------------------------------------------------------------
        if desired_action == PokerAction.CHECK:
            if can_check():
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        if desired_action == PokerAction.CALL:
            if to_call <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, 0

        if desired_action == PokerAction.RAISE:
            if legal_raise(raise_to_amount):
                return PokerAction.RAISE, raise_to_amount
            # Try to downgrade to CALL or CHECK
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        if desired_action == PokerAction.ALL_IN:
            return PokerAction.ALL_IN, 0

        # Fallback
        return PokerAction.FOLD, 0

    # ======================================================================
    # --------------------------  UTILITIES ---------------------------------
    # ======================================================================

    # ------------ Extract hole cards from (possibly) varying field names ----
    @staticmethod
    def _extract_hole_cards(round_state: RoundStateClient) -> List[str] | None:
        possible_fields = ["hole_cards", "player_hands", "playerHands", "hand"]
        for field in possible_fields:
            if hasattr(round_state, field):
                data = getattr(round_state, field)
                # If the structure is {player_id: [c1,c2]}
                if isinstance(data, dict):
                    my_id = str(getattr(round_state, "player_id", None))
                    if my_id in data:
                        return data[my_id]
                # If it is already a list
                if isinstance(data, list) and len(data) == 2:
                    return data
        return None

    # ------------  Simple Chen formula approximation ------------------------
    def _chen_score(self, cards: List[str]) -> float:
        """Approximate hand value.  Works only pre-flop."""
        if len(cards) != 2:
            return 0.0
        r1 = RANK_STR_TO_INT[cards[0][0]]
        r2 = RANK_STR_TO_INT[cards[1][0]]

        # Order so that r1 >= r2
        if r2 > r1:
            r1, r2 = r2, r1

        def rank_to_points(rank: int) -> float:
            if rank == 14:
                return 10
            elif rank == 13:
                return 8
            elif rank == 12:
                return 7
            elif rank == 11:
                return 6
            elif rank == 10:
                return 5
            else:
                return (rank - 2) / 2  # 9 -> 3.5 … 2 -> 0

        score = rank_to_points(r1)

        # Pair bonus
        if r1 == r2:
            score = max(5, score * 2)
            if r1 >= 5:
                score += 2

        # Suited bonus
        if cards[0][1] == cards[1][1]:
            score += 2

        # Gap penalty
        gap = r1 - r2 - 1
        if gap == 0:
            score += 1
        elif gap == 1:
            score += 0
        elif gap == 2:
            score -= 1
        elif gap == 3:
            score -= 2
        elif gap >= 4:
            score -= 4

        # Straight and wheel bonus (AKQJT or 5432A possibilities)
        if gap <= 1 and min(r1, r2) >= 10:
            score += 1

        return max(score, 0)

    # ------------  Hand category evaluator ----------------------------------
    def _hand_category(self, cards: List[str]) -> int:
        """
        Very lightweight 7-card evaluator returning only the *category*
        (not kicker strength).  The categories are encoded numerically:

          8 = straight flush
          7 = four of a kind
          6 = full house
          5 = flush
          4 = straight
          3 = three of a kind
          2 = two pair
          1 = one pair
          0 = high card
        """
        ranks = [c[0] for c in cards]
        suits = [c[1] for c in cards]

        rank_counts: Dict[int, int] = {}
        suit_counts: Dict[str, List[int]] = {}

        for card in cards:
            r = RANK_STR_TO_INT[card[0]]
            s = card[1]
            rank_counts[r] = rank_counts.get(r, 0) + 1
            suit_counts.setdefault(s, []).append(r)

        # ---------- Straight flush / flush detection -------------------------
        flush_suit = None
        for s, lst in suit_counts.items():
            if len(lst) >= 5:
                flush_suit = s
                break

        def _has_straight(ranks_list: List[int]) -> bool:
            unique_ranks = sorted(set(ranks_list))
            # Wheel possibility
            if {14, 5, 4, 3, 2}.issubset(unique_ranks):
                return True
            for i in range(len(unique_ranks) - 4):
                if (
                    unique_ranks[i]
                    + 4
                    == unique_ranks[i + 4]
                    and len(set(unique_ranks[i : i + 5])) == 5
                ):
                    return True
            return False

        # Straight flush
        if flush_suit:
            if _has_straight(suit_counts[flush_suit]):
                return 8  # straight flush

        # Four-of-a-kind
        if 4 in rank_counts.values():
            return 7

        # Full house
        triples = [r for r, c in rank_counts.items() if c == 3]
        pairs = [r for r, c in rank_counts.items() if c == 2]
        if triples and (len(triples) >= 2 or pairs):
            return 6

        # Flush
        if flush_suit:
            return 5

        # Straight
        if _has_straight([RANK_STR_TO_INT[r] for r in ranks]):
            return 4

        # Three-of-a-kind
        if triples:
            return 3

        # Two pair
        if len(pairs) >= 2:
            return 2

        # One pair
        if pairs:
            return 1

        return 0  # high card