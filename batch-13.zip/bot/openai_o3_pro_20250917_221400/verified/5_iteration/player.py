# player.py
from typing import List, Tuple, Dict
from collections import Counter
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

RANK_ORDER = "23456789TJQKA"
RANK_VALUE: Dict[str, int] = {r: i for i, r in enumerate(RANK_ORDER, start=2)}  # 2 -> 2, A -> 14


class SimplePlayer(Bot):
    """
    A very light-weight, no-dependency Texas Hold’em bot that uses:
        •  Simple pre-flop starting-hand chart
        •  Naïve post-flop made-hand detector (pair / two-pair / trips / flush / straight)
        •  Pot-sized bet sizing heuristics
    The goal is to stop bleeding blinds versus aggressive default opponents while still
    keeping the implementation small and 100 % compatible with the competition framework.
    """
    # ------------ public API required by competition --------------------------
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.big_blind = 0
        self.all_players: List[int] = []
        self.my_hole_cards: List[str] = []

    # ------------------- framework callbacks ----------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.all_players = all_players
        # We only know our own hole cards – they are passed as list[str]
        # (two cards, e.g. ["Ah", "Kd"])
        self.my_hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Hole cards may be refreshed every round depending on the real server implementation.
        self.my_hole_cards = self._extract_my_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine – chooses between FOLD / CHECK / CALL / RAISE / ALL_IN.
        The integer part of the tuple is ignored for FOLD / CHECK / CALL / ALL_IN,
        but must be supplied (0 is fine).
        """
        # Safety – never exceed remaining chips
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0

        stage = round_state.round.lower()  # 'preflop', 'flop', 'turn', 'river'
        my_bet = round_state.player_bets.get(str(self.id), 0) or round_state.player_bets.get(
            self.id, 0
        )
        to_call = max(round_state.current_bet - my_bet, 0)

        if stage == "preflop":
            return self._preflop_decision(round_state, remaining_chips, to_call)
        else:
            return self._postflop_decision(round_state, remaining_chips, to_call)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset cached cards
        self.my_hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # Nothing persistent to clean up

    # --------------------- decision helpers -----------------------------------
    # ---- pre-flop ------------------------------------------------------------
    def _preflop_decision(
        self, rs: RoundStateClient, stack: int, to_call: int
    ) -> Tuple[PokerAction, int]:
        strength = self._classify_preflop_strength(self.my_hole_cards)
        # First, can we check?
        if to_call == 0:
            if strength == "strong":
                # Open for 4× big blind or pot if multi-way
                raise_to = self._bounded_raise(rs, amount=self.big_blind * 4)
                return PokerAction.RAISE, raise_to
            elif strength == "medium":
                # Open-limp or small raise
                if rs.min_raise <= self.big_blind * 2:
                    raise_to = self._bounded_raise(rs, amount=self.big_blind * 2)
                    return PokerAction.RAISE, raise_to
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0

        # There is a bet to us (heads-up default bot min-raises a lot)
        if strength == "strong":
            # Re-raise (3-bet) to 3× opponent bet when affordable
            raise_to = self._bounded_raise(rs, amount=rs.current_bet * 3)
            # If stack shallow we might just call
            if raise_to <= rs.current_bet:  # cannot raise legally – just call
                return PokerAction.CALL, 0
            return PokerAction.RAISE, raise_to
        elif strength == "medium":
            # Call if inexpensive (≤4 bb); otherwise fold
            if to_call <= self.big_blind * 4:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else:  # weak hand
            # Defend big blind tighter: call if we already have 50 % invested
            invested = to_call / max(self.big_blind, 1)
            if invested <= 1:  # min-raise – peel one
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    # ---- post-flop -----------------------------------------------------------
    def _postflop_decision(
        self, rs: RoundStateClient, stack: int, to_call: int
    ) -> Tuple[PokerAction, int]:
        board = rs.community_cards
        hand_cat = self._analyze_made_hand(self.my_hole_cards, board)

        # Determine aggressive action if nobody bet
        if to_call == 0:
            if hand_cat in {"very_strong", "strong"}:
                bet_size = min(int(rs.pot * 0.75) + rs.current_bet, stack, rs.max_raise)
                bet_size = self._bounded_raise(rs, amount=max(bet_size, rs.min_raise + rs.current_bet))
                return PokerAction.RAISE, bet_size
            elif hand_cat == "medium":
                bet_size = min(int(rs.pot * 0.5) + rs.current_bet, stack, rs.max_raise)
                if bet_size >= rs.current_bet + rs.min_raise:
                    bet_size = self._bounded_raise(rs, amount=bet_size)
                    return PokerAction.RAISE, bet_size
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0

        # Somebody bet – decide whether to continue
        call_fraction_of_pot = to_call / max(rs.pot, 1)
        if hand_cat in {"very_strong", "strong"}:
            # Continue aggressively
            if to_call >= stack:  # Opponent all-in – call off
                return PokerAction.CALL, 0
            # Small raise for value
            raise_to = self._bounded_raise(rs, amount=rs.current_bet + rs.min_raise * 2)
            if raise_to > rs.current_bet:
                return PokerAction.RAISE, raise_to
            return PokerAction.CALL, 0
        elif hand_cat == "medium":
            if call_fraction_of_pot <= 0.5 and to_call <= stack * 0.2:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else:  # weak hand / draw
            if call_fraction_of_pot <= 0.2 and to_call <= self.big_blind * 2:
                return PokerAction.CALL, 0  # cheap bluff-catch or see turn card
            return PokerAction.FOLD, 0

    # ------------------------ poker logic helpers -----------------------------
    def _classify_preflop_strength(self, cards: List[str]) -> str:
        """Return 'strong', 'medium', 'weak' according to hard-coded chart."""
        if len(cards) != 2:
            return "weak"
        r1, s1 = cards[0][0], cards[0][1]
        r2, s2 = cards[1][0], cards[1][1]
        suited = s1 == s2
        pair = r1 == r2
        high_card = max(RANK_VALUE[r1], RANK_VALUE[r2])

        strong_pairs = {"A", "K", "Q", "J", "T"}
        medium_pairs = {"9", "8", "7"}

        if pair and r1 in strong_pairs:
            return "strong"
        if pair and r1 in medium_pairs:
            return "medium"

        # Specific premium non-pair
        premium_suited = {("A", "K"), ("A", "Q"), ("K", "Q")}
        offsuit_premium = {("A", "K")}

        ranks_set = tuple(sorted([r1, r2], key=lambda r: RANK_VALUE[r], reverse=True))
        if suited and ranks_set in premium_suited:
            return "strong"
        if ranks_set in offsuit_premium:
            return "strong"

        # All broadway suited (both cards ≥T) are at least medium
        if suited and RANK_VALUE[r1] >= 10 and RANK_VALUE[r2] >= 10:
            return "medium"
        # Ax suited down to A-9s
        if suited and "A" in (r1, r2):
            low = r2 if r1 == "A" else r1
            if RANK_VALUE[low] >= 9:
                return "medium"

        # Suited connectors 98s – 54s
        if suited and abs(RANK_VALUE[r1] - RANK_VALUE[r2]) == 1:
            if max(RANK_VALUE[r1], RANK_VALUE[r2]) >= 8:
                return "medium"

        # High card strength
        if high_card >= 12:  # Q or higher
            return "medium"

        return "weak"

    def _analyze_made_hand(self, hole: List[str], board: List[str]) -> str:
        """
        Very light evaluator – only detects: straight / flush / trips / two-pair / pair.
        Returns one of: 'very_strong', 'strong', 'medium', 'weak'
        """
        all_cards = hole + board
        ranks = [c[0] for c in all_cards]
        suits = [c[1] for c in all_cards]
        rank_counter = Counter(ranks)
        suit_counter = Counter(suits)

        # Flush (5 cards same suit)
        has_flush = any(v >= 5 for v in suit_counter.values())

        # Straight – generate unique sorted rank values, handling wheel A-5
        rank_vals = sorted({RANK_VALUE[r] for r in ranks})
        has_straight = False
        if len(rank_vals) >= 5:
            for i in range(len(rank_vals) - 4):
                if rank_vals[i + 4] - rank_vals[i] == 4:
                    has_straight = True
                    break
            # Wheel straight (A-2-3-4-5)
            if {14, 5, 4, 3, 2}.issubset(rank_vals):
                has_straight = True

        four_kind = any(v == 4 for v in rank_counter.values())
        trips = [r for r, v in rank_counter.items() if v == 3]
        pairs = [r for r, v in rank_counter.items() if v == 2]

        full_house = bool(trips) and bool(pairs)
        three_kind = bool(trips)
        two_pair = len(pairs) >= 2
        one_pair = len(pairs) == 1

        # Categorise
        if four_kind or full_house or (has_flush and has_straight):
            return "very_strong"
        if has_flush or has_straight or three_kind:
            return "strong"
        if two_pair or one_pair:
            # Upgrade to strong if our hole card forms top-pair
            top_board_rank = max([RANK_VALUE[c[0]] for c in board]) if board else 0
            top_pair = False
            if one_pair:
                pair_rank = RANK_VALUE[pairs[0]]
                if any(RANK_VALUE[c[0]] == pair_rank for c in hole) and pair_rank >= top_board_rank:
                    top_pair = True
            if top_pair or two_pair:
                return "strong"
            return "medium"
        return "weak"

    # --------------------- utility helpers ------------------------------------
    def _extract_my_hole_cards(self, rs: RoundStateClient) -> List[str]:
        """
        Attempt to recover our current hole cards out of RoundStateClient
        in case the framework provides them. Falls back to previously
        stored value if not present.
        """
        if hasattr(rs, "player_hands"):
            cards = rs.player_hands.get(str(self.id)) or rs.player_hands.get(self.id)
            if cards:
                return cards
        return self.my_hole_cards

    @staticmethod
    def _bounded_raise(rs: RoundStateClient, *, amount: int) -> int:
        """
        Clamp a desired total bet size to the legal [current_bet + min_raise, max_raise] interval.
        If the amount is below min_raise threshold, just return current_bet (meaning call).
        """
        min_legal = rs.current_bet + rs.min_raise
        max_legal = rs.max_raise
        if min_legal > max_legal:  # cannot legally raise
            return rs.current_bet
        return max(min(amount, max_legal), min_legal)