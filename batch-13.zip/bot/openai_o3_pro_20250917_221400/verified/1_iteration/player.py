import itertools
import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i + 2 for i, r in enumerate(RANK_ORDER)}  # 2 -> 14 (Ace)


def card_rank(card: str) -> int:
    """Returns numeric rank 2-14 from card code like 'Ah'."""
    return RANK_VALUE[card[0]]


def card_suit(card: str) -> str:
    return card[1]


def hand_key(card1: str, card2: str) -> str:
    """Returns canonical pre-flop hand string such as AA, AKs, AKo …"""
    r1, r2 = card1[0], card2[0]
    s1, s2 = card1[1], card2[1]

    if r1 == r2:
        return r1 + r2  # e.g. AA, 99
    suited = s1 == s2
    ranks = "".join(sorted([r1, r2], key=lambda r: RANK_VALUE[r], reverse=True))
    return ranks + ("s" if suited else "o")


def is_straight(ranks: List[int]) -> bool:
    """Assumes ranks is length 5 list, checks straight (wheel allowed)."""
    ranks = sorted(set(ranks))
    if len(ranks) < 5:
        return False
    # normal straights
    for i in range(len(ranks) - 4):
        if ranks[i + 4] - ranks[i] == 4 and len(set(ranks[i : i + 5])) == 5:
            return True
    # wheel (A2345)
    wheel = {14, 5, 4, 3, 2}
    return wheel.issubset(ranks)


def evaluate_5(cards: List[str]) -> int:
    """Very coarse 5-card evaluator that returns category integer.
    8: straight flush, 7: quads, 6: full house, 5: flush, 4: straight,
    3: trips, 2: two pair, 1: pair, 0: high card
    (kickers ignored, only category matters for our decisions)."""
    ranks = [card_rank(c) for c in cards]
    suits = [card_suit(c) for c in cards]
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts = sorted(rank_counts.values(), reverse=True)

    flush = len(set(suits)) == 1
    straight = is_straight(ranks)

    if flush and straight:
        return 8
    if counts[0] == 4:
        return 7
    if counts[0] == 3 and counts[1] == 2:
        return 6
    if flush:
        return 5
    if straight:
        return 4
    if counts[0] == 3:
        return 3
    if counts[0] == 2 and counts[1] == 2:
        return 2
    if counts[0] == 2:
        return 1
    return 0


def best_hand_category(cards: List[str]) -> int:
    """Return best category among all 5-card combos from given cards."""
    best = 0
    for combo in itertools.combinations(cards, 5):
        best = max(best, evaluate_5(list(combo)))
        if best == 8:  # can't beat straight flush
            break
    return best


class SimplePlayer(Bot):
    """A very lightweight but robust No-Limit Hold’em bot."""

    # --- Pre-flop charts -------------------------------------------------- #
    STRONG_PREFLOP = {
        "AA",
        "KK",
        "QQ",
        "JJ",
        "AKs",
        "AQs",
        "AKo",
    }

    MEDIUM_PREFLOP = {
        "TT",
        "99",
        "88",
        "77",
        "AQo",
        "AJs",
        "ATs",
        "KQs",
        "KJs",
        "QJs",
        "JTs",
        "AJo",
        "KQo",
    }

    # --------------------------------------------------------------------- #

    def __init__(self):
        super().__init__()
        self.starting_stack = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.players: List[int] = []
        self.hole_cards: List[str] = []
        self.current_round_num = -1

    # ---------------------- Framework hooks ------------------------------ #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_stack = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players
        self.hole_cards = player_hands or []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_num = round_state.round_num
        self.hole_cards = self._extract_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """Main decision logic; always returns a valid action."""
        # Ensure we know our bet and amount to call
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(round_state.current_bet - my_bet, 0)

        # Safety: if we cannot determine our hand, play ultra-tight
        if not self.hole_cards or len(self.hole_cards) < 2:
            return self._safe_action(amount_to_call, remaining_chips)

        stage = round_state.round.lower()  # 'preflop', 'flop', …

        if stage == "preflop":
            return self._preflop_strategy(round_state, amount_to_call, remaining_chips)

        # post-flop decisions
        return self._postflop_strategy(round_state, amount_to_call, remaining_chips)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass  # not used, but must exist

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # not used

    # -------------------------- Strategies ------------------------------- #

    def _preflop_strategy(
        self, rs: RoundStateClient, amount_to_call: int, remaining: int
    ) -> Tuple[PokerAction, int]:
        key = hand_key(self.hole_cards[0], self.hole_cards[1])

        # Decide strength group
        if key in self.STRONG_PREFLOP:
            return self._raise_or_call(rs, amount_to_call, remaining, aggressive=True)

        if key in self.MEDIUM_PREFLOP:
            # Small calls, otherwise fold
            pot_limit = self.blind_amount * 4  # limp or small raise allowed
            if amount_to_call <= pot_limit:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # Weak hand:
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    def _postflop_strategy(
        self, rs: RoundStateClient, amount_to_call: int, remaining: int
    ) -> Tuple[PokerAction, int]:
        # Evaluate current hand category
        cards = self.hole_cards + rs.community_cards
        category = best_hand_category(cards)

        pot = rs.pot + amount_to_call  # pot after we potentially call

        # Strong made hand (flush or better, trips+)
        if category >= 5 or category == 4:  # straight or better
            return self._raise_or_call(rs, amount_to_call, remaining, aggressive=True)

        # Medium strength (two pair or trips if board paired)
        if category in (2, 3):
            # call small / medium bets
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            if amount_to_call <= pot * 0.4:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # One pair
        if category == 1:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            if amount_to_call <= pot * 0.25:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # No made hand – fold to any bet
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    # ----------------------- Helper utilities ---------------------------- #

    def _raise_or_call(
        self,
        rs: RoundStateClient,
        amount_to_call: int,
        remaining: int,
        aggressive: bool = False,
    ) -> Tuple[PokerAction, int]:
        """Helper that decides between raise, call, or all-in based on stack."""
        # If we can put significant pressure, raise 2× min_raise
        min_raise = rs.min_raise
        current_bet = rs.current_bet
        my_bet = rs.player_bets.get(str(self.id), 0)

        # Target total bet
        raise_total = current_bet + min_raise * (3 if aggressive else 2)

        # Ensure it's above minimum legal raise
        if raise_total < current_bet + min_raise:
            raise_total = current_bet + min_raise

        required = raise_total - my_bet  # additional chips to commit

        # If insufficient stack for raise, default to all-in
        if required >= remaining:
            return (PokerAction.ALL_IN, 0)

        # Randomize a bit to avoid predictability
        if random.random() < (0.7 if aggressive else 0.4):
            return (PokerAction.RAISE, raise_total)

        # fallback call/check
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        if amount_to_call >= remaining:
            return (PokerAction.ALL_IN, 0)
        return (PokerAction.CALL, 0)

    def _safe_action(
        self, amount_to_call: int, remaining: int
    ) -> Tuple[PokerAction, int]:
        """Very conservative default when we lack information."""
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        if amount_to_call >= remaining:
            return (PokerAction.ALL_IN, 0)
        return (PokerAction.FOLD, 0)

    def _extract_hole_cards(self, rs: RoundStateClient) -> List[str]:
        """Attempts to pull our current hand from round_state (framework dependant)."""
        possible_attrs = ("player_hands", "player_hand", "hands", "hole_cards")
        for attr in possible_attrs:
            if hasattr(rs, attr):
                data = getattr(rs, attr)
                # data may be dict(id->cards) or directly list[str]
                if isinstance(data, dict):
                    if str(self.id) in data:
                        return data[str(self.id)]
                    if self.id in data:
                        return data[self.id]
                elif isinstance(data, list) and len(data) >= 2:
                    return data
        return []