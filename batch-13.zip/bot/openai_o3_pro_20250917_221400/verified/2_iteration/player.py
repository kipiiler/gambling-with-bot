from typing import List, Tuple, Dict
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# we rely on the pure-python hand evaluator “treys”
try:
    from treys import Card, Evaluator
except ImportError:
    # the judge will install everything in requirements.txt, but we still add a
    # soft-fallback so the import error will not crash the bot during the judge’s
    # dependency-installation phase.
    Card = None
    Evaluator = None


RANK_ORDER = "23456789TJQKA"
RANK_IDX = {r: i for i, r in enumerate(RANK_ORDER)}


def _card_to_int(card_str: str) -> int:
    """
    Helper that converts 'Ah', 'Td' … into treys integer representation.
    Safe-guarded if treys is unavailable.
    """
    if Card is None:
        return 0
    return Card.new(card_str[0] + card_str[1].lower())


class SimplePlayer(Bot):
    """
    Very small yet reasonably solid NLHE bot.
    Uses:
      • simple pre-flop chart
      • hand-strength evaluation on later streets (treys Evaluator)
    """

    # --- life-cycle methods -------------------------------------------------

    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.evaluator = Evaluator() if Evaluator else None

        # per-hand state
        self.hole_cards: List[str] = []
        self.last_round_num: int | None = None

    # called once at the beginning of the whole simulation
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands is the first hand dealt
        self.hole_cards = player_hands

    # called at the start of every hand
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # guard against missing attributes
        self.hole_cards = (
            self._extract_hole_cards(round_state) or self.hole_cards or []
        )
        self.last_round_num = round_state.round_num

    # --- main decision point -------------------------------------------------

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core strategy:
            • pre-flop: 3-bet or fold based on simple chart
            • post-flop: evaluate hand strength; bet strong, call medium, fold weak
        """

        # refresh our hole cards if we haven’t yet
        my_cards = self._extract_hole_cards(round_state) or self.hole_cards
        self.hole_cards = my_cards  # cache

        # ensure we always have something to play with
        if not my_cards or len(my_cards) != 2:
            return self._safe_default(round_state)

        stage = self._get_stage(round_state)
        current_bet = round_state.current_bet
        min_raise = (
            round_state.min_raise if round_state.min_raise is not None else 0
        )  # safe default
        max_raise = (
            round_state.max_raise if round_state.max_raise is not None else remaining_chips
        )

        # decide
        if stage == "preflop":
            decision = self._preflop_decision(my_cards, current_bet)
        else:
            decision = self._postflop_decision(
                my_cards, round_state.community_cards, current_bet
            )

        # translate decision into legal action
        return self._action_from_decision(
            decision, round_state, remaining_chips, min_raise, max_raise
        )

    # called when a hand ends
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []  # clear for next hand

    # called when the whole simulation ends
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # we don’t need to persist anything between simulations

    # -----------------------------------------------------------------------
    # -----------------------  strategy helpers  ----------------------------
    # -----------------------------------------------------------------------

    # decision keywords used internally
    #   "fold", "check", "call", "raise", "allin"
    def _preflop_decision(self, hole: List[str], current_bet: int) -> str:
        """
        Very small pre-flop chart (rough heads-up oriented).

        returns one of: fold, check, call, raise, allin
        """

        card1, card2 = hole
        r1, r2 = card1[0], card2[0]
        suited = card1[1] == card2[1]

        # build a hand key such as 'AKs', 'QTo', '99'
        if r1 == r2:
            hand_key = r1 + r2
        else:
            ranks_sorted = "".join(sorted([r1, r2], key=lambda x: RANK_IDX[x], reverse=True))
            hand_key = ranks_sorted + ("s" if suited else "o")

        # define value tiers
        premium_pairs = {"AA", "KK", "QQ", "JJ", "TT"}
        strong_pairs = {"99", "88", "77"}
        premium_broadway = {"AKs", "AQs", "AJs", "KQs", "AKo"}
        suited_connectors = {"T9s", "98s", "87s", "76s", "65s", "54s"}

        # aggression / stack sizing
        if hand_key in premium_pairs or hand_key in premium_broadway:
            return "raise"

        if hand_key in strong_pairs or hand_key in suited_connectors:
            # call if already raised, otherwise raise
            return "call" if current_bet > 0 else "raise"

        # Ace-x suited down to A5s are acceptable limps
        if r1 == "A" or r2 == "A":
            if suited and (RANK_IDX[r1] <= 4 or RANK_IDX[r2] <= 4):
                return "call" if current_bet > 0 else "check"

        # otherwise fold/check
        return "check" if current_bet == 0 else "fold"

    def _postflop_decision(
        self, hole: List[str], board: List[str], current_bet: int
    ) -> str:
        """
        Estimate hand strength via treys Evaluator and act accordingly.
        """

        if not self.evaluator:
            # if treys not available, fall back to tighter strategy
            return "fold" if current_bet > 0 else "check"

        # convert to treys ints
        hole_int = [_card_to_int(c) for c in hole]
        board_int = [_card_to_int(c) for c in board]

        # evaluator.score: lower score == stronger hand
        score = self.evaluator.evaluate(board_int, hole_int)
        # convert to pseudo percentile strength [0,1]
        strength = 1.0 - (score / 7462.0)

        # select action based on strength
        # thresholds chosen empirically for heads-up
        if strength > 0.8:
            return "allin"
        elif strength > 0.6:
            return "raise"
        elif strength > 0.4:
            return "call" if current_bet > 0 else "check"
        else:
            return "check" if current_bet == 0 else "fold"

    # -----------------------------------------------------------------------
    # -------------------------  utility helpers  ---------------------------
    # -----------------------------------------------------------------------

    def _extract_hole_cards(self, state: RoundStateClient) -> List[str]:
        """
        Tries multiple possible attribute names to obtain our current hole cards.
        """
        # common server implementations attach a dict[str, List[str]]
        for attr in ("player_hands", "playerHands", "hands"):
            if hasattr(state, attr):
                hands_obj: Dict[str, List[str]] | None = getattr(state, attr)
                if hands_obj and str(self.id) in hands_obj:
                    return hands_obj[str(self.id)]
        return []

    def _get_stage(self, state: RoundStateClient) -> str:
        round_name = (state.round or "").lower()
        if round_name.startswith("pre"):
            return "preflop"
        if round_name.startswith("flop"):
            return "flop"
        if round_name.startswith("turn"):
            return "turn"
        return "river"

    # safety-net default action (will never make illegal moves)
    def _safe_default(self, state: RoundStateClient) -> Tuple[PokerAction, int]:
        if state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    # translate internal decision keyword into (PokerAction, amount)
    def _action_from_decision(
        self,
        decision: str,
        state: RoundStateClient,
        remaining: int,
        min_raise: int,
        max_raise: int,
    ) -> Tuple[PokerAction, int]:
        decision = decision.lower()

        if decision == "fold":
            if state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

        if decision == "check":
            if state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            # cannot check, downgrade to call/fold
            return self._action_from_decision(
                "call" if state.current_bet <= self.blind_amount * 4 else "fold",
                state,
                remaining,
                min_raise,
                max_raise,
            )

        if decision == "call":
            # if there is nothing to call we just check
            if state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            call_amt = min(state.current_bet, remaining)
            if call_amt == remaining:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, call_amt)

        if decision == "raise":
            # compute a sensible raise size
            target = max(state.current_bet + min_raise, int(state.pot * 0.75))
            target = max(target, self.blind_amount * 3)
            target = min(target, remaining)
            if target < state.current_bet + min_raise:
                # can’t legally raise, fall back to call
                return self._action_from_decision("call", state, remaining, min_raise, max_raise)

            if target >= remaining:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.RAISE, target)

        if decision == "allin":
            return (PokerAction.ALL_IN, 0)

        # unknown keyword, fall back
        return self._safe_default(state)