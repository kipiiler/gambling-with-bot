import random
import time
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_TO_VALUE = {r: i for i, r in enumerate(RANK_ORDER, 2)}
VALUE_TO_RANK = {i: r for r, i in RANK_TO_VALUE.items()}


def card_rank(card: str) -> int:
    return RANK_TO_VALUE[card[0]]


def card_suit(card: str) -> str:
    return card[1]


def evaluate_7(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Very light-weight 7-card evaluator.
    Returns (category, tiebreaker list) where larger is better.
    Categories:
        8 – Straight flush
        7 – Four of a kind
        6 – Full house
        5 – Flush
        4 – Straight
        3 – Three of a kind
        2 – Two pair
        1 – One pair
        0 – High card
    NOTE: This evaluator is NOT optimised for absolute speed but is
    good enough for a few hundred Monte-Carlo iterations within the
    30-second per-move limit.
    """
    ranks = sorted([card_rank(c) for c in cards], reverse=True)
    suits = [card_suit(c) for c in cards]

    # Count occurrences of each rank
    counts: Dict[int, int] = {}
    for r in ranks:
        counts[r] = counts.get(r, 0) + 1
    # Get groups sorted (count desc, rank desc)
    groups = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
    count_values = [c for _, c in groups]

    # Helper: check straight (including wheel)
    unique_ranks = sorted(set(ranks))
    # Ace-low straight check
    if 14 in unique_ranks:
        unique_ranks.append(1)
    straight_high = None
    for i in range(len(unique_ranks) - 4):
        window = unique_ranks[i : i + 5]
        if window[-1] - window[0] == 4:
            straight_high = window[-1] if window[-1] != 1 else 5
    # Flush
    suit_counts: Dict[str, List[int]] = {}
    for c in cards:
        suit_counts.setdefault(card_suit(c), []).append(card_rank(c))
    flush_suit = None
    for s, lst in suit_counts.items():
        if len(lst) >= 5:
            flush_suit = s
            break
    flush_ranks = sorted(suit_counts.get(flush_suit, []), reverse=True) if flush_suit else []

    # Straight flush
    straight_flush_high = None
    if flush_suit:
        suited = sorted(set(flush_ranks))
        if 14 in suited:
            suited.append(1)
        for i in range(len(suited) - 4):
            w = suited[i : i + 5]
            if w[-1] - w[0] == 4:
                straight_flush_high = w[-1] if w[-1] != 1 else 5
    if straight_flush_high:
        return 8, [straight_flush_high]

    # Four of a kind
    if count_values[0] == 4:
        four_rank = groups[0][0]
        kicker = max([r for r in ranks if r != four_rank])
        return 7, [four_rank, kicker]

    # Full house
    if count_values[0] == 3 and (count_values[1] >= 2):
        triple_rank = groups[0][0]
        pair_rank = groups[1][0]
        return 6, [triple_rank, pair_rank]

    # Flush
    if flush_suit:
        return 5, flush_ranks[:5]

    # Straight
    if straight_high:
        return 4, [straight_high]

    # Three of a kind
    if count_values[0] == 3:
        triple_rank = groups[0][0]
        kickers = [r for r in ranks if r != triple_rank][:2]
        return 3, [triple_rank] + kickers

    # Two pair
    if count_values[0] == 2 and count_values[1] == 2:
        high_pair = groups[0][0]
        low_pair = groups[1][0]
        kicker = max([r for r in ranks if r not in {high_pair, low_pair}])
        return 2, [high_pair, low_pair, kicker]

    # One pair
    if count_values[0] == 2:
        pair_rank = groups[0][0]
        kickers = [r for r in ranks if r != pair_rank][:3]
        return 1, [pair_rank] + kickers

    # High card
    return 0, ranks[:5]


def compare_hands(a: Tuple[int, List[int]], b: Tuple[int, List[int]]) -> int:
    """
    Compare two evaluated hands.
    Returns 1 if a>b, 0 if tie, -1 if a<b.
    """
    if a[0] != b[0]:
        return 1 if a[0] > b[0] else -1
    for va, vb in zip(a[1], b[1]):
        if va != vb:
            return 1 if va > vb else -1
    return 0


class SimplePlayer(Bot):
    """
    A Monte-Carlo-powered Hold’em bot with tight pre-flop ranges and
    post-flop equity calculation.  Designed for robustness and to
    improve on the previous (losing) iteration.
    """

    def __init__(self):
        super().__init__()
        self.start_stack = 0
        self.big_blind = 0
        self.small_blind = 0
        self.hole_cards: List[str] = []
        self.round_num = 0
        self.players: List[int] = []

    # --- Utility helpers --------------------------------------------------

    @staticmethod
    def make_deck(exclude: List[str]) -> List[str]:
        deck = [r + s for r in RANK_ORDER for s in "shdc"]
        return [c for c in deck if c not in exclude]

    # --- Bot API callbacks -------------------------------------------------

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.start_stack = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.players = all_players
        # initial hole cards for first round if provided
        if player_hands and len(player_hands) == 2:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Attempt to grab our new hole cards if present in state
        hand = None
        if hasattr(round_state, "player_hands"):
            # dict keyed by player id or str id
            if isinstance(round_state.player_hands, dict):
                key_variants = [self.id, str(self.id)]
                for k in key_variants:
                    if k in round_state.player_hands:
                        hand = round_state.player_hands[k]
                        break
            elif isinstance(round_state.player_hands, list) and len(round_state.player_hands) == 2:
                hand = round_state.player_hands  # assume heads-up
        if hand:
            self.hole_cards = hand

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Core decision logic.
        """
        # Guard: if we somehow don’t know our hole cards, play safe
        if len(self.hole_cards) != 2:
            return PokerAction.FOLD, 0

        community = round_state.community_cards
        pot = round_state.pot
        to_call = max(round_state.current_bet - round_state.player_bets.get(str(self.id), 0), 0)

        active_players = [p for p in round_state.current_player]
        opponents = max(len(active_players) - 1, 1)  # assume at least 1 opponent

        stage = len(community)  # 0,3,4,5

        # Pre-flop shortcut strategy ---------------------------------------
        if stage == 0:
            rank_chars = [c[0] for c in self.hole_cards]
            suited = card_suit(self.hole_cards[0]) == card_suit(self.hole_cards[1])
            high_ranks = sorted([card_rank(c) for c in self.hole_cards], reverse=True)

            premium_pairs = {14, 13, 12, 11, 10}  # AA-TT
            pair = rank_chars[0] == rank_chars[1]
            # Determine hand strength bucket 0-3
            strength = 0  # default weak
            if pair and card_rank(self.hole_cards[0]) in premium_pairs:
                strength = 3
            elif pair and card_rank(self.hole_cards[0]) >= 8:
                strength = 2
            elif high_ranks[0] >= 13 and high_ranks[1] >= 11:
                strength = 2  # AK, AQ, AJ, KQ
            elif suited and abs(RANK_ORDER.index(rank_chars[0]) - RANK_ORDER.index(rank_chars[1])) == 1:
                strength = 1  # suited connectors
            elif pair:
                strength = 1  # small pair
            # Decision matrix
            if strength == 3:
                # Premium: raise big or reraise
                raise_amt = min(round_state.max_raise, max(round_state.min_raise, int(3.5 * self.big_blind)))
                if to_call > 0 and (to_call + raise_amt) <= remaining_chips:
                    return PokerAction.RAISE, raise_amt
                if to_call == 0:
                    return PokerAction.RAISE, raise_amt
                if to_call >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            elif strength == 2:
                if to_call == 0:
                    raise_amt = max(round_state.min_raise, int(3 * self.big_blind))
                    raise_amt = min(raise_amt, round_state.max_raise)
                    return PokerAction.RAISE, raise_amt
                elif to_call <= 4 * self.big_blind:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif strength == 1:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call <= 2 * self.big_blind:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hand
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        # Post-flop Monte-Carlo equity estimation --------------------------
        # Decide iteration count dynamically for speed
        if stage == 3:
            iterations = 700
        elif stage == 4:
            iterations = 600
        elif stage == 5:
            iterations = 1  # No need for sampling – we know all cards
        else:
            iterations = 500

        # Simple optimisation: fewer iterations with many opponents
        iterations = max(200, int(iterations / max(opponents, 1)))

        start_time = time.perf_counter()
        wins = ties = 0

        deck = self.make_deck(self.hole_cards + community)
        for i in range(iterations):
            # Time safety check
            if time.perf_counter() - start_time > 2.0:  # hard cap ~2 sec
                break
            sample = deck[:]
            random.shuffle(sample)

            community_sample = community[:]
            # Complete community to 5 cards
            need = 5 - len(community_sample)
            community_sample.extend(sample[:need])
            sample = sample[need:]

            # Opponent hole cards
            opp_hands = []
            for _ in range(opponents):
                opp_hands.append(sample[:2])
                sample = sample[2:]

            our_score = evaluate_7(self.hole_cards + community_sample)
            best_result = 1  # assume we win
            for h in opp_hands:
                opp_score = evaluate_7(h + community_sample)
                cmp = compare_hands(our_score, opp_score)
                if cmp == -1:
                    best_result = -1
                    break
                elif cmp == 0:
                    best_result = max(best_result, 0)
            if best_result == 1:
                wins += 1
            elif best_result == 0:
                ties += 1

        total = wins + ties + (iterations - wins - ties)
        win_rate = (wins + ties * 0.5) / (total + 1e-9)

        # Pot odds & decision
        if to_call == 0:
            # We can check – maybe value bet
            if win_rate > 0.7 and round_state.min_raise <= remaining_chips:
                bet = min(round_state.max_raise, max(round_state.min_raise, int(pot * 0.7)))
                return PokerAction.RAISE, bet
            return PokerAction.CHECK, 0

        breakeven = to_call / (pot + to_call + 1e-9)

        if win_rate > breakeven + 0.15:
            # Aggressive: raise for value
            raise_amt = min(round_state.max_raise, max(round_state.min_raise, int(pot * 0.75)))
            # If raise not possible / affordable just call
            if raise_amt > to_call and raise_amt <= remaining_chips:
                return PokerAction.RAISE, raise_amt
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        elif win_rate > breakeven - 0.05:
            # Marginal: call if cheap
            if to_call <= remaining_chips * 0.1:
                return PokerAction.CALL, 0
        # Otherwise fold
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass