from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.evaluator = None
        try:
            from deuces import Evaluator
            self.evaluator = Evaluator()
        except ImportError:
            self.evaluator = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.hole_cards = None
        self.rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        idx = all_players.index(self.id)
        hand_str = player_hands[idx]
        if len(hand_str) == 4:
            self.hole_cards = [hand_str[:2], hand_str[2:4]]
        else:
            self.hole_cards = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.hole_cards is None:
            return PokerAction.FOLD, 0
            
        if round_state.round == 'Preflop':
            return self.get_preflop_action(round_state, remaining_chips)
        else:
            return self.get_postflop_action(round_state, remaining_chips)
    
    def get_hand_group(self, hole_cards: List[str]) -> int:
        if len(hole_cards) != 2:
            return 5
            
        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]
        
        if rank1 not in self.rank_map or rank2 not in self.rank_map:
            return 5
            
        num1 = self.rank_map[rank1]
        num2 = self.rank_map[rank2]
        high_rank = max(num1, num2)
        low_rank = min(num1, num2)
        is_suited = (suit1 == suit2)

        if high_rank == 14 and low_rank == 14:  # AA
            return 1
        if high_rank == 13 and low_rank == 13:  # KK
            return 1
        if high_rank == 12 and low_rank == 12:  # QQ
            return 1
        if high_rank == 11 and low_rank == 11:  # JJ
            return 1
        if high_rank == 14 and low_rank == 13:  # AK
            return 1
            
        if high_rank == 10 and low_rank == 10:  # TT
            return 2
        if high_rank == 14 and low_rank == 12:  # AQ
            return 2
        if high_rank == 14 and low_rank == 11 and is_suited:  # AJs
            return 2
        if high_rank == 13 and low_rank == 12 and is_suited:  # KQs
            return 2
            
        if high_rank == 9 and low_rank == 9:  # 99
            return 3
        if high_rank == 11 and low_rank == 10 and is_suited:  # JTs
            return 3
        if high_rank == 12 and low_rank == 11 and is_suited:  # QJs
            return 3
        if high_rank == 13 and low_rank == 11 and is_suited:  # KJs
            return 3
        if high_rank == 14 and low_rank == 10 and is_suited:  # ATs
            return 3
        if high_rank == 14 and low_rank == 9 and is_suited:  # A9s
            return 3
        if high_rank == 13 and low_rank == 12 and not is_suited:  # KQo
            return 3
            
        return 4

    def get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        group = self.get_hand_group(self.hole_cards)
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        
        if amount_to_call == 0:
            if group <= 2:
                raise_amount = round_state.min_raise
                if raise_amount > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            if group == 1:
                if amount_to_call > 10 * self.blind_amount and amount_to_call > remaining_chips:
                    return PokerAction.FOLD, 0
                if amount_to_call > 10 * self.blind_amount:
                    raise_amount = round_state.min_raise
                    if amount_to_call + raise_amount > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif group == 2:
                if amount_to_call > 5 * self.blind_amount:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CALL, 0
            elif group == 3:
                if amount_to_call > 3 * self.blind_amount:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.evaluator is None:
            return PokerAction.FOLD, 0
            
        try:
            from deuces import Card
            hole_cards = [Card.new(self.hole_cards[0]), Card.new(self.hole_cards[1])]
            community_cards = [Card.new(card) for card in round_state.community_cards]
            hand_rank = self.evaluator.evaluate(hole_cards, community_cards)
            hand_strength_percentile = (7462 - hand_rank) / 7462.0 * 100.0
        except:
            return PokerAction.FOLD, 0

        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        
        if amount_to_call > 0:
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-9)
        else:
            pot_odds = 0

        if amount_to_call == 0:
            if hand_strength_percentile > 80:
                raise_amount = round_state.min_raise * 2
                if raise_amount > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif hand_strength_percentile > 50:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            if amount_to_call >= remaining_chips:
                if hand_strength_percentile > 80:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if hand_strength_percentile > 80:
                    raise_amount = round_state.min_raise * 2
                    if amount_to_call + raise_amount > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif hand_strength_percentile > 50:
                    if hand_strength_percentile/100.0 > pot_odds:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass