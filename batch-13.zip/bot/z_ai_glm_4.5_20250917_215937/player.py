from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import defaultdict

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.hole_cards = []
        self.round_num = 0
        self.rank_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '10':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        self.preflop_chart = {
            ('A', 'A'): 1.0, ('K', 'K'): 1.0, ('Q', 'Q'): 1.0, ('J', 'J'): 0.8, ('10', '10'): 0.7,
            ('A', 'K'): 0.9, ('A', 'Q'): 0.8, ('A', 'J'): 0.7, ('K', 'Q'): 0.7,
            ('9', '9'): 0.6, ('8', '8'): 0.5, ('7', '7'): 0.4, ('6', '6'): 0.3, ('5', '5'): 0.2, ('4', '4'): 0.1, ('3', '3'): 0.05, ('2', '2'): 0.05
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands
        self.round_num = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Only play first hand, fold all others
        if self.round_num > 0:
            return (PokerAction.FOLD, 0)
        
        # For first hand, implement strategy
        my_id_str = str(self.id)
        my_current_bet = round_state.player_bets.get(my_id_str, 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            try:
                strength = self._get_preflop_strength(self.hole_cards)
                
                # Fold if very weak
                if strength <= 0.05:
                    return (PokerAction.FOLD, 0)
                
                # Check/call if below threshold
                if strength < 0.5:
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    elif call_amount <= 5 * self.blind_amount:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                
                # Raise with strong hands
                if strength >= 0.5:
                    if call_amount > 0 and call_amount > 10 * self.blind_amount:
                        return (PokerAction.FOLD, 0)
                    
                    # Minimum raise
                    raise_amount = round_state.min_raise
                    if call_amount > 0:
                        total_bet = my_current_bet + call_amount + raise_amount
                    else:
                        total_bet = my_current_bet + raise_amount
                    
                    if total_bet > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    elif raise_amount < round_state.min_raise:
                        return (PokerAction.CHECK, 0) if call_amount == 0 else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
                        
            except Exception:
                return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            try:
                hand_strength = self._evaluate_hand_strength(self.hole_cards + round_state.community_cards)
                pot = round_state.pot
                
                # Very strong hands (flush or better)
                if hand_strength >= 5:
                    if call_amount > pot:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        raise_amount = min(pot // 2, round_state.max_raise)
                        if raise_amount < round_state.min_raise:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.RAISE, raise_amount)
                
                # Strong hands (two pair or three of a kind)
                elif hand_strength >= 2:
                    if call_amount > pot * 2:
                        return (PokerAction.FOLD, 0)
                    elif call_amount == 0:
                        raise_amount = min(pot // 3, round_state.max_raise)
                        if raise_amount < round_state.min_raise:
                            return (PokerAction.CHECK, 0)
                        else:
                            return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                
                # Weak hands
                else:
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    elif call_amount <= pot // 4:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _get_preflop_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.0
        
        # Parse cards
        r1_val = self.rank_values[hole_cards[0][:-1]] if len(hole_cards[0]) == 2 else self.rank_values[hole_cards[0][:2]]
        r2_val = self.rank_values[hole_cards[1][:-1]] if len(hole_cards[1]) == 2 else self.rank_values[hole_cards[1][:2]]
        s1 = hole_cards[0][-1]
        s2 = hole_cards[1][-1]
        
        # Order by rank
        if r1_val < r2_val:
            r1_val, r2_val = r2_val, r1_val
        
        is_suited = s1 == s2
        key = (self._rank_to_str(r1_val), self._rank_to_str(r2_val))
        
        # Check pocket pairs
        if r1_val == r2_val:
            return self.preflop_chart.get(key, 0.05)
        
        # Check specific non-paired hands
        if key in self.preflop_chart:
            return self.preflop_chart[key]
        
        # Adjust for suitedness
        if r1_val == 14 and is_suited:  # Ace high suited
            return 0.6
        elif r1_val == 14:  # Ace high offsuit
            return 0.4
        elif r1_val == 13 and is_suited:  # King high suited
            return 0.5
        else:
            return 0.05

    def _rank_to_str(self, rank_val: int) -> str:
        for r, val in self.rank_values.items():
            if val == rank_val:
                return r
        return '2'

    def _evaluate_hand_strength(self, cards: List[str]) -> int:
        if len(cards) < 5:
            return 0
        
        best_rank = 0
        for combo in combinations(cards, 5):
            rank = self._evaluate_hand_5(list(combo))
            if rank > best_rank:
                best_rank = rank
        return best_rank

    def _evaluate_hand_5(self, cards: List[str]) -> int:
        if len(cards) != 5:
            return 0
        
        suits = []
        ranks = []
        for card in cards:
            if len(card) == 2:
                rank_str = card[0]
                suit = card[1]
            else:
                rank_str = card[:2]
                suit = card[2]
            ranks.append(self.rank_values[rank_str])
            suits.append(suit)
        
        # Check for flush
        is_flush = suits.count(suits[0]) == 5
        
        # Check for straight
        sorted_ranks = sorted(ranks, reverse=True)
        is_straight = True
        for i in range(1, 5):
            if sorted_ranks[i] != sorted_ranks[i-1] - 1:
                is_straight = False
                break
        
        # Special case for ace-low straight
        if not is_straight and sorted_ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            sorted_ranks = [5, 4, 3, 2, 1]  # Ace-low straight
        
        # Royal flush
        if is_flush and is_straight and sorted_ranks[0] == 14:
            return 9
        # Straight flush
        elif is_flush and is_straight:
            return 8
        
        # Count ranks
        rank_count = defaultdict(int)
        for r in ranks:
            rank_count[r] += 1
        counts = sorted(rank_count.values(), reverse=True)
        
        # Four of a kind
        if counts[0] == 4:
            return 7
        # Full house
        elif counts[0] == 3 and counts[1] == 2:
            return 6
        # Flush
        elif is_flush:
            return 5
        # Straight
        elif is_straight:
            return 4
        # Three of a kind
        elif counts[0] == 3:
            return 3
        # Two pair
        elif counts[0] == 2 and counts[1] == 2:
            return 2
        # One pair
        elif counts[0] == 2:
            return 1
        # High card
        else:
            return 0