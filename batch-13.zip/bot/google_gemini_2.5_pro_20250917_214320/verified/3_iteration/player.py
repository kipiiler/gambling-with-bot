from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that uses hand strength evaluation, pot odds, and equity calculation
    (via outs) to make decisions. It includes robust logic to prevent invalid actions,
    specifically the invalid raise amount error from the previous iteration.
    """

    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount: int = 0
        self.player_count: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the game."""
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.player_count = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of a new hand."""
        pass # Reset any per-round state if necessary

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each betting round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass # Could be used for learning, but not for this version.

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main function that gets called by the game engine.
        It should return a tuple of (PokerAction, amount).
        """
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - my_bet
            can_check = amount_to_call == 0

            active_players = [p_id for p_id, p in round_state.player_actions.items() if p not in ["Fold", None] and int(p_id) != self.id]
            active_opponent_count = len(active_players)

            if round_state.round == 'Preflop':
                return self._get_preflop_action(round_state, remaining_chips, amount_to_call, can_check)
            else:
                return self._get_postflop_action(round_state, remaining_chips, amount_to_call, can_check, active_opponent_count)
        except Exception:
            # Fallback to a safe action in case of any error.
            # This prevents the bot from crashing and being auto-folded.
            my_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - my_bet
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            
            # If we cannot afford to call, we must fold or go all-in. Fold is safer.
            if amount_to_call > remaining_chips:
                 return PokerAction.FOLD, 0
            
            return PokerAction.FOLD, 0

    # --- Pre-flop Strategy ---

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        hand_tier = self._get_preflop_hand_tier(self.hole_cards)

        # Tier 1-2: Premium hands, play aggressively
        if hand_tier <= 2:
            if round_state.current_bet <= self.big_blind_amount: # If no one has raised yet
                raise_amount = 3 * self.big_blind_amount
            else: # If there's a raise, we re-raise
                raise_amount = 2.5 * round_state.current_bet + amount_to_call
            return self._decide_raise_or_all_in(raise_amount, round_state, remaining_chips)

        # Tier 3: Strong hands, can raise or call
        elif hand_tier == 3:
            if round_state.current_bet <= self.big_blind_amount: # If no one has raised, we raise
                raise_amount = 2.5 * self.big_blind_amount
                return self._decide_raise_or_all_in(raise_amount, round_state, remaining_chips)
            elif amount_to_call < 0.1 * remaining_chips: # Facing a small raise, call
                return PokerAction.CALL, 0
            else: # Facing a large raise, fold
                return PokerAction.FOLD, 0

        # Tier 4: Speculative hands (suited connectors, small pairs)
        elif hand_tier == 4:
            # Call a small raise (limpers or small open)
            if amount_to_call <= self.big_blind_amount * 2:
                return PokerAction.CALL, 0
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
        
        # Tier 5: Weak hands (trash)
        else:
            if can_check: # We are big blind and no one raised
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0
        
    def _get_preflop_hand_tier(self, cards: List[str]) -> int:
        """Categorizes starting hands into tiers."""
        ranks_str = sorted([c[:-1] for c in cards], key=lambda r: '23456789TJQKA'.index(r), reverse=True)
        suits = [c[-1] for c in cards]
        is_suited = suits[0] == suits[1]
        
        r1, r2 = ranks_str[0], ranks_str[1]
        is_pair = (r1 == r2)

        # Using a simplified tiering system
        if is_pair:
            if 'J' in r1 or 'Q' in r1 or 'K' in r1 or 'A' in r1: return 1 # JJ+
            if 'T' in r1 or '9' in r1: return 2 # TT, 99
            if '5' in r1 or '6' in r1 or '7' in r1 or '8' in r1: return 3 # 88-55
            return 4 # 44-22

        if is_suited:
            if r1 == 'A' and r2 in 'KQJ': return 1 # AKs, AQs, AJs
            if r1 == 'K' and r2 in 'QJ': return 2 # KQs, KJs
            if r1 == 'A' and r2 == 'T': return 2 # ATs
            if r1 in 'QJ' and r2 == 'T': return 3 # QTs, JTs
            if 'A' in r1: return 4 # A9s-A2s
            if '23456789T'.index(r1) - '23456789T'.index(r2) == 1: return 4 # Suited connectors
        
        if not is_suited:
            if r1 == 'A' and r2 in 'KQ': return 2 # AKo, AQo
            if (r1 == 'A' and r2 == 'J') or (r1 == 'K' and r2 == 'Q'): return 3 # AJo, KQo

        return 5 # Everything else (trash)

    # --- Post-flop Strategy ---

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, can_check: bool, opponent_count: int) -> Tuple[PokerAction, int]:
        
        strength_score, _ = self._calculate_hand_strength_postflop(self.hole_cards, round_state.community_cards)
        outs = self._calculate_outs(self.hole_cards, round_state.community_cards)
        
        win_prob = self._estimate_win_probability(strength_score, outs, round_state.round, opponent_count)
        
        pot_odds = 0
        if amount_to_call > 0:
            # Handle potential division by zero
            pot_and_call = round_state.pot + amount_to_call
            pot_odds = amount_to_call / (pot_and_call + 1e-9)

        # Very strong hand (Full House or better) - go for max value
        if strength_score >= 7:
            raise_amount = round_state.pot * 0.8 # Bet 80% of pot for value
            return self._decide_raise_or_all_in(raise_amount, round_state, remaining_chips)
        
        # Strong made hand (Two Pair to Flush) - bet for value
        if strength_score >= 3:
            if can_check:
                bet_amount = round_state.pot * (0.5 + (strength_score - 3) * 0.1) # Bet 50-80% pot
                return self._decide_raise_or_all_in(bet_amount, round_state, remaining_chips)
            else: # Facing a bet
                if win_prob > pot_odds + 0.15: # Confident we are ahead, re-raise
                    raise_amount = 2.5 * round_state.current_bet
                    return self._decide_raise_or_all_in(raise_amount, round_state, remaining_chips)
                elif win_prob > pot_odds: # Call, we are likely ahead
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Drawing hand (strong draw)
        if outs >= 8 and round_state.round != "River":
            if can_check:
                return PokerAction.CHECK, 0
            else:
                if win_prob > pot_odds: # Pot odds are good
                    return PokerAction.CALL, 0
                elif amount_to_call < 0.15 * remaining_chips: # Implied odds for a small bet
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Weak hand (One Pair or less)
        if can_check:
            return PokerAction.CHECK, 0
        else:
            # Bluff catch with top pair on a small bet
            if strength_score == 2 and amount_to_call < round_state.pot * 0.4:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _estimate_win_probability(self, strength_score, outs, poker_round, opponent_count):
        """A simple heuristic to estimate winning probability."""
        if poker_round == "River":
            equity_from_draw = 0
        elif poker_round == "Flop":
            equity_from_draw = outs * 4
        else: # Turn
            equity_from_draw = outs * 2

        base_equity = {
            9: 100, 8: 98, 7: 95, 6: 90, 5: 85,
            4: 75, 3: 65, 2: 50, 1: 10
        }.get(strength_score, 0)
        
        # Simple adjustment for multiple opponents
        total_equity = base_equity * (1 - (equity_from_draw / 100)) + equity_from_draw
        if opponent_count > 0:
            win_prob = total_equity ** opponent_count
        else:
            win_prob = total_equity

        return win_prob / 100.0

    # --- Action and Betting Helpers ---
    
    def _decide_raise_or_all_in(self, amount: float, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Calculates a valid raise amount and returns RAISE, ALL_IN, CALL, or CHECK."""
        bet_amount = int(amount)

        # A raise amount is the TOTAL bet for the round. It must be at least min_raise.
        min_raise_floor = round_state.min_raise
        
        # If we can check, the min_raise might be 0. A bet must be at least one big blind.
        if min_raise_floor == 0:
            min_raise_floor = self.big_blind_amount

        # Ensure our bet is at least the minimum valid amount
        final_bet = max(bet_amount, min_raise_floor)
        
        # Ensure we don't bet more than we have.
        final_bet = min(final_bet, remaining_chips)

        # If the bet is our entire stack, it's an ALL_IN
        if final_bet >= remaining_chips:
            return PokerAction.ALL_IN, 0
        
        # This is the CRITICAL FIX: If our calculated "raise" is not actually a raise,
        # it means we cannot or should not raise. We default to a call or check.
        if final_bet <= round_state.current_bet:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            if round_state.current_bet > my_bet:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0

        # If all checks pass, we can make the raise.
        return PokerAction.RAISE, final_bet


    # --- Card and Hand Evaluation Helpers ---

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """Converts a card string like 'Th' to a tuple (10, 'h')."""
        rank_str = card_str[:-1]
        suit = card_str[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return rank, suit

    def _calculate_hand_strength_postflop(self, my_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        """Evaluates the best 5-card hand from available cards."""
        if not community_cards:
            return 0, []
        
        all_cards_str = my_cards + community_cards
        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        best_hand_score = (-1, [])

        for combo in combinations(all_cards, 5):
            current_score = self._evaluate_5_card_combo(list(combo))
            if current_score[0] > best_hand_score[0] or \
               (current_score[0] == best_hand_score[0] and current_score[1] > best_hand_score[1]):
                best_hand_score = current_score
        
        return best_hand_score

    def _evaluate_5_card_combo(self, combo: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        """Evaluates a single 5-card hand, returns (rank_score, tiebreaker_ranks)."""
        ranks = sorted([c[0] for c in combo], reverse=True)
        suits = [c[1] for c in combo]

        is_flush = len(set(suits)) == 1
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        if is_ace_low_straight:
            is_straight = True
            ranks = [5, 4, 3, 2, 1] # Treat Ace as 1 for scoring this hand

        if is_straight and is_flush: return (9, ranks)  # Straight Flush
        
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        major_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)
        
        if counts == [4, 1]: return (8, major_ranks)    # Four of a Kind
        if counts == [3, 2]: return (7, major_ranks)    # Full House
        if is_flush: return (6, ranks)                  # Flush
        if is_straight: return (5, ranks)               # Straight
        if counts[0] == 3: return (4, major_ranks)      # Three of a Kind
        if counts == [2, 2, 1]: return (3, major_ranks) # Two Pair
        if counts[0] == 2: return (2, major_ranks)      # One Pair
        
        return (1, ranks)                               # High Card

    def _calculate_outs(self, my_cards: List[str], community_cards: List[str]) -> int:
        """Calculates the number of 'outs' to make a straight or flush."""
        if len(community_cards) >= 5: return 0
        
        all_cards = [self._parse_card(c) for c in my_cards + community_cards]
        current_ranks = {c[0] for c in all_cards}
        
        # Flush draw outs
        suit_counts = Counter(c[1] for c in all_cards)
        flush_draw_suit = None
        for suit, count in suit_counts.items():
            if count == 4:
                flush_draw_suit = suit
                break
        flush_outs = (13 - len([c for c in all_cards if c[1] == flush_draw_suit])) if flush_draw_suit else 0
        
        # Straight draw outs
        straight_outs = 0
        possible_straights = []
        for i in range(1, 11): # Ace-low to Ten-high
            possible_straights.append(set(range(i, i + 5)))
        possible_straights.append({14, 2, 3, 4, 5}) # Ace-low
        
        out_cards = set()
        for p_straight in possible_straights:
            missing = p_straight - current_ranks
            if len(missing) == 1:
                out_cards.add(list(missing)[0])
        
        straight_outs = len(out_cards)

        # Correct for double counting
        if flush_draw_suit:
            for rank in out_cards:
                 if (rank, flush_draw_suit) in all_cards:
                     straight_outs -=1 # This card is already on the board, does not help
        # This is a simplification; a more complex review of straight-flush outs would be needed
        
        return flush_outs + straight_outs