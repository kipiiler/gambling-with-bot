from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that uses a rule-based strategy based on hand strength.
    - Fixes the AttributeError from the previous iteration.
    - Implements hand evaluation and a tiered pre-flop/post-flop strategy.
    """
    def __init__(self):
        super().__init__()
        # Hand state, reset at the end of each hand (in on_end_game)
        self.hand: List[str] = []
        
        # Game state, received at the start of each hand
        self.all_players: List[int] = []
        self.big_blind_amount: int = 0

    @staticmethod
    def _parse_card(card: str) -> Tuple[int, str]:
        """ Parses a card string 'Rs' into (rank, suit), e.g., 'Kh' -> (13, 'h'). """
        rank_str = card[:-1]
        suit = card[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return rank, suit

    def _evaluate_hand(self, community_cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
        """
        Evaluates the best 5-card hand from self.hand and community_cards.
        Returns a tuple: (hand_rank, tie_breaker_ranks).
        Hand Ranks: 9=RoyalFlush, 8=StraightFlush, 7=4-of-a-Kind, ..., 1=Pair, 0=HighCard.
        """
        if not self.hand:
            return 0, (0,)

        all_cards_str = self.hand + community_cards
        all_cards = sorted([self._parse_card(c) for c in all_cards_str], key=lambda x: x[0], reverse=True)
        
        ranks = [c[0] for c in all_cards]
        suits = [c[1] for c in all_cards]

        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
            
        is_flush = False
        flush_suit = None
        for s, count in suit_counts.items():
            if count >= 5:
                is_flush = True
                flush_suit = s
                break
        
        flush_cards = []
        if is_flush:
            flush_cards = sorted([c for c in all_cards if c[1] == flush_suit], key=lambda x: x[0], reverse=True)

        def check_straight(card_ranks: List[int]) -> Tuple[int, Tuple[int, ...]]:
            unique_ranks = sorted(list(set(card_ranks)), reverse=True)
            if 14 in unique_ranks and all(x in unique_ranks for x in [2, 3, 4, 5]):
                 return 5, (5, 4, 3, 2, 1)
            if len(unique_ranks) < 5:
                return 0, ()
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - 4 == unique_ranks[i+4]:
                    return unique_ranks[i], tuple(unique_ranks[i:i+5])
            return 0, ()

        if is_flush:
            straight_rank, straight_tie_break = check_straight([c[0] for c in flush_cards])
            if straight_rank:
                return (9, straight_tie_break) if straight_rank == 14 else (8, straight_tie_break)

        counts = sorted(rank_counts.values(), reverse=True)
        sorted_ranks_by_count = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)
        
        if counts[0] == 4:
            quad_rank = sorted_ranks_by_count[0]
            kicker = max(r for r in ranks if r != quad_rank)
            return 7, (quad_rank, kicker)

        if counts[0] >= 3 and len(counts) > 1 and counts[1] >= 2:
            three_rank = -1
            pair_rank = -1
            for r, c in rank_counts.items():
                if c >= 3 and r > three_rank:
                    three_rank = r
            for r, c in rank_counts.items():
                if c >= 2 and r != three_rank and r > pair_rank:
                    pair_rank = r
            if three_rank != -1 and pair_rank != -1:
                return 6, (three_rank, pair_rank)

        if is_flush:
            return 5, tuple(c[0] for c in flush_cards[:5])

        straight_rank, straight_tie_break = check_straight(ranks)
        if straight_rank:
            return 4, straight_tie_break

        if counts[0] == 3:
            trip_rank = sorted_ranks_by_count[0]
            kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)[:2]
            return 3, (trip_rank,) + tuple(kickers)

        if counts[0] == 2:
            pair1_rank = sorted_ranks_by_count[0]
            if len(counts) > 1 and counts[1] == 2:
                pair2_rank = sorted_ranks_by_count[1]
                kicker = max(r for r in ranks if r not in [pair1_rank, pair2_rank])
                return 2, (pair1_rank, pair2_rank, kicker)
            else:
                kickers = sorted([r for r in ranks if r != pair1_rank], reverse=True)[:3]
                return 1, (pair1_rank,) + tuple(kickers)

        return 0, tuple(sorted(ranks, reverse=True)[:5])

    def _get_preflop_hand_tier(self) -> int:
        """ Classifies the starting hand into tiers (1=best, 5=worst). """
        if not self.hand or len(self.hand) != 2:
            return 5

        card1 = self._parse_card(self.hand[0])
        card2 = self._parse_card(self.hand[1])
        r1, s1 = card1; r2, s2 = card2
        
        rank1, rank2 = (max(r1, r2), min(r1, r2))
        is_suited = s1 == s2
        is_pair = r1 == r2
        
        if is_pair and rank1 >= 11: return 1
        if is_suited and rank1 == 14 and rank2 == 13: return 1
        
        if is_pair and rank1 == 10: return 2
        if is_suited and rank1 == 14 and rank2 in [12, 11]: return 2
        if is_suited and rank1 == 13 and rank2 == 12: return 2
        if not is_suited and rank1 == 14 and rank2 == 13: return 2

        if is_pair and rank1 in [9, 8]: return 3
        if is_suited and ( (rank1 == 14 and rank2 == 10) or (rank1 in [13, 12] and rank2 == 11) or (rank1 == 11 and rank2 == 10) ): return 3
        if not is_suited and rank1 == 14 and rank2 == 12: return 3

        if is_pair and rank1 >= 2: return 4
        if is_suited and rank1 == 14: return 4
        if is_suited and rank1 - rank2 == 1: return 4
        
        return 5

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.all_players = all_players
        self.big_blind_amount = blind_amount
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # This method is called at the start of each betting round.
        # The previous error was here; it's now fixed as no state is accessed.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        can_check = to_call == 0

        # Pre-flop Strategy
        if round_state.round == 'Preflop':
            tier = self._get_preflop_hand_tier()
            
            if tier == 1:
                raise_amount = 3 * (round_state.current_bet if round_state.current_bet > self.big_blind_amount else self.big_blind_amount)
                if raise_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(max(raise_amount, round_state.min_raise), remaining_chips)

            if tier == 2:
                if round_state.current_bet <= self.big_blind_amount:
                    raise_amount = int(2.5 * self.big_blind_amount)
                    if raise_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, min(max(raise_amount, round_state.min_raise), remaining_chips)
                else:
                    if to_call <= 3 * self.big_blind_amount and to_call < remaining_chips:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            
            if tier == 3 or tier == 4:
                if to_call <= 1.5 * self.big_blind_amount:
                    if can_check: return PokerAction.CHECK, 0
                    if to_call < remaining_chips: return PokerAction.CALL, 0
                    else: return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0
            
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # Post-flop Strategy
        else:
            hand_rank, _ = self._evaluate_hand(round_state.community_cards)

            if hand_rank >= 2:  # Two Pair or better
                bet_amount = int(pot * 0.75) if can_check else 3 * round_state.current_bet
                if bet_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(max(bet_amount, round_state.min_raise), remaining_chips)

            elif hand_rank == 1:  # One Pair
                if can_check: return PokerAction.CHECK, 0
                if to_call <= pot * 0.5 and to_call < remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            
            else:  # High Card / Draws
                if can_check: return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset hand-specific state for the next hand.
        self.hand = []