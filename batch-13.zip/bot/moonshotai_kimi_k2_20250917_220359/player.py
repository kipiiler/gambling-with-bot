from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.blind_amount = 10
        self.is_small_blind = False
        self.is_big_blind = False
        self.fold_percent = 0.8
        self.call_percent = 0.15
        self.raise_percent = 0.05
        self.game_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.is_small_blind = small_blind_player_id == self.id
        self.is_big_blind = big_blind_player_id == self.id
        self.game_count += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        round_name = round_state.round
        community_cards = round_state.community_cards

        # Get my current bet from player_bets
        my_bet = round_state.player_bets.get(str(self.id), 0)

        # Calculate how much more I need to call
        to_call = max(0, current_bet - my_bet)

        # Simple hand evaluation based on hole cards
        hand_strength = self.evaluate_hole_cards()

        # Adjust strategy based on round
        if round_name == 'Preflop':
            if self.is_big_blind and current_bet == self.blind_amount and to_call == 0:
                # Can check as big blind if no raise
                return PokerAction.CHECK, 0
            elif self.is_small_blind and current_bet == self.blind_amount // 2 and to_call == 0:
                # Can check as small blind if no raise
                return PokerAction.CHECK, 0

            # Preflop strategy - tighter
            if hand_strength < 0.3:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength < 0.6:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call <= self.blind_amount:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call <= self.blind_amount * 2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            # Post-flop strategy - more conservative
            if len(community_cards) >= 3:
                hand_strength = self.evaluate_board_strength(community_cards)

            if hand_strength < 0.4:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength < 0.7:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call <= pot * 0.1:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def evaluate_hole_cards(self) -> float:
        """Simple evaluation of hole cards strength"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.0

        card1, card2 = self.hole_cards
        rank1 = card1[0]
        rank2 = card2[0]
        suit1 = card1[1]
        suit2 = card2[1]

        # Pairs are strong
        if rank1 == rank2:
            return 0.8

        # Suited cards
        is_suited = suit1 == suit2

        # High cards
        high_cards = {'A', 'K', 'Q', 'J', 'T'}
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                       '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 0)
        val2 = rank_values.get(rank2, 0)
        max_val = max(val1, val2)
        min_val = min(val1, val2)

        # Connected cards
        is_connected = abs(val1 - val2) <= 1

        score = 0.0
        if max_val >= 12:  # A, K, Q
            score += 0.3
        elif max_val >= 10:  # J, T
            score += 0.2

        if is_suited:
            score += 0.1

        if is_connected:
            score += 0.1

        if min_val >= 10:
            score += 0.2

        return min(score, 1.0)

    def evaluate_board_strength(self, community_cards: List[str]) -> float:
        """Simple evaluation of hand strength with community cards"""
        return self.evaluate_hole_cards() * 0.8  # Reduce strength post-flop without proper evaluation