from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.community_cards = []
        self.position = 0    # 0 = early, 1 = middle, 2 = late
        self.stack = 10000
        self.active = True   # whether we're still in current hand
        self.num_opponents = 0
        self.last_action = None
        self.action_history = []  # track action sequence
        self.aggression_count = 0  # how aggressive we've been
        self.round_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands[:] if len(player_hands) == 2 else player_hands
        self.community_cards = []
        self.stack = starting_chips
        self.active = True
        self.num_opponents = len(all_players) - 1
        self.last_action = None
        self.action_history = []
        self.aggression_count = 0
        self.round_count = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack = remaining_chips
        self.community_cards = round_state.community_cards[:]  # deep copy to avoid mutation
        self.round_count += 1
        # Determine position based on order in player list (assumed: last ≈ late, first ≈ early)
        if self.id in round_state.current_player:
            idx = round_state.current_player.index(self.id)
            self.position = min(2, idx)  # map 0->early, 1->middle, 2->late

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        self.stack = remaining_chips
        my_bet_so_far = round_state.player_bets.get(self.id, 0)
        current_bet = round_state.current_bet
        to_call = current_bet - my_bet_so_far
        round_name = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'
        num_active_players = len(round_state.current_player)

        # Hand strength estimation via heuristic smiley scale 0.0–1.0
        hs = self.estimate_hand_strength(round_name, num_active_players)
        # Pot-odds fish flavor cheap calls
        podds = 0.0
        if to_call > 0 and (round_state.pot + to_call) > 0:
            podds = to_call / (round_state.pot + to_call + 1e-6)

        # Threat model: aggression ramp
        threat = hs - podds + self.position * 0.03
        # Add randomization to spice exploitative horizon
        if random.random() < 0.05:
            threat = min(1.0, threat + random.uniform(-0.2, 0.2))

        # Branch decision tree respecting legality
        if current_bet == 0:
            assert to_call == 0
            # Free play
            if threat > 0.50:
                # Raise sizing non-linear progression
                mult = max(0.5, min(3.0, 1.0 * threat * threat))
                base = 2 * round_state.min_raise if round_state.min_raise > 0 else (max(1, blind_amount if hasattr(self, 'blind_amount') else 200))
                size = math.floor(mult * (self.stack if base == 0 else base))
                # Boundaries
                size = min(size, self.stack, round_state.max_raise)
                size = max(2 * round_state.min_raise, round_state.min_raise) if round_state.min_raise > 0 else size
                if size > 0 and size <= self.stack:
                    self.aggression_count += 1
                    return (PokerAction.RAISE, size)
            # Lazy check unless forced to defend
            return (PokerAction.CHECK, 0)
        else:
            # Facing bet
            if threat > (0.75 + self.position * 0.02):
                # All-in monster by design (risky but maximizes delta)
                return (PokerAction.ALL_IN, 0)
            elif threat > 0.48:
                if to_call <= 0:
                    # Should not happen
                    return (PokerAction.CHECK, 0)
                # Call mildly if price is honest
                can_call = (self.stack >= to_call)
                if can_call and (to_call / (self.stack + 1e-6) < 0.35):
                    return (PokerAction.CALL, 0)
                else:
                    # else jam if smallish stack
                    return (PokerAction.ALL_IN, 0)
            else:
                # Semi-bluff raise?
                if threat > 0.32 and random.random() < 0.15:
                    mult = random.uniform(1.0, 2.2)
                    amt = int(mult * (round_state.min_raise + current_bet) - my_bet_so_far)
                    amt = min(amt, self.stack, round_state.max_raise)
                    amt = max(amt, round_state.min_raise) if round_state.min_raise > 0 else amt
                    if amt > to_call and self.stack >= amt + my_bet_so_far:
                        self.aggression_count += 1
                        return (PokerAction.RAISE, amt)
                # Also semi-folding draws or bricks
                if random.random() < 0.95 or self.stack < to_call:
                    return (PokerAction.FOLD, 0)
                return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack = remaining_chips
        self.community_cards = round_state.community_cards[:]
        self.last_action = round_state.player_actions.get(self.id, "")

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing to do
        pass

    def estimate_hand_strength(self, round_name: str, num_active: int) -> float:
        """Returns 0.0 (trash) to 1.0 (near nuts) heuristic pandas strength."""
        # Basic card utility
        def card_rank(c):
            r = c[0]
            if r == 'T': return 8
            if r == 'J': return 9
            if r == 'Q': return 10
            if r == 'K': return 11
            if r == 'A': return 12
            return int(r) - 2
        def card_suit(c):
            return c[1]

        if len(self.hole_cards) < 2:
            return 0.0

        c1, c2 = self.hole_cards[0], self.hole_cards[1]
        r1, s1 = card_rank(c1), card_suit(c1)
        r2, s2 = card_rank(c2), card_suit(c2)

        # Suited pairs very nice
        suited = (s1 == s2)
        pair = (r1 == r2)
        high = max(r1, r2)
        low = min(r1, r2)
        gap = high - low

        # Start base strength
        s = 0.10
        # Premium pairs AA-TT
        if pair:
            if high >= 12:  # AA, KK
                s += 0.85
            elif high >= 10:  # QQ, JJ, TT
                s += 0.70
            elif high >= 7:   # 99-77
                s += 0.50
            else:
                s += 0.28
        else:
            # High broadways
            if high >= 12:
                s += 0.35
            elif high >= 9:
                s += 0.18
            else:
                s += 0.05
            # Suitedness important
            if suited:
                s += 0.07
            # Connectivity for drawing
            if gap == 0:
                s += 0.06
            elif gap == 1:
                s += 0.04
            else:
                s += 0.01
            # Very trash off-suit big gap ding
            if gap >= 6 and not suited:
                s -= 0.10
        # Community apply simple nuts board fit
        all_cards = [c1, c2] + self.community_cards
        if len(all_cards) >= 5:
            board_ranks = []
            for c in all_cards:
                board_ranks.append(card_rank(c))
            board_ranks.sort(reverse=True)
            # Notice if we hit nut flush or quads with helper subsets
            suits = [card_suit(c) for c in all_cards]
            flush_test = False
            for suit in set(suits):
                if suits.count(suit) >= 5:
                    flush_test = True
            if flush_test:
                s += 0.25  # rough flush bonus
            # Simple quad-trip surrogate
            if board_ranks.count(board_ranks[0]) >= 4:
                s += 0.40
            elif board_ranks.count(board_ranks[0]) >= 3:
                s += 0.15
        # Add subtle positional edge
        s += self.position * 0.02
        # Crush multiway discount
        s = s / (1 + max(1, num_active - 2) * 0.05)
        return min(1.0, max(0.0, s))