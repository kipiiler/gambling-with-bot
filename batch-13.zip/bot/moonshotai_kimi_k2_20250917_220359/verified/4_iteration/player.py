from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 10
        self.hole_cards = []
        self.position = None
        self.current_bet = 0
        self.round_actions = {}
        self.opponent_tendencies = {
            'aggression': 0.0,
            'fold_frequency': 0.0,
            'raise_frequency': 0.0
        }
        self.hand_strength_cache = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands.copy()
        
        # Determine position
        if len(all_players) == 2:
            if self.id == small_blind_player_id:
                self.position = 'small_blind'
            elif self.id == big_blind_player_id:
                self.position = 'big_blind'
            else:
                self.position = 'other'
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_bet = 0
        self.round_actions = {}
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            community_cards = round_state.community_cards
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            
            # Calculate hand strength
            hand_strength = self.evaluate_hand_strength(self.hole_cards, community_cards)
            
            # Determine action based on hand strength and position
            if hand_strength >= 0.8:  # Strong hand
                return self.play_aggressive(round_state, remaining_chips, hand_strength)
            elif hand_strength >= 0.6:  # Medium strength
                return self.play_moderate(round_state, remaining_chips, hand_strength)
            else:  # Weak hand
                return self.play_passive(round_state, remaining_chips, hand_strength)
                
        except Exception as e:
            # Default to fold on any error
            return (PokerAction.FOLD, 0)
    
    def play_aggressive(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        
        # If no bet to call, raise
        if current_bet == 0:
            if min_raise <= max_raise:
                raise_amount = max(min_raise, min(max_raise, int(pot * 0.75)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CHECK, 0)
        
        # If there's a bet to call, raise if possible
        call_amount = current_bet - (self.current_bet if hasattr(self, 'current_bet') else 0)
        
        if min_raise > 0 and min_raise <= max_raise:
            raise_amount = max(min_raise, min(max_raise, int(pot * 0.75)))
            return (PokerAction.RAISE, raise_amount)
        elif call_amount <= remaining_chips:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def play_moderate(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        
        # If no bet to call
        if current_bet == 0:
            if min_raise <= max_raise:
                raise_amount = max(min_raise, min(max_raise, int(pot * 0.5)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CHECK, 0)
        
        # If there's a bet to call
        call_amount = current_bet - (self.current_bet if hasattr(self, 'current_bet') else 0)
        
        # Call if the bet is reasonable
        if call_amount <= pot * 0.3 and call_amount <= remaining_chips:
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def play_passive(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        pot = round_state.pot
        
        # If no bet to call, check
        if current_bet == 0:
            return (PokerAction.CHECK, 0)
        
        # If there's a bet to call, fold most of the time
        call_amount = current_bet - (self.current_bet if hasattr(self, 'current_bet') else 0)
        
        # Only call if it's a very small bet
        if call_amount <= pot * 0.1 and call_amount <= remaining_chips:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Basic hand evaluation
        all_cards = hole_cards + community_cards
        
        # High card values
        values = []
        for card in hole_cards:
            rank = card[0]
            if rank == 'A': values.append(14)
            elif rank == 'K': values.append(13)
            elif rank == 'Q': values.append(12)
            elif rank == 'J': values.append(11)
            elif rank == 'T': values.append(10)
            else: values.append(int(rank))
        
        # Pair in hand
        if hole_cards[0][0] == hole_cards[1][0]:
            return 0.7
        
        # High cards
        if max(values) >= 12:
            return 0.4
        
        # Connected cards
        if abs(values[0] - values[1]) <= 2:
            return 0.3
        
        # Suited cards
        if hole_cards[0][1] == hole_cards[1][1]:
            return 0.35
        
        return 0.1
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass