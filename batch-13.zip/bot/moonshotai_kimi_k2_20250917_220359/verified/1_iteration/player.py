from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math
from collections import defaultdict

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_stats = defaultdict(lambda: {'vpip': 0, 'pfr': 0, 'hands': 0, 'aggression': 0})
        self.my_hand = []
        self.table_position = 0
        self.players_count = 0
        self.stack_sizes = {}
        self.stage_actions = {
            'Preflop': self._preflop_action,
            'Flop': self._postflop_action,
            'Turn': self._postflop_action,
            'River': self._postflop_action
        }
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.players_count = len(all_players)
        self.player_hands = player_hands
        for i, player_id in enumerate(all_players):
            if player_id == self.id:
                self.table_position = i
                break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_hand = self.player_hands.copy()
        self.remaining_chips = remaining_chips
        self.round_state = round_state

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        self.round_state = round_state
        
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Get current street action function
        action_func = self.stage_actions.get(round_state.round, self._default_action)
        return action_func(round_state, current_bet, min_raise, max_raise, remaining_chips)

    def _preflop_action(self, round_state, current_bet, min_raise, max_raise, remaining_chips):
        hand_strength = self._evaluate_hand_strength(self.my_hand, [])
        position_strength = self._get_position_strength()
        
        # Adjust for players in hand
        active_players = [p for p in round_state.current_player if str(p) in round_state.player_actions]
        players_in_hand = len(active_players)
        
        # Calculate effective stack size in big blinds
        bb_size = max(100, round_state.pot // 3) if round_state.pot > 0 else 100
        effective_stack = remaining_chips / bb_size
        
        # Tight-aggressive preflop strategy
        open_raise_range = ['AA', 'KK', 'QQ', 'JJ', 'TT', '99', '88', '77', 'AKs', 'AQs', 'AJs', 'AKo']
        raise_range = ['66', '55', '44', '33', '22', 'AJs', 'KQs', 'ATs', 'AQo', 'KQo']
        call_range = ['AJs', 'ATs', 'KJs', 'QJs', 'JTs', 'AQo', 'KJo', 'QJo']
        
        my_hand_str = self._hand_to_string(self.my_hand)
        
        # Base decision
        if my_hand_str[:2] in open_raise_range or my_hand_str in open_raise_range:
            strength = 0.9
        elif my_hand_str[:2] in raise_range or my_hand_str in raise_range:
            strength = 0.7
        elif my_hand_str[:2] in call_range or my_hand_str in call_range:
            strength = 0.5
        else:
            strength = 0.2
            
        # Add position adjustment
        strength *= position_strength
        
        # Add bluffing component
        bluff_probability = 0.1 if players_in_hand <= 3 else 0.05
        
        # Make decision
        if current_bet == 0:
            # Can check or bet
            if strength > 0.7:
                raise_amount = max(min_raise, min(int(bb_size * 2.5), max_raise))
                return PokerAction.RAISE, raise_amount
            elif strength > 0.4 or random.random() < bluff_probability:
                raise_amount = max(min_raise, min(int(bb_size * 2), max_raise))
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            # Need to call, raise, or fold
            call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
            pot_odds = call_amount / (round_state.pot + call_amount + 1e-6)
            
            # Simple decision based on pot odds and hand strength
            if strength > 0.7 or (strength > 0.5 and pot_odds < 0.3):
                if strength > 0.8 and max_raise > current_bet * 3:
                    raise_amount = min(int(current_bet * 3), max_raise)
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif strength > 0.3 and pot_odds < 0.2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _postflop_action(self, round_state, current_bet, min_raise, max_raise, remaining_chips):
        community_cards = round_state.community_cards
        hand_strength = self._evaluate_hand_strength(self.my_hand, community_cards)
        
        # Calculate pot odds
        call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_odds = call_amount / (round_state.pot + call_amount + 1e-6)
        
        # Determine board texture
        board_text = self._analyze_board_texture(community_cards)
        
        # Aggression factor based on hand strength and board
        aggression_factor = self._calculate_aggression(hand_strength, board_text, pot_odds)
        
        # Make decision
        if current_bet == 0:
            if hand_strength > 0.7 or (hand_strength > 0.5 and random.random() < 0.3):
                bet_size = max(min_raise, min(int(round_state.pot * 0.7), max_raise))
                return PokerAction.RAISE, bet_size
            else:
                return PokerAction.CHECK, 0
        else:
            if hand_strength > 0.8:
                if max_raise > current_bet * 2:
                    raise_amount = min(int(current_bet * 2), max_raise)
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif hand_strength > 0.6:
                if pot_odds < 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength > 0.4 and pot_odds < 0.15:
                return PokerAction.CALL, 0
            elif hand_strength > 0.3 and pot_odds < 0.1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _default_action(self, round_state, current_bet, min_raise, max_raise, remaining_chips):
        # Fallback action
        if current_bet == 0:
            return PokerAction.CHECK, 0
        else:
            call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
            if call_amount < remaining_chips * 0.1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, hand, community_cards):
        """Simple hand strength evaluation"""
        if not hand:
            return 0.0
            
        # Convert cards to simple representation
        our_cards = hand
        all_cards = our_cards + community_cards
        
        # Basic evaluation - count high cards and potential
        high_cards = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        total_value = 0
        
        # Count pairs, suits, ranks
        ranks = {}
        suits = {}
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            
            if rank in high_cards:
                rank_num = high_cards[rank]
            else:
                rank_num = int(rank)
                
            ranks[rank] = ranks.get(rank, 0) + 1
            suits[suit] = suits.get(suit, 0) + 1
            
        # Count pairs/trips/quads
        pair_count = 0
        trips_count = 0
        for count in ranks.values():
            if count == 2:
                pair_count += 1
            elif count == 3:
                trips_count += 1
            elif count == 4:
                return 0.9  # Quads
                
        # Flush potential
        max_suit = max(suits.values()) if suits else 0
        
        # Simple scoring
        score = 0.2
        if not community_cards:
            # Pre-flop evaluation
            our_ranks = [c[0] for c in our_cards]
            our_suits = [c[1] for c in our_cards]
            
            if our_ranks[0] == our_ranks[1]:
                score = 0.8
            elif our_ranks[0] in high_cards and our_ranks[1] in high_cards:
                score = 0.7
            elif our_suits[0] == our_suits[1]:
                score = 0.6
            elif any(r in high_cards for r in our_ranks):
                score = 0.5
            else:
                score = 0.3
        else:
            # Post-flop evaluation
            if trips_count == 1:
                score = 0.85
            elif pair_count >= 2:
                score = 0.75
            elif pair_count == 1:
                score = 0.6
            elif max_suit >= 5:
                score = 0.65
            else:
                # Check for potential draws
                rank_nums = sorted([high_cards.get(r, int(r)) for r in ranks.keys()])
                straight_potential = self._check_straight_potential(rank_nums)
                flush_potential = 1 if max_suit >= 4 else 0
                
                score = 0.4 + (straight_potential * 0.1) + (flush_potential * 0.15)
                
        return min(score, 1.0)

    def _hand_to_string(self, hand):
        """Convert hand to string representation"""
        if not hand or len(hand) < 2:
            return ''
        
        ranks = [c[0] for c in hand]
        suits = [c[1] for c in hand]
        
        # Create hand string (e.g., "AKs", "54o")
        if ranks[0] == ranks[1]:
            return ranks[0] * 2
        
        if suits[0] == suits[1]:
            suffix = 's'
        else:
            suffix = 'o'
            
        # Order ranks
        high_low = sorted(ranks, key=lambda x: {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}.get(x, int(x)))
            
        return ''.join(reversed(high_low)) + suffix

    def _get_position_strength(self):
        """Calculate position advantage"""
        if self.players_count <= 2:
            return 1.0  # Heads-up
        
        position = (self.table_position / max(self.players_count - 1, 1))
        return 1.0 + (0.5 * position)

    def _check_straight_potential(self, ranks):
        """Check if we have straight potential"""
        if len(ranks) < 3:
            return 0
            
        for i in range(len(ranks) - 2):
           如果 ranks[i+2] - ranks[i] <= 4:
                return 0.7
        return 0

    def _analyze_board_texture(self, community_cards):
        """Simple board texture analysis"""
        if not community_cards:
            return 'dry'
            
        ranks = [c[0] for c in community_cards]
        suits = [c[1] for c in community_cards]
        
        # Check for paired board
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
            
        if max(rank_counts.values()) >= 2:
            return 'paired'
            
        # Check for flush potential
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
            
        if max(suit_counts.values()) >= 3:
            return 'flush_possible'
            
        return 'dry'

    def _calculate_aggression(self, hand_strength, board_text, pot_odds):
        """Calculate aggression factor based on position and hand"""
        base_aggression = hand_strength
        
        if board_text == 'paired':
            base_aggression *= 1.2
        elif board_text == 'flush_possible':
            base_aggression *= 0.8
            
        if pot_odds < 0.2:
            base_aggression *= 1.1
            
        return base_aggression

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass