from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.current_hand = []
        self.position = None
        self.is_big_blind = False
        self.is_small_blind = False
        self.blind_amount = 10
        self.opponent_tendency = 0.5
        self.our_bet_this_round = 0
        self.tightness = 0.6

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.current_hand = player_hands
        self.blind_amount = blind_amount
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        if len(all_players) == 2:
            if self.id == all_players[0]:
                self.position = 0
            else:
                self.position = 1
        else:
            try:
                idx = all_players.index(self.id)
                self.position = idx / len(all_players)
            except ValueError:
                self.position = 0.5

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.our_bet_this_round = 0
        pass

    def hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
        if not community_cards:
            rank1 = hole_cards[0][0]
            rank2 = hole_cards[1][0]
            if rank1 == rank2:
                return 0.85
            elif rank1 in 'AKQJ' and rank2 in 'AKQJ':
                return 0.65
            elif rank1 in 'AKQJ' or rank2 in 'AKQJ':
                return 0.45
            elif rank1 == rank2[0] and abs(self.card_rank(rank1) - self.card_rank(rank2)) <= 1:
                return 0.55
            else:
                return 0.25
        else:
            made_score = 0.0
            pair_bonus = 0.0
            for c in community_cards:
                if c[0] in [hole_cards[0][0], hole_cards[1][0]]:
                    pair_bonus = 0.5
            if len(community_cards) >= 3:
                made_score = 0.3
            if len(community_cards) >= 4:
                made_score = 0.5
            if len(community_cards) == 5:
                made_score = 0.6
            return min(0.9, made_score + pair_bonus)

    def card_rank(self, rank_char: str) -> int:
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                   'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(rank_char, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.current_hand
        community_cards = round_state.community_cards
        pot = round_state.pot
        current_bet = round_state.current_bet
        to_call = max(0, current_bet - self.our_bet_this_round)
        strength = self.hand_strength(hole_cards, community_cards)
        round_name = round_state.round.lower()
        is_preflop = (round_name == 'preflop')
        is_flop = (round_name == 'flop')
        is_turn = (round_name == 'turn')
        is_river = (round_name == 'river')
        effective_stack = remaining_chips
        pot_odds = 0.0
        if to_call > 0 and pot > 0:
            pot_odds = to_call / (pot + to_call + 1e-6)
        else:
            pot_odds = 0.0
        aggression_factor = 0.7
        if is_preflop:
            if self.is_big_blind and to_call == 0:
                if strength >= 0.65:
                    raise_amt = max(round_state.min_raise, int(0.3 * pot))
                    raise_amt = min(raise_amt, remaining_chips)
                    self.our_bet_this_round += raise_amt
                    return (PokerAction.RAISE, raise_amt)
                else:
                    return (PokerAction.CHECK, 0)
            elif to_call > 0:
                if strength >= 0.85:
                    if effective_stack > to_call * 5:
                        raise_amt = max(round_state.min_raise, int(0.5 * (pot + to_call)))
                        raise_amt = min(raise_amt, remaining_chips)
                        self.our_bet_this_round += raise_amt
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif strength >= 0.55:
                    if pot_odds <= 0.35:
                        self.our_bet_this_round += to_call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if pot_odds <= 0.25:
                        self.our_bet_this_round += to_call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                if strength >= 0.65:
                    raise_amt = max(round_state.min_raise, int(0.25 * pot))
                    raise_amt = min(raise_amt, remaining_chips)
                    self.our_bet_this_round += raise_amt
                    return (PokerAction.RAISE, raise_amt)
                else:
                    return (PokerAction.CHECK, 0)
        else:
            if to_call == 0:
                if strength >= 0.5:
                    bet_amt = max(round_state.min_raise, int(0.35 * pot))
                    bet_amt = min(bet_amt, remaining_chips)
                    self.our_bet_this_round += bet_amt
                    return (PokerAction.RAISE, bet_amt)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if strength >= 0.7:
                    if effective_stack > to_call * 4:
                        raise_amt = max(round_state.min_raise, int(0.6 * (pot + to_call)))
                        raise_amt = min(raise_amt, remaining_chips)
                        self.our_bet_this_round += raise_amt
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif strength >= 0.4:
                    if pot_odds <= 0.4:
                        self.our_bet_this_round += to_call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if pot_odds <= 0.25:
                        self.our_bet_this_round += to_call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass