from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
from collections import Counter
from itertools import combinations

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.all_players = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.hole_cards is None or len(self.hole_cards) != 2:
            return PokerAction.FOLD, 0

        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot

        num_active = len(round_state.current_player)
        num_opp = max(1, num_active - 1)
        sims = max(50, 300 // (1 + num_opp))

        all_cards_list = [r + s for r in '23456789TJQKA' for s in 'hscd']
        known = set(self.hole_cards + round_state.community_cards)
        remaining = [c for c in all_cards_list if c not in known]

        equity = self.calculate_equity(self.hole_cards, round_state.community_cards, remaining, num_opp, sims)

        if to_call <= 0:
            if equity > 0.6:
                raise_size = pot + round_state.current_bet
                raise_size = max(round_state.min_raise, raise_size)
                raise_size = min(raise_size, remaining_chips)
                if raise_size > 0:
                    return PokerAction.RAISE, raise_size
            return PokerAction.CHECK, 0
        else:
            call_amount = min(to_call, remaining_chips)
            pot_after = pot + call_amount
            pot_odds = call_amount / (pot_after + 1e-6)

            if equity > pot_odds + 0.1:
                if equity > 0.7 and remaining_chips > call_amount:
                    additional_min = to_call + round_state.min_raise
                    if additional_min > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    raise_size = to_call + pot
                    raise_size = max(additional_min, raise_size)
                    raise_size = min(raise_size, remaining_chips)
                    return PokerAction.RAISE, raise_size
                if call_amount >= remaining_chips:
                    if equity > 0.5:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank_str, suit = card[0], card[1]
        rank = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}[rank_str]
        return rank, suit

    def evaluate_hand(self, cards: List[Tuple[int, str]]) -> List[int]:
        if len(cards) < 5:
            ranks_desc = sorted([r for r, s in cards], reverse=True)
            return [0] + ranks_desc + [0] * (5 - len(ranks_desc))
        best = max((self.evaluate_5card(list(combo)) for combo in combinations(cards, 5)), key=lambda x: tuple(x))
        return best

    def evaluate_5card(self, cards5: List[Tuple[int, str]]) -> List[int]:
        ranks = [r for r, s in cards5]
        suits = [s for r, s in cards5]
        ranks_desc = sorted(ranks, reverse=True)
        rank_count = Counter(ranks)
        suit_count = Counter(suits)
        is_flush = max(suit_count.values()) == 5
        min_r = min(ranks)
        max_r = max(ranks)
        is_straight = (len(set(ranks)) == 5 and (max_r - min_r == 4)) or (set(ranks) == {14, 5, 4, 3, 2})
        straight_ranks = ranks_desc
        if set(ranks) == {14, 5, 4, 3, 2}:
            straight_ranks = [5, 4, 3, 2, 1]
        if is_straight and is_flush:
            return [8] + straight_ranks
        if 4 in rank_count.values():
            quad = next(k for k, v in rank_count.items() if v == 4)
            kicker = next(k for k in ranks if k != quad)
            return [7, quad, quad, quad, quad, kicker]
        if 3 in rank_count.values() and 2 in rank_count.values():
            three = next(k for k, v in rank_count.items() if v == 3)
            two = next(k for k, v in rank_count.items() if v == 2)
            return [6, three, three, three, two, two]
        if is_flush:
            return [5] + ranks_desc
        if is_straight:
            return [4] + straight_ranks
        if 3 in rank_count.values():
            three = next(k for k, v in rank_count.items() if v == 3)
            kickers = sorted([k for k in ranks if k != three], reverse=True)
            return [3, three, three, three, kickers[0], kickers[1]]
        if list(rank_count.values()).count(2) >= 2:
            pairs = sorted([k for k, v in rank_count.items() if v == 2], reverse=True)[:2]
            kicker = next(k for k in ranks if k not in pairs)
            return [2, pairs[0], pairs[0], pairs[1], pairs[1], kicker]
        if 2 in rank_count.values():
            pair = next(k for k, v in rank_count.items() if v == 2)
            kickers = sorted([k for k in ranks if k != pair], reverse=True)
            return [1, pair, pair, kickers[0], kickers[1], kickers[2]]
        return [0] + ranks_desc

    def calculate_equity(self, hole_cards: List[str], community: List[str], remaining: List[str], num_opponents: int, num_sim: int) -> float:
        if num_sim == 0:
            return 0.5
        wins = 0
        ties = 0
        cards_to_deal = 5 - len(community)
        for _ in range(num_sim):
            rem = remaining[:]
            random.shuffle(rem)
            board = community + rem[:cards_to_deal]
            rem = rem[cards_to_deal:]
            my_parsed = [self.parse_card(c) for c in hole_cards + board]
            my_hand = self.evaluate_hand(my_parsed)
            is_win = True
            is_tie = False
            for _ in range(num_opponents):
                if len(rem) < 2:
                    break
                opp_hole = rem[:2]
                rem = rem[2:]
                opp_parsed = [self.parse_card(c) for c in opp_hole + board]
                opp_hand = self.evaluate_hand(opp_parsed)
                cmp = self.compare_hands(my_hand, opp_hand)
                if cmp < 0:
                    is_win = False
                    is_tie = False
                    break
                elif cmp == 0:
                    is_tie = True
            if is_win:
                wins += 1
            elif is_tie:
                ties += 1
        total = wins + ties / 2.0
        equity = total / num_sim if num_sim > 0 else 0.5
        return equity

    def compare_hands(self, h1: List[int], h2: List[int]) -> int:
        return 1 if tuple(h1) > tuple(h2) else (-1 if tuple(h1) < tuple(h2) else 0)