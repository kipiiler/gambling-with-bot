from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.bb = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.bb = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def card_to_tuple(self, card: str) -> Tuple[int, str]:
        rank_str = card[0]
        suit = card[1]
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        rank = rank_map[rank_str]
        return rank, suit

    def evaluate_hand(self, cards: List[str]) -> int:
        parsed = [self.card_to_tuple(c) for c in cards]
        ranks = [r for r, s in parsed]
        suits = [s for r, s in parsed]
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        sorted_ranks = sorted(ranks, reverse=True)
        is_flush = all(s == suits[0] for s in suits)
        rank_set = set(ranks)
        is_straight = (len(rank_set) == 5) and (max(ranks) - min(ranks) == 4 or rank_set == {14, 5, 4, 3, 2})
        high = max(ranks)
        if is_straight and rank_set == {14, 5, 4, 3, 2}:
            high = 5
            sorted_ranks = [5, 4, 3, 2, 1]

        if is_straight and is_flush:
            if sorted_ranks == [14, 13, 12, 11, 10]:
                return 9 * 10**10  # royal flush
            return 8 * 10**10 + high * 10**8  # straight flush

        if 4 in rank_counts.values():
            quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r in sorted_ranks if r != quad_rank][0]
            return 7 * 10**10 + quad_rank * 10**8 + kicker * 10**6  # four of a kind

        if 3 in rank_counts.values() and 2 in rank_counts.values():
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            two_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return 6 * 10**10 + three_rank * 10**8 + two_rank * 10**6  # full house

        if is_flush:
            return 5 * 10**10 + sum(r * 10**(8 - 2 * i) for i, r in enumerate(sorted_ranks))  # flush

        if is_straight:
            return 4 * 10**10 + high * 10**8  # straight

        if 3 in rank_counts.values():
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r in sorted_ranks if r != three_rank], reverse=True)
            return 3 * 10**10 + three_rank * 10**8 + kickers[0] * 10**6 + kickers[1] * 10**4  # three of a kind

        if list(rank_counts.values()).count(2) == 2:
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r in sorted_ranks if r not in pairs][0]
            return 2 * 10**10 + pairs[0] * 10**8 + pairs[1] * 10**6 + kicker * 10**4  # two pair

        if 2 in rank_counts.values():
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r in sorted_ranks if r != pair_rank], reverse=True)[:3]
            return 1 * 10**10 + pair_rank * 10**8 + kickers[0] * 10**6 + kickers[1] * 10**4 + kickers[2] * 10**2  # pair

        return 0 + sum(r * 10**(8 - 2 * i) for i, r in enumerate(sorted_ranks))  # high card

    def get_best_hand_score(self, hole: List[str], community: List[str]) -> int:
        all_cards = hole + community
        if len(all_cards) < 5:
            return 0
        max_score = 0
        for combo in itertools.combinations(all_cards, 5):
            score = self.evaluate_hand(list(combo))
            if score > max_score:
                max_score = score
        return max_score

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        stack = remaining_chips
        pot = round_state.pot + 0.0001  # avoid divide by zero
        is_preflop = round_state.round == 'Preflop'

        if is_preflop:
            if len(self.hole_cards) != 2:
                return PokerAction.FOLD, 0
            ranks = sorted([r for r, _ in [self.card_to_tuple(c) for c in self.hole_cards]], reverse=True)
            suits = [self.card_to_tuple(c)[1] for c in self.hole_cards]
            is_pair = ranks[0] == ranks[1]
            is_suited = suits[0] == suits[1]
            premium = (is_pair and ranks[0] >= 12) or (ranks == [14, 13])
            playable = premium or (is_pair and ranks[0] >= 8) or (max(ranks) >= 11 and min(ranks) >= 10) or (is_suited and max(ranks) >= 10 and min(ranks) >= 9) or (is_suited and abs(ranks[0] - ranks[1]) <= 3)

            if not playable:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if to_call == 0:
                    raise_to = 3 * self.bb
                    raise_by = raise_to - my_bet
                    if raise_by >= round_state.min_raise and raise_by <= stack:
                        return PokerAction.RAISE, raise_by
                    elif raise_by < round_state.min_raise:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    if to_call <= 3 * self.bb or (premium and to_call <= 10 * self.bb):
                        return PokerAction.CALL, 0
                    elif premium:
                        raise_to = 3 * round_state.current_bet
                        raise_by = raise_to - my_bet
                        if raise_by >= round_state.min_raise and raise_by <= stack:
                            return PokerAction.RAISE, raise_by
                        else:
                            return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
        else:
            score = self.get_best_hand_score(self.hole_cards, round_state.community_cards)
            hand_type = score // (10**10)
            if hand_type >= 2:  # two pair or better
                if to_call == 0:
                    bet_amount = int(pot)
                    raise_by = bet_amount - my_bet
                    if raise_by < round_state.min_raise:
                        raise_by = round_state.min_raise
                    if raise_by > stack:
                        if stack >= round_state.min_raise:
                            return PokerAction.RAISE, stack
                        else:
                            return PokerAction.CHECK, 0
                    return PokerAction.RAISE, raise_by
                else:
                    if to_call < pot / 2:
                        return PokerAction.CALL, 0
                    else:
                        raise_by = to_call + int(pot)
                        if raise_by <= stack and raise_by >= round_state.min_raise:
                            return PokerAction.RAISE, raise_by
                        else:
                            return PokerAction.ALL_IN, 0
            elif hand_type >= 1:  # pair
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call < 2 * self.bb:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass