from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.rank_value = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank = self.rank_value[card[0]]
        suit = card[1]
        return rank, suit

    def evaluate_5card(self, cards5: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        ranks = sorted([r for r, s in cards5], reverse=True)
        suits = [s for r, s in cards5]
        is_flush = all(s == suits[0] for s in suits)
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        is_straight = (max(ranks) - min(ranks) == 4 and len(set(ranks)) == 5) or set(ranks) == {14, 5, 4, 3, 2}

        if is_straight:
            straight_high = 5 if set(ranks) == {14, 5, 4, 3, 2} else ranks[0]
            straight_ranks = [straight_high]
        else:
            straight_ranks = []

        if is_flush and is_straight:
            if straight_high == 14:
                return 9, [14]
            return 8, straight_ranks
        if counts[0] == 4:
            quad_rank = next(r for r, c in rank_counts.items() if c == 4)
            kicker = next(r for r, c in rank_counts.items() if c == 1)
            return 7, [quad_rank, kicker]
        if counts == [3, 2]:
            three = next(r for r, c in rank_counts.items() if c == 3)
            two = next(r for r, c in rank_counts.items() if c == 2)
            return 6, [three, two]
        if is_flush:
            return 5, ranks
        if is_straight:
            return 4, straight_ranks
        if counts[0] == 3:
            three = next(r for r, c in rank_counts.items() if c == 3)
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return 3, [three] + kickers[:2]
        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = next(r for r, c in rank_counts.items() if c == 1)
            return 2, pairs + [kicker]
        if counts[0] == 2:
            pair = next(r for r, c in rank_counts.items() if c == 2)
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return 1, [pair] + kickers[:3]
        return 0, ranks

    def get_best_hand(self, cards: List[str]) -> Tuple[int, List[int]]:
        parsed = [self.parse_card(c) for c in cards]
        best_type = -1
        best_tie = []
        for combo in itertools.combinations(parsed, 5):
            typ, tie = self.evaluate_5card(list(combo))
            if typ > best_type or (typ == best_type and tie > best_tie):
                best_type = typ
                best_tie = tie
        return best_type, best_tie

    def get_preflop_strength(self, hole: List[str]) -> float:
        if len(hole) != 2:
            return 0.0
        c1 = self.parse_card(hole[0])
        c2 = self.parse_card(hole[1])
        r1, s1 = c1
        r2, s2 = c2
        if r1 < r2:
            r1, r2 = r2, r1
            s1, s2 = s2, s1
        is_suited = s1 == s2
        is_pair = r1 == r2
        if is_pair:
            return min(1.0, (r1 - 1) / 13.0 + 0.3)
        elif is_suited:
            diff = r1 - r2
            return (r1 / 14.0) * (0.6 if diff < 5 else 0.5) + (0.2 if diff < 5 else 0)
        else:
            diff = r1 - r2
            return (r1 / 14.0) * (0.4 if diff < 3 else 0.3)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        pot_odds = to_call / (pot + to_call + 0.001) if to_call > 0 else 0.0

        if round_state.round == 'Preflop':
            strength = self.get_preflop_strength(self.hole_cards)
        else:
            all_cards = self.hole_cards + round_state.community_cards
            if len(all_cards) < 5:
                strength = 0.0
            else:
                best_type, _ = self.get_best_hand(all_cards)
                strength = best_type / 9.0

        if to_call >= remaining_chips:
            if strength > 0.7:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        if to_call == 0:
            if strength > 0.5:
                raise_amount = max(min_raise, pot // 2)
                raise_amount = min(raise_amount, max_raise)
                if raise_amount >= min_raise:
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            if strength > 0.8 or (strength > 0.4 and pot_odds < 0.2):
                if strength > 0.8:
                    raise_amount = max(min_raise, pot // 2)
                    raise_amount = min(raise_amount, max_raise)
                    total_bet = my_bet + raise_amount
                    if raise_amount >= min_raise and total_bet > round_state.current_bet and raise_amount <= remaining_chips:
                        return PokerAction.RAISE, raise_amount
                    elif remaining_chips >= to_call:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass