from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
from itertools import combinations

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 0
        self.num_players = 0
        self.rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suit_map = {'h': 0, 's': 1, 'd': 2, 'c': 3}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        call_amount = round_state.current_bet - my_bet
        if call_amount < 0:
            call_amount = 0
        can_check = call_amount == 0
        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max_raise
        pot = round_state.pot

        if round_state.round == 'Preflop':
            rank1, suit1 = self.hole_cards[0][0], self.hole_cards[0][1]
            rank2, suit2 = self.hole_cards[1][0], self.hole_cards[1][1]
            r1 = self.rank_map[rank1]
            r2 = self.rank_map[rank2]
            is_pair = r1 == r2
            is_suited = suit1 == suit2
            dist = abs(r1 - r2)
            min_r = min(r1, r2)
            max_r = max(r1, r2)
            preflop_strength = 0.0
            if is_pair:
                preflop_strength = 0.8 + (min_r / 14.0) * 0.2
            elif is_suited and dist <= 4:
                preflop_strength = 0.6 + (max_r / 14.0) * 0.2
            elif max_r >= 10:
                preflop_strength = 0.4 + (max_r / 14.0) * 0.4
            else:
                preflop_strength = 0.2 if dist <= 3 else 0.0

            if preflop_strength > 0.7:
                desired_raise = self.big_blind * 3
                amount = max(min_raise_amount, desired_raise)
                amount = min(amount, max_raise_amount)
                if amount >= min_raise_amount and amount <= max_raise_amount:
                    return PokerAction.RAISE, amount
                elif call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif preflop_strength > 0.3 and call_amount <= self.big_blind * 2:
                if call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            all_cards = self.hole_cards + round_state.community_cards
            if len(all_cards) < 5:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

            best_rank = 0
            best_tiebreak = []
            for combo in combinations(all_cards, 5):
                rank_type, tiebreak = self.evaluate_5card(list(combo))
                if rank_type > best_rank or (rank_type == best_rank and tiebreak > best_tiebreak):
                    best_rank = rank_type
                    best_tiebreak = tiebreak

            if best_rank >= 5:  # straight or better
                if can_check:
                    desired = pot if pot > 0 else self.big_blind * 2
                    amount = max(min_raise_amount, desired)
                    amount = min(amount, max_raise_amount)
                    if amount >= min_raise_amount and amount <= max_raise_amount:
                        return PokerAction.RAISE, amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    if call_amount < (pot + 1) / 2 and call_amount <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif best_rank >= 2:  # pair or better
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if call_amount < (pot + 1) / 4 and call_amount <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def evaluate_5card(self, cards: List[str]) -> Tuple[int, List[int]]:
        hand = []
        for card in cards:
            r = self.rank_map[card[0]]
            s = self.suit_map[card[1]]
            hand.append((r, s))
        hand.sort(key=lambda x: -x[0])
        ranks = [h[0] for h in hand]
        suits = [h[1] for h in hand]
        is_flush = all(s == suits[0] for s in suits)
        is_straight = all(ranks[i] - ranks[i + 1] == 1 for i in range(4))
        straight_ranks = ranks[:]
        if not is_straight and ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            straight_ranks = [5, 4, 3, 2, 1]
        if is_flush and is_straight:
            if ranks[0] == 14 and ranks[1] == 13:
                return 10, ranks
            return 9, straight_ranks
        rank_count = Counter(ranks)
        counts = sorted(rank_count.values(), reverse=True)
        if counts[0] == 4:
            quad_rank = [r for r, c in rank_count.items() if c == 4][0]
            kicker = [r for r, c in rank_count.items() if c == 1][0]
            return 8, [quad_rank, kicker]
        if counts == [3, 2]:
            trip = [r for r, c in rank_count.items() if c == 3][0]
            pair = [r for r, c in rank_count.items() if c == 2][0]
            return 7, [trip, pair]
        if is_flush:
            return 6, ranks
        if is_straight:
            return 5, straight_ranks
        if counts[0] == 3:
            trip = [r for r, c in rank_count.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 4, [trip] + kickers
        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_count.items() if c == 1][0]
            return 3, pairs + [kicker]
        if counts[0] == 2:
            pair = [r for r, c in rank_count.items() if c == 2][0]
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 2, [pair] + kickers
        return 1, ranks

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass