from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.blind_amount = 10
        self.game_count = 0
        self.total_games = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.hand_cards = player_hands
        self.blind_amount = blind_amount
        self.game_count = 0
        self.total_games += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        self.game_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current situation
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        # Calculate hand strength based on cards
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        if to_call > 0 and pot > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
        
        # Determine position (acting first or last)
        is_preflop = round_state.round == 'Preflop'
        
        # Strategy based on hand strength and pot odds
        if hand_strength >= 0.8:  # Very strong hand
            # Always raise or all-in with very strong hands
            if remaining_chips <= pot * 2:
                return (PokerAction.ALL_IN, 0)
            elif current_bet == 0:
                # No one has bet, make a strong bet
                raise_amount = min(pot, remaining_chips // 2)
                if raise_amount < round_state.min_raise:
                    raise_amount = round_state.min_raise
                return (PokerAction.RAISE, raise_amount)
            else:
                # Someone has bet, re-raise
                raise_amount = min(pot, remaining_chips // 2)
                if raise_amount < round_state.min_raise:
                    if to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, raise_amount)
                
        elif hand_strength >= 0.6:  # Strong hand
            if current_bet == 0:
                # No one has bet, make a moderate bet
                raise_amount = max(round_state.min_raise, pot // 2)
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif to_call <= pot // 2 and to_call <= remaining_chips:
                # Good pot odds, call
                return (PokerAction.CALL, 0)
            elif to_call <= remaining_chips // 3:
                # Small bet relative to stack, call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.4:  # Medium hand
            if current_bet == 0:
                # Check if no one has bet
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3 and to_call <= remaining_chips:
                # Good pot odds, call
                return (PokerAction.CALL, 0)
            elif is_preflop and to_call <= self.blind_amount * 2:
                # Small preflop bet, call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        else:  # Weak hand
            if current_bet == 0:
                # Try to bluff occasionally
                if pot > 0 and len(round_state.community_cards) >= 3:
                    # Bluff 20% of the time on later streets
                    if self._should_bluff():
                        raise_amount = max(round_state.min_raise, pot // 3)
                        if raise_amount <= remaining_chips // 4:
                            return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif is_preflop and to_call <= self.blind_amount:
                # Call small blind in preflop
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on cards."""
        if not self.hand_cards:
            return 0.3
            
        # Parse hand cards
        card1, card2 = self.hand_cards[0], self.hand_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Preflop hand strength
        strength = 0.3  # Base strength
        
        # Pocket pairs
        if rank1 == rank2:
            pair_strength = rank1 / 14.0
            strength = 0.5 + pair_strength * 0.4
            
        # High cards
        high_card = max(rank1, rank2)
        low_card = min(rank1, rank2)
        
        if high_card >= 12:  # Ace or King
            strength += 0.2
        elif high_card >= 10:  # Queen or Jack
            strength += 0.1
            
        if low_card >= 10:  # Both high cards
            strength += 0.15
            
        # Suited cards
        if suit1 == suit2:
            strength += 0.1
            
        # Connected cards (for straights)
        if abs(rank1 - rank2) == 1:
            strength += 0.05
        elif abs(rank1 - rank2) == 2:
            strength += 0.03
            
        # Adjust based on community cards
        if len(round_state.community_cards) > 0:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
            
        return min(1.0, max(0.0, strength))
    
    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust strength based on community cards."""
        comm_ranks = [self._parse_card(card)[0] for card in community_cards]
        hand_ranks = [self._parse_card(card)[0] for card in self.hand_cards]
        all_ranks = hand_ranks + comm_ranks
        
        # Check for pairs, trips, etc.
        rank_counts = {}
        for rank in all_ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        max_count = max(rank_counts.values())
        
        if max_count >= 4:  # Four of a kind
            return 0.95
        elif max_count == 3:  # Three of a kind
            # Check if we have the three of a kind
            for rank in hand_ranks:
                if rank_counts.get(rank, 0) >= 3:
                    return 0.85
            return base_strength * 0.7  # Board has trips
        elif max_count == 2:  # At least a pair
            # Check if we have the pair
            for rank in hand_ranks:
                if rank_counts.get(rank, 0) == 2:
                    pair_rank = rank / 14.0
                    return 0.5 + pair_rank * 0.3
            return base_strength * 0.8  # Board pair
            
        # Check for flush potential
        all_suits = [self._parse_card(card)[1] for card in self.hand_cards + community_cards]
        suit_counts = {}
        for suit in all_suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        if max(suit_counts.values()) >= 5:
            return 0.9  # Flush
        elif max(suit_counts.values()) >= 4:
            base_strength += 0.15  # Flush draw
            
        return min(1.0, base_strength)
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit."""
        if len(card) != 2:
            return (2, 's')  # Default to 2 of spades
            
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_char, 2)
        return (rank, suit)
    
    def _should_bluff(self) -> bool:
        """Decide whether to bluff based on game state."""
        # Simple bluff frequency based on game count
        return (self.game_count % 5) == 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass