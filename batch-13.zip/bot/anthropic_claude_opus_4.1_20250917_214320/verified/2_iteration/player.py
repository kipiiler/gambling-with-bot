from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_stats = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id:
                if player not in self.opponent_stats:
                    self.opponent_stats[player] = {
                        'vpip': 0,  # Voluntarily put in pot
                        'pfr': 0,   # Pre-flop raise
                        'aggression': 0,
                        'hands_played': 0
                    }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)  # Avoid division by zero
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Position awareness
        is_in_position = self._is_in_position(round_state)
        
        # Determine action based on round
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, hand_strength, is_in_position)
        else:
            return self._get_postflop_action(round_state, remaining_chips, hand_strength, pot_odds, is_in_position)
    
    def _is_in_position(self, round_state: RoundStateClient) -> bool:
        """Check if we're in position (acting last or late)"""
        active_players = len([p for p, action in round_state.player_actions.items() 
                            if action != 'Fold'])
        return active_players <= 2  # Simplified position check
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        if round_state.round == 'Preflop':
            # Premium hands
            if (rank1 >= 12 and rank2 >= 12):  # AA, KK, QQ, AK
                return 0.95
            elif (rank1 >= 11 and rank2 >= 11):  # JJ, AQ
                return 0.85
            elif (rank1 >= 10 and rank2 >= 10):  # TT, AJ, KQ
                return 0.75
            elif (rank1 >= 9 and rank2 >= 9):  # 99, AT, KJ
                return 0.65
            elif suited and abs(rank1 - rank2) <= 1:  # Suited connectors
                return 0.55
            elif rank1 >= 8 or rank2 >= 8:  # Medium pairs and high cards
                return 0.45
            else:
                return 0.25
        else:
            # Post-flop evaluation
            community = round_state.community_cards
            return self._evaluate_postflop_strength(community)
    
    def _evaluate_postflop_strength(self, community: List[str]) -> float:
        """Evaluate post-flop hand strength"""
        if not community:
            return 0.5
            
        all_cards = self.hole_cards + community
        
        # Check for made hands
        ranks = [self._card_rank(card) for card in all_cards]
        suits = [card[-1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for pairs, trips, etc.
        max_count = max(rank_counts.values()) if rank_counts else 0
        
        # Flush draw
        max_suit = max(suit_counts.values()) if suit_counts else 0
        
        if max_count >= 4:  # Four of a kind
            return 0.99
        elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Full house
            return 0.95
        elif max_suit >= 5:  # Flush
            return 0.90
        elif self._has_straight(ranks):  # Straight
            return 0.85
        elif max_count == 3:  # Three of a kind
            return 0.75
        elif len([c for c in rank_counts.values() if c == 2]) >= 2:  # Two pair
            return 0.65
        elif max_count == 2:  # One pair
            # Check if we have the pair
            hole_ranks = [self._card_rank(card) for card in self.hole_cards]
            for hr in hole_ranks:
                if rank_counts.get(hr, 0) >= 2:
                    return 0.55 + (hr / 14) * 0.1  # Higher pairs are better
            return 0.40  # Board pair
        elif max_suit == 4:  # Flush draw
            return 0.35
        else:
            # High card
            hole_ranks = [self._card_rank(card) for card in self.hole_cards]
            return 0.20 + (max(hole_ranks) / 14) * 0.15
    
    def _has_straight(self, ranks: List[int]) -> bool:
        """Check if there's a straight in the ranks"""
        if len(ranks) < 5:
            return False
        unique_ranks = sorted(set(ranks))
        
        # Check for ace-low straight
        if 14 in unique_ranks:
            unique_ranks.append(1)
        
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        return False
    
    def _card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        if not card or len(card) < 1:
            return 2
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
    
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, 
                           hand_strength: float, is_in_position: bool) -> Tuple[PokerAction, int]:
        """Get pre-flop action"""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot = round_state.pot
        
        # Adjust strength based on position
        if is_in_position:
            hand_strength *= 1.1
        
        # Strong hands - raise or re-raise
        if hand_strength >= 0.85:
            if to_call == 0:
                raise_amount = min(pot * 3, remaining_chips // 2)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.3:
                raise_amount = min(to_call * 3, remaining_chips // 2)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CALL, 0)
        
        # Good hands - raise if unopened, call if raised
        elif hand_strength >= 0.65:
            if to_call == 0:
                raise_amount = min(pot * 2.5, remaining_chips // 3)
                return (PokerAction.RAISE, raise_amount)
            elif to_call <= self.blind_amount * 3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Playable hands - limp or call small raises
        elif hand_strength >= 0.45:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - fold unless free
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int,
                            hand_strength: float, pot_odds: float, is_in_position: bool) -> Tuple[PokerAction, int]:
        """Get post-flop action"""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot = round_state.pot
        
        # Adjust for position
        if is_in_position:
            hand_strength *= 1.05
        
        # Very strong hands - bet/raise aggressively
        if hand_strength >= 0.85:
            if to_call == 0:
                bet_amount = min(int(pot * 0.75), remaining_chips // 2)
                return (PokerAction.RAISE, bet_amount)
            else:
                if to_call < remaining_chips * 0.5:
                    raise_amount = min(to_call * 2, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
        
        # Good hands - bet for value or call
        elif hand_strength >= 0.65:
            if to_call == 0:
                bet_amount = min(int(pot * 0.6), remaining_chips // 3)
                return (PokerAction.RAISE, bet_amount)
            elif pot_odds < hand_strength:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Drawing hands or marginal made hands
        elif hand_strength >= 0.35:
            if to_call == 0:
                # Sometimes bluff in position
                if is_in_position and pot < remaining_chips * 0.2:
                    bet_amount = min(int(pot * 0.4), remaining_chips // 4)
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength * 0.8:  # Call with good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        # Update opponent stats if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hole_cards = []