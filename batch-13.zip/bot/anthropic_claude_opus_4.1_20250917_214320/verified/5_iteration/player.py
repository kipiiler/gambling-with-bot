from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_strength = 0
        self.position = 0
        self.num_players = 0
        self.aggressive_threshold = 0.65
        self.tight_threshold = 0.35
        self.opponent_stats = {}
        self.hand_count = 0
        self.starting_chips = 10000
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.hand_count = 0
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'vpip': 0,  # Voluntarily Put In Pot
                    'pfr': 0,   # Pre-Flop Raise
                    'aggression': 0,
                    'hands_played': 0
                }
        
        # Calculate position
        if self.id == small_blind_player_id:
            self.position = 0
        elif self.id == big_blind_player_id:
            self.position = 1
        else:
            self.position = 2
            
        # Store hole cards
        self.hole_cards = player_hands
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
        # Update opponent stats based on actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[int(player_id)]
                stats['hands_played'] += 1
                
                if action in ['Call', 'Raise', 'All_in']:
                    stats['vpip'] += 1
                    stats['aggression'] += 2 if action in ['Raise', 'All_in'] else 1
                if action in ['Raise', 'All_in'] and round_state.round == 'Preflop':
                    stats['pfr'] += 1
    
    def calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Enhanced hand strength calculation with better evaluation"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        card1, card2 = hole_cards[0], hole_cards[1]
        rank1, suit1 = card1[0], card1[1] if len(card1) > 1 else ''
        rank2, suit2 = card2[0], card2[1] if len(card2) > 1 else ''
        
        # Card rank values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
            
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Base hand strength for hole cards
        is_pair = (rank1 == rank2)
        is_suited = (suit1 == suit2)
        
        # Premium hands
        if is_pair:
            if val1 >= 10:  # TT+
                base_strength = 0.85 + (val1 - 10) * 0.03
            else:
                base_strength = 0.55 + val1 * 0.03
        else:
            high_card = max(val1, val2)
            low_card = min(val1, val2)
            gap = high_card - low_card
            
            # High cards
            if high_card == 14:  # Ace high
                if low_card >= 10:  # AK, AQ, AJ, AT
                    base_strength = 0.75 + (low_card - 10) * 0.02
                else:
                    base_strength = 0.55 + low_card * 0.01
            elif high_card == 13:  # King high
                if low_card >= 10:
                    base_strength = 0.65 + (low_card - 10) * 0.02
                else:
                    base_strength = 0.45 + low_card * 0.01
            elif high_card >= 10:  # Queen, Jack, Ten high
                base_strength = 0.40 + high_card * 0.02 + low_card * 0.01
            else:
                base_strength = 0.25 + (high_card + low_card) * 0.01
            
            # Suited bonus
            if is_suited:
                base_strength += 0.08
                
            # Connector bonus
            if gap == 1:
                base_strength += 0.06
            elif gap == 2:
                base_strength += 0.03
                
        # Adjust for community cards
        if community_cards:
            made_hand_strength = self.evaluate_made_hand(hole_cards, community_cards)
            draw_strength = self.evaluate_draws(hole_cards, community_cards)
            
            # Weight made hands more heavily than draws
            strength = made_hand_strength * 0.8 + draw_strength * 0.2
            
            # Blend with preflop strength early in the hand
            cards_shown = len(community_cards)
            if cards_shown == 3:  # Flop
                return strength * 0.7 + base_strength * 0.3
            elif cards_shown == 4:  # Turn
                return strength * 0.85 + base_strength * 0.15
            else:  # River
                return strength
        
        return min(1.0, base_strength)
    
    def evaluate_made_hand(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate the strength of made hands"""
        all_cards = hole_cards + community_cards
        
        ranks = [card[0] for card in all_cards]
        suits = [card[1] if len(card) > 1 else '' for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        suit_counts = {}
        for suit in suits:
            if suit:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for pairs, trips, quads
        max_count = max(rank_counts.values()) if rank_counts else 0
        
        # Check which of our hole cards are involved
        hole_ranks = [card[0] for card in hole_cards]
        our_pairs = sum(1 for rank in hole_ranks if rank_counts.get(rank, 0) >= 2)
        
        if max_count == 4:
            return 0.95  # Four of a kind
        elif max_count == 3:
            if len([c for c in rank_counts.values() if c >= 2]) >= 2:
                return 0.90  # Full house
            else:
                return 0.75 if our_pairs > 0 else 0.65  # Three of a kind
        elif max_count == 2:
            pairs = [rank for rank, count in rank_counts.items() if count == 2]
            if len(pairs) >= 2:
                # Two pair - better if we have both pairs
                if all(rank in hole_ranks for rank in pairs[:2]):
                    return 0.70
                elif any(rank in hole_ranks for rank in pairs):
                    return 0.60
                else:
                    return 0.45
            else:
                # One pair - better if it's our pair
                pair_rank = pairs[0] if pairs else None
                if pair_rank and pair_rank in hole_ranks:
                    rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
                    for i in range(2, 10):
                        rank_values[str(i)] = i
                    pair_value = rank_values.get(pair_rank, 2)
                    return 0.40 + pair_value * 0.02
                else:
                    return 0.30
        
        # High card only
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
        
        hole_values = sorted([rank_values.get(rank, 2) for rank in hole_ranks], reverse=True)
        return 0.15 + hole_values[0] * 0.01
    
    def evaluate_draws(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate drawing hands potential"""
        all_cards = hole_cards + community_cards
        suits = [card[1] if len(card) > 1 else '' for card in all_cards]
        
        suit_counts = {}
        for suit in suits:
            if suit:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Flush draws
        max_suit = max(suit_counts.values()) if suit_counts else 0
        if max_suit == 4:
            # Check if we have suited cards
            hole_suits = [card[1] if len(card) > 1 else '' for card in hole_cards]
            for suit in hole_suits:
                if suit and suit_counts.get(suit, 0) == 4:
                    return 0.55  # Flush draw with our cards
        
        # Straight draws
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
            
        values = sorted([rank_values.get(card[0], 2) for card in all_cards])
        unique_values = sorted(set(values))
        
        # Check for straight possibilities
        for i in range(len(unique_values) - 3):
            if unique_values[i+3] - unique_values[i] <= 4:
                # Potential straight
                hole_values = [rank_values.get(card[0], 2) for card in hole_cards]
                if any(v in range(unique_values[i], unique_values[i+3]+1) for v in hole_values):
                    return 0.45  # Open-ended straight draw
        
        return 0.0
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds for the current situation"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def get_opponent_tendency(self, player_id: int) -> str:
        """Classify opponent playing style"""
        if player_id not in self.opponent_stats:
            return "unknown"
            
        stats = self.opponent_stats[player_id]
        if stats['hands_played'] < 3:
            return "unknown"
            
        vpip_rate = stats['vpip'] / max(stats['hands_played'], 1)
        aggression_rate = stats['aggression'] / max(stats['hands_played'], 1)
        
        if vpip_rate > 0.6 and aggression_rate > 1.5:
            return "loose-aggressive"
        elif vpip_rate > 0.6:
            return "loose-passive"
        elif aggression_rate > 1.5:
            return "tight-aggressive"
        else:
            return "tight-passive"
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Enhanced decision making with opponent modeling and pot odds"""
        community_cards = round_state.community_cards
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        
        # Calculate hand strength
        self.hand_strength = self.calculate_hand_strength(self.hole_cards, community_cards)
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Adjust strategy based on stack size
        stack_bb_ratio = remaining_chips / max(current_bet, 10)
        is_short_stack = stack_bb_ratio < 15
        
        # Position-based adjustments
        position_multiplier = 1.0 + (self.position * 0.1)
        
        # Adjust thresholds based on opponents
        active_opponents = [p for p in round_state.current_player if p != self.id]
        tight_opponents = sum(1 for p in active_opponents 
                             if self.get_opponent_tendency(p) in ["tight-passive", "tight-aggressive"])
        
        if tight_opponents > len(active_opponents) / 2:
            # Be more aggressive against tight players
            effective_strength = self.hand_strength * 1.15
        else:
            effective_strength = self.hand_strength
        
        # Apply position multiplier
        effective_strength *= position_multiplier
        
        # Decision logic
        if call_amount == 0:  # Can check
            if effective_strength > 0.7:
                # Strong hand - bet for value
                bet_size = int(pot * 0.75)
                if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
            elif effective_strength > 0.5:
                # Medium hand - bet smaller or check
                if len(active_opponents) == 1:  # Heads up
                    bet_size = int(pot * 0.4)
                    if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:  # Facing a bet
            # Calculate if we have good pot odds
            equity_needed = pot_odds
            
            if effective_strength > 0.85:
                # Very strong hand - raise for value
                if is_short_stack:
                    return (PokerAction.ALL_IN, 0)
                raise_size = min(int(current_bet * 3), remaining_chips)
                if raise_size >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_size)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif effective_strength > 0.65:
                # Good hand - call or raise depending on pot odds
                if pot_odds < 0.25 and effective_strength > 0.75:
                    # Good pot odds and strong hand - raise
                    raise_size = min(int(current_bet * 2.5), remaining_chips)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif effective_strength > equity_needed:
                # Positive expected value call
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif effective_strength > 0.35 and pot_odds < 0.2:
                # Decent hand with very good pot odds
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            
            # Bluff occasionally in position
            if self.position >= 2 and len(active_opponents) <= 2:
                if self.hand_count % 7 == 0 and effective_strength > 0.25:
                    # Occasional bluff
                    raise_size = min(int(pot * 0.6), remaining_chips)
                    if raise_size >= round_state.min_raise and raise_size <= remaining_chips * 0.3:
                        return (PokerAction.RAISE, raise_size)
            
            return (PokerAction.FOLD, 0)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Track results and update opponent models"""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Analyze game results"""
        pass