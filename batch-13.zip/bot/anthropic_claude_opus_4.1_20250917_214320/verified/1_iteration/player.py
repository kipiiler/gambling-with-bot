from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.hand_strength_cache = {}
        self.position_aggression_factor = 1.0
        self.opponents_fold_count = {}
        self.opponents_raise_count = {}
        self.current_hand_investment = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.current_hand_investment = 0
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                if player_id not in self.opponents_fold_count:
                    self.opponents_fold_count[player_id] = 0
                    self.opponents_raise_count[player_id] = 0
        
        # Position relative to big blind
        if self.id == big_blind_player_id:
            self.position_aggression_factor = 0.8
        elif self.id == small_blind_player_id:
            self.position_aggression_factor = 0.9
        else:
            self.position_aggression_factor = 1.1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.current_hand_investment = round_state.player_bets.get(str(self.id), 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate pot odds and hand strength
        pot_size = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot_size + to_call + 0.001)
        
        # Estimate hand strength
        hand_strength = self.estimate_hand_strength(round_state)
        
        # Track opponent actions
        self.update_opponent_stats(round_state)
        
        # Calculate aggression based on stack size
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        aggression_modifier = 1.0
        if stack_ratio < 0.3:  # Short stack - more aggressive
            aggression_modifier = 1.5
        elif stack_ratio > 2.0:  # Big stack - can be more aggressive
            aggression_modifier = 1.2
            
        # Adjust for position
        effective_strength = hand_strength * self.position_aggression_factor * aggression_modifier
        
        # Decision making
        if to_call == 0:  # Can check
            if effective_strength > 0.6:
                # Strong hand - raise
                raise_amount = self.calculate_raise_amount(round_state, remaining_chips, effective_strength)
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CHECK, 0)
        
        # Need to call or raise
        if effective_strength < pot_odds * 0.8:
            # Weak hand relative to pot odds
            return (PokerAction.FOLD, 0)
        elif effective_strength > pot_odds * 1.5:
            # Strong hand - consider raising
            if remaining_chips <= to_call:
                return (PokerAction.ALL_IN, 0)
            
            raise_amount = self.calculate_raise_amount(round_state, remaining_chips, effective_strength)
            if raise_amount > 0 and to_call + raise_amount <= remaining_chips:
                return (PokerAction.RAISE, raise_amount)
            elif to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
        else:
            # Medium strength - call if we can afford it
            if to_call >= remaining_chips:
                if effective_strength > 0.5:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            return (PokerAction.CALL, 0)

    def calculate_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, strength: float) -> int:
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # Calculate raise size based on strength and pot
        if strength > 0.8:
            # Very strong - bet 75% to 100% of pot
            raise_size = int(pot_size * (0.75 + 0.25 * strength))
        elif strength > 0.6:
            # Strong - bet 50% to 75% of pot
            raise_size = int(pot_size * (0.5 + 0.25 * strength))
        else:
            # Medium - bet 33% to 50% of pot
            raise_size = int(pot_size * (0.33 + 0.17 * strength))
        
        # Ensure minimum raise
        min_raise_total = current_bet * 2
        if min_raise_total <= my_current_bet:
            min_raise_total = current_bet + max(1, current_bet - my_current_bet)
        
        total_bet = max(min_raise_total, my_current_bet + raise_size)
        actual_raise = total_bet - my_current_bet
        
        # Check if we can afford it
        if actual_raise > remaining_chips:
            return 0
        
        # Ensure the raise meets minimum requirements
        if total_bet < round_state.min_raise:
            if round_state.min_raise <= my_current_bet + remaining_chips:
                return round_state.min_raise - my_current_bet
            return 0
            
        return min(actual_raise, remaining_chips)

    def estimate_hand_strength(self, round_state: RoundStateClient) -> float:
        # Simple hand strength estimation
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.5
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self.card_rank(card1), self.card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Preflop strength
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            strength = 0.5 + (rank1 / 14) * 0.4
        else:
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            strength = 0.2 + (high_rank / 14) * 0.3 + (low_rank / 14) * 0.1
            
            # Suited bonus
            if suited:
                strength += 0.05
                
            # Connectivity bonus
            if abs(rank1 - rank2) == 1:
                strength += 0.03
            elif abs(rank1 - rank2) == 2:
                strength += 0.02
        
        # Adjust based on community cards
        if round_state.community_cards:
            community_ranks = [self.card_rank(card) for card in round_state.community_cards]
            
            # Check for pairs with community cards
            for comm_rank in community_ranks:
                if comm_rank == rank1 or comm_rank == rank2:
                    strength += 0.15
                    
            # Check for flush potential
            suits = {}
            all_cards = self.hole_cards + round_state.community_cards
            for card in all_cards:
                suit = card[-1]
                suits[suit] = suits.get(suit, 0) + 1
            
            max_suit_count = max(suits.values())
            if max_suit_count >= 4:
                strength += 0.1 * (max_suit_count - 3)
                
            # Reduce strength if many community cards and we don't have strong connection
            if len(round_state.community_cards) >= 3:
                if strength < 0.6:
                    strength *= 0.9
                    
        return min(1.0, max(0.0, strength))

    def card_rank(self, card: str) -> int:
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            return int(rank_char)

    def update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                player_id_int = int(player_id)
                if action == 'Fold':
                    self.opponents_fold_count[player_id_int] = self.opponents_fold_count.get(player_id_int, 0) + 1
                elif action in ['Raise', 'All-in']:
                    self.opponents_raise_count[player_id_int] = self.opponents_raise_count.get(player_id_int, 0) + 1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hand investment tracking
        self.current_hand_investment = 0
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_strength_cache = {}
        self.current_hand_investment = 0