from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.game_count = 0
        self.total_games = 0
        self.current_round = None
        self.last_action = None
        self.opponent_aggression = {}
        self.my_total_bet = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.game_count += 1
        self.my_total_bet = 0
        
        # Track if we're blind
        if self.id == big_blind_player_id:
            self.my_total_bet = blind_amount
        elif self.id == small_blind_player_id:
            self.my_total_bet = blind_amount // 2
            
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[int(player_id)]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[int(player_id)]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[int(player_id)]['folds'] += 1
        
        # Calculate pot odds
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, round_state.current_bet - my_current_bet)
        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 0.001) if amount_to_call > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state.community_cards)
        
        # Get valid raise amount if we want to raise
        min_raise_total = round_state.current_bet * 2  # Minimum is double the current bet
        if min_raise_total <= my_current_bet:
            min_raise_total = my_current_bet + round_state.min_raise
        raise_amount = max(round_state.min_raise, min_raise_total - my_current_bet)
        
        # Ensure raise amount is valid
        if raise_amount > remaining_chips:
            raise_amount = remaining_chips
            
        # Decision logic based on hand strength and pot odds
        if round_state.round == 'Preflop':
            if hand_strength >= 0.8:
                # Premium hands - raise aggressively
                if remaining_chips > raise_amount and raise_amount > 0:
                    if raise_amount + my_current_bet > round_state.current_bet:
                        return (PokerAction.RAISE, min(raise_amount * 3, remaining_chips))
                return (PokerAction.ALL_IN, 0)
            elif hand_strength >= 0.6:
                # Good hands - raise or call
                if amount_to_call == 0:
                    if remaining_chips > raise_amount and raise_amount > 0:
                        if raise_amount + my_current_bet > round_state.current_bet:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength >= 0.4:
                # Decent hands - call small bets
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hands
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Post-flop play
            if hand_strength >= 0.7:
                # Strong hands - bet/raise
                if amount_to_call == 0:
                    if remaining_chips > raise_amount and raise_amount > 0:
                        if raise_amount + my_current_bet > round_state.current_bet:
                            return (PokerAction.RAISE, min(raise_amount * 2, remaining_chips))
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.4:
                    if remaining_chips > raise_amount * 2 and raise_amount > 0:
                        if raise_amount + my_current_bet > round_state.current_bet:
                            return (PokerAction.RAISE, min(raise_amount * 2, remaining_chips))
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength >= 0.5:
                # Medium hands - call or check
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hands - check or fold
                if amount_to_call == 0:
                    # Bluff occasionally
                    if len(round_state.community_cards) == 5 and pot_odds == 0:
                        if self.game_count % 5 == 0:  # Bluff 20% of the time
                            if remaining_chips > raise_amount and raise_amount > 0:
                                if raise_amount + my_current_bet > round_state.current_bet:
                                    return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0 to 1"""
        if not self.hand or len(self.hand) < 2:
            return 0.5
            
        card1_rank = self._get_card_rank(self.hand[0])
        card2_rank = self._get_card_rank(self.hand[1])
        card1_suit = self.hand[0][-1] if self.hand[0] else ''
        card2_suit = self.hand[1][-1] if self.hand[1] else ''
        
        is_suited = (card1_suit == card2_suit)
        is_pair = (card1_rank == card2_rank)
        high_card = max(card1_rank, card2_rank)
        low_card = min(card1_rank, card2_rank)
        gap = high_card - low_card
        
        # Pre-flop hand strength
        strength = 0.0
        
        # Pocket pairs
        if is_pair:
            strength = 0.5 + (card1_rank / 30.0)
            if card1_rank >= 12:  # QQ+
                strength = 0.85
            elif card1_rank >= 10:  # TT-JJ
                strength = 0.75
            elif card1_rank >= 8:  # 88-99
                strength = 0.65
        else:
            # High cards
            if high_card == 14:  # Ace
                if low_card >= 12:  # AQ+
                    strength = 0.8 if is_suited else 0.75
                elif low_card >= 10:  # AT-AJ
                    strength = 0.65 if is_suited else 0.6
                else:
                    strength = 0.5 if is_suited else 0.45
            elif high_card == 13:  # King
                if low_card >= 11:  # KJ+
                    strength = 0.65 if is_suited else 0.6
                elif low_card >= 10:
                    strength = 0.55 if is_suited else 0.5
                else:
                    strength = 0.4
            elif high_card >= 11:  # Face cards
                if gap <= 2:
                    strength = 0.55 if is_suited else 0.5
                else:
                    strength = 0.4
            else:
                # Connectors and suited cards
                if gap == 1:  # Connected
                    strength = 0.45 if is_suited else 0.4
                elif gap == 2:
                    strength = 0.4 if is_suited else 0.35
                else:
                    strength = 0.3 if is_suited else 0.25
        
        # Adjust based on community cards
        if community_cards:
            community_ranks = [self._get_card_rank(card) for card in community_cards]
            
            # Check for made hands
            all_ranks = [card1_rank, card2_rank] + community_ranks
            rank_counts = {}
            for rank in all_ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_count = max(rank_counts.values())
            if max_count >= 4:  # Four of a kind
                strength = 0.95
            elif max_count == 3:  # Three of a kind
                if card1_rank in rank_counts and rank_counts[card1_rank] >= 2:
                    strength = max(strength, 0.8)
                elif card2_rank in rank_counts and rank_counts[card2_rank] >= 2:
                    strength = max(strength, 0.8)
                else:
                    strength = max(strength, 0.7)
            elif max_count == 2:  # Pair
                if card1_rank in rank_counts and rank_counts[card1_rank] == 2:
                    strength = max(strength, 0.6 + card1_rank / 40.0)
                elif card2_rank in rank_counts and rank_counts[card2_rank] == 2:
                    strength = max(strength, 0.6 + card2_rank / 40.0)
                else:
                    strength = max(strength, 0.45)
        
        return min(1.0, strength)
    
    def _get_card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        if not card or len(card) < 1:
            return 0
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.total_games += 1