from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import collections

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hand = []
        self.preflop_score = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        if self.id in all_players:
            idx = all_players.index(self.id)
            hand_str = player_hands[idx]
            if len(hand_str) >= 4:
                self.my_hand = [hand_str[i:i+2] for i in range(0, 4, 2)]
            else:
                self.my_hand = []
        
        if self.my_hand:
            self.preflop_score = self.evaluate_preflop(self.my_hand)
        else:
            self.preflop_score = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            
            if round_state.round == 'Preflop':
                return self.handle_preflop(round_state, amount_to_call, remaining_chips)
            else:
                return self.handle_post_flop(round_state, amount_to_call, remaining_chips)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def card_rank(self, card_str: str) -> int:
        if not card_str:
            return 0
        rank_char = card_str[0]
        if rank_char.isdigit():
            return int(rank_char)
        else:
            return {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(rank_char, 0)

    def evaluate_preflop(self, cards: List[str]) -> float:
        if len(cards) < 2:
            return 0
        r1 = self.card_rank(cards[0])
        r2 = self.card_rank(cards[1])
        suited = cards[0][1] == cards[1][1] if len(cards[0]) > 1 and len(cards[1]) > 1 else False
        gap = abs(r1 - r2)
        
        if r1 == r2:
            return 200 + r1 * 2
        elif suited:
            if gap == 1:
                return 180 + max(r1, r2)
            elif gap == 2:
                return 170 + max(r1, r2)
            elif gap == 3:
                return 160 + max(r1, r2)
            else:
                return 150 + max(r1, r2)
        else:
            if gap == 1:
                return 160 + max(r1, r2)
            elif gap == 2:
                return 150 + max(r1, r2)
            elif gap == 3:
                return 140 + max(r1, r2)
            else:
                return 130 + max(r1, r2)

    def handle_preflop(self, round_state: RoundStateClient, amount_to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if amount_to_call == 0:
            if self.preflop_score >= 200:
                amount = round_state.min_raise
                if amount > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, amount)
            else:
                return (PokerAction.CHECK, 0)
        else:
            if self.preflop_score >= 200:
                amount = amount_to_call + round_state.min_raise
                if amount > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, amount)
            elif self.preflop_score >= 170:
                if amount_to_call > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def has_made_hand(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        all_cards = hole_cards + community_cards
        ranks = [self.card_rank(card) for card in all_cards]
        counter = collections.Counter(ranks)
        for count in counter.values():
            if count >= 2:
                return True
        return False

    def handle_post_flop(self, round_state: RoundStateClient, amount_to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.has_made_hand(self.my_hand, round_state.community_cards):
            if amount_to_call == 0:
                amount = round_state.min_raise
                if amount > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, amount)
            else:
                if amount_to_call > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
        else:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)