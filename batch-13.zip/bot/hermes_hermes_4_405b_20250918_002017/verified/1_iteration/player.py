import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.preflop_score = 0
        self.hand_score = 0
        self.blind_amount = 0
        self.PREFLOP_RANKS = {
            (14,14): 100,
            (13,13): 95,
            (12,12): 90,
            (11,11): 85,
            (10,10): 80,
            (9,9): 75,
            (8,8): 70,
            (7,7): 65,
            (6,6): 60,
            (5,5): 55,
            (4,4): 50,
            (3,3): 45,
            (2,2): 40,
            (14,13): {'s': 92, 'o': 90},
            (14,12): {'s': 88, 'o': 86},
            (14,11): {'s': 84, 'o': 82},
            (14,10): {'s': 80, 'o': 78},
            (13,12): {'s': 82, 'o': 80},
            (13,11): {'s': 78, 'o': 76},
            (12,11): {'s': 74, 'o': 72},
            (14,9): {'s': 76, 'o': 74},
            (13,10): {'s': 74, 'o': 72},
            (12,10): {'s': 70, 'o': 68},
            (11,10): {'s': 66, 'o': 64},
            (14,8): {'s': 72, 'o': 70},
            (13,9): {'s': 70, 'o': 68},
            (12,9): {'s': 66, 'o': 64},
            (11,9): {'s': 62, 'o': 60},
            (10,9): {'s': 58, 'o': 56},
        }

    def card_rank(self, card_str: str) -> int:
        rank_char = card_str[0]
        if rank_char == 'A': return 14
        elif rank_char == 'K': return 13
        elif rank_char == 'Q': return 12
        elif rank_char == 'J': return 11
        elif rank_char == 'T': return 10
        else: return int(rank_char)

    def card_suit(self, card_str: str) -> str:
        return card_str[1].lower()

    def evaluate_preflop(self, hand_str: str) -> int:
        cards = [hand_str[0:2], hand_str[2:4]]
        r1 = self.card_rank(cards[0])
        r2 = self.card_rank(cards[1])
        suit1 = self.card_suit(cards[0])
        suit2 = self.card_suit(cards[1])
        suited = (suit1 == suit2)
        
        if r1 < r2:
            r1, r2 = r2, r1
        
        if (r1, r2) in self.PREFLOP_RANKS:
            entry = self.PREFLOP_RANKS[(r1, r2)]
            if isinstance(entry, dict):
                if suited:
                    return entry['s']
                else:
                    return entry['o']
            else:
                return entry
        else:
            base = (r1 + r2) * 2.2
            gap = r1 - r2
            gap_bonus = 0
            if gap == 1:
                gap_bonus = 5
            elif gap == 2:
                gap_bonus = 3
            elif gap == 3:
                gap_bonus = 1
            elif gap == 4:
                gap_bonus = 0.5
            if suited:
                base = base * 1.1
            score = base + gap_bonus
            return min(int(score), 100)

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, List[int]]:
        ranks = [self.card_rank(c) for c in cards]
        suits = [self.card_suit(c) for c in cards]
        
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush = any(count >= 5 for count in suit_counts.values())
        
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        straight = False
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    straight = True
                    straight_high = unique_ranks[i]
                    break
            if not straight and set(unique_ranks).issuperset({14, 2, 3, 4, 5}):
                straight = True
                straight_high = 5
        
        if flush and straight:
            if straight_high == 14:
                return (9, [straight_high])
            else:
                return (8, [straight_high])
        
        quads = [r for r, count in rank_counts.items() if count == 4]
        if quads:
            quad_rank = max(quads)
            kickers = [r for r in ranks if r != quad_rank][:1]
            return (7, [quad_rank] + kickers)
        
        triples = [r for r, count in rank_counts.items() if count == 3]
        pairs = [r for r, count in rank_counts.items() if count == 2]
        if triples and pairs:
            triple_rank = max(triples)
            pair_rank = max(pairs)
            return (6, [triple_rank, pair_rank])
        if triples and len(triples) >= 2:
            triples_sorted = sorted(triples, reverse=True)
            return (6, [triples_sorted[0], triples_sorted[1]])
        
        if flush:
            flush_suit = max(suit_counts, key=suit_counts.get)
            flush_ranks = sorted([r for i, r in enumerate(ranks) if suits[i] == flush_suit], reverse=True)[:5]
            return (5, flush_ranks)
        
        if straight:
            return (4, [straight_high])
        
        if triples:
            triple_rank = max(triples)
            kickers = sorted([r for r in ranks if r != triple_rank], reverse=True)[:2]
            return (3, [triple_rank] + kickers)
        
        if len(pairs) >= 2:
            pairs_sorted = sorted(pairs, reverse=True)
            kickers = sorted([r for r in ranks if r not in pairs_sorted[:2]], reverse=True)[:1]
            return (2, pairs_sorted[:2] + kickers)
        
        if pairs:
            pair_rank = max(pairs)
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
            return (1, [pair_rank] + kickers)
        
        return (0, sorted(ranks, reverse=True)[:5])

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        for i, pid in enumerate(all_players):
            if pid == self.id:
                hand_str = player_hands[i]
                self.hole_cards = [hand_str[0:2], hand_str[2:4]]
                break
        self.blind_amount = blind_amount
        hand_str = ''.join(self.hole_cards)
        self.preflop_score = self.evaluate_preflop(hand_str)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        community = round_state.community_cards
        if community:
            all_cards = self.hole_cards + community
            hand_rank, kickers = self.evaluate_hand(all_cards)
            avg_kicker = sum(kickers) / len(kickers) if kickers else 0
            self.hand_score = hand_rank * 10 + (avg_kicker / 14) * 10
            if self.hand_score > 100:
                self.hand_score = 100
        else:
            self.hand_score = self.preflop_score

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(round_state.current_bet - our_bet, 0)
        
        if amount_to_call > 0:
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-5)
        else:
            pot_odds = 0
        
        if round_state.round == 'Preflop':
            equity = 0.1 + 0.9 * (self.preflop_score / 100)
        else:
            equity = 0.1 + 0.9 * (self.hand_score / 100)
        
        if random.random() < 0.1:
            if self.hand_score > 80:
                if amount_to_call == 0:
                    if random.random() < 0.5:
                        return (PokerAction.CHECK, 0)
                    else:
                        bet_amt = random.randint(round_state.min_raise, round_state.max_raise)
                        return (PokerAction.RAISE, bet_amt)
                else:
                    if random.random() < 0.5:
                        return (PokerAction.CALL, 0)
                    else:
                        bet_amt = max(round_state.min_raise, amount_to_call * 2)
                        bet_amt = min(bet_amt, round_state.max_raise)
                        return (PokerAction.RAISE, bet_amt)
            else:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    if random.random() < 0.5:
                        return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CALL, 0)
        
        if amount_to_call == 0:
            if equity > 0.7:
                bet_amt = max(round_state.min_raise, self.blind_amount * 2)
                bet_amt = min(bet_amt, round_state.max_raise)
                return (PokerAction.RAISE, bet_amt)
            else:
                return (PokerAction.CHECK, 0)
        else:
            if amount_to_call > remaining_chips:
                if equity > pot_odds:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if equity > pot_odds * 1.5:
                    bet_amt = max(round_state.min_raise, amount_to_call * 2)
                    if bet_amt > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, bet_amt)
                elif equity > pot_odds:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass