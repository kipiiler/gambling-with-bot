from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = ""
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
            '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        for i, pid in enumerate(all_players):
            if pid == self.id:
                self.hole_cards = player_hands[i]
                break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            
            amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if amount_to_call <= 0:
                return (PokerAction.CALL, 0)
            
            if round_state.round == 'Preflop':
                cards = self.hole_cards.split()
                if len(cards) != 2:
                    return (PokerAction.FOLD, 0)
                
                try:
                    r1 = self.rank_map.get(cards[0][0], 0)
                    r2 = self.rank_map.get(cards[1][0], 0)
                except IndexError:
                    return (PokerAction.FOLD, 0)
                
                suited = cards[0][1] == cards[1][1]
                score = 0
                if r1 == r2:
                    score = 100 + r1
                else:
                    high = max(r1, r2)
                    low = min(r1, r2)
                    score = high * 10 + low
                    if suited:
                        score += 5
                
                if score >= 114:
                    raise_amount = 3 * amount_to_call
                    if raise_amount < round_state.min_raise:
                        raise_amount = round_state.min_raise
                    if raise_amount > round_state.max_raise:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)
                elif score >= 100:
                    if amount_to_call < 0.1 * remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if amount_to_call < 0.05 * remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass