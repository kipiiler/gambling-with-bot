from typing import List, Tuple, Dict, Any
import random
import itertools

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = '23456789TJQKA'
RANK_TO_VAL: Dict[str, int] = {r: i + 2 for i, r in enumerate(RANK_ORDER)}  # 2..14
VAL_TO_RANK: Dict[int, str] = {v: r for r, v in RANK_TO_VAL.items()}
SUITS = ['c', 'd', 'h', 's']


def card_rank(card: str) -> int:
    # card like 'Ah' or 'Td'
    return RANK_TO_VAL[card[0]]


def card_suit(card: str) -> str:
    return card[1]


def sorted_ranks_desc(cards: List[str]) -> List[int]:
    return sorted([card_rank(c) for c in cards], reverse=True)


def evaluate_5(cards5: List[str]) -> Tuple[int, List[int]]:
    # Returns (category, tiebreakers). Higher tuple means stronger.
    # Category: 8=straight flush, 7=4kind, 6=full house, 5=flush, 4=straight, 3=3kind, 2=two pair, 1=pair, 0=high card
    ranks = [card_rank(c) for c in cards5]
    suits = [card_suit(c) for c in cards5]
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts_sorted = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
    is_flush = len(set(suits)) == 1

    # Straight detection with wheel
    unique_ranks = sorted(set(ranks), reverse=True)
    # Handle wheel: A(14),5,4,3,2 -> treat as 5-high straight
    def straight_high(urs: List[int]) -> int:
        if len(urs) < 5:
            return -1
        # Add Ace as 1 at end for wheel check
        urs_with_wheel = urs[:]
        if 14 in urs_with_wheel:
            urs_with_wheel = urs_with_wheel + [1]
        run = 1
        for i in range(1, len(urs_with_wheel)):
            if urs_with_wheel[i-1] - urs_with_wheel[i] == 1:
                run += 1
                if run >= 5:
                    return urs_with_wheel[i-4]  # high card of straight
            elif urs_with_wheel[i-1] == urs_with_wheel[i]:
                continue
            else:
                run = 1
        return -1

    straight_high_rank = straight_high(unique_ranks)

    if is_flush:
        # Check straight flush
        suited_cards = sorted([c for c in cards5], key=lambda c: card_rank(c), reverse=True)
        suited_ranks = sorted(set([card_rank(c) for c in suited_cards]), reverse=True)
        sf_high = straight_high(suited_ranks)
        if sf_high != -1:
            return (8, [sf_high])
        # Flush (tiebreak by ranks)
        return (5, sorted_ranks_desc(cards5))

    # Four of a kind
    if counts_sorted[0][1] == 4:
        four_rank = counts_sorted[0][0]
        kicker = max([r for r in ranks if r != four_rank])
        return (7, [four_rank, kicker])

    # Full house
    if counts_sorted[0][1] == 3 and counts_sorted[1][1] >= 2:
        trip_rank = counts_sorted[0][0]
        pair_rank = counts_sorted[1][0]
        return (6, [trip_rank, pair_rank])

    # Straight
    if straight_high_rank != -1:
        return (4, [straight_high_rank])

    # Three of a kind
    if counts_sorted[0][1] == 3:
        trip_rank = counts_sorted[0][0]
        kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)[:2]
        return (3, [trip_rank] + kickers)

    # Two pair
    if counts_sorted[0][1] == 2 and counts_sorted[1][1] == 2:
        high_pair = max(counts_sorted[0][0], counts_sorted[1][0])
        low_pair = min(counts_sorted[0][0], counts_sorted[1][0])
        kicker = max([r for r in ranks if r != high_pair and r != low_pair])
        return (2, [high_pair, low_pair, kicker])

    # One pair
    if counts_sorted[0][1] == 2:
        pair_rank = counts_sorted[0][0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
        return (1, [pair_rank] + kickers)

    # High card
    return (0, sorted(ranks, reverse=True))


def best_5_from_7(cards7: List[str]) -> Tuple[Tuple[int, List[int]], Tuple[str, ...]]:
    # Evaluates all 5-card combos, returns best rank tuple and the 5-card combo used.
    best_rank = (-1, [])
    best_combo: Tuple[str, ...] = tuple()
    for combo in itertools.combinations(cards7, 5):
        rank = evaluate_5(list(combo))
        if rank > best_rank:
            best_rank = rank
            best_combo = combo
    return best_rank, best_combo


def classify_preflop(hole: List[str]) -> str:
    # Returns one of: 'premium', 'strong', 'medium', 'speculative', 'trash'
    r1 = card_rank(hole[0])
    r2 = card_rank(hole[1])
    s1 = card_suit(hole[0])
    s2 = card_suit(hole[1])
    suited = s1 == s2
    ranks_sorted = sorted([r1, r2], reverse=True)
    high, low = ranks_sorted[0], ranks_sorted[1]
    rank_str = VAL_TO_RANK[high] + VAL_TO_RANK[low]
    # Build string with suited marker
    hand_key = f"{VAL_TO_RANK[high]}{VAL_TO_RANK[low]}{'s' if suited else 'o'}"

    # Premium
    premiums = set([
        'AAo', 'AA', 'KKo', 'KK', 'QQo', 'QQ', 'JJo', 'JJ', 'TTo', 'TT',
        'AKs', 'AQs', 'AJs', 'KQs', 'AKo'
    ])
    if hand_key in premiums or rank_str in ['AA', 'KK', 'QQ', 'JJ', 'TT']:
        return 'premium'

    # Strong
    strongs = set([
        '99o', '99', '88o', '88', '77o', '77',
        'AQo', 'ATs', 'KJs', 'QJs', 'JTs', 'KQo', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s'
    ])
    if hand_key in strongs or rank_str in ['99', '88', '77']:
        return 'strong'

    # Medium
    mediums = set([
        '66o', '66', '55o', '55', '44o', '44', '33o', '33', '22o', '22',
        'AJo', 'KJo', 'QJo', 'ATo', 'KTs', 'QTs', 'J9s', 'T9s', '98s', '87s', '76s'
    ])
    if hand_key in mediums or rank_str in ['66', '55', '44', '33', '22']:
        return 'medium'

    # Speculative (mostly suited connectors and gappers)
    if suited and ((high >= 10 and low >= 6) or (high - low <= 4 and high >= 7)):
        return 'speculative'

    # Trash
    return 'trash'


def has_flush_draw(hole: List[str], board: List[str]) -> bool:
    # 4 cards of same suit among hole+board with at least one hole of that suit
    all_cards = hole + board
    suit_counts: Dict[str, int] = {}
    for c in all_cards:
        s = card_suit(c)
        suit_counts[s] = suit_counts.get(s, 0) + 1
    for s, cnt in suit_counts.items():
        if cnt >= 4 and any(card_suit(h) == s for h in hole):
            return True
    return False


def has_straight_draw(hole: List[str], board: List[str]) -> bool:
    # Approximate: if there is a 4-card window within ranks that includes at least one of our hole cards ranks.
    ranks = sorted(set([card_rank(c) for c in hole + board]), reverse=True)
    if 14 in ranks:
        ranks_with_wheel = ranks + [1]
    else:
        ranks_with_wheel = ranks
    hole_ranks = set(card_rank(c) for c in hole)
    for i in range(len(ranks_with_wheel)):
        window = set()
        window.add(ranks_with_wheel[i])
        for j in range(i + 1, len(ranks_with_wheel)):
            if ranks_with_wheel[i] - ranks_with_wheel[j] <= 4:
                window.add(ranks_with_wheel[j])
            else:
                break
        if len(window) == 4 and (window & hole_ranks):
            return True
    return False


def is_top_pair_or_better_with_hole(hole: List[str], board: List[str]) -> Tuple[bool, bool, bool]:
    # Returns (top_pair, overpair, two_pair_plus) with at least one hole used.
    if not board:
        return (False, False, False)
    all7 = hole + board
    (cat, tieb), best5 = best_5_from_7(all7)
    uses_hole = any(c in hole for c in best5)
    two_pair_plus = cat >= 2 and uses_hole
    # Overpair: pocket pair higher than any board card and best5 uses our pair for one pair
    board_ranks = [card_rank(c) for c in board]
    hole_ranks = [card_rank(c) for c in hole]
    overpair = False
    if hole_ranks[0] == hole_ranks[1]:
        if hole_ranks[0] > max(board_ranks):
            # Ensure one-pair hand
            if cat == 1 and uses_hole and tieb[0] == hole_ranks[0]:
                overpair = True
    # Top pair: we pair the highest rank on the board with a hole card
    top_board = max(board_ranks)
    top_pair = False
    if cat == 1 and uses_hole and tieb[0] == top_board and top_board in hole_ranks:
        top_pair = True
    return (top_pair, overpair, two_pair_plus)


def safe_pot_odds(amount_to_call: int, pot: int) -> float:
    denom = pot + amount_to_call + 1e-9
    return amount_to_call / denom


def can_check(round_state: RoundStateClient, my_bet: int) -> bool:
    return round_state.current_bet <= my_bet


def amount_to_call(round_state: RoundStateClient, my_bet: int) -> int:
    return max(0, round_state.current_bet - my_bet)


def choose_min_raise_amount(round_state: RoundStateClient, my_bet: int) -> int:
    # We try to use min_raise; ensure it results in a valid new bet strictly greater than current_bet
    atc = amount_to_call(round_state, my_bet)
    # Raise amount must at least make our total bet > current_bet; so need atc + 1 minimal.
    minimal_to_beat = atc + 1
    # Engine provides min_raise; take the maximum of these
    raise_amt = max(round_state.min_raise, minimal_to_beat)
    # Cap to max_raise
    if raise_amt > round_state.max_raise:
        return -1
    return raise_amt


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0  # as given by environment (assume big blind or base unit)
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.players: List[int] = []
        self.hole_cards: List[str] = []  # our current 2 hole cards
        self.round_num = 0
        self.random = random.Random(1337)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = list(player_hands) if player_hands else []
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = list(all_players) if all_players else []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Round start may come before we have updated hole cards from on_start in some engines.
        # If engine provides new hole cards via on_start each hand, they will already be set.
        # Nothing to do here except update round number.
        self.round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive defaults
        my_id_str = str(self.id) if self.id is not None else None
        my_bet = 0
        if my_id_str and round_state.player_bets and my_id_str in round_state.player_bets:
            my_bet = int(round_state.player_bets[my_id_str])
        atc = amount_to_call(round_state, my_bet)
        can_chk = can_check(round_state, my_bet)
        pot = int(round_state.pot or 0)
        max_raise = int(round_state.max_raise or 0)
        min_raise = int(round_state.min_raise or 0)
        opponents = max(0, len(round_state.current_player or []) - 1)

        # If we don't know our hole cards, act conservatively
        if not self.hole_cards or len(self.hole_cards) < 2:
            if can_chk:
                return (PokerAction.CHECK, 0)
            else:
                # Facing bet with unknown hand: fold unless bet is minuscule and pot odds great.
                if safe_pot_odds(atc, pot) < 0.15:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        stage = (round_state.round or '').lower()

        # Preflop logic
        if stage == 'preflop':
            tier = classify_preflop(self.hole_cards)

            # If no bet to us
            if can_chk:
                # Opening or completing from BB
                if tier in ('premium', 'strong'):
                    # Try to open-raise with a minimum raise, fallback to check
                    raise_amt = choose_min_raise_amount(round_state, my_bet)
                    if raise_amt != -1 and raise_amt > 0:
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.CHECK, 0)
                elif tier in ('medium', 'speculative'):
                    # Mix in occasional raise with medium; mostly check
                    if self.random.random() < 0.25:
                        raise_amt = choose_min_raise_amount(round_state, my_bet)
                        if raise_amt != -1 and raise_amt > 0:
                            return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Facing a bet (raise)
                pot_odds = safe_pot_odds(atc, pot)
                # Strong hands: continue; occasionally jam with premiums
                if tier == 'premium':
                    # If raise isn't too big, call; else jam sometimes
                    if atc <= max(self.blind_amount * 6, 30):
                        return (PokerAction.CALL, 0)
                    # If we can't comfortably call or raise more, go all-in with top ~10% randomization
                    if self.random.random() < 0.6 and max_raise > 0:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                elif tier == 'strong':
                    # Call if pot odds are decent; avoid huge calls
                    if pot_odds <= 0.30 or atc <= max(self.blind_amount * 4, 20):
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                elif tier in ('medium', 'speculative'):
                    # Continue only with good price
                    if pot_odds <= 0.20 and atc <= max(self.blind_amount * 3, 15):
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    # Trash: fold to raises; call only if almost free
                    if atc <= max(1, self.blind_amount // 2) and pot_odds <= 0.10:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

        # Postflop logic
        board = list(round_state.community_cards or [])
        all7 = self.hole_cards + board
        best_rank, best5 = best_5_from_7(all7)
        cat, tieb = best_rank  # category and tiebreakers

        # Determine whether our hole cards contribute (to avoid paying with pure-board hands)
        uses_hole = any(c in self.hole_cards for c in best5)

        top_pair, overpair, two_pair_plus = is_top_pair_or_better_with_hole(self.hole_cards, board)
        fd = has_flush_draw(self.hole_cards, board)
        sd = has_straight_draw(self.hole_cards, board)

        # Heuristic strength score in [0,1]
        strength = 0.0
        if cat >= 6:
            strength = 0.92  # full house or better
        elif cat == 5:
            strength = 0.86  # flush
        elif cat == 4:
            strength = 0.80  # straight
        elif cat == 3:
            strength = 0.74  # trips
        elif cat == 2:
            strength = 0.64  # two pair
        elif cat == 1:
            # One pair: refine by top/over/weak
            if overpair or top_pair:
                # Kicker consideration: if top kicker (A/K/Q) we give extra
                kicker_high = (tieb[1] >= 12) if len(tieb) > 1 else False  # A/K/Q as 14/13/12
                strength = 0.58 + (0.04 if kicker_high else 0.0)
            else:
                strength = 0.45
        else:
            # High card with draws
            if fd and sd:
                strength = 0.50
            elif fd:
                strength = 0.44 if stage == 'flop' else 0.37
            elif sd:
                strength = 0.40 if stage == 'flop' else 0.33
            else:
                strength = 0.20

        # If our best hand does not use a hole card and it's not a monster, discount heavily
        if not uses_hole and cat < 5:
            strength *= 0.65

        # Slightly tighten vs multiple opponents
        if opponents >= 2:
            strength -= min(0.15, 0.05 * opponents)

        # Decide action
        if can_chk:
            # We can check; consider betting/raising for value with strong hand
            if strength >= 0.80:
                # Try to build pot: raise/bet
                raise_amt = choose_min_raise_amount(round_state, my_bet)
                if raise_amt != -1 and raise_amt > 0:
                    return (PokerAction.RAISE, raise_amt)
                elif max_raise > 0:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CHECK, 0)
            elif strength >= 0.62:
                # Sometimes bet for value/protection
                if self.random.random() < 0.5:
                    raise_amt = choose_min_raise_amount(round_state, my_bet)
                    if raise_amt != -1 and raise_amt > 0:
                        return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Facing a bet
            pot_odds = safe_pot_odds(atc, pot)
            # If we are very strong, prefer raising or all-in
            if strength >= 0.85:
                # Go for maximum value
                if max_raise > 0:
                    # Mix between min-raise and jam
                    if self.random.random() < 0.6:
                        return (PokerAction.ALL_IN, 0)
                    raise_amt = choose_min_raise_amount(round_state, my_bet)
                    if raise_amt != -1 and raise_amt > 0:
                        return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            # Call based on pot odds
            margin = 0.05
            if strength >= pot_odds + margin:
                # Semi-bluff raise with strong draws sometimes
                if (fd or sd) and strength >= 0.40 and self.random.random() < 0.25:
                    raise_amt = choose_min_raise_amount(round_state, my_bet)
                    if raise_amt != -1 and raise_amt > 0:
                        return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CALL, 0)
            # Otherwise fold
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards after round ends (next on_start should supply new hole cards)
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing persistent across games needed
        pass