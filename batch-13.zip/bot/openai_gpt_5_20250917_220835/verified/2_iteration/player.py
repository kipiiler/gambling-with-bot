from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

# Helper constants
RANK_ORDER = "23456789TJQKA"
RANK_TO_VAL = {r: i for i, r in enumerate(RANK_ORDER, start=2)}

def safe_div(n: float, d: float, eps: float = 1e-9) -> float:
    return n / (d + eps)

def card_rank(card: str) -> str:
    # Expects 'Ah', 'Td', etc.
    return card[0].upper()

def card_suit(card: str) -> str:
    return card[1].lower()

def is_suited(c1: str, c2: str) -> bool:
    return card_suit(c1) == card_suit(c2)

def rank_value(rc: str) -> int:
    return RANK_TO_VAL.get(rc.upper(), 0)

def sorted_ranks_desc(cards: List[str]) -> List[int]:
    return sorted([rank_value(card_rank(c)) for c in cards], reverse=True)

def count_by_suit(cards: List[str]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for c in cards:
        s = card_suit(c)
        d[s] = d.get(s, 0) + 1
    return d

def count_by_rank(cards: List[str]) -> Dict[int, int]:
    d: Dict[int, int] = {}
    for c in cards:
        r = rank_value(card_rank(c))
        d[r] = d.get(r, 0) + 1
    return d

def has_straight(ranks: List[int]) -> bool:
    # Given ranks as integers, detect any 5-card straight (Ace can be low)
    rset = set(ranks)
    # Treat Ace low
    if 14 in rset:
        rset.add(1)
    uniq = sorted(rset)
    if len(uniq) < 5:
        return False
    # slide window
    cnt = 1
    for i in range(1, len(uniq)):
        if uniq[i] == uniq[i-1] + 1:
            cnt += 1
            if cnt >= 5:
                return True
        else:
            cnt = 1
    return False

def straight_draw_potential(ranks: List[int]) -> Tuple[bool, bool]:
    # Returns (OESD, Gutshot) approximations for flop/turn
    rset = set(ranks)
    if 14 in rset:
        rset.add(1)
    uniq = sorted(rset)
    # Look for sequences of length 4 (OESD) or gaps indicating gutshot
    # Approximation: check any 4 out of 5 consecutive numbers present -> gutshot
    # and any 4 consecutive present -> OESD
    # Build run map
    oesd = False
    gut = False
    for start in range(1, 11):  # 1..10 possible starts
        seq = [start + i for i in range(5)]
        present = [v in rset for v in seq]
        c = sum(present)
        if c >= 4:
            # If missing exactly one and it's an end -> OESD, else gutshot
            if c == 4:
                missing_idx = [i for i, p in enumerate(present) if not p]
                if len(missing_idx) == 1:
                    if missing_idx[0] in (0, 4):
                        oesd = True
                    else:
                        gut = True
            else:
                # Already straight covered elsewhere
                pass
    return (oesd, gut)

def classify_preflop(hole: List[str]) -> str:
    # Returns one of: 'premium', 'strong', 'medium', 'speculative', 'trash'
    r1 = card_rank(hole[0])
    r2 = card_rank(hole[1])
    v1 = rank_value(r1)
    v2 = rank_value(r2)
    suited = is_suited(hole[0], hole[1])

    if r1 == r2:
        # Pairs
        if v1 >= rank_value('J'):
            return 'premium'  # JJ, QQ, KK, AA
        elif v1 == rank_value('T') or v1 == rank_value('9'):
            return 'strong'   # TT, 99
        elif v1 >= rank_value('7'):
            return 'medium'   # 77, 88
        else:
            return 'speculative'  # 22-66
    # Non-pair
    high = max(v1, v2)
    low = min(v1, v2)
    ranks = ''.join(sorted([r1, r2], key=lambda x: rank_value(x), reverse=True))
    # Premium combos
    if suited and set([r1, r2]) == set(['A', 'K']):
        return 'premium'  # AKs
    if not suited and set([r1, r2]) == set(['A', 'K']):
        return 'strong'   # AKo
    # Strong broadways
    if suited and ((('A' in (r1, r2)) and (low >= rank_value('J'))) or ranks in ['KQ', 'QJ', 'KJ']):
        # AQs/AJs/KQs/KJs/QJs
        if ('A' in (r1, r2) and low >= rank_value('Q')) or ranks == 'KQ':
            return 'strong'
        else:
            return 'medium'
    if not suited and (('A' in (r1, r2) and low >= rank_value('Q')) or ranks in ['KQ']):
        return 'medium'  # AQo/KQo
    # Suited aces
    if suited and 'A' in (r1, r2) and low >= rank_value('2'):
        if low >= rank_value('T'):
            return 'medium'  # ATs+
        else:
            return 'speculative'  # Axs
    # Suited connectors/gappers
    gap = abs(v1 - v2)
    if suited and gap == 1 and high >= rank_value('6'):
        if high >= rank_value('T'):
            return 'medium'  # T9s+
        else:
            return 'speculative'  # 65s-98s
    if suited and gap == 2 and high >= rank_value('9'):
        return 'speculative'  # one-gappers like J9s, T8s, 98s handled above
    # Offsuit broadways
    if not suited and high >= rank_value('Q') and low >= rank_value('T'):
        return 'speculative'  # QTo+, KTo+, ATo
    # Ace-X offsuit decent
    if not suited and 'A' in (r1, r2) and low >= rank_value('T'):
        return 'speculative'
    return 'trash'

def estimate_preflop_equity(cls: str, num_players: int) -> float:
    # Very rough HU baseline equity versus one random opponent
    base = {
        'premium': 0.70,
        'strong': 0.60,
        'medium': 0.53,
        'speculative': 0.47,
        'trash': 0.40
    }.get(cls, 0.45)
    # Multiway penalty: subtract 5% per extra opponent beyond 1 (heads-up)
    penalty = max(0, num_players - 2) * 0.05
    return max(0.05, min(0.95, base - penalty))

def evaluate_postflop_strength(hole: List[str], board: List[str]) -> float:
    # Approximate strength score [0,1] using simple heuristics
    cards = hole + board
    ranks = [rank_value(card_rank(c)) for c in cards]
    ranks_board = [rank_value(card_rank(c)) for c in board]
    rank_counts = count_by_rank(cards)
    suit_counts = count_by_suit(cards)
    max_suit = max(suit_counts.values()) if suit_counts else 0
    # Hand categories
    counts = sorted(rank_counts.values(), reverse=True)
    four = 4 in counts
    three = 3 in counts
    pairs = sum(1 for v in rank_counts.values() if v == 2)

    # Strong made hands
    if four:
        return 0.95
    if three and pairs >= 1:
        return 0.90  # full house
    if max_suit >= 5:
        return 0.86  # flush
    if has_straight(ranks):
        return 0.82  # straight
    if three:
        return 0.74  # trips
    if pairs >= 2:
        return 0.66  # two pair

    # One pair / overpair / top pair detection
    my_ranks = [rank_value(card_rank(c)) for c in hole]
    board_ranks = [rank_value(card_rank(c)) for c in board]
    my_pair = (card_rank(hole[0]) == card_rank(hole[1]))
    overpair = False
    if my_pair and len(board) >= 3:
        overpair = my_ranks[0] > max(board_ranks) if board_ranks else False

    if overpair:
        return 0.62

    # Check if we paired the board
    pair_made = False
    top_pair = False
    second_pair = False
    if len(board) >= 3:
        max_board = max(board_ranks) if board_ranks else 0
        sorted_board = sorted(set(board_ranks), reverse=True)
        top_board = sorted_board[0] if sorted_board else 0
        second_board = sorted_board[1] if len(sorted_board) > 1 else 0
        for r in my_ranks:
            if r in board_ranks:
                pair_made = True
                if r == top_board:
                    top_pair = True
                elif r == second_board:
                    second_pair = True

    if top_pair:
        # Kicker check
        high_kicker = max(my_ranks) >= rank_value('K')
        return 0.58 if high_kicker else 0.55
    if second_pair:
        return 0.47
    if pair_made:
        return 0.42

    # Draws on flop/turn
    if len(board) in (3, 4):
        # Flush draw (4 to a suit including our hole)
        hole_suits = [card_suit(c) for c in hole]
        fd = False
        nfd = False
        for s in set(hole_suits):
            total = sum(1 for c in cards if card_suit(c) == s)
            if total == 4:
                fd = True
                # Nut FD if we hold the Ace of that suit
                if any(card_rank(c) == 'A' and card_suit(c) == s for c in hole):
                    nfd = True
        oesd, gut = straight_draw_potential(ranks)
        base = 0.30  # no pair
        if fd:
            base += 0.10
            if nfd:
                base += 0.02
        if oesd:
            base += 0.08
        elif gut:
            base += 0.04
        # Overcards bonus
        if len(board) >= 3:
            max_board = max(board_ranks) if board_ranks else 0
            oc = sum(1 for r in my_ranks if r > max_board)
            if oc >= 2:
                base += 0.03
        return max(0.20, min(0.58, base))

    # Ace high / nothing
    if 'A' in [card_rank(c) for c in hole]:
        return 0.32
    return 0.25

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # big blind
        self.small_blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.rng = random.Random()

        # Opponent tracking (simple)
        self.vpip: Dict[int, int] = {}  # voluntarily put $ in pot counts
        self.pfr: Dict[int, int] = {}   # preflop raise counts
        self.hands_played: Dict[int, int] = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.starting_chips = starting_chips
            self.blind_amount = blind_amount
            # Assuming small blind is half big blind; if odd, floor division and ensure >=1
            self.small_blind_amount = max(1, blind_amount // 2)
            self.big_blind_player_id = big_blind_player_id
            self.small_blind_player_id = small_blind_player_id
            self.all_players = all_players[:] if all_players else []
            self.hole_cards = player_hands[:] if player_hands else []
            # Seed RNG for some stochasticity but stable-ish per game
            seed_base = (self.id or 0) ^ (sum(rank_value(card_rank(c)) for c in self.hole_cards) << 3) ^ (blind_amount << 1)
            self.rng.seed(seed_base)
            # Increment hands played
            for pid in self.all_players:
                self.hands_played[pid] = self.hands_played.get(pid, 0) + 1
        except Exception:
            # Fail-safe defaults
            self.hole_cards = self.hole_cards if self.hole_cards else []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # We can update any per-round state if needed
        pass

    def _my_current_bet(self, round_state: RoundStateClient) -> int:
        return int(round_state.player_bets.get(str(self.id), 0))

    def _amount_to_call(self, round_state: RoundStateClient) -> int:
        return max(0, int(round_state.current_bet) - self._my_current_bet(round_state))

    def _can_check(self, round_state: RoundStateClient) -> bool:
        # Per competition rule: You can't check if round's current bet > 0
        return int(round_state.current_bet) == 0

    def _num_active_players(self, round_state: RoundStateClient) -> int:
        # Best guess: current_player contains IDs of the current players still in the hand
        if round_state.current_player and isinstance(round_state.current_player, list):
            return len(round_state.current_player)
        # Fallback
        return max(2, len(self.all_players) if self.all_players else 2)

    def _is_heads_up(self, round_state: RoundStateClient) -> bool:
        return self._num_active_players(round_state) == 2

    def _in_small_blind(self) -> bool:
        return self.id == self.small_blind_player_id

    def _in_big_blind(self) -> bool:
        return self.id == self.big_blind_player_id

    def _valid_raise_amount(self, round_state: RoundStateClient, desired_total_bet: int, remaining_chips: int) -> Optional[int]:
        my_bet = self._my_current_bet(round_state)
        min_raise = int(round_state.min_raise)
        max_raise_amt = int(min(round_state.max_raise, remaining_chips))
        amount = int(max(desired_total_bet - my_bet, min_raise))
        # Ensure the new total bet exceeds current_bet
        if my_bet + amount <= int(round_state.current_bet):
            need = (int(round_state.current_bet) - my_bet) + min_raise
            amount = max(amount, need)
        if amount < min_raise:
            return None
        if amount > max_raise_amt:
            amount = max_raise_amt
        if amount < min_raise:
            return None
        # If after all, cannot exceed our chips or doesn't surpass current bet, consider None
        if my_bet + amount <= int(round_state.current_bet):
            return None
        return amount

    def _bet_pot_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, pct: float) -> Optional[int]:
        # When no one has bet (current_bet == 0), "bet" by raising an amount roughly equal to pct * pot
        pot = int(round_state.pot)
        target = int(pot * pct)
        target = max(target, int(round_state.min_raise))
        my_bet = self._my_current_bet(round_state)
        desired_total = my_bet + target  # Since current_bet is 0, our new bet equals amount
        return self._valid_raise_amount(round_state, desired_total_bet=desired_total, remaining_chips=remaining_chips)

    def _raise_over_current(self, round_state: RoundStateClient, remaining_chips: int, multiple: float = 2.5) -> Optional[int]:
        # Facing a bet/raise; raise to roughly multiple x the current bet (total), typical for 3bet/raise sizing
        current = int(round_state.current_bet)
        desired_total = int(current * multiple)
        return self._valid_raise_amount(round_state, desired_total_bet=desired_total, remaining_chips=remaining_chips)

    def _open_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, bb_mult: float = 2.5) -> Optional[int]:
        # Preflop open sizing relative to big blind
        desired_total = int(self.blind_amount * bb_mult)
        return self._valid_raise_amount(round_state, desired_total_bet=desired_total, remaining_chips=remaining_chips)

    def _call_or_check(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        amt_to_call = self._amount_to_call(round_state)
        if amt_to_call <= 0 and self._can_check(round_state):
            return (PokerAction.CHECK, 0)
        if amt_to_call > 0 and amt_to_call <= remaining_chips:
            return (PokerAction.CALL, 0)
        # If cannot call (all-in insufficient), just all-in if we have any chips
        if remaining_chips > 0:
            return (PokerAction.ALL_IN, 0)
        return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            stage = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'
            my_bet = self._my_current_bet(round_state)
            amt_to_call = self._amount_to_call(round_state)
            pot = int(round_state.pot)
            num_players = self._num_active_players(round_state)
            is_hu = (num_players == 2)

            # Avoid going crazy when short
            bb = max(1, self.blind_amount)
            effective_bb = safe_div(remaining_chips, bb)
            short_stack = effective_bb <= 20.0

            # PRE-FLOP
            if stage.lower() == 'preflop':
                cls = classify_preflop(self.hole_cards) if len(self.hole_cards) == 2 else 'trash'
                eq = estimate_preflop_equity(cls, num_players)

                # Determine if it's unopened pot (beyond blinds)
                unopened = int(round_state.current_bet) <= self.blind_amount

                # Open actions
                if unopened:
                    # Our turn with option to check/call/raise
                    # If we're BB and no raise, we can check
                    if self._can_check(round_state):
                        # Consider raising as BB vs limp (rare in HU), otherwise check
                        if cls in ('premium', 'strong') and self.rng.random() < 0.7:
                            amt = self._open_raise_amount(round_state, remaining_chips, bb_mult=3.0)
                            if amt is not None and amt >= int(round_state.min_raise):
                                return (PokerAction.RAISE, int(amt))
                        return (PokerAction.CHECK, 0)
                    else:
                        # We are likely SB (first to act); choose between limp and open-raise
                        if cls in ('premium', 'strong', 'medium') or (cls == 'speculative' and self.rng.random() < 0.5):
                            amt = self._open_raise_amount(round_state, remaining_chips, bb_mult=2.5 if not short_stack else 3.0)
                            if amt is not None and amt >= int(round_state.min_raise):
                                return (PokerAction.RAISE, int(amt))
                            # Fallback
                            return self._call_or_check(round_state, remaining_chips)
                        else:
                            # Limp or fold if facing min-raise (should not happen in unopened), here call matches BB
                            return self._call_or_check(round_state, remaining_chips)
                else:
                    # Facing a raise
                    # Simple pot-odds call rule
                    call_needed = amt_to_call
                    pot_after_call = pot + call_needed
                    pot_odds = safe_div(call_needed, pot_after_call)
                    # Tighten if multiway
                    adj_eq = eq - (0.02 if num_players > 2 else 0.0)
                    # 3-bet with premiums/strong; call with decent equity; fold trash
                    if cls in ('premium', 'strong'):
                        # 3-bet sizing
                        mult = 3.0 if not short_stack else 2.2
                        amt = self._raise_over_current(round_state, remaining_chips, multiple=mult)
                        if amt is not None and amt >= int(round_state.min_raise) and (my_bet + amt) < remaining_chips:
                            return (PokerAction.RAISE, int(amt))
                        # If we cannot raise validly, call if possible
                        if adj_eq >= pot_odds or call_needed <= remaining_chips:
                            return (PokerAction.CALL, 0)
                        # As a last resort with very strong, shove short
                        if short_stack and remaining_chips > 0:
                            return (PokerAction.ALL_IN, 0)
                    # Medium/speculative: call if prices good
                    if adj_eq >= pot_odds and call_needed <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    # Fold the rest
                    return (PokerAction.FOLD, 0)

            # POST-FLOP (Flop/Turn/River)
            board = round_state.community_cards if round_state.community_cards else []
            strength = evaluate_postflop_strength(self.hole_cards, board) if len(self.hole_cards) == 2 else 0.25

            # Determine aggression according to strength and street
            is_flop = stage.lower() == 'flop'
            is_turn = stage.lower() == 'turn'
            is_river = stage.lower() == 'river'

            # Choose baseline bet sizes
            val_bet_pct = 0.65 if is_flop else (0.60 if is_turn else 0.55)
            bluff_bet_pct = 0.55 if is_flop else (0.50 if is_turn else 0.45)

            # If no bet yet, decide whether to bet
            if self._can_check(round_state):
                # Value bet thresholds
                if strength >= 0.66:  # two pair or better typically
                    amt = self._bet_pot_raise_amount(round_state, remaining_chips, pct=val_bet_pct)
                    if amt is not None and amt >= int(round_state.min_raise):
                        return (PokerAction.RAISE, int(amt))
                    return (PokerAction.CHECK, 0)
                # Medium strength/top pair/overpair
                if strength >= 0.55:
                    # Mix between bet/check
                    if self.rng.random() < 0.7:
                        amt = self._bet_pot_raise_amount(round_state, remaining_chips, pct=0.5)
                        if amt is not None and amt >= int(round_state.min_raise):
                            return (PokerAction.RAISE, int(amt))
                    return (PokerAction.CHECK, 0)
                # Semi-bluff draws
                if (is_flop or is_turn) and 0.36 <= strength < 0.55:
                    if self.rng.random() < 0.5:
                        amt = self._bet_pot_raise_amount(round_state, remaining_chips, pct=bluff_bet_pct)
                        if amt is not None and amt >= int(round_state.min_raise):
                            return (PokerAction.RAISE, int(amt))
                # Otherwise check
                return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                call_needed = amt_to_call
                pot_after_call = pot + call_needed
                pot_odds = safe_div(call_needed, pot_after_call)
                # Aggressive raises with strong value
                if strength >= 0.70:
                    # Raise for value
                    mult = 2.8 if is_flop else 2.5
                    amt = self._raise_over_current(round_state, remaining_chips, multiple=mult)
                    if amt is not None and amt >= int(round_state.min_raise) and (self._my_current_bet(round_state) + amt) < remaining_chips:
                        return (PokerAction.RAISE, int(amt))
                    # If cannot raise, call
                    if call_needed <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    # Or shove if short and very strong
                    if short_stack and remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.FOLD, 0)
                # Medium strength hands: call if odds acceptable
                if strength >= 0.52 and strength > pot_odds:
                    if call_needed <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    if short_stack and remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.FOLD, 0)
                # Draws/semi-bluffs: occasionally raise, else call if priced in
                if (is_flop or is_turn) and 0.36 <= strength < 0.55:
                    # Semi-bluff raise sometimes
                    if self.rng.random() < (0.35 if not short_stack else 0.25):
                        amt = self._raise_over_current(round_state, remaining_chips, multiple=2.5)
                        if amt is not None and amt >= int(round_state.min_raise) and (self._my_current_bet(round_state) + amt) < remaining_chips:
                            return (PokerAction.RAISE, int(amt))
                    # Otherwise, call if priced in
                    implied_bonus = 0.03 if is_flop else 0.015
                    if (strength + implied_bonus) > pot_odds and call_needed <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                # Thin bluff catchers on river: call small bets sometimes
                if is_river and 0.45 <= strength < 0.52:
                    # If bet is small relative to pot (<= 1/3 pot), consider call
                    if call_needed <= remaining_chips and call_needed <= pot / 3:
                        if self.rng.random() < 0.5:
                            return (PokerAction.CALL, 0)
                # Default: fold
                return (PokerAction.FOLD, 0)
        except Exception:
            # Fail-safe: prefer check/call small, else fold
            try:
                if self._can_check(round_state):
                    return (PokerAction.CHECK, 0)
                amt_to_call = self._amount_to_call(round_state)
                if amt_to_call <= max(0, int(self.blind_amount)) and amt_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could update simple stats from player_actions
        try:
            actions = round_state.player_actions or {}
            for pid_str, act in actions.items():
                try:
                    pid = int(pid_str)
                except Exception:
                    continue
                if act in ('Raise', 'Bet'):
                    self.pfr[pid] = self.pfr.get(pid, 0) + 1
                    self.vpip[pid] = self.vpip.get(pid, 0) + 1
                elif act in ('Call',):
                    self.vpip[pid] = self.vpip.get(pid, 0) + 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No-op for now; could log results if needed.
        pass