import random
import math
from typing import List, Tuple, Dict, Any, Optional
from itertools import combinations
from collections import Counter

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
              '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11,
              'Q': 12, 'K': 13, 'A': 14}
RANKS = list(RANK_ORDER.keys())
SUITS = ['h', 'd', 'c', 's']
FULL_DECK = [r + s for r in RANKS for s in SUITS]


def parse_card(card: str) -> Tuple[int, str]:
    # Safely parse a card like 'Ah', 'Kd'.
    if not isinstance(card, str) or len(card) < 2:
        return (0, '')
    r, s = card[0], card[1]
    return (RANK_ORDER.get(r, 0), s)


def is_straight(ranks: List[int]) -> int:
    # Return highest straight high card rank, or 0 if none.
    # Input ranks should be unique and sorted descending.
    if not ranks:
        return 0
    unique = sorted(set(ranks), reverse=True)
    # Handle A-2-3-4-5 by treating Ace as 1 as well
    if 14 in unique:
        unique.append(1)
    run = 1
    best_high = 0
    for i in range(len(unique) - 1):
        if unique[i] - 1 == unique[i + 1]:
            run += 1
            if run >= 5:
                best_high = max(best_high, unique[i - 3])  # high card at start of 5-length
        elif unique[i] != unique[i + 1]:
            run = 1
    return best_high


def hand_rank_5(cards5: List[str]) -> Tuple[int, Tuple[int, ...]]:
    # Evaluate exact 5-card hand. Return a rank tuple where larger is better.
    ranks = [parse_card(c)[0] for c in cards5]
    suits = [parse_card(c)[1] for c in cards5]
    ranks_sorted = sorted(ranks, reverse=True)
    # Count occurrences
    cnt = Counter(ranks)
    groups = sorted(cnt.items(), key=lambda x: (x[1], x[0]), reverse=True)  # sort by count desc, then rank desc
    # Flush?
    is_flush = False
    flush_suit = None
    suit_cnt = Counter(suits)
    for s, c in suit_cnt.items():
        if c >= 5:
            is_flush = True
            flush_suit = s
            break
    # Straight?
    straight_high = is_straight(ranks)
    # Straight flush?
    if is_flush:
        ranks_flush = sorted([parse_card(c)[0] for c in cards5 if parse_card(c)[1] == flush_suit], reverse=True)
        straight_flush_high = is_straight(ranks_flush)
        if straight_flush_high:
            # Category 8: straight flush
            return (8, (straight_flush_high,))
    # Four of a kind
    if groups[0][1] == 4:
        four = groups[0][0]
        kicker = max([r for r in ranks if r != four]) if any(r != four for r in ranks) else 0
        return (7, (four, kicker))
    # Full house
    if groups[0][1] == 3 and groups[1][1] >= 2:
        triple = groups[0][0]
        pair = groups[1][0] if groups[1][1] >= 2 else 0
        return (6, (triple, pair))
    # Flush
    if is_flush:
        flush_ranks = sorted([parse_card(c)[0] for c in cards5 if parse_card(c)[1] == flush_suit], reverse=True)[:5]
        return (5, tuple(flush_ranks))
    # Straight
    if straight_high:
        return (4, (straight_high,))
    # Three of a kind
    if groups[0][1] == 3:
        triple = groups[0][0]
        kickers = [r for r in ranks_sorted if r != triple][:2]
        while len(kickers) < 2:
            kickers.append(0)
        return (3, (triple, kickers[0], kickers[1]))
    # Two pair
    if groups[0][1] == 2 and groups[1][1] == 2:
        high_pair = max(groups[0][0], groups[1][0])
        low_pair = min(groups[0][0], groups[1][0])
        kicker = max([r for r in ranks_sorted if r != high_pair and r != low_pair]) if any(
            r != high_pair and r != low_pair for r in ranks_sorted) else 0
        return (2, (high_pair, low_pair, kicker))
    # One pair
    if groups[0][1] == 2:
        pair = groups[0][0]
        kickers = [r for r in ranks_sorted if r != pair][:3]
        while len(kickers) < 3:
            kickers.append(0)
        return (1, (pair, kickers[0], kickers[1], kickers[2]))
    # High card
    top5 = ranks_sorted[:5] + [0] * (5 - len(ranks_sorted[:5]))
    return (0, tuple(top5))


def best_hand_rank(cards7: List[str]) -> Tuple[int, Tuple[int, ...]]:
    # Enumerate all 21 5-card combos, take best
    best = (-1, ())
    for combo in combinations(cards7, 5):
        r = hand_rank_5(list(combo))
        if r > best:
            best = r
    return best


def estimate_equity(hole_cards: List[str], community_cards: List[str], num_opponents: int, iterations: int = 200,
                    rng: Optional[random.Random] = None) -> float:
    # Monte Carlo equity estimation vs num_opponents.
    # Returns estimated probability of winning (with split pot counted fractionally).
    if rng is None:
        rng = random.Random()
    try:
        known_cards = set(hole_cards + community_cards)
        deck = [c for c in FULL_DECK if c not in known_cards]
        if num_opponents <= 0:
            # Heads up against no one -> 100% equity
            return 1.0
        wins = 0.0
        iters = max(1, iterations)
        # Ensure feasible number of opponents (cap to avoid overdraw)
        max_opp_by_deck = (len(deck) - max(0, 5 - len(community_cards))) // 2
        opps = max(1, min(num_opponents, max_opp_by_deck))
        for _ in range(iters):
            rng.shuffle(deck)
            draw_idx = 0
            # Opponent hands
            opp_hands = []
            for _o in range(opps):
                if draw_idx + 2 > len(deck):
                    break
                opp_hands.append([deck[draw_idx], deck[draw_idx + 1]])
                draw_idx += 2
            # Board runout
            needed = 5 - len(community_cards)
            board = list(community_cards)
            if needed > 0:
                if draw_idx + needed > len(deck):
                    # not enough cards left; reshuffle minimal
                    rng.shuffle(deck)
                    draw_idx = 0
                board.extend(deck[draw_idx:draw_idx + needed])
                draw_idx += needed
            # Evaluate hands
            my_rank = best_hand_rank(hole_cards + board)
            best_ranks = [my_rank]
            for oh in opp_hands:
                best_ranks.append(best_hand_rank(oh + board))
            max_rank = max(best_ranks)
            winners = [i for i, r in enumerate(best_ranks) if r == max_rank]
            # Index 0 is hero
            if 0 in winners:
                wins += 1.0 / len(winners)
        return wins / (iters + 1e-9)
    except Exception:
        # Fallback in case of any issue
        return 0.5


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: Optional[List[str]] = None
        self.round_counter = 0
        self.rng = random.Random(1337)
        self.player_last_actions: Dict[str, str] = {}
        self.debug = False  # set True to enable verbose internal logging (if supported)
        self.last_round_seen = -1

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players if all_players else []
        # Try to parse hole cards if provided here (some environments may provide them)
        if isinstance(player_hands, list) and len(player_hands) == 2 and isinstance(player_hands[0], str):
            self.hole_cards = player_hands[:]  # copy
        else:
            self.hole_cards = None
        # Seed RNG differently per player if id is set later.
        if self.id is not None:
            self.rng.seed(1337 + int(self.id))

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_counter += 1
        self.player_last_actions = dict(round_state.player_actions) if round_state and round_state.player_actions else {}
        # Attempt to refresh hole cards if they are embedded somewhere; otherwise, clear it for safety.
        self.hole_cards = self._extract_hole_cards_from_state(round_state)

    def _extract_hole_cards_from_state(self, round_state: RoundStateClient) -> Optional[List[str]]:
        # Some engines may attach private cards in round_state via non-standard fields.
        # Try common attribute names gracefully.
        try:
            for attr in ['my_hand', 'hand', 'hole_cards', 'player_hands', 'private_cards']:
                if hasattr(round_state, attr):
                    val = getattr(round_state, attr)
                    if isinstance(val, list):
                        # If it's a list of strings of length 2, take it as hole cards.
                        if len(val) == 2 and all(isinstance(x, str) for x in val):
                            return list(val)
                        # If it's a dict keyed by player id
                        if isinstance(val, dict):
                            key = str(self.id) if self.id is not None else None
                            if key and key in val and isinstance(val[key], list) and len(val[key]) == 2:
                                return list(val[key])
            # No suitable attribute found; keep previous if same round number matched else None
            return None
        except Exception:
            return None

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Basic state parsing
            my_id_str = str(self.id) if self.id is not None else None
            my_bet = 0
            if round_state and round_state.player_bets and my_id_str in round_state.player_bets:
                my_bet = int(round_state.player_bets[my_id_str])
            current_bet = int(round_state.current_bet) if round_state else 0
            to_call = max(0, current_bet - my_bet)
            pot = int(round_state.pot) if round_state else 0
            min_raise = int(round_state.min_raise) if round_state and round_state.min_raise is not None else 0
            max_raise = int(round_state.max_raise) if round_state and round_state.max_raise is not None else 0
            community = list(round_state.community_cards) if round_state and round_state.community_cards else []
            stage = (round_state.round or "Preflop").lower() if round_state and round_state.round else "preflop"
            # Determine active opponents count
            opp_count = self._estimate_active_opponents(round_state)

            # If we cannot act (sanity), choose safe action
            if remaining_chips <= 0:
                return (PokerAction.CHECK if to_call == 0 else PokerAction.FOLD, 0)

            # If calling would exceed our stack, it's effectively all-in if we continue
            if to_call >= remaining_chips:
                # Make an all-in decision
                if self.hole_cards:
                    eq = estimate_equity(self.hole_cards, community, max(1, opp_count), iterations=200, rng=self.rng)
                    # Push if equity decent or pot odds favor calling
                    pot_odds = to_call / (pot + to_call + 1e-9)
                    if eq >= max(0.5, pot_odds + 0.05):
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Without hole cards, default to fold unless pot odds extremely good
                    pot_odds = to_call / (pot + to_call + 1e-9)
                    if pot_odds < 0.15:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)

            # No need to call; can check or bet
            if to_call == 0:
                # Decide whether to open-raise or check
                if self.hole_cards:
                    # Estimate equity vs opp_count (at least 1)
                    eq = estimate_equity(self.hole_cards, community, max(1, opp_count), iterations=180, rng=self.rng)
                    open_threshold = 0.53 if stage == "preflop" else (0.58 if stage in ("flop", "turn") else 0.60)
                    if eq > open_threshold and self._can_raise(min_raise, max_raise):
                        raise_amt = self._select_raise_amount(min_raise, max_raise, pot, to_call)
                        if raise_amt is not None:
                            return (PokerAction.RAISE, raise_amt)
                        # fallback
                        return (PokerAction.CHECK, 0)
                    else:
                        # Occasional bluff open if allowed
                        if self._can_raise(min_raise, max_raise) and self.rng.random() < 0.05:
                            raise_amt = self._select_raise_amount(min_raise, max_raise, pot, to_call)
                            if raise_amt is not None:
                                return (PokerAction.RAISE, raise_amt)
                        return (PokerAction.CHECK, 0)
                else:
                    # No hole cards info: be conservative; small chance to open raise
                    if self._can_raise(min_raise, max_raise) and self.rng.random() < 0.07:
                        raise_amt = self._select_raise_amount(min_raise, max_raise, pot, to_call)
                        if raise_amt is not None:
                            return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.CHECK, 0)

            # Facing a bet (to_call > 0)
            if self.hole_cards:
                eq = estimate_equity(self.hole_cards, community, max(1, opp_count), iterations=220, rng=self.rng)
                pot_odds = to_call / (pot + to_call + 1e-9)
                # Fold if equity far below breakeven
                if eq < pot_odds - 0.05:
                    return (PokerAction.FOLD, 0)
                # Strong hands can raise; otherwise call
                if eq > max(0.65, pot_odds + 0.1) and self._can_raise(min_raise, max_raise):
                    raise_amt = self._select_raise_amount(min_raise, max_raise, pot, to_call)
                    if raise_amt is not None:
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.CALL, 0)
                # Call within pot odds
                return (PokerAction.CALL, 0)
            else:
                # No hole cards: use pot odds to make a conservative decision
                pot_odds = to_call / (pot + to_call + 1e-9)
                # Call small bets; fold large bets
                if pot_odds <= 0.15 or to_call <= max(1, int(0.02 * max(1, remaining_chips))):
                    # Occasionally raise as bluff when bet is tiny
                    if self._can_raise(min_raise, max_raise) and self.rng.random() < 0.03:
                        raise_amt = self._select_raise_amount(min_raise, max_raise, pot, to_call)
                        if raise_amt is not None:
                            return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        except Exception:
            # Fallback safest action to avoid invalid move
            try:
                # Attempt to read to_call safely
                current_bet = int(round_state.current_bet) if round_state and round_state.current_bet is not None else 0
                my_bet = int(round_state.player_bets.get(str(self.id), 0)) if round_state and round_state.player_bets else 0
                to_call = max(0, current_bet - my_bet)
            except Exception:
                to_call = 0
            return (PokerAction.CHECK if to_call == 0 else PokerAction.FOLD, 0)

    def _can_raise(self, min_raise: int, max_raise: int) -> bool:
        try:
            return max_raise is not None and max_raise > 0 and min_raise is not None and min_raise > 0 and max_raise >= min_raise
        except Exception:
            return False

    def _select_raise_amount(self, min_raise: int, max_raise: int, pot: int, to_call: int) -> Optional[int]:
        # Choose a safe raise amount within bounds. Prefer minimum valid raise to avoid invalid action.
        try:
            if not self._can_raise(min_raise, max_raise):
                return None
            # Simple size: min_raise; occasionally size up if allowed
            if self.rng.random() < 0.15:
                target = min_raise + int(0.5 * max(0, pot))
                amt = max(min_raise, min(max_raise, target))
                return int(amt)
            return int(min_raise)
        except Exception:
            return None

    def _estimate_active_opponents(self, round_state: RoundStateClient) -> int:
        # Estimate number of opponents still in the hand (non-folded).
        try:
            if not round_state:
                return max(1, len(self.all_players) - 1) if self.all_players else 1
            player_actions = round_state.player_actions or {}
            # Base list of players
            base_players = self.all_players if self.all_players else [int(pid) for pid in (round_state.player_bets or {}).keys() if pid.isdigit()]
            if not base_players:
                # Fallback to current_player field
                base_players = round_state.current_player if round_state.current_player else []
            non_fold = 0
            for pid in base_players:
                pid_str = str(pid)
                act = player_actions.get(pid_str, None)
                if act is None or act.lower() != 'fold':
                    non_fold += 1
            # hero not counted as opponent
            opps = max(1, non_fold - 1) if non_fold > 0 else 1
            # Clamp realistic bounds
            opps = max(1, min(opps, 9))
            return opps
        except Exception:
            return 1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hand-specific info
        self.player_last_actions = dict(round_state.player_actions) if round_state and round_state.player_actions else {}
        self.hole_cards = None  # clear by default; will attempt to fetch next round if available

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally process results; no-op to keep it lightweight.
        pass