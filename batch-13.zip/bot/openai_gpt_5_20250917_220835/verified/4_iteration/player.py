import random
from typing import List, Tuple, Dict, Any, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANKS = "23456789TJQKA"
RANK_TO_VAL = {r: i + 2 for i, r in enumerate(RANKS)}
VAL_TO_RANK = {v: k for k, v in RANK_TO_VAL.items()}
SUITS = set("cdhs")


def card_rank(card: str) -> int:
    # card like 'Ah', 'Ks'
    if not card or len(card) < 2:
        return 0
    return RANK_TO_VAL.get(card[0], 0)


def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ""
    return card[1]


def sorted_desc(vals: List[int]) -> List[int]:
    return sorted(vals, reverse=True)


def rank_counts(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        r = card_rank(c)
        if r <= 0:
            continue
        counts[r] = counts.get(r, 0) + 1
    return counts


def suit_counts(cards: List[str]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for c in cards:
        s = card_suit(c)
        if s == "":
            continue
        counts[s] = counts.get(s, 0) + 1
    return counts


def has_flush(cards: List[str]) -> Optional[str]:
    counts = suit_counts(cards)
    best_suit = None
    best = 0
    for s, cnt in counts.items():
        if cnt > best:
            best = cnt
            best_suit = s
    if best >= 5:
        return best_suit
    return None


def straight_high_val(values: List[int]) -> Optional[int]:
    # values: list of ranks, maybe with duplicates. Find highest straight high card.
    if not values:
        return None
    uniq = sorted(set(values))
    # Ace-low handling: add 1 if Ace present
    if 14 in uniq:
        uniq = [1] + uniq
    # Find any run of 5+ consecutive
    best_high = None
    run = 1
    for i in range(1, len(uniq)):
        if uniq[i] == uniq[i - 1] + 1:
            run += 1
        else:
            run = 1
        if run >= 5:
            best_high = uniq[i]
    return best_high


def evaluate_7card_category(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Returns (category, tiebreakers) with category:
    8: Straight Flush
    7: Four of a Kind
    6: Full House
    5: Flush
    4: Straight
    3: Three of a Kind
    2: Two Pair
    1: One Pair
    0: High Card
    Tiebreakers is a list of ranks sorted for comparison (not strictly needed for our decisions).
    """
    if not cards:
        return 0, []

    ranks = [card_rank(c) for c in cards if card_rank(c) > 0]
    suits = [card_suit(c) for c in cards if card_suit(c)]
    if not ranks:
        return 0, []

    # Straight Flush
    flush_s = has_flush(cards)
    if flush_s:
        suited_vals = [card_rank(c) for c in cards if card_suit(c) == flush_s]
        sh = straight_high_val(suited_vals)
        if sh is not None:
            return 8, [sh]

    # Groups
    rc = rank_counts(cards)
    groups = sorted(((cnt, r) for r, cnt in rc.items()), reverse=True)  # sort by cnt desc, then rank desc
    counts_sorted = sorted(rc.values(), reverse=True)

    # Four of a Kind
    if counts_sorted and counts_sorted[0] == 4:
        four_rank = max([r for r, c in rc.items() if c == 4])
        kickers = sorted_desc([r for r in rc.keys() if r != four_rank])
        return 7, [four_rank] + kickers[:1]

    # Full House
    trips = sorted_desc([r for r, c in rc.items() if c == 3])
    pairs = sorted_desc([r for r, c in rc.items() if c == 2])
    if trips:
        if len(trips) >= 2:
            return 6, [trips[0], trips[1]]
        if pairs:
            return 6, [trips[0], pairs[0]]

    # Flush
    if flush_s:
        flush_vals = sorted_desc([card_rank(c) for c in cards if card_suit(c) == flush_s])
        return 5, flush_vals[:5]

    # Straight
    sh = straight_high_val(ranks)
    if sh is not None:
        return 4, [sh]

    # Three of a Kind
    if trips:
        kickers = sorted_desc([r for r in rc.keys() if r not in trips])
        return 3, [trips[0]] + kickers[:2]

    # Two Pair
    if len(pairs) >= 2:
        kickers = sorted_desc([r for r in rc.keys() if r not in pairs])
        return 2, [pairs[0], pairs[1]] + kickers[:1]

    # One Pair
    if len(pairs) == 1:
        kickers = sorted_desc([r for r in rc.keys() if r != pairs[0]])
        return 1, [pairs[0]] + kickers[:3]

    # High Card
    high = sorted_desc(list(rc.keys()))[:5]
    return 0, high


def is_pocket_pair(hole: List[str]) -> bool:
    return len(hole) == 2 and card_rank(hole[0]) == card_rank(hole[1]) and card_rank(hole[0]) > 0


def preflop_strength(hole: List[str]) -> float:
    """
    Rough preflop strength vs random opponent in heads-up.
    Returns value in [0,1].
    Based on simple heuristic: pairs high, suited, connectors, high cards.
    """
    if len(hole) != 2:
        return 0.0
    r1 = card_rank(hole[0])
    r2 = card_rank(hole[1])
    s1 = card_suit(hole[0])
    s2 = card_suit(hole[1])
    if r1 == 0 or r2 == 0:
        return 0.0

    high = max(r1, r2)
    low = min(r1, r2)
    suited = (s1 == s2)
    gap = abs(r1 - r2)

    # Pairs
    if r1 == r2:
        # scale pairs: 22..AA -> ~0.53..0.85
        base = 0.40 + (r1 - 2) * (0.45 / 12.0)
        return min(0.95, base + 0.05)

    # Broadways and strong aces
    strength = 0.25
    if high >= 14 and low >= 11:  # A with broadway
        strength = 0.62
    elif high >= 13 and low >= 12:  # KQ, KJ
        strength = 0.55
    elif high >= 12 and low >= 11:  # QJ
        strength = 0.48

    # Adjust for suitedness
    if suited:
        strength += 0.04

    # Connectors (including 1-gap)
    if gap == 0:
        pass  # already handled
    elif gap == 1:
        if high >= 11:
            strength += 0.08
        elif high >= 9:
            strength += 0.06
        else:
            strength += 0.03
    elif gap == 2:
        if high >= 11:
            strength += 0.03
        elif high >= 9:
            strength += 0.02

    # Strong specific hands bump
    tags = {tuple(sorted([r1, r2], reverse=True))}
    # AKs
    if suited and set([r1, r2]) == set([14, 13]):
        return 0.85
    # AKo
    if set([r1, r2]) == set([14, 13]):
        return max(strength, 0.78)
    # AQs/AQo
    if 14 in [r1, r2] and 12 in [r1, r2]:
        strength = max(strength, 0.70 if suited else 0.64)

    # Clamp
    return max(0.22, min(0.88, strength))


def has_flush_draw(cards: List[str], street: str) -> bool:
    # On flop/turn only meaningful
    if street not in ("Flop", "Turn"):
        return False
    counts = suit_counts(cards)
    return max(counts.values()) >= 4 if counts else False


def has_open_ended_straight_draw(cards: List[str], street: str) -> bool:
    if street not in ("Flop", "Turn"):
        return False
    vals = sorted(set([card_rank(c) for c in cards if card_rank(c) > 0]))
    if not vals:
        return False
    if 14 in vals:
        vals = [1] + vals
    # Check for any 4 consecutive values
    run = 1
    for i in range(1, len(vals)):
        if vals[i] == vals[i - 1] + 1:
            run += 1
            if run >= 4:
                # ensure it's not already a straight (5)
                # We'll conservatively still treat as OESD if at least one 4-run exists
                return True
        else:
            run = 1
    return False


def has_gutshot_draw(cards: List[str], street: str) -> bool:
    if street not in ("Flop", "Turn"):
        return False
    vals = sorted(set([card_rank(c) for c in cards if card_rank(c) > 0]))
    if not vals:
        return False
    if 14 in vals:
        vals = [1] + vals
    # For any 5-span window, if exactly 4 are present -> gutshot
    for start in range(1, 11):  # 1..10 -> spans to 5..14
        span = set(range(start, start + 5))
        present = len([v for v in vals if v in span])
        if present == 4:
            # ensure not already straight
            if not (set(range(start, start + 5)).issubset(vals)):
                return True
    return False


def detect_top_pair(hole: List[str], board: List[str]) -> bool:
    if not board or not hole:
        return False
    board_ranks = [card_rank(c) for c in board]
    if not board_ranks:
        return False
    top = max(board_ranks)
    hole_ranks = [card_rank(c) for c in hole]
    # top pair if we have card equal to top and board includes it (which it does by definition)
    return (top in hole_ranks)


def detect_overpair(hole: List[str], board: List[str]) -> bool:
    if not is_pocket_pair(hole) or not board:
        return False
    pair_rank = card_rank(hole[0])
    max_board = max([card_rank(c) for c in board]) if board else 0
    return pair_rank > max_board


def count_overcards(hole: List[str], board: List[str]) -> int:
    if not board or not hole:
        return 0
    max_board = max([card_rank(c) for c in board])
    return sum(1 for c in hole if card_rank(c) > max_board)


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # could be big blind depending on engine; we'll treat as base unit
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.players: List[int] = []
        self.hole_cards: List[str] = []
        self.current_round_num: int = 0
        self.rng = random.Random(1337)
        self.last_round_seen: Optional[str] = None
        self.hand_strength_cache: Dict[int, float] = {}  # keyed by round_num

    def _id_str(self) -> str:
        return str(self.id) if self.id is not None else ""

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount if blind_amount is not None else 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players[:] if all_players else []
        # Store hole cards if provided
        self.hole_cards = player_hands[:] if player_hands else []
        self.hand_strength_cache.clear()
        self.current_round_num = 0
        self.last_round_seen = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Since we may not be provided hole cards here, we retain from on_start or prior.
        # Reset per-hand caches if round_num changes.
        if round_state and round_state.round_num != self.current_round_num:
            self.current_round_num = round_state.round_num
            self.hand_strength_cache.clear()
            self.last_round_seen = round_state.round

    def _amount_to_call(self, rs: RoundStateClient) -> int:
        mybet = 0
        try:
            mybet = rs.player_bets.get(self._id_str(), 0) if rs.player_bets else 0
        except Exception:
            mybet = 0
        need = (rs.current_bet or 0) - mybet
        return max(0, need)

    def _pot_odds(self, call_amount: int, pot: int) -> float:
        denom = float(pot + call_amount) + 1e-9
        return float(call_amount) / denom

    def _estimate_equity(self, rs: RoundStateClient) -> float:
        """
        Very rough equity estimation using hand category and draws.
        """
        board = rs.community_cards or []
        street = rs.round
        hole = self.hole_cards or []

        # Preflop
        if street == "Preflop" or len(board) == 0:
            eq = preflop_strength(hole)
            # Slightly adjust for players count (heads-up vs multi)
            n_players = max(2, len(self.players)) if self.players else 2
            # reduce equity slightly for more players
            eq = max(0.0, eq - 0.04 * (n_players - 2))
            return min(0.95, max(0.05, eq))

        # Postflop categories
        all_cards = (hole or []) + board
        cat, _ = evaluate_7card_category(all_cards)

        # Strong made hands
        if cat >= 7:  # quads or better
            return 0.99
        if cat == 6:  # full house
            return 0.95
        if cat == 5:  # flush
            return 0.88
        if cat == 4:  # straight
            return 0.85
        if cat == 3:  # trips
            return 0.80
        if cat == 2:  # two pair
            # Two pair is strong but vulnerable with more players
            n_players = max(2, len(self.players)) if self.players else 2
            adj = 0.75 - 0.03 * (n_players - 2)
            return max(0.60, adj)

        # One pair or high card: use draw/top pair heuristics
        flush_draw = has_flush_draw(all_cards, street)
        oesd = has_open_ended_straight_draw(all_cards, street)
        gutshot = has_gutshot_draw(all_cards, street)
        overpair = detect_overpair(hole, board)
        toppair = detect_top_pair(hole, board)
        overs = count_overcards(hole, board) if street == "Flop" else 0

        if cat == 1:  # One pair
            if overpair:
                return 0.65
            if toppair:
                # Kicker check
                other = [card_rank(c) for c in hole if card_rank(c) != max([card_rank(b) for b in board] or [0])]
                okicker = other[0] if other else 0
                if okicker >= 13:
                    return 0.58
                elif okicker >= 11:
                    return 0.52
                else:
                    return 0.46
            # Underpair
            return 0.32

        # High card with draws
        if flush_draw and oesd:
            return 0.48 if street == "Flop" else 0.30
        if flush_draw:
            return 0.36 if street == "Flop" else 0.20
        if oesd:
            return 0.32 if street == "Flop" else 0.16
        if gutshot:
            return 0.18 if street == "Flop" else 0.09
        if street == "Flop" and overs >= 2:
            return 0.24

        return 0.10

    def _strong_preflop_allin(self) -> bool:
        """Decide if we should shove preflop with premium hands."""
        hole = self.hole_cards or []
        if len(hole) != 2:
            return False
        r1, r2 = card_rank(hole[0]), card_rank(hole[1])
        s = (card_suit(hole[0]) == card_suit(hole[1]))
        # Pairs
        if r1 == r2 and r1 >= 12:  # QQ, KK, AA
            return True
        # AKs or AKo
        if set([r1, r2]) == set([14, 13]):
            return True
        # AQs suited only
        if s and set([r1, r2]) == set([14, 12]):
            return True
        return False

    def _value_shove_postflop(self, rs: RoundStateClient) -> bool:
        """Shove postflop with very strong made hands."""
        board = rs.community_cards or []
        hole = self.hole_cards or []
        all_cards = hole + board
        cat, _ = evaluate_7card_category(all_cards)
        if cat >= 6:  # full house or better
            return True
        if cat == 5:  # flush
            return True
        if cat == 4:  # straight
            # Be slightly cautious if board 4-straight; still shove for simplicity
            return True
        if cat == 3:  # trips
            # Trips good; shove if pot already non-trivial
            return True
        if cat == 2:  # two pair
            # Shove two pair if board not paired too dangerously (we ignore complexity -> still shove)
            return True
        return False

    def _safe_check(self, rs: RoundStateClient) -> bool:
        call_amt = self._amount_to_call(rs)
        return call_amt <= 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Basic derived values
            call_amount = self._amount_to_call(round_state)
            pot = max(0, round_state.pot or 0)
            street = round_state.round
            can_check = self._safe_check(round_state)

            # Equity and pot odds
            eq = self._estimate_equity(round_state)
            pot_odds = self._pot_odds(call_amount, pot)

            # Sanity clamps
            eq = max(0.0, min(0.999, eq))
            pot_odds = max(0.0, min(0.999, pot_odds))

            # Preflop decision
            if street == "Preflop":
                # Premium shove if no raise yet (or even against small raises)
                if can_check and self._strong_preflop_allin():
                    return (PokerAction.ALL_IN, 0)
                # If facing a bet:
                if call_amount > 0:
                    # If call is too big relative to equity, fold unless premium
                    if self._strong_preflop_allin():
                        # Over small stacks, just shove
                        return (PokerAction.ALL_IN, 0)
                    # Tight thresholds to avoid bleeding chips
                    # Call small raise with decent equity
                    small_raise = self.blind_amount * 3 if self.blind_amount else 20
                    medium_raise = self.blind_amount * 6 if self.blind_amount else 40
                    if call_amount <= small_raise and eq > max(0.50, pot_odds + 0.05):
                        return (PokerAction.CALL, 0)
                    if call_amount <= medium_raise and eq > max(0.60, pot_odds + 0.08):
                        return (PokerAction.CALL, 0)
                    # Otherwise fold
                    return (PokerAction.FOLD, 0)
                else:
                    # If no bet, just check preflop with most hands to avoid invalid raises
                    return (PokerAction.CHECK, 0)

            # Postflop decisions
            # Very strong made hands -> shove
            if self._value_shove_postflop(round_state):
                # If there's already a bet, we can shove over it; if not, we still shove for value
                return (PokerAction.ALL_IN, 0)

            # If we can check, prefer pot control
            if can_check:
                return (PokerAction.CHECK, 0)

            # Facing a bet: call/fold using equity vs pot odds
            # Add a small margin to avoid breakeven calls
            margin = 0.05
            if eq > pot_odds + margin:
                # If call requires all-in or near, just all-in
                if call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        except Exception:
            # Failsafe: don't crash; fold safely if something goes wrong
            if self._safe_check(round_state):
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # We can update any internal stats if desired; keep minimal to avoid memory
        self.last_round_seen = round_state.round if round_state else None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally, adjust RNG seed or parameters for future runs based on score
        # For now, keep deterministic behavior
        pass