from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Persistent game-level state
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []  # our private cards for the current hand
        self.last_round_num: int = -1
        self.random = random.Random(42)  # deterministic for reproducibility

        # Stats tracking for simple opponent modeling
        self.opponent_aggression: Dict[str, Dict[str, int]] = {}  # {player_id: {'raise': n, 'call': n, 'check': n, 'fold': n}}

        # Round-level flags
        self.street_bet_made: bool = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Treat on_start as "on new hand start" based on provided parameters
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Player hands is expected to be our private cards for this new hand
        self.hole_cards = player_hands[:] if player_hands else []
        # Reset street bet flag for new hand
        self.street_bet_made = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Called at start of each betting street (Preflop, Flop, Turn, River)
        # Reset street-level flags
        self.street_bet_made = False
        self.last_round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Safe accessors
            my_id_str = str(self.id) if self.id is not None else ""
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(round_state.current_bet or 0)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)  # remaining chips available to add
            pot = int(round_state.pot or 0)
            community_cards = round_state.community_cards[:] if round_state.community_cards else []
            call_needed = max(0, current_bet - my_bet)
            can_check = (call_needed == 0)

            # Defensive: if our remaining chips are 0 or negative, we can only check/fold
            if remaining_chips <= 0:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

            # Simple opponent modeling from current state actions
            if round_state.player_actions:
                for pid_str, action in round_state.player_actions.items():
                    if pid_str == my_id_str:
                        continue
                    stats = self.opponent_aggression.setdefault(pid_str, {'raise': 0, 'call': 0, 'check': 0, 'fold': 0})
                    a = action.lower()
                    if 'raise' in a:
                        stats['raise'] += 1
                    elif 'call' in a:
                        stats['call'] += 1
                    elif 'check' in a:
                        stats['check'] += 1
                    elif 'fold' in a:
                        stats['fold'] += 1

            stage = (round_state.round or '').lower()  # 'Preflop','Flop','Turn','River'
            num_active = len(round_state.current_player) if round_state.current_player else max(2, len(self.all_players) or 2)

            # Determine simple hand strength metrics
            has_cards = bool(self.hole_cards and len(self.hole_cards) == 2)
            preflop_score = self._evaluate_preflop_score(self.hole_cards) if has_cards else 10.0  # neutral if unknown
            postflop_category = self._evaluate_postflop_category(self.hole_cards, community_cards) if has_cards else 'unknown'

            # Strategic parameters
            eps = 1e-6
            # Pot odds helper
            def pot_odds_to_call(call_amt: int, cur_pot: int) -> float:
                return call_amt / max(cur_pot + call_amt + eps, 1.0)

            # Raise helper: return (can_raise, raise_amount_added)
            def plan_raise(target_extra_over_call: int) -> Tuple[bool, int]:
                # To raise legally, we must add at least call_needed + min_raise
                required = call_needed + max(min_raise, 1)
                desired = call_needed + max(target_extra_over_call, max(min_raise, 1))
                amount = max(required, desired)
                # Clamp to max_raise
                amount = min(amount, max_raise)
                if amount >= required and amount > 0:
                    return True, int(amount)
                return False, 0

            # Bet helper when no bet (i.e., can_check is True and current_bet == my_bet)
            def plan_bet(target_size: int) -> Tuple[bool, int]:
                # Betting is a raise when current_bet == my_bet == 0
                required = max(min_raise, 1)
                amount = max(required, min(target_size, max_raise))
                if amount >= required and amount > 0:
                    return True, int(amount)
                return False, 0

            # MAIN DECISION LOGIC
            # Preflop strategy
            if stage == 'preflop':
                # Heads-up tuned thresholds; loosen slightly heads-up, tighten multiway
                multiway_factor = 0.0 if num_active <= 2 else 2.0
                strong_thr = 17.0 + multiway_factor
                raise_thr = 14.0 + multiway_factor
                call_thr = 11.5 + multiway_factor

                # Facing bet (open or raise)
                if not can_check:
                    # Very strong hands: 3-bet
                    if preflop_score >= strong_thr and max_raise > 0 and min_raise > 0:
                        # Aim for ~2x the current bet over the call (aggressive but within no-limit constraints)
                        target_extra = max(current_bet, min_raise)
                        can_r, amount = plan_raise(target_extra_over_call=target_extra)
                        if can_r:
                            self.street_bet_made = True
                            return PokerAction.RAISE, amount
                        # If can't raise, just call
                        if remaining_chips >= call_needed:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0
                    # Medium hands: call if pot odds reasonable or cost small
                    elif preflop_score >= call_thr:
                        # Defend especially if cost is small relative to pot
                        if call_needed <= max(self.blind_amount * 2, int(0.25 * max(pot, 1))):
                            return PokerAction.CALL, 0
                        else:
                            # If too expensive and not premium, fold
                            return PokerAction.FOLD, 0
                    else:
                        # Occasional light defend in BB if call is very cheap
                        if my_bet >= current_bet and can_check:
                            return PokerAction.CHECK, 0
                        # If very small call (min-raise) and heads-up, defend with some frequency
                        if num_active <= 2 and call_needed <= max(self.blind_amount, 20) and self.random.random() < 0.25:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                else:
                    # Nobody has bet yet (we can check).
                    # As SB first-to-act preflop, call_needed usually > 0; if we can check we're likely BB.
                    # In BB, check most, raise with strong
                    if preflop_score >= strong_thr and max_raise > 0 and min_raise > 0:
                        # Open-raise size: about 2x big blind equivalent (use current_bet as proxy for BB if > 0)
                        open_size = max(current_bet, self.blind_amount if self.blind_amount > 0 else min_raise)
                        can_r, amount = plan_bet(target_size=open_size)
                        if can_r:
                            self.street_bet_made = True
                            return PokerAction.RAISE, amount
                    # Occasionally stab with mediocre hand heads-up
                    if num_active <= 2 and preflop_score >= raise_thr and self.random.random() < 0.35 and max_raise > 0 and min_raise > 0:
                        stab_size = max(current_bet, self.blind_amount if self.blind_amount > 0 else min_raise)
                        can_r, amount = plan_bet(target_size=stab_size)
                        if can_r:
                            self.street_bet_made = True
                            return PokerAction.RAISE, amount
                    return PokerAction.CHECK, 0

            # Postflop strategy
            # Categorize equity proxies
            strong = (postflop_category in ('two_pair_plus', 'overpair', 'top_pair_strong', 'trips_plus', 'straight_plus', 'flush_plus'))
            medium = (postflop_category in ('second_pair', 'top_pair_weak', 'pair'))
            draw = (postflop_category in ('flush_draw', 'oesd', 'combo_draw'))

            # Compute basic pot odds
            p_odds = pot_odds_to_call(call_needed, pot)

            # Estimate equity heuristically
            equity = 0.5  # neutral fallback
            if strong:
                equity = 0.75
            elif postflop_category == 'top_pair_strong':
                equity = 0.65
            elif postflop_category == 'top_pair_weak':
                equity = 0.55
            elif postflop_category == 'overpair':
                equity = 0.70
            elif postflop_category in ('two_pair_plus', 'trips_plus', 'straight_plus', 'flush_plus'):
                equity = 0.80
            elif postflop_category == 'second_pair':
                equity = 0.40
            elif postflop_category == 'pair':
                equity = 0.33
            elif postflop_category == 'flush_draw':
                # ~35% on flop, ~19% on turn
                equity = 0.35 if len(community_cards) == 3 else 0.19
            elif postflop_category == 'oesd':
                equity = 0.32 if len(community_cards) == 3 else 0.17
            elif postflop_category == 'combo_draw':
                equity = 0.45 if len(community_cards) == 3 else 0.25
            else:
                equity = 0.25  # unknown/weak

            # If no bet yet (we can check)
            if can_check:
                # Value bet with strong hands
                if strong:
                    target = int(0.6 * max(pot, 1))
                    target = max(target, min_raise if min_raise > 0 else 1)
                    can_r, amount = plan_bet(target_size=target)
                    if can_r:
                        self.street_bet_made = True
                        return PokerAction.RAISE, amount
                    # If cannot bet due to stack/min raise, just check
                    return PokerAction.CHECK, 0
                # Semi-bluff draws sometimes
                if draw and self.random.random() < 0.35 and max_raise > 0 and min_raise > 0:
                    target = int(0.5 * max(pot, 1))
                    target = max(target, min_raise if min_raise > 0 else 1)
                    can_r, amount = plan_bet(target_size=target)
                    if can_r:
                        self.street_bet_made = True
                        return PokerAction.RAISE, amount
                    return PokerAction.CHECK, 0
                # Medium/weak: check back
                return PokerAction.CHECK, 0
            else:
                # Facing a bet
                # If strong: raise or call depending on sizing
                if strong:
                    # If bet is small relative to pot, raise for value; otherwise call
                    if call_needed <= int(0.5 * max(pot, 1)) and min_raise > 0:
                        target_extra = max(int(0.75 * max(pot, 1)), min_raise)
                        can_r, amount = plan_raise(target_extra_over_call=target_extra)
                        if can_r:
                            self.street_bet_made = True
                            return PokerAction.RAISE, amount
                        # If can't raise, just call
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CALL, 0

                # Draws: call with correct pot odds, sometimes semi-bluff raise if cheap
                if draw:
                    if p_odds <= (equity + 0.05):  # slight threshold cushion
                        return PokerAction.CALL, 0
                    # Consider semi-bluff raise if bet small and we have fold equity
                    if call_needed <= int(0.3 * max(pot, 1)) and min_raise > 0 and self.random.random() < 0.25:
                        target_extra = max(int(0.6 * max(pot, 1)), min_raise)
                        can_r, amount = plan_raise(target_extra_over_call=target_extra)
                        if can_r:
                            self.street_bet_made = True
                            return PokerAction.RAISE, amount
                    # Otherwise fold
                    return PokerAction.FOLD, 0

                # Medium hands: call small bets, fold to large bets
                if medium:
                    # Threshold based on pot odds and equity guess
                    if p_odds <= (equity + 0.03):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Weak hands: mostly fold, occasionally bluff raise if very cheap and heads-up
                if num_active <= 2 and call_needed <= max(self.blind_amount, 20) and self.random.random() < 0.10 and min_raise > 0:
                    target_extra = max(int(0.5 * max(pot, 1)), min_raise)
                    can_r, amount = plan_raise(target_extra_over_call=target_extra)
                    if can_r:
                        self.street_bet_made = True
                        return PokerAction.RAISE, amount
                # Otherwise fold; if call is free (shouldn't be here), check
                return PokerAction.FOLD, 0

        except Exception:
            # Fail-safe: never crash. If we can check, check; otherwise fold.
            my_bet = 0
            current_bet = 0
            try:
                my_bet = int(round_state.player_bets.get(str(self.id), 0)) if round_state.player_bets else 0
                current_bet = int(round_state.current_bet or 0)
            except Exception:
                pass
            if current_bet - my_bet <= 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # No special teardown needed; could track results or reset state if necessary
        self.street_bet_made = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could log or adjust strategy parameters here
        pass

    # ----------------- Helper Evaluation Methods -----------------

    def _rank_value(self, card: str) -> int:
        if not card:
            return 0
        r = card[0]
        return RANK_ORDER.get(r, 0)

    def _suit_value(self, card: str) -> str:
        if not card:
            return ''
        return card[-1]

    def _evaluate_preflop_score(self, hole_cards: List[str]) -> float:
        # Simple heuristic scoring inspired by Chen-like features
        if not hole_cards or len(hole_cards) != 2:
            return 10.0
        c1, c2 = hole_cards[0], hole_cards[1]
        r1, r2 = self._rank_value(c1), self._rank_value(c2)
        s1, s2 = self._suit_value(c1), self._suit_value(c2)
        high = max(r1, r2)
        low = min(r1, r2)
        pair = (r1 == r2)
        suited = (s1 == s2)
        gap = abs(r1 - r2) - 1

        score = 0.0
        if pair:
            # Base for pairs
            score = 12.0 + (high - 8) * 1.5  # 22 ~ 0, 88 ~ 12, AA ~ > 18
        else:
            # High card strength
            score += (high - 8) * 1.3  # high cards valued
            score += max(low - 6, 0) * 0.8
            # Suited bonus
            if suited:
                score += 2.0
            # Connectivity
            if gap <= 0:
                score += 2.0
            elif gap == 1:
                score += 1.5
            elif gap == 2:
                score += 0.8
            # Ace-x bonus
            if r1 == 14 or r2 == 14:
                score += 1.0

        # Clamp
        score = max(0.0, min(score, 25.0))
        return score

    def _evaluate_postflop_category(self, hole_cards: List[str], board: List[str]) -> str:
        # Returns one of: 'two_pair_plus','trips_plus','straight_plus','flush_plus',
        # 'overpair','top_pair_strong','top_pair_weak','second_pair','pair',
        # 'flush_draw','oesd','combo_draw','unknown'
        if not hole_cards or len(hole_cards) != 2:
            return 'unknown'
        c1, c2 = hole_cards
        ranks_all = [self._rank_value(c) for c in (hole_cards + board)]
        suits_all = [self._suit_value(c) for c in (hole_cards + board)]
        ranks_board = [self._rank_value(c) for c in board]
        suits_board = [self._suit_value(c) for c in board]
        r1, r2 = self._rank_value(c1), self._rank_value(c2)
        s1, s2 = self._suit_value(c1), self._suit_value(c2)
        highest_board = max(ranks_board) if ranks_board else 0

        # Counts
        from collections import Counter
        rank_counts_all = Counter(ranks_all)
        rank_counts_board = Counter(ranks_board)
        suit_counts_all = Counter(suits_all)
        suit_counts_board = Counter(suits_board)

        # Made hands:
        # Trips or better uses all 7 cards counts
        if any(cnt >= 3 for cnt in rank_counts_all.values()):
            # Determine if it's trips+ with our involvement
            # If we have pocket pair and a board match => set/trips
            if r1 == r2 and rank_counts_all.get(r1, 0) >= 3:
                # Overpair that improved to set is strong
                return 'trips_plus'
            # If one of our hole ranks makes trips with board
            if rank_counts_board.get(r1, 0) + 1 >= 3 or rank_counts_board.get(r2, 0) + 1 >= 3:
                return 'trips_plus'

        # Two pair: if our two distinct ranks pair with board
        our_pair = (r1 == r2)
        pair_r1 = rank_counts_board.get(r1, 0) >= 1
        pair_r2 = rank_counts_board.get(r2, 0) >= 1
        if our_pair and rank_counts_board.get(r1, 0) >= 1:
            return 'two_pair_plus'
        if pair_r1 and pair_r2 and r1 != r2:
            return 'two_pair_plus'

        # Overpair: pocket pair higher than all board ranks
        if our_pair and (r1 > highest_board > 0):
            return 'overpair'

        # Top pair and second pair:
        if len(board) >= 3:
            top_board = highest_board
            # Do we pair the board?
            pair_with_board = (rank_counts_board.get(r1, 0) >= 1) or (rank_counts_board.get(r2, 0) >= 1)
            if pair_with_board:
                paired_rank = r1 if rank_counts_board.get(r1, 0) >= 1 else r2
                # Kicker quality
                other_rank = r2 if paired_rank == r1 else r1
                if paired_rank == top_board:
                    if other_rank >= 12:  # good kicker
                        return 'top_pair_strong'
                    else:
                        return 'top_pair_weak'
                else:
                    return 'second_pair'
            # Naked pocket pair below top board can still be 'pair'
            if our_pair:
                return 'pair'

        # Flush or Straight made:
        if any(cnt >= 5 for cnt in suit_counts_all.values()):
            return 'flush_plus'
        if self._has_straight(ranks_all):
            return 'straight_plus'

        # Draws (on flop/turn only):
        if len(board) in (3, 4):
            # Flush draw (4 to a flush with at least one of our hole cards contributing)
            for suit, cnt in suit_counts_all.items():
                if cnt == 4 and (s1 == suit or s2 == suit):
                    # If also have straight draw, combo draw
                    if self._has_oesd(hole_cards, board):
                        return 'combo_draw'
                    return 'flush_draw'
            if self._has_oesd(hole_cards, board):
                return 'oesd'

        # Weak/no made hand
        if our_pair:
            return 'pair'

        return 'unknown'

    def _has_straight(self, ranks_all: List[int]) -> bool:
        if not ranks_all:
            return False
        uniq = set(ranks_all)
        # Ace can be low straight (A-2-3-4-5)
        if 14 in uniq:
            uniq.add(1)
        for start in range(1, 11):
            if all((start + i) in uniq for i in range(5)):
                return True
        return False

    def _has_oesd(self, hole_cards: List[str], board: List[str]) -> bool:
        # Simple OESD detection: 4 consecutive ranks present among combined with at least one from hole
        ranks_all = [self._rank_value(c) for c in (hole_cards + board)]
        uniq = set(ranks_all)
        if 14 in uniq:
            uniq |= {1}  # Ace low
        hole_ranks = set(self._rank_value(c) for c in hole_cards)
        if 14 in hole_ranks:
            hole_ranks |= {1}
        for start in range(1, 11):
            seq = {start, start + 1, start + 2, start + 3}
            if seq.issubset(uniq) and (seq & hole_ranks):
                # Exclude cases where straight already made (5 in a row)
                if not all((start + i) in uniq for i in range(5)):
                    return True
        return False