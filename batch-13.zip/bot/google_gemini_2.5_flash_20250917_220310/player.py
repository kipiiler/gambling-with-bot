import collections
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.player_id: int = -1 # Initialize with an invalid ID
        self.num_players: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands # This is for the first hand, updated in on_round_start
        self.num_players = len(all_players)
        # self.player_id is set by the framework
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the new round
        # The framework passes player_hands in `on_start` for the *first* hand.
        # For subsequent hands, `on_round_start` doesn't provide hole cards directly,
        # but a real poker client would know its own hole cards.
        # For this contest, assume the `on_start`'s player_hands is the reference for the current round.
        # If not, this is a limitation due to the interface design.
        # However, for the scope of the problem, we will just use the `on_start` assigned values.
        # The competition framework might pass specific hole cards to subsequent hands to the bot
        # but the current `on_round_start` signature doesn't allow it.
        # If this causes an error, it implies that player_hands should be handled differently,
        # e.g., if get_action is called before on_round_start with new cards,
        # or if `on_round_start` is meant to reset player-specific state except `hole_cards`.
        # Assuming `on_start` hole cards are for the first round, and `get_action` needs them.

        # For the purpose of the competition, let's assume `hole_cards` is correctly managed externally
        # or that on_round_start doesn't explicitly update them if the framework handles it.
        # If the error is that `self.hole_cards` becomes outdated, the API needs to provide player_hands
        # in either on_round_start or get_action.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Error fix: Type Error: `hole_cards` is `List[str]`, `community_cards` is `List[str]`.
        # `_calculate_hand_strength` expects `List[str]` for both.
        # Original error: `TypeError: can only concatenate str (not "list") to str`
        # This implies that `self.hole_cards` was a string, not a list of strings, or
        # community_cards was a string.
        # Verify `self.hole_cards` is indeed a list of strings.
        # If the problem is in `on_start` -> `self.hole_cards = player_hands`,
        # then `player_hands` must be a list of strings. The type hint suggests it is.
        # The error suggests implicit conversion or wrong data type being passed.
        # Let's ensure `_calculate_hand_strength` concatenates lists correctly.

        # Ensure hole_cards exist before proceeding
        if not self.hole_cards:
            # This should ideally not happen if on_start is called correctly.
            # Fallback to a safe action.
            if current_bet_to_call > 0:
                if remaining_chips > current_bet_to_call:
                    return PokerAction.FOLD, 0
                else: # cannot call due to not enough chips
                    return PokerAction.ALL_IN, 0
            else:
                return PokerAction.CHECK, 0

        hand_strength_val = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Simple strategy based on hand strength and round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(hand_strength_val, round_state, remaining_chips, current_bet_to_call)
        elif round_state.round == 'Flop':
            return self._postflop_strategy(hand_strength_val, round_state, remaining_chips, current_bet_to_call, 0.7) # Aggressive factor
        elif round_state.round == 'Turn':
            return self._postflop_strategy(hand_strength_val, round_state, remaining_chips, current_bet_to_call, 0.8) # More aggressive
        elif round_state.round == 'River':
            return self._postflop_strategy(hand_strength_val, round_state, remaining_chips, current_bet_to_call, 0.9) # Most aggressive
        
        # Default fallback
        if current_bet_to_call == 0:
            return PokerAction.CHECK, 0
        elif current_bet_to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0
        else:
            return PokerAction.FOLD, 0

    def _preflop_strategy(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, current_bet_to_call: int) -> Tuple[PokerAction, int]:
        # Looser calling range for smaller blinds
        if hand_strength > 0.85: # Premium hands (AA, KK, AKs, QQ)
            if remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            # Aggressive raise
            raise_amount = min(round_state.max_raise, max(round_state.min_raise, self._calculate_raise_amount(remaining_chips, 0.75)))
            if raise_amount > current_bet_to_call * 2 + round_state.min_raise / 2 + 1: # ensure substantial raise
                 return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0 # if we can't make a meaningful raise, just call, or go all-in

        elif hand_strength > 0.70: # Strong hands (JJ, TT, AQs, KQs, etc.)
            if current_bet_to_call == 0:
                # Raise 3x blind or min_raise
                raise_amount = min(round_state.max_raise, max(round_state.min_raise, self.blind_amount * 3))
                return PokerAction.RAISE, raise_amount
            elif current_bet_to_call <= remaining_chips / 4: # Relatively cheap call
                return PokerAction.CALL, 0
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        elif hand_strength > 0.50: # Medium hands (small pairs, suited connectors)
            if current_bet_to_call == 0:
                return PokerAction.CHECK, 0
            elif current_bet_to_call < self.blind_amount * 2 and remaining_chips > current_bet_to_call: # Call small raises
                return PokerAction.CALL, 0
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        else: # Weak hands
            if current_bet_to_call == 0:
                return PokerAction.CHECK, 0
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0 # Go all-in if can't fold and no other option
            else:
                return PokerAction.FOLD, 0

    def _postflop_strategy(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, current_bet_to_call: int, aggression_factor: float) -> Tuple[PokerAction, int]:
        if hand_strength > 0.8: # Very strong hand (e.g., set, two pair high, flush draw, straight draw)
            if remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            
            # Check for a "value bet" threshold, e.g. min_raise vs current bet
            # If current bet is 0, we can bet. If someone else bet, we can raise.
            if current_bet_to_call == 0:
                bet_amount = min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * aggression_factor)))
                return PokerAction.RAISE, bet_amount # Using RAISE for betting when current_bet is 0
            else:
                # If there's a bet, raise
                if round_state.max_raise > round_state.min_raise and remaining_chips > current_bet_to_call + round_state.min_raise:
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(current_bet_to_call * (1 + aggression_factor))))
                    return PokerAction.RAISE, raise_amount
                else: # Cannot raise meaningfully, just call
                    return PokerAction.CALL, 0


        elif hand_strength > 0.6: # Strong holdings (e.g., top pair, good draws)
            if current_bet_to_call == 0:
                # Check or small bet
                if remaining_chips <= current_bet_to_call:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CHECK, 0 # Check with good but not nut hand
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            elif current_bet_to_call < remaining_chips / 3: # Call moderate bets
                return PokerAction.CALL, 0
            else: # Large bet, consider folding
                return PokerAction.FOLD, 0
            
        elif hand_strength > 0.4: # Marginal hands (e.g., middle pair, weak draws)
            if current_bet_to_call == 0:
                return PokerAction.CHECK, 0
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            elif current_bet_to_call < self.blind_amount * 2: # Call small bets
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else: # Weak hands
            if current_bet_to_call == 0:
                return PokerAction.CHECK, 0
            elif remaining_chips <= current_bet_to_call:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = [] 
        # Any other per-round cleanup can go here.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game has ended, no specific action needed for playing, but can be used for logging/analysis
        pass

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Calculates a numerical strength score for the given hand.
        This is a very simplified hand evaluator. A real bot would use a more robust library
        or a Monte Carlo simulation.
        
        Returns a float between 0.0 and 1.0, where 1.0 is the strongest.
        """
        all_cards = hole_cards + community_cards

        # The error `TypeError: can only concatenate str (not "list") to str`
        # likely means `hole_cards` or `community_cards` was a string.
        # But `all_cards = hole_cards + community_cards` should correctly concatenate two lists.
        # Let's ensure the inputs are always lists of strings to avoid this specific error.
        
        # If there are fewer than 5 cards, it's pre-flop or early flop, hand strength is based purely on hole cards
        if len(all_cards) < 5:
            return self._evaluate_hole_cards(hole_cards)
        
        # Simplified hand evaluation logic. This needs to be more robust for real poker.
        # For now, it will check for pairs, straights, flushes etc.
        
        # Extract ranks and suits
        ranks = [self._card_rank_to_int(card[0]) for card in all_cards]
        suits = [card[-1] for card in all_cards]

        # Count frequencies
        rank_counts = collections.Counter(ranks)
        suit_counts = collections.Counter(suits)

        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        sorted_ranks = sorted(list(set(ranks))) # Unique sorted ranks
        is_straight = False
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    is_straight = True
                    break
            # Check for A-5 straight (Ace low)
            if not is_straight and set([14, 2, 3, 4, 5]).issubset(set(ranks)): # Ace is 14, or 1 for A-5
                is_straight = True


        # Check for pairs, three of a kind, four of a kind
        pairs = 0
        three_of_a_kind = 0
        four_of_a_kind = 0
        for rank, count in rank_counts.items():
            if count == 4:
                four_of_a_kind += 1
            elif count == 3:
                three_of_a_kind += 1
            elif count == 2:
                pairs += 1

        # Assign a simple strength score
        if is_flush and is_straight:
            return 0.95 # Straight Flush (Royal Flush is just a high straight flush)
        if four_of_a_kind:
            return 0.90 # Four of a kind
        if three_of_a_kind and pairs:
            return 0.85 # Full House
        if is_flush:
            return 0.80 # Flush
        if is_straight:
            return 0.75 # Straight
        if three_of_a_kind:
            return 0.70 # Three of a kind
        if pairs >= 2:
            return 0.60 # Two Pair
        if pairs == 1:
            return 0.50 # One Pair
        
        # High card strength (simple 0.0-0.4 based on highest card)
        highest_rank = max(ranks) if ranks else 0
        return 0.1 + (highest_rank / 14.0) * 0.3 # Scale high card between 0.1 and 0.4
    
    def _evaluate_hole_cards(self, hole_cards: List[str]) -> float:
        """
        Evaluates the strength of starting two-card hands.
        This provides a rough pre-flop strength based on common poker wisdom.
        """
        if not hole_cards or len(hole_cards) != 2:
            return 0.0 # Should not happen

        r1_char = hole_cards[0][0]
        r2_char = hole_cards[1][0]
        s1 = hole_cards[0][-1]
        s2 = hole_cards[1][-1]

        r1 = self._card_rank_to_int(r1_char)
        r2 = self._card_rank_to_int(r2_char)

        is_suited = (s1 == s2)
        is_pair = (r1 == r2)

        # Assign scores based on general pre-flop hand rankings
        if is_pair:
            if r1 >= 14: return 0.9 # AA
            if r1 == 13: return 0.85 # KK
            if r1 == 12: return 0.8 # QQ
            if r1 == 11: return 0.7 # JJ
            if r1 == 10: return 0.65 # TT
            if r1 >= 8: return 0.6 # 88-99
            return 0.5 # Small pairs
        
        if r1 < r2: r1, r2 = r2, r1 # Ensure r1 is the higher rank

        if r1 == 14: # Ace high hands
            if r2 == 13: return 0.8 if is_suited else 0.75 # AK
            if r2 == 12: return 0.7 if is_suited else 0.65 # AQ
            if r2 == 11: return 0.6 if is_suited else 0.55 # AJ
            if r2 >= 10: return 0.55 if is_suited else 0.5 # A10
            return 0.4 if is_suited else 0.35 # Ax suited
        
        if r1 == 13: # King high hands
            if r2 == 12: return 0.6 if is_suited else 0.55 # KQ
            if r2 == 11: return 0.55 if is_suited else 0.5 # KJ
            if r2 >= 10: return 0.5 if is_suited else 0.45 # K10
            return 0.3 # Kx suited
        
        if r1 == 12: # Queen high hands
            if r2 == 11: return 0.5 if is_suited else 0.45 # QJ
            if r2 >= 10: return 0.45 if is_suited else 0.4 # Q10
        
        if r1 == 11 and r2 == 10: # Jack-Ten
            return 0.4 if is_suited else 0.35

        # Suited connectors
        if is_suited and r1 - r2 <= 2 and r1 <= 10 and r1 >= 7: # 78s, 89s, 9Ts, TJs
            return 0.4
        
        return 0.25 # Default for weak hands
        

    def _card_rank_to_int(self, rank_char: str) -> int:
        """Converts card rank character to integer (2-14 for A)"""
        if '2' <= rank_char <= '9':
            return int(rank_char)
        elif rank_char == 'T':
            return 10
        elif rank_char == 'J':
            return 11
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'K':
            return 13
        elif rank_char == 'A':
            return 14
        return 0 # Should not happen

    def _calculate_raise_amount(self, current_stack: int, fraction_of_pot: float) -> int:
        """
        Calculates a raise amount, aiming for a fraction of the pot or a standard bet.
        """
        # A simple strategy for now. Could be improved significantly.
        # This function might not be directly used as `round_state.min_raise` and `max_raise` are provided.
        # However, it helps in deciding the *magnitude* of the raise.
        
        # For simplicity, let's assume a pot-sized bet logic for now.
        # In a real scenario, this would be based on the actual pot size and position.
        
        # A common raise in NLHE is 2-3x the current bet, or a fixed amount.
        # Since this is a helper, return a reasonable raise quantity.
        
        # Let's return a default value that can be overridden by min/max_raise limits later.
        
        # Example: 3x the big blind, or 2/3 pot on later streets.
        
        # Ensure non-zero divisor
        if fraction_of_pot <= 0:
            fraction_of_pot = 0.5 # Default to half pot
            
        return int(current_stack * fraction_of_pot) # Simple: raise by a fraction of own chips (aggressive)