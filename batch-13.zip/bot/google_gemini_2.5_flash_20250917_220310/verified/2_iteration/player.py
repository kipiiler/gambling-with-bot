from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {int(p_id): hand for p_id, hand in zip(all_players, player_hands)}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hole_cards = player_hands[all_players.index(self.id)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the current round
        self.hole_cards = self.player_hands.get(self.id, [])

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise if round_state.min_raise > 0 else current_bet * 2
        max_raise = round_state.max_raise
        my_current_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        
        call_amount = current_bet - my_current_bet_in_round

        # Calculate strength of hand
        hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Determine number of active players
        active_players_count = sum(1 for p_id in round_state.current_player if round_state.player_bets.get(str(p_id), 0) < remaining_chips)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Aggressive play with strong hands
            if hand_strength >= 8:  # Premium hands (AA, KK, QQ, AKs)
                if call_amount == 0:
                    return PokerAction.RAISE, min(max(min_raise, self.blind_amount * 4), max_raise)
                else:
                    return PokerAction.RAISE, min(max(min_raise, call_amount + self.blind_amount * 3), max_raise)
            # Moderate play with good hands (JJ, TT, AQs, KQs, suited connectors)
            elif hand_strength >= 6:
                if current_bet == 0:
                    return PokerAction.RAISE, min(max(min_raise, self.blind_amount * 3), max_raise)
                elif call_amount <= remaining_chips * 0.15:  # Call if not too expensive
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Speculative play with decent hands
            elif hand_strength >= 3:
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                elif call_amount <= remaining_chips * 0.05: # Call small bets to see flop
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Fold weak hands
            else:
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength >= 10:  # Very strong hand (e.g., straight, flush, full house, quads)
                if current_bet == 0:
                    return PokerAction.RAISE, min(max(min_raise, int(round_state.pot * 0.75)), max_raise)
                else:
                    return PokerAction.RAISE, min(max(min_raise, call_amount + int(round_state.pot * 0.5)), max_raise)
            elif hand_strength >= 7:  # Strong hand (e.g., two pair, strong top pair)
                if current_bet == 0:
                    return PokerAction.RAISE, min(max(min_raise, int(round_state.pot * 0.5)), max_raise)
                elif call_amount <= remaining_chips * 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength >= 4: # Medium hand (e.g., middle pair, strong draw)
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                elif call_amount <= remaining_chips * 0.15:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    if call_amount > 0 and remaining_chips < call_amount:
                        return PokerAction.ALL_IN, 0 # All-in if can't call otherwise
                    return PokerAction.FOLD, 0

        # Default action
        if current_bet == 0:
            return PokerAction.CHECK, 0
        else:
            if call_amount >= remaining_chips: # If call amount is effectively an all-in
                return PokerAction.ALL_IN, 0
            if call_amount > 0 and call_amount < remaining_chips:
                # If the bet is a small fraction of remaining chips, call
                if call_amount <= remaining_chips * 0.10: # Tolerate 10% of stack for calling
                    return PokerAction.CALL, 0
                # If we have a slight edge or are close to a good hand, consider calling more
                elif hand_strength >= 5 and call_amount <= remaining_chips * 0.25: # With medium strength, call up to 25% of stack
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0 # Should not happen, but as a fallback
        

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> int:
        # Assign numerical values to cards
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Combine hole cards and community cards
        all_cards = hole_cards + community_cards
        
        # Parse cards into (rank, suit) tuples
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) == 2:
                rank = card_str[0]
                suit = card_str[1]
            else: # Handle '10' rank
                rank = 'T'
                suit = card_str[2]
            parsed_cards.append((rank_values[rank], suit))

        if len(parsed_cards) < 2:
            return 0 # Not enough cards to form a hand

        # Initial pre-flop strength
        if len(community_cards) == 0:
            rank1, suit1 = parsed_cards[0]
            rank2, suit2 = parsed_cards[1]
            
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= rank_values['A']: return 10 # AA
                if rank1 >= rank_values['K']: return 9  # KK
                if rank1 >= rank_values['Q']: return 8  # QQ
                if rank1 >= rank_values['J']: return 7  # JJ
                if rank1 >= rank_values['T']: return 6  # TT
                return 5 # 99-22
            
            # Suited connectors/high cards
            if suit1 == suit2: # Suited
                if rank1 >= rank_values['A'] and rank2 >= rank_values['K'] or rank2 >= rank_values['A'] and rank1 >= rank_values['K']: return 9 # AKs
                if rank1 >= rank_values['A'] and rank2 >= rank_values['Q'] or rank2 >= rank_values['A'] and rank1 >= rank_values['Q']: return 8 # AQs
                if rank1 >= rank_values['K'] and rank2 >= rank_values['Q'] or rank2 >= rank_values['K'] and rank1 >= rank_values['Q']: return 7 # KQs
                if abs(rank1 - rank2) == 1 and max(rank1, rank2) >= rank_values['T']: return 6 # Suited connectors T9s+
                return 4 # Other suited
            
            # Off-suit high cards
            if rank1 >= rank_values['A'] and rank2 >= rank_values['K'] or rank2 >= rank_values['A'] and rank1 >= rank_values['K']: return 8 # AKo
            if max(rank1, rank2) >= rank_values['A'] and min(rank1, rank2) >= rank_values['T']: return 5 # AT+ offsuit
            if max(rank1, rank2) >= rank_values['K'] and min(rank1, rank2) >= rank_values['J']: return 5 # KJ+ offsuit
            if max(rank1, rank2) >= rank_values['Q'] and min(rank1, rank2) >= rank_values['J']: return 4 # QJ+ offsuit

            # Connected cards
            if abs(rank1 - rank2) <= 2 and max(rank1, rank2) >= rank_values['T']: return 4 # Connected cards
            
            return 1 # Weak hands

        # Evaluate the best 5-card hand using combinations
        best_hand_rank = 0
        
        import itertools
        
        # Helper to convert rank to a comparable value, A high = 14, A low = 1
        def get_rank_val(rank_char):
            if rank_char == 'A': return 14
            if rank_char == 'K': return 13
            if rank_char == 'Q': return 12
            if rank_char == 'J': return 11
            if rank_char == 'T': return 10
            return int(rank_char)

        def get_hand_rank(five_cards):
            ranks = sorted([get_rank_val(c[0]) for c in five_cards], reverse=True)
            suits = [c[1] for c in five_cards]

            is_flush = len(set(suits)) == 1
            is_straight = all(ranks[i] == ranks[i+1] + 1 for i in range(4)) or \
                          (set(ranks) == {14, 5, 4, 3, 2} and len(set(ranks)) == 5) # A-5 straight

            rank_counts = {rank: ranks.count(rank) for rank in ranks}
            counts_list = sorted(list(rank_counts.values()), reverse=True)

            if is_straight and is_flush:
                if ranks == [14, 13, 12, 11, 10]: return 9 # Royal Flush
                return 8 # Straight Flush
            if counts_list == [4, 1]: return 7 # Four of a Kind
            if counts_list == [3, 2]: return 6 # Full House
            if is_flush: return 5 # Flush
            if is_straight: return 4 # Straight
            if counts_list == [3, 1, 1]: return 3 # Three of a Kind
            if counts_list == [2, 2, 1]: return 2 # Two Pair
            if counts_list == [2, 1, 1, 1]: return 1 # One Pair
            return 0 # High Card (using ranks[0] as tie-breaker, not implemented fully in strength calculation)

        # Generate all 5-card combinations
        # We need to consider both hole cards and community cards properly.
        # This part of the logic needs to ensure the right card format is passed to get_hand_rank
        
        flat_cards = []
        for card_str in hole_cards:
            flat_cards.append((card_str[0], card_str[1])) if len(card_str) == 2 else flat_cards.append(('T', card_str[2]))
        for card_str in community_cards:
            flat_cards.append((card_str[0], card_str[1])) if len(card_str) == 2 else flat_cards.append(('T', card_str[2]))

        if len(flat_cards) >= 5:
            for hand_combination in itertools.combinations(flat_cards, 5):
                best_hand_rank = max(best_hand_rank, get_hand_rank(list(hand_combination)))
        elif len(flat_cards) >= 2: # Pre-flop or less than 5 community cards
            # For now, if not enough cards for 5, rely on initial pre-flop strength
            # The hand_strength for post-flop should be based on actual poker hand ranks
            if current_bet == 0: # This is a quick fix, needs robust hand evaluation
                if self._get_pair_rank(hole_cards) > 0 and len(community_cards) == 0:
                    return 5 + self._get_pair_rank(hole_cards) # A pair could be a good start
                return self._evaluate_high_card(hole_cards) # Evaluate based on high cards
            # This logic needs to be enhanced with full poker hand evaluation

        # Simple post-flop strength based on initial pre-flop evaluation for now
        # This needs a proper 5-card evaluation logic.
        # For simplicity, if we have a pair from hole cards and it's on board, it's stronger
        
        # Consider making this more robust by actually evaluating the best 5-card poker hand using community cards
        # For now, a simplified evaluation if no full 5-card hand can be formed or is not yet evaluated properly.
        
        # If no community cards, return pre-flop strength
        if len(community_cards) == 0:
            return self._preflop_hand_strength(hole_cards)
        
        # A very basic post-flop check for pair with hole cards and one community card.
        # This is temporary and needs a proper library like pokerkit or manually implement hand ranking.
        ranks_in_play = [get_rank_val(c[0]) for c in flat_cards]
        hole_ranks = [get_rank_val(c[0][0]) if len(c[0]) == 2 else get_rank_val('T') for c in hole_cards]

        # Check for any pair
        rank_counts = {}
        for rank in ranks_in_play:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        if 4 in rank_counts.values(): return 10 # Four of a Kind
        if 3 in rank_counts.values() and 2 in rank_counts.values(): return 9 # Full House
        if 3 in rank_counts.values(): return 8 # Three of a Kind
        if list(rank_counts.values()).count(2) >= 2: return 7 # Two Pair
        if 2 in rank_counts.values(): return 6 # One Pair

        # Check for flush draw - if 4 of the same suit exist
        suit_counts = {}
        for _, suit in flat_cards:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        if 4 in suit_counts.values(): return 5 # Flush Draw

        # Check for straight draw - if sequence of 4 cards exist
        sorted_ranks_unique = sorted(list(set(ranks_in_play)))
        for i in range(len(sorted_ranks_unique) - 3):
            if sorted_ranks_unique[i+3] - sorted_ranks_unique[i] == 3:
                return 4 # Straight Draw

        # High card
        return max(hole_ranks) / 14 * 3 # Scale high card strength

    def _preflop_hand_strength(self, hole_cards: List[str]) -> int:
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        c1_rank = rank_values[hole_cards[0][0]] if len(hole_cards[0]) == 2 else rank_values['T']
        c1_suit = hole_cards[0][1] if len(hole_cards[0]) == 2 else hole_cards[0][2]
        c2_rank = rank_values[hole_cards[1][0]] if len(hole_cards[1]) == 2 else rank_values['T']
        c2_suit = hole_cards[1][1] if len(hole_cards[1]) == 2 else hole_cards[1][2]
        
        # Pocket pairs
        if c1_rank == c2_rank:
            if c1_rank >= rank_values['A']: return 10 
            if c1_rank >= rank_values['K']: return 9
            if c1_rank >= rank_values['Q']: return 8
            if c1_rank >= rank_values['J']: return 7
            if c1_rank >= rank_values['T']: return 6
            return 5 # 99-22
        
        # Suited connectors/high cards
        if c1_suit == c2_suit: # Suited
            if (c1_rank >= rank_values['A'] and c2_rank >= rank_values['K']) or (c2_rank >= rank_values['A'] and c1_rank >= rank_values['K']): return 9 # AKs
            if (c1_rank >= rank_values['A'] and c2_rank >= rank_values['Q']) or (c2_rank >= rank_values['A'] and c1_rank >= rank_values['Q']): return 8 # AQs
            if (c1_rank >= rank_values['K'] and c2_rank >= rank_values['Q']) or (c2_rank >= rank_values['K'] and c1_rank >= rank_values['Q']): return 7 # KQs
            if abs(c1_rank - c2_rank) == 1 and max(c1_rank, c2_rank) >= rank_values['T']: return 6 # Suited connectors T9s+
            return 4 # Other suited
        
        # Off-suit high cards
        if (c1_rank >= rank_values['A'] and c2_rank >= rank_values['K']) or (c2_rank >= rank_values['A'] and c1_rank >= rank_values['K']): return 8 # AKo
        if max(c1_rank, c2_rank) >= rank_values['A'] and min(c1_rank, c2_rank) >= rank_values['T']: return 5 # AT+ offsuit
        if max(c1_rank, c2_rank) >= rank_values['K'] and min(c1_rank, c2_rank) >= rank_values['J']: return 5 # KJ+ offsuit
        if max(c1_rank, c2_rank) >= rank_values['Q'] and min(c1_rank, c2_rank) >= rank_values['J']: return 4 # QJ+ offsuit

        # Connected cards
        if abs(c1_rank - c2_rank) <= 2 and max(c1_rank, c2_rank) >= rank_values['T']: return 4 # Connected cards
        
        return 1 # Weak hands

    def _get_pair_rank(self, hand_cards: List[str]) -> int:
        if len(hand_cards) != 2:
            return 0
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank1 = rank_values[hand_cards[0][0]] if len(hand_cards[0]) == 2 else rank_values['T']
        rank2 = rank_values[hand_cards[1][0]] if len(hand_cards[1]) == 2 else rank_values['T']
        if rank1 == rank2:
            return rank1
        return 0

    def _evaluate_high_card(self, hand_cards: List[str]) -> int:
        if len(hand_cards) == 0:
            return 0
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return max(rank_values[card[0]] if len(card) == 2 else rank_values['T'] for card in hand_cards)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass