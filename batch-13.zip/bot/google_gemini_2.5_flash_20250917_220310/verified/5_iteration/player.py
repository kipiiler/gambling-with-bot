import random
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.position = -1
        self.num_players = 0
        self.pot_odds_threshold = 0.2  # Default loose threshold
        self.opponents_active = {} # To track aggressive players

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.num_players = len(all_players)
        self.position = all_players.index(self.id)
        
        # Initialize opponent tracking
        self.opponents_active = {player_id: {'aggression': 0, 'total_actions': 0} for player_id in all_players if player_id != self.id}
        
        # Adjust strategy based on number of players (e.g., be tighter in multi-way pots)
        if self.num_players > 2:
            self.pot_odds_threshold = 0.15 # Tighter for multi-way
        else:
            self.pot_odds_threshold = 0.2 # Looser for heads-up

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # player_hands is not part of RoundStateClient. It's provided in on_start.
        # This error likely came from trying to access player_hands from round_state in a previous iteration.
        # self.hole_cards should be set on_start or via a separate mechanism by the game server if hole cards change per round.
        # For now, let's assume hole_cards are set once at the beginning of the game or just before on_round_start if they are per round.
        # Since player_hands is a LIST (potential for multiple hands if it's the server telling us all hands for some reason),
        # but our bot only has one hand, we need to clarify how our hole cards are passed.
        # Assuming for now that on_start's player_hands is OUR hole cards.
        # If it changes per round, it means this `on_round_start` needs to receive `player_hands` as an argument or it's stored in `round_state`
        # The error states `RoundStateClient` object has no attribute 'player_hands'.
        # This means we *DO NOT* get player_hands from round_state.
        # Assuming the initial `player_hands` from `on_start` are our hole cards for the first hand, 
        # and they are implicitly updated by the game server before each `get_action` or `on_round_start` with *our specific* hole cards.
        # For a competition, typically your bot only knows its own cards for the current hand.
        # The `player_hands` argument in `on_start` is unusual, but if it contained our specific hand.
        # If `player_hands` in `on_start` is for 'all players' at the start (highly unlikely for a real game unless it's for game state logging for spectator),
        # then we need to rely on the game engine to tell us our hole cards before `get_action`.
        # However, the `Bot` interface does not currently provide a way to update `hole_cards` explicitly per round unless it's given in `round_state` which it isn't.
        # For robustness, let's assume `hole_cards` will be provided by the server through `get_action` (though not in signature) or set before `get_action` is called.
        # The current template implies `player_hands` is a list, not a dict of player_id to hand.
        # It's highly probable that `on_round_start` should *not* update `self.hole_cards` from `round_state.player_hands`.
        # The error indicates that 'RoundStateClient' does not have 'player_hands'.
        # Let's assume `self.hole_cards` is handled by the server internally and passed to `get_action` (even if not explicitly in the signature) 
        # or `on_start`'s `player_hands` means OUR specific hole cards for the FIRST hand, and subsequent hands need an update mechanism.
        # Given the template, `self.hole_cards` usually needs to be explicitly passed somewhere if it changes per round.
        # Let's make `get_action` capable of using `hole_cards` if it needs to be updated.
        # For now, `self.hole_cards` will remain what it was set to in `on_start` (if player_hands means our cards).
        # This is a critical design assumption about how the game server passes cards.
        # If the server tells us our two hole cards each round, it's typically done by passing them into `get_action` or a `on_new_hand` method.
        # Since there's no `on_new_hand` and `player_hands` in `on_start` is a LIST, the most logical interpretation is that `player_hands` in `on_start`
        # is meant to be *our* initial hole cards for the first hand, and the system is expected to update `self.hole_cards` for subsequent hands implicitly or through `get_action`.
        # Let's assume for this iteration, `on_start`'s `player_hands` IS our hole cards for the FIRST hand, and the actual hole cards for subsequent hands will be handled by the context of `get_action`.
        # For the purpose of moving forward due to the `AttributeError`, we should remove any attempt to set `self.hole_cards` from `round_state` here.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Assume self.hole_cards are updated by the system before get_action is called for each hand.
        # If `on_start` `player_hands` actually contained OUR specific hole cards for the current hand,
        # then we should set `self.hole_cards` from there. If not explicitly refreshed, `self.hole_cards` may be stale.
        # Let's use `on_start`'s `player_hands` as our initial `hole_cards` for the first hand and assume it's updated somehow.
        # Or alternatively, the `player_hands` in `on_start` is a placeholder and our cards are implicitly set per round.
        
        # Simulating hole cards for testing purposes if not provided by the game context
        # In a real game, this would be provided by the server prior to get_action.
        # For now, let's use a dummy value if self.hole_cards is empty (which implies it wasn't set by `on_start` as our actual cards)
        # Assuming `on_start`'s `player_hands` parameter is *our* hold cards for the first hand.
        # If it's a list like `['Ah', 'Kd']`, then that's our initial hand.
        if not self.hole_cards:
            # This is a fallback if the system doesn't update `self.hole_cards`.
            # In a real game, `self.hole_cards` would be set by the environment.
            # Example: assuming it's passed as a hidden parameter to `get_action` or set as `self.hole_cards`
            # prior to this call, possibly from `on_start` which had `player_hands`.
            # For iteration fixes, explicitly removing `round_state.player_hands` access.
            # Let's mock a hand or assume it exists. For now, a dummy value if state is empty.
            # This should ideally be external to the bot logic once the game server is stable.
            pass # `self.hole_cards` must be set by the game server for each round.
                 # If `on_start` `player_hands` is actually `OUR` hole cards, then `self.hole_cards = player_hands` should be there.
                 # The current template for `on_start` has `player_hands`, indicating it *might* be our hand for the first game.
                 # Let's assume on_start's player_hands *are* the bot's initial hole cards.
                 # This means `on_start` should set `self.hole_cards`
                 # self.hole_cards = player_hands # This should be in on_start.

        community_cards = round_state.community_cards
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        pot_size = round_state.pot

        # Basic hand strength evaluation (simplified for quick testing)
        # This needs actual card parsing and strength calculation for a real bot.
        # For now, a placeholder for actual evaluation logic.
        hand_strength = self._evaluate_hand_strength(self.hole_cards, community_cards)

        # Pot odds calculation
        if amount_to_call > 0:
            pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9) # Add epsilon to prevent div by zero
        else:
            pot_odds = 0

        # Aggression tracking for opponents
        for player_id_str, action_str in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id != self.id and player_id in self.opponents_active:
                action = PokerAction[action_str.upper()]
                self.opponents_active[player_id]['total_actions'] += 1
                if action in [PokerAction.RAISE, PokerAction.ALL_IN]:
                    self.opponents_active[player_id]['aggression'] += 1
        
        # Determine overall opponent aggression
        total_aggression_score = 0
        total_opponent_actions = 0
        for opp_data in self.opponents_active.values():
            total_aggression_score += opp_data['aggression']
            total_opponent_actions += opp_data['total_actions']
        
        # Defensive check against division by zero
        opponent_aggression_ratio = total_aggression_score / (total_opponent_actions + 1e-9) if total_opponent_actions > 0 else 0

        # Simple strategy (Heads-up or Multi-way)
        if self.num_players == 2: # Heads-up strategy
            return self._heads_up_strategy(round_state, remaining_chips, hand_strength, pot_odds, amount_to_call, opponent_aggression_ratio)
        else: # Multi-way strategy
            return self._multi_way_strategy(round_state, remaining_chips, hand_strength, pot_odds, amount_to_call, opponent_aggression_ratio)

    def _heads_up_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, amount_to_call: int, opponent_aggression_ratio: float) -> Tuple[PokerAction, int]:
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Starting hand ranges (simplified)
            if hand_strength > 0.7:  # Premium hands (AA, KK, AKs, QQ)
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 3)
                elif amount_to_call * 2 < remaining_chips:
                    return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2 + self.blind_amount) # Re-raise
                else:
                    return PokerAction.ALL_IN
            elif hand_strength > 0.5: # Strong hands (JJ, AQ, TT, 99)
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 2)
                else:
                    if pot_odds < self.pot_odds_threshold * 1.5 and amount_to_call < remaining_chips / 3: # Call smaller bets
                        return PokerAction.CALL, 0
                    elif amount_to_call < remaining_chips / 5 and opponent_aggression_ratio < 0.3: # Call if not too aggressive and small bet
                        return PokerAction.CALL, 0
                    else: # Too expensive or aggressive opponent
                        return PokerAction.FOLD, 0
            elif hand_strength > 0.3: # Marginal hands (suited connectors, some Broadway cards)
                if amount_to_call == 0:
                    if random.random() < (0.1 + (0.05 * (1 - opponent_aggression_ratio))): # Occasionally limp/min-raise
                        return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 1)
                    else:
                        return PokerAction.CHECK, 0
                elif pot_odds < self.pot_odds_threshold and amount_to_call < remaining_chips / 4:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength > 0.85: # Very strong hand (e.g., set, straight, flush, two pair+)
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, min(round_state.max_raise, round_state.pot * 0.75))
                elif amount_to_call > 0:
                    if amount_to_call < remaining_chips * 0.5 and random.random() < 0.8: # Aggressive call/raise with strong hands
                        return PokerAction.RAISE, min(remaining_chips, round_state.min_raise + round_state.current_bet - my_bet) # Min raise as a value bet
                    else:
                        return PokerAction.ALL_IN
            elif hand_strength > 0.6: # Strong hand (e.g., top pair, good kicker, strong draw)
                if amount_to_call == 0:
                    if random.random() < (0.6 + (0.1 * opponent_aggression_ratio)): # Bet for value or bluff
                         return PokerAction.RAISE, min(remaining_chips, round_state.pot // 2)
                    else:
                        return PokerAction.CHECK, 0
                elif pot_odds < self.pot_odds_threshold * (1 + opponent_aggression_ratio): # Call if good pot odds and not facing too much aggression
                    return PokerAction.CALL, 0
                elif remaining_chips > round_state.max_raise: # Reraise if opponent is passive and we have strength
                    if opponent_aggression_ratio < 0.3 and random.random() < 0.2:
                        return PokerAction.RAISE, min(remaining_chips, round_state.min_raise)
                    else:
                        return PokerAction.FOLD, 0 # Could be too aggressive to call
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength > 0.3: # Marginal hand (e.g., middle pair, weak draw)
                if amount_to_call == 0:
                    if random.random() < (0.2 - (0.1 * opponent_aggression_ratio)): # Small bluff or check
                         return PokerAction.RAISE, min(remaining_chips, round_state.pot // 3)
                    else:
                        return PokerAction.CHECK, 0
                elif pot_odds < self.pot_odds_threshold * 0.8 and amount_to_call < remaining_chips / 5 : # Call if cheap and good odds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Implement bluffing if opponent is fold-prone (low aggression) and pot is small.
                    if opponent_aggression_ratio < 0.2 and round_state.current_bet < remaining_chips / 5 and random.random() < 0.1:
                        return PokerAction.RAISE, min(remaining_chips, round_state.min_raise) # Small bluff bet
                    return PokerAction.FOLD, 0
        
        # Default action if no condition met (should not happen with comprehensive logic)
        return PokerAction.FOLD, 0 # Fallback

    def _multi_way_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, amount_to_call: int, opponent_aggression_ratio: float) -> Tuple[PokerAction, int]:
        # Multi-way pots require tighter play due to increased competition and higher chance of facing a strong hand.

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            if hand_strength > 0.8: # Premium hands
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 3)
                elif amount_to_call * 2 < remaining_chips:
                    return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2 + self.blind_amount) # Re-raise
                else:
                    return PokerAction.ALL_IN
            elif hand_strength > 0.6: # Strong hands
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 2)
                else:
                    if pot_odds < self.pot_odds_threshold: # Only call if pot odds are very good for modest bets
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else: # Marginal or weak hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif pot_odds < self.pot_odds_threshold * 0.7: # Even tighter pot odds for calling
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength > 0.9: # Very strong hand (e.g., nuts, strong two pair+)
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, min(round_state.max_raise, round_state.pot * 0.75))
                elif amount_to_call < remaining_chips * 0.75:
                    return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2 + round_state.min_raise) # Value raise
                else:
                    return PokerAction.ALL_IN
            elif hand_strength > 0.75: # Strong hand (e.g., top pair, good kicker, strong draw)
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, round_state.pot // 2)
                elif pot_odds < self.pot_odds_threshold * 1.2: # Call if decent pot odds
                    return PokerAction.CALL, 0
                elif remaining_chips > round_state.max_raise and random.random() < 0.1: # Small chance to reraise if opponent passive
                    return PokerAction.RAISE, min(remaining_chips, round_state.min_raise)
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength > 0.4: # Marginal hand (e.g., middle pair, weak draw)
                if amount_to_call == 0:
                    if random.random() < 0.1: # Small bluff or check
                         return PokerAction.RAISE, min(remaining_chips, round_state.pot // 4)
                    else:
                        return PokerAction.CHECK, 0
                elif pot_odds < self.pot_odds_threshold * 0.9 and amount_to_call < remaining_chips / 6: # Call if very cheap for odds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    if opponent_aggression_ratio < 0.15 and round_state.current_bet < remaining_chips / 6 and random.random() < 0.05: # Rare bluff
                        return PokerAction.RAISE, min(remaining_chips, round_state.min_raise)
                    return PokerAction.FOLD, 0
        
        return PokerAction.FOLD, 0 # Fallback

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        A very basic placeholder for hand strength evaluation.
        In a real bot, this would involve complex hand evaluation logic.
        For now, it returns a random value or a value based on simple checks.
        This needs significant improvement with actual poker probabilities.
        """
        if not hole_cards:
            # If hole_cards are empty, it means they haven't been set by the game server for this round.
            # This is a critical state - we cannot play without our cards.
            # Returning a very low strength to force a fold.
            return 0.01 
            # In a real scenario, this would indicate an error in game state communication.
            # The bot must be able to access its hole cards for valid play.
            # For iteration, assuming `self.hole_cards` would be populated by `on_start` (for first hand)
            # and by the game engine implicitly for subsequent hands before `get_action`.

        all_cards = hole_cards + community_cards

        # Basic strength check (needs much more detail)
        # Higher values for stronger hands
        strength = 0.0

        # Pre-flop estimations
        if not community_cards:
            # Example: AA, KK = very strong
            if {'A', 'A'} <= {c[0] for c in hole_cards}: strength = 0.99
            elif {'K', 'K'} <= {c[0] for c in hole_cards}: strength = 0.95
            elif {'Q', 'Q'} <= {c[0] for c in hole_cards}: strength = 0.90
            elif ('A' in {c[0] for c in hole_cards} and 'K' in {c[0] for c in hole_cards} and hole_cards[0][1] == hole_cards[1][1]): strength = 0.88 # AKs
            elif {'J', 'J'} <= {c[0] for c in hole_cards}: strength = 0.85
            elif ('A' in {c[0] for c in hole_cards} and 'Q' in {c[0] for c in hole_cards} and hole_cards[0][1] == hole_cards[1][1]): strength = 0.82 # AQs
            elif {'T', 'T'} <= {c[0] for c in hole_cards}: strength = 0.80
            elif ('K' in {c[0] for c in hole_cards} and 'Q' in {c[0] for c in hole_cards} and hole_cards[0][1] == hole_cards[1][1]): strength = 0.75 # KQs
            elif ('A' in {c[0] for c in hole_cards} and 'K' in {c[0] for c in hole_cards}): strength = 0.70 # AKo
            # Suited connectors, pairs
            elif hole_cards[0][0] == hole_cards[1][0]: strength = 0.6 + (int(self._card_rank_to_int(hole_cards[0][0])) / 13 * 0.2) # Any pair
            elif hole_cards[0][1] == hole_cards[1][1]: strength = 0.5 + (random.random() * 0.1) # Suited
            else: strength = random.random() * 0.4 # Random low card
            
            return strength # This is still highly simplified. Needs real parsing.

        # Post-flop evaluation (very crude, needs real poker hand ranking)
        ranks = [self._card_rank_to_int(card[0]) for card in all_cards]
        suits = [card[1] for card in all_cards]

        # Check for pairs
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)

        if quads: return 0.99
        if trips and pairs: return 0.98 # Full House (simplified)
        if sum(1 for count in rank_counts.values() if count >= 3) >= 2: return 0.98 # Two trips, acts as full house
        if any(count == 3 for count in rank_counts.values()): return 0.90 # Three of a kind
        if pairs >= 2: return 0.80 # Two pair
        if pairs == 1: return 0.70 # One pair

        # Check for flush (very basic)
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        if any(count >= 5 for count in suit_counts.values()): return 0.95 # Flush

        # Check for straight (very basic, doesn't handle wraps/gaps well)
        sorted_ranks = sorted(list(set(ranks)))
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4: return 0.93 # Straight

        # For hands with no strong combination, base on high card of hole cards + value
        if hole_cards:
            high_card_strength = max(self._card_rank_to_int(c[0]) for c in hole_cards) / 14.0 * 0.6 # Use 14 for Ace
            strength = max(strength, high_card_strength)
        
        # Add random factor to simulate variance in hand evaluation for draws
        if len(community_cards) < 5: # If not river, potential for draws
            if random.random() < 0.1: # Small chance to overvalue draws
                strength += 0.05
        
        return strength

    def _card_rank_to_int(self, rank: str) -> int:
        """Converts card rank to an integer for comparison."""
        if rank == 'A': return 14
        if rank == 'K': return 13
        if rank == 'Q': return 12
        if rank == 'J': return 11
        if rank == 'T': return 10
        return int(rank)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset aggression tracking for next round, or decay it.
        # For simplicity, let's decay it slightly for persistent tendencies.
        for player_id in self.opponents_active:
            self.opponents_active[player_id]['aggression'] *= 0.8
            self.opponents_active[player_id]['total_actions'] *= 0.8
        
        # IMPORTANT: The game server should update self.hole_cards for the next hand.
        # This is typically done by passing `player_hands` into a `on_new_hand` or `get_action`
        # if the cards change per hand. Since `on_start` has `player_hands` as a list,
        # it is assumed to be *our* hole cards for the first hand.
        # If the game server doesn't re-provide hole cards, the bot will play same hand repeatedly.
        # Need to ensure `self.hole_cards` is cleared for the next round or explicitly updated.
        self.hole_cards = [] # Clear hole cards to ensure they are refreshed, assuming the game server will provide them again.

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass # No specific action needed at end of game for this bot.