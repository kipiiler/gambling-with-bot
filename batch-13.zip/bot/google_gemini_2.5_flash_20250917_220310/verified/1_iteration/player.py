from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.player_id = None
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []

    def set_id(self, player_id: int) -> None:
        self.player_id = str(player_id) # Store player ID as string to match player_bets keys

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = str(big_blind_player_id)
        self.small_blind_player_id = str(small_blind_player_id)
        self.all_players = [str(p_id) for p_id in all_players]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self._get_my_hole_cards(round_state) # Update hole cards at each round start if they are passed in some form

    def _get_my_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        # This assumes hole cards are part of round_state for the current player
        # If not, they must be stored from on_start and maintained.
        # For this template, let's assume they are stored from on_start.
        # The `player_hands` from `on_start` is usually only for the current player,
        # and doesn't change round to round for a single hand.
        return self.hole_cards

    def _get_card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def _get_card_suit(self, card: str) -> str:
        return card[1]

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0, [] # No cards to evaluate

        ranks = sorted([self._get_card_rank(card) for card in all_cards], reverse=True)
        suits = [self._get_card_suit(card) for card in all_cards]

        # Count occurrences for pairs, trips, quads
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)

        # Check for flush
        flush_suit = None
        for suit, count in suit_counts.items():
            if count >= 5:
                flush_suit = suit
                break

        # Check for straight
        straight_ranks = sorted(list(set(ranks)), reverse=True)
        straight_high_card = 0
        if len(straight_ranks) >= 5:
            # Check for A-5 straight (special case: A, 5, 4, 3, 2)
            if 14 in straight_ranks and 5 in straight_ranks and 4 in straight_ranks and 3 in straight_ranks and 2 in straight_ranks:
                straight_high_card = 5 # Represent A-5 straight with 5 as the highest card in the sequence
            else:
                for i in range(len(straight_ranks) - 4):
                    if straight_ranks[i] - straight_ranks[i+1] == 1 and \
                       straight_ranks[i+1] - straight_ranks[i+2] == 1 and \
                       straight_ranks[i+2] - straight_ranks[i+3] == 1 and \
                       straight_ranks[i+3] - straight_ranks[i+4] == 1:
                        straight_high_card = straight_ranks[i]
                        break

        # Generate all 5-card combinations for best hand
        # This is a simplification; a full evaluation function would consider all 21 combinations
        # of 5 cards from 7 for the best 5-card hand.
        # For a basic bot, we'll try to find the best hand based on the *current* card pool.

        # Royal Flush (10)
        if flush_suit and straight_high_card == 14 and all(r in ranks for r in [14, 13, 12, 11, 10]):
            flush_cards = [card for card in all_cards if self._get_card_suit(card) == flush_suit]
            flush_ranks = sorted([self._get_card_rank(card) for card in flush_cards], reverse=True)
            if all(r in flush_ranks for r in [14, 13, 12, 11, 10]):
                return 10, [14, 13, 12, 11, 10]

        # Straight Flush (9)
        if flush_suit and straight_high_card > 0:
            flush_cards = [card for card in all_cards if self._get_card_suit(card) == flush_suit]
            flush_ranks = sorted(list(set([self._get_card_rank(card) for card in flush_cards])), reverse=True)
            if len(flush_ranks) >= 5:
                # Check for A-5 straight flush (A, 5, 4, 3, 2 of same suit)
                if 14 in flush_ranks and 5 in flush_ranks and 4 in flush_ranks and 3 in flush_ranks and 2 in flush_ranks:
                    return 9, [5, 4, 3, 2, 1] # Kicker ranks for A-5 straight flush
                for i in range(len(flush_ranks) - 4):
                    if flush_ranks[i] - flush_ranks[i+1] == 1 and \
                       flush_ranks[i+1] - flush_ranks[i+2] == 1 and \
                       flush_ranks[i+2] - flush_ranks[i+3] == 1 and \
                       flush_ranks[i+3] - flush_ranks[i+4] == 1:
                        return 9, [flush_ranks[i], flush_ranks[i+1], flush_ranks[i+2], flush_ranks[i+3], flush_ranks[i+4]]


        # Four of a Kind (8)
        four_kind_rank = 0
        for rank, count in rank_counts.items():
            if count >= 4:
                four_kind_rank = rank
                break
        if four_kind_rank > 0:
            kickers = sorted([r for r in ranks if r != four_kind_rank], reverse=True)[:1]
            return 8, [four_kind_rank, four_kind_rank, four_kind_rank, four_kind_rank] + kickers

        # Full House (7)
        trips_rank = 0
        pairs_rank = 0
        pair_ranks_list = []
        for rank, count in rank_counts.items():
            if count >= 3:
                # Find the highest trip
                if rank > trips_rank:
                    # If this is a new highest trip, reset pair search
                    if trips_rank != 0: # If we had a trip before, make it a pair candidate
                         pair_ranks_list.append(trips_rank)
                    trips_rank = rank
            elif count >= 2:
                pair_ranks_list.append(rank)

        # Handle two trips case (e.g., KKKJJ)
        if trips_rank > 0 and len(pair_ranks_list) > 0:
            # If we have two trips (e.g., KKK and JJJ), the second highest trip becomes a pair
            # Or if we have one trip and multiple pairs, take the highest pair
            pairs_rank = max(pair_ranks_list)
            return 7, [trips_rank, trips_rank, trips_rank, pairs_rank, pairs_rank]

        # Flush (6)
        if flush_suit:
            flush_ranks = sorted([self._get_card_rank(card) for card in all_cards if self._get_card_suit(card) == flush_suit], reverse=True)[:5]
            return 6, flush_ranks

        # Straight (5)
        if straight_high_card > 0:
            straight_sequence = []
            if straight_high_card == 5 and 14 in ranks and 5 in ranks and 4 in ranks and 3 in ranks and 2 in ranks: # A-5 straight
                straight_sequence = [5, 4, 3, 2, 1]
            else:
                current_rank = straight_high_card
                for _ in range(5):
                    straight_sequence.append(current_rank)
                    current_rank -= 1
            return 5, straight_sequence

        # Three of a Kind (4)
        if trips_rank > 0 :
            kickers = sorted([r for r in ranks if r != trips_rank], reverse=True)[:2]
            return 4, [trips_rank, trips_rank, trips_rank] + kickers

        # Two Pair (3)
        if len(pair_ranks_list) >= 2:
            pair_ranks_list.sort(reverse=True)
            top_two_pairs = pair_ranks_list[:2]
            kickers = sorted([r for r in ranks if r not in top_two_pairs], reverse=True)[:1]
            return 3, top_two_pairs + top_two_pairs + kickers

        # One Pair (2)
        if len(pair_ranks_list) >= 1:
            highest_pair_rank = max(pair_ranks_list)
            kickers = sorted([r for r in ranks if r != highest_pair_rank], reverse=True)[:3]
            return 2, [highest_pair_rank, highest_pair_rank] + kickers

        # High Card (1)
        return 1, ranks[:5]


    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(self.player_id, 0)
        amount_to_call = current_bet - my_current_bet
        
        # Ensure max_raise is not negative
        max_raise_amount_possible = remaining_chips + my_current_bet
        max_raise = round_state.max_raise # This is typically remaining chips
        # Adjust max_raise if the round_state's max_raise indicates a value lower than our actual chips
        # This can happen if another player has less chips than us and went all-in, limiting subsequent raises.
        max_raise = min(max_raise, remaining_chips) 

        # Calculate hand strength
        hand_rank, _ = self._evaluate_hand(self.hole_cards, round_state.community_cards)

        num_players_in_hand = len(round_state.current_player)

        # Preflop strategy
        if round_state.round == 'Preflop':
            # Starting hand strength based on common pre-flop charts (simplified)
            # High pairs, suited connectors, high cards
            c1_rank = self._get_card_rank(self.hole_cards[0])
            c2_rank = self._get_card_rank(self.hole_cards[1])
            c1_suit = self._get_card_suit(self.hole_cards[0])
            c2_suit = self._get_card_suit(self.hole_cards[1])

            is_suited = (c1_suit == c2_suit)
            is_pair = (c1_rank == c2_rank)
            
            # Premium hands
            if is_pair and c1_rank >= 10:  # TT, JJ, QQ, KK, AA
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 3 + self.blind_amount) # raise 3-4x BB
                elif amount_to_call < remaining_chips / 4 or amount_to_call < self.blind_amount * 3: # Call small raises or re-raise
                    raise_amount = min(remaining_chips, current_bet * 2) # raise up to 2x current bet
                    if raise_amount > 0:
                        min_raise_actual = round_state.min_raise
                        if my_current_bet + raise_amount < current_bet * 2 - my_current_bet + self.blind_amount: # Ensure valid raise
                             raise_amount = max(round_state.min_raise, current_bet * 2 - my_current_bet )
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CALL, 0
                else: # Big raise, consider all-in or fold
                    if remaining_chips <= amount_to_call * 1.5: # If almost all-in to call
                        return PokerAction.ALL_IN, 0
                    return PokerAction.FOLD, 0
            
            # Strong speculative hands
            if (is_suited and c1_rank >= 10 and c2_rank >= 10) or \
               (is_pair and c1_rank >= 7) : # AKs, AQs, KQs, 77, 88, 99
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 2 + self.blind_amount // 2)
                elif amount_to_call < remaining_chips / 5 or amount_to_call < self.blind_amount * 2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Medium hands
            if (is_suited and c1_rank >= 8 and c2_rank >= 8) or \
               (c1_rank >= 12 and c2_rank >= 10) or \
               (is_pair and c1_rank >= 4): # QJs, KTs, AJo, 44, 55, 66
                if amount_to_call == 0: # Can open lim or small raise
                    if random.random() < 0.6: # 60% chance to check/call, 40% to raise
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 2)
                elif amount_to_call <= self.blind_amount: # Call minimal bets
                    return PokerAction.CALL, 0
                elif amount_to_call > self.blind_amount * 2 and random.random() < 0.2: # Small chance to call larger bet
                    if remaining_chips <= amount_to_call * 1.2:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Weak hands / Blinds handling
            if self.player_id == self.big_blind_player_id and amount_to_call == 0:
                return PokerAction.CHECK, 0 # Check in BB if no raise
            
            if self.player_id == self.small_blind_player_id and amount_to_call == self.blind_amount / 2:
                if random.random() < 0.7: # 70% chance to complete SB
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Default for weak hands preflop
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            
            if amount_to_call < remaining_chips / 10 and num_players_in_hand > 2: # Call small bets in multiway pots with hope
                return PokerAction.CALL, 0

            return PokerAction.FOLD, 0
            

        # Post-flop strategy (Flop, Turn, River)
        # The strategy here becomes more dynamic based on community cards.
        
        # Early rounds (Flop, Turn) - consider draws and strong made hands
        if round_state.round in ['Flop', 'Turn']:
            if hand_rank >= 8: # Quads or better - always go for value
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, current_bet + self.blind_amount * 2) if current_bet > 0 else min(remaining_chips, self.blind_amount * 2)
                elif amount_to_call < remaining_chips / 2:
                    return PokerAction.RAISE, min(remaining_chips, current_bet * 2)
                else:
                    return PokerAction.ALL_IN, 0
            
            if hand_rank >= 6: # Flush or better - strong hands
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, current_bet + self.blind_amount) if current_bet > 0 else min(remaining_chips, self.blind_amount * 1.5)
                elif amount_to_call < remaining_chips / 3:
                     return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2)
                elif amount_to_call < remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0

            if hand_rank >= 4: # Three of a kind, Straight, or better
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, current_bet + self.blind_amount // 2) if current_bet > 0 else min(remaining_chips, self.blind_amount)
                elif amount_to_call < remaining_chips / 4:
                    return PokerAction.CALL, 0
                else:
                    # Consider folding or all-in if price is too high but hand is strong
                    if remaining_chips <= amount_to_call * 1.2:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.FOLD, 0

            if hand_rank >= 2: # One pair or two pair - medium hands
                if amount_to_call == 0:
                    if random.random() < 0.7: # Check more often to control pot
                        return PokerAction.CHECK, 0
                    else: # Occasionally bet for value/protection
                        return PokerAction.RAISE, min(remaining_chips, self.blind_amount)
                elif amount_to_call < remaining_chips / 5: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Bluffs/Semi-bluffs for draws - this is a simplification
            # For a more advanced bot, you'd calculate outsourced equity
            # here we just fold weak hands
            if amount_to_call == 0 :
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0


        # Late round (River)
        if round_state.round == 'River':
            if hand_rank >= 7: # Full house or better - strong value bet
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, current_bet + self.blind_amount * 2) if current_bet > 0 else min(remaining_chips, self.blind_amount * 2)
                elif amount_to_call < remaining_chips / 2:
                    return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2)
                else:
                    return PokerAction.ALL_IN, 0
            
            if hand_rank >= 5: # Straight or better - good value bet
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, current_bet + self.blind_amount) if current_bet > 0 else min(remaining_chips, self.blind_amount * 1.5)
                elif amount_to_call < remaining_chips / 3:
                     return PokerAction.RAISE, min(remaining_chips, amount_to_call * 2)
                elif amount_to_call < remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0

            if hand_rank >= 2: # One pair, two pair, three of a kind
                if amount_to_call == 0:
                    if random.random() < 0.6: # Value bet with decent strength
                        return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 0.75) if self.blind_amount * 0.75 > 0 else 1
                    else:
                        return PokerAction.CHECK, 0
                elif amount_to_call < remaining_chips / 5: # Call small bets on river, pot odds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0 # Big bet on river suggests strong hand, fold marginal
            
            # Weak or no hand - just check or fold
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        # Default action in case nothing else matches (should broadly be covered)
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif amount_to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0
        else:
            # Random call/fold for remaining situations or if facing small bets
            if amount_to_call < (remaining_chips / 10) or (random.random() < 0.1 and amount_to_call <= remaining_chips / 5):
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass