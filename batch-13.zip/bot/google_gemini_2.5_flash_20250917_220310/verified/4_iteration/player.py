import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # We only know our hole cards at the beginning of each hand
        self.hole_cards = round_state.player_hands.get(str(self.id), [])

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        
        # Calculate approximate hand strength
        strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic VPIP (Voluntarily Put In Pot) logic
        # Adjusting VPIP based on number of players. Tighter in multi-way pots.
        vpip_threshold = 0.20 # Default for heads-up or fewer players
        if self.num_players > 2:
            vpip_threshold = 0.15 # Tighter for more players
        
        # Preflop Strategy
        if round_state.round == 'Preflop':
            # Premium hands: AA, KK, QQ, AKs, AKo, JJ, TT (top ~5%)
            if self._is_premium_hand(self.hole_cards):
                # Always raise or call with premium hands
                if amount_to_call == 0: # Can check or raise
                    raise_amount = min(remaining_chips, round_state.min_raise * 2) # Raise 2x min_raise
                    if raise_amount > 0:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                else: # Must call or raise
                    if amount_to_call >= remaining_chips: # All-in to call
                        return PokerAction.ALL_IN, 0
                    if remaining_chips > amount_to_call + round_state.min_raise:
                        return PokerAction.RAISE, round_state.current_bet * 2 # Raise to 2x current bet
                    else:
                        return PokerAction.CALL, 0
            
            # Strong hands: Pocket pairs (22-99), suited connectors (e.g., JTs, 98s), high-card combos (e.g., AQo, KJs)
            # This is where we apply the VPIP logic more directly
            if strength > vpip_threshold: # For hands better than a certain threshold
                if amount_to_call == 0: # Can check or raise
                    # If we are the big blind and no one has raised, check
                    if self.id == round_state.big_blind_player_id and round_state.current_bet == self.blind_amount:
                        return PokerAction.CHECK, 0
                    
                    # Otherwise, make a small raise to test strength
                    raise_amount = min(remaining_chips, round_state.current_bet + self.blind_amount * 2)
                    if raise_amount > 0 and raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, raise_amount
                    else: # If we can't make a valid raise, just call (if amount_to_call is 0, this means check)
                        return PokerAction.CHECK, 0
                else: # Must call or raise
                    # If the bet is small relative to the pot or blinds, call
                    if amount_to_call <= self.blind_amount * 2 or amount_to_call * 2 < sum(round_state.player_bets.values()) + round_state.pot:
                        if amount_to_call >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0
                    else: # If the bet is significant, fold marginal hands
                        return PokerAction.FOLD, 0
            
            # Marginal hands or weak hands: Fold if facing a raise, call if no raise or small raise from BB
            else:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= self.blind_amount: # Small blind's call or a cheap call
                    if amount_to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Postflop Strategy (Flop, Turn, River)
        # Dynamic strategy based on hand strength and number of opponents
        active_players = sum(1 for p_id, p_bet in round_state.player_bets.items() if p_id != str(self.id) and p_bet >= 0)
        
        if strength > 0.7:  # Very strong hand (e.g., two pair, trips, straight, flush, full house, quads)
            if amount_to_call == 0:
                 # Aggressively bet or raise
                raise_amount = min(remaining_chips, int(round_state.pot * 0.75))
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CHECK, 0 # If cannot raise a meaningful amount, check
            else:
                # Re-raise or call, lean towards raising if opponent seems weak or pot is large
                if remaining_chips > amount_to_call + round_state.min_raise and random.random() < 0.75: # 75% chance to raise if possible
                    raise_amount = min(remaining_chips, amount_to_call + int(round_state.pot * 0.5))
                    if raise_amount > 0 and raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CALL, 0 # Fallback to call if raise invalid
                else:
                    if amount_to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0

        elif strength > 0.4: # Medium strength hand (e.g., top pair, good kicker, strong draw)
            if amount_to_call == 0:
                # Bet or check, lean towards betting if fewer opponents or pot is small
                if active_players <= 1 or random.random() < 0.6: # 60% chance to bet
                    bet_amount = min(remaining_chips, int(round_state.pot * 0.5))
                    if bet_amount > 0 and (bet_amount >= round_state.min_raise or round_state.current_bet == 0):
                        return PokerAction.RAISE, bet_amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Call small bets, fold large bets
                if amount_to_call <= round_state.pot * 0.3: # Call up to 30% of the pot
                    if amount_to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        else: # Weak hand or no hand
            if amount_to_call == 0:
                # Check, bluff small if few opponents and late street
                if active_players <= 1 and round_state.round in ['Turn', 'River'] and random.random() < 0.2: # 20% chance to bluff
                    bluff_amount = min(remaining_chips, int(round_state.pot * 0.3))
                    if bluff_amount > 0 and (bluff_amount >= round_state.min_raise or round_state.current_bet == 0):
                        return PokerAction.RAISE, bluff_amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Fold unless the bet is very small (e.g., min raise on the big blind)
                if amount_to_call <= self.blind_amount and round_state.round == 'Preflop':
                    if amount_to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0



    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards after each round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Calculates a simplified hand strength. This is a very basic estimate
        and can be greatly improved with a more robust poker hand evaluator.
        Returns a float between 0.0 and 1.0.
        """
        if not hole_cards:
            return 0.0

        all_cards = hole_cards + community_cards
        
        # Mapping card ranks to numerical values for comparison
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = sorted([rank_map[card[0]] for card in all_cards], reverse=True)
        suits = [card[1] for card in all_cards]

        num_community = len(community_cards)

        # Pre-flop hand strength (based on common starting hand charts)
        if num_community == 0:
            card1_rank = rank_map[hole_cards[0][0]]
            card2_rank = rank_map[hole_cards[1][0]]
            is_suited = (hole_cards[0][1] == hole_cards[1][1])
            is_paired = (card1_rank == card2_rank)

            if is_paired:
                if card1_rank >= 12: return 0.9 # AA, KK, QQ
                if card1_rank >= 10: return 0.7 # JJ, TT
                if card1_rank >= 7: return 0.5 # 77, 88, 99
                return 0.3 # Small pairs
            
            if card1_rank >= 12 and card2_rank >= 11: # AK, AQ, KQ high cards
                if is_suited: return 0.8
                return 0.7
            if card1_rank >= 10 and card2_rank >= 9 and is_suited: # Suited connectors like JTs, T9s
                return 0.6
            if (card1_rank >= 10 or card2_rank >= 10) and (abs(card1_rank - card2_rank) <= 2): # Other high-card combos
                if is_suited: return 0.5
                return 0.4
            
            return 0.1 # Weak hands

        # Post-flop hand strength (basic evaluation)
        # This part is a simplification. A real poker bot would use a full hand evaluator.
        
        # Check for flush
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        has_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straight
        unique_ranks = sorted(list(set(ranks)))
        has_straight = False
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    has_straight = True
                    break
        
        # Check for pairs, three of a kind, four of a kind
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        pairs = 0
        trips = 0
        quads = 0
        for rank, count in rank_counts.items():
            if count == 2: pairs += 1
            if count == 3: trips += 1
            if count == 4: quads += 1
        
        if quads: return 1.0
        if trips >= 1 and pairs >= 1: return 0.95 # Full House
        if has_flush and has_straight and (max(ranks) == 14 and min(ranks) == 10): return 1.0 # Royal Flush (very basic check)
        if has_flush and has_straight: return 0.98 # Straight Flush
        if has_flush: return 0.9
        if has_straight: return 0.85
        if trips: return 0.8
        if pairs >= 2: return 0.75 # Two pair
        if pairs == 1: return 0.6 # One pair

        # High card strength based on the max of hole cards if no other combination
        if len(hole_cards) == 2:
            return max(rank_map[hole_cards[0][0]], rank_map[hole_cards[1][0]]) / 14 * 0.3 # max 0.3 if high card

        return 0.0 # Default weak hand

    def _is_premium_hand(self, hole_cards: List[str]) -> bool:
        """
        Checks if the hole cards constitute a premium starting hand.
        """
        if not hole_cards or len(hole_cards) < 2:
            return False
        
        card1_rank = hole_cards[0][0]
        card2_rank = hole_cards[1][0]
        is_suited = (hole_cards[0][1] == hole_cards[1][1])
        
        # Pocket pairs
        if card1_rank == card2_rank:
            if card1_rank in ['A', 'K', 'Q', 'J', 'T']:
                return True # AA, KK, QQ, JJ, TT
            
        # Ace-King suited or offsuit
        if (card1_rank == 'A' and card2_rank == 'K') or (card1_rank == 'K' and card2_rank == 'A'):
            return True
        
        # Ace-Queen suited or offsuit
        if (card1_rank == 'A' and card2_rank == 'Q' and is_suited) or \
           (card1_rank == 'Q' and card2_rank == 'A' and is_suited):
            return True
            
        return False