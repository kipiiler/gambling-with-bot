from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Helper functions for hand evaluation
def parse_card(card: str):
    """Parse a card string into rank and suit"""
    if len(card) == 2:
        rank, suit = card[0], card[1]
    else:
        rank, suit = card[0:2], card[2]  # for '10h' etc.
    rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    return rank_map.get(rank, 0), suit

def hand_rank(cards: List[str]) -> Tuple[int, List[int]]:
    """Return the rank of the best 5-card poker hand as (rank_type, tie_breakers)"""
    if len(cards) == 0:
        return 0, []
        
    # Parse cards
    parsed = [parse_card(c) for c in cards]
    ranks = [r for r, s in parsed]
    suits = [s for r, s in parsed]
    rank_counts = {r: ranks.count(r) for r in set(ranks)}
    sorted_ranks = sorted(ranks, reverse=True)
    
    # Sort by count descending, then by rank descending
    sorted_by_count = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
    
    is_flush = len(set(suits)) == 1
    sorted_unique_ranks = sorted(set(ranks), reverse=True)
    is_straight = len(sorted_unique_ranks) >= 5 and \
                  (sorted_unique_ranks[0] - sorted_unique_ranks[4] == 4 or \
                   (sorted_unique_ranks == [14, 5, 4, 3, 2]))  # A-5-4-3-2 straight
    
    # Check for A-5-4-3-2 straight
    if sorted_unique_ranks == [14, 5, 4, 3, 2]:
        is_straight = True
        straight_high = 5
    elif len(sorted_unique_ranks) >= 5:
        for i in range(len(sorted_unique_ranks) - 4):
            if sorted_unique_ranks[i] - sorted_unique_ranks[i+4] == 4:
                is_straight = True
                straight_high = sorted_unique_ranks[i]
                break
        else:
            is_straight = False
            straight_high = 0
    else:
        is_straight = False
        straight_high = 0

    # Royal Flush: T,J,Q,K,A of same suit
    if is_straight and is_flush and sorted_unique_ranks[0] == 14 and sorted_unique_ranks[1] == 13:
        return 9, [14]
    
    # Straight Flush
    if is_straight and is_flush:
        if straight_high == 5 and 14 in sorted_unique_ranks:  # 5-high straight flush
            return 8, [5]
        return 8, [straight_high]
    
    # Four of a kind
    if 4 in rank_counts.values():
        quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
        kickers = sorted([r for r in ranks if r != quad_rank], reverse=True)[:1]
        return 7, [quad_rank] + kickers
    
    # Full House
    if 3 in rank_counts.values() and 2 in rank_counts.values():
        trips = [r for r, c in rank_counts.items() if c == 3][0]
        pair = [r for r, c in rank_counts.items() if c == 2][0]
        return 6, [trips, pair]
    if list(rank_counts.values()).count(3) >= 2:  # two trips -> make full house
        trips_ranks = sorted([r for r, c in rank_counts.items() if c == 3], reverse=True)
        return 6, [trips_ranks[0], trips_ranks[1]]
    
    # Flush
    if is_flush:
        return 5, sorted_ranks[:5]  # already sorted
    
    # Straight
    if is_straight:
        if straight_high == 5 and 14 in sorted_unique_ranks:
            return 4, [5]
        return 4, [straight_high]
    
    # Three of a kind
    if 3 in rank_counts.values():
        trips_rank = [r for r, c in rank_counts.items() if c == 3][0]
        kickers = sorted([r for r in ranks if r != trips_rank], reverse=True)[:2]
        return 3, [trips_rank] + kickers
    
    # Two pair
    pairs = [r for r, c in rank_counts.items() if c == 2]
    if len(pairs) >= 2:
        pairs_sorted = sorted(pairs, reverse=True)[:2]
        kicker = max([r for r in ranks if r not in pairs]) if [r for r in ranks if r not in pairs] else 0
        return 2, pairs_sorted + [kicker]
    
    # One pair
    if 2 in rank_counts.values():
        pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
        return 1, [pair_rank] + kickers
    
    # High card
    return 0, sorted_ranks[:5]

def evaluate_hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    """Estimate hand strength based on hole + community cards"""
    if not hole_cards:
        return 0.0
        
    all_cards = hole_cards + community_cards
    best_hand_rank = hand_rank(all_cards)
    rank_type, _ = best_hand_rank

    # If we have a very strong hand, return high strength
    if rank_type >= 3:  # Three of a kind or better
        return 0.9 + rank_type / 100.0
    
    # Evaluate based on draws and high cards
    hole_parsed = [parse_card(c) for c in hole_cards]
    comm_parsed = [parse_card(c) for c in community_cards] if community_cards else []
    
    total_parsed = hole_parsed + comm_parsed
    
    # Check for flush draw
    suit_count = {}
    for r, s in total_parsed:
        suit_count[s] = suit_count.get(s, 0) + 1
    flush_draw = any(count >= 4 for count in suit_count.values())

    # Check for straight draw
    ranks = [r for r, s in total_parsed]
    unique_ranks = set(ranks)
    straight_draw = False
    for r in unique_ranks:
        needed = sum(1 for i in range(1,5) if (r+i) in unique_ranks)
        if needed >= 3:
            straight_draw = True
            break
    # Also consider 5-4-3-2-A low
    if {14,2,3,4}.issubset(unique_ranks) or {14,2,3,5}.issubset(unique_ranks) or {14,2,4,5}.issubset(unique_ranks):
        straight_draw = True

    # High card strength
    hole_ranks = [r for r, s in hole_parsed]
    high_card_strength = max(hole_ranks) / 14.0
    
    # Pocket pair
    pocket_pair = hole_ranks[0] == hole_ranks[1]
    pair_strength = hole_ranks[0] / 14.0 if pocket_pair else 0

    # Combine into rough estimate
    strength = 0.1
    if pocket_pair:
        strength += 0.2 + (pair_strength * 0.3)
    if flush_draw:
        strength += 0.25
    if straight_draw:
        strength += 0.2
    if not community_cards:  # Pre-flop
        # Use Chen formula approximation
        high_card = max(hole_ranks)
        chen = high_card / 2.0
        if pocket_pair:
            chen = max(5.0, chen * 2)
        if hole_parsed[0][1] == hole_parsed[1][1]:  # suited
            chen += 2.0
        if abs(hole_ranks[0] - hole_ranks[1]) == 1:  # connected
            chen += 1.0
        elif abs(hole_ranks[0] - hole_ranks[1]) == 2:
            chen += 0.5
        strength = min(1.0, chen / 10.0)
    else:
        strength = min(1.0, strength)

    # Adjust upwards with more community cards
    if len(community_cards) >= 3 and (flush_draw or straight_draw or rank_type >= 2):
        strength = max(strength, 0.4)

    return strength

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = None
        self.big_blind_amount = 0
        self.starting_chips = 10000
        self.position = {}  # track player positions
        self.own_position = None
        self.hand_history = []  # track actions per hand

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.hole_cards = player_hands
        # Clear history
        self.hand_history = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per round
        self.hand_history.append({'actions': [], 'pot': 0})

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Determine current player index and our ID
        current_player_ids = round_state.current_player
        if self.id not in current_player_ids:
            return PokerAction.FOLD, 0
        
        # Extract our state
        my_bet = round_state.player_bets.get(str(self.id), 0)
        pot = round_state.pot
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        community_cards = round_state.community_cards

        # Calculate amount needed to call
        to_call = current_bet - my_bet if current_bet > my_bet else 0

        # Evaluate hand strength
        hand_strength = evaluate_hand_strength(self.hole_cards, community_cards)

        # Determine round stage
        is_preflop = round_state.round == 'Preflop'
        is_flop = round_state.round == 'Flop'
        is_turn = round_state.round == 'Turn'
        is_river = round_state.round == 'River'

        # Position logic: early, middle, late
        all_players_list = list(round_state.player_bets.keys())
        try:
            own_index = all_players_list.index(str(self.id))
            total_players = len(all_players_list)
            # Assume position based on index (last is dealer, effectively late position)
            self.own_position = own_index / max(total_players, 1)
        except:
            self.own_position = 0.5  # default middle

        # Stack to pot ratio
        stack_to_pot = remaining_chips / (pot + 1)  # +1 to avoid div0

        # Action decisions
        if to_call == 0:
            # We can check
            if hand_strength > 0.3:
                # Raise with decent hands
                if is_preflop:
                    if hand_strength > 0.7:
                        # Strong preflop hands: raise bigger
                        raise_amount = min(remaining_chips, int(pot * 0.7))
                        raise_amount = max(min_raise, raise_amount)
                        return PokerAction.RAISE, raise_amount
                    elif hand_strength > 0.4:
                        # Medium: small raise
                        raise_amount = min(remaining_chips, big_blind_amount * 3)
                        raise_amount = max(min_raise, raise_amount)
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Post-flop value betting
                    if hand_strength > 0.6:
                        bet_size = int(pot * 0.6)
                        bet_size = min(max(min_raise, bet_size), remaining_chips)
                        return PokerAction.RAISE, bet_size
                    else:
                        # Check with draw or bluff potential occasionally
                        return PokerAction.CHECK, 0
            else:
                # Weak hand, check
                return PokerAction.CHECK, 0
        else:
            # Must call or raise
            call_ratio = to_call / (pot + to_call + 1)  # +1 to avoid div0
            pot_odds = to_call / (pot + to_call + 1)
            equity_required = pot_odds
            
            # Aggressive adjustment: call more on draws or position or strength
            can_call = to_call <= remaining_chips
            can_raise = remaining_chips > min_raise

            # Bluff catching: if we are on later streets with medium hand
            showdown_value = hand_strength > 0.35 and call_ratio < 0.5

            if hand_strength > equity_required + 0.2 or showdown_value:
                if can_raise and hand_strength > 0.65 and call_ratio < 0.4 and not is_preflop:
                    # Raise for value
                    raise_amount = min(remaining_chips, int(pot * 0.8))
                    raise_amount = max(min_raise, raise_amount)
                    return PokerAction.RAISE, raise_amount
                elif can_call:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN if remaining_chips > 0 else PokerAction.FOLD
            elif hand_strength > 0.4 and (is_flop or is_turn) and pot < remaining_chips * 5:
                # Call with draw potential
                if call_ratio < 0.4:
                    return PokerAction.CALL, 0
                elif call_ratio < 0.6 and stack_to_pot > 5:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD
            elif hand_strength > 0.6 and is_preflop:
                # Strong preflop hand, willing to commit
                if to_call <= remaining_chips * 0.2 or (to_call <= big_blind_amount * 10):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.RAISE, min(remaining_chips, max(min_raise, to_call * 2))
            else:
                # Fold otherwise
                return PokerAction.FOLD, 0

        # Default safe action
        if to_call == 0:
            return PokerAction.CHECK, 0
        elif to_call > remaining_chips:
            return PokerAction.FOLD, 0
        elif to_call <= remaining_chips:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Log round end
        if self.hand_history:
            self.hand_history[-1]['pot'] = round_state.pot

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: analyze final results
        pass