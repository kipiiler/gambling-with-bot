from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.current_position = None
        self.player_count = 0
        self.stack_size = 10000
        self.is_big_blind = False
        self.is_small_blind = False
        self.starting_chips = 10000
        # Track opponent tendencies if possible in future versions
        self.opponent_action_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.stack_size = starting_chips
        self.hole_cards = player_hands
        self.player_count = len(all_players)
        
        # Determine our position based on blinds
        self.is_big_blind = self.id == big_blind_player_id
        self.is_small_bb = self.id == small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        # Reset any round-specific state if needed
        pass

    def hand_strength_preflop(self) -> float:
        """Evaluate preflop hand strength based on hole cards."""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.1  # Very weak if no cards

        card1, card2 = self.hole_cards
        rank1, rank2 = card1[0], card2[0]
        suit1, suit2 = card1[1], card2[1]

        # Map card ranks to values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        v1, v2 = rank_values.get(rank1, 0), rank_values.get(rank2, 0)

        # Sort high to low
        high, low = max(v1, v2), min(v1, v2)
        
        # Base score
        score = 0.0

        # Pocket pairs
        if v1 == v2:
            score += 0.3 + (high / 100)
        # High cards
        if high >= 11:  # J, Q, K, A
            score += 0.1
        if high == 14:  # Ace
            score += 0.1
        if low >= 11:
            score += 0.05
        # Suited
        if suit1 == suit2:
            score += 0.1
        # Connected
        if abs(v1 - v2) == 1:
            score += 0.05
        elif abs(v1 - v2) == 2:
            score += 0.04
        elif abs(v1 - v2) == 3:
            score += 0.03
        # Ace with any face/small
        if high == 14 and low >= 9:
            score += 0.05
            
        return min(score, 1.0)

    def pot_odds_percentage(self, round_state: RoundStateClient) -> float:
        """Calculate pot odds as percentage needed to call."""
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        total_pot_after_call = round_state.pot + to_call
        
        if total_pot_after_call <= 0:
            return 0.0
        return to_call / total_pot_after_call if to_call > 0 else 0.0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player based on hand strength and game state."""
        self.stack_size = remaining_chips
        pot = round_state.pot
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet

        # Handle pre-flop, flop, etc. differently
        if round_state.round == "Preflop":
            strength = self.hand_strength_preflop()
        else:
            # For now, use preflop strength as placeholder
            # Future improvement: implement post-flop hand evaluation
            strength = self.hand_strength_preflop()
            # On post-flop, adjust based on board texture (skipping for now)

        # If we can check
        if current_bet == my_current_bet:
            # Always check if strength is low
            if strength < 0.2:
                return (PokerAction.CHECK, 0)
            elif strength < 0.4:
                # Check or small bet
                if remaining_chips > 50:
                    bet_amount = min(50, int(pot * 0.5), max_raise)
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Strong hand: bet
                bet_amount = min(int(pot * 0.75), max_raise)
                bet_amount = max(bet_amount, min_raise)  # Respect minimum raise
                return (PokerAction.RAISE, bet_amount)
                
        else:
            # We must respond to a bet
            if to_call <= 0:
                return (PokerAction.CHECK, 0)
                
            # Pot odds
            pot_odds = self.pot_odds_percentage(round_state)
            call_percentage = to_call / (pot + to_call) if (pot + to_call) > 0 else 1.0

            # Fold if weak hand and high pot odds required
            if strength < 0.15:
                return (PokerAction.FOLD, 0)
            if strength < 0.25 and call_percentage > 0.3:
                return (PokerAction.FOLD, 0)
            if strength < 0.35 and call_percentage > 0.5:
                return (PokerAction.FOLD, 0)

            # Call if getting decent odds
            if strength >= 0.3 and call_percentage <= 0.5:
                return (PokerAction.CALL, 0)
            if strength >= 0.4:
                # Raise with strong hands
                raise_amount = min(int(pot * 1.0), remaining_chips)
                raise_amount = max(raise_amount, min_raise)
                raise_amount = min(raise_amount, max_raise)
                return (PokerAction.RAISE, raise_amount)
            
            # Default to call with medium-strength hands
            return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update stack
        self.stack_size = remaining_chips
        # Could analyze showdown here in future
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or learning if state preserved
        pass