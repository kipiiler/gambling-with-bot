from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.current_hand_strength = 0.0
        self.positional_advantage = 0
        self.tight_aggressive_factor = 0.7
        self.tight_aggressive_threshold = 0.6
        self.volatility_factor = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Estimate hand strength based on hole cards and stage
        if len(self.player_hands) < 2:
            return
        
        hole_cards = self.player_hands[-2:]  # assume last two are current hole cards
        hole_ranks = [self.card_rank(c[0]) for c in hole_cards]
        hole_suits = [c[1] for c in hole_cards]
        
        hand_power = self.evaluate_hole_card_power(hole_cards)
        stage_factor = self.get_stage_factor(round_state.round)
        num_opponents = len(round_state.current_player) - 1
        opponents_factor = 1.0 / (1 + num_opponents * 0.3)

        self.current_hand_strength = hand_power * stage_factor * opponents_factor
        self.update_positional_advantage(round_state)
        self.adjust_volatility(round_state, remaining_chips)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands[-2:] if len(self.player_hands) >= 2 else []
        pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
        implied_odds_multiplier = 1.5
        effective_stack = min(remaining_chips, round_state.max_raise)
        min_raise_amount = max(round_state.min_raise, 2 * round_state.current_bet if round_state.current_bet > 0 else self.blind_amount * 2)

        # Fold if we have no chance
        if self.current_hand_strength < 0.1 and round_state.current_bet > 0:
            return (PokerAction.FOLD, 0)

        # All-in if very strong hand and deep stack
        if self.current_hand_strength > 0.9 and effective_stack > self.blind_amount * 20:
            return (PokerAction.ALL_IN, 0)

        # Adjust aggression based on position and volatility
        aggression = self.current_hand_strength * self.positional_advantage * self.volatility_factor
        call_threshold = 0.3 + self.tight_aggressive_factor * 0.2
        raise_threshold = 0.5 + self.tight_aggressive_factor * 0.3

        # Prevent invalid actions
        if round_state.current_bet == 0:
            if aggression > raise_threshold and remaining_chips >= min_raise_amount:
                raise_amount = min(
                    max(min_raise_amount, int(effective_stack * 0.5)),
                    round_state.max_raise
                )
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Evaluate whether to call based on pot odds
            if pot_odds > 0 and self.current_hand_strength > pot_odds / (pot_odds + 1) * 0.8:
                if aggression > raise_threshold and remaining_chips >= min_raise_amount:
                    raise_amount = min(
                        max(min_raise_amount, int(round_state.pot * 0.75)),
                        round_state.max_raise
                    )
                    return (PokerAction.RAISE, raise_amount)
                elif remaining_chips >= max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0)):
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update strategy based on outcome (simple learning simulation)
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up if needed
        pass

    def card_rank(self, rank: str) -> int:
        """Convert card rank to numerical value"""
        rank_vals = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_vals.get(rank.upper(), 0)

    def evaluate_hole_card_power(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.1
        
        r1, s1 = self.card_rank(hole_cards[0][0]), hole_cards[0][1]
        r2, s2 = self.card_rank(hole_cards[1][0]), hole_cards[1][1]

        # Pair bonus
        if r1 == r2:
            return min(0.9, 0.3 + (r1 - 2) * 0.05)

        # Suited bonus
        suited_bonus = 0.1 if s1 == s2 else 0

        # Connectors bonus
        gap = abs(r1 - r2)
        connector_bonus = 0.05 if gap == 1 else 0.02 if gap == 2 else 0.01 if gap == 3 else 0

        # High card strength
        high_card = max(r1, r2)
        low_card = min(r1, r2)
        high_card_power = (high_card - 2) * 0.05
        low_card_power = (low_card - 2) * 0.02

        # Premium hands
        if high_card == 14 and low_card >= 10:  # AK, AQ, AJ, AT
            return 0.7 + suited_bonus + 0.1
        if high_card == 13 and low_card == 12:  # KQ
            return 0.6 + suited_bonus

        base = high_card_power + low_card_power + suited_bonus + connector_bonus
        return min(base, 0.8)

    def get_stage_factor(self, current_round: str) -> float:
        stage_multipliers = {
            'Preflop': 1.0,
            'Flop': 0.9,
            'Turn': 0.8,
            'River': 0.7
        }
        return stage_multipliers.get(current_round, 1.0)

    def update_positional_advantage(self, round_state: RoundStateClient):
        # Estimate position: later is better
        current_players = round_state.current_player
        if self.id is None or self.id not in current_players:
            self.positional_advantage = 0.5
            return

        pos_index = current_players.index(self.id)
        total_players = len(current_players)
        # Later position has higher advantage (0.5 to 1.5)
        self.positional_advantage = 0.5 + (pos_index / max(1, total_players - 1)) * 1.0

    def adjust_volatility(self, round_state: RoundStateClient, remaining_chips: int):
        # More volatile when short stacked or near blinds increase
        chip_coverage = remaining_chips / (self.blind_amount * 2 + 1e-8)  # Avoid div by zero
        volatility = 1.0
        if chip_coverage < 10:
            volatility = 2.0
        elif chip_coverage < 20:
            volatility = 1.5
        self.volatility_factor = volatility

    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        # Pot odds = (amount to call) / (pot + amount to call)
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet

        if to_call <= 0:
            return float('inf')

        effective_call = min(to_call, remaining_chips)
        total_pot_after_call = round_state.pot + effective_call

        if total_pot_after_call == 0:
            return 0.0

        return effective_call / total_pot_after_call