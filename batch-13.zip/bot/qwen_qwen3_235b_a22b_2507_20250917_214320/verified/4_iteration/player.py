from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_stack = 10000
        self.current_round = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.our_position = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_stack = starting_chips
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        if self.id is not None:
            self.our_position = all_players.index(self.id)
        if str(self.id) in player_hands:
            self.hole_cards = player_hands[str(self.id)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round_num
        # Reset hole cards if needed? Or they persist?
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Use a small epsilon to avoid division by zero
        EPS = 1e-8
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_id_str = str(self.id)
        our_current_bet = round_state.player_bets.get(player_id_str, 0)
        call_amount = current_bet - our_current_bet

        # Determine the round
        round_name = round_state.round

        # Estimate hand strength (simplified)
        hand_rank = self.estimate_hand_strength(self.hole_cards, community_cards)

        # Position: early, middle, late
        num_players = len(round_state.current_player)
        our_seat_index = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
        position = self.get_position(our_seat_index, num_players)

        # Fold if can't afford the call and not already all-in
        if call_amount > remaining_chips and remaining_chips > 0:
            return PokerAction.FOLD, 0

        # If the current bet is 0 (no one raised), we can check
        if current_bet == our_current_bet:
            # Check or bet
            if round_name == 'Preflop':
                # Preflop: play tight from early, open from late
                if hand_rank > 0.8:
                    # Strong hand: raise
                    raise_amount = min(remaining_chips, max(2 * min_raise, pot // 4))
                    return PokerAction.RAISE, raise_amount
                elif hand_rank > 0.6 and position in ['late', 'middle']:
                    # Medium hand in good position: raise or call
                    if random.random() < 0.7:
                        raise_amount = min(remaining_chips, max(min_raise, 2 * blind_from_state(round_state)))
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                elif hand_rank > 0.4 and position == 'late':
                    # Small raise or call
                    if remaining_chips > 10:
                        raise_amount = min(remaining_chips, max(min_raise, 2 * blind_from_state(round_state)))
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Post-flop: check or bet
                if hand_rank > 0.7:
                    # Strong hand: bet
                    bet_size = min(remaining_chips, max(min_raise, int(pot * 0.5)))
                    return PokerAction.RAISE, bet_size
                elif hand_rank > 0.4:
                    # Draw or medium: small bet or check
                    if random.random() < 0.3 and remaining_chips > 10:
                        bet_size = min(remaining_chips, max(min_raise, int(pot * 0.3)))
                        return PokerAction.RAISE, bet_size
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
        else:
            # Someone raised: fold, call, or re-raise
            pot_odds = call_amount / (pot + call_amount + EPS)
            equity = hand_rank

            # Simple decision: call if equity > pot_odds, with some buffer
            if equity > pot_odds * 1.3:
                if hand_rank > 0.8 and random.random() < 0.6:
                    # Re-raise strong hand
                    raise_amount = min(remaining_chips,
                                       max(min_raise, call_amount + max(min_raise, int(pot * 0.7))))
                    return PokerAction.RAISE, raise_amount
                else:
                    # Call
                    if call_amount == 0:
                        return PokerAction.CHECK, 0
                    elif call_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.CALL, 0
            elif equity > pot_odds * 0.8 and random.random() < 0.3:
                # Bluff or float occasionally
                if remaining_chips > 10:
                    raise_amount = min(remaining_chips, max(min_raise, int(pot * 0.5)))
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            else:
                # Fold weak hand
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up or track
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict,
                    active_players_hands: dict):
        # Final cleanup
        pass

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Estimate hand strength based on hole cards and community cards.
        Returns a value between 0 and 1.
        """
        if not hole_cards:
            return 0.1

        # Parse cards
        all_cards = hole_cards + community_cards
        ranks = [card[0:-1] for card in all_cards]
        suits = [card[-1] for card in all_cards]

        # Convert ranks to numbers
        rank_values = []
        for r in ranks:
            if r == 'A':
                rank_values.append(14)
            elif r == 'K':
                rank_values.append(13)
            elif r == 'Q':
                rank_values.append(12)
            elif r == 'J':
                rank_values.append(11)
            elif r == 'T':
                rank_values.append(10)
            else:
                rank_values.append(int(r))

        # Pair detection
        rank_count = {}
        for r in rank_values:
            rank_count[r] = rank_count.get(r, 0) + 1

        pairs = sum(1 for count in rank_count.values() if count == 2)
        trips = sum(1 for count in rank_count.values() if count == 3)
        quads = sum(1 for count in rank_count.values() if count == 4)

        # Flush check
        flush = any(suits.count(s) >= 5 for s in set(suits))

        # Straight check
        sorted_ranks = sorted(set(rank_values))
        straight = False
        if len(sorted_ranks) >= 5:
            seq = 1
            for i in range(1, len(sorted_ranks)):
                if sorted_ranks[i] == sorted_ranks[i - 1] + 1:
                    seq += 1
                    if seq >= 5:
                        straight = True
                        break
                else:
                    seq = 1
        # Special case: A-5 straight
        if set([14, 2, 3, 4, 5]).issubset(set(rank_values)):
            straight = True

        # High card
        hole_rank_vals = rank_values[:2]
        hole_high = max(hole_rank_vals)
        hole_low = min(hole_rank_vals)

        # Preflop strength (if no community cards)
        if len(community_cards) == 0:
            # Pocket pairs
            if hole_cards[0][0:-1] == hole_cards[1][0:-1]:
                pair_rank = hole_rank_vals[0]
                if pair_rank >= 10:
                    return 0.8
                elif pair_rank >= 7:
                    return 0.7
                elif pair_rank >= 5:
                    return 0.6
                else:
                    return 0.5
            # Suited connectors
            elif hole_cards[0][-1] == hole_cards[1][-1] and abs(hole_rank_vals[0] - hole_rank_vals[1]) == 1:
                return 0.6
            # Suited aces
            elif hole_cards[0][-1] == hole_cards[1][-1] and (14 in hole_rank_vals):
                return 0.55
            # Any ace
            elif 14 in hole_rank_vals:
                return 0.5
            # Other high cards
            elif hole_high >= 11:
                return 0.4
            # Connected cards
            elif abs(hole_rank_vals[0] - hole_rank_vals[1]) == 1:
                return 0.35
            else:
                return 0.2

        # Post-flop hand strength estimation
        if quads:
            return 0.95
        if trips and pairs:  # Full house
            return 0.9
        if flush:
            return 0.85
        if straight:
            return 0.8
        if trips:
            return 0.7
        if pairs == 2:
            return 0.6
        if pairs == 1:
            # Pair strength depends on rank
            paired_rank = next(r for r, c in rank_count.items() if c == 2)
            if paired_rank >= hole_high and paired_rank >= 10:
                return 0.55
            elif paired_rank >= hole_high:
                return 0.5
            else:
                return 0.4
        # High card
        kickers = sorted([r for r in hole_rank_vals if r != hole_low], reverse=True)[:2]
        high_card_strength = (hole_high - 2) / 12.0
        return 0.1 + high_card_strength * 0.2 + len([k for k in kickers if k > 10]) * 0.1

    def get_position(self, seat_index: int, num_players: int) -> str:
        if num_players <= 2:
            return 'late'
        elif seat_index >= num_players - 2:
            return 'late'
        elif seat_index >= num_players // 2:
            return 'middle'
        else:
            return 'early'


def blind_from_state(round_state: RoundStateClient) -> int:
    # Estimate blind as the smaller blind posted
    if not round_state.player_bets:
        return 5
    bets = list(round_state.player_bets.values())
    if len(bets) == 0:
        return 5
    min_nonzero = min((b for b in bets if b > 0), default=5)
    return min(min_nonzero, 10)