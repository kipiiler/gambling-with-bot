from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.current_round = None
        self.is_big_blind = False
        self.is_small_blind = False
        self.position_tier = 0  # 0=early, 1=middle, 2=late
        self.tight_aggressive_factor = 1.0  # Dynamic adjustment for aggression
        self.hand_strength_estimate = 0.0
        self.previous_bet_size = 0
        self.voluntary_put_in_pot = 0  # Track how often we voluntarily bet/call
        self.hands_played = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): None for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.hands_played += 1
        # Adjust aggression based on stack and game phase
        chip_threshold = 8000
        if remaining_chips < chip_threshold:
            self.tight_aggressive_factor = 1.3  # More aggressive when short stacked
        else:
            self.tight_aggressive_factor = 1.0  # Play tighter when deep stacked

        # Estimate position tier (simplified)
        current_pid = self.id
        current_idx = self.all_players.index(current_pid)
        total_players = len(self.all_players)
        if current_idx >= total_players - 2:
            self.position_tier = 2  # Late position
        elif current_idx >= total_players // 2:
            self.position_tier = 1  # Middle
        else:
            self.position_tier = 0  # Early

        # Reset hand-specific state
        self.hand_strength_estimate = 0.0
        self.previous_bet_size = 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Prevent division by zero
            epsilon = 1e-8

            # Extract game state
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            player_bet = round_state.player_bets.get(str(self.id), 0)

            # Analyze hole cards and board
            hole_cards = self.player_hands.get(str(self.id))
            if not hole_cards:
                # Fallback: fold if hole cards not properly set
                return PokerAction.FOLD, 0

            # Update hand strength
            self.hand_strength_estimate = self.estimate_hand_strength(hole_cards, community_cards)

            # Normalize pot odds and equity
            cost_to_call = current_bet - player_bet
            pot_odds = cost_to_call / (pot + cost_to_call + epsilon)
            equity = self.hand_strength_estimate

            # Decision logic based on round and hand strength
            action, amount = PokerAction.FOLD, 0

            if round_state.round == 'Preflop':
                action, amount = self.preflop_strategy(hole_cards, cost_to_call, pot, remaining_chips, min_raise)
            elif round_state.round == 'Flop':
                action, amount = self.postflop_strategy(hole_cards, community_cards, cost_to_call, pot, remaining_chips, min_raise, equity, pot_odds)
            elif round_state.round == 'Turn':
                action, amount = self.postflop_strategy(hole_cards, community_cards, cost_to_call, pot, remaining_chips, min_raise, equity, pot_odds)
            elif round_state.round == 'River':
                action, amount = self.river_strategy(hole_cards, community_cards, cost_to_call, pot, remaining_chips, min_raise, equity, pot_odds)

            # Validate action
            if action == PokerAction.RAISE:
                # Ensure raise is valid: amount >= min_raise and <= max_raise
                if amount < min_raise:
                    amount = min_raise
                if amount > max_raise:
                    # Downgrade to all-in if we want to raise more than allowed
                    action = PokerAction.ALL_IN
                    amount = remaining_chips
                # Final clamp
                amount = max(min(amount, max_raise), min_raise)
            elif action == PokerAction.ALL_IN:
                amount = remaining_chips
            elif action == PokerAction.CALL:
                if cost_to_call == 0:
                    action = PokerAction.CHECK
            elif action == PokerAction.CHECK:
                if cost_to_call > 0:
                    action = PokerAction.CALL  # Cannot check when there's a bet

            return action, amount

        except Exception as e:
            # On any error, fold to avoid crash
            return PokerAction.FOLD, 0

    def preflop_strategy(self, hole_cards: List[str], cost_to_call: int, pot: int, remaining_chips: int, min_raise: int) -> Tuple[PokerAction, int]:
        rank_order = "23456789TJQKA"
        card1, card2 = hole_cards[0][0], hole_cards[1][0]
        suit1, suit2 = hole_cards[0][1], hole_cards[1][1]
        rank1, rank2 = rank_order.index(card1), rank_order.index(card2)

        # Gap heuristic & hand groups
        is_suited = suit1 == suit2
        is_pair = card1 == card2
        high_card = max(rank1, rank2)
        low_card = min(rank1, rank2)
        gap = high_card - low_card

        # Predefined hand ranges (tight aggressive)
        if is_pair or high_card >= 10:  # Premium pairs and broadways
            power = 3
        elif is_suited and gap <= 3:  # Suited connectors
            power = 2
        elif is_suited and high_card >= 9:  # Suited aces/kings
            power = 2
        elif gap <= 1 and low_card >= 8:  # Connected big cards
            power = 2
        elif high_card >= 11:  # High cards
            power = 1
        else:
            power = 0

        # Position boost
        if self.position_tier == 2:  # Late
            power += 1
        elif self.position_tier == 1:  # Middle
            pass
        else:  # Early
            if power < 2:
                power = 0  # Fold marginal hands early

        # Stack and aggression adjustment
        can_3bet = remaining_chips > 3 * self.blind_amount * 2

        # Action mapping
        invested = self.blind_amount
        if self.is_big_blind:
            invested = self.blind_amount * 2
        elif self.is_small_blind:
            invested = self.blind_amount

        if cost_to_call == 0:
            if power >= 2:
                raise_amount = min(3 * min_raise, remaining_chips)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            effective_cost = cost_to_call / (self.starting_chips + epsilon)
            if power >= 3:
                if can_3bet and cost_to_call > self.blind_amount:
                    raise_amount = min(3 * cost_to_call, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif power == 2:
                if effective_cost < 0.05:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if self.is_big_blind and cost_to_call == self.blind_amount:
                    return PokerAction.CALL, 0  # Floating BB
                return PokerAction.FOLD, 0

    def postflop_strategy(self, hole_cards: List[str], community_cards: List[str], cost_to_call: int, pot: int, remaining_chips: int, min_raise: int, equity: float, pot_odds: float):
        # Estimate improvement potential and bet accordingly
        hand_type = self.evaluate_hand(hole_cards, community_cards)
        made_hand = hand_type >= 3  # One pair or better
        draw = equity > 0.35 and not made_hand
        semi_bluff = draw and random.random() < 0.4

        # Bet sizing logic
        min_bet = max(min_raise, pot // 4)
        half_pot = max(min_bet, pot // 2)
        full_pot = max(min_bet, pot)
        bet_size = min(half_pot, remaining_chips)

        if cost_to_call == 0:
            if equity > 0.4 or made_hand:
                return PokerAction.RAISE, bet_size
            elif random.random() < 0.3 and len(community_cards) == 3:
                return PokerAction.RAISE, min_bet  # Probe bluff on dry board
            else:
                return PokerAction.CHECK, 0
        else:
            # Call if we have pot odds or are semi-bluffing
            if equity > pot_odds or semi_bluff:
                if equity > 0.6 and pot < 3 * self.starting_chips:
                    raise_amount = min(full_pot, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                elif cost_to_call <= half_pot:
                    return PokerAction.CALL, 0
                else:
                    if equity > 0.5 or random.random() < 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0

    def river_strategy(self, hole_cards: List[str], community_cards: List[str], cost_to_call: int, pot: int, remaining_chips: int, min_raise: int, equity: float, pot_odds: float):
        hand_type = self.evaluate_hand(hole_cards, community_cards)
        made_hand = hand_type >= 3
        value_threshold = 0.55

        if cost_to_call == 0:
            if equity > 0.5:
                bet_size = min(pot, remaining_chips)
                return PokerAction.RAISE, bet_size
            else:
                return PokerAction.CHECK, 0
        else:
            # Final decision: call if equity > pot odds with small buffer
            call_threshold = pot_odds - 0.05
            if equity > call_threshold:
                if equity > value_threshold and cost_to_call < pot:
                    raise_amount = min(pot, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if len(community_cards) == 0:
            return self.preflop_equity_estimator(hole_cards)
        else:
            return self.simulate_equity(hole_cards, community_cards, n=50)

    def preflop_equity_estimator(self, hole_cards: List[str]) -> float:
        # Simplified Sklansky hand groups based equity estimate
        rank_order = "23456789TJQKA"
        card1, card2 = hole_cards[0][0], hole_cards[1][0]
        suit1, suit2 = hole_cards[0][1], hole_cards[1][1]
        rank1, rank2 = rank_order.index(card1), rank_order.index(card2)

        is_suited = suit1 == suit2
        is_pair = card1 == card2
        high_card = max(rank1, rank2)
        gap = abs(rank1 - rank2)

        score = 0
        if is_pair:
            score = 10 + high_card
        else:
            if high_card >= 10:
                score += 5
            if is_suited:
                score += 2
            if gap <= 1:
                score += 3
            elif gap == 2:
                score += 2
            elif gap == 3:
                score += 1
            if high_card == 12 or high_card == 13:  # A or K
                score += 3

        # Normalize score to equity (approx)
        normalized = score / 30.0  # Rough max score ~25
        return max(min(normalized, 0.9), 0.3)  # Clamp between 0.3 and 0.9

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> int:
        # Returns hand type strength: 0=high card, 1=pair, 2=two pair, 3=trip, 4=straight, 5=flush, 6=full house, 7=quads, 8=straight flush
        cards = hole_cards + community_cards
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]

        # Count ranks and suits
        rank_count = {r: ranks.count(r) for r in set(ranks)}
        suit_count = {s: suits.count(s) for s in set(suits)}

        rank_vals = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
        sorted_ranks = sorted(set(rank_vals[r] for r in ranks), reverse=True)

        # Check flush
        flush = any(sc >= 5 for sc in suit_count.values())
        flush_suit = None
        if flush:
            flush_suit = next(s for s, sc in suit_count.items() if sc >= 5)
            flush_cards = sorted([rank_vals[r] for r, s in zip(ranks, suits) if s == flush_suit], reverse=True)

        # Check straight
        unique_ranks = sorted(set(rank_vals[r] for r in ranks))
        straight = False
        if 12 in unique_ranks:  # Ace
            unique_ranks = [12] + unique_ranks  # For A-5 straight
        for i in range(len(unique_ranks) - 4):
            if all(unique_ranks[i + k] == unique_ranks[i] + k for k in range(5)):
                straight = True
                straight_high = unique_ranks[i] + 4
                break

        # Assign hand type
        pairs = sum(1 for r in rank_count.values() if r == 2)
        trips = sum(1 for r in rank_count.values() if r == 3)
        quads = sum(1 for r in rank_count.values() if r == 4)

        if flush and straight:
            return 8  # Straight flush
        elif quads > 0:
            return 7
        elif trips > 0 and pairs > 0 or trips >= 2:
            return 6  # Full house
        elif flush:
            return 5
        elif straight:
            return 4
        elif trips > 0:
            return 3
        elif pairs >= 2:
            return 2
        elif pairs == 1:
            return 1
        else:
            return 0

    def simulate_equity(self, hole_cards: List[str], community_cards: List[str], n: int = 50) -> float:
        # Very lightweight Monte Carlo simulation for equity estimation against random hands
        if len(community_cards) == 5:
            return self.hand_value_at_showdown(hole_cards, community_cards)

        # Simulate n random runouts
        deck = self.generate_deck_excluding(hole_cards + community_cards)
        wins = 0
        total = 0

        for _ in range(n):
            simulated_board = community_cards.copy()
            needed = 5 - len(community_cards)
            if len(deck) < needed:
                break
            burn = random.sample(deck, needed)
            for card in burn:
                deck.remove(card)
            simulated_board += burn

            my_value = self.evaluate_hand_value(hole_cards, simulated_board)
            opponent_hole = random.sample(deck, 2)
            opponent_value = self.evaluate_hand_value(opponent_hole, simulated_board)

            if my_value > opponent_value:
                wins += 1
            total += 1

            # Return partial if deck runs low
            deck += burn

        return wins / (total + 1e-8)

    def generate_deck_excluding(self, excluded: List[str]) -> List[str]:
        suits = 'shdc'
        ranks = '23456789TJQKA'
        deck = [r + s for s in suits for r in ranks]
        for card in excluded:
            if card in deck:
                deck.remove(card)
        return deck

    def evaluate_hand_value(self, hole_cards: List[str], community_cards: List[str]) -> int:
        # Combines hole + community and returns comparable score
        all_cards = hole_cards + community_cards
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]

        rank_vals = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
        num_ranks = [rank_vals[r] for r in ranks]

        from collections import Counter
        rank_count = Counter(num_ranks)
        count_rank = {}
        for r, c in rank_count.items():
            if c not in count_rank:
                count_rank[c] = []
            count_rank[c].append(r)

        # Sort each group descending
        for k in count_rank:
            count_rank[k].sort(reverse=True)

        suit_count = Counter(suits)
        has_flush = any(c >= 5 for c in suit_count.values())
        flush_suit = None
        if has_flush:
            for s in suit_count:
                if suit_count[s] >= 5:
                    flush_suit = s
                    break
            flush_ranks = sorted([rank_vals[r] for r, s in zip(ranks, suits) if s == flush_suit], reverse=True)

        # Check straight
        unique_ranks = sorted(set(num_ranks))
        if 12 in unique_ranks:  # Ace
            unique_ranks = [12] + unique_ranks  # A-5
        straight_high = None
        for i in range(len(unique_ranks) - 4):
            if all(unique_ranks[i + k] == unique_ranks[i] + k for k in range(5)):
                straight_high = unique_ranks[i] + 4
                break

        score = 0

        # Straight flush
        if has_flush and straight_high is not None:
            flush_ranks_on_suit = sorted([r for r, s in zip(num_ranks, suits) if s == flush_suit], reverse=True)
            for i in range(len(flush_ranks_on_suit) - 4):
                if all(flush_ranks_on_suit[i + k] == flush_ranks_on_suit[i] + k for k in range(5)):
                    score = 8 * (13**5) + sum(flush_ranks_on_suit[i+k] * (13**(4-k)) for k in range(5))
                    return score

        # Four of a kind
        if 4 in count_rank:
            quads = count_rank[4][0]
            kickers = sorted([r for r in num_ranks if r != quads], reverse=True)[:1]
            score = 7 * (13**5) + quads * (13**4)
            for i, k in enumerate(kickers):
                score += k * (13**(3-i))
            return score

        # Full house
        if 3 in count_rank and len(count_rank[3]) >= 2:
            trips = count_rank[3][0]
            pair = count_rank[3][1]
            score = 6 * (13**5) + trips * (13**4) + pair * (13**3)
            return score
        if 3 in count_rank and 2 in count_rank:
            trips = count_rank[3][0]
            pair = count_rank[2][0]
            score = 6 * (13**5) + trips * (13**4) + pair * (13**3)
            return score

        # Flush
        if has_flush:
            score = 5 * (13**5) + sum(flush_ranks[i] * (13**(4-i)) for i in range(5))
            return score

        # Straight
        if straight_high is not None:
            score = 4 * (13**5) + straight_high * (13**4)
            return score

        # Three of a kind
        if 3 in count_rank:
            trips = count_rank[3][0]
            kickers = sorted([r for r in num_ranks if r != trips], reverse=True)[:2]
            score = 3 * (13**5) + trips * (13**4)
            for i, k in enumerate(kickers):
                score += k * (13**(3-i))
            return score

        # Two pair
        if 2 in count_rank and len(count_rank[2]) >= 2:
            pairs = sorted(count_rank[2], reverse=True)[:2]
            kickers = sorted([r for r in num_ranks if r not in pairs], reverse=True)[:1]
            score = 2 * (13**5) + pairs[0] * (13**4) + pairs[1] * (13**3) + kickers[0] * (13**2)
            return score

        # One pair
        if 2 in count_rank:
            pair_val = count_rank[2][0]
            kickers = sorted([r for r in num_ranks if r != pair_val], reverse=True)[:3]
            score = 1 * (13**5) + pair_val * (13**4)
            for i, k in enumerate(kickers):
                score += k * (13**(3-i))
            return score

        # High card
        kickers = sorted(num_ranks, reverse=True)[:5]
        score = 0
        for i, k in enumerate(kickers):
            score += k * (13**(4-i))
        return score

    def hand_value_at_showdown(self, hole_cards: List[str], community_cards: List[str]) -> float:
        my_value = self.evaluate_hand_value(hole_cards, community_cards)
        # Simplified opponent comparison
        wins = 0
        total = 0
        deck = self.generate_deck_excluding(hole_cards + community_cards)
        for _ in range(30):
            if len(deck) < 2:
                break
            opp = random.sample(deck, 2)
            opp_value = self.evaluate_hand_value(opp, community_cards)
            if my_value > opp_value:
                wins += 1
            total += 1
        return wins / (total + 1e-8)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used for learning or stats tracking
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or reflection
        pass