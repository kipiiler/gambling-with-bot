from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.player_id = None
        self.starting_chips = 0
        self.player_index = -1
        self.all_players = []
        self.preflop_groups = {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs', 'AKo'],
            2: ['AQs', 'TT', '99', '88', 'AJo', 'KQs', 'AJs', 'ATs', 'KQo', 'QJs', 'JTs'],
            3: ['77', '66', '55', '44', '33', '22', 'ATo', 'KJo', 'QJo', 'JTo', 'T9s', '98s', '87s', '76s', '65s', '54s', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 'K9s', 'QTs', 'J9s', 'T8s', '97s', '86s', '75s', '64s', '53s']
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.player_index = all_players.index(self.player_id) if self.player_id is not None else -1
        
        if player_hands and 0 <= self.player_index < len(all_players):
            start_idx = 2 * self.player_index
            if start_idx + 1 < len(player_hands):
                self.hole_cards = [player_hands[start_idx], player_hands[start_idx+1]]
            else:
                self.hole_cards = []
        else:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_preflop_hand_group(self) -> int:
        if len(self.hole_cards) < 2:
            return 4
            
        rank_order = "AKQJT98765432"
        card1, card2 = self.hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        if rank1 == rank2:
            hand_str = rank1 + rank2
            for group, hands in self.preflop_groups.items():
                if hand_str in hands:
                    return group
            return 4
        
        r1_idx = rank_order.index(rank1)
        r2_idx = rank_order.index(rank2)
        if r1_idx < r2_idx:
            rank1, rank2 = rank2, rank1
        hand_base = rank1 + rank2
        hand_str = hand_base + ('s' if suit1 == suit2 else 'o')
        
        for group, hands in self.preflop_groups.items():
            if hand_str in hands:
                return group
        
        return 4

    def hand_strength(self, cards: List[str]) -> Tuple[int, ...]:
        if len(cards) < 5:
            return (0,)
        
        rank_val = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        ranks = [rank_val[c[0]] for c in cards]
        suits = [c[1] for c in cards]
        ranks.sort(reverse=True)
        
        # Flush
        suit_count = {s: suits.count(s) for s in set(suits)}
        if max(suit_count.values()) >= 5:
            flush_suit = max(suit_count, key=suit_count.get)
            flush_ranks = sorted([rank_val[c[0]] for c in cards if c[1]==flush_suit], reverse=True)[:5]
            if flush_ranks[0] == 14 and flush_ranks[1]==13 and flush_ranks[2]==12 and flush_ranks[3]==11 and flush_ranks[4]==10:
                return (9,)  # Royal flush
            if flush_ranks[0] - flush_ranks[4] == 4 and len(set(flush_ranks)) == 5:
                return (8, flush_ranks[0])  # Straight flush
            return (5, *flush_ranks)  # Flush
        
        # Straight
        unique_ranks = sorted(set(ranks), reverse=True)
        if 14 in unique_ranks:
            unique_ranks.append(1)
        straight_high = 0
        for i in range(len(unique_ranks)-4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight_high = unique_ranks[i]
        if straight_high:
            return (4, straight_high)  # Straight
        
        # Quads, full house, trips, pairs
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r,0) + 1
        counts = sorted([(cnt, r) for r, cnt in rank_count.items()], reverse=True)
        
        if counts[0][0] == 4:
            quad_rank = counts[0][1]
            kicker = max(r for r in ranks if r != quad_rank)
            return (7, quad_rank, kicker)  # Four of a kind
        if counts[0][0] == 3 and counts[1][0] >= 2:
            trips = counts[0][1]
            pair = max(r for cnt, r in counts if cnt >= 2 and r != trips)
            return (6, trips, pair)  # Full house
        if counts[0][0] == 3:
            trips = counts[0][1]
            kickers = [r for r in ranks if r != trips]
            kickers.sort(reverse=True)
            return (3, trips, kickers[0], kickers[1])  # Three of a kind
        if counts[0][0] == 2 and counts[1][0] == 2:
            pairs = sorted([r for cnt, r in counts if cnt == 2], reverse=True)[:2]
            kicker = max(r for r in ranks if r not in pairs)
            return (2, pairs[0], pairs[1], kicker)  # Two pair
        if counts[0][0] == 2:
            pair = counts[0][1]
            kickers = sorted([r for r in ranks if r != pair], reverse=True)[:3]
            return (1, pair, *kickers)  # One pair
            
        return (0, *ranks[:5])  # High card

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pid = str(self.player_id)
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(pid, 0)
        amount_to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        if round_state.round in ['Preflop']:
            hand_group = self.get_preflop_hand_group()
            if amount_to_call == 0:
                if hand_group <= 2:
                    raise_amount = min(3 * self.blind_amount, max_raise) 
                    if raise_amount > min_raise:
                        return (PokerAction.RAISE, min(raise_amount, max_raise))
                    else:
                        return (PokerAction.CALL, 0)
                return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)
            
            if amount_to_call > 0:
                if hand_group == 1:
                    return (PokerAction.RAISE, min(min_raise, max_raise))
                if hand_group == 2 and amount_to_call <= 4 * self.blind_amount:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)
        
        # Postflop strategy
        if len(self.hole_cards) == 0:
            return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)
            
        all_cards = self.hole_cards + round_state.community_cards
        score = self.hand_strength(all_cards)
        score_val = score[0] if score else 0

        if amount_to_call == 0:
            if score_val >= 7:
                raise_amt = min(max(min_raise, round_state.pot // 3), max_raise)
                if raise_amt > 0:
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CALL, 0)
            if score_val >= 5:
                return (PokerAction.CHECK, 0)
            return (PokerAction.CHECK, 0)
            
        if amount_to_call > 0:
            if score_val >= 7:
                if remaining_chips > amount_to_call:
                    raise_amt = min_raise if min_raise < max_raise else max_raise
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.ALL_IN, 0)
            if score_val >= 5:
                if amount_to_call <= round_state.pot // 4:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            if score_val >= 3 and amount_to_call <= round_state.pot // 6:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id