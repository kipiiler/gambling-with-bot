from typing import List, Tuple, Dict, Optional
import random
import time

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.initial_blind_amount: int = 0  # best guess for big blind amount at init
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.players: List[int] = []
        self.player_str_ids: List[str] = []

        # Hand/round state
        self.hand_num: int = 0
        self.current_hand_cards: Optional[List[str]] = None  # may not be populated by framework
        self.last_known_bb: int = 0  # track blind dynamically per hand
        self.random = random.Random()
        self.random.seed(int(time.time() * 1000) % (2**32 - 1))

        # Opponent modeling (lightweight)
        self.vpip: Dict[str, int] = {}   # voluntary put money in pot counts
        self.hands_seen: Dict[str, int] = {}
        self.aggression: Dict[str, int] = {}  # raises + bets counts

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize session info
        self.starting_chips = starting_chips
        self.initial_blind_amount = max(int(blind_amount), 1)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players or []
        self.player_str_ids = [str(pid) for pid in self.players]
        self.current_hand_cards = list(player_hands) if player_hands else None

        for pid in self.player_str_ids:
            if pid not in self.vpip:
                self.vpip[pid] = 0
            if pid not in self.hands_seen:
                self.hands_seen[pid] = 0
            if pid not in self.aggression:
                self.aggression[pid] = 0

        # Best initial guess at bb
        self.last_known_bb = self.initial_blind_amount if self.initial_blind_amount > 0 else 10

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # New hand/round; update counters and attempt to infer current big blind
        self.hand_num += 1

        # Try to infer current big blind from preflop state if possible
        if round_state.round.lower() == 'preflop':
            # If a blind has been posted, current_bet often equals the big blind to call preflop
            if round_state.current_bet and round_state.current_bet > 0:
                self.last_known_bb = max(int(round_state.current_bet), 1)
            else:
                # Fall back: min_raise could approximate bb when no bet yet
                if round_state.min_raise and round_state.min_raise > 0:
                    self.last_known_bb = max(int(round_state.min_raise), 1)
                else:
                    self.last_known_bb = max(self.initial_blind_amount, 1)
        else:
            # Postflop – keep previous blind
            self.last_known_bb = max(self.last_known_bb or self.initial_blind_amount, 1)

        # Defensive: ensure the dictionaries contain our id entries for current hand
        if round_state.player_bets is not None and self.id is not None:
            round_state.player_bets.setdefault(str(self.id), 0)
        if round_state.player_actions is not None and self.id is not None:
            round_state.player_actions.setdefault(str(self.id), "")

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            pid = str(self.id)
            # Guard defaults
            our_bet = 0
            if round_state.player_bets and pid in round_state.player_bets:
                try:
                    our_bet = int(round_state.player_bets.get(pid, 0))
                except Exception:
                    our_bet = 0

            current_bet = int(round_state.current_bet or 0)
            to_call = max(0, current_bet - our_bet)
            can_check = (to_call == 0)

            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)
            pot = int(round_state.pot or 0)
            epsilon = 1e-9

            # Update last_known_bb heuristically if preflop or unclear
            if round_state.round.lower() == 'preflop':
                if current_bet > 0:
                    self.last_known_bb = max(int(current_bet), 1)
                elif min_raise > 0:
                    self.last_known_bb = max(int(min_raise), 1)
                else:
                    self.last_known_bb = max(self.last_known_bb, 1)
            else:
                self.last_known_bb = max(self.last_known_bb or self.initial_blind_amount or 1, 1)

            bb = max(self.last_known_bb, 1)

            # Conservative safety: never attempt invalid raises
            def clamp_raise_amount(desired_amount: int) -> Optional[int]:
                d = max(int(desired_amount), 0)
                lo = max(int(min_raise), 1)
                hi = max(int(max_raise), 0)
                if hi < lo:
                    return None
                d = max(lo, min(d, hi))
                return d

            # Helper to select a small value bet size relative to pot and blinds
            def bet_size_from_pot(frac: float) -> int:
                # Basic target bet is fraction of pot; fallback to blind-based amount
                base = int(max(frac * (pot + epsilon), 0))
                # Ensure it's at least a small multiple of bb
                if base < int(1.5 * bb):
                    base = int(1.5 * bb)
                return base

            # Decision policy: tight-aggressive but mostly cautious without hole cards
            stage = round_state.round.lower() if isinstance(round_state.round, str) else str(round_state.round)

            # Opponent count approximation
            active_players = round_state.current_player or []
            num_active = len(active_players) if active_players else len(self.players) or 2

            # Basic pot odds consideration
            pot_odds = (to_call / (pot + to_call + epsilon)) if to_call > 0 else 0.0

            # Short stack mode makes us simpler and more shove/call oriented
            short_stack = remaining_chips <= 40 * bb

            # Strategy per street
            action = None
            amount = 0

            # PREFLOP STRATEGY (no hole card info available)
            if stage == 'preflop':
                # Opening when checked to
                if can_check:
                    # Open-raise occasionally to steal blinds
                    steal_freq = 0.33 if num_active <= 3 else 0.20
                    if self.random.random() < steal_freq:
                        desired = max(2 * bb, bet_size_from_pot(0.75))
                        amt = clamp_raise_amount(desired)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    # Otherwise, check
                    return PokerAction.CHECK, 0
                else:
                    # Facing a bet preflop
                    # If the bet is tiny relative to bb or pot, call; otherwise fold mostly
                    # If short-stacked and raise is big, fold unless pot odds very favorable
                    if to_call <= 2 * bb or pot_odds >= 0.3:
                        # Avoid calling if it's a huge chunk of our stack
                        if to_call >= max(remaining_chips * 0.3, 1):
                            # Too large; fold usually unless short stack then all-in sometimes
                            if short_stack and self.random.random() < 0.2:
                                return PokerAction.ALL_IN, 0
                            return PokerAction.FOLD, 0
                        # Small 3-bet bluff very rarely
                        if self.random.random() < 0.06 and min_raise > 0 and max_raise >= min_raise:
                            desired = max(3 * bb, to_call + 2 * bb)
                            amt = clamp_raise_amount(desired)
                            if amt is not None:
                                return PokerAction.RAISE, amt
                        return PokerAction.CALL, 0
                    else:
                        # Large raises: mostly fold
                        if short_stack and to_call >= remaining_chips:
                            # Call off as all-in sometimes
                            if self.random.random() < 0.25:
                                return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0

            # FLOP STRATEGY (board info available but we don't use hole cards; play by sizing)
            elif stage == 'flop':
                if can_check:
                    # C-bet steal frequently when checked to (position agnostic approximation)
                    stab_freq = 0.55 if num_active <= 3 else 0.40
                    if self.random.random() < stab_freq and min_raise > 0 and max_raise >= min_raise:
                        desired = bet_size_from_pot(0.55)
                        amt = clamp_raise_amount(desired)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    # Facing a bet: call small, fold big
                    # Define thresholds by pot fractions
                    if pot <= 0:
                        # If pot missing, approximate with blinds
                        pot = 3 * bb
                    frac = to_call / (pot + epsilon)
                    if frac <= 0.25:
                        # Occasional small raise as bluff
                        if self.random.random() < 0.08 and min_raise > 0 and max_raise >= min_raise:
                            desired = max(to_call + int(1.5 * bb), bet_size_from_pot(0.6))
                            amt = clamp_raise_amount(desired)
                            if amt is not None:
                                return PokerAction.RAISE, amt
                        return PokerAction.CALL, 0
                    elif frac <= 0.45:
                        # Medium pressure: mix call and fold
                        if self.random.random() < 0.5:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                    else:
                        # Big bet: mostly fold; if short-stacked and price commits, shove sometimes
                        if short_stack and to_call >= remaining_chips:
                            if self.random.random() < 0.25:
                                return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0

            # TURN STRATEGY
            elif stage == 'turn':
                if can_check:
                    # Barrel sometimes when checked to
                    stab_freq = 0.45 if num_active <= 3 else 0.30
                    if self.random.random() < stab_freq and min_raise > 0 and max_raise >= min_raise:
                        desired = bet_size_from_pot(0.5)
                        amt = clamp_raise_amount(desired)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    if pot <= 0:
                        pot = 3 * bb
                    frac = to_call / (pot + epsilon)
                    if frac <= 0.2:
                        # Small call; occasionally raise
                        if self.random.random() < 0.05 and min_raise > 0 and max_raise >= min_raise:
                            desired = max(to_call + int(1.5 * bb), bet_size_from_pot(0.55))
                            amt = clamp_raise_amount(desired)
                            if amt is not None:
                                return PokerAction.RAISE, amt
                        return PokerAction.CALL, 0
                    elif frac <= 0.35:
                        if self.random.random() < 0.4:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                    else:
                        if short_stack and to_call >= remaining_chips:
                            if self.random.random() < 0.25:
                                return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0

            # RIVER STRATEGY
            else:
                if can_check:
                    # Thin value/bluff rarely on river when checked to
                    stab_freq = 0.25 if num_active <= 3 else 0.15
                    if self.random.random() < stab_freq and min_raise > 0 and max_raise >= min_raise:
                        desired = bet_size_from_pot(0.45)
                        amt = clamp_raise_amount(desired)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    if pot <= 0:
                        pot = 3 * bb
                    frac = to_call / (pot + epsilon)
                    # River calls are tight
                    if frac <= 0.12:
                        return PokerAction.CALL, 0
                    elif frac <= 0.22:
                        if self.random.random() < 0.35:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                    else:
                        return PokerAction.FOLD, 0

        except Exception:
            # Fail-safe: never crash; default to safe action
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update dynamic vpip/aggression from player_actions if available
        try:
            if not round_state or not round_state.player_actions:
                return
            for pid, act in round_state.player_actions.items():
                if pid not in self.hands_seen:
                    self.hands_seen[pid] = 0
                if pid not in self.vpip:
                    self.vpip[pid] = 0
                if pid not in self.aggression:
                    self.aggression[pid] = 0

                # Count one hand visibility per round for all active players
                self.hands_seen[pid] += 1

                # VPIP: voluntarily put money in pot (Call, Raise, All-in) not including blinds;
                # We don't differentiate blinds here due to lack of metadata; use actions as proxy.
                act_up = str(act).strip().lower()
                if act_up in ('call', 'raise', 'all_in', 'all-in', 'allin'):
                    self.vpip[pid] += 1
                if act_up in ('raise', 'all_in', 'all-in', 'allin'):
                    self.aggression[pid] += 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset or store end-of-game stats if needed
        pass