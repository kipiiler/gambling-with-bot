from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Simple and robust No-Limit Hold'em bot focused on safe, valid actions and solid baseline strategy.
# - Tight/aggressive preflop chart with heads-up adjustments
# - Postflop basic made-hand/draw detection, pot-odds-aware decisions
# - Conservative use of RAISE (mostly min-raise) to avoid invalid amounts
# - Careful guards to avoid invalid actions in all edge cases


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0  # big blind
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.num_players: int = 0

        # Per-hand state
        self.hole_cards: List[str] = []
        self.current_street: str = "Preflop"

        # Simple statistics
        self.game_hands_played = 0
        self.total_profit = 0.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the start of each hand (round of play)
        self.starting_chips = starting_chips
        self.blind_amount = max(int(blind_amount), 1)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players or []
        self.num_players = max(2, len(self.all_players)) if self.all_players else 2
        self.hole_cards = list(player_hands) if player_hands else []
        self.current_street = "Preflop"
        self.game_hands_played += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # round_state.round: 'Preflop','Flop','Turn','River'
        # Update street each betting round
        if round_state and isinstance(round_state.round, str):
            self.current_street = round_state.round

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            if round_state is None:
                # Safety: If no state, fold conservatively
                return PokerAction.FOLD, 0

            # Basic variables
            my_id_str = str(self.id) if self.id is not None else ""
            pot = int(round_state.pot) if round_state.pot is not None else 0
            current_bet = int(round_state.current_bet) if round_state.current_bet is not None else 0
            min_raise = int(round_state.min_raise) if round_state.min_raise is not None else 0
            max_raise = int(round_state.max_raise) if round_state.max_raise is not None else 0
            player_bets: Dict[str, int] = round_state.player_bets or {}
            my_bet = int(player_bets.get(my_id_str, 0))

            to_call = max(0, current_bet - my_bet)
            can_check = (to_call <= 0)
            street = (round_state.round or "Preflop")
            community = round_state.community_cards or []

            # Guard against empty hole cards
            hole = self.hole_cards or []

            # Quick helpers
            def safe_all_in():
                # Only all-in if we have chips
                if remaining_chips > 0:
                    return PokerAction.ALL_IN, 0
                # If no chips but to_call == 0 we can still check
                if can_check:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Compute number of active players if available, else default to table size
            active_players = round_state.current_player or []
            num_active = len(active_players) if active_players else max(2, self.num_players)

            # Preflop decision-making
            if street == "Preflop":
                # Heads-up vs multiway adjust
                hu = num_active <= 2
                tier = self._preflop_tier(hole)
                # Adjust thresholds: looser in heads-up
                open_raise_threshold = 8 if not hu else 7
                call_threshold = 6 if not hu else 5
                threebet_threshold = 9 if not hu else 8

                # Big blind can check if no raise
                if can_check:
                    # Optionally raise with strong hands as open
                    if tier >= open_raise_threshold:
                        return self._try_raise(min_raise, max_raise, fallback=(PokerAction.CHECK, 0))
                    # Otherwise just check
                    return PokerAction.CHECK, 0

                # Facing a bet preflop
                bb = max(self.blind_amount, 1)
                # If the to_call is huge relative to stack, only continue with premiums
                if remaining_chips <= 0:
                    return PokerAction.FOLD, 0
                stack_commit_ratio = to_call / (remaining_chips + 1e-9)
                if stack_commit_ratio > 0.6 and tier < threebet_threshold:
                    # Too expensive for marginal hands
                    return PokerAction.FOLD, 0

                # 3-bet or call depending on strength
                if tier >= threebet_threshold:
                    # Prefer a raise (min-raise for safety). If not possible, call.
                    act = self._try_raise(min_raise, max_raise)
                    if act is not None:
                        return act
                    # If cannot raise safely, try call if we can afford
                    if to_call <= remaining_chips:
                        return PokerAction.CALL, 0
                    return safe_all_in()

                # Medium strength: call if price is reasonable
                if tier >= call_threshold:
                    # Avoid over-calling massive raises with medium hands
                    if to_call <= 3 * bb or hu:
                        if to_call <= remaining_chips:
                            return PokerAction.CALL, 0
                        else:
                            # Calling would be all-in; make a conservative choice
                            if tier >= threebet_threshold:
                                return safe_all_in()
                            # Otherwise fold off marginal hands
                            return PokerAction.FOLD, 0
                    else:
                        return PokerAction.FOLD, 0

                # Weak hand: fold vs bet
                return PokerAction.FOLD, 0

            # Postflop decision-making
            # Simple hand categorization
            hand_info = self._postflop_hand_info(hole, community)
            strength = hand_info["strength"]  # "strong", "medium", "draw", "air"
            # Pot odds
            pot_odds = to_call / (pot + to_call + 1e-9)

            # Aggression parameters by street
            if street == "Flop":
                draw_call_threshold = 0.6  # to_call <= 0.6 * pot roughly equals pot odds ~36%
                value_bet = strength == "strong"
                semi_bluff = (strength == "draw")
            elif street == "Turn":
                draw_call_threshold = 0.3  # tighter on turn
                value_bet = strength == "strong"
                semi_bluff = (strength == "draw" and to_call <= max(self.blind_amount, pot * 0.25))
            else:  # River
                draw_call_threshold = 0.0  # no draws on river
                value_bet = strength == "strong" or strength == "medium"
                semi_bluff = False

            # If we can check:
            if can_check:
                # Bet for value or semi-bluff with draws on earlier streets
                if value_bet or semi_bluff:
                    act = self._try_raise(min_raise, max_raise)
                    if act is not None:
                        return act
                return PokerAction.CHECK, 0

            # Facing a bet:
            # Strong hands: prefer raise (min-raise), otherwise call
            if strength == "strong":
                # If stack is short relative to bet, just jam
                if to_call > 0 and (to_call / (remaining_chips + 1e-9) > 0.5):
                    return safe_all_in()
                # Try to raise; fallback to call if can't
                act = self._try_raise(min_raise, max_raise)
                if act is not None:
                    return act
                # Else just call
                if to_call <= remaining_chips:
                    return PokerAction.CALL, 0
                return safe_all_in()

            # Medium strength: prefer call if pot odds are acceptable; fold to large bets on later streets
            if strength == "medium":
                # If the bet is small relative to pot/stack, call
                if pot <= 0:
                    # If pot info is weird, conservative action
                    if to_call <= remaining_chips // 20:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                # On turn/river, avoid calling very large bets
                if street in ("Turn", "River") and to_call > pot:
                    return PokerAction.FOLD, 0
                if to_call <= remaining_chips:
                    return PokerAction.CALL, 0
                return safe_all_in()

            # Draws: call with proper odds (flop/turn), otherwise fold; occasional semi-bluff raise if cheap
            if strength == "draw":
                # Convert threshold to pot odds check: to_call <= draw_call_threshold * pot
                if to_call <= draw_call_threshold * pot + 1e-9:
                    if to_call <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        # If calling is effectively all-in and odds good, jam
                        return safe_all_in()
                else:
                    # Too expensive to chase
                    return PokerAction.FOLD, 0

            # Air: fold facing a bet
            return PokerAction.FOLD, 0

        except Exception:
            # Any unexpected error: return the safest legal action
            try:
                if round_state is not None:
                    my_id_str = str(self.id) if self.id is not None else ""
                    player_bets = round_state.player_bets or {}
                    my_bet = int(player_bets.get(my_id_str, 0))
                    current_bet = int(round_state.current_bet) if round_state.current_bet is not None else 0
                    to_call = max(0, current_bet - my_bet)
                    if to_call <= 0:
                        return PokerAction.CHECK, 0
            except Exception:
                pass
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Reset per-hand info that must not leak
        self.hole_cards = []
        self.current_street = "Preflop"

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Track total profit for optional debugging/metrics
        try:
            self.total_profit += float(player_score)
        except Exception:
            pass

    # ---------------- Helper methods ----------------

    @staticmethod
    def _rank_value(r: str) -> int:
        m = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
             '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11,
             'Q': 12, 'K': 13, 'A': 14}
        return m.get(r[0], 0) if r else 0

    @staticmethod
    def _suit_value(r: str) -> str:
        return r[1] if r and len(r) >= 2 else ''

    def _cards_info(self, cards: List[str]) -> Dict[str, Any]:
        ranks = [self._rank_value(c) for c in cards if c]
        suits = [self._suit_value(c) for c in cards if c]
        return {"ranks": ranks, "suits": suits}

    def _preflop_tier(self, hole: List[str]) -> int:
        # Return a tier roughly 1..10 where higher is stronger
        if not hole or len(hole) < 2:
            return 1
        c1, c2 = hole[0], hole[1]
        r1, r2 = self._rank_value(c1), self._rank_value(c2)
        s1, s2 = self._suit_value(c1), self._suit_value(c2)
        suited = (s1 == s2)
        high = max(r1, r2)
        low = min(r1, r2)
        pair = (r1 == r2)
        gap = max(0, high - low - 1)

        # Explicit top tiers
        if pair:
            # Pairs tiering
            if r1 >= 14:  # AA
                return 10
            if r1 == 13:  # KK
                return 10
            if r1 == 12:  # QQ
                return 9
            if r1 == 11:  # JJ
                return 9
            if r1 == 10:  # TT
                return 8
            if r1 == 9:
                return 7
            if r1 == 8:
                return 7
            if r1 == 7:
                return 6
            if r1 == 6:
                return 5
            if r1 == 5:
                return 4
            if r1 == 4:
                return 4
            # 33,22
            return 3

        # Non-pair
        # Strong broadways
        if suited and ((high == 14 and low >= 11) or (high >= 13 and low >= 12)):
            # AKs, AQs+, KQs
            return 9
        if not suited and ((high == 14 and low >= 12) or (high >= 13 and low >= 12)):
            # AKo, AQo, KQo
            return 8

        # Suited A-x and suited broadways
        if suited and high == 14 and low >= 9:
            return 8  # ATs+
        if suited and high >= 13 and low >= 10:
            return 7  # KTs+, QTs+

        # Offsuit broadways
        if not suited and high >= 13 and low >= 11:
            return 7  # KJo+, QJo

        # Suited connectors and one-gappers
        if suited and gap <= 1 and high >= 9 and low >= 8:
            return 7  # T9s, 98s, JTs etc.
        if suited and gap == 2 and high >= 10 and low >= 8:
            return 6  # J8s, T8s, 97s etc.

        # A-x suited moderate, AJo, ATo
        if suited and high == 14 and low >= 7:
            return 6
        if high == 14 and low >= 11:
            return 6  # AJo+
        if high == 14 and low == 10:
            return 5  # ATo

        # Suited wheel aces
        if suited and high == 14 and low >= 2:
            return 5

        # Suited connectors lower
        if suited and gap <= 1 and high >= 7 and low >= 5:
            return 5

        # KTo, QTo, JTo offsuit
        if not suited and high >= 13 and low >= 10:
            return 5

        # Otherwise weak
        return 3

    def _postflop_hand_info(self, hole: List[str], board: List[str]) -> Dict[str, Any]:
        # Returns a dictionary with coarse classification: strong/medium/draw/air
        info = {"strength": "air"}
        if not hole or len(hole) < 2:
            return info

        hc = self._cards_info(hole)
        bc = self._cards_info(board)
        hole_ranks = hc["ranks"]
        board_ranks = bc["ranks"]
        hole_suits = hc["suits"]
        board_suits = bc["suits"]

        all_ranks = hole_ranks + board_ranks
        all_suits = hole_suits + board_suits

        rank_counts: Dict[int, int] = {}
        for r in all_ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1

        board_rank_counts: Dict[int, int] = {}
        for r in board_ranks:
            board_rank_counts[r] = board_rank_counts.get(r, 0) + 1

        max_board_rank = max(board_ranks) if board_ranks else 0
        second_board_rank = 0
        if len(board_ranks) >= 2:
            sorted_board = sorted(board_ranks, reverse=True)
            # Find second distinct rank
            for r in sorted_board:
                if r < max_board_rank:
                    second_board_rank = r
                    break

        # Simple made-hand checks
        pocket_pair = (hole_ranks[0] == hole_ranks[1])
        # Overpair: pocket pair higher than any board card
        overpair = pocket_pair and (hole_ranks[0] > max_board_rank)

        # Trips with hole involvement
        has_set = False
        if pocket_pair:
            # Set if one of that value is on board
            has_set = (board_rank_counts.get(hole_ranks[0], 0) >= 1)
        else:
            # Board pair of a rank we hold -> trips
            for r in hole_ranks:
                if board_rank_counts.get(r, 0) >= 2:
                    has_set = True
                    break

        # Two-pair using at least one hole card
        two_pair = False
        shared_distinct_hits = len({r for r in hole_ranks if r in board_ranks})
        if shared_distinct_hits >= 2:
            two_pair = True

        # Top pair / second pair check
        top_pair = any((r == max_board_rank and board_rank_counts.get(r, 0) >= 1) for r in hole_ranks)
        second_pair = any((r == second_board_rank and board_rank_counts.get(r, 0) >= 1) for r in hole_ranks if second_board_rank > 0)

        # Flush draw detection (4 to a flush including at least one hole card of that suit)
        suit_counts: Dict[str, int] = {}
        for s in all_suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_draw = False
        for s in set(hole_suits):
            if s and suit_counts.get(s, 0) >= 4 and s in hole_suits:
                flush_draw = True
                break

        # Straight draw detection (approximate)
        def straight_draw(ranks_all: List[int], hole_ranks_list: List[int]) -> Tuple[bool, bool]:
            # Returns (oesd, gutshot)
            ranks_u = sorted(set(ranks_all))
            if not ranks_u:
                return False, False
            # Treat ace as both high and low for wheel
            augmented = ranks_u[:]
            if 14 in ranks_u:
                augmented = sorted(set(ranks_u + [1]))
            oesd = False
            gut = False
            # We require at least one hole rank to be within the 4-card window for OESD detection
            for i in range(len(augmented) - 3):
                window = augmented[i:i+4]
                # Check if the 4 numbers are consecutive
                if window[3] - window[0] == 3 and len(window) == 4:
                    # Check hole involvement
                    if any(r in window for r in hole_ranks_list):
                        # Need one of two cards to complete
                        oesd = True
                        break
            # Gutshot: 4 cards that would be consecutive if one missing in middle
            if not oesd:
                for i in range(len(augmented) - 4):
                    five = augmented[i:i+5]
                    if five[4] - five[0] == 4 and len(five) == 5:
                        # This already is a straight; not a draw
                        continue
                # Approx gutshot detection by checking for any 4-of-5 with a single gap
                for i in range(len(augmented) - 4 + 1):
                    slice5 = augmented[i:i+5]
                    if len(slice5) < 5:
                        break
                    # Count missing integers in the 5-length window
                    missing = 0
                    for x in range(slice5[0], slice5[0] + 5):
                        if x not in slice5:
                            missing += 1
                    if missing == 1 and any(r in range(slice5[0], slice5[0] + 5) for r in hole_ranks_list):
                        gut = True
                        break
            return oesd, gut

        oesd, gutshot = straight_draw(all_ranks, hole_ranks)
        straight_draw_flag = oesd or gutshot

        # Determine strength bucket
        if has_set or two_pair or overpair:
            category = "strong"
        elif top_pair and max(hole_ranks) >= 12:
            category = "medium"  # TPTK-ish
        elif top_pair or second_pair:
            category = "medium"
        elif flush_draw or oesd:
            category = "draw"
        else:
            category = "air"

        info["strength"] = category
        info["top_pair"] = top_pair
        info["overpair"] = overpair
        info["two_pair"] = two_pair
        info["set_plus"] = has_set
        info["flush_draw"] = flush_draw
        info["straight_draw"] = straight_draw_flag
        return info

    def _try_raise(self, min_raise: int, max_raise: int, fallback: Tuple[PokerAction, int] = None) -> Tuple[PokerAction, int] | None:
        # Validate and return a safe min-raise action if possible
        # If not valid, return fallback or None
        try:
            if min_raise is None or max_raise is None:
                return fallback
            min_r = int(min_raise)
            max_r = int(max_raise)
            if max_r <= 0:
                return fallback
            # If min raise is zero or invalid, try to use 1 as minimal positive within bounds
            amount = min_r if min_r > 0 else 1
            amount = max(1, amount)
            amount = min(amount, max_r)
            # If after adjustment amount is still invalid (<=0), fallback
            if amount <= 0:
                return fallback
            return PokerAction.RAISE, int(amount)
        except Exception:
            return fallback