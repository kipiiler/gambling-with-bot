from typing import List, Tuple, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Configuration
        self.starting_chips: int = 0
        self.blind_amount: int = 50  # fallback default if not provided
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.table_size: int = 0

        # State
        self.round_num: int = 0
        self.current_stage: str = "Preflop"
        self.player_hole_cards: Optional[List[str]] = None  # May be None if not provided
        self.rng_seed_base: int = 0

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ):
        # Initialize persistent game state
        self.starting_chips = int(starting_chips)
        self.blind_amount = int(blind_amount) if blind_amount is not None else self.blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.table_size = len(self.all_players)
        # Try to store our starting hole cards if provided (may be None or empty)
        if player_hands and isinstance(player_hands, list):
            # Expecting something like ['Ah', 'Kd'] or a list containing two strings
            self.player_hole_cards = player_hands[:2] if len(player_hands) >= 2 else None
        else:
            self.player_hole_cards = None

        # Prepare a deterministic RNG seed base to keep behavior stable across runs
        pid = self.id if self.id is not None else 0
        self.rng_seed_base = (pid * 73856093 + self.starting_chips * 19349663 + self.blind_amount * 83492791) & 0xFFFFFFFF

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update round-level state
        self.round_num = int(round_state.round_num)
        self.current_stage = round_state.round
        # We may not get hole cards here per the provided interface; keep last known or None
        # Reset any per-round tracking if needed in the future
        return

    def _safe_get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            key = str(self.id) if self.id is not None else ""
            return int(round_state.player_bets.get(key, 0))
        except Exception:
            return 0

    def _rng(self, round_state: RoundStateClient) -> random.Random:
        # Deterministic per decision RNG
        base = self.rng_seed_base
        comm_len = len(round_state.community_cards) if round_state.community_cards else 0
        seed = (base ^ (round_state.round_num * 2654435761) ^ (comm_len * 97531)) & 0xFFFFFFFF
        return random.Random(seed)

    def _to_call(self, round_state: RoundStateClient) -> int:
        my_bet = self._safe_get_my_bet(round_state)
        try:
            return max(int(round_state.current_bet) - my_bet, 0)
        except Exception:
            return 0

    def _valid_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, add_amount: int) -> bool:
        # Interpret min_raise and max_raise as "add amount" bounds per documentation
        try:
            if add_amount is None:
                return False
            add_amount = int(add_amount)
            if add_amount <= 0:
                return False
            min_r = int(round_state.min_raise) if round_state.min_raise is not None else 0
            max_r = int(round_state.max_raise) if round_state.max_raise is not None else remaining_chips
            # Ensure within bounds and that adding makes our total bet exceed current_bet
            my_bet = self._safe_get_my_bet(round_state)
            cur_bet = int(round_state.current_bet)
            if add_amount < max(min_r, 1):
                return False
            if add_amount > max_r:
                return False
            if my_bet + add_amount <= cur_bet:
                return False
            if remaining_chips < add_amount:
                return False
            return True
        except Exception:
            return False

    def _choose_open_raise(self, round_state: RoundStateClient, remaining_chips: int) -> Optional[int]:
        # Open-raise sizing heuristic: 2.5-3.5x BB, but comply with min/max
        bb = max(self.blind_amount, 1)
        rng = self._rng(round_state)
        target = int(2.5 * bb + rng.random() * 1.0 * bb)  # 2.5x to 3.5x
        min_r = int(round_state.min_raise) if round_state.min_raise is not None else max(bb, 1)
        max_r = int(round_state.max_raise) if round_state.max_raise is not None else remaining_chips
        # Ensure it's within [min_r, max_r]
        add_amount = max(min_r, target)
        add_amount = min(add_amount, max_r)
        if self._valid_raise_amount(round_state, remaining_chips, add_amount):
            return add_amount
        # Try min_r if target invalid
        if self._valid_raise_amount(round_state, remaining_chips, min_r):
            return min_r
        return None

    def _choose_raise_vs_bet(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Optional[int]:
        # 2.5x to 3x raise size on top, as add_amount
        rng = self._rng(round_state)
        base_mult = 2.5 + rng.random() * 0.7  # 2.5 to 3.2
        add_amount = int(max(round(to_call * base_mult), 1))
        # Ensure bounds
        min_r = int(round_state.min_raise) if round_state.min_raise is not None else max(to_call, 1)
        max_r = int(round_state.max_raise) if round_state.max_raise is not None else remaining_chips
        add_amount = max(add_amount, min_r)
        add_amount = min(add_amount, max_r)
        # Validate
        if self._valid_raise_amount(round_state, remaining_chips, add_amount):
            return add_amount
        # Try min raise if above invalid
        if self._valid_raise_amount(round_state, remaining_chips, min_r):
            return min_r
        return None

    def _stage_factor(self, round_state: RoundStateClient) -> float:
        stage = (round_state.round or "Preflop").lower()
        if stage == "preflop":
            return 1.0
        if stage == "flop":
            return 0.8
        if stage == "turn":
            return 0.6
        if stage == "river":
            return 0.5
        return 0.8

    def _pot_odds_call_thresh(self, round_state: RoundStateClient) -> float:
        # Conservative pot odds threshold baseline; smaller on later streets
        base = 0.22
        return max(0.08, base * self._stage_factor(round_state))

    def _aggression_freq(self, round_state: RoundStateClient) -> float:
        # Aggression frequency decreases on later streets
        base = 0.18  # base for preflop
        return max(0.05, base * self._stage_factor(round_state))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player.
        Strategy: Fast, conservative baseline with occasional aggression to avoid bleeding blinds.
        Ensures actions are always valid and within bounds.
        """
        try:
            rng = self._rng(round_state)
            my_bet = self._safe_get_my_bet(round_state)
            to_call = self._to_call(round_state)
            can_check = (to_call <= 0)
            pot = int(round_state.pot) if round_state.pot is not None else 0
            bb = max(self.blind_amount, 1)
            # Short stack shove logic
            # If very short and facing a bet not exceeding our stack, consider shoving with some frequency
            if remaining_chips <= 6 * bb:
                if to_call == 0:
                    # open shove rarely, mostly check if allowed
                    if rng.random() < 0.08 and remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    if can_check:
                        return (PokerAction.CHECK, 0)
                else:
                    # call all-in if needed or shove sometimes
                    if to_call >= remaining_chips:
                        # Pot odds check
                        effective_pot = pot + to_call + my_bet
                        thresh = self._pot_odds_call_thresh(round_state)
                        if effective_pot <= 0:
                            # Avoid division by zero
                            if rng.random() < 0.25:
                                return (PokerAction.ALL_IN, 0)
                            return (PokerAction.FOLD, 0)
                        # Pot odds: to_call / (pot + to_call)
                        if (to_call / (effective_pot + 1e-9)) <= thresh or rng.random() < 0.25:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Not all-in to call; mix call and shove
                        if rng.random() < 0.15:
                            return (PokerAction.ALL_IN, 0)
                        # Pot odds-based call
                        effective_pot = pot
                        if (to_call / (effective_pot + to_call + 1e-9)) <= self._pot_odds_call_thresh(round_state):
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)

            # General play
            if to_call == 0:
                # Nobody has bet yet: we can CHECK or OPEN RAISE
                # Try to open-raise with some probability; more likely preflop
                if rng.random() < self._aggression_freq(round_state):
                    add_amount = self._choose_open_raise(round_state, remaining_chips)
                    if add_amount is not None and self._valid_raise_amount(round_state, remaining_chips, add_amount):
                        return (PokerAction.RAISE, int(add_amount))
                # Otherwise check if allowed
                if can_check:
                    return (PokerAction.CHECK, 0)
                # Fallback if somehow check not allowed, try minimal raise or call
                add_amount = self._choose_open_raise(round_state, remaining_chips)
                if add_amount is not None:
                    return (PokerAction.RAISE, int(add_amount))
                if remaining_chips > 0:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.FOLD, 0)

            # Facing a bet
            # Evaluate pot odds for call
            call_prob = self._pot_odds_call_thresh(round_state)
            # If the call is our entire stack, decide all-in or fold using pot odds
            if to_call >= remaining_chips:
                eff_pot = pot + to_call + my_bet
                if eff_pot <= 0:
                    return (PokerAction.FOLD, 0)
                if (to_call / (eff_pot + 1e-9)) <= (call_prob * 0.8) or rng.random() < 0.2:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.FOLD, 0)

            # Non-all-in facing a bet
            # Sometimes 3-bet/raise as a bluff, more often fold/call based on price
            if rng.random() < self._aggression_freq(round_state) * 0.6:
                add_amount = self._choose_raise_vs_bet(round_state, remaining_chips, to_call)
                if add_amount is not None and self._valid_raise_amount(round_state, remaining_chips, add_amount):
                    return (PokerAction.RAISE, int(add_amount))

            # Default to pot odds call if cheap enough
            if (to_call / (pot + to_call + 1e-9)) <= call_prob:
                return (PokerAction.CALL, 0)

            # Otherwise fold
            return (PokerAction.FOLD, 0)

        except Exception:
            # Absolute fallback: be safe and valid
            try:
                my_bet = self._safe_get_my_bet(round_state)
                to_call = max(int(round_state.current_bet) - my_bet, 0)
                if to_call <= 0:
                    return (PokerAction.CHECK, 0)
                # If affordable, call small; else fold
                pot = int(round_state.pot) if round_state.pot is not None else 0
                if to_call <= max(self.blind_amount, 1) or (to_call / (pot + to_call + 1e-9)) <= 0.18:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could update adaptive parameters in the future. Keep minimal to avoid overhead.
        return

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No external side effects to ensure clean runs under constraints.
        return