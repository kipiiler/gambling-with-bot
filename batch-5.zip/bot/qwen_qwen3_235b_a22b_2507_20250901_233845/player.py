from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hands = []
        self.current_round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_hands = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_state = round_state

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive check for empty current_player list
        if not round_state.current_player:
            return PokerAction.FOLD, 0
        
        # If it's not our turn, fold (should not happen in correct game flow)
        if self.id not in round_state.current_player:
            return PokerAction.FOLD, 0

        # Extract game state
        current_round = round_state.round
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_bet = round_state.player_bets.get(str(self.id), 0)

        # Calculate amount needed to call
        to_call = current_bet - player_bet

        # If no bet to call, we can check
        if to_call == 0:
            return PokerAction.CHECK, 0

        # If we have very few chips, consider going all-in or calling
        if remaining_chips <= to_call:
            return PokerAction.ALL_IN, 0

        # Preflop strategy
        if current_round == "Preflop":
            # Simple preflop hand strength evaluation
            hole_cards = self.player_hands
            if not hole_cards:
                return PokerAction.FOLD, 0

            # Extract ranks and suits
            ranks = [card[0] for card in hole_cards]
            suits = [card[1] for card in hole_cards]
            
            # Assign values to ranks (T=10, J=11, Q=12, K=13, A=14)
            rank_values = []
            for r in ranks:
                if r == 'A':
                    rank_values.append(14)
                elif r == 'K':
                    rank_values.append(13)
                elif r == 'Q':
                    rank_values.append(12)
                elif r == 'J':
                    rank_values.append(11)
                elif r == 'T':
                    rank_values.append(10)
                else:
                    rank_values.append(int(r))
            
            rank_values.sort(reverse=True)
            high_card = rank_values[0]
            low_card = rank_values[1]
            is_pair = ranks[0] == ranks[1]
            is_suited = suits[0] == suits[1]
            gap = high_card - low_card

            # Evaluate hand strength
            hand_score = 0
            if is_pair:
                hand_score += 10 + high_card
            elif is_suited:
                if gap < 3:
                    hand_score += 5 + (high_card / 2)
                else:
                    hand_score += 3 + (high_card / 4)
            else:
                if gap < 3:
                    hand_score += 4 + (high_card / 3)
                else:
                    hand_score += (high_card / 4)

            # Position-adjusted decision
            # If we're in a tough spot (deep in betting or big bet), be cautious
            pot_odds = to_call / (pot_size + to_call) if (pot_size + to_call) > 0 else 0

            # Fold threshold based on pot odds and hand strength
            if hand_score < 8 or pot_odds > 0.3:
                return PokerAction.FOLD, 0
            elif hand_score > 14 and to_call <= remaining_chips * 0.3:
                # Strong hands raise
                raise_amount = min(to_call * 2 + 10, remaining_chips)
                return PokerAction.RAISE, raise_amount
            else:
                # Middle strength hands call
                return PokerAction.CALL, 0

        # Post-flop strategy
        else:
            # With community cards, make a very basic hand strength estimate
            community_cards = round_state.community_cards
            total_cards = self.player_hands + community_cards if self.player_hands else []

            if len(total_cards) < 3:
                return PokerAction.FOLD, 0

            # Count pairs, draws, etc. simply
            ranks = [card[0] for card in total_cards]
            suits = [card[1] for card in total_cards]
            
            rank_counts = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1

            # Check for pairs or better
            pairs = sum(1 for count in rank_counts.values() if count >= 2)
            trips = sum(1 for count in rank_counts.values() if count >= 3)
            quads = sum(1 for count in rank_counts.values() if count >= 4)

            # Check for flush draw or flush
            suit_counts = {}
            for s in suits:
                suit_counts[s] = suit_counts.get(s, 0) + 1
            flush_draw = any(count >= 3 for count in suit_counts.values())
            has_flush = any(count >= 5 for count in suit_counts.values())

            # Check for straight draw
            rank_nums = []
            for r in ranks:
                if r == 'A':
                    rank_nums.extend([1, 14])
                elif r == 'K':
                    rank_nums.append(13)
                elif r == 'Q':
                    rank_nums.append(12)
                elif r == 'J':
                    rank_nums.append(11)
                elif r == 'T':
                    rank_nums.append(10)
                else:
                    rank_nums.append(int(r))
            rank_nums = list(set(rank_nums))
            rank_nums.sort()
            straight_draw = False
            for i in range(len(rank_nums) - 3):
                if rank_nums[i+3] - rank_nums[i] <= 4:
                    straight_draw = True
                    break

            # Determine hand strength
            if quads > 0 or (trips > 0 and pairs > 0):
                hand_strength = 10
            elif has_flush or trips > 0:
                hand_strength = 8
            elif pairs >= 2 or (pairs > 0 and trips > 0):
                hand_strength = 7
            elif flush_draw and straight_draw:
                hand_strength = 6
            elif flush_draw or straight_draw:
                hand_strength = 5
            elif pairs > 0:
                hand_strength = 4
            else:
                hand_strength = 1

            # More aggressive with strong hands
            pot_odds = to_call / (pot_size + to_call) if (pot_size + to_call) > 0 else 0

            if hand_strength >= 8:
                if to_call <= remaining_chips * 0.4:
                    raise_amount = min(to_call * 2 + 50, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif hand_strength >= 5:
                if pot_odds <= 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if pot_odds > 0.5:
                    return PokerAction.FOLD, 0
                # Small chance to bluff on flop/turn
                if current_round in ["Flop", "Turn"] and pot_size > 50 and remaining_chips > 100:
                    # Small chance to bluff raise with weak hand if no strong bet
                    if to_call < 30 and remaining_chips > 500:
                        return PokerAction.RAISE, min(to_call * 2 + 50, remaining_chips // 5)
                return PokerAction.FOLD, 0

        # Default action
        if to_call == 0:
            return PokerAction.CHECK, 0
        elif remaining_chips <= to_call:
            return PokerAction.ALL_IN, 0
        else:
            return PokerAction.CALL, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset state if needed
        self.current_round_state = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up if needed
        pass