from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.positional_advantage = 0
        self.hand_strength_estimate = 0.0
        self.acting_player_count = 0
        self.is_blind_position = False
        self.tight_aggressive_mode = False
        self.previous_bet_size = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        current_id_str = str(self.id)
        self.acting_player_count = len(round_state.current_player)
        
        # Determine if in late position
        all_players_ids = [p for p in self.all_players if p in round_state.player_bets]
        try:
            my_index = all_players_ids.index(self.id)
            total_players = len(all_players_ids)
            self.positional_advantage = my_index / (total_players + 1e-8)
        except:
            self.positional_advantage = 0.5  # default if not found

        # Check if we're in blind positions
        self.is_blind_position = (self.id == self.big_blind_player_id or self.id == self.small_blind_player_id)
        
        # Adjust strategy based on stack size
        self.tight_aggressive_mode = remaining_chips < 5000  # Short stack mode

        # Estimate hand strength only once per round
        self.hand_strength_estimate = self.estimate_hand_strength(
            hole_cards=self.player_hands,
            community_cards=round_state.community_cards
        )

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_size = round_state.pot
        current_id_str = str(self.id)
        current_player_bet = round_state.player_bets.get(current_id_str, 0)
        call_amount = current_bet - current_player_bet

        # If already all-in, cannot act
        if remaining_chips <= 0:
            return (PokerAction.FOLD, 0)

        # Predefined thresholds
        aggression_factor = self.calculate_aggression_factor(round_state)
        effective_stack = min(remaining_chips, pot_size)

        # Avoid division by zero
        if pot_size == 0:
            pot_odds = 0.0
        else:
            pot_odds = call_amount / (pot_size + call_amount + 1e-8)

        # Decision logic based on hand strength and game context
        action, amount = self.decide_action(
            hand_strength=self.hand_strength_estimate,
            pot_odds=pot_odds,
            pot_size=pot_size,
            call_amount=call_amount,
            min_raise=min_raise,
            max_raise=max_raise,
            remaining_chips=remaining_chips,
            aggression_factor=aggression_factor,
            round_name=round_state.round,
            current_bet=current_bet,
            current_player_bet=current_player_bet
        )

        # Validate action bounds
        if action == PokerAction.RAISE:
            if amount < min_raise:
                amount = min_raise
            elif amount > max_raise:
                amount = max_raise
            if amount <= current_player_bet:
                action = PokerAction.CALL
            elif amount >= remaining_chips:
                action = PokerAction.ALL_IN
        elif action == PokerAction.CALL:
            if call_amount <= 0:
                action = PokerAction.CHECK
            elif call_amount >= remaining_chips:
                action = PokerAction.ALL_IN
        elif action == PokerAction.ALL_IN:
            amount = remaining_chips
        elif action == PokerAction.FOLD:
            amount = 0
        elif action == PokerAction.CHECK:
            if current_bet > current_player_bet:
                if call_amount >= remaining_chips:
                    action = PokerAction.ALL_IN
                else:
                    action = PokerAction.CALL

        return (action, amount)

    def decide_action(self, hand_strength: float, pot_odds: float, pot_size: int, call_amount: int,
                      min_raise: int, max_raise: int, remaining_chips: int, aggression_factor: float,
                      round_name: str, current_bet: int, current_player_bet: int) -> Tuple[PokerAction, int]:
        implied_odds = self.estimate_implied_odds(hand_strength, round_name)
        expected_value = hand_strength * (pot_size + call_amount) - pot_odds * call_amount

        # Normalize raise ranges
        small_raise = min(max(int(0.5 * pot_size), min_raise), max_raise)
        medium_raise = min(max(int(0.75 * pot_size), min_raise), max_raise)
        large_raise = min(max(int(1.5 * pot_size), min_raise), max_raise)

        # Position-based adjustments
        is_late_position = self.positional_advantage > 0.6
        is_early_position = self.positional_advantage < 0.4

        # Round-specific logic
        if round_name == 'Preflop':
            return self.preflop_action(hand_strength, call_amount, min_raise, max_raise, remaining_chips, is_late_position, is_early_position, aggression_factor)
        else:
            return self.postflop_action(hand_strength, pot_odds, implied_odds, expected_value, call_amount,
                                        min_raise, max_raise, remaining_chips, small_raise, medium_raise, large_raise,
                                        pot_size, is_late_position)

    def preflop_action(self, hand_strength: float, call_amount: int, min_raise: int, max_raise: int,
                       remaining_chips: int, is_late_position: bool, is_early_position: bool, aggression_factor: float) -> Tuple[PokerAction, int]:
        # Strong hands: AA, KK, QQ, AK
        if hand_strength >= 0.85:
            if call_amount == 0:
                return (PokerAction.RAISE, min(max_raise, int(3 * min_raise)))
            else:
                if call_amount < 0.5 * remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, remaining_chips)

        # Medium hands: AJ, AQ, KQ, TT-77
        elif hand_strength >= 0.6:
            if call_amount == 0:
                if is_late_position or random.random() < 0.3:
                    return (PokerAction.RAISE, min(max_raise, int(3 * min_raise)))
                else:
                    return (PokerAction.CALL, 0)
            elif call_amount <= 3 * min_raise:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

        # Weak hands
        else:
            if call_amount == 0:
                if self.is_blind_position and random.random() < 0.4:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif call_amount > min_raise:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CALL, 0)

    def postflop_action(self, hand_strength: float, pot_odds: float, implied_odds: float, expected_value: float,
                        call_amount: int, min_raise: int, max_raise: int, remaining_chips: int,
                        small_raise: int, medium_raise: int, large_raise: int, pot_size: int,
                        is_late_position: bool) -> Tuple[PokerAction, int]:
        has_equity = hand_strength > pot_odds
        is_drawing = 0.3 < hand_strength < 0.65
        is_value_bet_threshold = hand_strength > 0.6
        is_bluff_candidate = hand_strength < 0.2 and is_late_position and random.random() < 0.1

        # All-in when strong
        if hand_strength > 0.8 and call_amount > 0:
            return (PokerAction.ALL_IN, remaining_chips)

        # Value betting with strong hands
        if is_value_bet_threshold:
            if call_amount == 0:
                return (PokerAction.RAISE, medium_raise)
            else:
                if expected_value > 0:
                    if call_amount < 0.4 * pot_size:
                        return (PokerAction.RAISE, medium_raise)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)

        # Drawing hands
        elif is_drawing:
            if pot_odds <= hand_strength or implied_odds > pot_odds:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= 0.4 * pot_size:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

        # Bluff or check-fold
        elif is_bluff_candidate:
            if call_amount == 0:
                return (PokerAction.RAISE, small_raise)
            else:
                return (PokerAction.FOLD, 0)
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif expected_value > 0:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0

        hole_ranks = [self.card_rank(card) for card in hole_cards]
        hole_suits = [self.card_suit(card) for card in hole_cards]
        community_ranks = [self.card_rank(card) for card in community_cards]
        community_suits = [self.card_suit(card) for card in community_cards]

        all_ranks = hole_ranks + community_ranks
        all_suits = hole_suits + community_suits

        # High card strength
        high_card_strength = max(hole_ranks) / 14.0

        # Pair or better
        rank_counts = {r: all_ranks.count(r) for r in set(all_ranks)}
        max_rank_count = max(rank_counts.values()) if rank_counts else 0

        paired_strength = 0.0
        if max_rank_count >= 2:
            paired_strength = 0.4 + 0.1 * (max_rank_count - 2)
        
        # Flush draw
        flush_draw = any([all_suits.count(s) >= 4 for s in set(all_suits)])
        flush_strength = 0.3 if flush_draw else 0.0

        # Straight draw
        straight_draw = self.has_straight_draw(all_ranks)
        straight_strength = 0.2 if straight_draw else 0.0

        # Made hand boost
        made_hand = max_rank_count >= 3 or list(rank_counts.values()).count(2) >= 2
        made_strength = 0.5 if made_hand else 0.0

        # Positional and stage adjustment
        board_influence = len(community_cards) / 5.0
        base_strength = high_card_strength * (1 - board_influence)

        # Combine factors
        final_strength = (
            base_strength +
            paired_strength * 0.8 +
            flush_strength * 0.7 +
            straight_strength * 0.6 +
            made_strength * 0.9
        ) / 4.0  # Normalize

        # Clamp between 0 and 1
        return max(0.0, min(1.0, final_strength))

    def estimate_implied_odds(self, hand_strength: float, round_name: str) -> float:
        multiplier = 1.0
        if round_name == 'Flop':
            multiplier = 2.0
        elif round_name == 'Turn':
            multiplier = 1.5
        elif round_name == 'River':
            multiplier = 1.0
        
        # More implied value with drawing hands
        if 0.3 < hand_strength < 0.65:
            return hand_strength * multiplier
        elif hand_strength > 0.65:
            return hand_strength  # Already strong, less implied
        else:
            return 0.0

    def calculate_aggression_factor(self, round_state: RoundStateClient) -> float:
        aggressive_actions = 0
        passive_actions = 0
        for pid, action in round_state.player_actions.items():
            if pid == str(self.id):
                continue
            if action in ['Raise', 'Bet', 'AllIn']:
                aggressive_actions += 1
            elif action in ['Call', 'Check']:
                passive_actions += 1
        total = aggressive_actions + passive_actions
        return aggressive_actions / (total + 1e-8)

    def card_rank(self, card: str) -> int:
        if len(card) == 3:
            r = card[0:2]
        else:
            r = card[0]
        mapping = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(r, int(r))

    def card_suit(self, card: str) -> str:
        return card[-1]

    def has_straight_draw(self, ranks: List[int]) -> bool:
        unique_ranks = list(set(ranks))
        sorted_ranks = sorted(unique_ranks)
        # Include low ace
        if 14 in sorted_ranks:
            sorted_ranks.append(1)
            sorted_ranks = sorted(sorted_ranks)
        for i in range(len(sorted_ranks) - 1):
            if sorted_ranks[i+1] - sorted_ranks[i] <= 2:
                gap = 0
                for j in range(1, len(sorted_ranks)):
                    if sorted_ranks[j] - sorted_ranks[j-1] == 1:
                        gap += 1
                    elif sorted_ranks[j] - sorted_ranks[j-1] == 2:
                        gap += 1  # One gap = open-ended or gutshot
                if gap >= 3:
                    return True
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track previous round result for adaptation
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally log final game state
        pass