from typing import List, Tuple, Dict, Any
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.is_big_blind = False
        self.hand_strength_estimate = 0.0
        self.position_importance = {
            'early': 0.6,
            'middle': 0.8,
            'late': 1.0
        }
        self.tight_aggressive_factor = 0.7  # Between 0 (tight) and 1 (loose)
        self.volatility_threshold = 0.2  # How much variance to tolerate

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.is_big_blind = (self.id == big_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Estimate hand strength based on hole cards and board
        hole_cards = self.player_hands
        community_cards = round_state.community_cards
        self.hand_strength_estimate = self.estimate_hand_strength(hole_cards, community_cards)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Get position info
        pos_factor = self.get_position_multiplier(round_state)
        effective_strength = self.hand_strength_estimate * pos_factor

        # Current bet is 0 -> can check
        can_check = (current_bet == 0)
        in_position = self.is_in_position(round_state)
        pot_odds = self.get_pot_odds(round_state, remaining_chips)

        # Decision logic
        if round_state.round == "Preflop":
            action, amount = self.decide_preflop(current_bet, min_raise, max_raise, remaining_chips, effective_strength, pot_odds)
        else:
            # Post-flop: use hand strength and board texture
            action, amount = self.decide_postflop(round_state, current_bet, min_raise, max_raise, remaining_chips, effective_strength, pot_odds, in_position)

        # Ensure amount is within bounds
        if action == PokerAction.RAISE:
            amount = max(min(amount, max_raise), min_raise) if min_raise <= max_raise else max_raise
        elif action == PokerAction.CALL:
            amount = min(current_bet, remaining_chips)
        elif action == PokerAction.ALL_IN:
            amount = remaining_chips
        else:
            amount = 0

        return action, amount

    def decide_preflop(self, current_bet: int, min_raise: int, max_raise: int, remaining_chips: int,
                       effective_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands
        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]
        suited = suit1 == suit2
        connected = abs(self.rank_value(rank1) - self.rank_value(rank2)) == 1
        pair = rank1 == rank2
        high_card = max(self.rank_value(rank1), self.rank_value(rank2))

        # Predefined hand groups - stronger hands
        is_strong = pair or (suited and connected and high_card >= 9) or (pair and high_card >= 10) or (suited and high_card >= 11)

        if current_bet == 0:
            if is_strong:
                raise_amount = min(3 * self.blind_amount, max_raise)
                return PokerAction.RAISE, raise_amount
            elif suited or connected or pair or high_card >= 10:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0
        else:
            call_amount = current_bet
            if call_amount > remaining_chips:
                return PokerAction.FOLD, 0

            # Pot odds for calling
            pot_size = call_amount / (pot_odds + 1e-9)
            if pot_odds > 0.2 and (is_strong or (suited and high_card >= 11)):
                if call_amount <= 0.1 * remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    # Consider raising if strong
                    if is_strong and call_amount <= 0.05 * remaining_chips:
                        raise_amount = min(current_bet * 2, max_raise)
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CALL, 0
            else:
                if is_strong and random.random() < 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        return PokerAction.FOLD, 0

    def decide_postflop(self, round_state: RoundStateClient, current_bet: int, min_raise: int, max_raise: int,
                        remaining_chips: int, effective_strength: float, pot_odds: float, in_position: bool) -> Tuple[PokerAction, int]:
        hand_strength = self.hand_strength_estimate
        aggression_level = 0.5 + (hand_strength - 0.5) * 1.5  # Scale aggression with hand strength

        if current_bet == 0:
            if hand_strength > 0.7:
                bet_size = min(int(0.5 * round_state.pot), max_raise)
                bet_size = max(bet_size, min_raise)
                return PokerAction.RAISE, bet_size
            elif hand_strength > 0.4:
                if random.random() < 0.3:
                    bet_size = min(int(0.3 * round_state.pot), max_raise)
                    bet_size = max(bet_size, min_raise)
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            call_amount = min(current_bet, remaining_chips)
            if hand_strength > 0.8:
                # Strong hand: raise or call
                if in_position and random.random() < aggression_level:
                    raise_amount = min(int(0.75 * round_state.pot), max_raise)
                    raise_amount = max(raise_amount, min_raise)
                    return PokerAction.RAISE, raise_amount
                else:
                    if call_amount <= 0.3 * remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
            elif hand_strength > 0.5:
                # Medium hand: call if pot odds good
                if pot_odds >= 0.2 and call_amount <= 0.2 * remaining_chips:
                    return PokerAction.CALL, 0
                elif hand_strength > 0.6 and random.random() < 0.3:
                    # Bluff check-raise sometimes
                    return PokerAction.RAISE, min(int(0.6 * round_state.pot), max_raise)
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hand
                if random.random() < 0.1 and in_position and round_state.pot > 5 * self.blind_amount:
                    # Semi-bluff
                    bluff_size = min(int(0.7 * round_state.pot), max_raise)
                    return PokerAction.RAISE, bluff_size
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any round-specific state
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: log performance
        pass

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0

        # If no community cards, use pre-flop logic
        if len(community_cards) == 0:
            return self.preflop_hand_strength(hole_cards)

        # Evaluate hand strength post-flop using basic heuristics
        all_cards = hole_cards + community_cards
        ranks = [self.rank_value(c[0]) for c in all_cards]
        suits = [c[1] for c in all_cards]

        # Check for pairs, two pair, trips, etc.
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        pairs = sum(1 for count in rank_count.values() if count == 2)
        trips = sum(1 for count in rank_count.values() if count == 3)
        quads = sum(1 for count in rank_count.values() if count == 4)
        flush_suits = [s for s in 'shcd' if suits.count(s) >= 5]
        has_flush = len(flush_suits) > 0
        sorted_ranks = sorted(set(ranks), reverse=True)
        has_straight = self.has_straight(ranks)

        # Determine hand category
        if quads:
            strength = 0.95
        elif trips and pairs >= 1:
            strength = 0.85
        elif has_flush:
            strength = 0.8
        elif has_straight:
            strength = 0.75
        elif trips:
            strength = 0.65
        elif pairs >= 2:
            strength = 0.55
        elif pairs == 1:
            high_pair = max(k for k, v in rank_count.items() if v == 2)
            strength = 0.3 + high_pair / 100
        else:
            strength = max(ranks) / 14

        # Number of opponents reduces equity
        num_opponents = max(0, len(round(self.all_players)) - 1)
        opponent_discount = 1.0 - (num_opponents * 0.1)
        strength *= opponent_discount

        # Add noise to prevent deterministic exploitation
        strength = max(0.0, min(1.0, strength + random.uniform(-0.05, 0.05)))
        return strength

    def has_straight(self, ranks: List[int]) -> bool:
        sorted_unique = sorted(set(ranks))
        count = 0
        for i in range(len(sorted_unique)):
            if i > 0 and sorted_unique[i] == sorted_unique[i - 1] + 1:
                count += 1
            else:
                count = 1
            if count >= 5:
                return True
        return False

    def preflop_hand_strength(self, hole_cards: List[str]) -> float:
        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]

        v1, v2 = self.rank_value(rank1), self.rank_value(rank2)
        suited = suit1 == suit2
        pair = rank1 == rank2

        score = 0.0
        if pair:
            score = 0.3 + (v1 / 14) * 0.4
        else:
            high_card = max(v1, v2)
            gap = abs(v1 - v2)
            connector_bonus = 1 - (gap * 0.1)
            if gap <= 1:
                connector_bonus += 0.05
            if suited:
                score = 0.1 + (high_card / 14) * 0.2 + connector_bonus * 0.15
            else:
                score = 0.05 + (high_card / 14) * 0.15 + connector_bonus * 0.1

        return max(0.05, min(0.95, score))

    def rank_value(self, rank: str) -> int:
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(rank.upper(), 0)

    def get_position_multiplier(self, round_state: RoundStateClient) -> float:
        # Estimate position based on number of players left to act
        try:
            current_player_idx = round_state.current_player.index(self.id)
            players_remaining = len(round_state.current_player) - current_player_idx - 1
            total_players = len(self.all_players)

            if players_remaining <= 1:
                return self.position_importance['late']
            elif players_remaining <= total_players // 2:
                return self.position_importance['middle']
            else:
                return self.position_importance['early']
        except (ValueError, AttributeError):
            return 0.8  # default

    def is_in_position(self, round_state: RoundStateClient) -> bool:
        try:
            my_idx = round_state.current_player.index(self.id)
            # If I act last in current round, I'm in position
            return my_idx == len(round_state.current_player) - 1
        except (ValueError, IndexError):
            return False

    def get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return 1.0
        if round_state.pot == 0:
            return 0.0
        return min(call_amount / (round_state.pot + call_amount + 1e-9), 5.0)