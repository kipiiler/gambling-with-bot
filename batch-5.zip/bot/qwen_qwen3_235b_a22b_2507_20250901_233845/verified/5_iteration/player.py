from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength_estimate = 0.5
        self.player_hands = {}
        self.blind_amount = 10
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.current_round_num = 0
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        hole_cards = self.player_hands.get(str(self.id), [])
        community_cards = round_state.community_cards
        self.hand_strength_estimate = self.estimate_hand_strength(hole_cards, community_cards, round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands.get(str(self.id), [])
        if not hole_cards:
            return PokerAction.FOLD, 0

        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_size = round_state.pot
        round_name = round_state.round

        hand_strength = self.estimate_hand_strength(hole_cards, community_cards, round_state)
        aggression_factor = self.calculate_aggression_factor(round_state)
        pot_odds = self.calculate_pot_odds(current_bet, pot_size)

        num_players_in_hand = len([pid for pid in self.all_players if pid in round_state.current_player])
        is_preflop = (round_name == "Preflop")

        if is_preflop:
            position_factor = self.get_position_factor(round_state)
            starting_hand_strength = self.evaluate_starting_hand(hole_cards, position_factor, num_players_in_hand)
            if starting_hand_strength < 0.3:
                return PokerAction.FOLD, 0
            elif starting_hand_strength > 0.8 and remaining_chips >= 500:
                raise_amount = min(max_raise, int(pot_size * 2))
                if raise_amount >= min_raise and (current_bet + raise_amount) > current_bet:
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif starting_hand_strength > 0.6:
                return PokerAction.CALL, 0 if current_bet > 0 else PokerAction.CHECK, 0

        if current_bet == 0:
            if hand_strength > 0.4:
                raise_amount = min(max_raise, int(pot_size * 0.75))
                if raise_amount > min_raise:
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0

        call_amount = current_bet
        if call_amount > remaining_chips:
            call_amount = remaining_chips

        effective_strength = hand_strength * (1 + aggression_factor * 0.5)

        if effective_strength > 0.7:
            raise_amount = min(max_raise, max(min_raise, int(pot_size * 0.75)))
            if (current_bet + raise_amount) > current_bet and raise_amount <= max_raise:
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0
        elif effective_strength > pot_odds:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict,
                    active_players_hands: dict):
        pass

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str],
                              round_state: RoundStateClient) -> float:
        if not hole_cards:
            return 0.0

        if len(community_cards) == 0:
            return self.evaluate_starting_hand(hole_cards, position_factor=0.5, num_players=6)

        hand_rank = self.evaluate_hand_rank(hole_cards, community_cards)
        max_possible_hand = 9
        strength = hand_rank / max_possible_hand

        num_known_cards = len(community_cards) + len(hole_cards)
        num_possible_opponents = max(1, len(round_state.current_player) - 1)
        uncertainty = (7 - num_known_cards) / 7
        adjusted_strength = strength + (1 - strength) * uncertainty * 0.3

        if num_possible_opponents > 3:
            adjusted_strength *= 0.9
        elif num_possible_opponents == 1:
            adjusted_strength *= 1.1

        return min(max(adjusted_strength, 0.0), 1.0)

    def evaluate_hand_rank(self, hole_cards: List[str], community_cards: List[str]) -> int:
        all_cards = hole_cards + community_cards
        ranks = [self.parse_rank(card) for card in all_cards]
        suits = [self.parse_suit(card) for card in all_cards]

        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        pairs = sum(1 for count in rank_count.values() if count >= 2)
        trips = sum(1 for count in rank_count.values() if count >= 3)
        quads = sum(1 for count in rank_count.values() if count >= 4)

        is_flush = any(count >= 5 for count in suit_count.values())
        rank_values = sorted((r if r != 1 else 14) for r in set(ranks))  # Treat Ace as 14
        is_straight = self.has_straight(rank_values)

        if is_straight and is_flush:
            if max(rank_values) == 14:
                return 9  # Royal flush
            return 8  # Straight flush
        if quads > 0:
            return 7  # Four of a kind
        if trips > 0 and pairs >= 2:
            return 6  # Full house
        if is_flush:
            return 5  # Flush
        if is_straight:
            return 4  # Straight
        if trips > 0:
            return 3  # Three of a kind
        if pairs >= 2:
            return 2  # Two pair
        if pairs == 1:
            return 1  # One pair
        return 0  # High card

    def has_straight(self, rank_values):
        sorted_ranks = sorted(set(rank_values))
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i + 4] - sorted_ranks[i] == 4:
                return True
        if set([14, 2, 3, 4, 5]).issubset(sorted_ranks):
            return True
        return False

    def parse_rank(self, card: str) -> int:
        r = card[0]
        if r == 'A':
            return 1
        if r == 'K':
            return 13
        if r == 'Q':
            return 12
        if r == 'J':
            return 11
        if r == 'T':
            return 10
        return int(r)

    def parse_suit(self, card: str) -> str:
        return card[-1]

    def evaluate_starting_hand(self, hole_cards: List[str], position_factor: float, num_players: int) -> float:
        if len(hole_cards) != 2:
            return 0.1
        r1, s1 = self.parse_rank(hole_cards[0]), self.parse_suit(hole_cards[0])
        r2, s2 = self.parse_rank(hole_cards[1]), self.parse_suit(hole_cards[1])

        rank_score = 0
        if r1 == r2:
            rank_score = 10 + r1
        elif s1 == s2:
            rank_score = max(r1, r2) + 2
        else:
            rank_score = max(r1, r2)

        if abs(r1 - r2) == 1:
            rank_score += 2
        elif abs(r1 - r2) == 2:
            rank_score += 1

        if min(r1, r2) >= 10:
            rank_score += 3

        normalized = min(rank_score / 20.0, 1.0)
        strength = 0.1 + normalized * 0.8

        strength *= (1 + (position_factor * 0.3))

        if num_players >= 6:
            strength *= 0.9

        return max(0.1, min(strength, 0.95))

    def calculate_aggression_factor(self, round_state: RoundStateClient) -> float:
        player_id_str = str(self.id)
        player_bet = round_state.player_bets.get(player_id_str, 0)
        player_actions = round_state.player_actions.get(player_id_str, "")
        if player_bet > 0 and "Raise" in player_actions:
            return 1.5
        elif player_bet > 0:
            return 1.0
        return 0.5

    def calculate_pot_odds(self, current_bet: int, pot_size: int) -> float:
        if current_bet == 0:
            return 0.0
        return current_bet / (pot_size + current_bet)

    def get_position_factor(self, round_state: RoundStateClient) -> float:
        all_players_sorted = sorted(self.all_players)
        try:
            self_index = all_players_sorted.index(self.id)
        except ValueError:
            return 0.5

        late_position_threshold = len(all_players_sorted) - 2
        if self_index >= late_position_threshold:
            return 0.8
        elif self_index >= len(all_players_sorted) // 2:
            return 0.6
        else:
            return 0.4