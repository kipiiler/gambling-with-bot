from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hole_cards = []
        self.hand_strength_estimate = 0.0
        self.position = 0  # 0 = early, 1 = middle, 2 = late
        self.opp_action_history = {}
        self.own_last_action = None
        self.stack_size = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hole_cards = player_hands
        self.opp_action_history = {player_id: [] for player_id in all_players if player_id != self.id}
        self.stack_size = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        hole_cards = self.hole_cards if hasattr(self, 'hole_cards') else []
        community_cards = round_state.community_cards if round_state.community_cards else []

        # Estimate hand strength only if hole cards are valid
        if len(hole_cards) == 2:
            self.hand_strength_estimate = self.estimate_hand_strength(hole_cards, community_cards)
        else:
            self.hand_strength_estimate = 0.0

        # Determine position (simplified)
        if self.id == round_state.current_player[0]:
            self.position = 0
        elif len(round_state.current_player) > 1 and self.id == round_state.current_player[-1]:
            self.position = 2
        else:
            self.position = 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.stack_size = remaining_chips
        hole_cards = self.hole_cards if hasattr(self, 'hole_cards') else []
        community_cards = round_state.community_cards if round_state.community_cards else []

        # Update hand strength
        if len(hole_cards) == 2:
            self.hand_strength_estimate = self.estimate_hand_strength(hole_cards, community_cards)
        else:
            self.hand_strength_estimate = 0.0

        pot = round_state.pot
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        bet_diff = current_bet - (round_state.player_bets.get(str(self.id), 0))

        # Avoid divide-by-zero or invalid values
        epsilon = 1e-8

        # Pot odds calculation
        pot_odds = (bet_diff + epsilon) / (pot + bet_diff + epsilon)

        # Default fold as fallback
        action = PokerAction.FOLD
        amount = 0

        # Preflop strategy
        if round_state.round == 'Preflop':
            # Use hand strength based on hole cards only
            preflop_strength = self.preflop_hand_ranking(hole_cards)
            # Late position steal attempt with decent cards
            if self.position == 2 and preflop_strength > 0.4 and bet_diff <= 2 * self.blind_amount:
                if preflop_strength > 0.7:
                    action = PokerAction.RAISE
                    amount = min(3 * self.blind_amount, max_raise)
                else:
                    action = PokerAction.CALL
            # Early-middle with strong hand
            elif preflop_strength > 0.8:
                if bet_diff == 0:
                    action = PokerAction.RAISE
                    amount = min(3 * self.blind_amount, max_raise)
                else:
                    if preflop_strength > 0.9 and remaining_chips > 500:
                        action = PokerAction.RAISE
                        amount = min(int(0.5 * pot), max_raise) if pot > 100 else min(3 * self.blind_amount, max_raise)
                    else:
                        action = PokerAction.CALL
            elif preflop_strength < 0.3:
                action = PokerAction.FOLD
            else:
                if bet_diff == 0:
                    action = PokerAction.CALL
                elif pot_odds < 0.2 and preflop_strength > 0.5:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD

        # Postflop strategy
        else:
            effective_strength = self.refine_hand_strength(self.hand_strength_estimate, round_state)

            if effective_strength > 0.8:
                if bet_diff == 0:
                    action = PokerAction.RAISE
                    amount = min(max(int(0.5 * pot), min_raise), max_raise)
                else:
                    # Big raise or all-in with strong hand
                    if remaining_chips > 100 or effective_strength > 0.95:
                        action = PokerAction.RAISE
                        amount = min(max(int(0.75 * pot), min_raise), max_raise)
                    else:
                        action = PokerAction.ALL_IN

            elif effective_strength > 0.5:
                if bet_diff == 0:
                    action = PokerAction.CALL
                elif pot_odds < 0.3:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD

            elif effective_strength > 0.3:
                if bet_diff == 0:
                    action = PokerAction.CALL
                elif pot_odds < 0.2:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD
            else:
                if bet_diff == 0:
                    action = PokerAction.CHECK if current_bet == 0 else PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

        # Override with valid CALL or CHECK if needed
        if action == PokerAction.CALL and bet_diff <= 0:
            action = PokerAction.CHECK
        if action == PokerAction.CHECK and current_bet > 0:
            action = PokerAction.CALL

        # Ensure raises are valid
        if action == PokerAction.RAISE:
            if amount < min_raise:
                amount = min_raise
            if amount > max_raise:
                action = PokerAction.ALL_IN
                amount = 0

        # Ensure all-in amount does not exceed max_raise
        if action == PokerAction.ALL_IN:
            amount = 0  # Amount is ignored for ALL_IN; system uses remaining chips

        # Fallback: if action would be invalid due to constraints, fold
        try:
            if action == PokerAction.CALL and bet_diff > remaining_chips:
                action = PokerAction.FOLD
            if action == PokerAction.RAISE and amount > remaining_chips:
                action = PokerAction.ALL_IN
                amount = 0
        except:
            action = PokerAction.FOLD
            amount = 0

        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        # Optionally log opponent actions
        for pid, action in round_state.player_actions.items():
            if int(pid) != self.id:
                if pid not in self.opp_action_history:
                    self.opp_action_history[pid] = []
                self.opp_action_history[pid].append(action)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally analyze game result or persist stats
        pass

    def card_rank(self, card: str):
        if not card or len(card) < 2:
            return 0
        r = card[0].upper()
        mapping = {'J': 11, 'Q': 12, 'K': 13, 'A': 14, 'T': 10}
        if r in mapping:
            return mapping[r]
        try:
            return int(r)
        except ValueError:
            return 0  # Return 0 for invalid ranks instead of raising

    def card_suit(self, card: str):
        if len(card) < 2:
            return ''
        return card[-1].lower()

    def preflop_hand_ranking(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.1
        r1, r2 = sorted([self.card_rank(hole_cards[0]), self.card_rank(hole_cards[1])], reverse=True)
        suited = self.card_suit(hole_cards[0]) == self.card_suit(hole_cards[1])
        pair = r1 == r2
        gap = r1 - r2

        score = 0.0
        if pair:
            score = 0.3 + (r1 / 100.0) * 0.5  # Up to 0.8 for AA
        else:
            # Suited bonus
            if suited:
                score += 0.1
            # Connectors and high cards
            if r1 >= 10:
                score += 0.1
            if r2 >= 10 and not pair:
                score += 0.05
            if gap == 0:  # Connected
                score += 0.1
            elif gap == 1:  # One gap
                score += 0.05
            # Lower penalty for big gaps
            if gap > 3:
                score -= 0.1
            score = min(max(score, 0.1), 0.9)
        return score

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if len(community_cards) == 0:
            return self.preflop_hand_ranking(hole_cards)

        all_cards = hole_cards + community_cards
        ranks = [self.card_rank(card) for card in all_cards]
        suits = [self.card_suit(card) for card in all_cards]
        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        suit_counts = {s: suits.count(s) for s in set(suits)}

        is_flush = max(suit_counts.values(), default=0) >= 5
        sorted_ranks = sorted(set(ranks), reverse=True)
        if 14 in sorted_ranks:  # Ace for low straight
            sorted_ranks.append(1)

        # Check for straight
        is_straight = False
        sorted_ranks = sorted(set(ranks), reverse=True)
        if 14 in sorted_ranks:
            sorted_ranks.append(1)  # For A-5 straight
        sorted_ranks = sorted(sorted_ranks, reverse=True)
        consec = 1
        for i in range(1, len(sorted_ranks)):
            if sorted_ranks[i-1] - sorted_ranks[i] == 1:
                consec += 1
                if consec >= 5:
                    is_straight = True
                    break
            else:
                consec = 1

        # Identify hand strength
        if is_straight and is_flush:
            straight_ranks = []
            for r in sorted_ranks:
                if straight_ranks and straight_ranks[-1] - r == 1:
                    straight_ranks.append(r)
                elif not straight_ranks:
                    straight_ranks = [r]
                else:
                    straight_ranks = [r]
                if len(straight_ranks) >= 5:
                    break
            if 14 in straight_ranks[:5]:
                return 1.0  # Royal flush
            else:
                return 0.95  # Straight flush

        if max(rank_counts.values(), default=0) >= 4:
            return 0.9  # Four of a kind

        if max(rank_counts.values(), default=0) >= 3 and 2 in rank_counts.values():
            return 0.8  # Full house

        if is_flush:
            return 0.7  # Flush

        if is_straight:
            return 0.6  # Straight

        if max(rank_counts.values(), default=0) >= 3:
            return 0.5  # Three of a kind

        if list(rank_counts.values()).count(2) >= 2:
            return 0.4  # Two pair

        if 2 in rank_counts.values():
            high_pair_rank = max([r for r, c in rank_counts.items() if c == 2])
            if high_pair_rank >= 10:
                return 0.35  # High pair
            elif high_pair_rank >= 7:
                return 0.25  # Mid pair
            else:
                return 0.15  # Low pair

        # High card
        top_rank = max(ranks)
        return 0.05 + (top_rank - 2) * 0.02  # Up to ~0.28 for Ace

    def refine_hand_strength(self, base_strength: float, round_state: RoundStateClient) -> float:
        # Adjust based on number of players in pot
        active_players = [pid for pid, bet in round_state.player_bets.items() if bet > 0]
        num_active = len(active_players)
        if num_active > 2:
            # In multiway pots, reduce strength slightly for non-nuts
            if base_strength < 0.8:
                base_strength *= 0.8
        # Improve strength if we're last to act (implied position value)
        if round_state.current_player and self.id == round_state.current_player[-1]:
            base_strength *= 1.1
        return min(base_strength, 1.0)