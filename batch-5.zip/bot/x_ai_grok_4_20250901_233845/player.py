from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import defaultdict

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.rank_dict = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank = self.rank_dict[card[0]]
        suit = card[1]
        return rank, suit

    def evaluate_five(self, five_cards: List[str]) -> Tuple[int, List[int]]:
        parsed = [self.parse_card(c) for c in five_cards]
        parsed.sort(key=lambda x: x[0], reverse=True)
        ranks = [p[0] for p in parsed]
        suits = [p[1] for p in parsed]

        is_flush = len(set(suits)) == 1

        rank_set = set(ranks)
        is_straight = (len(rank_set) == 5 and max(ranks) - min(ranks) == 4) or (sorted(ranks) == [2, 3, 4, 5, 14])

        if is_flush and is_straight:
            if ranks == [14, 13, 12, 11, 10]:
                return 9, ranks  # royal flush
            return 8, ranks if not (ranks == [14, 5, 4, 3, 2]) else [5, 4, 3, 2, 1]  # straight flush

        rank_count = defaultdict(int)
        for r in ranks:
            rank_count[r] += 1

        counts = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)

        if counts[0][1] == 4:
            quads = counts[0][0]
            kicker = [r for r in ranks if r != quads][0]
            return 7, [quads, kicker]  # quads

        if counts[0][1] == 3 and counts[1][1] == 2:
            return 6, [counts[0][0], counts[1][0]]  # full house

        if is_flush:
            return 5, ranks  # flush

        if is_straight:
            return 4, ranks if not (ranks == [14, 5, 4, 3, 2]) else [5, 4, 3, 2, 1]  # straight

        if counts[0][1] == 3:
            trips = counts[0][0]
            kickers = sorted([r for r in rank_set if r != trips], reverse=True)[:2]
            return 3, [trips] + kickers  # three of a kind

        if counts[0][1] == 2 and counts[1][1] == 2:
            pairs = sorted([counts[0][0], counts[1][0]], reverse=True)
            kicker = [r for r in rank_set if r not in pairs][0]
            return 2, pairs + [kicker]  # two pair

        if counts[0][1] == 2:
            pair = counts[0][0]
            kickers = sorted([r for r in rank_set if r != pair], reverse=True)[:3]
            return 1, [pair] + kickers  # one pair

        return 0, ranks  # high card

    def get_best_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole + community
        if len(all_cards) < 5:
            return (0, [])
        best = (0, [])
        for combo in combinations(all_cards, 5):
            score = self.evaluate_five(list(combo))
            if score > best:
                best = score
        return best

    def preflop_strength(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.0
        ranks = sorted([self.rank_dict[c[0]] for c in self.hole_cards], reverse=True)
        suits = [c[1] for c in self.hole_cards]
        suited = suits[0] == suits[1]
        pair = ranks[0] == ranks[1]
        diff = ranks[0] - ranks[1]

        if pair:
            if ranks[0] >= 12:
                return 0.9
            if ranks[0] >= 9:
                return 0.7
            if ranks[0] >= 6:
                return 0.5
            return 0.3
        if suited:
            if ranks[0] == 14:
                if ranks[1] >= 11:
                    return 0.8
                if ranks[1] >= 8:
                    return 0.6
                return 0.4
            if ranks[0] == 13:
                if ranks[1] >= 10:
                    return 0.6
                return 0.4
            if ranks[0] >= 11 and diff <= 3:
                return 0.5
            return 0.3
        else:
            if ranks[0] == 14:
                if ranks[1] >= 12:
                    return 0.7
                if ranks[1] >= 10:
                    return 0.5
                return 0.3
            if ranks[0] == 13 and ranks[1] >= 12:
                return 0.5
            if ranks[0] >= 10 and diff <= 2:
                return 0.4
            return 0.1

    def postflop_strength(self, community: List[str]) -> float:
        if not community:
            return 0.0
        hand_score = self.get_best_hand(self.hole_cards, community)
        hand_type = hand_score[0]
        if hand_type >= 8:
            return 1.0
        elif hand_type == 7:
            return 0.98
        elif hand_type == 6:
            return 0.9
        elif hand_type == 5:
            return 0.85
        elif hand_type == 4:
            return 0.8
        elif hand_type == 3:
            return 0.7
        elif hand_type == 2:
            return 0.6
        elif hand_type == 1:
            return 0.5
        else:
            return 0.3

    def get_strength(self, round_state: RoundStateClient) -> float:
        if round_state.round == 'Preflop':
            return self.preflop_strength()
        else:
            return self.postflop_strength(round_state.community_cards)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0
        min_r = round_state.min_raise
        max_r = round_state.max_raise
        pot = round_state.pot
        stack = remaining_chips

        strength = self.get_strength(round_state)

        if to_call > stack:
            if strength > 0.7:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        if strength > 0.8:
            raise_amount = max(min_r, pot // 2 + 1)  # avoid divide by zero
            raise_amount = min(raise_amount, max_r)
            if raise_amount >= min_r and raise_amount <= max_r and raise_amount > 0:
                return PokerAction.RAISE, raise_amount
            elif stack <= min_r:
                if strength > 0.85:
                    return PokerAction.ALL_IN, 0
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CALL, 0

        elif strength > 0.5:
            if can_check:
                return PokerAction.CHECK, 0
            else:
                if to_call < (pot + to_call) * 0.2:  # approximate pot odds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        else:
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass