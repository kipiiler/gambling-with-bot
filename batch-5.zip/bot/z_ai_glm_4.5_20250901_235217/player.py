from typing import List, Tuple, Dict, Any
from itertools import combinations
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.blind_amount = 0
        self.position_map = {}
        self.hand_evaluations = {}
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.blind_amount = blind_amount
        self.position_map = {
            'SB': small_blind_player_id,
            'BB': big_blind_player_id
        }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            pot = round_state.pot
            community_cards = round_state.community_cards
            round_name = round_state.round
            
            # Get our hole cards
            my_cards = self._get_my_cards(round_state)
            if not my_cards:
                return (PokerAction.FOLD, 0)
            
            # Determine position
            position = self._determine_position(round_state)
            
            # Preflop strategy
            if round_name == 'Preflop':
                group = self._preflop_group(my_cards)
                return self._preflop_action(round_state, group, position, call_amount)
            
            # Postflop strategy
            hand_strength = self._evaluate_hand(my_cards + community_cards)
            return self._postflop_action(round_state, hand_strength, call_amount, pot)
        
        except Exception:
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
    
    def _get_my_cards(self, round_state: RoundStateClient) -> List[str]:
        """Extract my hole cards from the round state."""
        # In a real implementation, we would get this from the server
        # For now, we assume the cards are available in the state
        if hasattr(round_state, 'player_hands') and str(self.id) in round_state.player_hands:
            return round_state.player_hands[str(self.id)]
        return []
    
    def _determine_position(self, round_state: RoundStateClient) -> str:
        """Determine position (SB, BB, early, middle, late)"""
        if self.id == self.position_map['SB']:
            return 'SB'
        if self.id == self.position_map['BB']:
            return 'BB'
        
        current_players = round_state.current_player
        if not current_players:
            return 'middle'
        
        idx = current_players.index(self.id)
        n = len(current_players)
        
        if idx < n // 3:
            return 'early'
        elif idx < 2 * n // 3:
            return 'middle'
        else:
            return 'late'
    
    def _preflop_group(self, hand: List[str]) -> int:
        """Assign hand to a strength group (1-8, 1 is best)"""
        rank_map = {'2':0, '3':1, '4':2, '5':3, '6':4, '7':5, '8':6, '9':7, 'T':8, 'J':9, 'Q':10, 'K':11, 'A':12}
        r1 = rank_map[hand[0][0]]
        r2 = rank_map[hand[1][0]]
        suited = hand[0][1] == hand[1][1]
        
        # Order cards high to low
        if r1 < r2:
            r1, r2 = r2, r1
        
        # Group assignments
        if r1 == 12:  # Ace high
            if r2 == 12: return 1  # AA
            if r2 == 11 and suited: return 1  # AKs
            if r2 == 11: return 2  # AK
            if r2 == 10 and suited: return 2  # AQs
            if r2 == 10: return 3  # AQ
            return 4
        elif r1 == 11:  # King high
            if r2 == 11: return 1  # KK
            if r2 == 10 and suited: return 2  # KQs
            if r2 == 10: return 3  # KQ
            return 5
        elif r1 == 10:  # Queen high
            if r2 == 10: return 1  # QQ
            if r2 == 9 and suited: return 2  # QJs
            if r2 == 9: return 3  # QJ
            return 6
        elif r1 == 9:  # Jack high
            if r2 == 9: return 1  # JJ
            if r2 == 8 and suited: return 3  # JTs
            if r2 == 8: return 4  # JT
            return 7
        elif r1 == 8:  # Ten high
            if r2 == 8: return 2  # TT
            return 8
        else:
            return 8
    
    def _preflop_action(self, state: RoundStateClient, group: int, position: str, call_amount: int) -> Tuple[PokerAction, int]:
        """Select preflop action based on hand group and position"""
        # Check for raises
        has_raise = state.current_bet > self.blind_amount
        min_raise = state.min_raise
        max_raise = state.max_raise
        
        # Group 1: Always raise/reraise
        if group <= 1:
            if has_raise:
                # Reraise with group 1
                raise_amount = min(3 * state.current_bet - state.player_bets.get(str(self.id), 0), max_raise)
                if raise_amount < min_raise:
                    return (PokerAction.RAISE, min_raise)
                return (PokerAction.RAISE, raise_amount)
            else:
                # Open raise
                raise_amount = min(3 * self.blind_amount - state.player_bets.get(str(self.id), 0), max_raise)
                if raise_amount < min_raise:
                    return (PokerAction.RAISE, min_raise)
                return (PokerAction.RAISE, raise_amount)
        
        # Group 2: Raise/call based on position
        elif group == 2:
            if has_raise:
                return (PokerAction.CALL, 0)
            else:
                if position in ['late', 'middle']:
                    raise_amount = min(2.5 * self.blind_amount - state.player_bets.get(str(self.id), 0), max_raise)
                    if raise_amount < min_raise:
                        return (PokerAction.RAISE, min_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
        
        # Group 3: Call in late position, fold otherwise
        elif group == 3:
            if has_raise:
                return (PokerAction.FOLD, 0)
            else:
                if position == 'late':
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Group 4+: Call if very cheap, otherwise fold
        else:
            if call_amount <= self.blind_amount // 4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand(self, cards: List[str]) -> Tuple[int, ...]:
        """Evaluate 7-card poker hand and return strength tuple"""
        try:
            # Convert to integers
            card_ints = []
            for card in cards:
                rank_char = card[0]
                suit_char = card[1]
                rank = {'2':0, '3':1, '4':2, '5':3, '6':4, '7':5, '8':6, '9':7, 'T':8, 'J':9, 'Q':10, 'K':11, 'A':12}[rank_char]
                suit = {'s':0, 'h':1, 'd':2, 'c':3}[suit_char]
                card_ints.append(rank * 4 + suit)
            
            # Check cache
            canonical = tuple(sorted(card_ints))
            if canonical in self.hand_evaluations:
                return self.hand_evaluations[canonical]
            
            # Evaluate all 5-card combinations
            best = None
            for combo in combinations(card_ints, 5):
                hand = self._evaluate_5card(list(combo))
                if best is None or hand > best:
                    best = hand
            
            # Cache result
            self.hand_evaluations[canonical] = best
            return best
        except Exception:
            return (0, 0, 0, 0, 0, 0)
    
    def _evaluate_5card(self, cards: List[int]) -> Tuple[int, ...]:
        """Evaluate 5-card poker hand"""
        ranks = sorted([c // 4 for c in cards], reverse=True)
        suits = [c % 4 for c in cards]
        rank_set = set(ranks)
        suit_set = set(suits)
        
        # Check for flush
        is_flush = len(suit_set) == 1
        
        # Check for straight
        is_straight = False
        straight_high = 0
        
        # Regular straight
        if len(rank_set) == 5 and ranks[0] - ranks[4] == 4:
            is_straight = True
            straight_high = ranks[0]
        # Wheel straight (A-5)
        elif set(ranks) == {12, 3, 2, 1, 0}:
            is_straight = True
            straight_high = 5
        
        # Straight flush
        if is_flush and is_straight:
            return (8, straight_high, 0, 0, 0, 0)
        
        # Four of a kind
        if ranks[0] == ranks[3] or ranks[1] == ranks[4]:
            if ranks[0] == ranks[3]:
                return (7, ranks[0], ranks[4], 0, 0, 0)
            else:
                return (7, ranks[1], ranks[0], 0, 0, 0)
        
        # Full house
        if ranks[0] == ranks[2] and ranks[3] == ranks[4]:
            return (6, ranks[0], ranks[3], 0, 0, 0)
        if ranks[2] == ranks[4] and ranks[0] == ranks[1]:
            return (6, ranks[2], ranks[0], 0, 0, 0)
        
        # Flush
        if is_flush:
            return (5, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])
        
        # Straight
        if is_straight:
            return (4, straight_high, 0, 0, 0, 0)
        
        # Three of a kind
        if ranks[0] == ranks[2] or ranks[1] == ranks[3] or ranks[2] == ranks[4]:
            if ranks[0] == ranks[2]:
                kickers = sorted(set(ranks) - {ranks[0]}, reverse=True)
                return (3, ranks[0], kickers[0], kickers[1], 0, 0)
            elif ranks[1] == ranks[3]:
                kickers = sorted(set(ranks) - {ranks[1]}, reverse=True)
                return (3, ranks[1], kickers[0], kickers[1], 0, 0)
            else:
                kickers = sorted(set(ranks) - {ranks[2]}, reverse=True)
                return (3, ranks[2], kickers[0], kickers[1], 0, 0)
        
        # Two pair
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        pairs = [r for r, cnt in rank_counts.items() if cnt == 2]
        if len(pairs) >= 2:
            pairs.sort(reverse=True)
            kicker = [r for r, cnt in rank_counts.items() if cnt == 1][0]
            return (2, pairs[0], pairs[1], kicker, 0, 0)
        
        # One pair
        if len(pairs) == 1:
            pair = pairs[0]
            kickers = sorted([r for r in ranks if r != pair], reverse=True)
            return (1, pair, kickers[0], kickers[1], kickers[2], 0)
        
        # High card
        return (0, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])
    
    def _postflop_action(self, state: RoundStateClient, hand_strength: Tuple[int, ...], call_amount: int, pot: int) -> Tuple[PokerAction, int]:
        """Select postflop action based on hand strength"""
        hand_rank = hand_strength[0]
        my_bet = state.player_bets.get(str(self.id), 0)
        min_raise = state.min_raise
        max_raise = state.max_raise
        
        # Very strong hands (straight flush or quads)
        if hand_rank >= 7:
            if call_amount > 0:
                # Raise if we can
                if max_raise > 0:
                    raise_amount = min(pot, max_raise)
                    if raise_amount < min_raise:
                        raise_amount = min_raise
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.ALL_IN, 0)
            else:
                # Bet if no action
                if max_raise > 0:
                    bet_amount = min(pot // 2, max_raise)
                    if bet_amount < min_raise:
                        bet_amount = min_raise
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.ALL_IN, 0)
        
        # Strong hands (full house, flush, straight)
        elif hand_rank >= 5:
            if call_amount > 0:
                if call_amount <= pot // 2:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                if max_raise > 0:
                    bet_amount = min(pot // 3, max_raise)
                    if bet_amount < min_raise:
                        bet_amount = min_raise
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Medium hands (three of a kind, two pair)
        elif hand_rank >= 2:
            if call_amount > 0:
                if call_amount <= pot // 4:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            return (PokerAction.CHECK, 0)
        
        # Weak hands (one pair or high card)
        else:
            if call_amount > 0:
                return (PokerAction.FOLD, 0)
            return (PokerAction.CHECK, 0)