import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Try to use the excellent pure-python “treys” evaluator if the
# environment provides it.  If it is not available we fall back to a
# very coarse heuristic evaluator (always safe – never raises).
try:
    from treys import Card, Evaluator  # type: ignore
    _HAS_TREYS = True
except Exception:  # pragma: no cover
    _HAS_TREYS = False


class SimplePlayer(Bot):
    """
    A very small, self-contained NL Hold’em bot that

    1. Plays reasonable pre-flop ranges (tight-aggressive).
    2. Uses the ‘treys’ hand evaluator (if available) post-flop to
       estimate hand strength.
    3. Makes sure every action returned is legal given the current
       RoundStateClient.
    4. Never throws an exception (defensive coding everywhere).
    """

    # ---- public API (required by the framework) --------------------

    def __init__(self) -> None:
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0                 # small blind amount
        self.big_blind_player_id: int | None = None
        self.small_blind_player_id: int | None = None
        self.all_players: List[int] = []
        self.evaluator = Evaluator() if _HAS_TREYS else None
        self.round_hole_cards: Dict[int, List[str]] | None = None
        self.round_number: int = 0

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # try to capture our hole cards if provided in RoundStateClient
        self.round_number = round_state.round_num
        self.round_hole_cards = getattr(round_state, "player_hands", {})
        # nothing else to do here

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide and return an action that is ALWAYS valid.
        For actions other than RAISE we return amount = 0.
        For RAISE we return amount that respects [min_raise, max_raise].
        """

        # Defensive helpers --------------------------------------------------
        def safe_get(dct, key, default=0):
            try:
                return dct.get(str(key), default)
            except Exception:
                return default

        def current_bet_needed() -> int:
            """Amount we still need to put in if we want to call."""
            want = max(round_state.current_bet - safe_get(round_state.player_bets, self.id), 0)
            return min(want, remaining_chips)

        def make_raise(target_amount: int) -> Tuple[PokerAction, int]:
            """
            Clamp target_amount to [min_raise, max_raise].
            If after clamping the amount is invalid, fall back to ALL-IN.
            """
            amount = max(round_state.min_raise, target_amount)
            amount = min(amount, round_state.max_raise)
            if amount < round_state.min_raise:  # cannot legally raise
                return PokerAction.ALL_IN, 0
            return PokerAction.RAISE, amount

        # --------------------------------------------------------------------

        call_amount: int = current_bet_needed()

        # Try to fetch our current hole cards (two cards) if available
        my_hole_cards: List[str] = []
        if self.round_hole_cards:
            my_hole_cards = safe_get(self.round_hole_cards, self.id, [])

        street: str = (round_state.round or "").lower()  # preflop / flop / turn / river
        is_preflop = street.startswith("pre")

        # --------------- 1. Pre-flop ----------------------------------------
        if is_preflop:
            hand_group = self._classify_starting_hand(my_hole_cards)

            # Uncontested pot (no bet yet)
            if call_amount == 0:
                if hand_group == 1:
                    # premium – open large
                    return make_raise(self.blind_amount * 4)
                elif hand_group == 2:
                    return make_raise(self.blind_amount * 3)
                elif hand_group == 3:
                    # speculative; just limp / check
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0

            # Somebody has raised -------------------------------------------
            else:
                if hand_group == 1:
                    # 3-bet to ~3× the bet to call, but cap in range
                    return make_raise(call_amount * 3)
                elif hand_group == 2:
                    # call if not too expensive; otherwise fold
                    if call_amount <= remaining_chips * 0.1:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                elif hand_group == 3:
                    # call only if cheap
                    if call_amount <= self.blind_amount * 2:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

        # --------------- 2. Post-flop ---------------------------------------
        win_prob: float = 0.5  # default guess

        if _HAS_TREYS and len(my_hole_cards) == 2:
            # translate cards for treys
            try:
                board_ints = [Card.new(c) for c in round_state.community_cards]
                hand_ints = [Card.new(c) for c in my_hole_cards]
                score = self.evaluator.evaluate(board_ints, hand_ints)
                class_rank = self.evaluator.get_rank_class(score)
                # estimate win probabilities from rank class (rough mapping)
                if class_rank <= 5:       # Flush or better
                    win_prob = 0.9
                elif class_rank == 6:     # Straight
                    win_prob = 0.8
                elif class_rank == 7:     # Trips
                    win_prob = 0.65
                elif class_rank == 8:     # Two pair
                    win_prob = 0.55
                elif class_rank == 9:     # One pair
                    win_prob = 0.35
                else:                     # High card
                    win_prob = 0.15
            except Exception:
                # Fallback if something goes wrong
                win_prob = 0.5
        else:
            # Coarse fallback heuristic: the more community cards, the less
            # likely high-card wins.
            board_len = len(round_state.community_cards or [])
            win_prob = max(0.1, 1.0 - board_len * 0.15)

        pot_size: int = round_state.pot
        # Pot odds to call
        pot_after_call: float = pot_size + call_amount + 1e-9
        pot_odds: float = call_amount / pot_after_call if pot_after_call > 0 else 1.0

        # ------------------------------------------------ decision ----------
        if call_amount == 0:
            # We can check – sometimes bet for value/protection if strong
            if win_prob > 0.80:
                return make_raise(int(pot_size * 0.75))
            if win_prob > 0.60:
                return make_raise(int(pot_size * 0.5))
            if win_prob > 0.40:
                return PokerAction.CHECK, 0
            return PokerAction.CHECK, 0
        else:
            # We face a bet
            if win_prob > 0.80:
                # raise big
                return make_raise(int(call_amount * 3))
            if win_prob > 0.55 and win_prob > pot_odds:
                # profitable call
                return PokerAction.CALL, 0
            if win_prob > 0.45 and call_amount < pot_size * 0.25:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    # ---- callback stubs (no advanced learning at the moment) --------------

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could log things here – keep it lightweight
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # ---- internal helpers --------------------------------------------------

    @staticmethod
    def _rank_value(card_str: str) -> int:
        rank_char = (card_str or "X")[0]
        order = "23456789TJQKA"
        return order.index(rank_char) if rank_char in order else -1

    def _classify_starting_hand(self, cards: List[str]) -> int:
        """
        Returns hand group:
        1 – premium
        2 – strong
        3 – medium/speculative
        4 – everything else
        """
        if len(cards) != 2:
            return 4

        r1 = self._rank_value(cards[0])
        r2 = self._rank_value(cards[1])
        if r1 < 0 or r2 < 0:
            return 4

        pair = r1 == r2
        suited = cards[0][1] == cards[1][1]
        ranks_sorted = sorted([r1, r2], reverse=True)
        high, low = ranks_sorted

        # Helper lambdas
        def is_broadway(rank):  # Ten or better
            return rank >= 8

        # Group 1 – Premium
        if pair and r1 >= 10:  # JJ, QQ, KK, AA
            return 1
        if {r1, r2} == {12, 8} and suited:  # AKs (A=12, K=11, Q=10, J=9, T=8)
            return 1

        # Group 2 – Strong
        if pair and r1 == 9:  # TT
            return 2
        if pair and r1 == 8:  # 99
            return 3
        if pair and 5 <= r1 <= 7:  # 66–88 medium pairs
            return 3
        if high == 12 and low >= 8:  # A broadway
            return 2 if suited or low >= 10 else 3
        if high >= 10 and low >= 9 and suited:  # strong suited connectors
            return 2

        # Group 3 – suited connectors / small pairs
        if pair:  # any other pair
            return 3
        if suited and high - low == 1 and low >= 5:  # suited connectors 67s+
            return 3
        if suited and is_broadway(high):  # suited broadway like KJs, QTs
            return 3

        # Everything else
        return 4