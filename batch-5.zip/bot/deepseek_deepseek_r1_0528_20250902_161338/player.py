from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_cards = []
        self.blind_amount = 0
        self.my_id = None
        self.player_order = []
        self.big_blind_id = None
        self.small_blind_id = None
        self.position = -1
        self.hand_strength = 0
        self.previous_action = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_id = self.id
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.blind_amount = blind_amount
        self.player_order = all_players
        self.my_cards = player_hands[:]  # Store initial hand

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.previous_action = None
        # Update position
        idx = self.player_order.index(self.my_id)
        bb_idx = self.player_order.index(self.big_blind_id)
        if bb_idx == 0:
            if idx == len(self.player_order) - 1:
                self.position = 0  # Dealer
            elif idx == 0:
                self.position = 1  # Small blind
            else:
                self.position = idx + 1
        else:
            if idx < bb_idx:
                self.position = idx + (len(self.player_order) - bb_idx) + 1
            else:
                self.position = idx - bb_idx + 1

    def evaluate_hand(self, hole_cards, board_cards):
        """Simple hand strength estimation"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Basic hand evaluation categories
        categories = {
            "high_card": 0.0,
            "pair": 0.3,
            "two_pair": 0.5,
            "trips": 0.6,
            "straight": 0.7,
            "flush": 0.75,
            "full_house": 0.85,
            "quads": 0.95,
            "straight_flush": 1.0
        }
        
        all_cards = hole_cards + (board_cards if board_cards else [])
        if not all_cards:
            return 0.0
            
        # Count suits and ranks
        suit_count = {}
        rank_count = {}
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        
        for card in all_cards:
            if card:  # Ensure we don't process empty cards
                if card[0] in rank_map:
                    rank = rank_map[card[0]]
                else:
                    # Skip if card sequence is invalid
                    continue
                suit = card[1]
                rank_count[rank] = rank_count.get(rank, 0) + 1
                suit_count[suit] = suit_count.get(suit, 0) + 1
                
        # Calculate hand strength based on what's possible
        rank_vals = list(rank_count.values())
        if 4 in rank_vals:
            return categories["quads"]
        if 3 in rank_vals and 2 in rank_vals:
            return categories["full_house"]
        if max(suit_count.values(), default=0) >= 5:
            return categories["flush"]
        if len(rank_count) >= 5:
            sorted_ranks = sorted(rank_count.keys())
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    return categories["straight"]
        if 3 in rank_vals:
            return categories["trips"]
        if rank_vals.count(2) >= 2:
            return categories["two_pair"]
        if 2 in rank_vals:
            return categories["pair"]
        # If we don't detect anything, return high card strength
        best_rank = max(rank_count.keys(), default=0) if rank_count else 0
        return min(0.2, (best_rank / 30))  # Normalize best rank to 0-0.2 range

    def estimate_strength(self, round_state, hole_cards):
        """Estimate hand strength based on current game state"""
        board = round_state.community_cards
        
        # Start with simple hand evaluation
        strength = self.evaluate_hand(hole_cards, board)
        
        # Position adjustment
        pos_multiplier = 1.0 + ((self.position / 6.0) * 0.3)  # Up to 1.3
        strength *= pos_multiplier
        
        # Adjust for aggression
        prev_actions = [a for a in round_state.player_actions.values() if a.upper() in ['RAISE', 'ALL_IN']]
        if any(prev_actions):
            strength *= 0.9  # Be more cautious if previous aggression
            
        return min(strength, 1.0)  # Cap at 1.0

    def can_aggressive(self, strength):
        """Decide if we should play aggressively"""
        if strength > 0.65:
            return True
        if strength > 0.4 and self.position > 4:  # Late position
            return True
        if strength > 0.2 and self.position > 6:  # Very late position
            return True
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Implements the poker bot logic"""
        # Get current betting context
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_bet)
        
        # Practical values
        is_preflop = (round_state.round == 'Preflop')
        has_raised = self.previous_action in ["RAISE", "ALL_IN"]
        stack = remaining_chips
        bet_ratio = (to_call / stack) if stack > 0 else 1.0
        pot_size = round_state.pot
        strength = self.estimate_strength(round_state, self.my_cards)
        
        # Dedicated action selection
        if to_call > 0:
            # We need to call or raise
            odds = to_call / pot_size if pot_size > 0 else 0
            if strength > 0.7 or (odds < 0.1 and strength > 0.1):
                # Strong hand or good odds - raise for value
                if stack > min_raise and self.can_aggressive(strength):
                    self.previous_action = "RAISE"
                    amount = max(min_raise, min(strength * pot_size, max_raise))
                    return (PokerAction.RAISE, amount)
                else:
                    self.previous_action = "CALL"
                    return (PokerAction.CALL, to_call)
            elif odds < 0.3 or strength > 0.2:  # Okay odds or fair hand
                self.previous_action = "CALL"
                return (PokerAction.CALL, to_call)
            else:
                self.previous_action = "FOLD"
                return (PokerAction.FOLD, 0)
        else:
            # No bet to call - can check/raise
            if strength > 0.7:
                # Strong hand - bet for value
                bet_size = min(max(min_raise, int(strength * pot_size // 2)), max_raise)
                if bet_size > stack and stack > 0:
                    self.previous_action = "ALL_IN"
                    return (PokerAction.ALL_IN, 0)
                else:
                    self.previous_action = "RAISE"
                    return (PokerAction.RAISE, bet_size)
            elif is_preflop and self.can_aggressive(strength):
                # Bluff or semi-bluff in position
                self.previous_action = "RAISE"
                return (PokerAction.RAISE, min_raise)
            else:
                self.previous_action = "CHECK"
                return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass  # No special cleanup needed

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass  # No special game end handling