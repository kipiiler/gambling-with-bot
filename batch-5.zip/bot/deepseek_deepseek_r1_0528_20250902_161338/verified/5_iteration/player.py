from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools
import random
import time

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.player_id = None
        self.opponent_aggression = 0.5
        self.opponent_tightness = 0.5
        self.hand_strength_cache = {}
        self.last_action_time = time.time()

    def set_id(self, player_id: int) -> None:
        self.id = player_id
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Extract our hole cards
        our_index = all_players.index(self.player_id)
        hand_str = player_hands[our_index]
        if ' ' in hand_str:
            self.hole_cards = hand_str.split()
        else:
            self.hole_cards = [hand_str[i:i+2] for i in range(0, len(hand_str), 2)]
        
        # Reset opponent modeling
        self.opponent_aggression = 0.5
        self.opponent_tightness = 0.5
        self.hand_strength_cache = {}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # Reset cache at start of each round
        self.hand_strength_cache = {}

    def card_rank(self, card_char: str) -> int:
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, 
            '7': 7, '8': 8, '9': 9, 'T': 10, 
            'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        return rank_map.get(card_char, 0)

    def preflop_strength(self, hole_cards: List[str]) -> float:
        card1, card2 = hole_cards
        rank1 = self.card_rank(card1[0])
        rank2 = self.card_rank(card2[0])
        suited = card1[1] == card2[1]
        
        if rank1 == rank2:  # Pair
            return rank1 / 14.0
        else:
            high = max(rank1, rank2)
            low = min(rank1, rank2)
            gap = high - low
            strength = high / 14.0 - gap * 0.02
            if suited:
                strength += 0.05
            return min(1.0, max(0.1, strength))

    def evaluate_5cards(self, cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
        ranks = sorted([self.card_rank(c[0]) for c in cards], reverse=True)
        suits = [c[1] for c in cards]
        
        # Check flush
        is_flush = len(set(suits)) == 1
        
        # Check straight
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4 or 
                (ranks[0] == 14 and ranks[1] == 5 and ranks[2] == 4 and 
                 ranks[3] == 3 and ranks[4] == 2))  # Handle A-5 straight
        
        if is_flush and is_straight:
            if ranks[0] == 14 and ranks[1] == 13:  # Royal flush
                return (10, (14,))
            return (9, (ranks[0],))  # Straight flush
        
        # Check four of a kind
        if ranks[0] == ranks[3]:
            return (8, (ranks[0], ranks[4]))
        if ranks[1] == ranks[4]:
            return (8, (ranks[1], ranks[0]))
        
        # Check full house
        if ranks[0] == ranks[2] and ranks[3] == ranks[4]:
            return (7, (ranks[0], ranks[3]))
        if ranks[0] == ranks[1] and ranks[2] == ranks[4]:
            return (7, (ranks[2], ranks[0]))
        
        if is_flush:
            return (6, tuple(ranks))
        
        if is_straight:
            high = ranks[0]
            if high == 14 and ranks[1] == 5:  # Wheel straight (A-5)
                high = 5
            return (5, (high,))
        
        # Check three of a kind
        if ranks[0] == ranks[2]:
            return (4, (ranks[0], ranks[3], ranks[4]))
        if ranks[1] == ranks[3]:
            return (4, (ranks[1], ranks[0], ranks[4]))
        if ranks[2] == ranks[4]:
            return (4, (ranks[2], ranks[0], ranks[1]))
        
        # Check two pair
        if ranks[0] == ranks[1] and ranks[2] == ranks[3]:
            return (3, (ranks[0], ranks[2], ranks[4]))
        if ranks[0] == ranks[1] and ranks[3] == ranks[4]:
            return (3, (ranks[0], ranks[3], ranks[2]))
        if ranks[1] == ranks[2] and ranks[3] == ranks[4]:
            return (3, (ranks[1], ranks[3], ranks[0]))
        
        # Check one pair
        if ranks[0] == ranks[1]:
            return (2, (ranks[0],) + tuple(sorted(ranks[2:], reverse=True))
        if ranks[1] == ranks[2]:
            return (2, (ranks[1], ranks[0]) + tuple(ranks[3:]))
        if ranks[2] == ranks[3]:
            return (2, (ranks[2], ranks[0], ranks[1], ranks[4]))
        if ranks[3] == ranks[4]:
            return (2, (ranks[3], ranks[0], ranks[1], ranks[2]))
        
        # High card
        return (1, tuple(ranks))

    def best_hand_rank(self, seven_cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
        best = None
        for combo in itertools.combinations(seven_cards, 5):
            rank_val = self.evaluate_5cards(list(combo))
            if best is None or rank_val > best:
                best = rank_val
        return best

    def monte_carlo_hand_strength(self, hole_cards: List[str], 
                                 community_cards: List[str], 
                                 num_samples: int) -> float:
        cache_key = (tuple(hole_cards), tuple(community_cards), num_samples)
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        # Create full deck
        ranks = [str(r) for r in range(2,10)] + ['T', 'J', 'Q', 'K', 'A']
        suits = ['h', 'd', 'c', 's']
        full_deck = [r + s for r in ranks for s in suits]
        
        # Remove known cards
        known_cards = hole_cards + community_cards
        for card in known_cards:
            if card in full_deck:
                full_deck.remove(card)
        
        wins = 0
        ties = 0
        total = num_samples
        
        for _ in range(num_samples):
            # Shuffle remaining deck
            random.shuffle(full_deck)
            
            # Complete board if needed
            board = community_cards.copy()
            if len(board) < 5:
                needed = 5 - len(board)
                board += full_deck[:needed]
                remaining_deck = full_deck[needed:]
            else:
                remaining_deck = full_deck.copy()
            
            # Assign opponent hand
            opp_hand = remaining_deck[:2]
            remaining_deck = remaining_deck[2:]
            
            # Evaluate hands
            our_rank = self.best_hand_rank(hole_cards + board)
            opp_rank = self.best_hand_rank(opp_hand + board)
            
            # Compare
            if our_rank > opp_rank:
                wins += 1
            elif our_rank == opp_rank:
                ties += 1
        
        strength = (wins + ties/2) / total
        self.hand_strength_cache[cache_key] = strength
        return strength

    def hand_value_to_strength(self, hand_value: Tuple[int, Tuple[int, ...]]) -> float:
        category = hand_value[0]
        if category == 10:  # Royal flush
            return 1.0
        elif category == 9:  # Straight flush
            return 0.95
        elif category == 8:  # Four of a kind
            return 0.90
        elif category == 7:  # Full house
            return 0.80
        elif category == 6:  # Flush
            return 0.70
        elif category == 5:  # Straight
            return 0.60
        elif category == 4:  # Three of a kind
            return 0.50
        elif category == 3:  # Two pair
            return 0.40
        elif category == 2:  # One pair
            return 0.25
        else:  # High card
            return 0.10

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate time elapsed since last action
        elapsed = time.time() - self.last_action_time
        self.last_action_time = time.time()
        
        # Get current player ID as string
        current_player_str = str(self.id)
        
        # Get current bet and player's current bet
        current_bet = round_state.current_bet
        player_bets = round_state.player_bets
        my_bet_so_far = player_bets.get(current_player_str, 0)
        to_call = max(0, current_bet - my_bet_so_far)
        pot = round_state.pot
        
        # Calculate pot odds
        if pot + to_call > 0:
            pot_odds = to_call / (pot + to_call + 1e-8)
        else:
            pot_odds = 0
        
        # Determine position
        is_button = self.id == self.small_blind_player_id
        is_big_blind = self.id == self.big_blind_player_id
        is_preflop = round_state.round == 'Preflop'
        is_aggressive_position = is_button and is_preflop
        
        # Calculate hand strength
        strength = 0.0
        if is_preflop:
            strength = self.preflop_strength(self.hole_cards)
            # Adjust for position
            if is_aggressive_position:
                strength = min(1.0, strength * 1.2)
        else:
            # Determine number of samples based on street
            if round_state.round == 'Flop':
                num_samples = 50
            elif round_state.round == 'Turn':
                num_samples = 100
            else:  # River
                num_samples = 200
            
            # Use Monte Carlo simulation
            strength = self.monte_carlo_hand_strength(
                self.hole_cards, 
                round_state.community_cards, 
                num_samples
            )
            
            # Adjust for opponent modeling
            strength = min(1.0, strength * (1.0 + (1 - self.opponent_tightness) * 0.2))
        
        # Handle all-in situations
        if to_call >= remaining_chips:
            if strength > pot_odds or strength > 0.5:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Decision logic
        if strength > 0.8:
            # Very strong hand - maximize value
            if to_call == 0:
                # We can bet/raise
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                raise_amount = min_raise + int(0.67 * pot)
                raise_amount = min(max_raise, max(min_raise, raise_amount))
                
                if raise_amount >= remaining_chips - to_call:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, raise_amount)
            else:
                # Raise opponent's bet
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                raise_amount = min_raise + int(0.5 * pot)
                raise_amount = min(max_raise, max(min_raise, raise_amount))
                
                if raise_amount >= remaining_chips - to_call:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, raise_amount)
        
        elif strength > 0.6:
            # Strong hand - build pot cautiously
            if to_call == 0:
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                raise_amount = min_raise + int(0.4 * pot)
                raise_amount = min(max_raise, max(min_raise, raise_amount))
                
                if raise_amount >= remaining_chips - to_call:
                    return (PokerAction.ALL_IN, 0)
                elif random.random() < 0.7:  # 70% chance to bet/raise
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if strength > pot_odds:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        elif strength > 0.4:
            # Medium strength - check/call small bets
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                if strength > pot_odds and to_call < pot * 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        else:
            # Weak hand - fold unless facing no bet
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # Update opponent model based on their actions
        opponent_id = [p for p in self.all_players if p != self.id][0]
        opponent_actions = round_state.player_actions.get(str(opponent_id), [])
        
        aggression_factors = {
            'RAISE': 1.0,
            'ALL_IN': 1.0,
            'CALL': 0.5,
            'CHECK': 0.0,
            'FOLD': -0.5
        }
        
        tightness_factors = {
            'FOLD': 1.0,
            'CALL': 0.5,
            'CHECK': 0.0,
            'RAISE': -0.5,
            'ALL_IN': -1.0
        }
        
        # Calculate average aggression and tightness
        if opponent_actions:
            aggression_sum = sum(aggression_factors.get(action, 0) for action in opponent_actions)
            tightness_sum = sum(tightness_factors.get(action, 0) for action in opponent_actions)
            
            self.opponent_aggression = max(0.1, min(0.9, 
                self.opponent_aggression * 0.7 + (aggression_sum / len(opponent_actions)) * 0.3))
            self.opponent_tightness = max(0.1, min(0.9, 
                self.opponent_tightness * 0.7 + (tightness_sum / len(opponent_actions)) * 0.3))

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                   all_scores: dict, active_players_hands: dict) -> None:
        # Reset for new game
        self.opponent_aggression = 0.5
        self.opponent_tightness = 0.5
        self.hand_strength_cache = {}