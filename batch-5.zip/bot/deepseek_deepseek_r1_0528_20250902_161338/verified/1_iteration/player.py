from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.small_blind_player_id = 0
        self.big_blind_player_id = 0
        self.players = []
        self.hand_rankings = {"ROYAL_FLUSH": 8, "STRAIGHT_FLUSH": 7, "FOUR_OF_A_KIND": 6, "FULL_HOUSE": 5, 
                              "FLUSH": 4, "STRAIGHT": 3, "THREE_OF_A_KIND": 2, "TWO_PAIR": 1, "PAIR": 0, "HIGH_CARD": -1}
        self.ranks = "23456789TJQKA"
        self.suits = "cdhs"
        self.total_players_count = 0
        self.position_strategy_initialized = False
        self.early_position_threshold = 0.33
        self.late_position_threshold = 0.67
        self.position_adjustment = 0
        self.pre_flop_group = -1
        self.initial_bankroll = 10000
        self.pot_odds_threshold = 0.2
        self.aggressive_threshold = 0.7
        self.conservative_threshold = 0.4
        self.preflop_hand_groups = {
            1: ["AA", "KK", "QQ", "JJ", "AKs"],
            2: ["TT", "AK", "AQs", "AJs", "KQs"],
            3: ["99", "AQ", "ATs", "KJs", "QJs"],
            4: ["88", "JT", "QTs", "KTs", "J9s", "T9s", "98s"],
            5: ["77", "A9s", "A5s", "A4s", "A3s", "A2s", "K9s", "J8s"],
            6: ["66", "55", "44", "33", "22", "AT", "KJ"],
            7: []
        }
        self.pre_flop_group_str = ""

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players
        self.total_players_count = len(all_players)
        self.position_strategy_initialized = False
        self.pre_flop_group = self.classify_pre_flop_hand()
        self.pre_flop_group_str = self.get_preflop_group_name()
        self.determine_position()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def determine_position(self):
        if not self.players: return
        try:
            player_index = self.players.index(self.id)
            big_blind_index = self.players.index(self.big_blind_player_id)
            small_blind_index = self.players.index(self.small_blind_player_id)
            try:
                button_index = (small_blind_index - 1) % self.total_players_count
            except:
                button_index = small_blind_index

            relative_position = (player_index - button_index) % self.total_players_count
            position_ratio = relative_position / self.total_players_count
            self.position_adjustment = 0
            if position_ratio < self.early_position_threshold:
                self.position_adjustment = -1
            elif position_ratio > self.late_position_threshold:
                self.position_adjustment = 1
            self.position_strategy_initialized = True
        except Exception as e:
            self.position_adjustment = 0

    def classify_pre_flop_hand(self) -> int:
        if not self.hole_cards or len(self.hole_cards) < 2: 
            return 7
            
        card1, card2 = self.hole_cards
        r1, s1 = card1[0], card1[1]
        r2, s2 = card2[0], card2[1]
        idx1, idx2 = self.ranks.index(r1), self.ranks.index(r2)
        low_idx, high_idx = min(idx1, idx2), max(idx1, idx2)
        suited = s1 == s2
        key = "{}{}".format(self.ranks[high_idx], self.ranks[low_idx])
        if suited and r1 != r2:
            key += "s"
        
        for group, hands in self.preflop_hand_groups.items():
            if key in hands:
                return group
        
        if r1 == r2:
            return 6
        elif low_idx < 8:
            return 7
        else:
            return 5

    def get_preflop_group_name(self) -> str:
        group_map = {
            1: "Group 1 (Strongest)",
            2: "Group 2 (Strong)",
            3: "Group 3 (Above Average)",
            4: "Group 4 (Average)",
            5: "Group 5 (Below Average)",
            6: "Group 6 (Weak Pair)",
            7: "Group 7 (Trash)"
        }
        return group_map.get(self.pre_flop_group, "Unknown Group")

    def get_my_bet(self, player_bets: Dict[str, int]) -> int:
        if not player_bets: 
            return 0
        return player_bets.get(str(self.id), 0)

    def has_raised(self, player_actions: Dict[str, str]) -> bool:
        if not player_actions: 
            return False
        return any("RAISE" in a.upper() or a.upper() == "ALL_IN" for a in player_actions.values())

    def is_big_blind(self) -> bool:
        return self.id == self.big_blind_player_id
    
    def is_small_blind(self) -> bool:
        return self.id == self.small_blind_player_id
    
    def hand_strength_equity(self, hole_cards: List[str], community_cards: List[str], opponents_count: int, n_simulations: int = 100) -> float:
        deck = [r + s for r in self.ranks for s in self.suits]
        for card in hole_cards:
            if card in deck: 
                deck.remove(card)
        for card in community_cards:
            if card in deck: 
                deck.remove(card)
        wins, ties = 0, 0
        if len(community_cards) == 5 and opponents_count > 0:
            my_value = self.evaluate_hand(hole_cards + community_cards)
            for _ in range(n_simulations):
                random.shuffle(deck)
                opponents_hands = [deck[i*2:i*2+2] for i in range(opponents_count)]
                deck_pointer = opponents_count * 2
                opp_best = -1
                for h in opponents_hands:
                    candidate = self.evaluate_hand(h + community_cards)
                    if candidate > opp_best: 
                        opp_best = candidate
                if my_value > opp_best:
                    wins += 1
                elif my_value == opp_best:
                    ties += 1
        elif len(community_cards) < 5:
            full_comm_cards = community_cards.copy()
            required_draws = 5 - len(community_cards)
            for _ in range(n_simulations):
                random.shuffle(deck)
                sim_deck = deck.copy()
                drawing = sim_deck[:required_draws]
                remaining = sim_deck[required_draws:]
                new_community = full_comm_cards + drawing
                opponents_hands = [remaining[i*2:i*2+2] for i in range(opponents_count)]
                deck_pointer = opponents_count * 2
                my_value = self.evaluate_hand(hole_cards + new_community)
                opp_best = -1
                for h in opponents_hands:
                    opp_hand_value = self.evaluate_hand(h + new_community)
                    if opp_hand_value > opp_best: 
                        opp_best = opp_hand_value
                if my_value > opp_best:
                    wins += 1
                elif my_value == opp_best:
                    ties += 1
        return (wins + ties / 2) / n_simulations

    def evaluate_hand(self, cards: List[str]) -> int:
        if len(cards) < 5: 
            return 0
        combinations_list = []
        for i in range(len(cards)):
            for j in range(i+1, len(cards)):
                combinations_list.append(cards[i:j] + [cards[i]])
        best_score = 0
        for comb in combinations_list:
            score_val = self._score_five_card(comb)
            if score_val > best_score:
                best_score = score_val
        return best_score

    def _score_five_card(self, hand: List[str]) -> int:
        def is_flush(suits_list):
            return len(set(suits_list)) == 1
        
        def is_straight(ranks_list):
            if len(ranks_list) != 5:
                return False
            sorted_ranks = sorted(ranks_list)
            if sorted_ranks == [0, 1, 2, 3, 12]:
                return 4 # Wheel straight
            for i in range(1, 5):
                if sorted_ranks[i] != sorted_ranks[i-1] + 1:
                    return False
            return sorted_ranks[4]
        
        rank_count = Counter([self.ranks.index(c[0]) for c in hand])
        ordered_counts = sorted(rank_count.values(), reverse=True)
        rank_values = sorted(rank_count.keys(), reverse=True, key=lambda x: (rank_count[x], x))
        flush = is_flush([c[1] for c in hand])
        straight_high = is_straight([self.ranks.index(c[0]) for c in hand])
        if straight_high != 0 and flush and straight_high == 12:
            return 900
        elif straight_high != 0 and flush:
            return 800 + straight_high
        elif straight_high != 0:
            return 400 + straight_high
        elif flush:
            return 500 + max(rank_values)
        elif ordered_counts[0] == 4:
            return 700 + max(rank_values)
        elif ordered_counts[0] == 3 and ordered_counts[1] == 2:
            return 600 + max(rank_values)
        elif flush:
            return 500 + max(rank_values)
        elif ordered_counts[0] == 3:
            return 300 + max(rank_values)
        elif ordered_counts[0] == 2 and ordered_counts[1] == 2:
            return 200 + max(rank_values)
        elif ordered_counts[0] == 2:
            return 100 + max(rank_values)
        else:
            return max(rank_values)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        community_cards = round_state.community_cards
        round_name = round_state.round.upper()
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        current_bet = round_state.current_bet
        my_bet = self.get_my_bet(round_state.player_bets)
        to_call = max(0, current_bet - my_bet)
        opponents_count = len(round_state.current_player) - 1

        if round_name == "PREFLOP":
            return self.handle_pre_flop(round_state, remaining_chips, my_bet, to_call)
        else:
            return self.handle_post_flop(round_state, remaining_chips, my_bet, to_call, opponents_count)

    def handle_pre_flop(self, round_state: RoundStateClient, remaining_chips: int, my_bet: int, to_call: int) -> Tuple[PokerAction, int]:
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        bb_val = self.blind_amount
        group_num = self.pre_flop_group
        is_raisen = self.has_raised(round_state.player_actions)

        if self.is_big_blind() and to_call == 0 and not is_raisen and group_num >= 5:
            return PokerAction.CHECK, 0

        if to_call == 0:
            if group_num <= 2:
                raise_amount = min(max(bb_val * 3, min_raise), remaining_chips)
                return PokerAction.RAISE, raise_amount if raise_amount <= max_raise else (min_raise if min_raise <= max_raise else max_raise)
            elif group_num <= 4 and not self.position_adjustment < 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD if self.position_adjustment < 0 \
                    or (group_num > 5) else (PokerAction.CHECK, 0)
        else:
            if group_num <= 3 and to_call <= (bb_val * 8):
                return PokerAction.CALL, to_call
            elif group_num <= 5 and to_call <= (bb_val * 3) and self.position_adjustment > 0:
                return PokerAction.CALL, to_call
            else:
                if self.is_small_blind() and to_call == (self.blind_amount // 2):
                    return PokerAction.CALL, to_call
                elif self.is_big_blind() and to_call == 0 and my_bet == self.blind_amount:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD

    def handle_post_flop(self, round_state: RoundStateClient, remaining_chips: int, my_bet: int, to_call: int, opponents_count: int) -> Tuple[PokerAction, int]:
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        current_bet = round_state.current_bet
        pot = round_state.pot
        win_prob = 0.5
        try:
            win_prob = self.hand_strength_equity(self.hole_cards, round_state.community_cards, opponents_count, 100)
        except Exception as e:
            win_prob = 0.5

        if win_prob > self.aggressive_threshold:
            if min_raise > 0 and to_call == 0:
                raise_val = min(pot // 3, remaining_chips)
                if min_raise <= raise_val <= max_raise:
                    return PokerAction.RAISE, raise_val
                else:
                    return PokerAction.CHECK
            elif to_call > 0:
                if remaining_chips > 0 and to_call < min_raise * 2:
                    return PokerAction.CALL
                return PokerAction.RAISE, min_raise
            elif to_call == 0:
                if remaining_chips > 0 and min_raise * 2 < max_raise:
                    return PokerAction.RAISE, max(min_raise, min(pot // 3, max_raise))
                else:
                    return PokerAction.CHECK
        elif win_prob > self.conservative_threshold and to_call <= (0.3 * pot) if to_call > 0 else True :
            if to_call > 0:
                if remaining_chips > to_call:
                    return PokerAction.CALL
                else:
                    return PokerAction.ALL_IN
            else:
                return PokerAction.CHECK
        else:
            if to_call > 0:
                my_pot_odds = min(to_call, remaining_chips) / (pot + min(to_call, remaining_chips) + 1e-10)
                if win_prob > my_pot_odds:
                    return PokerAction.CALL
                else:
                    return PokerAction.FOLD
            else:
                return PokerAction.CHECK 

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass