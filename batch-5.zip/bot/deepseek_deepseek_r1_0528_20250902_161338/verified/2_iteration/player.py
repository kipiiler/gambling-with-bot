from typing import List, Tuple, Dict, Any
import itertools
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
                           'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        if self.id in all_players:
            idx = all_players.index(self.id)
            self.hole_cards = player_hands[idx]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0

        if round_state.round == 'Preflop':
            strength = self.preflop_strength(self.hole_cards)
        else:
            strength = self.hand_strength(self.hole_cards, round_state.community_cards)

        if strength > 0.8:  # Premium hand
            if to_call > 0:
                total_bet = min(
                    round_state.current_bet + round_state.min_raise + (round_state.max_raise - round_state.min_raise) // 2,
                    my_bet + remaining_chips
                )
            else:
                total_bet = round_state.current_bet + round_state.min_raise + (round_state.max_raise - round_state.min_raise) // 2
            
            if total_bet >= my_bet + remaining_chips:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.RAISE, total_bet)
                
        elif strength > 0.5:  # Playable hand
            if to_call > 0:
                if to_call >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CHECK, 0)
                
        else:  # Weak hand
            if to_call > 0:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def preflop_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.4
            
        r0, r1 = hole_cards[0][0], hole_cards[1][0]
        suited = hole_cards[0][1] == hole_cards[1][1]
        v0, v1 = self.rank_values[r0], self.rank_values[r1]
        
        if v0 < v1:
            r0, r1 = r1, r0
            v0, v1 = v1, v0
            
        hand_str = r0 + r1
        if r0 != r1:
            hand_str += 's' if suited else 'o'

        strength_table = {
            'AA': 0.9, 'KK': 0.85, 'QQ': 0.8, 'JJ': 0.75, 'TT': 0.7,
            '99': 0.65, '88': 0.6, '77': 0.55, 'AKs': 0.7, 'AKo': 0.65,
            'AQs': 0.65, 'AQo': 0.6, 'AJs': 0.6, 'AJo': 0.55, 'ATs': 0.55,
            'KQs': 0.6, 'KQo': 0.55, 'KJs': 0.55, 'QJs': 0.5, 'JTs': 0.5
        }
        
        return strength_table.get(hand_str, 0.4)

    def hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.2
            
        best_score = 0.0
        for combo in itertools.combinations(all_cards, 5):
            score = self.evaluate_five_card_hand(list(combo))
            if score > best_score:
                best_score = score
                
        return best_score / 10.0

    def evaluate_five_card_hand(self, cards: List[str]) -> float:
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]
        rank_vals = [self.rank_values[r] for r in ranks]
        rank_vals.sort(reverse=True)
        
        # Count rank frequencies
        count = {}
        for r in ranks:
            count[r] = count.get(r, 0) + 1
        sorted_counts = sorted(count.items(), key=lambda x: (x[1], self.rank_values[x[0]]), reverse=True)
        
        # Check flush
        flush = len(set(suits)) == 1
        
        # Check straight
        straight = False
        unique_vals = sorted(set(rank_vals))
        if len(unique_vals) >= 5:
            for i in range(len(unique_vals) - 4):
                if unique_vals[i] - unique_vals[i+4] == 4:
                    straight = True
                    high = unique_vals[i]
                    break
            # Check for Ace-low straight (A-5)
            if not straight and set(unique_vals) >= {14, 2, 3, 4, 5}:
                straight = True
                high = 5
        
        # Evaluate hand type
        if straight and flush:
            return 9.0 + high / 14.0
        elif sorted_counts[0][1] == 4:
            quad_rank = self.rank_values[sorted_counts[0][0]]
            kicker = self.rank_values[sorted_counts[1][0]]
            return 7.0 + quad_rank / 14.0 + kicker / (14.0 * 14.0)
        elif sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
            trip_rank = self.rank_values[sorted_counts[0][0]]
            pair_rank = self.rank_values[sorted_counts[1][0]]
            return 6.0 + trip_rank / 14.0 + pair_rank / (14.0 * 14.0)
        elif flush:
            return 5.0 + max(rank_vals) / 14.0
        elif straight:
            return 4.0 + high / 14.0
        elif sorted_counts[0][1] == 3:
            trip_rank = self.rank_values[sorted_counts[0][0]]
            kickers = sorted([self.rank_values[r] for r in count.keys() if r != sorted_counts[0][0]], reverse=True)[:2]
            return 3.0 + trip_rank / 14.0 + kickers[0] / (14.0 * 14.0) + kickers[1] / (14.0 * 14.0 * 14.0)
        elif sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
            pair1 = self.rank_values[sorted_counts[0][0]]
            pair2 = self.rank_values[sorted_counts[1][0]]
            kicker = self.rank_values[sorted_counts[2][0]]
            return 2.0 + max(pair1, pair2) / 14.0 + min(pair1, pair2) / (14.0 * 14.0) + kicker / (14.0 * 14.0 * 14.0)
        elif sorted_counts[0][1] == 2:
            pair_rank = self.rank_values[sorted_counts[0][0]]
            kickers = sorted([self.rank_values[r] for r in count.keys() if r != sorted_counts[0][0]], reverse=True)[:3]
            return 1.0 + pair_rank / 14.0 + kickers[0] / (14.0 * 14.0) + kickers[1] / (14.0 * 14.0 * 14.0) + kickers[2] / (14.0 * 14.0 * 14.0 * 14.0)
        else:
            return sum(val / (14.0 ** (i+1)) for i, val in enumerate(sorted(rank_vals, reverse=True)[:5]))

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass