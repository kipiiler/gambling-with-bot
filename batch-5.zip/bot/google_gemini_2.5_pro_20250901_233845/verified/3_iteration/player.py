import random
from itertools import combinations
from typing import List, Tuple, Dict, Any

# Assuming these enums are provided by the game environment in a file like type.poker_action
from enum import Enum

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 'Preflop'
    FLOP = 'Flop'
    TURN = 'Turn'
    RIVER = 'River'

# Assuming this class is provided by the game environment
class RoundStateClient:
    def __init__(self, round_num: int, round: str, community_cards: List[str], pot: int,
                 current_player: List[int], current_bet: int, min_raise: int, max_raise: int,
                 player_bets: Dict[str, int], player_actions: Dict[str, str], side_pots: list = None):
        self.round_num = round_num
        self.round = round
        self.community_cards = community_cards
        self.pot = pot
        self.current_player = current_player
        self.current_bet = current_bet
        self.min_raise = min_raise
        self.max_raise = max_raise
        self.player_bets = player_bets
        self.player_actions = player_actions
        self.side_pots = side_pots if side_pots is not None else []

# Assuming this class is provided by the game environment
class Bot:
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    def on_start(self, starting_chips, player_hands, blind_amount, big_blind_player_id, small_blind_player_id, all_players): pass
    def on_round_start(self, round_state, remaining_chips): pass
    def get_action(self, round_state, remaining_chips) -> Tuple[PokerAction, int]: pass
    def on_end_round(self, round_state, remaining_chips): pass
    def on_end_game(self, round_state, player_score, all_scores, active_players_hands): pass


class SimplePlayer(Bot):
    """
    A poker bot that uses a rule-based strategy based on hand strength and pot odds.
    - Pre-flop: Uses a starting hand chart to decide whether to play.
    - Post-flop: Evaluates hand strength, considers draws, and uses pot odds to make decisions.
    - Avoids folding strong hands and plays more selectively than a purely random bot.
    """

    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.initial_chips: int = 0
        self.big_blind_amount: int = 0
        self.all_player_ids: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_chips = starting_chips
        self.all_player_ids = all_players
        self.hand = player_hands
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand = round_state.community_cards + self.hand[:2] # This seems incorrect, should just be player_hands

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Main decision-making function """
        
        my_bet_this_round = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet_this_round

        # --- Pre-flop Strategy ---
        if round_state.round == PokerRound.PREFLOP.value:
            return self._get_preflop_action(round_state, remaining_chips, to_call)

        # --- Post-flop Strategy ---
        else:
            return self._get_postflop_action(round_state, remaining_chips, to_call)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. Can be used for opponent modeling. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    # --------------------------------------------------------------------------
    # Helper methods for strategy
    # --------------------------------------------------------------------------

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take before the flop. """
        hand_strength_category = self._get_preflop_hand_strength(self.hand)

        num_active_players = sum(1 for pid in self.all_player_ids if round_state.player_actions.get(str(pid)) != 'Fold')
        is_heads_up = num_active_players <= 2

        # Premium hands: Always raise
        if hand_strength_category == 'premium':
            # Raise 3x BB if no one has raised, or re-raise if there's a small raise.
            raise_amount = 3 * self.big_blind_amount
            if round_state.current_bet > self.big_blind_amount:
                raise_amount = round_state.current_bet * 3
            return self._get_validated_raise_action(raise_amount, round_state, remaining_chips)

        # Strong hands: Raise or call depending on the situation
        if hand_strength_category == 'strong':
            if to_call == 0:  # No one has raised yet
                raise_amount = 2.5 * self.big_blind_amount
                return self._get_validated_raise_action(raise_amount, round_state, remaining_chips)
            elif to_call <= 0.1 * remaining_chips:  # Call small raises
                return PokerAction.CALL, 0
            else: # Fold to large raises
                return PokerAction.FOLD, 0
        
        # Playable hands: More cautious
        if hand_strength_category == 'playable':
            # Limp in or call small raises, especially in late position or heads-up
            if (is_heads_up and to_call <= 0.1 * remaining_chips) or (to_call <= 2 * self.big_blind_amount):
                 return PokerAction.CALL, 0 if to_call > 0 else PokerAction.CHECK, 0
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        
        # Weak hands: Fold, unless we can check for free in the big blind
        if to_call == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take on the Flop, Turn, or River. """
        if not self.hand or len(self.hand) < 2: return PokerAction.FOLD, 0
        
        num_active_players = sum(1 for pid in self.all_player_ids if round_state.player_actions.get(str(pid)) != 'Fold')

        # Evaluate hand strength
        hand_rank, hand_values = self._evaluate_hand(self.hand, round_state.community_cards)

        # Evaluate draw potential (Flop and Turn only)
        outs = 0
        if round_state.round != PokerRound.RIVER.value:
            outs = self._calculate_draw_outs(self.hand, round_state.community_cards)

        win_prob_heuristic = self._calculate_win_prob_heuristic(hand_rank, outs, round_state.round)

        # Decision making based on heuristic win probability
        
        # Monster hands (Set or better)
        if hand_rank >= 3: # Three of a kind or better
            # Bet/Raise aggressively
            if remaining_chips <= 15 * self.big_blind_amount:
                return PokerAction.ALL_IN, 0
            
            # Bet for value: 50-75% of the pot
            raise_amount = 0.75 * round_state.pot
            if to_call > 0: # If facing a bet, raise
                raise_amount = to_call + 0.75 * (round_state.pot + to_call)
            return self._get_validated_raise_action(raise_amount, round_state, remaining_chips)

        # Strong hands (Two Pair, Overpair, Top Pair Good Kicker)
        is_top_pair = (hand_rank == 1 and hand_values[0] == max(self._get_card_values(round_state.community_cards)))
        is_overpair = (hand_rank == 1 and self._is_pocket_pair(self.hand) and hand_values[0] > max(self._get_card_values(round_state.community_cards)))

        if hand_rank == 2 or is_overpair or (is_top_pair and hand_values[2] >= 10): # TPK or better
            # Value bet or call
            if to_call == 0: # Bet 1/2 to 2/3 pot
                bet_amount = 0.6 * round_state.pot
                return self._get_validated_raise_action(bet_amount, round_state, remaining_chips)
            else: # Call bets, reconsider against huge raises
                pot_odds = to_call / (round_state.pot + to_call + 1e-6)
                if to_call < 0.5 * remaining_chips and pot_odds < 0.4:
                     return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
        
        # Drawing hands or marginal made hands
        pot_odds = to_call / (round_state.pot + to_call + 1e-6) if to_call > 0 else 1.0

        if win_prob_heuristic > pot_odds:
            # If the odds are good, call to see the next card
            return PokerAction.CALL, 0
        
        # Weak hands and missed draws
        if to_call == 0:
            # Check and hope for a free card or to get to showdown cheap
            return PokerAction.CHECK, 0
        else:
            # If someone bets and we have nothing, fold.
            # Exception: small bluff catch on the river with Ace-high if bet is tiny
            if round_state.round == PokerRound.RIVER.value and to_call <= 2 * self.big_blind_amount and hand_rank==0 and hand_values[0]>=14:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _get_validated_raise_action(self, amount: float, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Ensures a raise is valid and returns the appropriate action. """
        raise_amount = int(amount)
        
        # All-in if raise amount is close to or exceeds remaining chips
        if raise_amount >= remaining_chips:
            return PokerAction.ALL_IN, 0
            
        # Ensure raise is at least the minimum, and not more than the max.
        validated_raise = max(round_state.min_raise, raise_amount)
        validated_raise = min(round_state.max_raise, validated_raise)
        
        if validated_raise <= round_state.current_bet - round_state.player_bets.get(str(self.id), 0):
            return PokerAction.CALL, 0

        # If we can't meet the min_raise, decide whether to call or fold
        if validated_raise < round_state.min_raise:
            to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if to_call > 0.2 * remaining_chips:
                return PokerAction.FOLD, 0
            return PokerAction.CALL, 0
            
        return PokerAction.RAISE, validated_raise

    @staticmethod
    def _get_card_rank(card: str) -> int:
        """ '2'->2, 'T'->10, 'A'->14 """
        val = card[:-1]
        if val.isdigit(): return int(val)
        return {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[val]

    @staticmethod
    def _get_card_suit(card: str) -> str:
        return card[-1]

    def _get_card_values(self, cards: List[str]) -> List[int]:
        return [self._get_card_rank(c) for c in cards]
    
    @staticmethod
    def _is_pocket_pair(hole_cards: List[str]) -> bool:
        return SimplePlayer._get_card_rank(hole_cards[0]) == SimplePlayer._get_card_rank(hole_cards[1])

    @staticmethod
    def _get_preflop_hand_strength(hole_cards: List[str]) -> str:
        """ Classifies a starting hand into a strength category. """
        rank1 = SimplePlayer._get_card_rank(hole_cards[0])
        rank2 = SimplePlayer._get_card_rank(hole_cards[1])
        is_suited = SimplePlayer._get_card_suit(hole_cards[0]) == SimplePlayer._get_card_suit(hole_cards[1])
        
        higher_rank = max(rank1, rank2)
        lower_rank = min(rank1, rank2)

        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 11: return 'premium'  # JJ+
            if rank1 >= 8: return 'strong'    # 88, 99, TT
            return 'playable'                 # 22-77

        # Suited hands
        if is_suited:
            if higher_rank >= 13 and lower_rank >= 11: return 'premium' # AKs, KQs
            if higher_rank >= 12: return 'strong' # AQs, AJs, ATs, KJs
            if higher_rank >= 10 or (higher_rank - lower_rank == 1): return 'playable' # Suited connectors, suited A/K/Q
        
        # Off-suit hands
        else:
            if higher_rank == 14 and lower_rank == 13: return 'strong' # AKo
            if higher_rank >= 12 and lower_rank >= 11: return 'playable' # KQo, KJo, QJo
        
        return 'weak'


    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        """
        Evaluates the best 5-card hand from 2 hole cards and 5 community cards.
        Returns a tuple: (hand_rank_code, tie_breaker_values).
        Rank codes: 9=SF, 8=Quads, 7=FH, 6=Flush, 5=Straight, 4=Trips, 3=2P, 2=1P, 1=HC.
        (Note: Previous version had these ranks mixed up, this is a more standard hierarchy)
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return (-1, [])

        best_rank = (-1, [])
        for hand_combination in combinations(all_cards, 5):
            current_rank = self._evaluate_5_card_hand(list(hand_combination))
            if current_rank[0] > best_rank[0]:
                best_rank = current_rank
            elif current_rank[0] == best_rank[0]:
                if current_rank[1] > best_rank[1]:
                    best_rank = current_rank

        # Correcting rank codes to a more logical order (high is good)
        ranks_map = {-1: 0, 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9}
        final_rank_code = ranks_map.get(best_rank[0], 0)

        # Simplified re-ordering
        hand_rank, tie_breaker = best_rank
        # Ranks: [HC, 1P, 2P, 3K, ST, FL, FH, 4K, SF]
        # map to: [0, 1, 2, 3, 4, 5, 6, 7, 8]
        return hand_rank, tie_breaker


    def _evaluate_5_card_hand(self, hand: List[str]) -> Tuple[int, List[int]]:
        """ Evaluates a 5-card hand. """
        values = sorted([self._get_card_rank(c) for c in hand], reverse=True)
        suits = [self._get_card_suit(c) for c in hand]
        is_flush = len(set(suits)) == 1
        
        # Ace-low straight check
        is_straight = all(values[i] == values[i+1] + 1 for i in range(4))
        if not is_straight and values == [14, 5, 4, 3, 2]:
            is_straight = True
            values = [5, 4, 3, 2, 1] # For tie-breaking treat ace as 1

        if is_straight and is_flush: return (8, values) # Straight Flush
        
        counts = {v: values.count(v) for v in set(values)}
        card_counts = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
        
        vals_by_count = [item[0] for item in card_counts]
        
        if card_counts[0][1] == 4: return (7, vals_by_count)  # Four of a Kind
        if card_counts[0][1] == 3 and card_counts[1][1] == 2: return (6, vals_by_count) # Full House
        if is_flush: return (5, values) # Flush
        if is_straight: return (4, values) # Straight
        if card_counts[0][1] == 3: return (3, vals_by_count) # Three of a Kind
        if card_counts[0][1] == 2 and card_counts[1][1] == 2: return (2, vals_by_count) # Two Pair
        if card_counts[0][1] == 2: return (1, vals_by_count) # One Pair
        return (0, values) # High Card

    def _calculate_draw_outs(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """ Calculates the number of 'outs' for straight and flush draws. """
        all_cards = hole_cards + community_cards
        
        # Flush draw outs
        suits = [self._get_card_suit(c) for c in all_cards]
        suit_counts = {s: suits.count(s) for s in set(suits)}
        flush_outs = 0
        if 4 in suit_counts.values():
            flush_outs = 13 - 4  # 9 outs
        
        # Straight draw outs
        ranks = sorted(list(set(self._get_card_values(all_cards))))
        straight_outs = 0
        if len(ranks) >= 4:
            # Open-ended straight draw check
            for i in range(len(ranks) - 3):
                if ranks[i+3] - ranks[i] == 3:
                    if ranks[i] > 1 and ranks[i+3] < 14:
                        straight_outs = 8
                    elif ranks[i] == 1 and ranks[i+3] == 4: # Ace-low
                        straight_outs = 4
                    else: # one-sided straight
                        straight_outs = 4
            # Gutshot straight draw check
            for i in range(len(ranks) - 2):
                if ranks[i+2] - ranks[i] == 3: straight_outs = max(straight_outs, 4)
                if ranks[i+2] - ranks[i] == 4: straight_outs = max(straight_outs, 4)
        
        # TOTO: This simple logic can double-count straight-flush outs.
        # For this version, just summing them is a reasonable approximation.
        return flush_outs + straight_outs


    def _calculate_win_prob_heuristic(self, hand_rank: int, outs: int, round_name: str) -> float:
        """ A simple heuristic to estimate win probability. """
        
        # Made hand strength (0-1 scale)
        made_hand_prob = hand_rank / 8.0 # e.g. Straight flush (8/8=1.0), Pair (1/8=0.125)
        
        # Draw potential (0-1 scale)
        draw_prob = 0.0
        if round_name == PokerRound.FLOP.value:
            draw_prob = (outs * 4) / 100.0  # Approx. chance to hit by river
        elif round_name == PokerRound.TURN.value:
            draw_prob = (outs * 2) / 100.0  # Approx. chance to hit on river
            
        # Combine them: use the better of the two probabilities, with a slight bonus for combo draws
        return max(made_hand_prob, draw_prob) + (0.1 if made_hand_prob > 0 and draw_prob > 0 else 0)