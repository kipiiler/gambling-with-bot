import collections
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Hand rank constants for internal evaluation
HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8
ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    """
    A poker bot that uses hand strength evaluation, pot odds, and equity estimation.
    - Pre-flop: Plays a range of hands based on a simplified tier system.
    - Post-flop: Makes decisions based on hand evaluation (made hands vs. draws),
      pot odds, and semi-bluffing with strong draws.
    - It avoids common pitfalls like overplaying marginal hands on dangerous boards.
    """

    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the game."""
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        # For this bot framework, our hand is delivered at round start by being appended to community_cards
        # This is a bit unusual, so we extract it here.
        if round_state.round == 'Preflop':
            self.hole_cards = round_state.community_cards[-2:] if len(round_state.community_cards) >= 2 else []
        # No else needed, self.hole_cards persists through the round

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Calculates and returns the best action for the current turn.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        cost_to_call = round_state.current_bet - my_bet
        can_check = cost_to_call == 0

        if not self.hole_cards:
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, cost_to_call, can_check)
        else:
            return self._get_postflop_action(round_state, cost_to_call, can_check, remaining_chips)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        # This can be used for opponent modeling in future iterations.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass

    # --------------------------------- #
    # ---       HELPER METHODS      --- #
    # --------------------------------- #

    def _get_preflop_action(self, round_state: RoundStateClient, cost_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        """Determines the action to take pre-flop based on hand strength."""
        strength = self._get_preflop_strength(self.hole_cards)
        is_raised = round_state.current_bet > self.big_blind_amount

        # Tier 1-2 (Premium & Very Strong Hands): Always raise or re-raise.
        if strength >= 4:
            if is_raised:
                raise_amount = 3 * round_state.current_bet
            else:
                raise_amount = 3 * self.big_blind_amount
            
            raise_amount = max(raise_amount, round_state.min_raise)
            if round_state.max_raise > 0 and raise_amount < round_state.max_raise:
                 return PokerAction.RAISE, raise_amount
            return PokerAction.ALL_IN, 0

        # Tier 3 (Good Hands): Playable, call raises or open-raise.
        elif strength == 3:
            if is_raised:
                if cost_to_call < self.big_blind_amount * 5 and cost_to_call <= round_state.max_raise:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                raise_amount = int(2.5 * self.big_blind_amount)
                raise_amount = max(raise_amount, round_state.min_raise)
                if round_state.max_raise > 0 and raise_amount < round_state.max_raise:
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0

        # Tier 4 (Speculative Hands): Limp in if cheap, otherwise fold.
        elif strength == 2:
            if not is_raised and cost_to_call <= round_state.max_raise:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Tier 5 (Trash): Fold unless we are the big blind and can check.
        else:
            return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, cost_to_call: int, can_check: bool, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determines the action to take post-flop based on hand strength, draws, and pot odds."""
        pot_total = round_state.pot
        all_cards = self.hole_cards + round_state.community_cards
        hand_eval = self._evaluate_7_cards(all_cards)
        hand_rank = hand_eval[0]
        outs, is_strong_draw = self._calculate_outs(self.hole_cards, round_state.community_cards)

        equity = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100.0
        pot_odds = cost_to_call / (pot_total + cost_to_call + 1e-6) if cost_to_call > 0 else 0

        # ---- Decision Logic ----

        # Strong Made Hands (Two Pair or better)
        if hand_rank >= TWO_PAIR:
            bet_amount = int(pot_total * 0.75) if hand_rank < FULL_HOUSE else pot_total
            if can_check:
                bet_amount = max(bet_amount, round_state.min_raise)
                if round_state.max_raise > 0 and bet_amount < round_state.max_raise:
                    return PokerAction.RAISE, bet_amount
                return PokerAction.ALL_IN, 0
            else: # Facing a bet
                raise_amount = 2 * cost_to_call + bet_amount
                raise_amount = max(raise_amount, round_state.min_raise)
                if round_state.max_raise > 0 and raise_amount < round_state.max_raise:
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0

        # Medium Made Hand (One Pair - Top Pair)
        if hand_rank == ONE_PAIR:
            pair_rank = hand_eval[1][0]
            board_ranks = [self._card_to_val(c)[0] for c in round_state.community_cards]
            is_top_pair = pair_rank >= max(board_ranks) if board_ranks else True
            if is_top_pair:
                if can_check:
                    bet_amount = int(pot_total * 0.5)
                    bet_amount = max(bet_amount, round_state.min_raise)
                    if round_state.max_raise > 0 and bet_amount > 0 and bet_amount < round_state.max_raise:
                        return PokerAction.RAISE, bet_amount
                    return PokerAction.CHECK, 0
                else: # Facing a bet
                    if cost_to_call < remaining_chips / 3:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
        
        # Drawing Hands
        if outs > 0:
            if cost_to_call > 0 and equity > pot_odds and cost_to_call <= round_state.max_raise:
                return PokerAction.CALL, 0
            if can_check and is_strong_draw: # Semi-bluff with strong draws
                bet_amount = int(pot_total * 0.6)
                bet_amount = max(bet_amount, round_state.min_raise)
                if round_state.max_raise > 0 and bet_amount > 0 and bet_amount < round_state.max_raise:
                    return PokerAction.RAISE, bet_amount
        
        # No made hand, no good draw: Check/Fold
        return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0

    def _card_to_val(self, card: str) -> Tuple[int, str]:
        """Converts a card string like 'Th' to a tuple (10, 'h')."""
        rank_str = card[:-1]
        suit = card[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return rank, suit

    def _get_preflop_strength(self, hole_cards: List[str]) -> int:
        """Assigns a score from 1 (trash) to 5 (premium) to a starting hand."""
        r1, s1 = self._card_to_val(hole_cards[0])
        r2, s2 = self._card_to_val(hole_cards[1])
        is_suited, is_pair = s1 == s2, r1 == r2
        r_max, r_min = max(r1, r2), min(r1, r2)

        if is_pair and r1 >= 11: return 5  # JJ+
        if is_suited and r_max == 14 and r_min == 13: return 5  # AKs
        if is_pair and r1 >= 9: return 4  # 99, TT
        if is_suited and r_max >= 12 and r_max - r_min <= 2: return 4  # AQs, KQs, AJs
        if not is_suited and r_max == 14 and r_min == 13: return 4  # AKo
        if is_pair and r1 >= 7: return 3  # 77, 88
        if is_suited and (r_max == 14 or (r_max >= 11 and r_max - r_min <= 3)): return 3 # Axs, KJs, QJs, JTs
        if not is_suited and r_max >= 13: return 3 # ATo+, KQo
        if is_pair: return 2 # 22-66
        if is_suited and r_max - r_min <= 4: return 2 # Suited connectors/gappers
        return 1

    def _evaluate_7_cards(self, cards: List[str]) -> Tuple:
        """Finds the best 5-card hand from a list of 5-7 cards and returns its rank and tie-breaking values."""
        if len(cards) < 5:
            vals = sorted([self._card_to_val(c)[0] for c in cards], reverse=True)
            return (HIGH_CARD, vals)
        
        best_hand = (-1, [])
        for combo in combinations(cards, 5):
            ranks = sorted([self._card_to_val(c)[0] for c in combo], reverse=True)
            suits = [self._card_to_val(c)[1] for c in combo]
            
            is_flush = len(set(suits)) == 1
            is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
            _ranks = [5, 4, 3, 2, 1] if is_ace_low_straight else ranks
            is_straight = all(_ranks[i] == _ranks[i+1] + 1 for i in range(len(_ranks)-1)) or is_ace_low_straight
            
            counts = collections.Counter(ranks)
            count_vals = sorted(counts.values(), reverse=True)
            rank_vals = sorted(counts.keys(), key=lambda r: (counts[r], r), reverse=True)

            hand_rank = -1
            hand_tiebreaker = []

            if is_straight and is_flush:
                hand_rank = STRAIGHT_FLUSH if not (ranks[0] == 14 and is_ace_low_straight) else ROYAL_FLUSH
                hand_tiebreaker = _ranks
            elif count_vals[0] == 4:
                hand_rank, hand_tiebreaker = FOUR_OF_A_KIND, rank_vals
            elif count_vals == [3, 2]:
                hand_rank, hand_tiebreaker = FULL_HOUSE, rank_vals
            elif is_flush:
                hand_rank, hand_tiebreaker = FLUSH, ranks
            elif is_straight:
                hand_rank, hand_tiebreaker = STRAIGHT, _ranks
            elif count_vals[0] == 3:
                hand_rank, hand_tiebreaker = THREE_OF_A_KIND, rank_vals
            elif count_vals == [2, 2, 1]:
                hand_rank, hand_tiebreaker = TWO_PAIR, rank_vals
            elif count_vals[0] == 2:
                hand_rank, hand_tiebreaker = ONE_PAIR, rank_vals
            else:
                hand_rank, hand_tiebreaker = HIGH_CARD, ranks
            
            current_hand = (hand_rank, hand_tiebreaker)
            if current_hand > best_hand:
                best_hand = current_hand
        return best_hand

    def _calculate_outs(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, bool]:
        """Calculates outs for straight and flush draws. Returns total outs and if it's a strong draw."""
        all_cards = hole_cards + community_cards
        my_ranks = {self._card_to_val(c)[0] for c in all_cards}
        my_suits = collections.Counter(self._card_to_val(c)[1] for c in all_cards)
        
        # Flush draw outs (4 cards of same suit)
        flush_outs = 9 if any(count == 4 for count in my_suits.values()) else 0

        # Straight draw outs (4 cards to a 5-card sequence)
        straight_outs = 0
        for i in range(1, 11):
            potential_straight = {14, 2, 3, 4, 5} if i == 1 else set(range(i, i + 5))
            if len(my_ranks.intersection(potential_straight)) == 4:
                missing = list(potential_straight - my_ranks)
                if not missing or missing[0] in my_ranks: continue
                
                # Check for open-ended vs gutshot by checking continuity
                if i>1 and i<10 and {i+1, i+2}.issubset(my_ranks): straight_outs = 8; break
                straight_outs = max(straight_outs, 4)

        total_outs = flush_outs + straight_outs
        if flush_outs > 0 and straight_outs > 0:
            total_outs -= 2  # Heuristic adjustment for straight-flush draw overlaps

        is_strong_draw = total_outs >= 8
        return max(0, total_outs), is_strong_draw