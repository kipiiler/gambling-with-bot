import itertools
import random
from collections import Counter
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Hand Ranking Constants
HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8
ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    """
    A poker bot that uses hand strength evaluation, position, and pot odds
    to make decisions.
    """

    def __init__(self):
        """
        Initializes the bot.
        """
        super().__init__()
        self.hand: List[str] = []
        self.initial_stack: int = 0
        self.big_blind_amount: int = 0
        self.num_players: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once at the start of a game.
        """
        self.hand = player_hands
        self.initial_stack = starting_chips
        self.big_blind_amount = blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each round/hand.
        """
        # No per-round state needed for this strategy
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main function that returns the bot's action.
        """
        # --- Action Helper Variables ---
        can_check = round_state.current_bet == round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)

        # Count active players (not folded)
        active_players = 0
        for p_id, action in round_state.player_actions.items():
            if action != 'Fold':
                active_players += 1
        
        if active_players == 0: # This happens if we are the first to act, so we count players with chips
            active_players = self.num_players

        # --- Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            preflop_strength = self._evaluate_preflop_strength(self.hand, self.num_players)

            # Very strong hands: Raise
            if preflop_strength > 0.7:
                raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'strong')
                return PokerAction.RAISE, raise_amount

            # Good hands: Call if affordable, otherwise fold
            if preflop_strength > 0.4:
                # If facing a small bet, call. If a large raise, be more cautious.
                if amount_to_call <= self.big_blind_amount * 3:
                    return PokerAction.CALL, amount_to_call
                else:
                    return PokerAction.FOLD, 0
            
            # Mediocre hands: Call a small bet if check is not an option
            if preflop_strength > 0.2:
                 if can_check:
                    return PokerAction.CHECK, 0
                 # Call only if it's a small bet (e.g. big blind)
                 if amount_to_call <= self.big_blind_amount:
                     return PokerAction.CALL, amount_to_call

            # Weak hands: Check if possible, otherwise fold
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        # --- Post-flop Strategy (Flop, Turn, River) ---
        else:
            hand_strength, _ = self._evaluate_postflop_hand(self.hand, round_state.community_cards)
            
            # Pot odds calculation
            pot_odds = 0
            if amount_to_call > 0:
                pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)

            # Draw potential
            draw_strength = self._calculate_draw_strength(self.hand, round_state.community_cards)
            
            # Effective Hand Strength (EHS) - combine current strength and potential
            ehs = hand_strength + (1 - hand_strength) * draw_strength

            # Bet/Raise with very strong hands
            if hand_strength >= TWO_PAIR:
                if ehs > 0.8: # Confident in our hand
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'strong')
                    return PokerAction.RAISE, raise_amount
                else: # Still strong, but be a bit more cautious
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'medium')
                    return PokerAction.RAISE, raise_amount
            
            # Good made hands or strong draws
            if ehs > 0.5:
                # If facing a bet, call if pot odds are good
                if not can_check:
                    # Semi-bluff with a strong draw
                    if hand_strength < ONE_PAIR and draw_strength > 0.5:
                         if random.random() < 0.3: # Bluff 30% of the time
                            raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'medium')
                            return PokerAction.RAISE, raise_amount
                    
                    # Call if pot odds are reasonable compared to our equity
                    if pot_odds < ehs:
                        return PokerAction.CALL, amount_to_call
                    else:
                        return PokerAction.FOLD, 0
                else: # We can check, so we can consider betting for value/protection
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'medium')
                    return PokerAction.RAISE, raise_amount
            
            # Weak hands / Weak draws
            if can_check:
                return PokerAction.CHECK, 0
            else:
                # Call with a decent draw if pot odds are excellent
                if draw_strength > 0.3 and pot_odds < 0.25:
                    return PokerAction.CALL, amount_to_call
                # Otherwise, fold
                return PokerAction.FOLD, 0

        # Default fallback action (should not be reached often)
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the end of each round. Can be used for learning.
        """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """
        Called at the end of the game.
        """
        pass

    # --- Helper Functions ---

    def _card_to_value_suit(self, card: str) -> tuple:
        """Converts card string 'XY' to (value, suit)."""
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        if not card or len(card) < 2: return (0, '')
        return (ranks[card[0]], card[1])
        
    def _evaluate_preflop_strength(self, hand: List[str], num_players: int) -> float:
        """
        Evaluates pre-flop hand strength on a scale of 0 to 1.
        Uses a simplified Chen formula approach.
        """
        card1, card2 = hand
        val1, _ = self._card_to_value_suit(card1)
        val2, _ = self._card_to_value_suit(card2)

        # High card score
        high_card = max(val1, val2)
        score = 0
        if high_card == 14: score = 10
        elif high_card == 13: score = 8
        elif high_card == 12: score = 7
        elif high_card == 11: score = 6
        else: score = high_card / 2.0

        # Pair bonus
        if val1 == val2:
            score = max(score * 2, 5) # Minimum score for a pair is 5 (for deuces)
        
        # Suited bonus
        if card1[1] == card2[1]:
            score += 2
            
        # Connector bonus
        gap = abs(val1 - val2)
        if gap == 1: score += 1
        elif gap == 2: score -= 1
        elif gap == 3: score -= 2
        elif gap == 4: score -= 4
        
        # Adjust for number of players
        strength = score / 30.0 # Normalize base score
        if num_players > 3:
            strength *= 0.85 # Tighter range for more players
        if num_players > 6:
            strength *= 0.85
        
        return min(max(strength, 0), 1)

    def _evaluate_postflop_hand(self, my_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        """
        Evaluates the best 5-card hand from 7 cards.
        Returns a tuple of (hand_rank, tiebreaker_values).
        """
        all_cards = my_cards + community_cards
        if len(all_cards) < 5:
            return HIGH_CARD, [c[0] for c in sorted([self._card_to_value_suit(c) for c in all_cards], reverse=True)]

        best_rank = HIGH_CARD
        best_tiebreaker = []

        for hand_combination in itertools.combinations(all_cards, 5):
            cards = sorted([self._card_to_value_suit(c) for c in hand_combination], key=lambda x: x[0], reverse=True)
            
            values = [c[0] for c in cards]
            suits = [c[1] for c in cards]
            
            is_flush = len(set(suits)) == 1
            
            value_counts = Counter(values)
            counts = sorted(value_counts.values(), reverse=True)
            val_sorted_by_count = sorted(value_counts.keys(), key=lambda v: (value_counts[v], v), reverse=True)
            
            is_straight = False
            # Ace-low straight check
            if all(v in values for v in [14, 2, 3, 4, 5]):
                is_straight = True
                # For tie-breaking, the ace in an A-5 straight is low
                values = [5, 4, 3, 2, 1]
            else:
                for i in range(len(values) - 4):
                    if values[i] - values[i+4] == 4 and len(set(values[i:i+5])) == 5:
                        is_straight = True
                        break

            rank = HIGH_CARD
            tiebreaker = val_sorted_by_count

            if is_straight and is_flush:
                if values[0] == 14: # Ace high straight flush
                    rank = ROYAL_FLUSH
                else:
                    rank = STRAIGHT_FLUSH
            elif counts[0] == 4:
                rank = FOUR_OF_A_KIND
            elif counts == [3, 2]:
                rank = FULL_HOUSE
            elif is_flush:
                rank = FLUSH
            elif is_straight:
                rank = STRAIGHT
                # For A-5 straight, the tiebreaker is the 5
                if set(values) == {14,2,3,4,5}: tiebreaker = [5]
            elif counts[0] == 3:
                rank = THREE_OF_A_KIND
            elif counts == [2, 2, 1]:
                rank = TWO_PAIR
            elif counts[0] == 2:
                rank = ONE_PAIR
            
            if rank > best_rank:
                best_rank = rank
                best_tiebreaker = tiebreaker
            elif rank == best_rank:
                # Basic tie-breaking
                if tiebreaker > best_tiebreaker:
                    best_tiebreaker = tiebreaker

        return best_rank, best_tiebreaker
    
    def _calculate_draw_strength(self, my_cards: List[str], community_cards: List[str]) -> float:
        """
        Estimates draw potential (flush or straight) on a 0-1 scale.
        """
        all_cards = my_cards + community_cards
        
        # Flush draw
        suits = [self._card_to_value_suit(c)[1] for c in all_cards]
        suit_counts = Counter(suits)
        flush_outs = 0
        if max(suit_counts.values(), default=0) == 4:
            flush_outs = 9 # Standard flush draw
        
        # Straight draw
        values = sorted(list(set([self._card_to_value_suit(c)[0] for c in all_cards])))
        straight_outs = 0
        
        # Open-ended straight draw
        for i in range(len(values) - 3):
            if values[i+3] - values[i] == 3 and len(set(values[i:i+4])) == 4:
                straight_outs = max(straight_outs, 8) # Open-ended
        
        # Gutshot straight draw
        for i in range(len(values) - 3):
             if values[i+3] - values[i] == 4 and len(set(values[i:i+4])) == 4:
                straight_outs = max(straight_outs, 4) # Gutshot

        # Crude probability conversion (Rule of 2 and 4)
        if len(community_cards) == 3: # Flop
            return (flush_outs + straight_outs) * 4 / 100
        elif len(community_cards) == 4: # Turn
            return (flush_outs + straight_outs) * 2 / 100
        else: # River or pre-flop
            return 0.0

    def _calculate_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, strength_level: str) -> int:
        """
        Calculates a reasonable raise amount based on pot size and hand strength.
        """
        if strength_level == 'strong':
            raise_fraction = 0.75  # 75% of pot
        elif strength_level == 'medium':
            raise_fraction = 0.5   # 50% of pot
        else:
            raise_fraction = 0.3 # For bluffs/semi-bluffs

        pot_based_raise = int(round_state.pot * raise_fraction)
        
        # The amount to raise is on top of the current bet
        # Total desired bet = current_bet + raise_amount
        # Let's simplify: raise by a fraction of the pot
        
        amount = pot_based_raise
        
        # Ensure raise is within legal bounds
        if round_state.min_raise is not None and round_state.max_raise is not None:
            # Clamp the bet to the legal range
            final_amount = max(round_state.min_raise, amount)
            final_amount = min(final_amount, round_state.max_raise)
            
            # If our calculated raise is less than min_raise, just raise the minimum
            if amount < round_state.min_raise:
                final_amount = round_state.min_raise
            
            # Can't raise more than we have
            if final_amount > remaining_chips:
                return remaining_chips # This will trigger an ALL_IN
                
            return int(final_amount)
        
        # Fallback if bounds are not available (should not happen)
        return int(min(remaining_chips, pot_based_raise))