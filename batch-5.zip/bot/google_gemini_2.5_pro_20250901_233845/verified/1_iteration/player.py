import itertools
import random
import collections
from typing import List, Tuple, Set

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# poker_action and round_state definitions are provided in the problem, no need to redefine.

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand charts and post-flop Monte Carlo simulation
    to estimate win probability and make decisions.
    """

    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount: int = 0
        self.starting_chips: int = 0
        self.monte_carlo_simulations = 750 # Balance between accuracy and speed

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once at the start of the game.
        Initializes bot state. `player_hands` here is for the first hand.
        """
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each new hand.
        The framework is expected to update self.hole_cards before this call for hands > 1,
        as this information is not provided in any method's arguments.
        This is a critical assumption based on the problem's incomplete specification.
        If the bot consistently folds after hand 1, this assumption is likely incorrect.
        """
        # For now, we assume self.hole_cards is magically updated. No action needed here.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        It is called when it is the bot's turn to act.
        """
        # --- Action Helper Variables ---
        legal_actions = self._get_legal_actions(round_state, remaining_chips)
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet_in_round

        # --- Strategy Dispatch ---
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, legal_actions, call_amount)
        else:
            return self._get_postflop_action(round_state, remaining_chips, legal_actions, call_amount)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each hand. Can be used for opponent modeling. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    # --- Pre-flop Strategy ---

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, legal_actions: set, call_amount: int) -> Tuple[PokerAction, int]:
        strength = self._get_preflop_strength(self.hole_cards)

        # Tier 1-2 (Strong hands): Always look to raise
        if strength >= 8:
            if PokerAction.RAISE in legal_actions:
                # Raise 3x the big blind if unopened, or pot-sized raise if facing a bet
                num_bets = len([p for p in round_state.player_actions if round_state.player_actions.get(p) in ['RAISE', 'CALL']])
                if num_bets == 0 : # Unopened pot (only blinds in)
                    raise_amount = 3 * self.big_blind_amount
                else: 
                    # Re-raise: pot size + last bet
                    raise_amount = round_state.pot + round_state.current_bet
                
                # Clamp raise amount to be legal
                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, round_state.max_raise)
                
                return PokerAction.RAISE, int(raise_amount)

        # Tier 3 (Good hands): Look to play if price is right
        elif strength >= 6:
            if call_amount == 0 and PokerAction.RAISE in legal_actions: # Unopened pot
                raise_amount = int(2.5 * self.big_blind_amount)
                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, round_state.max_raise)
                return PokerAction.RAISE, raise_amount
            elif PokerAction.CALL in legal_actions and call_amount < 0.1 * remaining_chips:
                return PokerAction.CALL, 0
        
        # Tier 4 (Speculative hands): Play only if very cheap
        elif strength >= 3:
            if PokerAction.CALL in legal_actions and call_amount <= self.big_blind_amount:
                return PokerAction.CALL, 0

        # Default / Weak hands
        if PokerAction.CHECK in legal_actions:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0
    
    # --- Post-flop Strategy ---

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, legal_actions: set, call_amount: int) -> Tuple[PokerAction, int]:
        active_players_ids = [p_id for p_id in round_state.player_bets if round_state.player_actions.get(p_id) != 'Fold']
        num_opponents = max(0, len(active_players_ids) - 1)
        
        if num_opponents <= 0:
            if PokerAction.CHECK in legal_actions:
                return PokerAction.CHECK, 0
            else: # Must be heads up and they bet, so we call
                return PokerAction.CALL, 0

        win_prob = self._estimate_win_prob(self.hole_cards, round_state.community_cards, num_opponents)
        
        pot_odds = call_amount / (round_state.pot + call_amount + 1e-9)

        # Go all-in if a monster hand on the river with high probability
        if round_state.round == 'River' and win_prob > 0.95 and PokerAction.ALL_IN in legal_actions:
            return PokerAction.ALL_IN, 0

        # Strong hands (win_prob > 80%): Bet/Raise for value
        if win_prob > 0.8 and PokerAction.RAISE in legal_actions:
            if call_amount > 0: # Facing a bet
                bet_amount = int(call_amount * 2.5 + round_state.pot) # Pot-sized raise
            else: # We open the betting
                bet_amount = int(0.75 * round_state.pot)
            
            bet_amount = max(bet_amount, round_state.min_raise)
            bet_amount = min(bet_amount, round_state.max_raise)
            
            if bet_amount < remaining_chips:
                return PokerAction.RAISE, bet_amount
            else:
                return PokerAction.ALL_IN, 0

        # Good hands (win_prob > 50%): Value bet or call
        if win_prob > 0.5:
            if call_amount == 0 and PokerAction.RAISE in legal_actions: # Bet if checked to
                bet_amount = int(0.5 * round_state.pot)
                bet_amount = max(bet_amount, round_state.min_raise)
                bet_amount = min(bet_amount, round_state.max_raise)
                return PokerAction.RAISE, bet_amount
            elif PokerAction.CALL in legal_actions and win_prob > pot_odds:
                return PokerAction.CALL, 0

        # Drawing hands / speculative calls
        if PokerAction.CALL in legal_actions and win_prob > pot_odds:
            return PokerAction.CALL, 0
        
        # Weak hands: Check/Fold, with an occasional bluff
        if call_amount == 0 and PokerAction.RAISE in legal_actions and random.random() < 0.15: # Bluff
             # Semi-bluff a C-Bet (continuation bet)
            bet_amount = int(0.5 * round_state.pot)
            bet_amount = max(bet_amount, round_state.min_raise)
            bet_amount = min(bet_amount, round_state.max_raise)
            return PokerAction.RAISE, bet_amount
            
        if PokerAction.CHECK in legal_actions:
            return PokerAction.CHECK, 0
        
        return PokerAction.FOLD, 0
    
    # --- Hand Evaluation and Simulation ---

    def _estimate_win_prob(self, hole_cards: List[str], community_cards: List[str], num_opponents: int) -> float:
        """
        Estimates win probability using a Monte Carlo simulation.
        """
        ranks = '23456789TJQKA'
        suits = 'shdc'
        deck = [r + s for r in ranks for s in suits]

        known_cards = hole_cards + community_cards
        for card in known_cards:
            if card in deck:
                deck.remove(card)

        wins = 0
        if num_opponents == 0: return 1.0

        for i in range(self.monte_carlo_simulations):
            deck_copy = random.sample(deck, len(deck))
            
            if len(deck_copy) < (num_opponents * 2) + (5 - len(community_cards)):
                break # not enough cards to run sim

            opp_hands = [deck_copy[j*2:j*2+2] for j in range(num_opponents)]
            
            remaining_deck = deck_copy[num_opponents*2:]
            num_remaining_comm = 5 - len(community_cards)
            sim_community = community_cards + remaining_deck[:num_remaining_comm]
            
            my_best = self._evaluate_best_hand(hole_cards + sim_community)
            
            opp_best_hands = [self._evaluate_best_hand(oh + sim_community) for oh in opp_hands]
            
            if not opp_best_hands or my_best >= max(opp_best_hands):
                wins += 1
                
        return wins / self.monte_carlo_simulations if self.monte_carlo_simulations > 0 else 0

    def _parse_cards(self, card_strs: List[str]) -> List[Tuple[int, str]]:
        ranks_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        parsed_cards = []
        for c in card_strs:
            rank_str = c[:-1]
            suit_str = c[-1]
            rank = int(rank_str) if rank_str.isdigit() else ranks_map[rank_str]
            parsed_cards.append((rank, suit_str))
        return parsed_cards


    def _evaluate_best_hand(self, seven_cards_str: List[str]):
        cards = self._parse_cards(seven_cards_str)
        best_rank = (-1,)
        for combo in itertools.combinations(cards, 5):
            rank = self._evaluate_five_card_hand(list(combo))
            if rank > best_rank:
                best_rank = rank
        return best_rank

    def _evaluate_five_card_hand(self, five_cards: List[Tuple[int, str]]):
        ranks = sorted([c[0] for c in five_cards], reverse=True)
        suits = [c[1] for c in five_cards]

        is_flush = len(set(suits)) == 1
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)
        if not is_straight and ranks == [14, 5, 4, 3, 2]: # Ace-low straight
            is_straight = True
            ranks = [5, 4, 3, 2, 1] 

        rank_counts = collections.Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)
        
        # Hand ranks: 8=SF, 7=4K, 6=FH, 5=Flush, 4=Straight, 3=3K, 2=2P, 1=1P, 0=HC
        if is_straight and is_flush: return (8, ranks[0])
        if counts[0] == 4: return (7, main_ranks[0], main_ranks[1])
        if counts == [3, 2]: return (6, main_ranks[0], main_ranks[1])
        if is_flush: return (5, tuple(ranks))
        if is_straight: return (4, ranks[0])
        if counts[0] == 3: return (3, main_ranks[0], tuple(main_ranks[1:3]))
        if counts == [2, 2, 1]: return (2, main_ranks[0], main_ranks[1], main_ranks[2])
        if counts[0] == 2: return (1, main_ranks[0], tuple(main_ranks[1:4]))
        return (0, tuple(ranks))

    def _get_preflop_strength(self, hole_cards_str: List[str]) -> int:
        """ Returns hand strength on a scale of 0-10 """
        cards = self._parse_cards(hole_cards_str)
        c1, c2 = cards[0], cards[1]
        r1, r2 = sorted([c1[0], c2[0]], reverse=True)
        is_suited = c1[1] == c2[1]
        is_pair = r1 == r2

        if is_pair:
            if r1 >= 11: return 10 # JJ+
            if r1 >= 8: return 8 # 88-TT
            return 6 # 22-77

        if r1 == 14: # Ace high
            if r2 >= 13: return 10 if is_suited else 8 # AKs, AKo
            if r2 >= 10: return 8 if is_suited else 6 # AQs-ATs, AQo-ATo
            if is_suited: return 4 # A9s-A2s
        
        if r1 == 13: # King high
            if r2 >= 11: return 8 if is_suited else 6 # KQs, KJs
            if r2 == 10: return 6 if is_suited else 4 # KTs
        
        if is_suited and r1 - r2 <= 2 and r1 >= 10: # Suited connectors
            return 5
            
        return 0

    def _get_legal_actions(self, round_state: RoundStateClient, remaining_chips: int) -> Set[PokerAction]:
        legal_actions = {PokerAction.FOLD}
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet_in_round

        if call_amount == 0:
            legal_actions.add(PokerAction.CHECK)
        elif call_amount < remaining_chips:
            legal_actions.add(PokerAction.CALL)

        if remaining_chips > 0:
            legal_actions.add(PokerAction.ALL_IN)

        my_total_potential_bet = remaining_chips + my_bet_in_round
        if round_state.min_raise > 0 and my_total_potential_bet >= round_state.min_raise:
            legal_actions.add(PokerAction.RAISE)
        
        return legal_actions