from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for hand ranks, makes code more readable
HIGH_CARD, ONE_PAIR, TWO_PAIR, THREE_OF_A_KIND, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH, ROYAL_FLUSH = range(10)

def _card_to_value(card: str) -> Tuple[int, str]:
    """Converts a card string like 'Th' to a tuple (rank, suit), e.g., (10, 'h')."""
    if not card or len(card) < 2:
        return 0, ' '
    rank_str = card[:-1]
    suit = card[-1]
    if '2' <= rank_str <= '9':
        rank = int(rank_str)
    else:
        rank = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(rank_str, 0)
    return rank, suit

class HandEvaluator:
    """
    Evaluates poker hands.
    The primary method `evaluate_hand` takes 5 to 7 cards and returns the best 5-card hand rank
    and its value for tie-breaking.
    """
    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]) -> Tuple[int, Tuple]:
        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        
        is_flush = len(set(suits)) == 1
        
        is_straight = False
        # Ace-low straight check (A, 2, 3, 4, 5) -> ranks are [14, 5, 4, 3, 2]
        if ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            tie_breaker_ranks = (5, 4, 3, 2, 1) # Treat Ace as 1 for tie-breaking
        # Regular straight check
        elif len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4):
            is_straight = True
            tie_breaker_ranks = tuple(ranks)

        if is_straight and is_flush:
            if ranks == [14, 13, 12, 11, 10]:
                return ROYAL_FLUSH, tuple(ranks)
            return STRAIGHT_FLUSH, tie_breaker_ranks

        rank_counts = Counter(ranks)
        sorted_rank_counts = sorted(rank_counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
        
        counts = [x[1] for x in sorted_rank_counts]
        major_ranks = [x[0] for x in sorted_rank_counts]

        if counts[0] == 4:
            return FOUR_OF_A_KIND, (major_ranks[0], major_ranks[1])
        if counts == [3, 2]:
            return FULL_HOUSE, (major_ranks[0], major_ranks[1])
        if is_flush:
            return FLUSH, tuple(ranks)
        if is_straight:
            return STRAIGHT, tie_breaker_ranks
        if counts[0] == 3:
            return THREE_OF_A_KIND, (major_ranks[0], major_ranks[1], major_ranks[2])
        if counts == [2, 2, 1]:
            return TWO_PAIR, (major_ranks[0], major_ranks[1], major_ranks[2])
        if counts[0] == 2:
            return ONE_PAIR, (major_ranks[0], major_ranks[1], major_ranks[2], major_ranks[3])

        return HIGH_CARD, tuple(ranks)

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, Tuple]:
        """Evaluates the best 5-card hand from a list of 5 to 7 cards."""
        if len(cards) < 5:
            return HIGH_CARD, tuple(sorted([_card_to_value(c)[0] for c in cards], reverse=True))

        card_values = [_card_to_value(c) for c in cards]
        
        best_rank = -1
        best_tie_breaker = (0,)

        for combo in combinations(card_values, 5):
            rank, tie_breaker = self._evaluate_5_card_hand(list(combo))
            if rank > best_rank:
                best_rank = rank
                best_tie_breaker = tie_breaker
            elif rank == best_rank:
                if tie_breaker > best_tie_breaker:
                    best_tie_breaker = tie_breaker
        
        return best_rank, best_tie_breaker

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.hand_evaluator = HandEvaluator()
        self.big_blind_amount = 10
        self.all_player_ids: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.all_player_ids = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        hand_strength = self._calculate_hand_strength(round_state)

        # Baseline thresholds for a tight-aggressive strategy
        fold_threshold = 0.20
        call_threshold = 0.50
        raise_threshold = 0.75

        # Adjust thresholds based on aggression
        pot_total = round_state.pot
        if amount_to_call > 0:
            bet_pot_ratio = amount_to_call / (pot_total + 1e-6)
            if bet_pot_ratio > 0.75: # Large bet compared to pot
                fold_threshold += 0.20
                call_threshold += 0.15
            elif bet_pot_ratio > 0.4: # Pot-sized bet
                fold_threshold += 0.10
                call_threshold += 0.10

        # Action decision logic
        if hand_strength < fold_threshold:
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
        
        if hand_strength < call_threshold:
            if can_check:
                return PokerAction.CHECK, 0
            
            # Simple pot odds check
            current_pot_size = round_state.pot + sum(round_state.player_bets.values())
            pot_odds = amount_to_call / (current_pot_size + amount_to_call + 1e-6)
            if hand_strength >= pot_odds:
                 if amount_to_call >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                 return PokerAction.CALL, 0
            else:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        if hand_strength < raise_threshold:
            # Medium-strong hand, prefer to call a raise, but bet if checked to.
            if can_check:
                return self._get_raise_action(round_state, 0.5) # Bet half pot
            else:
                if amount_to_call >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0

        # Hand strength is high, we want to raise/bet.
        if can_check:
            return self._get_raise_action(round_state, 0.75) # Bet 3/4 pot
        else:
            return self._get_raise_action(round_state, 1.0) # Pot-sized raise
            
    def _get_raise_action(self, round_state: RoundStateClient, pot_fraction: float) -> Tuple[PokerAction, int]:
        """Calculates a valid raise amount and returns the action, preventing invalid raises."""
        
        if round_state.min_raise > round_state.max_raise:
            return PokerAction.ALL_IN, 0

        pot_total = round_state.pot + sum(round_state.player_bets.values())
        desired_raise = int(pot_total * pot_fraction)
        
        raise_amount = max(desired_raise, round_state.min_raise)
        raise_amount = min(raise_amount, round_state.max_raise)
        
        if raise_amount >= round_state.max_raise:
            return PokerAction.ALL_IN, 0
        
        return PokerAction.RAISE, raise_amount

    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculates hand strength as a float from 0.0 to 1.0"""
        if round_state.round == 'Preflop':
            return self._get_preflop_strength()
        else:
            return self._get_postflop_strength(round_state)

    def _get_preflop_strength(self) -> float:
        """Assigns a value to a starting hand based on a tiered system"""
        card1, card2 = [_card_to_value(c) for c in self.hole_cards]
        r1, s1 = card1
        r2, s2 = card2
        
        high_card, low_card = (max(r1, r2), min(r1, r2))
        is_pair = r1 == r2
        is_suited = s1 == s2
        
        # Simplified Chen Formula / Hand Tiers
        if is_pair:
            if r1 >= 13: return 0.95  # AA, KK
            if r1 >= 11: return 0.90  # QQ, JJ
            if r1 >= 9: return 0.80   # TT, 99
            if r1 >= 7: return 0.70   # 88, 77
            return 0.60              # 66-22
        
        score = 0
        if high_card == 14: score = 10
        elif high_card == 13: score = 8
        elif high_card == 12: score = 7
        elif high_card == 11: score = 6
        else: score = high_card / 2

        if is_suited: score += 2
        
        gap = high_card - low_card
        if gap == 1: score += 1
        elif gap > 3: score -= (gap - 2)

        return min(max(score / 15.0, 0.0), 1.0) # Normalize to 0-1 range

    def _get_postflop_strength(self, round_state: RoundStateClient) -> float:
        """Evaluates hand strength post-flop, including draw potential."""
        all_cards_str = self.hole_cards + round_state.community_cards
        rank, _ = self.hand_evaluator.evaluate_hand(all_cards_str)

        strength_map = {
            ROYAL_FLUSH: 1.0, STRAIGHT_FLUSH: 0.98, FOUR_OF_A_KIND: 0.96,
            FULL_HOUSE: 0.92, FLUSH: 0.88, STRAIGHT: 0.84,
            THREE_OF_A_KIND: 0.75, TWO_PAIR: 0.65, ONE_PAIR: 0.45, HIGH_CARD: 0.15
        }
        made_hand_strength = strength_map.get(rank, 0.0)

        draw_strength = 0.0
        if round_state.round != 'River':
            all_cards_val = [_card_to_value(c) for c in all_cards_str]
            suits = [c[1] for c in all_cards_val]
            ranks = sorted(list(set(c[0] for c in all_cards_val)), reverse=True)
            
            suit_counts = Counter(suits)
            if suit_counts.most_common(1)[0][1] == 4:
                draw_strength = max(draw_strength, 0.35) # Flush draw

            unique_ranks = sorted(list(set(r[0] for r in all_cards_val)))
            # Open-ended straight draw
            if len(unique_ranks) >= 4:
                for i in range(len(unique_ranks) - 3):
                    if unique_ranks[i+3] - unique_ranks[i] == 3:
                        draw_strength = max(draw_strength, 0.30)
                        break
            # Gutshot straight draw
            if draw_strength < 0.25 and len(unique_ranks) >= 4:
                for i in range(len(unique_ranks) - 3):
                     if unique_ranks[i+3] - unique_ranks[i] == 4:
                        draw_strength = max(draw_strength, 0.15)
                        break
        
        # Combine made hand and draw potential. Don't let it exceed 1.0
        if made_hand_strength > 0.8: # If we have a monster, play it as such
            return made_hand_strength
        else:
            return min(made_hand_strength + draw_strength, 0.99)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass