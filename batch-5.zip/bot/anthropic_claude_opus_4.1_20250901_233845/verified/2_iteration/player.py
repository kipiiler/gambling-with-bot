from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.starting_chips = 0
        self.blind_amount = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.game_count = 0
        self.total_games = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.game_count += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current game state
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Determine betting round
        betting_round = self._get_betting_round(round_state)
        
        # Get pot odds
        if call_amount > 0:
            pot_odds = call_amount / (pot + call_amount + 0.001)
        else:
            pot_odds = 0
            
        # Decision making based on hand strength and position
        if remaining_chips == 0:
            return (PokerAction.CHECK, 0)
            
        # Pre-flop strategy
        if betting_round == 'Preflop':
            if hand_strength >= 0.85:  # Premium hands (AA, KK, QQ, AK)
                if current_bet == 0:
                    raise_amount = min(3 * self.blind_amount, max_raise)
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                else:
                    raise_amount = min(current_bet * 2, max_raise)
                    if raise_amount >= min_raise and raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                        
            elif hand_strength >= 0.7:  # Good hands (JJ, TT, AQ, AJ)
                if call_amount <= 3 * self.blind_amount:
                    if call_amount > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        raise_amount = min(2 * self.blind_amount, max_raise)
                        if raise_amount >= min_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif hand_strength >= 0.5:  # Decent hands
                if call_amount <= self.blind_amount:
                    if call_amount > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Post-flop strategy
        else:
            if hand_strength >= 0.8:  # Very strong hand
                if current_bet == 0:
                    raise_amount = min(int(pot * 0.75), max_raise)
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    raise_amount = min(current_bet * 2, max_raise)
                    if raise_amount >= min_raise and raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                        
            elif hand_strength >= 0.6:  # Good hand
                if pot_odds < 0.3 and call_amount > 0:
                    return (PokerAction.CALL, 0)
                elif call_amount == 0:
                    if betting_round == 'River':
                        return (PokerAction.CHECK, 0)
                    else:
                        raise_amount = min(int(pot * 0.5), max_raise)
                        if raise_amount >= min_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                elif call_amount > pot * 0.5:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CALL, 0)
                    
            elif hand_strength >= 0.4:  # Marginal hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
    def _get_betting_round(self, round_state: RoundStateClient) -> str:
        """Determine the current betting round."""
        return round_state.round
        
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)."""
        if not self.hole_cards:
            return 0.3
            
        # Extract cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Pre-flop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # AA, KK, QQ
                    return 0.95
                elif rank1 >= 10:  # JJ, TT
                    return 0.8
                elif rank1 >= 8:  # 99, 88
                    return 0.7
                elif rank1 >= 6:  # 77, 66
                    return 0.6
                else:
                    return 0.5
                    
            # High cards
            max_rank = max(rank1, rank2)
            min_rank = min(rank1, rank2)
            suited = (suit1 == suit2)
            
            # Ace high
            if max_rank == 14:
                if min_rank >= 12:  # AK, AQ
                    return 0.85 if suited else 0.8
                elif min_rank >= 10:  # AJ, AT
                    return 0.75 if suited else 0.7
                else:
                    return 0.55 if suited else 0.5
                    
            # King high
            elif max_rank == 13:
                if min_rank >= 11:  # KQ, KJ
                    return 0.7 if suited else 0.65
                elif min_rank >= 9:
                    return 0.6 if suited else 0.55
                else:
                    return 0.45 if suited else 0.4
                    
            # Queen high
            elif max_rank == 12:
                if min_rank >= 10:
                    return 0.65 if suited else 0.6
                else:
                    return 0.5 if suited else 0.45
                    
            # Connectors
            if abs(rank1 - rank2) == 1:
                if min_rank >= 8:
                    return 0.6 if suited else 0.55
                else:
                    return 0.5 if suited else 0.45
                    
            # Default
            return 0.4 if suited else 0.35
            
        else:
            # Post-flop: simple evaluation based on community cards
            community = round_state.community_cards
            if not community:
                return 0.5
                
            # Check for pairs, trips, etc.
            all_ranks = [rank1, rank2]
            for card in community:
                rank, _ = self._parse_card(card)
                all_ranks.append(rank)
                
            rank_counts = {}
            for rank in all_ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            max_count = max(rank_counts.values())
            
            # Evaluate based on combinations
            if max_count >= 4:
                return 0.95  # Four of a kind
            elif max_count == 3:
                if len([c for c in rank_counts.values() if c >= 2]) >= 2:
                    return 0.9  # Full house
                else:
                    return 0.75  # Three of a kind
            elif max_count == 2:
                pairs = [r for r, c in rank_counts.items() if c == 2]
                if len(pairs) >= 2:
                    return 0.65  # Two pair
                else:
                    # Check if we have a pair with our hole cards
                    if rank1 in pairs or rank2 in pairs:
                        pair_rank = rank1 if rank1 in pairs else rank2
                        if pair_rank >= 12:  # High pair
                            return 0.7
                        elif pair_rank >= 9:
                            return 0.6
                        else:
                            return 0.55
                    else:
                        return 0.45  # Pair on board only
            else:
                # High card
                if max(rank1, rank2) >= 13:
                    return 0.4
                else:
                    return 0.3
                    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse a card string into rank and suit."""
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
            '7': 7, '8': 8, '9': 9, 'T': 10,
            'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        rank = rank_map.get(rank_str, 2)
        return rank, suit
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.total_games += 1