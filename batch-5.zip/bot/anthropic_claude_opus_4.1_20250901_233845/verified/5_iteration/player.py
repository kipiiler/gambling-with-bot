from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.game_count = 0
        self.opponent_fold_rate = {}
        self.opponent_aggression = {}
        self.last_aggressive_action = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.game_count += 1
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id:
                if player not in self.opponent_fold_rate:
                    self.opponent_fold_rate[player] = 0.5
                    self.opponent_aggression[player] = 0.5
                    self.last_aggressive_action[player] = False
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Get position info
        position = self._get_position(round_state)
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Determine action based on round
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, position, hand_strength)
        else:
            return self._get_postflop_action(round_state, remaining_chips, position, hand_strength, pot_odds)
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Track opponent tendencies"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                pid = int(player_id)
                if action == 'Fold':
                    self.opponent_fold_rate[pid] = min(0.9, self.opponent_fold_rate.get(pid, 0.5) * 1.05)
                elif action in ['Raise', 'All_in']:
                    self.opponent_aggression[pid] = min(0.9, self.opponent_aggression.get(pid, 0.5) * 1.05)
                    self.last_aggressive_action[pid] = True
                elif action in ['Call', 'Check']:
                    self.opponent_aggression[pid] = max(0.1, self.opponent_aggression.get(pid, 0.5) * 0.95)
                    self.last_aggressive_action[pid] = False
    
    def _get_position(self, round_state: RoundStateClient) -> str:
        """Determine position relative to button"""
        active_players = len(round_state.current_player)
        my_idx = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
        
        if active_players == 2:
            return 'heads-up'
        elif my_idx >= active_players - 2:
            return 'late'
        elif my_idx <= 1:
            return 'early'
        else:
            return 'middle'
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        if call_amount == 0:
            return float('inf')
        
        pot_after_call = round_state.pot + call_amount
        return pot_after_call / (call_amount + 0.001)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1)"""
        if not self.hand:
            return 0.3
        
        # Convert cards to values
        card1_val = self._card_value(self.hand[0])
        card2_val = self._card_value(self.hand[1])
        suited = self.hand[0][-1] == self.hand[1][-1]
        
        # Preflop strength
        if round_state.round == 'Preflop':
            strength = 0.0
            
            # Pocket pairs
            if card1_val == card2_val:
                strength = 0.5 + (card1_val / 14) * 0.4
                if card1_val >= 10:  # TT+
                    strength = min(0.95, strength + 0.15)
            # High cards
            elif max(card1_val, card2_val) >= 12:  # A or K
                strength = 0.4 + (min(card1_val, card2_val) / 14) * 0.3
                if suited:
                    strength += 0.1
                if abs(card1_val - card2_val) <= 2:  # Connected
                    strength += 0.05
            # Suited connectors
            elif suited and abs(card1_val - card2_val) == 1:
                strength = 0.35 + (min(card1_val, card2_val) / 14) * 0.2
            # Other hands
            else:
                strength = 0.15 + (max(card1_val, card2_val) / 14) * 0.2
                if suited:
                    strength += 0.05
            
            return min(1.0, strength)
        
        # Postflop evaluation
        community = round_state.community_cards
        all_cards = self.hand + community
        
        # Check for made hands
        flush = self._has_flush(all_cards)
        straight = self._has_straight(all_cards)
        pairs = self._count_pairs(all_cards)
        high_card = max(card1_val, card2_val)
        
        strength = 0.1 + (high_card / 14) * 0.1
        
        # Adjust for made hands
        if flush and straight:
            strength = 0.95
        elif self._has_four_of_kind(all_cards):
            strength = 0.93
        elif self._has_full_house(all_cards):
            strength = 0.90
        elif flush:
            strength = 0.85
        elif straight:
            strength = 0.75
        elif self._has_three_of_kind(all_cards):
            strength = 0.65
        elif pairs >= 2:
            strength = 0.55
        elif pairs == 1:
            # Check if we have the pair
            if self._have_pair(all_cards):
                pair_rank = self._get_pair_rank(all_cards)
                strength = 0.35 + (pair_rank / 14) * 0.15
        
        # Adjust for draws
        if not flush and self._has_flush_draw(all_cards):
            strength += 0.15
        if not straight and self._has_straight_draw(all_cards):
            strength += 0.10
        
        # Adjust for board texture
        if self._is_dangerous_board(community):
            strength *= 0.8
        
        return min(1.0, strength)
    
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, position: str, hand_strength: float) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        pot_size = round_state.pot
        
        # Aggression factor based on position
        position_multiplier = {'late': 1.3, 'middle': 1.0, 'early': 0.8, 'heads-up': 1.2}.get(position, 1.0)
        adjusted_strength = hand_strength * position_multiplier
        
        # Random aggression factor
        aggro_factor = random.uniform(0.8, 1.2)
        adjusted_strength *= aggro_factor
        
        # If no one has raised
        if round_state.current_bet <= self.blind_amount * 2:
            if adjusted_strength > 0.7:
                # Strong hand - raise big
                raise_amount = min(remaining_chips, int(pot_size * random.uniform(2.5, 4)))
                return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength > 0.45:
                # Decent hand - standard raise
                raise_amount = min(remaining_chips, int(self.blind_amount * random.uniform(2.5, 3.5)))
                return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength > 0.35 and position in ['late', 'heads-up']:
                # Steal attempt
                raise_amount = min(remaining_chips, int(self.blind_amount * 2.5))
                return (PokerAction.RAISE, raise_amount)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Facing a raise
        else:
            raise_size_ratio = round_state.current_bet / (self.blind_amount * 2 + 0.001)
            
            if adjusted_strength > 0.8:
                # Premium hand - 3bet or call
                if raise_size_ratio < 4 and random.random() < 0.7:
                    reraise = min(remaining_chips, int(round_state.current_bet * random.uniform(2.5, 3.5)))
                    return (PokerAction.RAISE, reraise)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength > 0.6:
                # Good hand - call if not too expensive
                if raise_size_ratio < 3.5 and call_amount <= remaining_chips * 0.15:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength > 0.4:
                # Marginal hand - call small raises
                if raise_size_ratio < 2.5 and call_amount <= remaining_chips * 0.08:
                    return (PokerAction.CALL, 0)
            
            return (PokerAction.FOLD, 0)
    
    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, position: str, hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        pot_size = round_state.pot
        
        # Bluff frequency
        bluff_freq = 0.25 if position in ['late', 'heads-up'] else 0.15
        should_bluff = random.random() < bluff_freq
        
        # If no one has bet
        if round_state.current_bet == 0:
            if hand_strength > 0.7:
                # Strong hand - value bet
                bet_size = min(remaining_chips, int(pot_size * random.uniform(0.5, 0.8)))
                return (PokerAction.RAISE, bet_size)
            elif hand_strength > 0.5:
                # Medium hand - smaller bet
                bet_size = min(remaining_chips, int(pot_size * random.uniform(0.3, 0.5)))
                return (PokerAction.RAISE, bet_size)
            elif should_bluff and self._is_good_bluff_spot(round_state):
                # Bluff
                bet_size = min(remaining_chips, int(pot_size * random.uniform(0.4, 0.6)))
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        
        # Facing a bet
        else:
            # Calculate if we should call based on pot odds and hand strength
            required_equity = call_amount / (pot_size + call_amount + 0.001)
            
            if hand_strength > 0.8:
                # Very strong hand - raise for value
                if random.random() < 0.6:
                    raise_size = min(remaining_chips, int(round_state.current_bet * random.uniform(2, 3)))
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength > 0.6:
                # Good hand - call or occasionally raise
                if random.random() < 0.2 and call_amount < remaining_chips * 0.3:
                    raise_size = min(remaining_chips, int(round_state.current_bet * 2))
                    return (PokerAction.RAISE, raise_size)
                elif hand_strength > required_equity:
                    return (PokerAction.CALL, 0)
            elif hand_strength > required_equity * 0.8:
                # Marginal hand but good pot odds
                if call_amount <= remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
            elif should_bluff and call_amount > pot_size * 0.5:
                # Semi-bluff raise against large bets
                if random.random() < 0.15:
                    raise_size = min(remaining_chips, int(round_state.current_bet * 2.5))
                    return (PokerAction.RAISE, raise_size)
            
            return (PokerAction.FOLD, 0)
    
    def _is_good_bluff_spot(self, round_state: RoundStateClient) -> bool:
        """Determine if this is a good spot to bluff"""
        community = round_state.community_cards
        
        # Good bluff boards
        if len(community) >= 3:
            # Check for scary boards
            high_cards = sum(1 for c in community if self._card_value(c) >= 11)
            same_suit = len(set(c[-1] for c in community)) == 1
            connected = self._has_straight_potential(community)
            
            return high_cards >= 2 or same_suit or connected
        
        return random.random() < 0.3
    
    def _is_dangerous_board(self, community: List[str]) -> bool:
        """Check if board is dangerous"""
        if len(community) < 3:
            return False
        
        # Many high cards
        high_cards = sum(1 for c in community if self._card_value(c) >= 11)
        if high_cards >= 3:
            return True
        
        # Flush possible
        suits = [c[-1] for c in community]
        if any(suits.count(s) >= 3 for s in set(suits)):
            return True
        
        # Straight possible
        if self._has_straight_potential(community):
            return True
        
        return False
    
    def _has_straight_potential(self, cards: List[str]) -> bool:
        """Check if cards have straight potential"""
        values = sorted([self._card_value(c) for c in cards])
        for i in range(len(values) - 2):
            if values[i+2] - values[i] <= 4:
                return True
        return False
    
    def _card_value(self, card: str) -> int:
        """Convert card to numeric value"""
        if not card or len(card) < 1:
            return 0
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0
    
    def _has_flush(self, cards: List[str]) -> bool:
        """Check for flush"""
        suits = [c[-1] for c in cards if len(c) > 1]
        return any(suits.count(s) >= 5 for s in set(suits))
    
    def _has_flush_draw(self, cards: List[str]) -> bool:
        """Check for flush draw"""
        suits = [c[-1] for c in cards if len(c) > 1]
        return any(suits.count(s) == 4 for s in set(suits))
    
    def _has_straight(self, cards: List[str]) -> bool:
        """Check for straight"""
        values = sorted(set(self._card_value(c) for c in cards))
        
        # Check ace-low straight
        if 14 in values:
            values.append(1)
        
        for i in range(len(values) - 4):
            if values[i+4] - values[i] == 4:
                return True
        return False
    
    def _has_straight_draw(self, cards: List[str]) -> bool:
        """Check for straight draw"""
        values = sorted(set(self._card_value(c) for c in cards))
        
        if 14 in values:
            values.append(1)
        
        # Open-ended straight draw
        for i in range(len(values) - 3):
            if values[i+3] - values[i] == 3:
                return True
        return False
    
    def _count_pairs(self, cards: List[str]) -> int:
        """Count number of pairs"""
        values = [self._card_value(c) for c in cards]
        pairs = 0
        for v in set(values):
            if values.count(v) == 2:
                pairs += 1
        return pairs
    
    def _has_three_of_kind(self, cards: List[str]) -> bool:
        """Check for three of a kind"""
        values = [self._card_value(c) for c in cards]
        return any(values.count(v) >= 3 for v in set(values))
    
    def _has_four_of_kind(self, cards: List[str]) -> bool:
        """Check for four of a kind"""
        values = [self._card_value(c) for c in cards]
        return any(values.count(v) >= 4 for v in set(values))
    
    def _has_full_house(self, cards: List[str]) -> bool:
        """Check for full house"""
        values = [self._card_value(c) for c in cards]
        has_three = False
        has_pair = False
        
        for v in set(values):
            count = values.count(v)
            if count >= 3:
                has_three = True
            elif count >= 2:
                has_pair = True
        
        return has_three and has_pair
    
    def _have_pair(self, cards: List[str]) -> bool:
        """Check if we have a pair with our hole cards"""
        if not self.hand:
            return False
        
        my_values = [self._card_value(c) for c in self.hand]
        all_values = [self._card_value(c) for c in cards]
        
        for v in my_values:
            if all_values.count(v) >= 2:
                return True
        return False
    
    def _get_pair_rank(self, cards: List[str]) -> int:
        """Get the rank of our pair"""
        if not self.hand:
            return 0
        
        my_values = [self._card_value(c) for c in self.hand]
        all_values = [self._card_value(c) for c in cards]
        
        for v in my_values:
            if all_values.count(v) >= 2:
                return v
        return 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass