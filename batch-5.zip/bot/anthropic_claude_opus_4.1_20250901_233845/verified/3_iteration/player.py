from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.blind_amount = 10
        self.game_count = 0
        self.position_stats = {'small_blind': 0, 'big_blind': 0}
        self.fold_count = 0
        self.raise_count = 0
        self.call_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        
        if self.id == small_blind_player_id:
            self.position_stats['small_blind'] += 1
        elif self.id == big_blind_player_id:
            self.position_stats['big_blind'] += 1
            
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0 to 1"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.3
            
        # Parse hole cards
        card1_rank = self.card_rank_value(hole_cards[0][0])
        card2_rank = self.card_rank_value(hole_cards[1][0])
        suited = len(hole_cards) >= 2 and hole_cards[0][1] == hole_cards[1][1]
        
        # Pre-flop strength evaluation
        if not community_cards:
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 12:  # QQ or better
                    return 0.95
                elif card1_rank >= 10:  # TT or JJ
                    return 0.85
                elif card1_rank >= 7:  # 77-99
                    return 0.75
                else:  # Small pairs
                    return 0.65
                    
            # High cards
            high_card = max(card1_rank, card2_rank)
            low_card = min(card1_rank, card2_rank)
            gap = high_card - low_card
            
            if high_card == 14:  # Ace high
                if low_card >= 12:  # AK, AQ
                    return 0.85 if suited else 0.80
                elif low_card >= 10:  # AJ, AT
                    return 0.75 if suited else 0.70
                else:
                    return 0.60 if suited else 0.55
                    
            elif high_card == 13:  # King high
                if low_card >= 11:  # KQ, KJ
                    return 0.70 if suited else 0.65
                elif low_card >= 9:  # KT, K9
                    return 0.60 if suited else 0.55
                else:
                    return 0.45
                    
            elif high_card >= 11:  # Queen or Jack high
                if gap <= 2:  # Connected cards
                    return 0.55 if suited else 0.50
                else:
                    return 0.45 if suited else 0.40
                    
            # Suited connectors
            if suited and gap == 1:
                return 0.50
            elif gap == 1:  # Unsuited connectors
                return 0.45
                
            # Default weak hand
            return 0.35
            
        # Post-flop evaluation (simplified)
        else:
            # Count pairs, trips, etc.
            all_cards = hole_cards + community_cards
            ranks = [self.card_rank_value(card[0]) for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            max_count = max(rank_counts.values())
            
            # Check for flush potential
            suits = [card[1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit = max(suit_counts.values())
            
            # Evaluate strength
            if max_count >= 4:  # Four of a kind
                return 0.98
            elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Full house
                return 0.95
            elif max_suit >= 5:  # Flush
                return 0.90
            elif max_count == 3:  # Three of a kind
                return 0.80
            elif len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Two pair
                return 0.70
            elif max_count == 2:  # One pair
                # Check if we have top pair
                hole_ranks = [self.card_rank_value(card[0]) for card in hole_cards]
                if max(hole_ranks) in rank_counts and rank_counts[max(hole_ranks)] == 2:
                    if max(hole_ranks) >= 12:  # High pair
                        return 0.75
                    else:
                        return 0.65
                return 0.55
            else:  # High card
                hole_ranks = [self.card_rank_value(card[0]) for card in hole_cards]
                if max(hole_ranks) >= 13:  # Ace or King high
                    return 0.45
                return 0.35
                
    def card_rank_value(self, rank: str) -> int:
        """Convert card rank to numerical value"""
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
                
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Get current state
            pot = round_state.pot
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_bet
            
            # Evaluate hand strength
            hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self.calculate_pot_odds(pot, call_amount)
            
            # Determine betting round
            if not round_state.community_cards:
                betting_round = 'preflop'
            elif len(round_state.community_cards) == 3:
                betting_round = 'flop'
            elif len(round_state.community_cards) == 4:
                betting_round = 'turn'
            else:
                betting_round = 'river'
                
            # Aggressive pre-flop strategy
            if betting_round == 'preflop':
                if hand_strength >= 0.85:  # Premium hands
                    # Always raise with premium hands
                    if current_bet == 0:
                        raise_amount = min(pot * 3, remaining_chips // 2)
                        return (PokerAction.RAISE, max(raise_amount, self.blind_amount * 3))
                    elif call_amount < remaining_chips // 3:
                        raise_amount = min(call_amount * 3, remaining_chips // 2)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                        
                elif hand_strength >= 0.70:  # Good hands
                    if current_bet == 0:
                        # Open raise
                        raise_amount = self.blind_amount * 2
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= self.blind_amount * 3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
                elif hand_strength >= 0.55:  # Playable hands
                    if current_bet == 0:
                        return (PokerAction.CHECK, 0)
                    elif call_amount <= self.blind_amount:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
                else:  # Weak hands
                    if current_bet == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            # Post-flop strategy
            else:
                # Strong hands - bet/raise
                if hand_strength >= 0.80:
                    if current_bet == 0:
                        # Bet for value
                        bet_amount = min(pot // 2, remaining_chips // 3)
                        if bet_amount > 0:
                            return (PokerAction.RAISE, bet_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                    elif call_amount < remaining_chips // 2:
                        # Consider raising
                        if hand_strength >= 0.90:
                            raise_amount = min(call_amount * 2, remaining_chips // 2)
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)
                        
                # Medium hands - call if pot odds are good
                elif hand_strength >= 0.60:
                    if current_bet == 0:
                        return (PokerAction.CHECK, 0)
                    elif pot_odds < hand_strength - 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
                # Drawing hands
                elif hand_strength >= 0.45:
                    if current_bet == 0:
                        return (PokerAction.CHECK, 0)
                    elif pot_odds < 0.25:  # Good pot odds
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
                # Weak hands - check/fold
                else:
                    if current_bet == 0:
                        # Occasional bluff
                        if pot > 0 and remaining_chips > pot * 2:
                            bluff_frequency = 0.15
                            import random
                            if random.random() < bluff_frequency:
                                bluff_amount = min(pot // 3, remaining_chips // 4)
                                if bluff_amount > 0:
                                    return (PokerAction.RAISE, bluff_amount)
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # Fallback to safe action
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif round_state.current_bet - round_state.player_bets.get(str(self.id), 0) < remaining_chips // 10:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, 
                     active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hole_cards = []