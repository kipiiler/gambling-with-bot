from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.hand_strength_cache = {}
        self.opponent_aggression = {}
        self.round_aggression = {}
        self.total_hands_played = 0
        self.position_advantage = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.total_hands_played = 0
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_aggression[str(player_id)] = 0.5
        
        # Check position advantage
        self.position_advantage = (self.id != big_blind_player_id and self.id != small_blind_player_id)
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_aggression = {}
        self.hand_strength_cache = {}
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(round_state)
        
        # Get pot odds
        pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
        
        # Calculate effective stack
        effective_stack = min(remaining_chips, round_state.max_raise)
        
        # Get position info
        num_players = len(round_state.current_player)
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        
        # Update opponent tracking
        self.update_opponent_tracking(round_state)
        
        # Get average aggression
        avg_aggression = self.get_average_aggression()
        
        # Preflop strategy
        if round_state.round == 'Preflop':
            return self.preflop_strategy(hand_strength, to_call, effective_stack, round_state, avg_aggression, remaining_chips)
        
        # Postflop strategy
        return self.postflop_strategy(hand_strength, to_call, effective_stack, round_state, pot_odds, avg_aggression, remaining_chips)
    
    def preflop_strategy(self, hand_strength, to_call, effective_stack, round_state, avg_aggression, remaining_chips):
        # Premium hands (AA, KK, QQ, AKs)
        if hand_strength > 0.85:
            if to_call > 0:
                # 3-bet or 4-bet with premium hands
                raise_amount = min(int(to_call * 3 + round_state.pot * 0.7), effective_stack)
                if raise_amount >= round_state.min_raise and raise_amount <= effective_stack:
                    return (PokerAction.RAISE, raise_amount)
                elif to_call < remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Open raise
                raise_amount = min(int(round_state.pot * 2.5), effective_stack)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Strong hands (JJ, TT, AK, AQ)
        elif hand_strength > 0.75:
            pot_ratio = to_call / (round_state.pot + 0.01)
            if pot_ratio < 0.3:
                if to_call > 0:
                    return (PokerAction.CALL, 0)
                else:
                    raise_amount = min(int(round_state.pot * 2), effective_stack)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
            elif pot_ratio < 0.5 and avg_aggression < 0.6:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Playable hands
        elif hand_strength > 0.6:
            pot_ratio = to_call / (round_state.pot + 0.01)
            if pot_ratio < 0.15:
                if to_call > 0:
                    return (PokerAction.CALL, 0)
                else:
                    # Sometimes open raise with position
                    if self.position_advantage and random.random() < 0.4:
                        raise_amount = min(int(round_state.pot * 1.5), effective_stack)
                        if raise_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= round_state.pot * 0.1 and hand_strength > 0.4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def postflop_strategy(self, hand_strength, to_call, effective_stack, round_state, pot_odds, avg_aggression, remaining_chips):
        # Very strong hands
        if hand_strength > 0.9:
            if to_call > 0:
                # Sometimes slowplay, mostly raise
                if random.random() < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    raise_amount = min(int(to_call * 2.5 + round_state.pot * 0.6), effective_stack)
                    if raise_amount >= round_state.min_raise and raise_amount <= effective_stack:
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call < remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
            else:
                # Bet for value
                bet_amount = min(int(round_state.pot * 0.7), effective_stack)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Strong hands
        elif hand_strength > 0.75:
            if to_call > 0:
                if pot_odds > hand_strength * 0.8:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Value bet
                bet_amount = min(int(round_state.pot * 0.5), effective_stack)
                if bet_amount >= round_state.min_raise and random.random() < 0.7:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Medium strength hands
        elif hand_strength > 0.6:
            if to_call > 0:
                if pot_odds > hand_strength * 0.9:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Sometimes bet, mostly check
                if random.random() < 0.3 and avg_aggression < 0.5:
                    bet_amount = min(int(round_state.pot * 0.3), effective_stack)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Weak hands or draws
        else:
            if to_call == 0:
                # Bluff occasionally
                if random.random() < 0.15 and avg_aggression < 0.4:
                    bet_amount = min(int(round_state.pot * 0.4), effective_stack)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds > 0.7 and to_call < round_state.pot * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        # Cache hand strength for the round
        cache_key = tuple(round_state.community_cards)
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        # Preflop hand strength based on hole cards
        if round_state.round == 'Preflop':
            strength = self.evaluate_preflop_strength()
        else:
            strength = self.evaluate_postflop_strength(round_state.community_cards)
        
        self.hand_strength_cache[cache_key] = strength
        return strength
    
    def evaluate_preflop_strength(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.5
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                      '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        
        v1 = rank_values.get(rank1, 2)
        v2 = rank_values.get(rank2, 2)
        
        # Pocket pairs
        if rank1 == rank2:
            if v1 >= 12:  # QQ+
                return 0.88 + (v1 - 12) * 0.03
            elif v1 >= 10:  # TT-JJ
                return 0.78 + (v1 - 10) * 0.04
            elif v1 >= 7:  # 77-99
                return 0.65 + (v1 - 7) * 0.04
            else:  # 22-66
                return 0.55 + (v1 - 2) * 0.02
        
        # High cards
        high_card = max(v1, v2)
        low_card = min(v1, v2)
        suited = (suit1 == suit2)
        
        # Ace high
        if high_card == 14:
            if low_card >= 13:  # AK
                return 0.85 if suited else 0.82
            elif low_card >= 12:  # AQ
                return 0.80 if suited else 0.77
            elif low_card >= 11:  # AJ
                return 0.75 if suited else 0.72
            elif low_card >= 10:  # AT
                return 0.70 if suited else 0.67
            else:  # Ax
                return 0.58 + low_card * 0.01 if suited else 0.55 + low_card * 0.01
        
        # King high
        if high_card == 13:
            if low_card >= 12:  # KQ
                return 0.73 if suited else 0.70
            elif low_card >= 11:  # KJ
                return 0.68 if suited else 0.65
            elif low_card >= 10:  # KT
                return 0.63 if suited else 0.60
            else:
                return 0.52 + low_card * 0.01 if suited else 0.50 + low_card * 0.01
        
        # Connected cards
        if abs(v1 - v2) == 1:
            base = 0.45 + min(low_card, 10) * 0.02
            return base + 0.03 if suited else base
        
        # Suited connectors and one-gappers
        if suited and abs(v1 - v2) <= 2:
            return 0.48 + min(low_card, 10) * 0.015
        
        # Default
        return 0.35 + (high_card + low_card) * 0.01
    
    def evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        # Simplified postflop evaluation
        all_cards = self.hole_cards + community_cards
        
        # Check for made hands
        ranks = [self.get_rank_value(card[0]) for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for pairs, trips, etc.
        max_count = max(rank_counts.values())
        
        # Flush check
        has_flush = any(count >= 5 for count in suit_counts.values())
        
        # Straight check
        unique_ranks = sorted(set(ranks))
        has_straight = self.check_straight(unique_ranks)
        
        # Evaluate hand strength
        if has_flush and has_straight:
            return 0.98
        elif max_count == 4:
            return 0.95
        elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
            return 0.90  # Full house
        elif has_flush:
            return 0.88
        elif has_straight:
            return 0.85
        elif max_count == 3:
            return 0.75
        elif len([c for c in rank_counts.values() if c == 2]) >= 2:
            return 0.65  # Two pair
        elif max_count == 2:
            # Pair strength depends on rank
            pair_rank = max([rank for rank, count in rank_counts.items() if count == 2])
            return 0.45 + pair_rank * 0.02
        else:
            # High card
            return 0.25 + max(ranks) * 0.015
    
    def get_rank_value(self, rank: str) -> int:
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                      '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        return rank_values.get(rank, 2)
    
    def check_straight(self, ranks: List[int]) -> bool:
        if len(ranks) < 5:
            return False
        
        # Check for regular straight
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5 straight
        if 14 in ranks and set([2, 3, 4, 5]).issubset(set(ranks)):
            return True
        
        return False
    
    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        
        if to_call == 0:
            return 1.0
        
        pot_after_call = round_state.pot + to_call
        return pot_after_call / (to_call + 0.01)
    
    def update_opponent_tracking(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All_in']:
                    self.opponent_aggression[player_id] = min(1.0, self.opponent_aggression.get(player_id, 0.5) + 0.1)
                    self.round_aggression[player_id] = self.round_aggression.get(player_id, 0) + 1
                elif action == 'Call':
                    self.opponent_aggression[player_id] = self.opponent_aggression.get(player_id, 0.5) * 0.95
                elif action == 'Fold':
                    self.opponent_aggression[player_id] = max(0.0, self.opponent_aggression.get(player_id, 0.5) - 0.05)
    
    def get_average_aggression(self) -> float:
        if not self.opponent_aggression:
            return 0.5
        return sum(self.opponent_aggression.values()) / (len(self.opponent_aggression) + 0.01)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.total_hands_played += 1
        
        # Decay aggression values slightly
        for player_id in self.opponent_aggression:
            self.opponent_aggression[player_id] = self.opponent_aggression[player_id] * 0.98 + 0.01
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass