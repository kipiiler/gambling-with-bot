from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0
        self.all_players = []
        self.game_history = []
        self.opponent_stats = {}
        self.hand_count = 0
        self.is_big_blind = False
        self.is_small_blind = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.all_players = all_players
        self.hand_count += 1
        self.is_big_blind = (big_blind_player_id == self.id)
        self.is_small_blind = (small_blind_player_id == self.id)
        
        for player_id in all_players:
            if player_id not in self.opponent_stats:
                self.opponent_stats[player_id] = {
                    'vpip': 0,
                    'pfr': 0,
                    'aggression': 0,
                    'hands_played': 0,
                    'showdown_wins': 0,
                    'folds_to_raise': 0
                }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Calculate hand strength with more nuanced evaluation"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        card1_rank = self.get_card_rank(hole_cards[0])
        card2_rank = self.get_card_rank(hole_cards[1])
        card1_suit = hole_cards[0][-1] if hole_cards[0] else ''
        card2_suit = hole_cards[1][-1] if hole_cards[1] else ''
        
        is_pair = (card1_rank == card2_rank)
        is_suited = (card1_suit == card2_suit)
        
        # Pre-flop strength calculation
        if not community_cards:
            strength = 0.0
            
            # Pocket pairs
            if is_pair:
                strength = 0.5 + (card1_rank / 14) * 0.5
                if card1_rank >= 10:  # High pairs
                    strength = min(0.95, strength + 0.2)
            else:
                high_card = max(card1_rank, card2_rank)
                low_card = min(card1_rank, card2_rank)
                gap = high_card - low_card
                
                # High cards bonus
                if high_card == 14:  # Ace
                    strength += 0.25
                elif high_card >= 12:  # K, Q
                    strength += 0.15
                elif high_card >= 10:  # J, T
                    strength += 0.1
                    
                # Connected cards bonus
                if gap == 1:
                    strength += 0.08
                elif gap == 2:
                    strength += 0.04
                    
                # Suited bonus
                if is_suited:
                    strength += 0.05
                    
                # Two high cards
                if high_card >= 10 and low_card >= 10:
                    strength += 0.15
                    
                # Ace with high kicker
                if high_card == 14 and low_card >= 10:
                    strength += 0.1
                    
            return min(1.0, max(0.0, strength))
        
        # Post-flop evaluation
        all_cards = hole_cards + community_cards
        strength = self.evaluate_made_hand(all_cards, hole_cards)
        
        # Adjust for draws
        if len(community_cards) < 5:
            draw_strength = self.evaluate_draws(hole_cards, community_cards)
            strength = max(strength, draw_strength * 0.7)
            
        return min(1.0, max(0.0, strength))
    
    def evaluate_made_hand(self, all_cards: List[str], hole_cards: List[str]) -> float:
        """Evaluate the strength of made hands"""
        ranks = [self.get_card_rank(card) for card in all_cards]
        suits = [card[-1] if card else '' for card in all_cards]
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        is_straight = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                is_straight = True
                break
        # Check for A-2-3-4-5 straight
        if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
            is_straight = True
            
        # Count pairs, trips, quads
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)
        
        # Determine hand strength
        if is_straight and is_flush:
            return 0.95  # Straight flush
        elif quads > 0:
            return 0.92  # Four of a kind
        elif trips > 0 and pairs > 0:
            return 0.88  # Full house
        elif is_flush:
            return 0.85  # Flush
        elif is_straight:
            return 0.80  # Straight
        elif trips > 0:
            # Check if we're using our hole cards for the trips
            hole_ranks = [self.get_card_rank(card) for card in hole_cards]
            for rank in hole_ranks:
                if rank_counts.get(rank, 0) >= 3:
                    return 0.70  # Strong trips
            return 0.65  # Weak trips
        elif pairs >= 2:
            # Check if we have a pocket pair
            if self.get_card_rank(hole_cards[0]) == self.get_card_rank(hole_cards[1]):
                return 0.60  # Two pair with pocket pair
            return 0.55  # Regular two pair
        elif pairs == 1:
            # Check which cards make the pair
            hole_ranks = [self.get_card_rank(card) for card in hole_cards]
            for rank in hole_ranks:
                if rank_counts.get(rank, 0) == 2:
                    if rank >= 12:  # High pair
                        return 0.45
                    elif rank >= 9:  # Medium pair
                        return 0.35
                    else:  # Low pair
                        return 0.25
            return 0.20  # Board pair only
        else:
            # High card
            max_rank = max([self.get_card_rank(card) for card in hole_cards])
            return 0.05 + (max_rank / 14) * 0.15
    
    def evaluate_draws(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate drawing hands"""
        all_cards = hole_cards + community_cards
        ranks = [self.get_card_rank(card) for card in all_cards]
        suits = [card[-1] if card else '' for card in all_cards]
        
        # Flush draw
        for suit in set(suits):
            if suits.count(suit) == 4:
                hole_suits = [card[-1] for card in hole_cards]
                if suit in hole_suits:
                    return 0.35  # Strong flush draw
                    
        # Open-ended straight draw
        unique_ranks = sorted(set(ranks))
        for i in range(len(unique_ranks) - 3):
            if unique_ranks[i+3] - unique_ranks[i] == 3:
                hole_ranks = [self.get_card_rank(card) for card in hole_cards]
                if any(rank in unique_ranks[i:i+4] for rank in hole_ranks):
                    return 0.30  # Straight draw
                    
        return 0.0
    
    def get_card_rank(self, card: str) -> int:
        if not card or len(card) < 2:
            return 0
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        if pot + call_amount == 0:
            return 0.0
        return call_amount / (pot + call_amount + 0.001)
    
    def get_aggression_factor(self, round_state: RoundStateClient) -> float:
        """Determine aggression based on position and stack size"""
        # Position-based aggression
        if self.is_small_blind:
            position_factor = 1.3  # More aggressive in position
        elif self.is_big_blind:
            position_factor = 1.0
        else:
            position_factor = 1.2
            
        # Stack size factor
        if hasattr(self, 'remaining_chips'):
            stack_bb = self.remaining_chips / (self.big_blind + 0.001)
            if stack_bb < 10:  # Short stack - more aggressive
                stack_factor = 1.5
            elif stack_bb < 30:  # Medium stack
                stack_factor = 1.2
            else:  # Deep stack
                stack_factor = 1.0
        else:
            stack_factor = 1.1
            
        # Round-based aggression
        round_factors = {
            'Preflop': 1.0,
            'Flop': 1.1,
            'Turn': 1.2,
            'River': 1.3
        }
        round_factor = round_factors.get(round_state.round, 1.0)
        
        return position_factor * stack_factor * round_factor
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        
        # Get current bet amounts
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot = round_state.pot
        
        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Get aggression factor
        aggression = self.get_aggression_factor(round_state)
        
        # Adjust strength based on aggression
        adjusted_strength = hand_strength * aggression
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Determine number of opponents
        active_players = len([p for p, action in round_state.player_actions.items() 
                            if action != 'Fold'])
        
        # Multi-way pot adjustment
        if active_players > 2:
            adjusted_strength *= 0.85
            
        # Decision logic with more aggression
        if call_amount == 0:  # Can check
            if adjusted_strength > 0.65:  # Strong hand - bet
                bet_size = int(pot * (0.5 + adjusted_strength * 0.5))
                bet_size = min(bet_size, remaining_chips)
                if bet_size > round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            elif adjusted_strength > 0.35 and aggression > 1.2:  # Bluff occasionally
                if pot > 0:
                    bet_size = int(pot * 0.4)
                    if bet_size <= remaining_chips and bet_size > round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
            
        else:  # Facing a bet
            # All-in considerations for very strong hands
            if adjusted_strength > 0.85 and remaining_chips > 0:
                return (PokerAction.ALL_IN, 0)
                
            # Raise with strong hands
            if adjusted_strength > 0.70:
                raise_size = int(round_state.current_bet * 2.5 + pot * 0.3)
                raise_size = max(raise_size, round_state.min_raise)
                if raise_size <= remaining_chips:
                    return (PokerAction.RAISE, raise_size)
                elif remaining_chips > 0:
                    return (PokerAction.ALL_IN, 0)
                    
            # Call with decent hands and good pot odds
            if adjusted_strength > 0.40 or (adjusted_strength > 0.25 and pot_odds < adjusted_strength):
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                    
            # Fold weak hands
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent statistics
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and int(player_id) in self.opponent_stats:
                stats = self.opponent_stats[int(player_id)]
                if action in ['Raise', 'All-in']:
                    stats['aggression'] += 1
                elif action == 'Call':
                    stats['vpip'] += 1
                elif action == 'Fold':
                    stats['folds_to_raise'] += 1
                stats['hands_played'] += 1
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        self.game_history.append({
            'score': player_score,
            'hand': self.hole_cards,
            'final_board': round_state.community_cards
        })