from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 50
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.my_hand = None
        self.players = []
        self.aggression_factor = 2.5
        self.position_factor = 0
        self.hand_strength_cache = {}
        self.opponent_profiles = {}
        self.round_history = []
        self.current_bet = 0
        self.total_invested = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands[0] if player_hands else "??"
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = sorted(all_players)
        
        for player in all_players:
            if player not in self.opponent_profiles:
                self.opponent_profiles[player] = {
                    'vpip': 0,
                    'pfr': 0,
                    'aggression': 0,
                    'hands_played': 0,
                    'hands_raised': 0,
                    'hands_voluntarily_put_money': 0
                }
    
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
        
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._preflop_strength(hole_cards)
        
        return self._postflop_strength(hole_cards, community_cards)
    
    def _preflop_strength(self, hole_cards: List[str]) -> float:
        """Evaluate pre-flop hand strength"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        ranks = [card[:-1] for card in hole_cards]
        suits = [card[-1] for card in hole_cards]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank1, rank2 = rank_map[ranks[0]], rank_map[ranks[1]]
        suited = suits[0] == suits[1]
        connected = abs(rank1 - rank2) <= 1
        
        high_card = max(rank1, rank2)
        
        score = 0
        if ranks[0] == ranks[1]:
            score = 50 + high_card * 2
        elif suited and connected:
            score = 30 + high_card
        elif connected:
            score = 20 + high_card * 0.8
        elif suited:
            score = 25 + high_card * 0.9
        else:
            score = min(rank1, rank2) + high_card * 0.7
        
        return min(score / 70.0, 1.0)
    
    def _postflop_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simplified post-flop hand strength"""
        if not community_cards or len(community_cards) < 3:
            return 0.0
            
        all_cards = hole_cards + community_cards
        strength = 0.0
        
        # Check pairs
        ranks = [card[:-1] for card in all_cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        pairs = [r for r, c in rank_counts.items() if c == 2]
        three_kind = [r for r, c in rank_counts.items() if c == 3]
        four_kind = [r for r, c in rank_counts.items() if c == 4]
        
        if four_kind:
            strength = 0.9
        elif three_kind and pairs:
            strength = 0.8
        elif three_kind:
            strength = 0.7
        elif len(pairs) >= 2:
            strength = 0.6
        elif pairs:
            strength = 0.4
        else:
            strength = 0.1
            
        # Flush potential
        suits = [card[-1] for card in all_cards]
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        if max(suit_counts.values()) >= 5:
            strength = max(strength, 0.5)
        
        return min(strength, 1.0)
    
    def _get_position_score(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage"""
        my_index = self.players.index(self.id)
        players_left = len(round_state.current_player)
        
        if players_left == 2:
            # Heads-up
            if my_index == 0:
                return 0.8  # Dealer position
            else:
                return 0.6  # Big blind position
        
        # Multiway
        position = my_index / len(self.players)
        return 0.6 + position * 0.4
    
    def _get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if round_state.pot == 0:
            return 0.0
        return to_call / (round_state.pot + to_call)
    
    def _update_opponent_profiles(self, round_state: RoundStateClient):
        """Update opponent play style profiles"""
        for pid, action in round_state.player_actions.items():
            pid_int = int(pid)
            if pid_int == self.id:
                continue
            
            profile = self.opponent_profiles[pid_int]
            profile['hands_played'] += 1
            
            if action in ['Call', 'Raise', 'All-in']:
                profile['hands_voluntarily_put_money'] += 1
            if action in ['Raise', 'All-in']:
                profile['hands_raised'] += 1
                
            if profile['hands_played'] > 0:
                profile['vpip'] = profile['hands_voluntarily_put_money'] / profile['hands_played']
                profile['pfr'] = profile['hands_raised'] / profile['hands_played']
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_bet = round_state.player_bets.get(str(self.id), 0)
        self.total_invested = self.current_bet
        
        if round_state.round == 'Preflop':
            self._update_opponent_profiles(round_state)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0
        
        # Extract hole cards from round state if available
        hole_cards = []
        if hasattr(round_state, 'player_hands') and str(self.id) in round_state.player_hands:
            hole_cards = round_state.player_hands[str(self.id)]
        else:
            # Try to parse from my_hand
            if self.my_hand != "??" and len(self.my_hand) >= 4:
                hole_cards = [self.my_hand[i:i+2] for i in range(0, 4, 2)]
        
        community_cards = round_state.community_cards
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        position_score = self._get_position_score(round_state)
        pot_odds = self._get_pot_odds(round_state, remaining_chips)
        
        # Adjust for opponents
        avg_tightness = 0.5
        active_players = len(round_state.current_player)
        if active_players > 1:
            tight_counts = [p['vpip'] for p in self.opponent_profiles.values()]
            if tight_counts:
                avg_tightness = sum(tight_counts) / len(tight_counts)
        
        # Decision tree
        if round_state.round == 'Preflop':
            return self._preflop_action(hand_strength, to_call, remaining_chips, position_score, active_players)
        else:
            return self._postflop_action(hand_strength, to_call, remaining_chips, community_cards, pot_odds, active_players)
    
    def _preflop_action(self, hand_strength: float, to_call: int, remaining_chips: int, position_score: float, active_players: int) -> Tuple[PokerAction, int]:
        """Pre-flop decision making"""
        min_raise = max(50, to_call * 2) if to_call > 0 else 50
        max_raise = remaining_chips
        
        # Basic pre-flop ranges adjusted for position
        open_range = 0.15 + position_score * 0.1
        three_bet_range = 0.05 + position_score * 0.05
        
        if to_call == 0:
            # First to act or checked to
            if hand_strength >= open_range:
                raise_amount = min(int(self.blind_amount * 3 * (1 + hand_strength * 2)), max_raise)
                return PokerAction.RAISE, max(min_raise, raise_amount)
            else:
                if hand_strength >= 0.3:
                    return PokerAction.RAISE, min_raise
                else:
                    return PokerAction.FOLD, 0
        else:
            # Facing a bet
            pot_odds = to_call / (to_call + self.blind_amount * 4)
            if hand_strength >= pot_odds * 1.5:
                if hand_strength >= three_bet_range and to_call < remaining_chips * 0.1:
                    raise_amount = min(int(to_call * 3), max_raise)
                    return PokerAction.RAISE, max(min_raise, raise_amount)
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
    
    def _postflop_action(self, hand_strength: float, to_call: int, remaining_chips: int, community_cards: List[str], pot_odds: float, active_players: int) -> Tuple[PokerAction, int]:
        """Post-flop decision making"""
        min_raise = max(50, to_call * 2) if to_call > 0 else 50
        max_raise = remaining_chips
        
        # Aggression increases with hand strength
        if hand_strength > 0.8:
            # Strong hand, value betting
            bet_size = min(int(remaining_chips * 0.2 * (hand_strength + 0.5)), max_raise)
            return PokerAction.RAISE, max(min_raise, bet_size)
        elif hand_strength > 0.6:
            # Medium strength
            if to_call == 0:
                bet_size = min(int(remaining_chips * 0.15), max_raise)
                return PokerAction.RAISE, max(min_raise, bet_size)
            else:
                if pot_odds < 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        elif hand_strength > 0.4:
            # Weak hand but possible draw
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                if pot_odds < 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            # Very weak hand
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store round data for analysis
        self.round_history.append({
            'round_num': round_state.round_num,
            'chips': remaining_chips,
            'pot': round_state.pot,
            'round': round_state.round
        })
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game if needed
        self.opponent_profiles = {}
        self.round_history = []