from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 10000
        self.my_chips = 10000
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.player_id = None
        self.round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.my_chips = remaining_chips

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        # Simple hand strength evaluation
        # This is a basic implementation - can be improved with more sophisticated algorithms
        high_card_value = 0
        suit_count = {}
        rank_count = {}
        
        all_cards = hand + community_cards
        
        for card in all_cards:
            if len(card) < 2:
                continue
            rank = card[0]
            suit = card[1]
            
            if rank in ['T', 'J', 'Q', 'K', 'A']:
                rank_value = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank]
            else:
                try:
                    rank_value = int(rank)
                except ValueError:
                    continue
                    
            high_card_value = max(high_card_value, rank_value)
            
            rank_count[rank] = rank_count.get(rank, 0) + 1
            suit_count[suit] = suit_count.get(suit, 0) + 1
        
        # Check for pairs, three of a kind, etc.
        pairs = sum(1 for count in rank_count.values() if count == 2)
        triples = sum(1 for count in rank_count.values() if count == 3)
        fours = sum(1 for count in rank_count.values() if count == 4)
        
        # Basic hand strength calculation
        strength = high_card_value / 14.0  # Normalize high card
        
        if fours > 0:
            strength = 0.95 + (high_card_value / 14.0) * 0.05
        elif triples > 0 and pairs > 0:
            strength = 0.90 + (high_card_value / 14.0) * 0.05
        elif triples > 0:
            strength = 0.80 + (high_card_value / 14.0) * 0.05
        elif pairs >= 2:
            strength = 0.70 + (high_card_value / 14.0) * 0.05
        elif pairs == 1:
            strength = 0.60 + (high_card_value / 14.0) * 0.05
            
        # Check for flush
        if any(count >= 5 for count in suit_count.values()):
            strength = max(strength, 0.85)
            
        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.round_state = round_state
        self.my_chips = remaining_chips
        
        # Get current bet and pot information
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - my_current_bet
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(self.hand, round_state.community_cards)
        
        # Positional awareness
        is_preflop = round_state.round == "Preflop"
        is_blind = (self.id == self.big_blind_player_id) or (self.id == self.small_blind_player_id)
        
        # Aggression factor based on hand strength
        if is_preflop:
            # Preflop strategy
            if hand_strength > 0.7:
                # Strong hand
                if amount_to_call == 0:
                    # We can check or raise
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.1)))
                    return (PokerAction.RAISE, raise_amount)
                elif amount_to_call <= remaining_chips * 0.1:
                    # Reasonable call
                    return (PokerAction.CALL, 0)
                else:
                    # Too expensive to call
                    return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:
                # Medium hand
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif amount_to_call <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Post-flop strategy
            if hand_strength > 0.8:
                # Very strong hand
                if amount_to_call == 0:
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.15)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength > 0.6:
                # Strong hand
                if amount_to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:
                # Medium hand
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif amount_to_call <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass