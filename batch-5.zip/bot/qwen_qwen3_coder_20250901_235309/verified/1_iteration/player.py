import random
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.player_id = None
        self.all_players = []
        self.position = 0  # later assigned as position relative to dealer (0 = dealer, 1 = sb, 2 = bb, etc.)
        self.relative_position = 0
        self.dealer_id = None
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.hand_history = []
        self.is_preflop = True
        
    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """Basic hand strength evaluation using randomization for now"""
        # Placeholder hand strength evaluator
        # In real implementation, integrate with poker hand evaluator library like deuces or phevaluator
        # For now, we will return a random number between 0.0 and 1.0 as placeholder logic
        
        # Example: Simple range-based logic without proper hand evaluator
        ranks = '23456789TJQKA'
        rank_map = {r: i for i, r in enumerate(ranks)}
        
        if not hand:
            return 0.0
            
        h1_rank = hand[0][0]
        h2_rank = hand[1][0]
        h1_suit = hand[0][1]
        h2_suit = hand[1][1]

        # High card values
        high_card_val = max(rank_map[h1_rank], rank_map[h2_rank])
        low_card_val = min(rank_map[h1_rank], rank_map[h2_rank])

        # Pocket pair bonus
        pair_bonus = 0.3 if h1_rank == h2_rank else 0.0

        # Suited bonus
        suited_bonus = 0.1 if h1_suit == h2_suit else 0.0

        # Connectors bonus
        connector_bonus = 0.05 if abs(rank_map[h1_rank] - rank_map[h2_rank]) == 1 else 0.0

        # Base strength = normalized high card + additional bonuses
        base_strength = (high_card_val / 12.0) * 0.5 + 0.2 + pair_bonus + suited_bonus + connector_bonus

        # Post-flop adjustment if available
        if len(community_cards) >= 3:
            # Dummy scoring for post-flop - replace with actual poker hand evaluator
            base_strength += random.uniform(0.0, 0.3)

        return min(1.0, base_strength)

    def get_aggression_factor(self, round_state: RoundStateClient) -> float:
        """Adjust aggression based on position and stack depth"""
        # Conservative early game and aggressive when deep stacked
        aggression = 1.0
        # Aggressive later in tournament
        if round_state.round_num > 200:
            aggression *= 1.2
        # Position-wise aggression boost in late position
        if self.relative_position >= 4:
            aggression *= 1.1
        return aggression

    def calculate_equity(self, hand: List[str], community: List[str], num_opponents: int = 1) -> float:
        """
        Very simplified equity estimator.
        Real bots should use libraries like phevaluator or deuces.
        """
        # For simplicity: return hand strength modified by number of opponents
        raw_strength = self.evaluate_hand_strength(hand, community)
        adjustment = 1.0 - (num_opponents * 0.05)  # assumes equity drops slightly per opponent
        return max(0.0, min(1.0, raw_strength * adjustment))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_bet

            if round_state.round == 'Preflop':
                self.is_preflop = True
                hand_strength = self.evaluate_hand_strength(self.my_hand, [])
            else:
                self.is_preflop = False
                hand_strength = self.calculate_equity(self.my_hand, round_state.community_cards, len(round_state.current_player)-1)

            fold_threshold = 0.3
            call_threshold = 0.5
            raise_threshold = 0.65

            if self.is_preflop:
                # Preflop adjustments
                if self.relative_position <= 2:  # Early position
                    fold_threshold += 0.1
                    call_threshold += 0.1
                    raise_threshold += 0.1
                elif self.relative_position >= 4: # Late position
                    fold_threshold -= 0.05
                    call_threshold -= 0.05
                    raise_threshold -= 0.05

            pot_odds = (to_call / (round_state.pot + to_call + 1e-8)) if to_call > 0 else 0

            # Aggression factor based on position/stack
            af = self.get_aggression_factor(round_state)

            if hand_strength < fold_threshold * (1 - pot_odds) and to_call > 0:
                return (PokerAction.FOLD, 0)

            elif hand_strength < call_threshold or (pot_odds > hand_strength):
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

            elif hand_strength >= raise_threshold:
                bet_size = int(to_call + max(round_state.min_raise, int(0.75 * round_state.pot)) * af)
                if bet_size > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, bet_size)

            else:
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        except Exception:
            return (PokerAction.FOLD, 0)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.all_players = all_players[:]
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-specific data if needed
        if str(self.id) in player_hands:
            self.my_hand = player_hands[str(self.id)]
        else:
            self.my_hand = []

        # Set current round state and determine our position relative to dealer
        active_players = round_state.current_player[:]
        dealer_index = active_players.index(self.dealer_id) if self.dealer_id in active_players else 0
        self.relative_position = (active_players.index(self.id) - dealer_index) % len(active_players)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.hand_history = []