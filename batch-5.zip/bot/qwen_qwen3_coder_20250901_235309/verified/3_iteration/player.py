from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_chips = 10000
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_chips = starting_chips
        self.hole_cards = player_hands
        self.is_big_blind = (big_blind_player_id == self.id)
        self.is_small_blind = (small_blind_player_id == self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get player's current bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # Calculate how much more we need to call
        amount_to_call = round_state.current_bet - my_current_bet
        
        # Check if we can check (no bet to call)
        if amount_to_call == 0:
            # We can check, but let's consider betting/raising sometimes
            if self._should_bet(round_state):
                # Make a reasonable bet
                bet_amount = self._calculate_bet_amount(round_state, remaining_chips)
                if bet_amount > 0 and bet_amount <= remaining_chips:
                    return (PokerAction.RAISE, bet_amount)
            return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            if amount_to_call >= remaining_chips:
                # We can't afford to call, so we must go all-in or fold
                if self._should_call_all_in(round_state):
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # We can afford to call
                if self._should_call(round_state, amount_to_call):
                    # Consider raising instead
                    if self._should_raise(round_state):
                        raise_amount = self._calculate_raise_amount(round_state, remaining_chips, amount_to_call)
                        if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _should_bet(self, round_state) -> bool:
        # Simple strategy: bet sometimes in early rounds when we can check
        if round_state.round == "Preflop":
            return self._hand_strength_preflop() > 0.6
        elif round_state.round == "Flop":
            return random.random() < 0.3
        else:
            return random.random() < 0.2

    def _should_call(self, round_state, amount_to_call) -> bool:
        # Call if amount is small relative to pot or we have good hand
        pot_odds = amount_to_call / (round_state.pot + amount_to_call) if (round_state.pot + amount_to_call) > 0 else 0
        
        if round_state.round == "Preflop":
            hand_strength = self._hand_strength_preflop()
            return hand_strength > 0.4 or pot_odds < 0.3
        else:
            # Simplified decision making for now
            return pot_odds < 0.4 or random.random() < 0.3

    def _should_raise(self, round_state) -> bool:
        if round_state.round == "Preflop":
            return self._hand_strength_preflop() > 0.7
        else:
            return random.random() < 0.2

    def _should_call_all_in(self, round_state) -> bool:
        if round_state.round == "Preflop":
            return self._hand_strength_preflop() > 0.8
        else:
            return random.random() < 0.1

    def _calculate_bet_amount(self, round_state, remaining_chips) -> int:
        # Bet 1/4 to 1/2 of pot size for value betting
        min_bet = round_state.min_raise
        bet_size = max(min_bet, round_state.pot // 4)
        return min(bet_size, remaining_chips)

    def _calculate_raise_amount(self, round_state, remaining_chips, call_amount) -> int:
        # Raise to 2x to 3x the current bet
        raise_multiplier = random.choice([2, 3])
        total_bet = (round_state.current_bet * raise_multiplier)
        raise_amount = total_bet - call_amount  # Amount to add to our call
        return max(round_state.min_raise, raise_amount)

    def _hand_strength_preflop(self) -> float:
        if len(self.hole_cards) < 2:
            return 0.0
            
        card1 = self.hole_cards[0]
        card2 = self.hole_cards[1]
        
        rank1 = card1[0]
        rank2 = card2[0]
        suit1 = card1[1]
        suit2 = card2[1]
        
        # Simplified hand strength calculation
        high_card_value = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        value1 = high_card_value.get(rank1, int(rank1)) if rank1.isdigit() else high_card_value[rank1]
        value2 = high_card_value.get(rank2, int(rank2)) if rank2.isdigit() else high_card_value[rank2]
        
        # Pocket pairs
        if rank1 == rank2:
            if value1 >= 10:  # High pocket pairs
                return 0.9
            elif value1 >= 7:  # Medium pocket pairs
                return 0.7
            else:  # Small pocket pairs
                return 0.5
        
        # High cards
        if value1 >= 12 and value2 >= 12:  # AK, AQ, AJ, KQ, etc.
            return 0.8 if suit1 == suit2 else 0.7  # Suited bonus
        elif value1 >= 10 and value2 >= 10:  # QJ, JT, T9, etc.
            return 0.6 if suit1 == suit2 else 0.5
            
        # Connectors and suited cards
        if abs(value1 - value2) == 1:  # Connectors
            return 0.5 if suit1 == suit2 else 0.4
        elif suit1 == suit2:  # Suited cards
            return 0.4
            
        # Otherwise, weak hand
        return 0.3