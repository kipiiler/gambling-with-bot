from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.player_position = 0
        self.all_players = []
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.hand_history = []
        self.opponent_aggression = {}  # Track how aggressive opponents are
        self.opponent_volatility = {}  # Track how much opponents vary their play
        self.my_aggression = 0  # Track my own aggression level
        self.hand_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.all_players = all_players
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.community_cards[:2] if len(round_state.community_cards) >= 2 else []
        self.hand_count += 1

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not hole_cards:
            return 0.0
            
        # Simplified hand evaluation
        # In a real implementation, this would be much more sophisticated
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        hole_ranks = [card[0] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # High card strength
        high_card_value = max([rank_values.get(rank, 0) for rank in hole_ranks])
        high_card_strength = high_card_value / 14.0
        
        # Pair strength
        pair_bonus = 0.1 if len(hole_cards) == 2 and hole_ranks[0] == hole_ranks[1] else 0
        
        # Connectedness (straight potential)
        connected_bonus = 0
        if len(hole_cards) == 2:
            rank_diff = abs(rank_values.get(hole_ranks[0], 0) - rank_values.get(hole_ranks[1], 0))
            if rank_diff == 1:  # Connected
                connected_bonus = 0.05
            elif rank_diff == 0:  # Pair
                connected_bonus = 0.1
            elif rank_diff == 2:  # One gap
                connected_bonus = 0.03
        
        # Suited bonus
        suited_bonus = 0.05 if len(hole_cards) == 2 and hole_suits[0] == hole_suits[1] else 0
        
        # Base strength with community cards consideration
        base_strength = high_card_strength + pair_bonus + connected_bonus + suited_bonus
        
        # Adjust based on community cards if available
        if community_cards:
            # This is a simplified version - a full implementation would consider draws, etc.
            community_ranks = [card[0] for card in community_cards]
            community_suits = [card[1] for card in community_cards]
            
            # Check for possible made hands
            all_ranks = hole_ranks + community_ranks
            rank_counts = {}
            for rank in all_ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            # Check for pairs, two pairs, sets, etc.
            max_count = max(rank_counts.values()) if rank_counts else 0
            if max_count >= 2:
                base_strength += 0.2 * (max_count - 1)
            
            # Flush draw potential
            all_suits = hole_suits + community_suits
            suit_counts = {}
            for suit in all_suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            if max_suit_count >= 4:  # Flush draw or better
                base_strength += 0.15
        
        return min(1.0, base_strength)

    def _calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        """Calculate pot odds for calling decision"""
        if call_amount <= 0:
            return 1.0
        return pot_size / (pot_size + call_amount)

    def _is_in_position(self, round_state: RoundStateClient) -> bool:
        """Check if we're in position (acting last)"""
        # Simplified position check - in real implementation, this would be more detailed
        return True  # For now, assume we have position advantages

    def _get_opponent_aggression_factor(self, opponent_id: str) -> float:
        """Get opponent's aggression factor (0.0 passive to 1.0 aggressive)"""
        return self.opponent_aggression.get(opponent_id, 0.5)

    def _adjust_for_stack_sizes(self, remaining_chips: int, round_state: RoundStateClient) -> float:
        """Adjust strategy based on stack sizes"""
        # Deep stack - play more conservatively
        if remaining_chips > 5000:
            return 0.8
        # Medium stack - normal play
        elif remaining_chips > 2000:
            return 1.0
        # Short stack - play more aggressively
        else:
            return 1.2

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get basic information
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_bet
            pot_size = round_state.pot
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
            
            # Adjust for stack sizes
            stack_adjustment = self._adjust_for_stack_sizes(remaining_chips, round_state)
            hand_strength *= stack_adjustment
            
            # Calculate pot odds if we need to call
            pot_odds = self._calculate_pot_odds(call_amount, pot_size)
            
            # Determine action based on betting round and hand strength
            if round_state.round == "Preflop":
                return self._preflop_action(round_state, remaining_chips, hand_strength, call_amount, pot_size)
            else:
                return self._postflop_action(round_state, remaining_chips, hand_strength, call_amount, pot_size, pot_odds)
                
        except Exception as e:
            # If anything goes wrong, fold to be safe
            return (PokerAction.FOLD, 0)

    def _preflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, pot_size: int) -> Tuple[PokerAction, int]:
        """Preflop action strategy"""
        # Extract hole cards ranks for simpler evaluation
        ranks = [card[0] for card in self.hole_cards]
        suits = [card[1] for card in self.hole_cards]
        
        is_pair = len(ranks) == 2 and ranks[0] == ranks[1]
        is_suited = len(suits) == 2 and suits[0] == suits[1]
        
        # Premium hands - always raise or reraise
        premium_hands = ['A', 'K']
        if all(rank in premium_hands for rank in ranks):
            if call_amount == 0:
                raise_amount = min(max(round_state.min_raise, pot_size // 3), round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            else:
                # Re-raise significantly
                re_raise_amount = min(max(call_amount * 3, round_state.min_raise), round_state.max_raise)
                if re_raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, re_raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
        
        # Strong hands (pocket pairs 10+, AK, AQ)
        strong_ranks = ['T', 'J', 'Q', 'K', 'A']
        if is_pair and ranks[0] in strong_ranks:
            if call_amount == 0:
                raise_amount = min(max(round_state.min_raise, pot_size // 4), round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.05:  # Small call relative to stack
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands (small-medium pairs, suited connectors)
        medium_ranks = ['7', '8', '9']
        if (is_pair and ranks[0] in medium_ranks) or (is_suited and all(r in strong_ranks + medium_ranks for r in ranks)):
            if call_amount == 0:
                raise_amount = min(max(round_state.min_raise, pot_size // 6), round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.03:  # Very small call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - fold unless very cheap to see flop
        if call_amount <= remaining_chips * 0.01:  # Extremely cheap
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _postflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, pot_size: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Postflop action strategy"""
        # Very strong hand (made hand or strong draw)
        if hand_strength > 0.7:
            if call_amount == 0:
                # Value bet
                bet_amount = min(max(round_state.min_raise, pot_size // 3), round_state.max_raise)
                return (PokerAction.RAISE, bet_amount)
            else:
                # For value or protect hand
                if call_amount <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    # Large bet - proceed with caution
                    if hand_strength > 0.85:
                        return (PokerAction.ALL_IN, 0)  # We're committed
                    else:
                        return (PokerAction.FOLD, 0)
        
        # Decent hand (top pair or good draw)
        elif hand_strength > 0.4:
            if call_amount == 0:
                # Small continuation bet or check
                if pot_odds > 0.3:  # Good pot odds to bet
                    bet_amount = min(max(round_state.min_raise, pot_size // 6), round_state.max_raise)
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Call reasonable bets for pot odds
                if pot_odds > hand_strength:  # Pot odds justify the call
                    if call_amount <= remaining_chips * 0.2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Weak hand
        else:
            if call_amount == 0:
                # Consider bluffing with some frequency
                if random.random() < 0.1 and round_state.round in ["Flop", "Turn"]:
                    bluff_amount = min(max(round_state.min_raise, pot_size // 4), round_state.max_raise)
                    return (PokerAction.RAISE, bluff_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Fold weak hands to bets unless pot odds are excellent
                if pot_odds > 0.7 and call_amount <= remaining_chips * 0.05:  # Very cheap call with good odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round"""
        # Update opponent modeling based on this round's actions
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        # Reset for next game
        self.hand_history = []
        self.opponent_aggression = {}
        self.opponent_volatility = {}