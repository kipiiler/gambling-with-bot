from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.hole_cards = []
        self.game_history = []
        self.opponent_tendencies = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get basic game state
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_bet
            pot_size = round_state.pot
            
            # Calculate position (heads-up)
            is_button = len([p for p in round_state.current_player if p == self.id]) > 0
            
            # Evaluate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds if there's a bet to call
            pot_odds = 0
            if call_amount > 0:
                pot_odds = call_amount / (pot_size + call_amount + 1e-10)
            
            # Determine action based on hand strength and situation
            if hand_strength >= 0.8:  # Very strong hands
                return self._play_premium_hand(round_state, remaining_chips, pot_size)
            elif hand_strength >= 0.6:  # Strong hands
                return self._play_strong_hand(round_state, remaining_chips, pot_size, call_amount)
            elif hand_strength >= 0.4:  # Medium hands
                return self._play_medium_hand(round_state, remaining_chips, pot_size, call_amount, pot_odds)
            elif hand_strength >= 0.25:  # Weak but playable
                return self._play_weak_hand(round_state, remaining_chips, call_amount, pot_odds, is_button)
            else:  # Very weak hands
                return self._play_trash_hand(round_state, call_amount, pot_odds, is_button)
                
        except Exception as e:
            # Emergency fallback
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 20:  # Small call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _play_premium_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_size: int) -> Tuple[PokerAction, int]:
        """Play very strong hands aggressively"""
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_bet
        
        if call_amount == 0:
            # Bet for value
            bet_size = max(pot_size // 2, round_state.min_raise)
            bet_size = min(bet_size, remaining_chips)
            return (PokerAction.RAISE, bet_size)
        else:
            # Raise for value
            raise_size = call_amount + max(pot_size // 3, round_state.min_raise)
            if raise_size <= remaining_chips:
                return (PokerAction.RAISE, raise_size)
            elif call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)

    def _play_strong_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_size: int, call_amount: int) -> Tuple[PokerAction, int]:
        """Play strong hands for value"""
        if call_amount == 0:
            bet_size = max(pot_size // 3, round_state.min_raise)
            bet_size = min(bet_size, remaining_chips)
            return (PokerAction.RAISE, bet_size)
        elif call_amount <= pot_size // 2:  # Good pot odds
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _play_medium_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_size: int, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Play medium hands cautiously but aggressively when appropriate"""
        if call_amount == 0:
            # Sometimes bet for value, sometimes check
            if round_state.round in ['Preflop', 'Flop']:
                bet_size = max(pot_size // 4, round_state.min_raise)
                bet_size = min(bet_size, remaining_chips)
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        elif pot_odds < 0.3 and call_amount <= remaining_chips:  # Good pot odds
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips // 10:  # Small bet
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _play_weak_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_odds: float, is_button: bool) -> Tuple[PokerAction, int]:
        """Play weak hands carefully, fold to pressure"""
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 20 and pot_odds < 0.2:  # Very small bet with good odds
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _play_trash_hand(self, round_state: RoundStateClient, call_amount: int, pot_odds: float, is_button: bool) -> Tuple[PokerAction, int]:
        """Play trash hands - mostly fold unless great pot odds"""
        if call_amount == 0:
            if round_state.round == 'Preflop' and is_button:
                # Occasional bluff from button
                bet_size = round_state.min_raise
                return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        elif pot_odds < 0.15:  # Excellent pot odds
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        hole_ranks = [self._card_rank(card) for card in self.hole_cards]
        hole_suits = [self._card_suit(card) for card in self.hole_cards]
        
        # Preflop evaluation
        if round_state.round == 'Preflop':
            return self._evaluate_preflop_strength(hole_ranks, hole_suits)
        
        # Post-flop evaluation
        all_cards = self.hole_cards + round_state.community_cards
        hand_type, _ = self._get_best_hand(all_cards)
        
        # Convert hand type to strength
        hand_strengths = {
            'royal_flush': 1.0,
            'straight_flush': 0.95,
            'four_of_a_kind': 0.9,
            'full_house': 0.85,
            'flush': 0.75,
            'straight': 0.65,
            'three_of_a_kind': 0.55,
            'two_pair': 0.45,
            'one_pair': 0.35,
            'high_card': 0.15
        }
        
        base_strength = hand_strengths.get(hand_type, 0.1)
        
        # Adjust based on community cards and draws
        if round_state.round in ['Flop', 'Turn']:
            base_strength += self._evaluate_draws(all_cards, round_state.community_cards) * 0.1
        
        return min(base_strength, 1.0)

    def _evaluate_preflop_strength(self, ranks: List[int], suits: List[str]) -> float:
        """Evaluate preflop hand strength"""
        rank1, rank2 = ranks[0], ranks[1]
        suited = suits[0] == suits[1]
        
        # Premium pairs
        if rank1 == rank2:
            if rank1 >= 11:  # AA, KK, QQ
                return 0.9
            elif rank1 >= 8:  # JJ, TT, 99, 88
                return 0.75
            elif rank1 >= 5:  # 77, 66, 55
                return 0.6
            else:  # Small pairs
                return 0.45
        
        # High cards
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        if high_rank == 14:  # Ace
            if low_rank >= 11:  # AK, AQ
                return 0.85 if suited else 0.8
            elif low_rank >= 9:  # AJ, AT
                return 0.7 if suited else 0.6
            elif low_rank >= 6:  # A9-A6
                return 0.55 if suited else 0.4
            else:  # A5-A2
                return 0.5 if suited else 0.3
        
        elif high_rank >= 12:  # King or Queen high
            if low_rank >= 10:  # KQ, KJ, QJ
                return 0.7 if suited else 0.6
            elif low_rank >= 8:  # KT, K9, QT, Q9
                return 0.55 if suited else 0.4
            else:
                return 0.35 if suited else 0.25
        
        elif high_rank >= 10:  # Jack or Ten high
            if abs(rank1 - rank2) <= 1:  # Connected
                return 0.5 if suited else 0.35
            else:
                return 0.3 if suited else 0.2
        
        # Suited connectors and gappers
        if suited and abs(rank1 - rank2) <= 3:
            return 0.4
        
        return 0.15

    def _evaluate_draws(self, all_cards: List[str], community: List[str]) -> float:
        """Evaluate drawing potential"""
        if len(community) < 3:
            return 0
            
        suits = [self._card_suit(card) for card in all_cards]
        ranks = [self._card_rank(card) for card in all_cards]
        
        draw_value = 0
        
        # Flush draw
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        if max(suit_counts.values()) == 4:  # Flush draw
            draw_value += 0.3
        
        # Straight draw
        unique_ranks = list(set(ranks))
        unique_ranks.sort()
        
        for i in range(len(unique_ranks) - 3):
            consecutive = 1
            for j in range(i + 1, len(unique_ranks)):
                if unique_ranks[j] == unique_ranks[j-1] + 1:
                    consecutive += 1
                else:
                    break
            if consecutive >= 4:  # Open-ended straight draw
                draw_value += 0.25
                break
        
        return draw_value

    def _get_best_hand(self, cards: List[str]) -> Tuple[str, List[str]]:
        """Get the best 5-card hand from available cards"""
        if len(cards) < 5:
            return 'high_card', cards
            
        ranks = [self._card_rank(card) for card in cards]
        suits = [self._card_suit(card) for card in cards]
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        straight_high = 0
        
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i + 4] == 4:
                    is_straight = True
                    straight_high = unique_ranks[i]
                    break
        
        # Check for A-2-3-4-5 straight (wheel)
        if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
            is_straight = True
            straight_high = 5
        
        # Determine hand type
        counts = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            if straight_high == 14:
                return 'royal_flush', cards
            return 'straight_flush', cards
        elif counts[0] == 4:
            return 'four_of_a_kind', cards
        elif counts[0] == 3 and counts[1] == 2:
            return 'full_house', cards
        elif is_flush:
            return 'flush', cards
        elif is_straight:
            return 'straight', cards
        elif counts[0] == 3:
            return 'three_of_a_kind', cards
        elif counts[0] == 2 and counts[1] == 2:
            return 'two_pair', cards
        elif counts[0] == 2:
            return 'one_pair', cards
        else:
            return 'high_card', cards

    def _card_rank(self, card: str) -> int:
        """Convert card rank to number (2=2, ..., T=10, J=11, Q=12, K=13, A=14)"""
        rank = card[0]
        if rank == 'T':
            return 10
        elif rank == 'J':
            return 11
        elif rank == 'Q':
            return 12
        elif rank == 'K':
            return 13
        elif rank == 'A':
            return 14
        else:
            return int(rank)

    def _card_suit(self, card: str) -> str:
        """Get card suit"""
        return card[1]

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass