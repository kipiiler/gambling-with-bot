from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = None
        self.opponent_stats = {}
        self.game_count = 0
        self.aggressive_factor = 1.2

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[str(player_id)] = {
                    'aggression': 0.5,
                    'vpip': 0.3,
                    'fold_to_raise': 0.6,
                    'hands_seen': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.round_state = round_state

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update stats
            self._update_opponent_stats(round_state)
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Determine position advantage
            position_factor = self._get_position_factor(round_state)
            
            # Calculate opponent aggression
            opponent_aggression = self._estimate_opponent_aggression(round_state)
            
            # Main decision logic
            current_bet_needed = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            
            # Strong hands - be aggressive
            if hand_strength >= 0.8:
                if current_bet_needed == 0:
                    # Bet for value
                    bet_size = max(round_state.min_raise, int(round_state.pot * 0.7))
                    bet_size = min(bet_size, remaining_chips)
                    return (PokerAction.RAISE, bet_size)
                elif current_bet_needed < remaining_chips * 0.3:
                    # Raise with strong hands
                    raise_size = max(round_state.min_raise, current_bet_needed * 2 + round_state.player_bets.get(str(self.id), 0))
                    raise_size = min(raise_size, remaining_chips)
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            
            # Good hands with position
            elif hand_strength >= 0.6:
                if current_bet_needed == 0:
                    if position_factor > 0.5:  # Good position
                        bet_size = max(round_state.min_raise, int(round_state.pot * 0.5))
                        bet_size = min(bet_size, remaining_chips)
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                elif current_bet_needed <= remaining_chips * 0.15:
                    return (PokerAction.CALL, 0)
                elif position_factor > 0.7 and opponent_aggression < 0.6:
                    # Bluff raise in good position against passive opponents
                    raise_size = max(round_state.min_raise, current_bet_needed * 1.5 + round_state.player_bets.get(str(self.id), 0))
                    raise_size = min(raise_size, remaining_chips)
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Mediocre hands
            elif hand_strength >= 0.35:
                if current_bet_needed == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds > 3.0 and current_bet_needed <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Weak hands - mostly fold, sometimes bluff
            else:
                if current_bet_needed == 0:
                    if position_factor > 0.8 and opponent_aggression < 0.4 and round_state.round == "Preflop":
                        # Occasional bluff from good position
                        bet_size = max(round_state.min_raise, int(round_state.pot * 0.6))
                        bet_size = min(bet_size, remaining_chips)
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception:
            # Safe fallback
            current_bet_needed = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            if current_bet_needed == 0:
                return (PokerAction.CHECK, 0)
            elif current_bet_needed <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate current hand strength"""
        try:
            if not self.hole_cards or len(self.hole_cards) < 2:
                return 0.3
            
            card1, card2 = self.hole_cards[0], self.hole_cards[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Convert face cards
            rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
            val1 = rank_values.get(rank1, int(rank1))
            val2 = rank_values.get(rank2, int(rank2))
            
            # Base strength from hole cards
            if val1 == val2:  # Pair
                if val1 >= 10:
                    strength = 0.85
                elif val1 >= 7:
                    strength = 0.65
                else:
                    strength = 0.45
            elif suit1 == suit2:  # Suited
                if abs(val1 - val2) <= 4:
                    strength = 0.6
                else:
                    strength = 0.4
            else:  # Offsuit
                high_card = max(val1, val2)
                if high_card >= 12:
                    strength = 0.5
                elif high_card >= 10:
                    strength = 0.35
                else:
                    strength = 0.25
            
            # Adjust based on community cards
            if round_state.community_cards:
                strength = self._evaluate_with_community(strength, round_state.community_cards)
            
            return min(1.0, max(0.0, strength))
            
        except Exception:
            return 0.3

    def _evaluate_with_community(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust strength based on community cards"""
        try:
            all_cards = self.hole_cards + community_cards
            if len(all_cards) < 5:
                return base_strength
            
            # Simple evaluation - look for pairs, straights, flushes
            ranks = []
            suits = []
            
            rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
            
            for card in all_cards:
                rank = card[0]
                suit = card[1]
                ranks.append(rank_values.get(rank, int(rank)))
                suits.append(suit)
            
            rank_counts = {}
            suit_counts = {}
            
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            # Check for strong hands
            if max(rank_counts.values()) >= 3:  # Three of a kind or better
                return 0.9
            elif max(suit_counts.values()) >= 5:  # Flush
                return 0.85
            elif len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Two pair or full house
                return 0.75
            elif max(rank_counts.values()) >= 2:  # Pair
                return max(base_strength, 0.6)
            
            return base_strength
            
        except Exception:
            return base_strength

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        try:
            current_bet_needed = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            if current_bet_needed <= 0:
                return 10.0
            return round_state.pot / (current_bet_needed + 0.01)
        except Exception:
            return 2.0

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage (0-1, higher is better)"""
        try:
            if len(self.all_players) <= 2:
                # Heads up - big blind is last to act except preflop
                if round_state.round == "Preflop":
                    return 0.8 if self.id != self.big_blind_player else 0.2
                else:
                    return 0.8 if self.id == self.big_blind_player else 0.2
            return 0.5  # Default for multi-way
        except Exception:
            return 0.5

    def _estimate_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Estimate opponent aggression level"""
        try:
            total_aggression = 0
            count = 0
            
            for player_id, stats in self.opponent_stats.items():
                if player_id in round_state.player_actions:
                    action = round_state.player_actions[player_id]
                    if action in ['Raise', 'All-in']:
                        total_aggression += 1.0
                    elif action == 'Call':
                        total_aggression += 0.5
                    count += 1
            
            if count > 0:
                return total_aggression / count
            return 0.5
        except Exception:
            return 0.5

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        try:
            for player_id, action in round_state.player_actions.items():
                if player_id != str(self.id) and player_id in self.opponent_stats:
                    stats = self.opponent_stats[player_id]
                    stats['hands_seen'] += 1
                    
                    if action in ['Raise', 'All-in']:
                        stats['aggression'] = min(1.0, stats['aggression'] * 0.9 + 0.2)
                    elif action == 'Fold':
                        stats['fold_to_raise'] = min(1.0, stats['fold_to_raise'] * 0.9 + 0.1)
        except Exception:
            pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.game_count += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Adjust strategy based on performance
        if player_score < 0:
            self.aggressive_factor = min(1.5, self.aggressive_factor + 0.05)
        else:
            self.aggressive_factor = max(0.8, self.aggressive_factor - 0.02)