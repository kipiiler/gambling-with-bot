from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.opponent_stats = {}
        self.position_stats = {}
        self.round_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'folds': 0,
                    'calls': 0,
                    'raises': 0,
                    'all_ins': 0,
                    'vpip': 0.0,  # Voluntarily put money in pot
                    'pfr': 0.0,   # Pre-flop raise
                    'aggression': 0.0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Calculate position advantage
        position_factor = self._calculate_position_factor(round_state)
        
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Determine action based on strategy
        action, amount = self._determine_action(round_state, remaining_chips, hand_strength, position_factor, pot_odds)
        
        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store round information for learning
        self.round_history.append({
            'round_state': round_state,
            'final_chips': remaining_chips
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate the strength of current hand"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.0
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        # Pre-flop hand strength
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(card1, card2)
        
        # Post-flop hand strength
        all_cards = self.hole_cards + round_state.community_cards
        return self._postflop_hand_strength(all_cards)

    def _preflop_hand_strength(self, card1: str, card2: str) -> float:
        """Calculate pre-flop hand strength"""
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        val1, val2 = rank_values.get(rank1, 0), rank_values.get(rank2, 0)
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # TT, JJ, QQ, KK, AA
                return 0.9
            elif val1 >= 7:  # 77, 88, 99
                return 0.7
            else:  # 22-66
                return 0.5
        
        # Suited cards
        if suit1 == suit2:
            if (val1 == 14 and val2 >= 10) or (val2 == 14 and val1 >= 10):  # AK, AQ, AJ, AT suited
                return 0.8
            elif max(val1, val2) >= 10:  # High suited cards
                return 0.6
            else:
                return 0.4
        
        # Offsuit cards
        if (val1 == 14 and val2 >= 12) or (val2 == 14 and val1 >= 12):  # AK, AQ offsuit
            return 0.7
        elif max(val1, val2) >= 11 and min(val1, val2) >= 10:  # Broadway cards
            return 0.5
        else:
            return 0.2

    def _postflop_hand_strength(self, all_cards: List[str]) -> float:
        """Calculate post-flop hand strength"""
        if len(all_cards) < 5:
            return 0.3
            
        # Simple hand evaluation - looking for pairs, straights, flushes, etc.
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush
        has_flush = any(count >= 5 for count in suit_counts.values())
        if has_flush:
            return 0.9
        
        # Check for pairs, trips, quads
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        if max_rank_count >= 4:  # Four of a kind
            return 0.95
        elif max_rank_count >= 3:  # Three of a kind
            pair_count = sum(1 for count in rank_counts.values() if count >= 2)
            if pair_count >= 2:  # Full house
                return 0.9
            else:  # Trips
                return 0.7
        elif max_rank_count >= 2:  # Pair
            pair_count = sum(1 for count in rank_counts.values() if count >= 2)
            if pair_count >= 2:  # Two pair
                return 0.6
            else:  # One pair
                return 0.4
        
        # Check for straight possibility
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        values = sorted([rank_values.get(rank, 0) for rank in set(ranks)])
        
        # Check for straight
        for i in range(len(values) - 4):
            if values[i+4] - values[i] == 4:
                return 0.8
        
        # High card
        return 0.2

    def _calculate_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor"""
        if not self.all_players:
            return 1.0
            
        # In heads-up, being last to act is better
        if len(self.all_players) == 2:
            return 1.2 if self.id != self.big_blind_player_id else 0.8
        
        # In multi-way, later position is generally better
        try:
            my_position = self.all_players.index(self.id)
            total_players = len(self.all_players)
            return 0.8 + (my_position / (total_players - 1 + 1e-6)) * 0.4
        except (ValueError, ZeroDivisionError):
            return 1.0

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        if call_amount <= 0:
            return float('inf')
        
        pot_size = round_state.pot + call_amount
        if pot_size <= 0:
            return 0.0
            
        return pot_size / (call_amount + 1e-6)

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update statistics for opponent modeling"""
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id != self.id and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                stats['hands_played'] += 1
                
                if action == 'Fold':
                    stats['folds'] += 1
                elif action == 'Call':
                    stats['calls'] += 1
                elif action == 'Raise':
                    stats['raises'] += 1
                elif action == 'All_in':
                    stats['all_ins'] += 1
                
                # Update ratios
                total_actions = stats['hands_played']
                if total_actions > 0:
                    stats['vpip'] = (stats['calls'] + stats['raises'] + stats['all_ins']) / total_actions
                    stats['pfr'] = stats['raises'] / total_actions
                    stats['aggression'] = (stats['raises'] + stats['all_ins']) / (total_actions + 1e-6)

    def _get_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Get average opponent aggression level"""
        total_aggression = 0.0
        active_opponents = 0
        
        for player_id in round_state.current_player:
            if player_id != self.id and player_id in self.opponent_stats:
                total_aggression += self.opponent_stats[player_id]['aggression']
                active_opponents += 1
        
        return total_aggression / (active_opponents + 1e-6)

    def _determine_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_factor: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Determine the best action based on all factors"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        # Adjust hand strength based on position and opponent aggression
        opponent_aggression = self._get_opponent_aggression(round_state)
        adjusted_strength = hand_strength * position_factor * (1.0 - opponent_aggression * 0.2)
        
        # Emergency fold if hand is very weak
        if adjusted_strength < 0.15 and call_amount > 0:
            return PokerAction.FOLD, 0
        
        # All-in with very strong hands
        if adjusted_strength > 0.85 and call_amount > 0:
            return PokerAction.ALL_IN, 0
        
        # No bet to call - check or bet
        if call_amount == 0:
            if adjusted_strength > 0.6:
                # Bet for value or as bluff
                bet_size = min(int(round_state.pot * 0.7), remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
            return PokerAction.CHECK, 0
        
        # There's a bet to call
        # Calculate if call is profitable based on pot odds and hand strength
        pot_odds_ratio = pot_odds
        required_equity = 1.0 / (pot_odds_ratio + 1.0 + 1e-6)
        
        if adjusted_strength > required_equity * 1.2:
            # Strong enough to call or raise
            if adjusted_strength > 0.7 and remaining_chips > call_amount * 2:
                # Raise with strong hands
                raise_size = min(int(call_amount + round_state.pot * 0.5), remaining_chips, round_state.max_raise)
                if raise_size >= round_state.min_raise:
                    return PokerAction.RAISE, raise_size
            
            # Call
            if call_amount <= remaining_chips:
                return PokerAction.CALL, 0
        
        # Bluff occasionally with weak hands in good position
        if position_factor > 1.1 and adjusted_strength < 0.3 and random.random() < 0.1:
            if call_amount == 0:
                bet_size = min(int(round_state.pot * 0.6), remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
        
        # Default action when not strong enough
        if call_amount == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0