from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0
        self.all_players = []
        self.opponent_tendencies = {}
        self.games_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.all_players = all_players
        self.games_played += 1
        
        # Store opponent info
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_tendencies:
                self.opponent_tendencies[player_id] = {
                    'raises': 0, 'calls': 0, 'folds': 0, 'checks': 0,
                    'total_actions': 0, 'aggression': 0.0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update opponent tendencies
            self._update_opponent_tendencies(round_state)
            
            # Get hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate position advantage (heads up)
            num_active_players = len([p for p in round_state.current_player])
            
            # Calculate pot odds if we need to call
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = call_amount / (round_state.pot + call_amount + 1e-9)
            
            # Calculate bet sizing
            pot_size = round_state.pot
            
            # Get bluff frequency and aggression
            bluff_freq = self._get_bluff_frequency(round_state, remaining_chips)
            should_bluff = self._should_bluff(round_state, hand_strength)
            
            # Preflop strategy
            if round_state.round == "Preflop":
                return self._preflop_strategy(round_state, remaining_chips, hand_strength, call_amount, pot_odds)
            
            # Postflop strategy
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, call_amount, pot_odds, should_bluff)
            
        except Exception as e:
            # Emergency fallback
            if round_state.current_bet > round_state.player_bets.get(str(self.id), 0):
                if remaining_chips <= round_state.current_bet:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.FOLD, 0)
            return (PokerAction.CHECK, 0)

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        pot_size = round_state.pot
        
        # Premium hands (AA, KK, QQ, AK)
        if hand_strength >= 0.85:
            if round_state.current_bet == 0:
                bet_size = max(round_state.min_raise, min(pot_size, remaining_chips // 3))
                return (PokerAction.RAISE, bet_size)
            elif call_amount < remaining_chips // 2:
                raise_size = max(round_state.min_raise, min(pot_size * 2, remaining_chips // 2))
                if raise_size <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
        
        # Strong hands (JJ, AQ, AJ, KQ)
        elif hand_strength >= 0.7:
            if round_state.current_bet == 0:
                bet_size = max(round_state.min_raise, min(pot_size // 2, remaining_chips // 4))
                return (PokerAction.RAISE, bet_size)
            elif call_amount <= pot_size and call_amount < remaining_chips // 3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Decent hands (medium pairs, suited connectors)
        elif hand_strength >= 0.5:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= pot_size // 2 and call_amount < remaining_chips // 5:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, pot_odds: float, should_bluff: bool) -> Tuple[PokerAction, int]:
        pot_size = round_state.pot
        
        # Very strong hands
        if hand_strength >= 0.8:
            if round_state.current_bet == 0:
                bet_size = max(round_state.min_raise, min(pot_size, remaining_chips // 2))
                return (PokerAction.RAISE, bet_size)
            else:
                raise_size = max(round_state.min_raise, min(pot_size * 2, remaining_chips // 2))
                if raise_size <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.65:
            if round_state.current_bet == 0:
                bet_size = max(round_state.min_raise, min(pot_size * 2 // 3, remaining_chips // 3))
                return (PokerAction.RAISE, bet_size)
            elif call_amount <= pot_size:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.4:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3 and call_amount < pot_size // 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - bluff or fold
        else:
            if should_bluff and round_state.current_bet == 0:
                bluff_size = max(round_state.min_raise, min(pot_size // 2, remaining_chips // 4))
                return (PokerAction.RAISE, bluff_size)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not hasattr(self, 'hole_cards') or len(self.hole_cards) != 2:
            return 0.3
        
        community_cards = round_state.community_cards
        all_cards = self.hole_cards + community_cards
        
        if round_state.round == "Preflop":
            return self._preflop_hand_strength()
        else:
            return self._postflop_hand_strength(all_cards)

    def _preflop_hand_strength(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.3
        
        card1, card2 = self.hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        val1 = rank_values.get(rank1, int(rank1))
        val2 = rank_values.get(rank2, int(rank2))
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = suit1 == suit2
        is_pair = val1 == val2
        
        # Premium hands
        if is_pair and high_card >= 10:
            return 0.85 + (high_card - 10) * 0.03
        
        # High cards
        if high_card == 14:  # Ace
            if low_card >= 10:
                return 0.75 + (low_card - 10) * 0.05
            elif low_card >= 7:
                return 0.55 + (low_card - 7) * 0.03
            else:
                return 0.45 + (low_card - 2) * 0.02
        
        if high_card == 13:  # King
            if low_card >= 10:
                return 0.65 + (low_card - 10) * 0.03
            elif low_card >= 8:
                return 0.45 + (low_card - 8) * 0.04
            else:
                return 0.25 + (low_card - 2) * 0.02
        
        # Pairs
        if is_pair:
            return 0.5 + (high_card - 2) * 0.03
        
        # Suited connectors
        if is_suited and abs(val1 - val2) <= 1:
            return 0.55 + (high_card - 7) * 0.02
        
        # Suited cards
        if is_suited:
            return 0.35 + (high_card - 2) * 0.015
        
        # Connected cards
        if abs(val1 - val2) <= 1:
            return 0.3 + (high_card - 2) * 0.01
        
        return 0.15 + (high_card - 2) * 0.01

    def _postflop_hand_strength(self, all_cards: List[str]) -> float:
        if len(all_cards) < 5:
            return 0.3
        
        # Basic hand evaluation
        ranks = []
        suits = []
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            val = rank_values.get(rank, int(rank))
            ranks.append(val)
            suits.append(suit)
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        sorted_ranks = sorted(ranks, reverse=True)
        sorted_counts = sorted(rank_counts.values(), reverse=True)
        
        # Check for flush
        has_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        has_straight = self._check_straight(sorted_ranks)
        
        # Evaluate hand
        if has_straight and has_flush:
            return 0.95
        elif sorted_counts[0] == 4:  # Four of a kind
            return 0.92
        elif sorted_counts[0] == 3 and sorted_counts[1] == 2:  # Full house
            return 0.88
        elif has_flush:
            return 0.82
        elif has_straight:
            return 0.75
        elif sorted_counts[0] == 3:  # Three of a kind
            return 0.68
        elif sorted_counts[0] == 2 and sorted_counts[1] == 2:  # Two pair
            return 0.55
        elif sorted_counts[0] == 2:  # One pair
            pair_rank = max([rank for rank, count in rank_counts.items() if count == 2])
            return 0.35 + (pair_rank - 2) * 0.015
        else:  # High card
            return 0.15 + (max(ranks) - 2) * 0.01

    def _check_straight(self, sorted_ranks: List[int]) -> bool:
        unique_ranks = sorted(list(set(sorted_ranks)), reverse=True)
        
        if len(unique_ranks) < 5:
            return False
        
        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i + 4] == 4:
                return True
        
        # Check for A-2-3-4-5 straight
        if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
            return True
        
        return False

    def _should_bluff(self, round_state: RoundStateClient, hand_strength: float) -> bool:
        if hand_strength > 0.4:
            return False
        
        # More likely to bluff on later streets
        bluff_frequencies = {"Preflop": 0.05, "Flop": 0.15, "Turn": 0.20, "River": 0.25}
        base_freq = bluff_frequencies.get(round_state.round, 0.1)
        
        # Bluff more against tight players
        import random
        return random.random() < base_freq

    def _get_bluff_frequency(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        base_freq = 0.15
        
        # Bluff more when deeper stacked
        if remaining_chips > self.starting_chips // 2:
            base_freq *= 1.5
        
        return min(base_freq, 0.3)

    def _update_opponent_tendencies(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and int(player_id) in self.opponent_tendencies:
                tendencies = self.opponent_tendencies[int(player_id)]
                tendencies['total_actions'] += 1
                
                if action.lower() in ['raise', 'all_in']:
                    tendencies['raises'] += 1
                elif action.lower() == 'call':
                    tendencies['calls'] += 1
                elif action.lower() == 'fold':
                    tendencies['folds'] += 1
                elif action.lower() == 'check':
                    tendencies['checks'] += 1
                
                # Calculate aggression factor
                if tendencies['total_actions'] > 0:
                    tendencies['aggression'] = (tendencies['raises'] + tendencies['calls']) / (tendencies['total_actions'] + 1e-9)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Learn from revealed hands
        if active_players_hands:
            for player_id, hand in active_players_hands.items():
                if int(player_id) != self.id and len(hand) == 2:
                    self.hole_cards = hand  # Store for analysis