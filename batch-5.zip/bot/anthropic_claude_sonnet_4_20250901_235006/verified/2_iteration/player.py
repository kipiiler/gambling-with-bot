from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = None
        self.num_players = 0
        self.big_blind_amount = 0
        self.hands_played = 0
        self.wins = 0
        self.opponent_aggression = 0.5  # Track opponent aggression level
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.big_blind_amount = blind_amount
        # Determine position based on blind assignments
        if self.id == big_blind_player_id:
            self.position = "BB"
        elif self.id == small_blind_player_id:
            self.position = "SB"
        else:
            self.position = "BUTTON"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == "Preflop":
            self.hands_played += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get pot odds and betting information
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Update opponent aggression tracking
        self._update_opponent_aggression(round_state)
        
        # Determine action based on round and hand strength
        if round_state.round == "Preflop":
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.0
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        if round_state.round == "Preflop":
            return self._preflop_hand_strength(card1, card2)
        else:
            return self._postflop_hand_strength(round_state.community_cards)

    def _preflop_hand_strength(self, card1: str, card2: str) -> float:
        """Evaluate preflop hand strength"""
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
                      'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values[rank1], rank_values[rank2]
        is_suited = suit1 == suit2
        is_pair = val1 == val2
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Premium hands
        if is_pair and val1 >= 10:  # TT+
            return 0.9 + (val1 - 10) * 0.02
        if val1 == 14 and val2 >= 10:  # AK, AQ, AJ, AT
            return 0.8 + (val2 - 10) * 0.02 + (0.05 if is_suited else 0)
        if val1 == 13 and val2 >= 11:  # KQ, KJ
            return 0.75 + (val2 - 11) * 0.02 + (0.05 if is_suited else 0)
            
        # Medium pairs
        if is_pair and val1 >= 6:
            return 0.55 + (val1 - 6) * 0.05
            
        # Suited connectors and one-gappers
        if is_suited and abs(val1 - val2) <= 2 and high_card >= 8:
            return 0.45 + (high_card - 8) * 0.02
            
        # Broadway cards
        if high_card >= 10 and low_card >= 9:
            return 0.4 + (high_card - 10) * 0.02
            
        # Ace with mid card
        if high_card == 14 and low_card >= 7:
            return 0.3 + (low_card - 7) * 0.02
            
        return 0.1 + (high_card + low_card) * 0.01

    def _postflop_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if not community_cards:
            return 0.0
            
        all_cards = self.hole_cards + community_cards
        return self._evaluate_five_card_hand(all_cards)

    def _evaluate_five_card_hand(self, cards: List[str]) -> float:
        """Simplified hand evaluation for 5+ cards"""
        if len(cards) < 5:
            # For flop/turn, estimate based on pairs and high cards
            ranks = [self._card_rank(card) for card in cards]
            suits = [card[1] for card in cards]
            
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            # Check for pairs, trips, etc.
            if 4 in rank_counts.values():
                return 0.95
            if 3 in rank_counts.values():
                if 2 in rank_counts.values():
                    return 0.9  # Full house
                return 0.7  # Three of a kind
            if list(rank_counts.values()).count(2) == 2:
                return 0.65  # Two pair
            if 2 in rank_counts.values():
                pair_rank = [k for k, v in rank_counts.items() if v == 2][0]
                return 0.4 + pair_rank * 0.01  # Pair
                
            # Check for flush/straight draws
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            if max(suit_counts.values()) >= 4:
                return 0.35  # Flush draw
                
            return 0.1 + max(ranks) * 0.01  # High card
            
        # For river, more complete evaluation would go here
        return 0.3

    def _card_rank(self, card: str) -> int:
        """Convert card rank to numeric value"""
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
                      'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values[card[0]]

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return float('inf')
        pot_after_call = round_state.pot + call_amount
        return pot_after_call / (call_amount + 0.01)  # Add small epsilon

    def _update_opponent_aggression(self, round_state: RoundStateClient):
        """Track opponent aggression based on their actions"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression = min(1.0, self.opponent_aggression + 0.1)
                elif action in ['Call']:
                    self.opponent_aggression = max(0.0, self.opponent_aggression - 0.02)

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Premium hands - always play aggressively
        if hand_strength >= 0.85:
            if round_state.current_bet == 0:
                raise_amount = max(round_state.min_raise, self.big_blind_amount * 3)
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            elif call_amount <= remaining_chips * 0.3:
                raise_amount = max(round_state.min_raise, round_state.current_bet * 2)
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            else:
                return (PokerAction.CALL, 0)
                
        # Strong hands
        elif hand_strength >= 0.7:
            if round_state.current_bet == 0:
                raise_amount = max(round_state.min_raise, self.big_blind_amount * 2)
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            elif call_amount <= remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Medium hands
        elif hand_strength >= 0.5:
            if round_state.current_bet == 0:
                if self.position == "BUTTON":  # More aggressive on button
                    raise_amount = max(round_state.min_raise, self.big_blind_amount * 2)
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= self.big_blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.big_blind_amount and pot_odds > 5:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Very strong hands
        if hand_strength >= 0.8:
            if round_state.current_bet == 0:
                bet_amount = max(round_state.min_raise, round_state.pot // 2)
                return (PokerAction.RAISE, min(bet_amount, remaining_chips))
            else:
                raise_amount = max(round_state.min_raise, round_state.current_bet * 2)
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                
        # Strong hands
        elif hand_strength >= 0.65:
            if round_state.current_bet == 0:
                bet_amount = max(round_state.min_raise, round_state.pot // 3)
                return (PokerAction.RAISE, min(bet_amount, remaining_chips))
            elif call_amount <= remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Medium hands
        elif hand_strength >= 0.4:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds > 3 and call_amount <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands with draws
        elif hand_strength >= 0.25:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds > 4 and call_amount <= self.big_blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Very weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        if player_score > 0:
            self.wins += 1