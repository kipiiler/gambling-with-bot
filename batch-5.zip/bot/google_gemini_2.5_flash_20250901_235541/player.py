import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Import PokerRound from the same module as PokerAction
from type.poker_action import PokerRound

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []

        # Hand strength calculation parameters
        self.strength_preflop_raise_threshold = 0.7  # Top 30% hands for preflop raise
        self.strength_preflop_call_threshold = 0.5   # Top 50% hands for preflop call
        self.strength_postflop_raise_threshold = 0.6 # Top 40% hands for postflop raise
        self.strength_postflop_call_threshold = 0.3  # Top 70% hands for postflop call

        # Aggression parameters
        self.aggression_factor = 1.0 # 0.5 (passive) to 2.0 (aggressive)
        self.bluff_probability = 0.05 # Small chance to bluff
        self.value_bet_sizing = 0.7 # Percentage of pot to bet for value

        # Tracking opponents
        self.opponent_actions = {} # Stores opponent tendencies, e.g., {'player_id': {'fold_count': X, 'call_count': Y, 'raise_count': Z}}
        self.num_opponents_active = 0


    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_id = self.id # Use the id set by the parent Bot class
        self.opponent_actions = {}
        for player_id in all_players:
            if player_id != self.player_id:
                self.opponent_actions[player_id] = {'fold_count': 0, 'call_count': 0, 'raise_count': 0, 'total_actions': 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards if they are available (they are only passed once at on_start)
        # However, for simplicity and to prevent issues if not all info is passed, assume hole_cards is consistent.
        # Player's own cards are not in round_state, only community cards.
        # This method is called at the start of *each* betting round (pre-flop, flop, etc.)
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.num_opponents_active = len(round_state.current_player) -1 # exclude self
        
        # Determine the current bet for this player
        my_current_bet_in_round = round_state.player_bets.get(str(self.player_id), 0)
        current_call_amount = round_state.current_bet - my_current_bet_in_round
        
        # Ensure minimum raise is respected
        min_raise_amount = round_state.min_raise
        max_raise_amount = remaining_chips + my_current_bet_in_round # Max raise is all remaining chips + what's already bet

        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic strategy based on current round and hand strength
        if round_state.round == PokerRound.PREFLOP.name:
            return self._preflop_strategy(hand_strength, current_call_amount, remaining_chips, min_raise_amount, max_raise_amount, round_state.pot)
        elif round_state.round == PokerRound.FLOP.name:
            return self._postflop_strategy(hand_strength, current_call_amount, remaining_chips, min_raise_amount, max_raise_amount, round_state.pot, round_state.community_cards)
        elif round_state.round == PokerRound.TURN.name:
            return self._postflop_strategy(hand_strength, current_call_amount, remaining_chips, min_raise_amount, max_raise_amount, round_state.pot, round_state.community_cards)
        elif round_state.round == PokerRound.RIVER.name:
            return self._postflop_strategy(hand_strength, current_call_amount, remaining_chips, min_raise_amount, max_raise_amount, round_state.pot, round_state.community_cards)

        return PokerAction.FOLD, 0 # Default to fold if somehow none matched

    def _preflop_strategy(self, hand_strength: float, current_call_amount: int, remaining_chips: int, min_raise_amount: int, max_raise_amount: int, pot: int) -> Tuple[PokerAction, int]:
        
        # Consider an aggressive bluff if it's heads-up and hand is weak
        if self.num_opponents_active == 1 and random.random() < self.bluff_probability and hand_strength < self.strength_preflop_call_threshold:
            # If we decide to bluff, try to make a significant raise to scare off
            bluff_bet = min(max_raise_amount, int(pot * 1.5)) # Bet 1.5x pot as a bluff
            if bluff_bet > current_call_amount and bluff_bet >= min_raise_amount:
                return PokerAction.RAISE, bluff_bet
            elif current_call_amount == 0 and remaining_chips > 0: # Can check/bet, let's bet if bluffing instead of check
                 bet_amount = min(max_raise_amount, int(self.blind_amount * 2)) # 2x BB bluff
                 if bet_amount > 0: return PokerAction.RAISE, bet_amount


        if hand_strength >= self.strength_preflop_raise_threshold:
            # Strong hand: Raise
            if current_call_amount == 0: # No previous bet, so open raise
                raise_amount = min(max_raise_amount, max(min_raise_amount, int(2.5 * self.blind_amount * self.aggression_factor)))
            else: # Opponent already bet, re-raise or call depending on calculated raise
                raise_amount = min(max_raise_amount, max(min_raise_amount, current_call_amount + int(2.5 * self.blind_amount * self.aggression_factor)))

            if raise_amount > 0 and raise_amount >= current_call_amount + min_raise_amount : # Check if it's a valid raise
                return PokerAction.RAISE, raise_amount
            elif current_call_amount > 0 and current_call_amount <= remaining_chips:
                return PokerAction.CALL, 0 # If cannot raise or raise amount is too small, just call
            elif current_call_amount == 0:
                return PokerAction.CHECK, 0 # If no bet and can't raise for some reason, check
        elif hand_strength >= self.strength_preflop_call_threshold:
            # Medium hand: Call or Check
            if current_call_amount > 0:
                if current_call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else: # Cannot afford to call, must fold
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Weak hand: Fold or Check if possible
            if current_call_amount > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        
        # Fallback to fold if no other action is returned
        return PokerAction.FOLD, 0

    def _postflop_strategy(self, hand_strength: float, current_call_amount: int, remaining_chips: int, min_raise_amount: int, max_raise_amount: int, pot: int, community_cards: List[str]) -> Tuple[PokerAction, int]:
        
        # Aggressive bluffing post-flop, especially if pot is small and few opponents
        if self.num_opponents_active <= 2 and random.random() < self.bluff_probability * 0.5: # Lower bluff prob postflop
            bluff_bet = min(max_raise_amount, int(pot * 0.75)) # Bet 75% of pot as a bluff
            if bluff_bet > 0 and bluff_bet >= min_raise_amount and bluff_bet > current_call_amount:
                return PokerAction.RAISE, bluff_bet
            elif current_call_amount == 0 and remaining_chips > 0: # Can check, but bluff instead if possible
                bet_amount = min(max_raise_amount, int(pot * 0.5)) # Bet half pot
                if bet_amount > 0 : return PokerAction.RAISE, bet_amount

        if hand_strength >= self.strength_postflop_raise_threshold:
            # Very strong hand: Value bet/raise
            if current_call_amount == 0: # No bet, initiate with a value bet
                bet_amount = min(max_raise_amount, max(min_raise_amount, int(pot * self.value_bet_sizing * self.aggression_factor)))
                if bet_amount == 0 and remaining_chips > 0: # If pot is tiny, bet minimum blind
                    bet_amount = min(max_raise_amount, max(min_raise_amount, self.blind_amount))
                if bet_amount > 0:
                    return PokerAction.RAISE, bet_amount
                else: # Cannot make a minimum raise or bet, so check
                    return PokerAction.CHECK, 0
            else: # Opponent bet, re-raise for value
                raise_amount = min(max_raise_amount, max(min_raise_amount, current_call_amount + int(pot * 0.6 * self.aggression_factor)))
                if raise_amount > 0 and raise_amount >= current_call_amount + min_raise_amount:
                    return PokerAction.RAISE, raise_amount
                elif current_call_amount <= remaining_chips:
                    return PokerAction.CALL, 0 # If can't raise, just call
                else:
                    return PokerAction.ALL_IN, 0 # All-in if cannot afford to call but have strong hand
        elif hand_strength >= self.strength_postflop_call_threshold:
            # Medium hand: Call or Check
            if current_call_amount > 0:
                if current_call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Weak hand: Fold or Check
            if current_call_amount > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        
        # Fallback in case none above returns an action.
        return PokerAction.FOLD, 0


    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Estimates the strength of the hand. 
        This is a simplified estimation and should be replaced with a proper poker hand evaluator.
        For now, it's based on pair/straight/flush potential.
        """
        all_cards = hole_cards + community_cards

        # Convert cards to rank and suit for easier processing
        ranks = []
        suits = []
        for card in all_cards:
            if len(card) == 2:
                rank = card[0]
                suit = card[1]
            else: # e.g., '10h'
                rank = card[0:2]
                suit = card[2]
            
            # Map face cards and '10' to numerical values for sorting/comparison
            if rank == 'A': ranks.append(14)
            elif rank == 'K': ranks.append(13)
            elif rank == 'Q': ranks.append(12)
            elif rank == 'J': ranks.append(11)
            elif rank == 'T': ranks.append(10)
            else: ranks.append(int(rank))
            suits.append(suit)

        # Hand strength score
        score = 0.0

        # Pre-flop strength, very basic
        if not community_cards:
            rank1 = ranks[0]
            rank2 = ranks[1]
            suit1 = suits[0]
            suit2 = suits[1]

            # Pair
            if rank1 == rank2:
                score += (rank1 / 14.0) * 0.4 + 0.1 # High pairs are very strong
            # Suited
            if suit1 == suit2:
                score += 0.1
            # Connectors (e.g., 7-8, J-Q)
            if abs(rank1 - rank2) == 1 and rank1 < 14 and rank2 < 14: # Exclude A-K for now for simple conn.
                score += 0.05
            # Broadways (A, K, Q, J, T)
            if (rank1 >= 10 and rank2 >= 10) or (rank1 >= 10 and abs(rank1 - rank2) <3) or (rank2 >= 10 and abs(rank1 - rank2) <3):
                 score += 0.1

            # Normalize pre-flop score to 0-1
            # A rough estimate for pre-flop, aiming to categorize rather than precise equity
            if rank1 == rank2 and rank1 >= 10: return 0.9 + (rank1-10)/40 # AA, KK, QQ, JJ, TT
            if rank1 == rank2 and rank1 < 10: return 0.5 + (rank1-2)/80 # 22-99
            if (rank1==14 and rank2==13) or (rank1==13 and rank2==14): return 0.8 # AK
            if (rank1==14 and suit1==suit2) or (rank2==14 and suit1==suit2): return 0.7 # Suited Ace high

            return min(1.0, score + max(rank1, rank2) / 20.0) # Add a bit based on high card

        # Post-flop strength
        # Count rank occurrences for pairs, trips, quads
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1

        is_pair = False
        is_two_pair = False
        is_trips = False
        is_quads = False
        pair_ranks = []
        for r, count in rank_counts.items():
            if count == 2:
                is_pair = True
                pair_ranks.append(r)
            elif count == 3:
                is_trips = True
            elif count == 4:
                is_quads = True
        
        if len(pair_ranks) >= 2:
            is_two_pair = True

        if is_quads: return 1.0 # Very strong
        if is_trips and is_pair: return 0.95 # Full House
        if is_trips: return 0.85
        if is_two_pair: return 0.75
        if is_pair: score += 0.5 # A pair
        
        # Check for flush
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        for s, count in suit_counts.items():
            if count >= 5:
                score += 0.4 # Has a flush

        # Check for straight (simple, needs improvement for wrap-arounds e.g. A2345)
        sorted_ranks = sorted(list(set(ranks))) # Unique sorted ranks
        straight_count = 0
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 1):
                if sorted_ranks[i+1] == sorted_ranks[i] + 1:
                    straight_count += 1
                    if straight_count >= 4:
                        score += 0.3 # Has a straight
                        break
                else:
                    straight_count = 0
            # Check for A-5 straight (A=14, treat as 1)
            if {14, 2, 3, 4, 5}.issubset(set(ranks)):
                score += 0.3 # Has A-5 straight

        # High card power if no strong hand
        if score < 0.5 and len(all_cards) == 5: # Only if on flop and no strong hand yet
            high_card_strength = max(ranks) / 14.0
            score += high_card_strength * 0.1 # Very minor influence

        # Consider drawing hands
        num_community = len(community_cards)
        if num_community < 5: # Check for draws only on Flop/Turn
            # Flush draw (4 cards of same suit)
            for s, count in suit_counts.items():
                if count == 4:
                    score += 0.15 # Backdoor flush draw potential

            # Open-ended straight draw (e.g., 789T, needs J or 6)
            # Gutshot straight draw (e.g., 78TJ, needs 9)
            # This logic can be quite complex, simplify for now
            if len(sorted_ranks) >= 4:
                # Check for 4 consecutive ranks (open-ended straight draw)
                for i in range(len(sorted_ranks) - 3):
                    if sorted_ranks[i+3] == sorted_ranks[i] + 3:
                        score += 0.1 # Open-ended straight draw
                        break
                # Check for 3 gaps: x x x y ; x x y x; x y x x - Gutshot
                if len(sorted_ranks) >= 3:
                    for i in range(len(sorted_ranks) - 2):
                        if sorted_ranks[i+2] == sorted_ranks[i] + 2: # e.g., 7_9, J_Q
                             score += 0.05 # Gutshot straight draw

        return min(1.0, max(0.0, score)) # Ensure strength is between 0 and 1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent tendencies based on actions observed
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id == self.player_id or player_id not in self.opponent_actions:
                continue

            self.opponent_actions[player_id]['total_actions'] += 1
            if action == 'Fold':
                self.opponent_actions[player_id]['fold_count'] += 1
            elif action == 'Call':
                self.opponent_actions[player_id]['call_count'] += 1
            elif action == 'Raise' or action == 'All_in': # All_in treated as an aggressive action
                self.opponent_actions[player_id]['raise_count'] += 1

        # Adjust aggression factor based on opponent tendencies for the next rounds
        # This is a very simple adaptation, can be much more complex
        total_folds = sum(data['fold_count'] for data in self.opponent_actions.values() if data['total_actions'] > 0)
        total_actions = sum(data['total_actions'] for data in self.opponent_actions.values())

        if total_actions > 0 :
            fold_percentage = total_folds / total_actions
            if fold_percentage > 0.4: # Opponents folding often, be more aggressive
                self.aggression_factor = min(2.0, self.aggression_factor + 0.1)
            elif fold_percentage < 0.2: # Opponents calling/raising often, be less aggressive (tighter)
                self.aggression_factor = max(0.5, self.aggression_factor - 0.1)
        
        # Reset for next hand
        self.hole_cards = []


    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass