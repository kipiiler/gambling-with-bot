import random
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands 
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2 if blind_amount > 1 else 1 # Ensure small blind is at least 1
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.id)] if str(self.id) in round_state.player_hands else []

    def _rank_card(self, card: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]

    def _get_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # Simplistic hand strength based on high cards and pairs, can be greatly expanded.
        # This is a very basic heuristic. A real poker bot would use Monte Carlo simulations
        # or pre-calculated hand strengths.
        all_cards = hole_cards + community_cards
        ranks = sorted([self._rank_card(card) for card in all_cards], reverse=True)
        suits = [card[1] for card in all_cards]

        strength = 0.0

        # Check for pairs
        rank_counts: Dict[int, int] = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1

        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)

        if quads > 0:
            strength = 1.0 # Very strong
        elif trips > 0 and pairs > 0: # Full House
            strength = 0.9
        elif trips > 0:
            strength = 0.7
        elif pairs >= 2:
            strength = 0.5
        elif pairs == 1:
            strength = 0.3
        
        # Check for flush draw possibility and straight draw possibility (very basic)
        if len(community_cards) >= 3:
            suit_counts: Dict[str, int] = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            if any(count >= 3 for count in suit_counts.values()): # Potential flush
                strength = max(strength, 0.4)

            # Check for straight draws (basic, only looks for 3 cards in a row)
            sorted_unique_ranks = sorted(list(set(ranks)))
            for i in range(len(sorted_unique_ranks) - 2):
                if sorted_unique_ranks[i+2] - sorted_unique_ranks[i] <= 4:
                    strength = max(strength, 0.35) # Open-ended straight draw

        # High card strength (preflop, or if no common hand formed)
        if not (pairs or trips or quads):
            if ranks:
                strength += ranks[0] / 14.0 * 0.1 # Add a small component for high card strength

        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Simple pre-flop strategy based on hole cards
        if round_state.round == 'Preflop':
            # Convert card ranks to integers
            card1_rank = self._rank_card(self.hole_cards[0])
            card2_rank = self._rank_card(self.hole_cards[1])
            card1_suit = self.hole_cards[0][1]
            card2_suit = self.hole_cards[1][1]

            is_suited = (card1_suit == card2_suit)
            is_pair = (card1_rank == card2_rank)

            # Define thresholds for different actions
            # Premium hands: AA, KK, QQ, AKs
            if (is_pair and card1_rank >= 12) or \
               (card1_rank == 14 and card2_rank == 13 and is_suited) or \
               (card2_rank == 14 and card1_rank == 13 and is_suited):
                # Aggressive play with premium hands
                if current_bet_to_match == 0:
                    # If no bet, raise aggressively (3x big blind or more)
                    raise_amount = min(remaining_chips, max(round_state.min_raise, self.big_blind * 3))
                    return PokerAction.RAISE, raise_amount
                elif current_bet_to_match > 0:
                    # If there's a bet, re-raise or call, depending on bet size
                    if current_bet_to_match * 2 <= remaining_chips:
                        raise_amount = min(remaining_chips, max(round_state.min_raise, current_bet_to_match * 2))
                        return PokerAction.RAISE, raise_amount
                    elif current_bet_to_match < remaining_chips * 0.2: # Call if it's a small portion of stack
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0 # Go all-in with premium if bet is significant
            
            # Strong hands: JJ, TT, AQs, KQs, 99-77, AJs
            elif (is_pair and card1_rank >= 7) or \
                 (is_suited and ((card1_rank >= 12 and card2_rank >=10) or (card2_rank >= 12 and card1_rank >= 10))) or \
                 (max(card1_rank, card2_rank) == 14 and min(card1_rank, card2_rank) >= 11): # A-rag suited/connected
                
                if current_bet_to_match == 0:
                    # Check or small raise (2x big blind)
                    raise_amount = min(remaining_chips, max(round_state.min_raise, self.big_blind * 2))
                    return PokerAction.RAISE, raise_amount
                elif current_bet_to_match < remaining_chips * 0.15: # Call if not too expensive
                    return PokerAction.CALL, 0
                else: 
                     return PokerAction.FOLD, 0 # Fold to large bets

            # Medium hands: Suited connectors, small pairs, good high cards
            elif (is_suited and abs(card1_rank - card2_rank) <= 2 and max(card1_rank, card2_rank) >= 7) or \
                 (is_pair and card1_rank >= 2) or \
                 (max(card1_rank, card2_rank) >= 10 and min(card1_rank, card2_rank) >= 8):
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match < remaining_chips * 0.1: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Weak hands: Fold, unless it's a check or min-call
            else:
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match == self.small_blind or current_bet_to_match == self.big_blind:
                    return PokerAction.CALL, 0 # Call the blinds
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            hand_strength = self._get_hand_strength(self.hole_cards, round_state.community_cards)

            if current_bet_to_match == 0: # If no one has bet yet
                if hand_strength >= 0.7:  # Strong hand
                    # Bet aggressively
                    bet_amount = min(remaining_chips, int(round_state.pot * 0.75 + 0.5)) # Bet 75% of pot
                    if bet_amount < round_state.min_raise and remaining_chips >= round_state.min_raise:
                        bet_amount = round_state.min_raise
                    elif bet_amount < round_state.min_raise and remaining_chips < round_state.min_raise and remaining_chips > 0:
                        return PokerAction.ALL_IN, 0 # All-in if less than min_raise
                    elif bet_amount == 0 and remaining_chips > 0: # Edge case if pot is ~0 and we have min_raise
                        bet_amount = round_state.min_raise
                    elif bet_amount == 0 and remaining_chips == 0:
                        return PokerAction.CHECK, 0 # If all chips gone
                    if bet_amount > 0:
                        return PokerAction.RAISE, bet_amount
                    else:
                        return PokerAction.CHECK, 0 # Should not happen, but fallback
                elif hand_strength >= 0.4: # Medium hand
                    # Check or small bet
                    if random.random() < 0.5: # 50% chance to bet for value/protection
                        bet_amount = min(remaining_chips, int(round_state.pot * 0.5 + 0.5)) # Bet 50% of pot
                        if bet_amount < round_state.min_raise and remaining_chips >= round_state.min_raise:
                            bet_amount = round_state.min_raise
                        elif bet_amount < round_state.min_raise and remaining_chips < round_state.min_raise and remaining_chips > 0:
                            return PokerAction.ALL_IN, 0
                        elif bet_amount == 0 and remaining_chips > 0:
                            bet_amount = round_state.min_raise
                        elif bet_amount == 0 and remaining_chips == 0:
                            return PokerAction.CHECK, 0
                        if bet_amount > 0:
                            return PokerAction.RAISE, bet_amount
                        else:
                            return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else: # Weak hand
                    return PokerAction.CHECK, 0

            else: # Someone has bet
                if hand_strength >= 0.8: # Very strong hand (nuts or near-nuts)
                    # Raise or All-in
                    if current_bet_to_match < remaining_chips:
                        raise_amount = min(remaining_chips, max(round_state.min_raise, current_bet_to_match * 2))
                        if raise_amount == 0 and remaining_chips > 0: # If min_raise is tiny, ensure we raise at least something
                             raise_amount = max(round_state.min_raise, self.big_blind)
                        if raise_amount > 0:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                elif hand_strength >= 0.5: # Strong hand
                    # Call or small raise if bet is small
                    if current_bet_to_match < remaining_chips * 0.2: # Bet is less than 20% of stack
                        if random.random() < 0.3 and current_bet_to_match * 1.5 <= remaining_chips: # Sometimes raise slightly
                                raise_amount = min(remaining_chips, max(round_state.min_raise, int(current_bet_to_match * 1.5 + 0.5)))
                                if raise_amount > 0:
                                    return PokerAction.RAISE, raise_amount
                                else:
                                     return PokerAction.CALL, 0
                        return PokerAction.CALL, 0
                    elif current_bet_to_match < remaining_chips: # Bet is larger, consider folding or calling if it's worth it
                        if current_bet_to_match <= round_state.pot * 0.5: # Bet is up to half the pot
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    else: # Bet is entire stack
                        return PokerAction.CALL, 0
                elif hand_strength >= 0.2: # Marginal hand (draws, small pairs)
                    # Call only if bet is small, otherwise fold
                    if current_bet_to_match < remaining_chips * 0.1: # Bet is less than 10% of stack
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Weak hand
                    return PokerAction.FOLD, 0

        # Fallback to fold if no other action is determined (shouldn't be reached with complete logic)
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass