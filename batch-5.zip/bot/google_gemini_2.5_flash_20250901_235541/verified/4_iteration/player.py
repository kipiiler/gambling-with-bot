from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.hand_rank_data = {}
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.my_id = None

        # Pre-compute hand rankings for pre-flop (simplified)
        self._precompute_hand_rankings()

    def _precompute_hand_rankings(self):
        # This is a very simplified pre-flop hand strength assessment.
        # A real bot would use external libraries for robust hand evaluation or pre-calculated equities.
        # For this iteration, we'll assign arbitrary scores.
        # Higher score = stronger hand
        # Suits are ignored for now, only ranks and pairs.

        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        rank_values = {rank: i for i, rank in enumerate(ranks)}

        def get_card_rank_value(card_str):
            return rank_values[card_str[0]]

        # Examples of hand rankings:
        # Pockets: AA > KK > QQ ... 22
        # Suited connectors: AKs > AQs > KQs ...
        # Offsuit Broadway: AKo > AQo > KJo ...

        # Assign raw scores based on card ranks
        for i in range(len(ranks)):
            for j in range(len(ranks)):
                card1_rank = ranks[i]
                card2_rank = ranks[j]
                
                # Pair
                if card1_rank == card2_rank:
                    score = 1000 + rank_values[card1_rank] * 10
                else:
                    score = rank_values[card1_rank] + rank_values[card2_rank]

                # Suited bonus (arbitrary)
                # assuming input stores suited cards with 's' or 'o' like 'AKs', 'AKo'
                # For initial hole cards like ['Ah', 'Kh'], we need to check suits manually based on two cards
                self.hand_rank_data[(card1_rank, card2_rank)] = score

    def _get_hand_strength_preflop(self, hand: List[str]) -> float:
        if not hand or len(hand) != 2:
            return 0.0

        r1 = hand[0][0]
        r2 = hand[1][0]
        s1 = hand[0][1]
        s2 = hand[1][1]

        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        val1 = rank_values.get(r1, 0)
        val2 = rank_values.get(r2, 0)

        # Ensure val1 is always the higher rank for consistent lookup
        if val1 < val2:
            val1, val2 = val2, val1
            r1, r2 = r2, r1

        strength = 0.0

        # Pocket pairs
        if r1 == r2:
            if r1 == 'A': strength = 1.00 # AA
            elif r1 == 'K': strength = 0.95 # KK
            elif r1 == 'Q': strength = 0.90 # QQ
            elif r1 == 'J': strength = 0.85 # JJ
            elif r1 == 'T': strength = 0.80 # TT
            elif r1 == '9': strength = 0.75 # 99
            elif r1 == '8': strength = 0.70 # 88
            elif r1 == '7': strength = 0.65 # 77
            elif r1 == '6': strength = 0.60 # 66
            else: strength = 0.55 # 22-55 (any pair)
        
        # Suited connectors/broadways
        elif s1 == s2: # Suited
            if val1 >= 12 and val2 >= 10: strength = 0.80 # AKs, AQs, KQs, KJs, QJs, QTs (Premium suited)
            elif val1 >= 10 and abs(val1 - val2) <= 3: strength = 0.70 # Suited connectors/gappers like JTs, T9s, etc.
            elif val1 >= 10: strength = 0.60 # Other suited broadways like AJs, KTs etc.
            else: strength = 0.50 # Other suited hands
        
        # Offsuit broadways/strong
        else: # Offsuit
            if val1 >= 12 and val2 >= 10: strength = 0.70 # AKo, AQo, KQo (Premium offsuit)
            elif val1 >= 10 and val2 >= 9: strength = 0.50 # KJo, QJo, JTo (Decent offsuit broadways)
            else: strength = 0.40 # Other offsuit hands

        # Add a slight modifier for high cards in general
        strength += (val1 + val2) / 28.0 * 0.1 # Max sum 28 (A+K=14+13=27), so 27/28 ~ 1.0 * 0.1

        return min(strength, 1.0) # Cap at 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands.get(str(self.id), []) if hasattr(round_state, 'player_hands') else []
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        
        # Determine player position (simplified: if player is a blind, they are in early position)
        is_small_blind = (self.id == self.small_blind_player_id)
        is_big_blind = (self.id == self.big_blind_player_id)
        
        # Calculate effective stack (remaining chips)
        effective_stack = remaining_chips

        # Simple Hand Strength Evaluation based on pre-flop (can be expanded for post-flop)
        hand_strength = self._get_hand_strength_preflop(self.hole_cards)

        # Aggression factor (based on how many players are left and current betting behavior)
        num_active_players = sum(1 for player_id in round_state.current_player if round_state.player_bets.get(str(player_id), -1) != -1)
        
        # Dynamic threshold for aggressive play
        # Be more aggressive heads-up or with few players, less aggressive multi-way
        aggression_threshold_modifier = 0.0
        if num_active_players <= 2:
            aggression_threshold_modifier = 0.15 # Play more hands heads-up
        elif num_active_players <= 4:
            aggression_threshold_modifier = 0.05
        else:
            aggression_threshold_modifier = -0.05 # Be tighter with more players

        # Define thresholds for actions based on hand strength and round
        fold_threshold = 0.30 - aggression_threshold_modifier
        call_threshold = 0.45 - aggression_threshold_modifier
        raise_threshold = 0.65 # Keep raise threshold higher for strong hands

        # Adjust thresholds based on current bet size relative to pot or stack
        # If opponent has bet a large portion of the pot or all-in, tighten up
        if round_state.pot > 0:
            bet_to_pot_ratio = amount_to_call / max(1, round_state.pot)
            if bet_to_pot_ratio > 0.5 and amount_to_call > 0: # Opponent made a big bet
                fold_threshold += 0.10 # Be more likely to fold
                call_threshold += 0.10
        
        # Logic for pre-flop actions
        if round_state.round == PokerRound.PREFLOP.name:
            if hand_strength >= raise_threshold:
                # Attempt to raise 3x big blind, or 2.5x current bet if there's a previous raise
                if amount_to_call == 0: # No previous bet, or just blinds
                    raise_amount = self.blind_amount * 3
                else: # Opponent has bet
                    raise_amount = amount_to_call + max(round_state.min_raise, amount_to_call * 1.5) # Re-raise 2.5x previous bet

                # Ensure raise amount is valid
                raise_amount = min(max(raise_amount, round_state.min_raise), effective_stack)
                raise_amount = max(my_bet_in_round + self.blind_amount * 2, raise_amount) # Ensure minimum raise value
                
                if raise_amount >= effective_stack:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, int(raise_amount)
            
            elif hand_strength >= call_threshold:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call < effective_stack:
                    return PokerAction.CALL, 0
                else: # Cannot call, must go all-in
                    return PokerAction.ALL_IN, 0
            else: # Hand strength below call threshold
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0 # Check if no bet
                else:
                    return PokerAction.FOLD, 0 # Fold otherwise
        
        # Logic for post-flop actions (Flop, Turn, River)
        else:
            # Re-evaluate hand strength with community cards (simple: just rely on initial hand for now)
            # A real bot would integrate a proper poker hand evaluator here.
            # For iteration 4, we'll keep it simple and just slightly modify behavior based on stage
            
            # Adjust strength slightly based on number of community cards,
            # indicating more certainty about hand (but we are not evaluating full hand)
            if round_state.round == PokerRound.FLOP.name:
                hand_strength += 0.05 # slight boost as more information is out
            elif round_state.round == PokerRound.TURN.name:
                hand_strength += 0.10
            elif round_state.round == PokerRound.RIVER.name:
                hand_strength += 0.15

            # Aggressive play post-flop with good hands
            if hand_strength >= raise_threshold + 0.1: # Stronger hand needed to raise post-flop
                raise_amount = max(round_state.min_raise, round_state.pot // 2) # Bet half the pot
                raise_amount = min(raise_amount, effective_stack)
                raise_amount = max(my_bet_in_round + self.blind_amount * 2, raise_amount) # Ensure valid raise amount
                
                if raise_amount >= effective_stack - 10: # If raise amount is close to all-in, just go all-in
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, int(raise_amount)

            elif hand_strength >= call_threshold + 0.05: # Need a slightly better hand to call post-flop
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call < effective_stack:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0 # Not enough chips to call, but want to play
            else:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Default fallback
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif amount_to_call < effective_stack:
            return PokerAction.CALL, 0
        else:
            return PokerAction.ALL_IN, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = []
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass