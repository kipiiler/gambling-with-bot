from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.player_id = None # Store player's own ID
        self.hand_strength = 0 # Simple hand strength, 0-100
        self.aggressiveness = 0.5 # A value between 0 and 1, affecting betting behavior

        # Card ranking for evaluation
        self.card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.card_suits = {'h': 0, 'd': 1, 'c': 2, 's': 3}

    def set_id(self, player_id: int) -> None:
        """ Sets the player ID. Overriding to store the ID. """
        self.player_id = player_id
        super().set_id(player_id)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        # player_hands in on_start is typically an empty list or only shows your hand if the server permits.
        # We will get our actual hole cards in on_round_start or get_action.
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # On_round_start doesn't provide player_hands. It's usually known within get_action for the current player.
        # The common practice is to update hole_cards when get_action is called, as that's when the player
        # receives their specific hand information. If the framework provided it here, it would be in
        # a structure specific to the player's ID, but RoundStateClient doesn't have it directly.
        # We will assume if hole_cards are needed they will be accessed when an action is required
        # or passed as part of the bot's internal state management, often implied by the 'player_hands' attribute
        # which is *not* part of RoundStateClient. We'll handle hole cards in get_action.

        # Reset hand strength for a new round
        self.hand_strength = 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # The error "AttributeError: 'RoundStateClient' object has no attribute 'player_hands'" means
        # player_hands is not part of RoundStateClient. We need to handle how hole cards are passed.
        # Typically, a framework indicates hole cards on the *first* action of the hand (pre-flop)
        # or through a specific 'set_hole_cards' method if provided.
        # Given the template, it's implied that `self.hole_cards` should be set by the game runner.
        # Let's assume current player's hole cards are available within the bot's state or can be derived.
        # For this version, let's assume `self.hole_cards` would have been set by an external call,
        # or we might need to rely on the environment providing it if it's not explicitly in round_state.
        # Since on_start and on_round_start don't provide it, and get_action needs it,
        # we have a gap. A common approach in such competitions is that hole cards
        # are *implicitly* available to the bot when `get_action` is called *pre-flop*.
        # However, the provided `RoundStateClient` does not include `player_hands`.
        # This implies that a competition framework would either pass it as an argument to `get_action`
        # or set it on the bot object directly before calling `get_action` pre-flop.
        # As per the problem description `player_hands` is passed only to `on_start` (which is unusual
        # as it's typically per-round).
        # Given this ambiguity, for now, let's assume `self.hole_cards` is populated by the system
        # *before* `get_action` is called for the preflop. If not, this needs clarification.
        # For robustness, we will add a placeholder but rely on actual context.

        # Since it's a critical error, let's re-evaluate how hole cards are handled.
        # The prompt for on_start says `player_hands: List[str]`. This is unusual
        # because `on_start` happens once for the entire game session, not per round.
        # It's more likely `player_hands` is actually the bot's own hand for the *current round*
        # when `get_action` is called. But it's not in `RoundStateClient`.
        # If `player_hands` from `on_start` was *meant* to be *your* initial hand,
        # that's only for the first hand.
        #
        # **Correction**: The typical poker bot interface passes the specific player's
        # hole cards directly to the `get_action` method, or implicitly makes them
        # available as a bot attribute. `RoundStateClient` does not contain it.
        # Let's assume `self.hole_cards` is updated by an *external* component
        # before `get_action` if it's not passed.
        # To proceed, for strategy, we'll need to assume `self.hole_cards` has our 2 cards.
        # This means the player implementation should be able to get `self.hole_cards` set by the game server somewhere.
        # If not, the bot cannot play correctly. This is an essential piece of info.

        # For the purpose of providing a complete answer, let's assume the bot's `hole_cards`
        # attribute is properly set by the competition framework before `get_action` is called
        # for a pre-flop action. After pre-flop, `self.hole_cards` should remain the same.

        # Define some strategy parameters
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        my_current_bet_in_round = round_state.player_bets.get(str(self.player_id), 0)
        chips_to_call = current_bet - my_current_bet_in_round

        # Basic hand evaluation (Placeholder for actual poker logic)
        # Combine hole cards with community cards
        revealed_cards = self.hole_cards + round_state.community_cards
        self.hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        # Determine number of active players
        active_players_count = len(round_state.current_player)

        # Simple strategy based on hand strength and round
        stage = round_state.round

        # Pre-flop strategy
        if stage == 'Preflop':
            # This is where hole cards matter most initially
            if "A" in [card[0] for card in self.hole_cards] and "K" in [card[0] for card in self.hole_cards]: # AK
                 self.aggressiveness = 0.9
            elif len(self.hole_cards) == 2 and self.card_ranks[self.hole_cards[0][0]] == self.card_ranks[self.hole_cards[1][0]] and self.card_ranks[self.hole_cards[0][0]] >= self.card_ranks['J']: # Pairs JJ+
                self.aggressiveness = 0.8
            elif self.hand_strength > 70: # Strong hands
                self.aggressiveness = 0.7
            elif self.hand_strength > 50: # Medium hands
                self.aggressiveness = 0.5
            else: # Weak hands
                self.aggressiveness = 0.2

            # Decide action
            if self.aggressiveness > 0.65: # Aggressive pre-flop
                if chips_to_call == 0: # Can check or raise
                    raise_amount = min(max_raise, max(min_raise, self.blind_amount * 3)) # 3x blind or min_raise
                    return PokerAction.RAISE, raise_amount
                elif chips_to_call < remaining_chips * 0.2: # Call small bets or raise
                    if random.random() < 0.7:  # 70% chance to raise, 30% to call
                        raise_val = self._calculate_raise_amount(min_raise, max_raise, remaining_chips, chips_to_call, self.aggressiveness)
                        return PokerAction.RAISE, raise_val
                    else:
                        return PokerAction.CALL, 0
                else: # Large bet to call
                    if self.hand_strength > 75 and remaining_chips > chips_to_call: # Only call strong if it's not all-in
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif self.aggressiveness > 0.4: # Medium pre-flop
                if chips_to_call == 0:
                    return PokerAction.CHECK, 0
                elif chips_to_call < remaining_chips * 0.1: # Call small bets
                    if random.random() < 0.5: # 50% chance to call, 50% to fold
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Large bet
                    return PokerAction.FOLD, 0
            else: # Passive/Fold pre-flop
                if chips_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        # Adjust aggressiveness based on hand strength and community cards
        if self.hand_strength > 85: # Very strong hand (e.g., set, straight, flush, better)
            self.aggressiveness = 0.95
        elif self.hand_strength > 70: # Strong hand (e.g., top pair, overpair, strong draw)
            self.aggressiveness = 0.8
        elif self.hand_strength > 50: # Medium hand (e.g., middle pair, weak draw)
            self.aggressiveness = 0.5
        elif self.hand_strength > 30: # Weak hand (e.g., high card, very weak pair)
            self.aggressiveness = 0.3
        else: # No hand
            self.aggressiveness = 0.1


        # Action logic for post-flop
        if chips_to_call >= remaining_chips: # Opponent is all-in or effective all-in
            # If our hand is very strong, go all-in too
            if self.hand_strength > 80:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        if current_bet > my_current_bet_in_round: # There's a bet to call
            if self.aggressiveness > 0.7: # Aggressive player with good hand
                if remaining_chips > chips_to_call: # Can raise
                    raise_val = self._calculate_raise_amount(min_raise, max_raise, remaining_chips, chips_to_call, self.aggressiveness)
                    return PokerAction.RAISE, raise_val
                else: # Must go all_in to raise
                    return PokerAction.ALL_IN, 0
            elif self.aggressiveness > 0.4: # Medium hand or cautious
                if chips_to_call < remaining_chips * 0.25: # Call if bet is less than 25% of stack
                    return PokerAction.CALL, 0
                else: # Bet is too large, fold
                    return PokerAction.FOLD, 0
            else: # Weak hand, don't call big bets
                return PokerAction.FOLD, 0
        else: # No bet to call, can check or bet
            if self.aggressiveness > 0.6: # Bet if strong or trying to bluff
                bet_amount = min(max_raise, max(min_raise, int(round_state.pot * 0.5))) # Bet half pot
                if bet_amount == 0 and remaining_chips > 0: # If min_raise is 0 (can happen if current_bet is 0 and no prior raises), ensure valid raise
                     bet_amount = self.blind_amount # Bet at least a blind if min_raise is 0.
                bet_amount = max(bet_amount, min_raise) # Ensure minimum raise amount
                if bet_amount > 0 and remaining_chips >= bet_amount:
                   return PokerAction.RAISE, bet_amount
                elif remaining_chips > 0: # If can't raise a meaningful amount, check or all_in
                    return PokerAction.ALL_IN, 0 # Try to push chips in if can't make a standard raise
                else:
                    return PokerAction.CHECK, 0 # No chips left
            else: # Check if weak or cautious
                return PokerAction.CHECK, 0

    def _calculate_raise_amount(self, min_raise: int, max_raise: int, remaining_chips: int, chips_to_call: int, aggressiveness: float) -> int:
        # Calculate a raise amount based on aggressiveness, ensuring valid ranges.
        # Base raise is 2x current bet or 3x blind (if preflop and no bet yet)
        if min_raise == 0: # This can happen preflop if blinds are posted and it's first action after BB
            effective_min_raise = self.blind_amount * 2
        else:
            effective_min_raise = min_raise

        # A more dynamic raise amount: between min_raise and a fraction of stack
        # weighted by aggressiveness.
        potential_raise = int(remaining_chips * aggressiveness)
        # Ensure the raise is at least min_raise and not more than max_raise
        raise_amount = max(effective_min_raise, potential_raise)
        raise_amount = min(raise_amount, max_raise)

        # The raise amount is the *total* bet amount, not just the additional chips.
        # No, for RAISE action, the amount is the total amount put into pot for the current round by the player.
        # "For RAISE: the amount raise combine with your current bet must be larger than the the current raise."
        # This implies `amount` is the *total* bet for the round (current_bet + raise_amount).
        # However, the `min_raise` in RoundStateClient is typically the minimum *additional* amount to raise.
        # Let's assume the `RAISE` amount parameter expects `total_bet_for_round`, consistent with current_bet.
        # If it expects the *additional* amount to raise *above* current_bet, this logic needs adjustment.
        # Given "current_bet: The current bet (need to match round's current bet minus your current bet if you want to call)"
        # and "For RAISE: the amount raise combine with your current bet must be larger than the the current raise."
        # It's highly ambiguous. A standard convention is to specify the total new bet.
        # If min_raise refers to the *absolute total amount* for the current bet, then it's simpler.
        # If `min_raise` is the minimum `additional` amount, then your total bet must be `current_bet + min_raise`.

        # Let's interpret "amount raise combine with your current bet must be larger than the the current raise"
        # as the amount you send being your *TOTAL* contribution to the pot for this betting round,
        # which must exceed the current highest bet (round_state.current_bet).
        # So essentially, you need to call, and then make a raise on top of that.
        # The true *minimum raise value* above the `current_bet` is `min_raise` from `RoundStateClient`.
        # So the absolute minimum total bet would be `current_bet + min_raise`.
        
        # Calculate how much more is needed beyond `chips_to_call`
        absolute_min_total_bet = current_bet + min_raise
        
        # Decide the raise amount as a factor of the pot or based on aggressiveness
        # Let's aim for a raise that is a multiple of the current bet or a fraction of our stack
        # A common raise size is 2-3x the current bet, or a pot-sized bet.
        
        # Make a pot-sized re-raise
        pot_size = round_state.pot
        bet_size = current_bet
        pot_raise_amount = int(pot_size + bet_size) # This is roughly a pot-sized raise over the current bet.
        
        # Adjust based on aggressiveness
        if aggressiveness > 0.8: # Very aggressive, aim for larger raise
            target_amount = max(absolute_min_total_bet, pot_raise_amount)
        elif aggressiveness > 0.5: # Moderately aggressive
            target_amount = max(absolute_min_total_bet, int(pot_raise_amount * 0.75)) # 75% of pot raise
        else: # Less aggressive, stick closer to min_raise
            target_amount = absolute_min_total_bet

        final_raise_amount = min(target_amount, remaining_chips) # Cannot raise more than we have
        final_raise_amount = max(final_raise_amount, absolute_min_total_bet) # Cannot be less than the required minimum

        # Ensure we don't accidentally try to "raise" if current_bet is 0 and min_raise is 0 (first action, no blinds posted yet)
        if final_raise_amount < current_bet + min_raise:
            final_raise_amount = current_bet + min_raise

        # Ensure we don't try to raise more than max_raise (which is remaining_chips)
        final_raise_amount = min(final_raise_amount, max_raise)
        
        # Also, ensure final_raise_amount is not less than a default initial bet for pre-flop if applicable
        # (e.g., if there's no current bet yet, a standard open raise)
        if current_bet == 0 and final_raise_amount < self.blind_amount * 2: # Or some other standard open size
             final_raise_amount = self.blind_amount * 2 # Or 3x blind, depending on table dynamics

        # Make sure the raise amount is always positive, and if it becomes effectively 0 or too small, fall back.
        if final_raise_amount <= current_bet: # This scenario should not happen if min_raise is correctly calculated by server
            if remaining_chips > current_bet + self.blind_amount:
                # If there's an issue with min_raise, just try to raise 2x blind or small amount
                return min(remaining_chips, current_bet + self.blind_amount * 2)
            else:
                 return remaining_chips # All-in if we can't make a proper raise
                 
        return final_raise_amount


    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> int:
        # A simplified poker hand evaluator that assigns a score from 0-100.
        # This is very basic and needs significant improvement for a competitive bot.

        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0

        # Parse cards for ranks and suits
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) == 2:
                rank_char, suit_char = card_str[0], card_str[1]
            elif len(card_str) == 3: # Handle '10' rank
                rank_char, suit_char = card_str[0:2], card_str[2]
            else:
                continue # Skip malformed card string

            rank = self.card_ranks.get(rank_char, 0)
            suit = self.card_suits.get(suit_char, 0)
            parsed_cards.append((rank, suit))

        if len(parsed_cards) < 2: # Need at least hole cards to evaluate anything meaningful
            return 0

        # Sort cards by rank for easier evaluation
        parsed_cards.sort(key=lambda x: x[0], reverse=True)

        # High Card / Pair (only considering hole cards for now if no community cards)
        if len(parsed_cards) == 2: # Pre-flop strength based on hole cards
            if parsed_cards[0][0] == parsed_cards[1][0]: # Pair
                if parsed_cards[0][0] >= self.card_ranks['A']: return 95 # AA
                if parsed_cards[0][0] >= self.card_ranks['K']: return 90 # KK
                if parsed_cards[0][0] >= self.card_ranks['Q']: return 85 # QQ
                if parsed_cards[0][0] >= self.card_ranks['J']: return 80 # JJ
                if parsed_cards[0][0] >= self.card_ranks['T']: return 75 # TT
                return 50 + parsed_cards[0][0] # Other pairs
            elif (parsed_cards[0][0] == self.card_ranks['A'] and parsed_cards[1][0] == self.card_ranks['K']): # AK
                if parsed_cards[0][1] == parsed_cards[1][1]: return 88 # AKs
                else: return 85 # AKo
            elif (parsed_cards[0][0] >= self.card_ranks['A'] and parsed_cards[1][0] >= self.card_ranks['Q']) or \
                 (parsed_cards[0][0] >= self.card_ranks['K'] and parsed_cards[1][0] >= self.card_ranks['J']): # AQ, KJ+
                if parsed_cards[0][1] == parsed_cards[1][1]: return 70 # suited
                else: return 60 # offsuit
            else: # Other hands
                if parsed_cards[0][1] == parsed_cards[1][1] and self.card_ranks[hole_cards[0][0]] - self.card_ranks[hole_cards[1][0]] <= 4 and self.card_ranks[hole_cards[1][0]] >= self.card_ranks['5']: # Suited connectors
                    return 45
                return 30 + (parsed_cards[0][0] / 10) # Base strength on high card

        # Evaluate strength post-flop (5 or more cards)
        # This part requires a full hand evaluator. For simplicity, we just look for common patterns.
        # This is a very rough estimation. A real bot would implement robust hand evaluation.

        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        for rank, suit in parsed_cards:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1

        hand_score = 0

        # Check for flushes
        for suit, count in suit_counts.items():
            if count >= 5:
                hand_score = max(hand_score, 80) # Assume a flush is strong

        # Check for straights (simple check, doesn't handle all cases)
        unique_ranks = sorted(list(set([r for r, s in parsed_cards])), reverse=True)
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4: # Straight 5 consecutive ranks
                    hand_score = max(hand_score, 70)
                # Handle Ace-low straight (A,2,3,4,5)
                if set([self.card_ranks['A'], self.card_ranks['5'], self.card_ranks['4'], self.card_ranks['3'], self.card_ranks['2']]).issubset(set(unique_ranks)):
                    hand_score = max(hand_score, 70)


        # Check for pairs, three of a kind, four of a kind
        num_pairs = 0
        three_of_a_kind = 0
        four_of_a_kind = 0
        for rank, count in rank_counts.items():
            if count == 4:
                four_of_a_kind = rank
                hand_score = max(hand_score, 98)
            elif count == 3:
                three_of_a_kind = rank
                hand_score = max(hand_score, 60)
            elif count == 2:
                num_pairs += 1

        if four_of_a_kind > 0:
            return 98
        elif three_of_a_kind > 0 and num_pairs >= 1: # Full House
            return 90
        elif hand_score >= 80: # Flush already set
            return hand_score
        elif hand_score >= 70: # Straight already set
            return hand_score
        elif three_of_a_kind > 0:
            return hand_score # Three of a kind
        elif num_pairs >= 2: # Two Pair
            return 55
        elif num_pairs == 1: # One Pair
            # If the pair is high, it's better
            if parsed_cards[0][0] == parsed_cards[1][0] and parsed_cards[0][0] >= self.card_ranks['T']:
                return 40 + parsed_cards[0][0]
            return 30
        else: # High card
            return 10 + (parsed_cards[0][0] / 1.4) # Add a small bonus for high card

        return max(1, min(100, int(hand_score))) # Ensure score is within 1-100 and at least 1.

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # We don't need to refresh hole cards here; they are constant per hand.
        # This is where you might log total chips, analyze opponent actions, etc.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game has ended, log final results or strategy performance.
        pass