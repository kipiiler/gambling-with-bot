import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.remaining_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands # This is the player's hole cards for the current hand
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        # The hole cards are updated in on_start for the new hand
        # This method is for actions specific to the start of a betting round
        # For a basic bot, not much special needs to happen here beyond updating chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_id_str = str(self.id)
        my_current_bet_in_round = round_state.player_bets.get(player_id_str, 0)

        # Calculate how much more needs to be called
        amount_to_call = current_bet - my_current_bet_in_round

        # Basic strategy:
        # Pre-flop:
        # - If current bet is 0 (first to act or blinds are posted and it's small blind's turn before big blind acted):
        #   - Check if possible (if no one has bet yet)
        #   - Otherwise, call the big blind or raise with good starting hands
        # - If there's a bet:
        #   - Call if the bet is small
        #   - Raise with very strong hands
        #   - Fold otherwise

        num_players_active = len([p_id for p_id in round_state.current_player if round_state.player_bets.get(str(p_id), 0) < self.remaining_chips + my_current_bet_in_round])

        # A very basic hand strength evaluation (High card value, pairs)
        # '2','3','4','5','6','7','8','9','T','J','Q','K','A'
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        card1_rank = rank_map[self.hole_cards[0][0]]
        card2_rank = rank_map[self.hole_cards[1][0]]
        card1_suit = self.hole_cards[0][1]
        card2_suit = self.hole_cards[1][1]

        is_pair = (card1_rank == card2_rank)
        is_suited = (card1_suit == card2_suit)
        is_connector = (abs(card1_rank - card2_rank) == 1)

        # Simple Hand Strength Score (higher means stronger)
        hand_strength = 0
        if is_pair:
            hand_strength += card1_rank * 2 # Pairs are good
        else:
            hand_strength += card1_rank + card2_rank # Sum of ranks

        if is_suited:
            hand_strength += 3 # Suited cards are slightly better
        if is_connector:
            hand_strength += 2 # Connectors are slightly better

        # Adjust hand strength for high cards
        if max(card1_rank, card2_rank) >= rank_map['T']:
            hand_strength += 5 # High cards are good

        # Community cards influence hand strength (very basic - just checking for pairs)
        for community_card in round_state.community_cards:
            comm_rank = rank_map[community_card[0]]
            if comm_rank == card1_rank or comm_rank == card2_rank:
                hand_strength += 10 # Increase if we get a pair with community
            elif is_pair and comm_rank == card1_rank:
                hand_strength += 15 # Set or better (very crude)


        # Determine aggressiveness based on hand strength and betting round
        # More aggressive for stronger hands, more aggressive in later rounds if board hits
        aggressiveness = 0
        if round_state.round == 'Preflop':
            if hand_strength >= 25: # Premium hands (e.g., AA, KK, QQ, AKs)
                aggressiveness = 3
            elif hand_strength >= 18: # Strong hands (e.g., JJ, TT, AQo, KJs)
                aggressiveness = 2
            elif hand_strength >= 12: # Medium hands (e.g., suited connectors, small pairs)
                aggressiveness = 1
            else: # Weak hands
                aggressiveness = 0
        else: # Post-flop
            # This part needs sophisticated hand evaluation for real strength (e.g. check for flushes, straights, two pair, etc.)
            # For simplicity, we'll just check for basic improvements
            if len(round_state.community_cards) > 0:
                # Re-evaluate hand strength with community cards
                # This is a very simplistic check and doesn't calculate actual poker hands
                # A full poker hand evaluator would be needed here.
                # For now, just assume our initial hand strength is generally relevant.
                pass # A more complex bot would calculate actual hand value here

            # Example: If current_bet is 0 (meaning we can check or bet ourselves)
            if current_bet == 0:
                if hand_strength >= 20: # Strong post-flop hand
                    aggressiveness = 3 # Bet
                elif hand_strength >= 15: # Medium post-flop hand
                    aggressiveness = 2 # Check or small bet
                else:
                    aggressiveness = 1 # Check

            else: # Someone else has bet
                if hand_strength >= 25: # Very strong hand
                    aggressiveness = 3 # Raise
                elif hand_strength >= 20: # Strong hand
                    aggressiveness = 2 # Call or Potentially small raise
                elif hand_strength >= 15: # Medium hand
                    aggressiveness = 1 # Call
                else:
                    aggressiveness = 0 # Fold or just call if amount is tiny

        # Action logic based on calculated aggressiveness
        if amount_to_call > 0:
            # We need to call, raise, or fold
            if amount_to_call >= self.remaining_chips: # All-in situation if calling
                if aggressiveness >= 2: # Call/All-in with strong/medium hands
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            else: # We can call, raise, or fold
                if aggressiveness == 3: # Very aggressive: Raise
                    # Try to raise 2x current bet or pot size if possible
                    raise_amount = max(min_raise, current_bet * 2)
                    if raise_amount > max_raise:
                        return PokerAction.ALL_IN, 0 # Go all-in if raise is too high
                    elif raise_amount + my_current_bet_in_round > self.remaining_chips + my_current_bet_in_round: # ensure we don't accidentally overbet our stack
                         return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif aggressiveness == 2: # Moderately aggressive: Call almost always, sometimes raise
                    # Small chance to raise with strong hands, otherwise call
                    if random.random() < 0.2 and amount_to_call + min_raise <= self.remaining_chips: # 20% chance to raise
                         return PokerAction.RAISE, min_raise
                    return PokerAction.CALL, 0
                elif aggressiveness == 1: # Passive: Call if small, otherwise fold
                    if amount_to_call <= self.remaining_chips * 0.15 or (amount_to_call <= self.blind_amount * 2 and round_state.round == 'Preflop'): # Call small bets
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Very passive/weak hand: Fold
                    return PokerAction.FOLD, 0
        else:
            # No current bet, we can check or bet/raise
            if aggressiveness >= 2: # Strong/Medium hand: Bet
                bet_amount = max(self.blind_amount, min_raise) # Bet at least the big blind or min_raise
                if bet_amount > max_raise:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            else: # Weak hand: Check
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        # This method is called at the end of each hand.
        # You can use it to reset state or analyze the hand outcome.
        # For simplicity, we just update remaining chips.

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This method is called at the very end of the game (tournament simulation).
        # No specific action expected for competition.
        pass