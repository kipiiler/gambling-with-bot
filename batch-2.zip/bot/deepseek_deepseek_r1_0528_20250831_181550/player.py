from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.initial_players = []
        self.button_index = 0
        self.current_bb = 0
        self.my_cards = []
        self.rank_map = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, 
                         '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
        self.group1 = ['AA', 'KK', 'QQ', 'JJ', 'AKs']
        self.group2 = ['TT', 'AQs', 'AJs', 'KQs', 'AKo']
        self.group3 = ['99', 'ATs', 'KJs', 'QJs', 'JTs', 'AQo']
        self.group4 = ['88', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'AJo', 'KQo']

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.initial_players = all_players
        self.my_cards = player_hands
        
        try:
            small_blind_index = all_players.index(small_blind_player_id)
            self.button_index = (small_blind_index - 1) % len(all_players)
        except ValueError:
            self.button_index = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        if round_state.round == 'Preflop':
            self.current_bb = round_state.current_bet
        self.my_cards = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        player_id_str = str(self.id)
        my_bet = round_state.player_bets.get(player_id_str, 0)
        amount_to_call = round_state.current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        if round_state.round == 'Preflop' and not self.my_cards:
            for pid, cards in round_state.player_hands.items():
                if pid == player_id_str:
                    self.my_cards = cards
                    break

        if not self.my_cards and round_state.round != 'Preflop':
            return (PokerAction.FOLD, 0)

        if round_state.round == 'Preflop':
            return self.preflop_action(round_state, amount_to_call, min_raise, max_raise, remaining_chips)
        else:
            return self.postflop_action(round_state, amount_to_call, min_raise, max_raise, remaining_chips)

    def preflop_action(self, round_state: RoundStateClient, amount_to_call: int, 
                      min_raise: int, max_raise: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.my_cards:
            return (PokerAction.FOLD, 0)
            
        hand_str = self.get_hand_group(self.my_cards)
        n = len(self.initial_players)
        my_index = self.initial_players.index(self.id)
        distance = (my_index - self.button_index) % n
        position = self.get_position(distance, n)

        if hand_str in self.group1 or hand_str in self.group2:
            if amount_to_call == 0:
                raise_amount = min(3 * self.current_bb, max_raise)
                if raise_amount < min_raise:
                    raise_amount = min_raise
                if raise_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, raise_amount)
            else:
                if hand_str in self.group1:
                    raise_amount = min(amount_to_call + min_raise, max_raise)
                    if raise_amount < min_raise:
                        raise_amount = min_raise
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    if amount_to_call <= 5 * self.current_bb:
                        if amount_to_call >= remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                    
        elif hand_str in self.group3 or hand_str in self.group4:
            if amount_to_call == 0:
                if position in ['button', 'cutoff']:
                    raise_amount = min(3 * self.current_bb, max_raise)
                    if raise_amount < min_raise:
                        raise_amount = min_raise
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if amount_to_call <= 3 * self.current_bb:
                    if amount_to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        else:
            if amount_to_call == 0 and position in ['button', 'small_blind', 'big_blind']:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

    def postflop_action(self, round_state: RoundStateClient, amount_to_call: int, 
                       min_raise: int, max_raise: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        hand_strength = self.evaluate_hand(self.my_cards, round_state.community_cards)
        base = hand_strength[0] if hand_strength else 0
        pot = round_state.pot

        if base >= 3:
            if base >= 6:
                if amount_to_call > 0:
                    raise_amount = min(amount_to_call + min_raise, max_raise)
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    bet_amount = min(max(pot // 2, min_raise), max_raise)
                    if bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, bet_amount)
            else:
                if amount_to_call > 0:
                    if amount_to_call <= pot // 3:
                        if amount_to_call >= remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    bet_amount = min(max(pot // 4, min_raise), max_raise)
                    if bet_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, bet_amount)
        else:
            is_draw, outs = self.check_draw(self.my_cards, round_state.community_cards)
            if is_draw:
                if round_state.round == 'Flop':
                    probability = outs * 4.0 / 100
                else:
                    probability = outs * 2.0 / 100
                pot_odds = amount_to_call / (pot + amount_to_call + 1e-8)
                if probability > pot_odds:
                    if amount_to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)

    def get_hand_group(self, hole_cards: List[str]) -> str:
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        idx1 = self.rank_map[rank1]
        idx2 = self.rank_map[rank2]
        
        if idx1 == idx2:
            return rank1 + rank2
        
        suited = 's' if suit1 == suit2 else 'o'
        if idx1 > idx2:
            return rank1 + rank2 + suited
        return rank2 + rank1 + suited

    def get_position(self, distance: int, n: int) -> str:
        positions = ['button', 'small_blind', 'big_blind', 'UTG', 'middle', 'cutoff']
        if distance < len(positions):
            return positions[distance]
        return 'UTG'

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole_cards + community_cards
        converted = []
        for card in all_cards:
            rank, suit = card[0], card[1]
            converted.append((self.rank_map[rank], suit))
        
        suits = {}
        for r, s in converted:
            if s not in suits:
                suits[s] = []
            suits[s].append(r)
        
        flush_high = None
        for suit, ranks in suits.items():
            if len(ranks) >= 5:
                flush_ranks = sorted(ranks, reverse=True)[:5]
                straight_flush = self.check_straight(flush_ranks)
                if straight_flush:
                    return (8, straight_flush)
                flush_high = (5, flush_ranks)
        
        all_ranks = sorted(set([r for r, s in converted]), reverse=True)
        straight_high = self.check_straight(all_ranks)
        if straight_high:
            return (4, straight_high)
        
        if flush_high:
            return flush_high
        
        rank_count = {}
        for r, _ in converted:
            rank_count[r] = rank_count.get(r, 0) + 1
        groups = sorted(rank_count.items(), key=lambda x: (-x[1], -x[0]))
        
        if groups[0][1] == 4:
            return (7, [groups[0][0], groups[1][0]])
        if groups[0][1] == 3 and groups[1][1] >= 2:
            return (6, [groups[0][0], groups[1][0]])
        if groups[0][1] == 3:
            kickers = [g[0] for g in groups[1:] if g[1] < 3][:2]
            return (3, [groups[0][0]] + kickers)
        if groups[0][1] == 2 and groups[1][1] == 2:
            kicker = [g[0] for g in groups[2:] if g[1] < 2][0]
            return (2, [groups[0][0], groups[1][0], kicker])
        if groups[0][1] == 2:
            kickers = [g[0] for g in groups[1:] if g[1] < 2][:3]
            return (1, [groups[0][0]] + kickers)
        
        return (0, all_ranks[:5])

    def check_straight(self, ranks: List[int]) -> List[int]:
        unique_ranks = sorted(set(ranks), reverse=True)
        if 12 in unique_ranks:
            unique_ranks.append(-1)
        
        straight_high = None
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight_high = unique_ranks[i]
                break
        
        if straight_high is None:
            return None
        return [straight_high - i for i in range(5)]

    def check_draw(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[bool, int]:
        all_cards = hole_cards + community_cards
        converted = []
        for card in all_cards:
            rank, suit = card[0], card[1]
            converted.append((self.rank_map[rank], suit))
        
        suits = {}
        for r, s in converted:
            if s not in suits:
                suits[s] = []
            suits[s].append(r)
        
        flush_outs = 0
        for suit, ranks in suits.items():
            if len(ranks) == 4:
                flush_outs = 9
        
        all_ranks = sorted(set([r for r, s in converted]), reverse=True)
        straight_outs = 0
        for i in range(len(all_ranks) - 1):
            gap = all_ranks[i] - all_ranks[i+1]
            if gap == 2:
                straight_outs += 4
            elif gap == 1:
                straight_outs += 0
        
        total_outs = flush_outs + straight_outs
        return (total_outs > 0, total_outs)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.button_index = (self.button_index + 1) % len(self.initial_players)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                   all_scores: dict, active_players_hands: dict) -> None:
        pass