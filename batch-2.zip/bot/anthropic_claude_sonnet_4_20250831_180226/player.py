from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.position = None
        self.opponent_tendencies = {
            'aggression': 0.5,  # Track opponent aggression
            'fold_frequency': 0.5
        }
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self.evaluate_hand_strength(self.hand, round_state.community_cards)
            
            # Get pot odds
            pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
            
            # Determine position advantage
            position_factor = self.get_position_factor(round_state)
            
            # Calculate call amount needed
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Determine action based on hand strength and situation
            if call_amount == 0:  # No bet to call
                if hand_strength > 0.7 or (hand_strength > 0.4 and position_factor > 0.5):
                    # Strong hand or decent hand in good position - bet/raise
                    if round_state.min_raise > 0:
                        bet_size = self.calculate_bet_size(round_state, hand_strength, remaining_chips)
                        if bet_size >= round_state.min_raise and bet_size <= round_state.max_raise:
                            return (PokerAction.RAISE, bet_size)
                # Otherwise check
                return (PokerAction.CHECK, 0)
            else:
                # There's a bet to call
                if hand_strength > 0.8:
                    # Very strong hand - raise if possible
                    if round_state.min_raise > 0:
                        raise_size = self.calculate_raise_size(round_state, hand_strength, remaining_chips)
                        if raise_size >= round_state.min_raise and raise_size <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_size)
                    # Can't raise, just call
                    return (PokerAction.CALL, 0)
                elif hand_strength > 0.5 or pot_odds > 0.3:
                    # Decent hand or good pot odds - call
                    return (PokerAction.CALL, 0)
                elif hand_strength > 0.3 and call_amount <= remaining_chips * 0.05:
                    # Marginal hand but cheap to call
                    return (PokerAction.CALL, 0)
                else:
                    # Weak hand - fold
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Fallback to safe action if any error occurs
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.1:  # Call if cheap
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def calculate_bet_size(self, round_state: RoundStateClient, hand_strength: float, remaining_chips: int) -> int:
        """Calculate appropriate bet size for raising when no current bet"""
        base_bet = max(round_state.min_raise, self.blind_amount)
        
        if hand_strength > 0.8:
            # Strong hand - bet bigger
            bet_size = int(base_bet * 3)
        elif hand_strength > 0.6:
            # Good hand - standard bet
            bet_size = int(base_bet * 2)
        else:
            # Marginal hand - small bet
            bet_size = base_bet
            
        # Ensure bet is within limits
        bet_size = max(bet_size, round_state.min_raise)
        bet_size = min(bet_size, round_state.max_raise)
        bet_size = min(bet_size, remaining_chips)
        
        return bet_size
    
    def calculate_raise_size(self, round_state: RoundStateClient, hand_strength: float, remaining_chips: int) -> int:
        """Calculate appropriate raise size when there's already a bet"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if hand_strength > 0.9:
            # Extremely strong - big raise
            raise_amount = int(call_amount + round_state.pot * 0.8)
        elif hand_strength > 0.7:
            # Strong hand - standard raise
            raise_amount = int(call_amount + round_state.pot * 0.5)
        else:
            # Decent hand - small raise
            raise_amount = int(call_amount + round_state.min_raise)
            
        # Ensure raise meets minimum requirements
        min_total_bet = round_state.current_bet + round_state.min_raise
        total_bet_needed = min_total_bet - my_current_bet
        raise_amount = max(raise_amount, total_bet_needed)
        
        # Ensure within limits
        raise_amount = min(raise_amount, round_state.max_raise)
        raise_amount = min(raise_amount, remaining_chips)
        
        return raise_amount
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on scale 0-1"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.3
            
        card1, card2 = hole_cards
        rank1, suit1 = self.parse_card(card1)
        rank2, suit2 = self.parse_card(card2)
        
        # Base hand evaluation (preflop)
        strength = 0.0
        
        # High card values
        high_cards = max(rank1, rank2)
        if high_cards >= 11:  # Face cards
            strength += 0.3
        elif high_cards >= 9:  # 9, 10
            strength += 0.2
        elif high_cards >= 7:  # 7, 8
            strength += 0.1
            
        # Pair bonus
        if rank1 == rank2:
            strength += 0.4
            if rank1 >= 10:  # High pairs
                strength += 0.3
                
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
            
        # Connected cards bonus
        if abs(rank1 - rank2) == 1:
            strength += 0.1
        elif abs(rank1 - rank2) <= 3:
            strength += 0.05
            
        # Ace high bonus
        if max(rank1, rank2) == 14:
            strength += 0.15
            
        # Post-flop evaluation
        if community_cards:
            all_cards = hole_cards + community_cards
            post_flop_strength = self.evaluate_post_flop(all_cards, hole_cards)
            strength = max(strength, post_flop_strength)
            
        return min(strength, 1.0)
    
    def evaluate_post_flop(self, all_cards: List[str], hole_cards: List[str]) -> float:
        """Evaluate hand strength after flop/turn/river"""
        if len(all_cards) < 5:
            return 0.3
            
        # Parse all cards
        parsed_cards = [self.parse_card(card) for card in all_cards]
        ranks = [card[0] for card in parsed_cards]
        suits = [card[1] for card in parsed_cards]
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for various hands
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Four of a kind
        if max_rank_count >= 4:
            return 0.95
            
        # Full house
        if max_rank_count >= 3 and len([count for count in rank_counts.values() if count >= 2]) >= 2:
            return 0.9
            
        # Flush
        if max_suit_count >= 5:
            return 0.8
            
        # Straight check (simplified)
        sorted_ranks = sorted(set(ranks))
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    return 0.75
                    
        # Three of a kind
        if max_rank_count >= 3:
            return 0.7
            
        # Two pair
        pairs = [rank for rank, count in rank_counts.items() if count >= 2]
        if len(pairs) >= 2:
            return 0.6
            
        # One pair
        if max_rank_count >= 2:
            pair_rank = max([rank for rank, count in rank_counts.items() if count >= 2])
            if pair_rank >= 10:  # High pair
                return 0.55
            else:
                return 0.45
                
        # High card
        return 0.3
    
    def parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank and suit"""
        if len(card) != 2:
            return (7, 'h')  # Default fallback
            
        rank_char = card[0]
        suit = card[1]
        
        if rank_char == 'A':
            rank = 14
        elif rank_char == 'K':
            rank = 13
        elif rank_char == 'Q':
            rank = 12
        elif rank_char == 'J':
            rank = 11
        elif rank_char == 'T':
            rank = 10
        else:
            try:
                rank = int(rank_char)
            except:
                rank = 7  # Default
                
        return (rank, suit)
    
    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 1.0
            
        total_pot = round_state.pot + call_amount
        return (total_pot + 0.001) / (call_amount + 0.001)  # Add small epsilon to avoid division by zero
    
    def get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage (simplified)"""
        return 0.5  # Neutral position for now
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass