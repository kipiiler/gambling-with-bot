from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_history = []
        self.opponent_aggression = 0.5  # Track opponent aggression level
        self.hands_played = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.hands_played += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Calculate pot odds and betting context
        pot_size = round_state.pot
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Ensure we don't call more than we have
        call_amount = min(call_amount, remaining_chips)
        
        # Position and aggression adjustments
        position_factor = self._get_position_factor(round_state)
        opponent_aggression = self._estimate_opponent_aggression(round_state)
        
        # Adjust strategy based on stack size
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)  # Avoid division by zero
        
        # Decision logic based on hand strength and context
        if hand_strength >= 0.85:  # Very strong hands
            return self._handle_strong_hand(round_state, remaining_chips, call_amount, pot_size)
        elif hand_strength >= 0.65:  # Good hands
            return self._handle_good_hand(round_state, remaining_chips, call_amount, pot_size, position_factor)
        elif hand_strength >= 0.4:  # Medium hands
            return self._handle_medium_hand(round_state, remaining_chips, call_amount, pot_size, position_factor, stack_ratio)
        else:  # Weak hands
            return self._handle_weak_hand(round_state, remaining_chips, call_amount, position_factor, stack_ratio)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        # Convert cards to values and suits
        def card_value(card):
            if not card or len(card) < 2:
                return 0
            rank = card[0]
            if rank == 'A': return 14
            elif rank == 'K': return 13
            elif rank == 'Q': return 12
            elif rank == 'J': return 11
            elif rank == 'T': return 10
            else: return int(rank)
        
        def card_suit(card):
            return card[1] if card and len(card) >= 2 else ''
        
        hole_values = [card_value(card) for card in hole_cards]
        hole_suits = [card_suit(card) for card in hole_cards]
        
        # Pre-flop evaluation
        if not community_cards:
            return self._evaluate_preflop_strength(hole_values, hole_suits)
        
        # Post-flop evaluation
        all_cards = hole_cards + community_cards
        all_values = [card_value(card) for card in all_cards]
        all_suits = [card_suit(card) for card in all_cards]
        
        return self._evaluate_postflop_strength(all_values, all_suits, hole_values)
    
    def _evaluate_preflop_strength(self, hole_values: List[int], hole_suits: List[str]) -> float:
        """Evaluate pre-flop hand strength"""
        if len(hole_values) < 2:
            return 0.0
            
        high_card = max(hole_values)
        low_card = min(hole_values)
        is_pair = hole_values[0] == hole_values[1]
        is_suited = hole_suits[0] == hole_suits[1]
        gap = abs(hole_values[0] - hole_values[1])
        
        # Premium pairs
        if is_pair and high_card >= 11:  # JJ, QQ, KK, AA
            return 0.9 + (high_card - 11) * 0.025
        
        # Medium pairs
        if is_pair and high_card >= 8:
            return 0.7 + (high_card - 8) * 0.05
        
        # Small pairs
        if is_pair:
            return 0.5 + (high_card - 2) * 0.03
        
        # High cards
        if high_card >= 13:  # Ace or King high
            if low_card >= 11:  # AK, AQ, AJ, KQ
                return 0.8 if is_suited else 0.75
            elif low_card >= 9:  # AT, A9, KJ, KT
                return 0.65 if is_suited else 0.6
            else:
                return 0.4 if is_suited else 0.35
        
        # Suited connectors and one-gappers
        if is_suited and gap <= 1 and high_card >= 9:
            return 0.6
        elif is_suited and gap <= 2 and high_card >= 10:
            return 0.55
        
        # Connected cards
        if gap <= 1 and high_card >= 10:
            return 0.45
        
        # Default for other hands
        return max(0.1, (high_card + low_card - 4) / 24.0)
    
    def _evaluate_postflop_strength(self, all_values: List[int], all_suits: List[str], hole_values: List[int]) -> float:
        """Evaluate post-flop hand strength"""
        # Count cards by value and suit
        value_counts = {}
        suit_counts = {}
        
        for i, value in enumerate(all_values):
            if value > 0:  # Valid card
                value_counts[value] = value_counts.get(value, 0) + 1
                if i < len(all_suits):
                    suit = all_suits[i]
                    suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for different hand types
        pairs = [v for v, c in value_counts.items() if c >= 2]
        trips = [v for v, c in value_counts.items() if c >= 3]
        quads = [v for v, c in value_counts.items() if c >= 4]
        
        # Flush check
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        is_flush = max_suit_count >= 5
        
        # Straight check
        sorted_values = sorted(set(all_values))
        is_straight = self._check_straight(sorted_values)
        
        # Hand ranking
        if quads:
            return 0.95
        elif trips and len(pairs) >= 2:  # Full house
            return 0.9
        elif is_flush:
            return 0.85
        elif is_straight:
            return 0.8
        elif trips:
            return 0.75
        elif len(pairs) >= 2:  # Two pair
            # Check if we have a pocket pair
            hole_pair = hole_values[0] == hole_values[1]
            our_pairs = [p for p in pairs if p in hole_values]
            if hole_pair or len(our_pairs) >= 1:
                return 0.65
            else:
                return 0.45  # Board pairs
        elif pairs:
            # Check if it's our pair
            our_pair = any(p in hole_values for p in pairs)
            if our_pair:
                pair_strength = max(pairs) / 14.0
                return 0.4 + pair_strength * 0.2
            else:
                return 0.25  # Board pair only
        else:
            # High card - check if we have top pair potential
            high_hole = max(hole_values)
            return max(0.1, high_hole / 14.0 * 0.3)
    
    def _check_straight(self, sorted_values: List[int]) -> bool:
        """Check if values contain a straight"""
        if len(sorted_values) < 5:
            return False
        
        # Check for wheel straight (A,2,3,4,5)
        if 14 in sorted_values and all(x in sorted_values for x in [2, 3, 4, 5]):
            return True
        
        # Check for regular straights
        for i in range(len(sorted_values) - 4):
            if sorted_values[i+4] - sorted_values[i] == 4:
                return True
        
        return False
    
    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Get position factor (higher = better position)"""
        # In heads-up, being the small blind means acting first pre-flop (worse position)
        # but acting last post-flop (better position)
        if round_state.round == "Preflop":
            return 0.4  # Simplified for heads-up
        else:
            return 0.6
    
    def _estimate_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Estimate opponent aggression based on betting patterns"""
        # Simple aggression estimation based on pot size vs blinds
        if round_state.pot > self.blind_amount * 4:
            return 0.7  # Aggressive
        elif round_state.pot > self.blind_amount * 2:
            return 0.5  # Moderate
        else:
            return 0.3  # Passive
    
    def _handle_strong_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int) -> Tuple[PokerAction, int]:
        """Handle very strong hands (>= 0.85 strength)"""
        if call_amount == 0:
            # We can check or bet
            bet_size = max(round_state.min_raise, min(pot_size // 2, remaining_chips))
            if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Someone bet, we should raise or call
            if call_amount <= remaining_chips // 4:  # Don't risk too much of stack
                raise_size = max(round_state.min_raise, min(call_amount * 3, remaining_chips))
                current_bet = round_state.player_bets.get(str(self.id), 0)
                total_bet = current_bet + raise_size
                
                if total_bet > round_state.current_bet and raise_size <= remaining_chips:
                    return (PokerAction.RAISE, raise_size)
            
            # Fall back to calling if we can't raise properly
            if call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
    
    def _handle_good_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int, position_factor: float) -> Tuple[PokerAction, int]:
        """Handle good hands (0.65-0.84 strength)"""
        if call_amount == 0:
            # Consider betting for value
            if position_factor > 0.5:
                bet_size = max(round_state.min_raise, min(pot_size // 3, remaining_chips // 2))
                if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:
            # Call reasonable bets, fold to very large bets
            if call_amount <= pot_size // 2 and call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _handle_medium_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int, position_factor: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        """Handle medium hands (0.4-0.64 strength)"""
        if call_amount == 0:
            # Check or small bet depending on position
            if position_factor > 0.6 and round_state.round == "Preflop":
                bet_size = max(round_state.min_raise, min(self.blind_amount * 2, remaining_chips // 3))
                if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:
            # Call small bets, fold to big bets
            pot_odds = call_amount / (pot_size + call_amount + 0.001)
            if pot_odds < 0.3 and call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _handle_weak_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, position_factor: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        """Handle weak hands (< 0.4 strength)"""
        if call_amount == 0:
            # Usually check, occasionally bluff if in good position
            if position_factor > 0.7 and round_state.round == "Preflop" and stack_ratio > 0.8:
                # Occasional bluff
                if self.hands_played % 7 == 0:  # Bluff roughly 1 in 7 times
                    bet_size = max(round_state.min_raise, min(self.blind_amount * 3, remaining_chips // 4))
                    if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:
            # Generally fold, but call very small bets with decent pot odds
            pot_odds = call_amount / (pot_size + call_amount + 0.001)
            if pot_odds < 0.15 and call_amount <= self.blind_amount and call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game results for learning
        chip_change = remaining_chips - (self.starting_chips - (round_state.pot if round_state.pot else 0))
        self.game_history.append({
            'round': round_state.round_num,
            'result': chip_change,
            'final_pot': round_state.pot
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hole_cards = []
        # Keep learning data across games for adaptation