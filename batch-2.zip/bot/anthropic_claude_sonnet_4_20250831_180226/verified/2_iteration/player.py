from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.position = None  # 'SB' for small blind, 'BB' for big blind
        self.opponent_tendencies = {
            'aggression': 0.5,  # Track opponent aggression
            'fold_to_bet': 0.5,  # Track fold frequency
            'bet_frequency': 0.5  # Track betting frequency
        }
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.position = 'SB' if self.id == small_blind_player_id else 'BB'

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Main decision-making method"""
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds and implied odds
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001)  # Avoid division by zero
        
        # Position factor (more aggressive in position)
        position_factor = 1.2 if self.position == 'BB' and len(round_state.current_player) == 2 else 1.0
        
        # Opponent modeling
        opponent_aggression = self._estimate_opponent_aggression(round_state)
        
        # Stack-to-pot ratio
        spr = remaining_chips / (round_state.pot + 0.001)
        
        # Decision tree based on round and hand strength
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, position_factor)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, spr, opponent_aggression)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        val1, val2 = rank_values.get(rank1, 7), rank_values.get(rank2, 7)
        
        # Base strength calculation
        high_card = max(val1, val2) / 14.0
        pair_bonus = 0.3 if val1 == val2 else 0
        suited_bonus = 0.1 if suit1 == suit2 else 0
        connector_bonus = 0.05 if abs(val1 - val2) <= 1 else 0
        ace_bonus = 0.15 if val1 == 14 or val2 == 14 else 0
        
        preflop_strength = min(1.0, high_card + pair_bonus + suited_bonus + connector_bonus + ace_bonus)
        
        if round_state.round == 'Preflop':
            return preflop_strength
        
        # Post-flop evaluation with community cards
        return self._evaluate_postflop_strength(round_state.community_cards, preflop_strength)

    def _evaluate_postflop_strength(self, community_cards: List[str], preflop_strength: float) -> float:
        """Simplified post-flop hand evaluation"""
        if not community_cards:
            return preflop_strength
        
        all_cards = self.hole_cards + community_cards
        if len(all_cards) < 5:
            return preflop_strength * 0.8  # Reduce confidence with incomplete board
        
        # Simple heuristics for post-flop strength
        # This is a simplified version - in practice, you'd want more sophisticated hand evaluation
        
        # Count pairs, potential straights/flushes
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for made hands
        max_rank_count = max(rank_counts.values()) if rank_counts else 1
        max_suit_count = max(suit_counts.values()) if suit_counts else 1
        
        if max_rank_count >= 4:  # Four of a kind or better
            return 0.95
        elif max_rank_count == 3:  # Three of a kind
            return 0.8
        elif max_suit_count >= 5:  # Flush
            return 0.85
        elif max_rank_count == 2:  # Pair
            pairs = sum(1 for count in rank_counts.values() if count == 2)
            if pairs >= 2:  # Two pair
                return 0.7
            else:  # One pair
                return 0.6
        
        return min(0.9, preflop_strength + 0.1)  # High card with board texture bonus

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_factor: float) -> Tuple[PokerAction, int]:
        """Preflop decision making"""
        
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        adjusted_strength = hand_strength * position_factor
        
        # Very strong hands - always raise/call
        if adjusted_strength >= 0.8:
            if round_state.current_bet == 0:
                raise_size = min(round_state.pot // 2 + 10, remaining_chips)
                return (PokerAction.RAISE, raise_size)
            elif call_amount <= remaining_chips * 0.1:  # Reasonable call
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
        
        # Strong hands
        elif adjusted_strength >= 0.65:
            if round_state.current_bet == 0:
                raise_size = min(round_state.pot // 3 + 5, remaining_chips)
                return (PokerAction.RAISE, raise_size)
            elif call_amount <= remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif adjusted_strength >= 0.45:
            if round_state.current_bet == 0:
                if position_factor > 1.0:  # In position, more aggressive
                    return (PokerAction.RAISE, min(15, remaining_chips))
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.02:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, spr: float, opponent_aggression: float) -> Tuple[PokerAction, int]:
        """Post-flop decision making"""
        
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Very strong hands - bet for value
        if hand_strength >= 0.8:
            if round_state.current_bet == 0:
                bet_size = min(int(round_state.pot * 0.75), remaining_chips)
                return (PokerAction.RAISE, bet_size)
            else:
                if call_amount <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        
        # Strong hands
        elif hand_strength >= 0.65:
            if round_state.current_bet == 0:
                bet_size = min(int(round_state.pot * 0.5), remaining_chips)
                return (PokerAction.RAISE, bet_size)
            else:
                if pot_odds < 0.3:  # Good pot odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Medium hands - play cautiously
        elif hand_strength >= 0.5:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                if pot_odds < 0.2 and call_amount <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Weak hands with bluff potential
        elif hand_strength >= 0.3 and opponent_aggression < 0.6:
            if round_state.current_bet == 0 and round_state.round in ['Turn', 'River']:
                # Bluff bet
                bluff_size = min(int(round_state.pot * 0.6), remaining_chips // 3)
                return (PokerAction.RAISE, bluff_size)
            else:
                return (PokerAction.FOLD, 0) if round_state.current_bet > 0 else (PokerAction.CHECK, 0)
        
        # Very weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _estimate_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Estimate opponent aggression based on betting patterns"""
        # Simple heuristic based on current betting
        if round_state.current_bet > round_state.pot:
            return 0.8  # Very aggressive
        elif round_state.current_bet > round_state.pot * 0.5:
            return 0.6  # Moderately aggressive
        else:
            return 0.4  # Conservative

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Update opponent modeling"""
        # Track game history for opponent modeling
        self.game_history.append({
            'round': round_state.round,
            'pot': round_state.pot,
            'current_bet': round_state.current_bet,
            'remaining_chips': remaining_chips
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Learn from game results"""
        # Update opponent tendencies based on revealed hands and actions
        pass