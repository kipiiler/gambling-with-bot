from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.position = None
        self.opponent_stats = {}
        self.hand_history = []
        self.current_round_actions = []
        self.aggression_factor = 1.2
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggression': 0.5,
                    'fold_to_aggression': 0.5,
                    'recent_actions': []
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_actions = []
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = call_amount / (round_state.pot + call_amount + 1e-6)
            
            # Position analysis
            position_factor = self._get_position_factor(round_state)
            
            # Opponent analysis
            opponent_factor = self._analyze_opponents(round_state)
            
            # Bluff factor
            bluff_factor = self._calculate_bluff_factor(round_state, remaining_chips)
            
            # Adjust hand strength based on factors
            adjusted_strength = hand_strength * position_factor * opponent_factor + bluff_factor
            
            # Action decision logic
            action, amount = self._decide_action(round_state, remaining_chips, adjusted_strength, pot_odds)
            
            # Update tracking
            self._update_action_tracking(round_state, action, amount)
            
            return action, amount
            
        except Exception as e:
            # Emergency fallback
            if round_state.current_bet > round_state.player_bets.get(str(self.id), 0):
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate current hand strength from 0 to 1"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert ranks to numeric values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        
        # Pre-flop evaluation
        if round_state.round == 'Preflop':
            strength = self._preflop_strength(val1, val2, suit1 == suit2)
        else:
            # Post-flop evaluation with community cards
            strength = self._postflop_strength(round_state.community_cards)
            
        return min(1.0, max(0.0, strength))

    def _preflop_strength(self, val1: int, val2: int, suited: bool) -> float:
        """Calculate pre-flop hand strength"""
        high_val, low_val = max(val1, val2), min(val1, val2)
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # TT+
                return 0.9
            elif val1 >= 7:  # 77-99
                return 0.75
            else:  # 22-66
                return 0.6
                
        # High cards
        if high_val == 14:  # Ace
            if low_val >= 10:  # AK, AQ, AJ, AT
                return 0.85 if suited else 0.8
            elif low_val >= 6:  # A6+
                return 0.7 if suited else 0.6
            else:  # A2-A5
                return 0.55 if suited else 0.45
                
        if high_val == 13:  # King
            if low_val >= 10:  # KQ, KJ, KT
                return 0.75 if suited else 0.7
            elif low_val >= 8:  # K8+
                return 0.6 if suited else 0.5
                
        if high_val == 12 and low_val >= 10:  # QJ, QT
            return 0.65 if suited else 0.6
            
        if high_val == 11 and low_val == 10:  # JT
            return 0.6 if suited else 0.55
            
        # Connected cards
        if abs(high_val - low_val) == 1 and low_val >= 6:
            return 0.55 if suited else 0.45
            
        # Suited connectors
        if suited and abs(high_val - low_val) <= 2 and low_val >= 5:
            return 0.5
            
        return 0.3

    def _postflop_strength(self, community_cards: List[str]) -> float:
        """Calculate post-flop hand strength"""
        if not community_cards:
            return self._preflop_strength(*self._get_card_values())
            
        all_cards = self.hole_cards + community_cards
        hand_rank = self._get_hand_rank(all_cards)
        
        # Convert hand rank to strength
        strength_map = {
            9: 1.0,    # Royal flush
            8: 0.95,   # Straight flush
            7: 0.9,    # Four of a kind
            6: 0.85,   # Full house
            5: 0.8,    # Flush
            4: 0.75,   # Straight
            3: 0.65,   # Three of a kind
            2: 0.55,   # Two pair
            1: 0.4,    # One pair
            0: 0.2     # High card
        }
        
        base_strength = strength_map.get(hand_rank, 0.2)
        
        # Adjust for draws
        draw_strength = self._evaluate_draws(community_cards)
        
        return min(1.0, base_strength + draw_strength)

    def _get_hand_rank(self, cards: List[str]) -> int:
        """Get hand ranking (0=high card, 9=royal flush)"""
        if len(cards) < 5:
            return 0
            
        # Convert cards to ranks and suits
        ranks = []
        suits = []
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in cards:
            if len(card) >= 2:
                ranks.append(rank_values.get(card[0], 2))
                suits.append(card[1])
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        sorted_ranks = sorted(ranks, reverse=True)
        is_flush = len(set(suits)) <= 1 and len(suits) >= 5
        is_straight = self._is_straight(sorted_ranks)
        
        counts = sorted(rank_counts.values(), reverse=True)
        
        # Royal flush
        if is_flush and is_straight and max(ranks) == 14 and min(ranks) >= 10:
            return 9
        # Straight flush
        if is_flush and is_straight:
            return 8
        # Four of a kind
        if counts[0] == 4:
            return 7
        # Full house
        if counts[0] == 3 and counts[1] == 2:
            return 6
        # Flush
        if is_flush:
            return 5
        # Straight
        if is_straight:
            return 4
        # Three of a kind
        if counts[0] == 3:
            return 3
        # Two pair
        if counts[0] == 2 and counts[1] == 2:
            return 2
        # One pair
        if counts[0] == 2:
            return 1
        # High card
        return 0

    def _is_straight(self, ranks: List[int]) -> bool:
        """Check if ranks form a straight"""
        unique_ranks = sorted(set(ranks), reverse=True)
        if len(unique_ranks) < 5:
            return False
            
        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                return True
                
        # Check for A-2-3-4-5 straight
        if set([14, 5, 4, 3, 2]).issubset(set(unique_ranks)):
            return True
            
        return False

    def _evaluate_draws(self, community_cards: List[str]) -> float:
        """Evaluate drawing potential"""
        if len(community_cards) < 3:
            return 0
            
        all_cards = self.hole_cards + community_cards
        
        # Flush draw
        suits = {}
        for card in all_cards:
            if len(card) >= 2:
                suit = card[1]
                suits[suit] = suits.get(suit, 0) + 1
                
        max_suit_count = max(suits.values()) if suits else 0
        if max_suit_count == 4:
            return 0.15  # Strong flush draw
        elif max_suit_count == 3 and len(community_cards) == 3:
            return 0.1   # Flush draw on flop
            
        # Straight draw (simplified)
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = []
        for card in all_cards:
            if len(card) >= 2:
                ranks.append(rank_values.get(card[0], 2))
                
        unique_ranks = sorted(set(ranks))
        
        # Open-ended straight draw
        if len(unique_ranks) >= 4:
            for i in range(len(unique_ranks) - 3):
                if unique_ranks[i+3] - unique_ranks[i] == 3:
                    return 0.12
                    
        return 0

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor"""
        num_players = len(round_state.current_player)
        if num_players <= 1:
            return 1.0
            
        # In heads-up, button has advantage
        if num_players == 2:
            return 1.1  # Assume we're in good position
            
        return 1.0

    def _analyze_opponents(self, round_state: RoundStateClient) -> float:
        """Analyze opponent behavior"""
        factor = 1.0
        
        for player_id, action in round_state.player_actions.items():
            if int(player_id) != self.id and int(player_id) in self.opponent_stats:
                stats = self.opponent_stats[int(player_id)]
                
                # Adjust based on opponent aggression
                if action in ['Raise', 'All-in']:
                    factor *= 0.9  # Be more cautious against aggression
                elif action == 'Fold':
                    factor *= 1.1  # Be more aggressive against folders
                    
        return factor

    def _calculate_bluff_factor(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate bluffing opportunity"""
        # Don't bluff with short stack
        if remaining_chips < round_state.pot * 2:
            return 0
            
        # Bluff more on later streets
        round_multiplier = {'Preflop': 0, 'Flop': 0.05, 'Turn': 0.1, 'River': 0.15}
        base_bluff = round_multiplier.get(round_state.round, 0)
        
        # Bluff more in position
        position_bluff = 0.05 if len(round_state.current_player) == 2 else 0
        
        # Random element
        random_bluff = 0.1 if random.random() < 0.15 else 0
        
        return base_bluff + position_bluff + random_bluff

    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Make the final action decision"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # All-in scenarios
        if call_amount >= remaining_chips:
            if strength > 0.7:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
                
        # No current bet - can check or bet
        if round_state.current_bet == 0:
            if strength > 0.8:
                # Strong hand - bet for value
                bet_size = min(round_state.pot // 2, remaining_chips // 4)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
            elif strength > 0.6:
                # Medium hand - smaller bet or check
                if random.random() < 0.6:
                    bet_size = min(round_state.pot // 3, remaining_chips // 8)
                    if bet_size >= round_state.min_raise:
                        return PokerAction.RAISE, bet_size
            
            return PokerAction.CHECK, 0
            
        # Facing a bet
        else:
            # Strong hands - raise
            if strength > 0.85:
                raise_size = min(round_state.pot, remaining_chips - call_amount)
                if raise_size >= round_state.min_raise:
                    return PokerAction.RAISE, call_amount + raise_size
                else:
                    return PokerAction.CALL, 0
                    
            # Good hands - call or raise
            elif strength > 0.7:
                if random.random() < 0.7:
                    return PokerAction.CALL, 0
                else:
                    raise_size = min(round_state.pot // 2, remaining_chips - call_amount)
                    if raise_size >= round_state.min_raise:
                        return PokerAction.RAISE, call_amount + raise_size
                    else:
                        return PokerAction.CALL, 0
                        
            # Marginal hands - check pot odds
            elif strength > 0.4:
                if pot_odds < 0.3:  # Good odds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
            # Weak hands - fold
            else:
                return PokerAction.FOLD, 0

    def _update_action_tracking(self, round_state: RoundStateClient, action: PokerAction, amount: int):
        """Update internal tracking"""
        self.current_round_actions.append({
            'round': round_state.round,
            'action': action,
            'amount': amount,
            'pot_size': round_state.pot
        })

    def _get_card_values(self) -> Tuple[int, int]:
        """Get numeric values of hole cards"""
        if len(self.hole_cards) < 2:
            return 2, 2
            
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(self.hole_cards[0][0], 2)
        val2 = rank_values.get(self.hole_cards[1][0], 2)
        
        return val1, val2

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round"""
        # Update opponent modeling
        for player_id, action in round_state.player_actions.items():
            player_id_int = int(player_id)
            if player_id_int != self.id and player_id_int in self.opponent_stats:
                stats = self.opponent_stats[player_id_int]
                stats['hands_played'] += 1
                stats['recent_actions'].append(action)
                
                # Keep only recent actions
                if len(stats['recent_actions']) > 10:
                    stats['recent_actions'] = stats['recent_actions'][-10:]

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        # Learn from final results
        pass