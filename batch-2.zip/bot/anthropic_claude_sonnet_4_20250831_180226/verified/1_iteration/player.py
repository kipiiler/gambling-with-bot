from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.blind_amount = 0
        self.all_players = []
        self.opponent_stats = {}
        self.hand_history = []
        self.position_stats = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'vpip': 0,  # Voluntarily put money in pot
                    'pfr': 0,   # Pre-flop raise
                    'aggression': 0,
                    'showdowns': 0,
                    'wins': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate how much we need to call
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get position strength (later position is better)
        position_strength = self._get_position_strength(round_state)
        
        # Calculate pot odds if we need to call
        pot_odds = 0
        if call_amount > 0:
            pot_odds = call_amount / (round_state.pot + call_amount + 0.001)
        
        # Adjust strategy based on stack size
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, position_strength, call_amount, stack_ratio)
        
        # Post-flop strategy
        return self._postflop_strategy(round_state, remaining_chips, hand_strength, position_strength, call_amount, pot_odds, stack_ratio)

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_strength: float, call_amount: int, stack_ratio: float) -> Tuple[PokerAction, int]:
        # Premium hands - always play aggressively
        if hand_strength >= 0.9:
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.8))
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif call_amount < remaining_chips * 0.3:
                raise_amount = max(round_state.min_raise, call_amount * 3)
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.7:
            if call_amount == 0:
                if position_strength > 0.5:
                    raise_amount = max(round_state.min_raise, int(round_state.pot * 0.6))
                    if raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Decent hands
        elif hand_strength >= 0.5:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.1 and position_strength > 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_strength: float, call_amount: int, pot_odds: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        # Very strong hands
        if hand_strength >= 0.85:
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.7))
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                if call_amount < remaining_chips * 0.5:
                    raise_amount = max(round_state.min_raise, call_amount * 2)
                    if raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.65:
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.5))
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3 or call_amount < remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.25 and call_amount < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands but potential
        elif hand_strength >= 0.2:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.15 and call_amount < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Very weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.2
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        # Pre-flop evaluation
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(card1, card2)
        
        # Post-flop evaluation
        all_cards = self.hole_cards + round_state.community_cards
        return self._postflop_hand_strength(all_cards)

    def _preflop_hand_strength(self, card1: str, card2: str) -> float:
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        is_suited = suit1 == suit2
        is_pair = val1 == val2
        
        # High pairs
        if is_pair:
            if val1 >= 10:  # TT, JJ, QQ, KK, AA
                return 0.9 + (val1 - 10) * 0.02
            elif val1 >= 7:  # 77, 88, 99
                return 0.7 + (val1 - 7) * 0.05
            else:  # 22-66
                return 0.4 + (val1 - 2) * 0.04
        
        # High cards
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Premium non-pairs
        if high_card == 14:  # Ace
            if low_card >= 10:  # AK, AQ, AJ, AT
                base_strength = 0.75 + (low_card - 10) * 0.03
                return base_strength + (0.05 if is_suited else 0)
            elif low_card >= 7:  # A9, A8, A7
                base_strength = 0.55 + (low_card - 7) * 0.02
                return base_strength + (0.08 if is_suited else 0)
            else:  # A6 and below
                base_strength = 0.35 + (low_card - 2) * 0.02
                return base_strength + (0.1 if is_suited else 0)
        
        # King high
        elif high_card == 13:
            if low_card >= 10:  # KQ, KJ, KT
                base_strength = 0.6 + (low_card - 10) * 0.03
                return base_strength + (0.05 if is_suited else 0)
            else:
                base_strength = 0.3 + (low_card - 2) * 0.02
                return base_strength + (0.08 if is_suited else 0)
        
        # Queen high
        elif high_card == 12:
            if low_card >= 10:  # QJ, QT
                base_strength = 0.5 + (low_card - 10) * 0.03
                return base_strength + (0.05 if is_suited else 0)
            else:
                base_strength = 0.25 + (low_card - 2) * 0.02
                return base_strength + (0.08 if is_suited else 0)
        
        # Connected cards
        if abs(val1 - val2) <= 1 and min(val1, val2) >= 6:
            base_strength = 0.35 + (min(val1, val2) - 6) * 0.02
            return base_strength + (0.1 if is_suited else 0.05)
        
        # Suited connectors
        if is_suited and abs(val1 - val2) <= 4:
            return 0.3 + (min(val1, val2) - 2) * 0.015
        
        # Default weak hands
        return 0.15 + (high_card - 2) * 0.01

    def _postflop_hand_strength(self, all_cards: List[str]) -> float:
        if len(all_cards) < 5:
            return 0.3
        
        # Simple hand evaluation - in a real implementation, you'd want more sophisticated evaluation
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        values = [rank_values.get(rank, 2) for rank in ranks]
        
        # Count occurrences
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for different hand types
        counts = sorted(rank_counts.values(), reverse=True)
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        unique_values = sorted(set(values))
        is_straight = False
        if len(unique_values) >= 5:
            for i in range(len(unique_values) - 4):
                if unique_values[i+4] - unique_values[i] == 4:
                    is_straight = True
                    break
        
        # Hand rankings
        if is_straight and is_flush:
            return 0.95  # Straight flush
        elif counts[0] == 4:
            return 0.9   # Four of a kind
        elif counts[0] == 3 and counts[1] >= 2:
            return 0.85  # Full house
        elif is_flush:
            return 0.75  # Flush
        elif is_straight:
            return 0.65  # Straight
        elif counts[0] == 3:
            return 0.55  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 0.45  # Two pair
        elif counts[0] == 2:
            high_pair_value = 0
            for rank, count in rank_counts.items():
                if count == 2:
                    high_pair_value = rank_values.get(rank, 2)
            if high_pair_value >= 10:
                return 0.4   # High pair
            else:
                return 0.25  # Low pair
        else:
            # High card - check if we have high cards
            hole_values = [rank_values.get(self.hole_cards[0][0], 2), rank_values.get(self.hole_cards[1][0], 2)]
            if max(hole_values) >= 12:
                return 0.2
            else:
                return 0.1

    def _get_position_strength(self, round_state: RoundStateClient) -> float:
        if not self.all_players:
            return 0.5
        
        # Simple position calculation - later position is better
        try:
            my_position = self.all_players.index(self.id)
            return my_position / (len(self.all_players) + 0.001)
        except ValueError:
            return 0.5

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent statistics based on actions observed
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id in self.opponent_stats:
                self.opponent_stats[player_id]['hands_played'] += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Store game results for future analysis
        self.hand_history.append({
            'score': player_score,
            'final_chips': self.starting_chips + player_score,
            'opponents': list(all_scores.keys())
        })