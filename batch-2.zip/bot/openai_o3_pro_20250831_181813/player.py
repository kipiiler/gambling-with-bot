# player.py
from __future__ import annotations

import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    """
    A very small-footprint no-limit Texas Hold’em bot.

    High-level strategy (heads-up & 6-max):
        • Tight-aggressive pre-flop: raise / re-raise premium hands, fold trash.
        • Post-flop: use a light-weight 7-card evaluator to classify our hand;
          bet/raise strong made hands, call small with marginal hands, fold junk.
    The implementation purposefully stays simple to guarantee validity under all
    corner cases while still improving on a pure calling station that loses
    blinds every hand (iteration-3 behaviour).
    """

    # ---------- Helpers: basic card / hand utilities ---------- #
    RANK_TO_VAL = {'2': 2, '3': 3, '4': 4, '5': 5,
                   '6': 6, '7': 7, '8': 8, '9': 9,
                   'T': 10, 'J': 11, 'Q': 12, 'K': 13,
                   'A': 14}
    VAL_TO_RANK = {v: r for r, v in RANK_TO_VAL.items()}

    # Hand category strength (bigger is stronger)
    CATEGORY_NAME = [
        "High card", "Pair", "Two pair", "Trips",
        "Straight", "Flush", "Full house",
        "Quads", "Straight flush"
    ]

    def __init__(self) -> None:
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.hole_cards: List[str] = []
        self.table_players: List[int] = []
        # Remember min blind so we can size raises even when min_raise==0 later
        self.min_blind_seen: int = 1

    # ---------- Mandatory interface methods ---------- #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.min_blind_seen = max(1, self.small_blind)
        self.table_players = list(all_players)
        # player_hands contains _our_ two hole cards at game start
        self.hole_cards = list(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        A new hand begins – store fresh private cards if the server provides
        them inside the round_state structure (implementation dependent).
        """
        # Many engines deliver private cards in round_state.player_hands
        # (dict mapping player_id to ['Ah', 'Kd']) or directly as a list.
        if hasattr(round_state, "player_hands"):
            ph = round_state.player_hands
            if isinstance(ph, dict):
                self.hole_cards = ph.get(str(self.id), ph.get(self.id, []))
            elif isinstance(ph, list):
                # If list, assume those are our two cards
                self.hole_cards = list(ph)
        # Blind might change throughout the tournament
        self.min_blind_seen = max(self.min_blind_seen, round_state.min_raise or 1)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide an action given the current round_state.

        Return tuple: (PokerAction, amount) – amount is ignored for CHECK/CALL.
        """

        # --- Safety & convenience variables --- #
        pot = max(1, round_state.pot)  # avoid 0-division
        current_bet = round_state.current_bet
        already_put_in = round_state.player_bets.get(
            str(self.id), round_state.player_bets.get(self.id, 0)
        )
        call_amount = max(0, current_bet - already_put_in)
        min_raise = max(round_state.min_raise, self.min_blind_seen)
        max_raise = round_state.max_raise

        stage = round_state.round.lower()  # 'preflop', 'flop', ...
        # -------------------------------------------------------- #

        # -------- PRE-FLOP STRATEGY -------- #
        if stage == "preflop":
            preflop_strength = self._evaluate_preflop(self.hole_cards)

            # Garbage hand
            if preflop_strength == 0:
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Playable hand – call small / raise if unopened
            if preflop_strength == 1:
                # If we can limp for <= 2 BBs call, else fold
                if call_amount <= self.big_blind * 2:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Strong hand – raise or call small 3-bet
            if preflop_strength == 2:
                # If no bet yet, open raise 3 BBs
                if call_amount == 0:
                    raise_to = min(remaining_chips, max(min_raise, self.big_blind * 3))
                    return PokerAction.RAISE, raise_to
                # Facing a raise: call up to 5 BBs else fold
                if call_amount <= self.big_blind * 5:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Premium – (re-)raise / shove if short
            if preflop_strength >= 3:
                # Short stack: shove
                if remaining_chips <= self.big_blind * 10:
                    return PokerAction.ALL_IN, 0
                # Otherwise raise / re-raise
                raise_to = min(
                    remaining_chips,
                    max(min_raise, call_amount + self.big_blind * 3),
                )
                # If we cannot legally raise more than calling, just call
                if raise_to <= call_amount or raise_to > max_raise:
                    return PokerAction.CALL, 0
                return PokerAction.RAISE, raise_to

        # -------- POST-FLOP STRATEGY -------- #
        # Build a 7-card list (hole + community) for strength evaluation
        community = round_state.community_cards
        category = self._best_hand_category(self.hole_cards + community)

        # classify as strong / medium / weak
        if category >= 3:  # Trips or better
            # Bet / raise big
            if call_amount == 0:
                bet_size = min(
                    remaining_chips,
                    max(min_raise, int(pot * 0.75)),
                )
                if bet_size <= 0:
                    return PokerAction.CHECK, 0
                return PokerAction.RAISE, bet_size
            else:
                # facing a bet – raise or call depending on stack
                if remaining_chips <= call_amount * 2:
                    return PokerAction.ALL_IN, 0
                raise_to = min(
                    remaining_chips,
                    max(min_raise, call_amount * 2),
                )
                # Ensure legal raise
                if raise_to <= call_amount or raise_to > max_raise:
                    return PokerAction.CALL, 0
                return PokerAction.RAISE, raise_to

        elif category == 2:  # Two pair
            # Value-bet small or call reasonable bet
            if call_amount == 0:
                bet_size = min(remaining_chips, max(min_raise, int(pot * 0.4)))
                return PokerAction.RAISE, bet_size
            else:
                if call_amount <= int(pot * 0.4):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        elif category == 1:  # Single pair
            # Pot control – call tiny bets only
            if call_amount == 0:
                return PokerAction.CHECK, 0
            if call_amount <= int(pot * 0.15):
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        else:  # High card – mostly give up
            if call_amount == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No state to keep between hands for now
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[int, float],
        active_players_hands: Dict[int, List[str]],
    ):
        # Nothing persistent needed – could log if desired
        pass

    # ---------- Private helper methods ---------- #

    # ---- Pre-flop evaluator ---- #
    def _evaluate_preflop(self, hole_cards: List[str]) -> int:
        """
        Return an integer category describing starting-hand strength:
            0 = junk, 1 = playable, 2 = strong, 3 = premium
        """
        if len(hole_cards) != 2:
            return 0
        r1, s1 = hole_cards[0][0], hole_cards[0][1]
        r2, s2 = hole_cards[1][0], hole_cards[1][1]
        v1, v2 = self.RANK_TO_VAL[r1], self.RANK_TO_VAL[r2]
        suited = s1 == s2
        pair = r1 == r2

        high_card = max(v1, v2)
        low_card = min(v1, v2)

        # Pocket pairs
        if pair:
            if v1 >= 11:  # JJ, QQ, KK, AA
                return 3
            if v1 >= 8:  # 88-TT
                return 2
            if v1 >= 6:  # 66-77
                return 1
            return 0

        # Ax hands
        if r1 == 'A' or r2 == 'A':
            if high_card >= 13 and suited:  # AKs, AQs
                return 3
            if high_card >= 12:  # AKo, AQs, AJs
                return 2
            if suited or high_card >= 10:  # ATs/AJo etc.
                return 1
            return 0

        # Broadways & suited connectors
        is_connector = abs(v1 - v2) == 1
        both_high = v1 >= 10 and v2 >= 10

        if suited and both_high:
            return 2
        if suited and is_connector and high_card >= 10:
            return 1
        if both_high:
            return 1
        return 0

    # ---- Hand strength category for 7 cards ---- #
    def _best_hand_category(self, cards_7: List[str]) -> int:
        """
        Compute the highest 5-card hand category available in the supplied cards.
        Returns integer 0-8 (see CATEGORY_NAME).
        Optimised for simplicity over speed (7C5C = 21 iterations only).
        """
        if len(cards_7) < 5:
            return 0
        best_cat = 0
        for five_cards in itertools.combinations(cards_7, 5):
            cat = self._evaluate_five(five_cards)
            if cat > best_cat:
                best_cat = cat
                if best_cat == 8:  # Cannot beat straight flush
                    break
        return best_cat

    def _evaluate_five(self, five: Tuple[str, ...]) -> int:
        """
        Return category for a 5-card hand (0-8).
        """
        ranks = [card[0] for card in five]
        suits = [card[1] for card in five]
        vals = sorted([self.RANK_TO_VAL[r] for r in ranks], reverse=True)

        # Frequency of ranks
        freq: Dict[int, int] = {}
        for v in vals:
            freq[v] = freq.get(v, 0) + 1
        counts = sorted(freq.values(), reverse=True)  # e.g. [3,2] for full house

        is_flush = len(set(suits)) == 1
        is_straight = False
        unique_vals = sorted(set(vals), reverse=True)

        # Check straight with high Ace
        if len(unique_vals) >= 5:
            for i in range(len(unique_vals) - 4):
                window = unique_vals[i : i + 5]
                if window[0] - window[-1] == 4:
                    is_straight = True
                    break
            # Wheel A-5 straight
            if not is_straight and set([14, 5, 4, 3, 2]).issubset(unique_vals):
                is_straight = True

        # Straight flush
        if is_flush and is_straight:
            return 8
        # Quads
        if counts[0] == 4:
            return 7
        # Full house
        if counts[0] == 3 and counts[1] == 2:
            return 6
        # Flush
        if is_flush:
            return 5
        # Straight
        if is_straight:
            return 4
        # Trips
        if counts[0] == 3:
            return 3
        # Two pair
        if counts[0] == 2 and counts[1] == 2:
            return 2
        # One pair
        if counts[0] == 2:
            return 1
        # High card
        return 0