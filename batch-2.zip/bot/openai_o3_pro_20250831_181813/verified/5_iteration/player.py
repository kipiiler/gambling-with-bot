import itertools
import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_STR = "23456789TJQKA"
RANK_TO_INT = {r: i for i, r in enumerate(RANK_STR)}
INT_TO_RANK = {i: r for r, i in RANK_TO_INT.items()}


def _card_rank(card: str) -> int:
    """Return rank index of a single card (0 .. 12)."""
    return RANK_TO_INT[card[0]]


def _card_suit(card: str) -> str:
    """Return suit character of a single card."""
    return card[1]


class SimplePlayer(Bot):
    """
    A very small-foot-print rule based No-Limit Texas Hold’em bot.
    The bot plays tighter pre-flop and becomes aggressive with strong
    made hands post-flop.  All computations are pure python with zero
    external dependencies and are well within the 30 s / 100 MB limits.
    """

    # -------- Life-cycle hooks ------------------------------------------------
    def __init__(self):
        super().__init__()
        # Persistent (whole game) information
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0

        # Hand (per round) information
        self.hole_cards: List[str] = []
        self.round_num: int = 0
        self.random = random.Random()

    # ------------------- Helper functions ------------------------------------
    # 1. 7-card evaluator (quick & dirty but accurate)
    # -------------------------------------------------------------------------
    def _evaluate_5(self, cards: Tuple[str, ...]) -> Tuple[int, List[int]]:
        """
        Evaluate exactly five cards and return a tuple:
        (category, tie_breaker_list).  Higher tuple beats lower.
        Categories (high → low):
         8 Straight flush
         7 Four of a kind
         6 Full house
         5 Flush
         4 Straight
         3 Three of a kind
         2 Two pair
         1 One pair
         0 High card
        """
        ranks = sorted((_card_rank(c) for c in cards), reverse=True)
        suits = [_card_suit(c) for c in cards]

        # Count occurrences of each rank
        counts: Dict[int, int] = {}
        for r in ranks:
            counts[r] = counts.get(r, 0) + 1
        counts_sorted = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
        count_nums = [cnt for _, cnt in counts_sorted]

        is_flush = len(set(suits)) == 1
        # Straight detection (wheel A-5)
        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        straight_high = None
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                window = unique_ranks[i:i + 5]
                if window[0] - window[4] == 4:
                    is_straight = True
                    straight_high = window[0]
                    break
            # Wheel (A2345) special case
            if not is_straight and set(unique_ranks[-4:] + [12]) >= {12, 3, 2, 1, 0}:
                is_straight = True
                straight_high = 3  # 5 high straight

        # Straight flush
        if is_flush and is_straight:
            return 8, [straight_high]

        # Four of a kind
        if count_nums[0] == 4:
            quad_rank = counts_sorted[0][0]
            kicker = counts_sorted[1][0]
            return 7, [quad_rank, kicker]

        # Full house
        if count_nums[0] == 3 and count_nums[1] == 2:
            trip_rank = counts_sorted[0][0]
            pair_rank = counts_sorted[1][0]
            return 6, [trip_rank, pair_rank]

        # Flush
        if is_flush:
            return 5, ranks

        # Straight
        if is_straight:
            return 4, [straight_high]

        # Three of a kind
        if count_nums[0] == 3:
            trips = counts_sorted[0][0]
            kickers = sorted([r for r in ranks if r != trips], reverse=True)
            return 3, [trips] + kickers[:2]

        # Two pair
        if count_nums[0] == 2 and count_nums[1] == 2:
            high_pair = counts_sorted[0][0]
            low_pair = counts_sorted[1][0]
            kicker = counts_sorted[2][0]
            return 2, [high_pair, low_pair, kicker]

        # One pair
        if count_nums[0] == 2:
            pair_rank = counts_sorted[0][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return 1, [pair_rank] + kickers[:3]

        # High card
        return 0, ranks

    def _evaluate_7(self, cards: List[str]) -> Tuple[int, List[int]]:
        best = (-1, [])
        # 7 choose 5 = 21 iterations – trivial cost
        for comb in itertools.combinations(cards, 5):
            score = self._evaluate_5(comb)
            if score > best:
                best = score
        return best

    # 2. Very light-weight pre-flop hand strength (Chen formula approximation)
    # -------------------------------------------------------------------------
    def _chen_score(self, hole: List[str]) -> float:
        r1, r2 = _card_rank(hole[0]), _card_rank(hole[1])
        s1, s2 = _card_suit(hole[0]), _card_suit(hole[1])
        high = max(r1, r2)
        low = min(r1, r2)

        # Base value for high card
        base_val = [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5,
                    5, 6, 7, 8, 10][high]

        # Paired hand
        if r1 == r2:
            score = base_val * 2
            if score < 5:
                score = 5
            return score

        # Suited bonus
        score = base_val
        if s1 == s2:
            score += 2

        # Gap penalty
        gap = high - low - 1
        gap_penalty = {0: 0, 1: 1, 2: 2, 3: 4}.get(gap, 5)
        score -= gap_penalty

        # Small straight bonus
        if gap == 0 and high < 8:  # Connected & ≤9 high
            score += 1

        return max(score, 0)  # Clamp at 0

    # 3. Extract hole cards from RoundStateClient if possible
    # -------------------------------------------------------------------------
    @staticmethod
    def _extract_hole_cards(round_state: RoundStateClient, player_id: int) -> List[str]:
        possible_attrs = ['hole_cards', 'hand', 'player_hands', 'hands']
        for attr in possible_attrs:
            if hasattr(round_state, attr):
                data = getattr(round_state, attr)
                # Could be list or dict of lists
                if isinstance(data, list) and len(data) == 2 and isinstance(data[0], str):
                    return data
                if isinstance(data, dict):
                    return data.get(str(player_id), data.get(player_id, []))
        # Nothing found
        return []

    # -------------------------------------------------------------------------
    # Bot interface ­– required by the framework
    # -------------------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.hole_cards = player_hands
        self.round_num = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        extracted = self._extract_hole_cards(round_state, self.id)
        if extracted:
            self.hole_cards = extracted  # Update for this hand

    # ----------------------------- Decision logic ----------------------------
    def _decide_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Simple pre-flop logic:
          – Tight/aggressive based on Chen score
        """
        chen = self._chen_score(self.hole_cards)
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Aggressive range
        if chen >= 8:  # Premium hands – re-raise / open raise
            desired_raise = max(min_raise, self.big_blind * 3)
            raise_amount = min(to_call + desired_raise, max_raise)
            if raise_amount > remaining_chips:
                return PokerAction.ALL_IN, 0
            if raise_amount > to_call:
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0

        # Middle strength – call or small raise when first in
        if chen >= 5:
            # If no bet to us, open limp with call (actually check) or small raise
            if to_call == 0:
                # 30 % chance to open for small raise to steal blinds
                if self.random.random() < 0.3 and min_raise <= remaining_chips:
                    return PokerAction.RAISE, min(min_raise, remaining_chips)
                return PokerAction.CHECK, 0
            else:
                # Facing a bet – call small, fold to large (>6×BB)
                if to_call <= self.big_blind * 6:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Weak range
        if to_call == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    # -------------------------------------------------------------------------
    def _decide_postflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Post-flop logic based on made hand strength vs. board texture.
        """
        community = round_state.community_cards
        full_cards = self.hole_cards + community
        my_hand = self._evaluate_7(full_cards)
        board_hand = self._evaluate_7(community) if len(community) >= 5 else (-1, [])

        category = my_hand[0]
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot = max(round_state.pot, 1)

        # Very strong (two-pair+)
        if category >= 2:
            # Raise 70 % pot when ahead or shove if short
            desired_raise = int(pot * 0.7 + to_call)
            desired_raise = max(desired_raise, round_state.min_raise)
            if desired_raise >= remaining_chips or round_state.max_raise == remaining_chips:
                return PokerAction.ALL_IN, 0
            return (PokerAction.RAISE, min(desired_raise, round_state.max_raise))

        # Medium (top-pair / over-pair)     category == 1
        if category == 1:
            # If board already paired or better, treat cautiously
            board_cat = board_hand[0]
            if board_cat >= 1 and my_hand <= board_hand:
                # Only bluff catch small
                if to_call == 0:
                    return PokerAction.CHECK, 0
                call_limit = int(0.15 * pot)
                if to_call <= call_limit:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Otherwise value bet / call
            if to_call == 0:
                value_bet = max(round_state.min_raise, int(pot * 0.5))
                if value_bet < remaining_chips and value_bet <= round_state.max_raise:
                    return PokerAction.RAISE, value_bet
                return PokerAction.CHECK, 0
            else:
                if to_call <= int(0.25 * pot):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # High-card / draws
        # Occasional semi-bluff
        if to_call == 0:
            if self.random.random() < 0.1:
                bluff_amount = max(round_state.min_raise, int(pot * 0.6))
                if bluff_amount <= round_state.max_raise and bluff_amount < remaining_chips:
                    return PokerAction.RAISE, bluff_amount
            return PokerAction.CHECK, 0

        # Facing a bet – fold unless cheap
        if to_call <= int(0.1 * pot) and to_call <= self.big_blind * 2:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    # -------------------------------------------------------------------------
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Main decision entry.  Delegates to pre-flop / post-flop strategy.
        Always returns a valid (action, amount) tuple.
        """
        # Update hole-cards if they were not set for some reason
        if not self.hole_cards:
            self.hole_cards = self._extract_hole_cards(round_state, self.id) or []

        stage = round_state.round.lower()  # 'preflop', 'flop', ...
        try:
            if stage == "preflop":
                return self._decide_preflop(round_state, remaining_chips)
            else:
                return self._decide_postflop(round_state, remaining_chips)
        except Exception:
            # Any unforeseen error -> safe-fold
            return PokerAction.FOLD, 0

    # -------------- Round / Game end hooks (book-keeping only) ---------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing yet – could add learning later.
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[Any, float],
        active_players_hands: Dict[Any, List[str]],
    ):
        # Reset between games (if the same instance continues)
        self.hole_cards = []
        pass