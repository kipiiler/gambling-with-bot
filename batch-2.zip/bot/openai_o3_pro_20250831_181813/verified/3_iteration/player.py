from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    """
    A very small-foot-print, rule–based No-Limit Texas Hold’em bot.
    Goals for this implementation:
        1. NEVER send an illegal action (causes auto-fold / elimination).
        2. Play tighter / more aggressive than the previous iteration.
        3. Keep the logic extremely light so that it will certainly stay
           inside the 30-second / 100 MB limits.
    The bot uses a rough pre-flop hand strength table and a few
    situation-dependent rules (position, current price to call, etc.).
    Post-flop it behaves cautiously, continuing only with made hands
    two-pair or better (it never tries to read the board in detail,
    but that is still far better than the always-fold behaviour seen
    in the previous submission).
    """

    # ───────────────────────────── helper constants ────────────────────────── #

    _RANK_ORDER = "23456789TJQKA"
    _RANK_TO_VALUE = {r: i for i, r in enumerate(_RANK_ORDER)}  # 0 … 12

    # Premium, strong, medium hand groups (rank letters only, unsuited key).
    _PREMIUM = {"AA", "KK", "QQ", "JJ", "AK"}
    _STRONG = {
        "TT", "AQ", "AJ", "KQ", "99", "88", "77", "AK", "AQs", "AJs", "KQs"
    }  # small pairs also handled separately
    _MEDIUM_PAIRS = {"66", "55", "44", "33", "22"}

    # Conservative threshold multipliers (in big blinds) for calling
    _CALL_PRICE_LIMIT = {"premium": 6, "strong": 4, "medium": 2}

    # ────────────────────────────────── init ───────────────────────────────── #

    def __init__(self):
        super().__init__()
        # Persistent (per-game) information
        self.starting_stack: int = 0
        self.big_blind: int = 0
        self.hole_cards: List[str] = []
        self.seat_order: List[int] = []
        # Per-round info (refreshed every on_round_start)
        self.round_num: int = 0

    # ─────────────────────────── life-cycle hooks ─────────────────────────── #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        """
        Called once at the beginning of a single 10-hand “mini match”.
        """
        self.starting_stack = starting_chips
        self.hole_cards = player_hands[:]  # copy
        self.big_blind = blind_amount
        self.seat_order = all_players[:]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # refresh hand for the new round if the server provided it
        self.round_num = round_state.round_num
        # the hole cards might change for every hand, fetch from state if present
        # (the public interface does not guarantee this, so we fall back to
        #  the original two cards if absent).
        if hasattr(round_state, "player_hands"):  # type: ignore
            self.hole_cards = round_state.player_hands.get(str(self.id), self.hole_cards)  # type: ignore

    # ────────────────────────────── strategy ──────────────────────────────── #

    # -------- pre-flop helpers -------- #
    def _canonical_repr(self) -> Tuple[str, bool]:
        """
        Converts the two hole cards into a canonical representation:
        Returns:
            code (str)  – rank1+rank2 (sorted high to low, e.g. 'AK')
            suited (bool)
        """
        if len(self.hole_cards) != 2:
            return "72", False  # worst default
        rank1, suit1 = self.hole_cards[0][0], self.hole_cards[0][1]
        rank2, suit2 = self.hole_cards[1][0], self.hole_cards[1][1]
        # sort by rank strength
        if self._RANK_TO_VALUE[rank2] > self._RANK_TO_VALUE[rank1]:
            rank1, rank2 = rank2, rank1  # swap
            suit1, suit2 = suit2, suit1
        suited = suit1 == suit2
        return f"{rank1}{rank2}", suited

    def _hand_category(self) -> str:
        """Return 'premium' / 'strong' / 'medium' / 'weak'."""
        code, suited = self._canonical_repr()
        # suited code variant (AKs, etc.)
        suited_code = f"{code}s" if suited else code
        if code in self._PREMIUM or suited_code in self._PREMIUM:
            return "premium"
        if suited_code in self._STRONG or code in self._STRONG:
            return "strong"
        if code in self._MEDIUM_PAIRS:
            return "medium"
        # suited connectors 54s+ count as medium
        hi, lo = code[0], code[1]
        diff = abs(self._RANK_TO_VALUE[hi] - self._RANK_TO_VALUE[lo])
        if suited and diff == 1 and self._RANK_TO_VALUE[hi] >= 4:  # 65s+
            return "medium"
        return "weak"

    # ------------- safety helpers ------------- #
    @staticmethod
    def _my_bet(round_state: RoundStateClient, pid: int) -> int:
        return round_state.player_bets.get(str(pid), 0)

    # ─────────────────────────── choose an action ─────────────────────────── #

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine – chooses the next move ensuring legality.
        """
        # Current financial situation
        my_bet = self._my_bet(round_state, self.id)
        to_call = max(round_state.current_bet - my_bet, 0)
        min_raise = round_state.min_raise
        # For robustness make sure min_raise is at least big blind when
        # no bet has been made (many servers provide 0 in that case)
        if min_raise == 0 and round_state.current_bet == 0:
            min_raise = self.big_blind

        # Determine hand strength category
        category = self._hand_category()

        # Decision matrix ---------------------------------------------------- #
        # No money required to stay in hand
        if to_call == 0:
            # Opportunity to bet/raise
            if category == "premium" and min_raise > 0 and remaining_chips > min_raise:
                raise_amount = min(min_raise * 3, remaining_chips)
                return PokerAction.RAISE, raise_amount
            if category == "strong" and min_raise > 0 and remaining_chips > min_raise:
                raise_amount = min(min_raise * 2, remaining_chips)
                return PokerAction.RAISE, raise_amount
            # otherwise just check
            return PokerAction.CHECK, 0

        # There is an outstanding bet --------------------------------------- #
        max_price = self._CALL_PRICE_LIMIT.get(category, 0) * self.big_blind
        if category == "premium":
            # Call any reasonable bet (<20 BB); otherwise all-in fold logic
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            if to_call <= 20 * self.big_blind:
                return PokerAction.CALL, to_call
            # huge over-bet – fold
            return PokerAction.FOLD, 0

        elif category == "strong":
            if to_call <= max_price and to_call < remaining_chips:
                return PokerAction.CALL, to_call
            if to_call >= remaining_chips:  # short-stacked – gamble
                return PokerAction.ALL_IN, 0
            return PokerAction.FOLD, 0

        elif category == "medium":
            if to_call <= max_price and to_call < remaining_chips / 10:
                return PokerAction.CALL, to_call
            return PokerAction.FOLD, 0

        else:  # weak hand
            return PokerAction.FOLD, 0

    # ───────────────────────────── round / game end ───────────────────────── #

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing fancy: reset round specific flags if needed
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict,
        active_players_hands: Dict,
    ):
        # Reset everything for the next “game”
        self.hole_cards.clear()
        self.seat_order.clear()
        self.round_num = 0