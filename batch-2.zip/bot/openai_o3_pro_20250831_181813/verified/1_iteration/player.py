# player.py
import random
import itertools
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i + 2 for i, r in enumerate(RANK_ORDER)}
# Reverse map for straight detection (Ace can be low)
ACE_LOW_STRAIGHT = {14, 5, 4, 3, 2}


class SimplePlayer(Bot):
    """
    A simple yet solid no-limit Texas Hold’em poker bot.
    Strategy outline:
        • Tight-aggressive pre-flop using a Chen-formula evaluation.
        • Post-flop strength evaluation by enumerating every 5-card combination
          of the 7 available cards and selecting the best category.
        • Pot-odds & stack‐size aware betting / calling.
        • Always produces legal actions and never raises less than the minimum.
    This bot is intentionally lightweight (pure Python, no external libs) and
    robust against all edge-cases required by the tournament rules.
    """

    # --- Bot framework mandatory methods ------------------------------------
    def __init__(self):
        super().__init__()
        # Persisted state across hands
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.all_players: List[int] = []
        self.my_hole_cards: List[str] = []  # updated every round

    # -------------------- tournament/event hooks ----------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players
        # player_hands may contain our first hand (depends on engine) – store if provided
        if player_hands and isinstance(player_hands[0], str):
            self.my_hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Attempt to extract our fresh hole cards from the round_state
        self.my_hole_cards = self._extract_hole_cards(round_state) or self.my_hole_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Decide action every turn.
        Robustness guidelines:
            • Always fall back to FOLD if something looks wrong.
            • Never exceed stack size or engine-provided max_raise.
            • Respect check legality.
        """
        try:
            hole = self.my_hole_cards
            if len(hole) != 2:  # We must have exactly 2 hole cards
                return PokerAction.FOLD, 0

            stage = round_state.round.lower()  # 'preflop', 'flop', 'turn', 'river'
            pot = max(round_state.pot, 1)  # avoid division by 0
            my_bet = round_state.player_bets.get(str(self.id), 0) or round_state.player_bets.get(self.id, 0) or 0
            to_call = max(round_state.current_bet - my_bet, 0)
            min_raise = round_state.min_raise or max(to_call * 2, self.big_blind)
            max_raise = min(round_state.max_raise, remaining_chips)

            # --- Pre-flop decision ------------------------------------------
            if stage == "preflop":
                chen = self._chen_score(hole)
                if chen >= 10:
                    return self._aggressive_raise(min_raise, max_raise, pot, remaining_chips)
                elif chen >= 7:
                    # Good hand: raise if no big bet to call, else call
                    if to_call <= self.big_blind * 2:
                        return self._aggressive_raise(min_raise, max_raise, pot, remaining_chips)
                    else:
                        return self._safe_call_check(to_call)
                elif chen >= 5:
                    # Medium hand – call small bets, otherwise fold
                    return self._safe_call_check(to_call) if to_call <= self.big_blind else (PokerAction.FOLD, 0)
                else:
                    # Trash
                    return self._safe_call_check(to_call) if to_call == 0 else (PokerAction.FOLD, 0)

            # --- Post-flop decision -----------------------------------------
            strength = self._hand_category(hole, round_state.community_cards)
            # Betting thresholds using hand category (0-8)
            # 5+  -> strong (Flush or better)
            # 3-4 -> medium (Straight, Trips)
            # 2   -> weak-medium (Two Pair)
            # 1   -> marginal (One Pair)
            # 0   -> garbage
            if strength >= 5:
                # Very strong – bet big / shove with short stack
                return self._aggressive_raise(min_raise, max_raise, pot, remaining_chips, all_in_threshold=0.6)
            elif strength >= 3:
                # Value bet or call
                if to_call == 0:
                    return self._aggressive_raise(min_raise, max_raise, pot, remaining_chips, aggression_factor=0.5)
                else:
                    # Call reasonable bets (<= pot/2)
                    if to_call <= pot * 0.5:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            elif strength == 2:
                # Two pair – pot control
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # good pot odds only
                    if to_call <= pot * 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            elif strength == 1:
                # Single pair – avoid big pots
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= pot * 0.15:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            else:
                # High card only
                return self._safe_call_check(to_call)

        except Exception:
            # Any unexpected error: fold gracefully
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass  # We do not store statistics for now

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass  # No persistent learning

    # -------------------------- Helper methods ------------------------------
    # --------- Action builders ---------------------------------------------
    @staticmethod
    def _safe_call_check(to_call: int) -> Tuple[PokerAction, int]:
        if to_call == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _aggressive_raise(
        self,
        min_raise: int,
        max_raise: int,
        pot: int,
        remaining: int,
        aggression_factor: float = 1.0,
        all_in_threshold: float = 0.85,
    ) -> Tuple[PokerAction, int]:
        """
        Decide raise size. Convert aggression_factor in [0,1] to proportion of pot.
        all_in_threshold is stack/pot ratio below which we just shove.
        """
        if remaining <= pot * all_in_threshold:
            return PokerAction.ALL_IN, 0

        # Desired raise amount
        desired = int(min(max(int(pot * aggression_factor), min_raise), max_raise))
        # Ensure legality
        if desired < min_raise:
            if remaining >= min_raise:
                desired = min_raise
            else:
                return PokerAction.ALL_IN, 0
        return PokerAction.RAISE, desired

    # --------- Hole-card & hand evaluation ----------------------------------
    def _extract_hole_cards(self, state: RoundStateClient) -> List[str]:
        """
        Attempt to fetch our hole cards from various possible attribute names.
        Returns [] if not found.
        """
        for attr in ("player_hands", "hole_cards", "player_cards"):
            if hasattr(state, attr):
                container = getattr(state, attr)
                if isinstance(container, dict):
                    cards = container.get(str(self.id)) or container.get(self.id)
                    if cards:
                        return cards
                elif isinstance(container, list) and len(container) == 2 and isinstance(container[0], str):
                    # Assume list corresponds to this player (heads-up environments sometimes do this)
                    return container
        return []

    # --------------- Pre-flop Chen formula ----------------------------------
    @staticmethod
    def _chen_score(hole: List[str]) -> float:
        """
        Compute Chen formula (rounded up to nearest 0.5).
        """
        if len(hole) != 2:
            return 0.0
        ranks = sorted([RANK_VALUE[c[0]] for c in hole], reverse=True)
        high, low = ranks
        high_card_score = {
            14: 10, 13: 8, 12: 7, 11: 6, 10: 5, 9: 4.5, 8: 4, 7: 3.5, 6: 3, 5: 2.5, 4: 2, 3: 1.5, 2: 1
        }[high]

        score = high_card_score
        # Pair bonus
        if high == low:
            score = max(score * 2, 5)
        # Suited bonus
        if hole[0][1] == hole[1][1]:
            score += 2
        # Gap penalty
        gap = high - low - 1
        gap_penalty = {0: 0, 1: 1, 2: 2, 3: 4}.get(gap, 5)
        score -= gap_penalty
        # Straight bonus
        if gap == 0 and high <= 11:  # connectors 5-J
            score += 1
        return max(score, 0)

    # --------------- Post-flop hand strength --------------------------------
    def _hand_category(self, hole: List[str], board: List[str]) -> int:
        """
        Evaluate hand strength category on a 0-8 scale using 5-card exhaustive enumeration.
        Higher is better.
        """
        cards = hole + board
        if len(cards) < 5:
            return 0
        best_category = 0
        for combo in itertools.combinations(cards, 5):
            category = self._categorize_5(combo)
            if category > best_category:
                best_category = category
                if best_category == 8:  # Early exit at nuts
                    break
        return best_category

    @staticmethod
    def _categorize_5(cards5: Tuple[str, ...]) -> int:
        """
        Returns category integer:
            8 Straight Flush
            7 Four of a kind
            6 Full House
            5 Flush
            4 Straight
            3 Trips
            2 Two Pair
            1 Pair
            0 High Card
        """
        ranks = sorted([RANK_VALUE[c[0]] for c in cards5], reverse=True)
        suits = [c[1] for c in cards5]
        rank_counts: Dict[int, int] = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        counts = sorted(rank_counts.values(), reverse=True)
        is_flush = len(set(suits)) == 1
        unique_ranks = sorted(set(ranks), reverse=True)

        # Straight detection (Ace low)
        is_straight = False
        if len(unique_ranks) == 5 and max(unique_ranks) - min(unique_ranks) == 4:
            is_straight = True
        elif set(unique_ranks) == ACE_LOW_STRAIGHT:
            is_straight = True

        if is_straight and is_flush:
            return 8
        if counts[0] == 4:
            return 7
        if counts[0] == 3 and counts[1] == 2:
            return 6
        if is_flush:
            return 5
        if is_straight:
            return 4
        if counts[0] == 3:
            return 3
        if counts[0] == 2 and counts[1] == 2:
            return 2
        if counts[0] == 2:
            return 1
        return 0