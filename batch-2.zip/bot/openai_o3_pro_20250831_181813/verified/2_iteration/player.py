from __future__ import annotations

import random
from typing import Dict, List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


# ---------------------------  CARD / HAND UTILITIES  --------------------------- #
RANK_ORDER = "23456789TJQKA"
RANK_TO_INT: Dict[str, int] = {r: i + 2 for i, r in enumerate(RANK_ORDER)}


def card_rank(card: str) -> int:
    """Return numerical rank 2-14 for a card such as 'Ah' or 'Tc'."""
    r = card[0]
    return RANK_TO_INT.get(r, 0)


def card_suit(card: str) -> str:
    """Return suit character for a card."""
    return card[-1]


def is_straight(ranks: List[int]) -> int | None:
    """
    Return highest rank of straight (5-high straight returns 5)
    or None if no straight in ordered unique ranks list.
    Ace can be low.
    """
    if len(ranks) < 5:
        return None
    # Treat Ace low by appending 1 when Ace present
    r_set = set(ranks)
    if 14 in r_set:
        r_set.add(1)
    ordered = sorted(r_set)
    consec = 0
    prev = -10
    high = 0
    for r in ordered:
        if r == prev + 1:
            consec += 1
        else:
            consec = 1
        if consec >= 5:
            high = r
        prev = r
    return high if high else None


def best_hand_category(cards: List[str]) -> int:
    """
    Very fast approximate evaluator returning category:
    0 = High Card … 9 = Royal Flush
    Works well for decision making but not tie-breaks.
    """
    if len(cards) < 5:
        return 0
    suits: Dict[str, List[int]] = {}
    counts: Dict[int, int] = {}
    for c in cards:
        r = card_rank(c)
        s = card_suit(c)
        suits.setdefault(s, []).append(r)
        counts[r] = counts.get(r, 0) + 1

    # Flush & Straight-Flush detection
    flush_suit = next((s for s, lst in suits.items() if len(lst) >= 5), None)
    straight_flush = False
    royal = False
    if flush_suit:
        franks = sorted(suits[flush_suit], reverse=True)
        sf_high = is_straight(franks)
        if sf_high:
            straight_flush = True
            if sf_high == 14:  # Ace-high straight flush
                royal = True

    if royal:
        return 9
    if straight_flush:
        return 8

    # Multiples
    freq_values = sorted(counts.values(), reverse=True)
    if 4 in freq_values:
        return 7
    if 3 in freq_values and 2 in freq_values:
        return 6

    # Flush
    if flush_suit:
        return 5

    # Straight
    all_ranks_unique = sorted({card_rank(c) for c in cards}, reverse=True)
    if is_straight(all_ranks_unique):
        return 4

    # Trips / Pairs
    if 3 in freq_values:
        return 3
    if freq_values.count(2) >= 2:
        return 2
    if 2 in freq_values:
        return 1
    return 0


# ---------------------------  SIMPLE PLAYER BOT  --------------------------- #
class SimplePlayer(Bot):
    """
    A lightweight rule-based poker bot using:
    • Chen-style pre-flop scoring
    • Simple post-flop hand evaluation
    • Pot-odds vs. estimated equity decision making
    """

    # ---------- INITIALIZATION & STATE ---------- #
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.round_num: int = 0
        # Cache card evaluations to save CPU
        self._eval_cache: Dict[Tuple[str, ...], int] = {}

    # ---------- CALLBACKS FROM THE FRAMEWORK ---------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.hole_cards = player_hands[:]
        self.all_players = all_players[:]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Update hole cards robustly
        hc = None
        if hasattr(round_state, "player_hands"):
            ph = getattr(round_state, "player_hands")
            if isinstance(ph, dict):
                hc = ph.get(str(self.id)) or ph.get(self.id)
            elif isinstance(ph, list):
                hc = ph
        elif hasattr(round_state, "hole_cards"):
            hc = getattr(round_state, "hole_cards")
        if hc:
            self.hole_cards = hc[:]

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        try:
            stage = round_state.round.lower()  # 'preflop', 'flop', etc.
        except Exception:
            stage = "preflop"

        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(round_state.current_bet - my_bet, 0)
        pot_size = round_state.pot

        # --------------------  PREFLOP STRATEGY  -------------------- #
        if stage == "preflop":
            strength = self._preflop_score(self.hole_cards)
            if call_amount == 0:
                # No raise yet
                if strength >= 20 and remaining_chips > round_state.min_raise:
                    raise_amt = self._clamp_raise(
                        pot_size, round_state.min_raise, round_state.max_raise
                    )
                    return PokerAction.RAISE, raise_amt
                elif strength >= 12:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Facing raise
                if strength >= 22:
                    # Re-raise or shove
                    desired = call_amount * 3
                    raise_amt = self._clamp_raise(
                        desired, round_state.min_raise, round_state.max_raise
                    )
                    if raise_amt < round_state.min_raise:
                        # Not enough to reraise – just call
                        if call_amount >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0
                    return PokerAction.RAISE, raise_amt
                elif strength >= 16:
                    # Just call if affordable
                    if call_amount >= remaining_chips:
                        return PokerAction.FOLD, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # --------------------  POST-FLOP STRATEGY  -------------------- #
        est_equity = self._postflop_equity(round_state.community_cards)
        # Pot odds
        pot_odds = (
            call_amount / float(pot_size + call_amount + 1e-9) if call_amount > 0 else 0
        )

        if call_amount == 0:
            # Decide whether to value bet / bluff
            if est_equity > 0.7 and remaining_chips > round_state.min_raise:
                raise_amt = self._clamp_raise(
                    int(pot_size * 0.75), round_state.min_raise, round_state.max_raise
                )
                return PokerAction.RAISE, raise_amt
            elif est_equity < 0.25 and random.random() < 0.5:
                # Occasional small bluff
                raise_amt = self._clamp_raise(
                    int(pot_size * 0.5), round_state.min_raise, round_state.max_raise
                )
                if raise_amt >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0
        else:
            # Facing a bet
            if est_equity > 0.9:
                # Big hand – raise or shove
                if remaining_chips <= call_amount * 2:
                    return PokerAction.ALL_IN, 0
                raise_amt = self._clamp_raise(
                    int(pot_size + call_amount), round_state.min_raise, round_state.max_raise
                )
                return PokerAction.RAISE, raise_amt
            elif est_equity > pot_odds + 0.1:
                # +EV call
                if call_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            elif est_equity > 0.4 and random.random() < 0.2:
                # Occasional semi-bluff raise
                raise_amt = self._clamp_raise(
                    int(call_amount * 3), round_state.min_raise, round_state.max_raise
                )
                if raise_amt >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amt
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing stateful to do
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # Nothing to clean up
        pass

    # ---------- STRATEGY HELPER FUNCTIONS ---------- #
    def _preflop_score(self, hole_cards: List[str]) -> int:
        """Very light Chen-style score."""
        if len(hole_cards) != 2:
            return 0
        r1, r2 = map(card_rank, hole_cards)
        s1, s2 = map(card_suit, hole_cards)
        high = max(r1, r2)
        low = min(r1, r2)
        score = high
        # Pair bonus
        if r1 == r2:
            score += 10
        # Suited bonus
        if s1 == s2:
            score += 2
        # Gap penalty
        gap = high - low - 1
        score -= max(gap, 0)
        # Small card penalty
        if high < 9:
            score -= 2
        return max(score, 0)

    def _postflop_equity(self, community: List[str]) -> float:
        """Return estimated equity in [0,1] based on made-hand category."""
        cards = tuple(sorted(self.hole_cards + community))
        if cards in self._eval_cache:
            cat = self._eval_cache[cards]
        else:
            cat = best_hand_category(list(cards))
            self._eval_cache[cards] = cat
        # Map category to rough equity estimate
        return {
            9: 0.99,
            8: 0.97,
            7: 0.95,
            6: 0.92,
            5: 0.8,
            4: 0.75,
            3: 0.65,
            2: 0.55,
            1: 0.35,
            0: 0.15,
        }.get(cat, 0.5)

    @staticmethod
    def _clamp_raise(desired: int, min_raise: int, max_raise: int) -> int:
        """Return a legal raise amount adhering to min/max constraints."""
        if max_raise < min_raise:
            return 0
        return max(min_raise, min(desired, max_raise))