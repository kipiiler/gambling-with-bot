import collections
import itertools
import random
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

#################################################################################################
# Hand Evaluation Helper Class
#
# This class is self-contained and does not require external libraries.
# It's used to parse cards, evaluate the strength of a 5-card hand,
# and find the best possible 5-card hand from a set of cards.
#################################################################################################
class HandEvaluator:
    """
    A helper class to manage hand evaluation logic.
    """
    RANK_MAP = {
        '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
        'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
    }
    INT_TO_RANK = {v: k for k, v in RANK_MAP.items()}
    SUITS = ['s', 'h', 'd', 'c']

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """ Converts a card string like 'Ah' to a tuple (rank, suit), e.g., (14, 'h'). """
        if not card_str or len(card_str) != 2:
            return (0, '')
        rank = self.RANK_MAP.get(card_str[0])
        suit = card_str[1]
        return (rank, suit)

    def _parse_cards(self, cards: List[str]) -> List[Tuple[int, str]]:
        """ Parses a list of card strings. """
        return [self._parse_card(c) for c in cards]

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]):
        """
        Evaluates a 5-card hand and returns a tuple (hand_rank, ranks_for_tiebreak).
        Higher hand_rank is better. Tiebreaks are decided by the sorted ranks.
        - 9: Straight Flush
        - 8: Four of a Kind
        - 7: Full House
        - 6: Flush
        - 5: Straight
        - 4: Three of a Kind
        - 3: Two Pair
        - 2: One Pair
        - 1: High Card
        """
        if not hand or len(hand) != 5:
            return (0, [])

        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]

        is_flush = len(set(suits)) == 1
        is_ace_low_straight = set(ranks) == {14, 5, 4, 3, 2}
        is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)) or is_ace_low_straight
        
        if is_ace_low_straight:
            # For tie-breaking, the Ace in a wheel is treated as the lowest card (value 1).
            tiebreak_ranks = [5, 4, 3, 2, 1] 
        else:
            tiebreak_ranks = ranks

        # Hand Ranking Logic (from best to worst)
        if is_straight and is_flush:
            return (9, tiebreak_ranks) # Straight Flush (Royal is just the highest)
        
        rank_counts = collections.Counter(ranks)
        count_vals = sorted(rank_counts.values(), reverse=True)
        
        # Order ranks by count first, then by rank value for tie-breaking
        ordered_ranks = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)

        if count_vals == [4, 1]:  # Four of a Kind
            return (8, ordered_ranks)
        if count_vals == [3, 2]:  # Full House
            return (7, ordered_ranks)
        if is_flush:
            return (6, ranks)
        if is_straight:
            return (5, tiebreak_ranks)
        if count_vals == [3, 1, 1]: # Three of a Kind
            return (4, ordered_ranks)
        if count_vals == [2, 2, 1]: # Two Pair
            return (3, ordered_ranks)
        if count_vals == [2, 1, 1, 1]: # One Pair
            return (2, ordered_ranks)
            
        return (1, ranks) # High Card

    def evaluate_best_hand(self, hole_cards: List[str], community_cards: List[str]):
        """ From 7 cards (2 hole + 5 community), finds the best 5-card hand. """
        all_cards_str = hole_cards + community_cards
        if len(all_cards_str) < 5:
            # Not enough cards to form a 5-card hand
            parsed_cards = self._parse_cards(all_cards_str)
            return self._evaluate_5_card_hand(parsed_cards + [(0, 'x')] * (5 - len(parsed_cards)))
        
        all_cards = self._parse_cards(all_cards_str)
        
        best_hand_rank = (0, [])
        for hand_combination in itertools.combinations(all_cards, 5):
            current_rank = self._evaluate_5_card_hand(list(hand_combination))
            if current_rank > best_hand_rank:
                best_hand_rank = current_rank
        
        return best_hand_rank

    def create_deck(self, excluded_cards: List[str] = []) -> List[str]:
        """ Creates a standard 52-card deck, excluding specified cards. """
        ranks_str = self.RANK_MAP.keys()
        deck = [r + s for r in ranks_str for s in self.SUITS]
        for card in excluded_cards:
            if card in deck:
                deck.remove(card)
        return deck

#################################################################################################
# SimplePlayer Bot Implementation
#################################################################################################
class SimplePlayer(Bot):

    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.evaluator = HandEvaluator()
        self.all_players_at_table: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.all_players_at_table = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Main logic for deciding an action.
        This version fixes the "invalid check" error by correctly identifying legal moves
        and uses pre-flop hand charts and post-flop Monte Carlo simulation for decisions.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        active_opponents = len([pid for pid in round_state.player_bets.keys() if int(pid) != self.id])
        
        if round_state.round == 'Preflop':
            return self._decide_preflop_action(round_state, remaining_chips, can_check, amount_to_call)

        return self._decide_postflop_action(round_state, remaining_chips, can_check, amount_to_call, active_opponents)

    def _decide_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int) -> Tuple[PokerAction, int]:
        strength = self._get_preflop_strength(self.hole_cards)
        big_blind = round_state.round_num # Convention seems to be round_num = bb amount in test env
        
        is_large_raise = amount_to_call > 3 * big_blind

        # Premium hands (top ~5%): Always raise/re-raise
        if strength > 0.8:
            raise_amount = int(3 * round_state.current_bet + round_state.pot)
            return self._get_raise_action(round_state, remaining_chips, raise_amount)

        # Strong hands (top ~15%): Raise if first in, call raises
        if strength > 0.6:
            if amount_to_call > 0: # Facing a bet
                return (PokerAction.CALL, amount_to_call)
            else: # First to act or limpers
                raise_amount = int(2.5 * big_blind)
                return self._get_raise_action(round_state, remaining_chips, raise_amount)

        # Playable hands (mid-strength): Call small bets, fold to big raises
        if strength > 0.4:
            if is_large_raise:
                return (PokerAction.FOLD, 0)
            if can_check:
                return (PokerAction.CHECK, 0)
            if amount_to_call <= 2 * big_blind:
                return (PokerAction.CALL, amount_to_call)
            return (PokerAction.FOLD, 0)

        # Weak hands: Fold, unless you can check for free
        if can_check:
            return (PokerAction.CHECK, 0)
        
        is_bb = self.id == self.all_players_at_table[(self.all_players_at_table.index(round_state.current_player[0]) -1) % len(self.all_players_at_table)] if len(round_state.current_player) > 0 else False
        if is_bb and amount_to_call <= big_blind:
            return (PokerAction.CALL, amount_to_call)

        return (PokerAction.FOLD, 0)

    def _decide_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int, num_opponents: int) -> Tuple[PokerAction, int]:
        num_sims = 400 if round_state.round == 'Flop' else 600
        win_prob = self._run_monte_carlo(round_state, num_opponents, num_simulations=num_sips)
        
        if can_check:
            if win_prob > 0.8: # Strong value bet
                return self._get_raise_action(round_state, remaining_chips, int(0.7 * round_state.pot))
            elif win_prob > 0.5: # Medium strength value bet
                return self._get_raise_action(round_state, remaining_chips, int(0.5 * round_state.pot))
            else: # Check with weaker hands
                return (PokerAction.CHECK, 0)
        else: # Facing a bet
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)
            
            # If we have a monster hand, raise
            if win_prob > 0.85:
                raise_amount = int(round_state.pot + 2 * amount_to_call)
                return self._get_raise_action(round_state, remaining_chips, raise_amount)

            # Call if our equity is better than pot odds
            if win_prob > pot_odds:
                return (PokerAction.CALL, amount_to_call)
            
            # Fold if odds are not in our favor
            return (PokerAction.FOLD, 0)

    def _get_raise_action(self, round_state: RoundStateClient, remaining_chips: int, raise_amount: int) -> Tuple[PokerAction, int]:
        """Calculates a valid raise amount and returns a RAISE or ALL_IN action."""
        raise_amount = int(raise_amount)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Ensure raise is legal. If desired raise is too small, just call.
        if raise_amount < min_raise and max_raise > 0:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - my_bet
            if amount_to_call > 0:
                return (PokerAction.CALL, amount_to_call)
            return (PokerAction.CHECK, 0)

        clamped_raise = min(max(raise_amount, min_raise), max_raise)
        
        if clamped_raise >= remaining_chips:
            return (PokerAction.ALL_IN, remaining_chips)
        
        return (PokerAction.RAISE, clamped_raise)

    def _get_preflop_strength(self, hole_cards: List[str]) -> float:
        """ Returns a score from 0.0 to 1.0 for pre-flop hand strength. """
        if not hole_cards or len(hole_cards) < 2: return 0.0
        cards = self.evaluator._parse_cards(hole_cards)
        rank1, rank2 = sorted([c[0] for c in cards], reverse=True)
        is_suited = cards[0][1] == cards[1][1]
        is_pair = rank1 == rank2
        
        score = 0
        if is_pair: score = rank1 * 2
        else: score = rank1 + (rank2 / 1.5)
        
        if is_suited: score += 4
        if abs(rank1 - rank2) <= 4:
            score += max(0, 4 - abs(rank1 - rank2)) # Connector bonus
        
        return min(score / 35.0, 1.0) # Normalize to ~0-1 range

    def _run_monte_carlo(self, round_state: RoundStateClient, num_opponents: int, num_simulations: int = 500) -> float:
        """ Estimates win probability by simulating the hand against random opponent hands. """
        if num_opponents <= 0: return 1.0

        my_cards = self.hole_cards
        community = round_state.community_cards
        known_cards = my_cards + community
        
        wins = 0
        ties = 0

        for _ in range(num_simulations):
            try:
                deck = self.evaluator.create_deck(excluded_cards=known_cards)
                random.shuffle(deck)
                
                opponents_hands = [deck[i*2:i*2+2] for i in range(num_opponents)]
                deck_ptr = num_opponents * 2
                
                num_remaining_community = 5 - len(community)
                sim_community = community + deck[deck_ptr:deck_ptr + num_remaining_community]
                
                my_hand_rank = self.evaluator.evaluate_best_hand(my_cards, sim_community)
                
                best_opponent_rank = (0, [])
                for opp_hand in opponents_hands:
                    opp_rank = self.evaluator.evaluate_best_hand(opp_hand, sim_community)
                    if opp_rank > best_opponent_rank:
                        best_opponent_rank = opp_rank
                        
                if my_hand_rank > best_opponent_rank: wins += 1
                elif my_hand_rank == best_opponent_rank: ties += 1
            except (IndexError, KeyError):
                continue
        
        win_prob = (wins + ties / (num_opponents + 1)) / num_simulations
        return win_prob

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.hole_cards = []