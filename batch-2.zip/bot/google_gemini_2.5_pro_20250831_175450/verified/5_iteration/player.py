import collections
import random
from itertools import combinations
from typing import List, Tuple, Dict, Any

# These type definitions are provided by the game server's environment.
# They are included here for clarity and context.
from enum import Enum

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

from dataclasses import dataclass

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]]

# Abstract base class provided by the game server.
from abc import ABC, abstractmethod

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass
    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass
    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass


class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand strength charts and post-flop
    Monte Carlo equity simulation to make decisions. It fixes the AttributeError from the
    previous iteration by correctly handling where hole cards are received.
    """
    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.all_player_ids: List[int] = []

        # Card and hand evaluation utilities
        self.card_rank_map = self._create_card_rank_map()
        self.preflop_hand_strength = self._create_preflop_hand_strength_map()
        self.deck = [(r, s) for r in self.card_rank_map.values() for s in "shdc"]

        # Game state tracking
        self.big_blind_amount = 0

    def _create_card_rank_map(self) -> dict:
        """Creates a mapping from card character to rank value."""
        ranks = "23456789TJQKA"
        return {rank: i for i, rank in enumerate(ranks, 2)}

    def _create_preflop_hand_strength_map(self) -> dict:
        """
        Creates a pre-flop hand strength map. Higher numbers are better.
        """
        strength = {}
        # Tier 1: Premium
        for r in "AKQJ": strength[r+r] = 10
        strength["AKs"] = 10
        # Tier 2: Strong
        for r in "T9": strength[r+r] = 9
        for r1 in "AKQ":
            for r2 in "AKQ":
                if r1 != r2: strength["".join(sorted(r1+r2, reverse=True))+"s"] = 9
        strength["AJs"] = 9
        strength["AKo"] = 9
        # Tier 3: Playable
        for r in "876": strength[r+r] = 8
        strength["ATs"] = 8; strength["KQs"] = 8; strength["KJs"] = 8; strength["QJs"] = 8; strength["JTs"] = 8
        strength["AQo"] = 8
        # Tier 4: Speculative
        for r in "5432": strength[r+r] = 7
        for r in "98765432": strength[f"A{r}s"] = 7
        for r in "9876": strength[f"K{r}s"] = 6
        strength["AJo"] = 6; strength["KQo"] = 6
        strength["T9s"] = 6; strength["98s"] = 6; strength["87s"] = 6; strength["76s"] = 6
        # Tier 5: Marginal
        strength["ATo"] = 5; strength["KJo"] = 5; strength["QJo"] = 5; strength["JTo"] = 5
        return strength

    def _parse_cards(self, card_strs: List[str]) -> List[Tuple[int, str]]:
        """Parses card strings (e.g., ['As', 'Td']) into (rank, suit) tuples."""
        if not card_strs: return []
        return [(self.card_rank_map[c[0]], c[1]) for c in card_strs]

    def _get_preflop_strength(self, hand: List[Tuple[int, str]]) -> int:
        """Gets the pre-flop strength of a hand from the map."""
        c1, c2 = hand[0], hand[1]
        ranks = sorted([c1[0], c2[0]], reverse=True)
        # Create a reverse mapping for ranks to characters
        rev_rank_map = {v: k for k, v in self.card_rank_map.items()}
        rank_str = rev_rank_map[ranks[0]] + rev_rank_map[ranks[1]]

        if c1[0] == c2[0]: # Pair
            key = rank_str[0] * 2
        else:
            key = rank_str
            if c1[1] == c2[1]: # Suited
                key += "s"
            else: # Off-suit
                key += "o"
        return self.preflop_hand_strength.get(key, 0)

    def _evaluate_hand(self, cards: List[Tuple[int, str]]) -> Tuple:
        """
        Evaluates a 5-card hand and returns a comparable tuple representing its rank.
        (rank_id, kicker1, kicker2, ...). Higher is better.
        """
        if len(cards) != 5:
            return (0,)

        ranks = sorted([c[0] for c in cards], reverse=True)
        suits = [c[1] for c in cards]
        is_flush = len(set(suits)) == 1
        
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        is_straight = len(unique_ranks) >= 5 and (unique_ranks[0] - unique_ranks[4] == 4)
        if not is_straight and set(ranks) == {14, 2, 3, 4, 5}:
            is_straight = True
            ranks = [5, 4, 3, 2, 1] 
        
        if is_straight and is_flush: return (9, tuple(ranks))
        
        counts = collections.Counter(ranks)
        rank_counts = sorted(counts.values(), reverse=True)
        main_ranks = sorted(counts.keys(), key=lambda k: (counts[k], k), reverse=True)

        if rank_counts[0] == 4: return (8, (main_ranks[0], main_ranks[1]))
        if rank_counts == [3, 2]: return (7, (main_ranks[0], main_ranks[1]))
        if is_flush: return (6, tuple(ranks))
        if is_straight: return (5, tuple(ranks))
        if rank_counts[0] == 3: return (4, (main_ranks[0],) + tuple(sorted(main_ranks[1:], reverse=True)))
        if rank_counts[0:2] == [2, 2]: return (3, (main_ranks[0], main_ranks[1], main_ranks[2]))
        if rank_counts[0] == 2: return (2, (main_ranks[0],) + tuple(main_ranks[1:]))
        
        return (1, tuple(ranks))

    def _find_best_hand(self, hole_cards: list, community_cards: list) -> tuple:
        """Finds the best 5-card hand from 2 hole cards and community cards."""
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5: return (0,)
        return max(self._evaluate_hand(list(c)) for c in combinations(all_cards, 5))

    def _calculate_win_prob(self, my_hand: list, community: list, num_opponents: int, num_sims: int = 400) -> float:
        """Calculates win probability using Monte Carlo simulation."""
        if num_opponents == 0: return 1.0

        my_cards = self._parse_cards(my_hand)
        community_cards = self._parse_cards(community)

        used_cards = set(my_cards + community_cards)
        deck = [c for c in self.deck if c not in used_cards]

        wins, ties = 0, 0
        for _ in range(num_sims):
            shuffled_deck = random.sample(deck, len(deck))
            
            opp_hands = [shuffled_deck[i*2:i*2+2] for i in range(num_opponents)]
            remaining_board_cards = 5 - len(community_cards)
            sim_community = community_cards + shuffled_deck[num_opponents*2 : num_opponents*2 + remaining_board_cards]
            
            my_best = self._find_best_hand(my_cards, sim_community)
            opp_bests = [self._find_best_hand(opp_hand, sim_community) for opp_hand in opp_hands]
            
            if my_best > max(opp_bests): wins += 1
            elif my_best == max(opp_bests): ties += 1
                
        return (wins + ties / 2) / num_sims if num_sims > 0 else 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called at the start of each new hand, providing hole cards."""
        self.my_hand = player_hands
        self.all_player_ids = all_players
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each betting round (Preflop, etc.). No action needed here."""
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """The main decision-making logic for the bot."""
        pot_size = round_state.pot
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Calculate active opponents
        active_players = {pid for pid, bet in round_state.player_bets.items() if (pid not in round_state.player_actions or round_state.player_actions[pid] != 'Fold')}
        # If we haven't acted, we are active
        if str(self.id) not in active_players:
            active_players.add(str(self.id))
        num_opponents = len(active_players) - 1

        if round_state.round == "Preflop":
            parsed_hand = self._parse_cards(self.my_hand)
            strength = self._get_preflop_strength(parsed_hand)
            
            if amount_to_call == 0: # Option to check or bet
                if strength >= 8:
                    raise_amt = min(max(3 * self.big_blind_amount, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, int(raise_amt)
                elif strength >= 6 and random.random() < 0.5:
                    raise_amt = min(max(2.5 * self.big_blind_amount, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, int(raise_amt)
                else:
                    return PokerAction.CHECK, 0
            else: # Must call, raise, or fold
                pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9)
                is_large_bet = amount_to_call > 4 * self.big_blind_amount
                
                if strength >= 9:
                    if remaining_chips < 50 * self.big_blind_amount: return PokerAction.ALL_IN, 0
                    raise_amt = min(max(3 * amount_to_call, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, int(raise_amt)
                elif strength >= 7 and not is_large_bet:
                    return PokerAction.CALL, 0
                elif strength >= 5 and pot_odds < 0.15 and not is_large_bet:
                    return PokerAction.CALL, 0
                else: 
                    if str(self.id) == str(round_state.big_blind_player_id) and amount_to_call <= self.big_blind_amount:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
        else: # Post-flop
            if num_opponents == 0: return PokerAction.CHECK, 0
            
            win_prob = self._calculate_win_prob(self.my_hand, round_state.community_cards, num_opponents)
            
            if amount_to_call > 0:
                pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9)
                if win_prob > pot_odds:
                    if win_prob > 0.85:
                        raise_amt = min(max(int(0.75 * pot_size), round_state.min_raise), round_state.max_raise)
                        return PokerAction.RAISE, raise_amt
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Option to check or bet
                if win_prob > 0.75: # Value bet
                    bet_amt = min(max(int(0.7 * pot_size), self.big_blind_amount, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, bet_amt
                elif win_prob > 0.5 and random.random() < 0.4: # Semi-bluff/probe bet
                    bet_amt = min(max(int(0.4 * pot_size), self.big_blind_amount, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, bet_amt
                else:
                    return PokerAction.CHECK, 0

        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of a hand."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass