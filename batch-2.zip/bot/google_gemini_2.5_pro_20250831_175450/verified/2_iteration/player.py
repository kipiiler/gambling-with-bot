import random
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot for No-Limit Texas Hold'em.
    This bot uses a Monte Carlo simulation to estimate hand equity post-flop
    and a pre-computed strength score for pre-flop decisions.
    It plays a tight-aggressive style, adjusting for heads-up vs multi-way pots.
    """

    def __init__(self):
        super().__init__()
        self.my_cards: List[str] = []
        self.all_players_ids: List[int] = []
        self.big_blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called once at the start of the game. """
        self.my_cards = player_hands
        self.big_blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players_ids = all_players
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each round. """
        # Hand can change in new simulations, though the current setup gives it once.
        if hasattr(round_state, 'player_hands') and str(self.id) in round_state.player_hands:
            self.my_cards = round_state.player_hands[str(self.id)]
        
        # In heads-up, blinds can alternate if a player is eliminated and game resets
        if hasattr(round_state, 'big_blind_player_id'):
            self.big_blind_player_id = round_state.big_blind_player_id
            self.small_blind_player_id = [p for p in self.all_players_ids if p not in [self.big_blind_player_id, None]][0]


    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player based on game state.
        Switches between pre-flop and post-flop strategies.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet

        active_players_count = sum(1 for action in round_state.player_actions.values() if action != 'Fold')
        if active_players_count == 0: # If we are the first to act, count players from bets
             active_players_count = len(round_state.player_bets)

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, to_call, my_bet)
        else:
            return self._get_postflop_action(round_state, remaining_chips, to_call, my_bet, active_players_count)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each round. Can be used for opponent modeling. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    # --- Strategy Helper Methods ---

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, my_bet: int) -> Tuple[PokerAction, int]:
        """ Determines pre-flop action based on hand strength and position. """
        strength = self._get_preflop_strength(self.my_cards)

        # Heads-up logic is more aggressive
        if self.num_players == 2:
            is_sb = self.id == self.small_blind_player_id
            if is_sb:  # We are on the button (Small Blind)
                if strength >= 12:
                    raise_to = 3 * self.big_blind_amount
                    return self._get_raise_decision(raise_to, round_state, remaining_chips, my_bet)
                if strength >= 8:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:  # We are the Big Blind
                limpers = [pid for pid, bet in round_state.player_bets.items() if int(pid) != self.id and bet == self.big_blind_amount]
                
                if to_call == 0: # Opponent limped or we have option
                    if strength >= 10:
                        raise_to = 4 * self.big_blind_amount
                        return self._get_raise_decision(raise_to, round_state, remaining_chips, my_bet)
                    return PokerAction.CHECK, 0
                else:  # Opponent raised
                    if strength >= 16:
                        raise_to = 3 * round_state.current_bet
                        return self._get_raise_decision(raise_to, round_state, remaining_chips, my_bet)
                    if strength >= 10:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
        
        # Multi-way pot logic (more conservative)
        else:
            if strength >= 15: # Premium hands (QQ+, AK)
                raise_to = 3 * self.big_blind_amount + len(round_state.player_actions) * self.big_blind_amount
                return self._get_raise_decision(raise_to, round_state, remaining_chips, my_bet)
            elif strength >= 12 and to_call <= 2 * self.big_blind_amount: # Good hands, small raise
                return PokerAction.CALL, 0
            
            # Defend big blind if no raise
            if self.id == self.big_blind_player_id and to_call == 0:
                return PokerAction.CHECK, 0
            
            return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, my_bet: int, active_players: int) -> Tuple[PokerAction, int]:
        """ Determines post-flop action using Monte Carlo equity simulation. """
        if active_players <= 1:
            return PokerAction.CHECK, 0

        # Run simulation to find our win probability (equity)
        equity = self._monte_carlo_simulation(
            my_cards=self.my_cards,
            community_cards=round_state.community_cards,
            num_opponents=active_players - 1,
            num_sims=500  # Balance of speed and accuracy
        )

        pot_size = round_state.pot

        # Facing a bet
        if to_call > 0:
            pot_odds = to_call / (pot_size + to_call + 1e-9)

            if equity > pot_odds:
                # Monster hand, re-raise for value
                if equity > 0.85:
                    raise_size = pot_size + round_state.current_bet
                    return self._get_raise_decision(raise_size, round_state, remaining_chips, my_bet)
                # Strong hand, consider raising sometimes to mix up play
                if equity > 0.65 and random.random() < 0.3:
                    raise_size = (pot_size + round_state.current_bet) // 2
                    return self._get_raise_decision(raise_size, round_state, remaining_chips, my_bet)
                
                # Otherwise, the odds are good, so just call
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        # No bet to call, we can check or bet
        else:
            # Bet/Raise for value with strong hands
            if equity > 0.80: # Bet 3/4 pot with very strong hands
                bet_size = int(pot_size * 0.75)
                return self._get_bet_decision(bet_size, round_state, remaining_chips)
            if equity > 0.50: # Bet 1/2 pot with good hands
                bet_size = int(pot_size * 0.50)
                return self._get_bet_decision(bet_size, round_state, remaining_chips)

            # Small bluff chance on flop/turn with weak hands
            if equity < 0.2 and round_state.round in ['Flop', 'Turn'] and random.random() < 0.15:
                bluff_size = int(pot_size * 0.5)
                return self._get_bet_decision(bluff_size, round_state, remaining_chips)
            
            # Otherwise, check
            return PokerAction.CHECK, 0

    def _get_bet_decision(self, bet_size: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Helper to make a bet into a pot with no current bet. """
        # Ensure bet is legal
        bet_size = max(bet_size, round_state.min_raise if round_state.min_raise > 0 else self.big_blind_amount)
        bet_size = min(bet_size, remaining_chips)

        if bet_size >= remaining_chips:
            return PokerAction.ALL_IN, 0
        if bet_size > 0:
            return PokerAction.RAISE, bet_size
        return PokerAction.CHECK, 0

    def _get_raise_decision(self, raise_to_target: int, round_state: RoundStateClient, remaining_chips: int, my_bet: int) -> Tuple[PokerAction, int]:
        """ Helper to form a valid raise over a current bet. """
        min_raise_target = round_state.current_bet + round_state.min_raise
        final_raise_target = max(raise_to_target, min_raise_target)
        
        my_total_stack = my_bet + remaining_chips
        final_raise_target = min(final_raise_target, my_total_stack)
        
        if final_raise_target >= my_total_stack:
            return PokerAction.ALL_IN, 0
            
        if final_raise_target > round_state.current_bet:
            return PokerAction.RAISE, int(final_raise_target)
        
        # If calculated raise is not valid, fallback to calling
        if remaining_chips >= (round_state.current_bet - my_bet):
            return PokerAction.CALL, 0
        else:
            return PokerAction.ALL_IN, 0 # All-in call

    def _get_preflop_strength(self, hole_cards: List[str]) -> int:
        """ A simple pre-flop hand strength evaluator based on a point system. """
        ranks = '23456789TJQKA'
        c1_val, c1_suit = self._card_value(hole_cards[0]), hole_cards[0][1]
        c2_val, c2_suit = self._card_value(hole_cards[1]), hole_cards[1][1]

        high_card, low_card = max(c1_val, c2_val), min(c1_val, c2_val)
        
        # Base score on high card, double for pairs
        score = high_card * 2 if high_card == low_card else high_card
        if high_card == low_card and score < 10:
            score = 5 # Minimum score for small pairs
        
        # Adjustments
        if c1_suit == c2_suit: score += 2 # Suited
        
        gap = high_card - low_card - 1
        if gap == 0 and low_card > 2: score += 1 # Connectors
        elif gap == 1: pass
        elif gap == 2: score -= 1
        elif gap == 3: score -= 2
        else: score -= 4
        
        if high_card < 12 and gap <= 1: score += 1 # Bonus for connected cards below Q
        
        return score

    # --- Hand Evaluation and Monte Carlo Simulation ---

    def _monte_carlo_simulation(self, my_cards: List[str], community_cards: List[str], num_opponents: int, num_sims: int) -> float:
        """ Estimates win probability by simulating random hands. """
        deck = [r + s for r in '23456789TJQKA' for s in 'shdc']
        for card in my_cards + community_cards:
            deck.remove(card)

        wins = 0
        ties = 0

        for _ in range(num_sims):
            shuffled_deck = random.sample(deck, len(deck))
            
            num_board_cards_to_draw = 5 - len(community_cards)
            
            opponent_hands = [shuffled_deck[i*2:i*2+2] for i in range(num_opponents)]
            board_completion = shuffled_deck[num_opponents*2 : num_opponents*2 + num_board_cards_to_draw]
            
            final_board = community_cards + board_completion
            
            my_best_rank = self._evaluate_hand(my_cards, final_board)
            opponent_best_ranks = [self._evaluate_hand(hand, final_board) for hand in opponent_hands]
            
            if my_best_rank >= max(opponent_best_ranks):
                if my_best_rank == max(opponent_best_ranks):
                    ties += 1
                else:
                    wins += 1
        
        # Simplified for heads-up, this is a decent approximation for multi-way.
        return (wins + ties / 2.0) / num_sims

    def _card_value(self, card: str) -> int:
        """ Converts card string to a numerical rank. """
        rank = card[:-1]
        if rank.isdigit():
            return int(rank)
        return {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank]
        
    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> tuple:
        """ Evaluates a 7-card hand and returns its rank as a comparable tuple. """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5: return (-1,)

        best_rank = (-1,)
        for hand_5 in combinations(all_cards, 5):
            current_rank = self._get_5_card_rank(list(hand_5))
            if current_rank > best_rank:
                best_rank = current_rank
        return best_rank

    def _get_5_card_rank(self, hand: List[str]) -> tuple:
        """ Gets the rank of a 5-card hand. """
        values = sorted([self._card_value(c) for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        
        is_flush = len(set(suits)) == 1
        is_straight = (values[0] - values[4] == 4 and len(set(values)) == 5) or (values == [14, 5, 4, 3, 2])
        
        straight_high_val = values[0] if not (values == [14, 5, 4, 3, 2]) else 5
        
        if is_straight and is_flush: return (8, straight_high_val) # Straight Flush (Royal is just high val 14)

        value_counts = {v: values.count(v) for v in set(values)}
        counts = sorted(value_counts.values(), reverse=True)
        major_kickers = sorted(value_counts.keys(), key=lambda k: (value_counts[k], k), reverse=True)

        if counts[0] == 4: return (7, major_kickers[0], major_kickers[1]) # Quads
        if counts == [3, 2]: return (6, major_kickers[0], major_kickers[1]) # Full House
        if is_flush: return (5, tuple(values))
        if is_straight: return (4, straight_high_val)
        if counts[0] == 3: return (3, major_kickers[0], tuple(major_kickers[1:3])) # Trips
        if counts == [2, 2, 1]: return (2, tuple(major_kickers[:2]), major_kickers[2]) # Two Pair
        if counts[0] == 2: return (1, major_kickers[0], tuple(major_kickers[1:4])) # One Pair
        return (0, tuple(values)) # High Card