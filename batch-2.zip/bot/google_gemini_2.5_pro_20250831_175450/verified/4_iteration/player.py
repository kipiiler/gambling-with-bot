import random
import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand strength, Monte Carlo simulation for post-flop,
    and strategic betting based on pot odds and win probability.
    """

    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.starting_chips: int = 10000
        self.big_blind_amount: int = 0
        
        # Pre-computed hand strengths for pre-flop decisions (Chen formula approximation)
        # Using a simplified lookup table based on common starting hand charts.
        # Values are roughly normalized from 0 to 1.
        self.preflop_hand_strength = self._create_preflop_strength_map()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called once at the start of the game. """
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        # In a real scenario, we could track opponent tendencies over games.

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each hand. """
        self.my_hand = round_state.player_hands[self.id]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        It decides whether to FOLD, CHECK, CALL, RAISE, or go ALL_IN.
        """
        can_check = round_state.current_bet == round_state.player_bets.get(self.id, 0)
        amount_to_call = round_state.current_bet - round_state.player_bets.get(self.id, 0)
        
        active_players = [p for p in round_state.player_bets if round_state.player_actions.get(p) != 'Fold']
        active_opponents = len(active_players) - 1
        if active_opponents == 0: # If everyone else folded
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.CALL, 0)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            return self._decide_preflop_action(round_state, remaining_chips, can_check, amount_to_call)
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            return self._decide_postflop_action(round_state, remaining_chips, can_check, amount_to_call, active_opponents)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each hand. """
        # We could use this to update our opponent models.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the entire game. """
        # Final cleanup or logging could go here.
        pass

    def _decide_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take before the flop. """
        hand_strength = self._get_preflop_hand_strength(self.my_hand)

        # Short stack push/fold strategy (less than 15 big blinds)
        if self.big_blind_amount > 0 and remaining_chips < 15 * self.big_blind_amount:
            if hand_strength > 0.45: # Push with top ~45% of hands
                return PokerAction.ALL_IN, remaining_chips
            else: # Fold rest, unless we are BB and can check
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # Standard pre-flop strategy
        # Aggressive raise with premium hands
        if hand_strength > 0.8:
            # Raise 3x the big blind if unopened, or 3x the current bet
            raise_amount = max(3 * self.big_blind_amount, 3 * round_state.current_bet)
            raise_amount = min(max(raise_amount, round_state.min_raise), remaining_chips)
            return PokerAction.RAISE, raise_amount

        # Call or raise with good hands
        if hand_strength > 0.5:
            if round_state.current_bet < 5 * self.big_blind_amount:  # Call small raises
                return PokerAction.CALL, amount_to_call
            else: # Fold to large raises
                return PokerAction.FOLD, 0
        
        # Play speculative hands cheaply
        if hand_strength > 0.3:
            # Call only if it's cheap (e.g., limping or calling a min-raise)
            if amount_to_call <= 2 * self.big_blind_amount:
                return PokerAction.CALL, amount_to_call

        # Fold weak hands, but check if possible (e.g., from the big blind)
        if can_check:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    def _decide_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int, num_opponents: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take after the flop, turn, or river. """
        if num_opponents == 0:
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.CALL, 0)

        # Calculate pot odds
        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)

        # Use Monte Carlo simulation to estimate win probability
        # FIX: The variable name was misspelled as 'num_sips' in the previous iteration.
        num_sims = 200  # More simulations for better accuracy
        win_prob = self._run_monte_carlo(self.my_hand, round_state.community_cards, num_opponents, num_simulations=num_sims)
        
        # Decision based on win probability vs. pot odds
        if win_prob > pot_odds:
            # Strong hand, bet for value
            if win_prob > 0.85: # Very strong hand, likely the nuts
                bet_amount = int(round_state.pot * 0.75)
            elif win_prob > 0.65: # Good hand, confident value bet
                bet_amount = int(round_state.pot * 0.5)
            else: # Positive EV call
                if amount_to_call > 0:
                    return PokerAction.CALL, amount_to_call
                else: # If we can check, let's check to see another card
                    return PokerAction.CHECK, 0
            
            # Ensure bet is valid
            bet_amount = min(max(bet_amount, round_state.min_raise), remaining_chips)
            if bet_amount >= round_state.min_raise:
                 return PokerAction.RAISE, bet_amount
            else: # If calculated bet is too small, just call
                return PokerAction.CALL, amount_to_call

        else: # Win probability is less than pot odds
            # Bluffing logic
            # More likely to bluff in heads-up pots on scary boards
            bluff_chance = 0.0
            if num_opponents == 1:
                bluff_chance = 0.15 # 15% bluff chance in heads-up
            
            if random.random() < bluff_chance and amount_to_call > 0 and remaining_chips > round_state.pot * 0.5:
                # Semi-bluff a reasonable amount
                bluff_amount = int(round_state.pot * 0.5)
                bluff_amount = min(max(bluff_amount, round_state.min_raise), remaining_chips)
                return PokerAction.RAISE, bluff_amount
            
            # If not bluffing, check if possible, otherwise fold
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def _get_preflop_hand_strength(self, hand: List[str]) -> float:
        """ Returns a numerical strength (0-1) for a 2-card pre-flop hand. """
        card1, card2 = hand[0], hand[1]
        rank1, suit1 = card1[:-1], card1[-1]
        rank2, suit2 = card2[:-1], card2[-1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1 = rank_map[rank1]
        r2 = rank_map[rank2]
        
        high_card = max(r1, r2)
        low_card = min(r1, r2)

        # Create sorted key for lookup, e.g., 'AKs' or 'T9o'
        key_ranks = f"{rank_map_rev[high_card]}{rank_map_rev[low_card]}"
        if r1 == r2: # Pocket pair
            key = key_ranks
        else:
            key_suit = 's' if suit1 == suit2 else 'o'
            key = f"{key_ranks}{key_suit}"
        
        return self.preflop_hand_strength.get(key, 0.0)

    def _run_monte_carlo(self, my_hand: List[str], community_cards: List[str], num_opponents: int, num_simulations: int) -> float:
        """
        Estimates win probability by simulating the rest of the hand multiple times.
        """
        ranks = '23456789TJQKA'
        suits = 'shdc'
        full_deck = [r + s for r in ranks for s in suits]

        known_cards = set(my_hand + community_cards)
        deck = [card for card in full_deck if card not in known_cards]

        wins = 0
        for _ in range(num_simulations):
            shuffled_deck = random.sample(deck, len(deck))
            
            # Deal cards to opponents and complete the board
            opponent_hands = []
            for i in range(num_opponents):
                opponent_hands.append([shuffled_deck.pop(), shuffled_deck.pop()])
            
            remaining_community_cards = 5 - len(community_cards)
            sim_community = community_cards + shuffled_deck[:remaining_community_cards]

            # Evaluate hands
            my_best_hand = self._evaluate_best_hand(my_hand, sim_community)
            opponents_best_hands = [self._evaluate_best_hand(opp_hand, sim_community) for opp_hand in opponent_hands]
            
            # Check for win/tie
            my_score = my_best_hand[0]
            is_winner = True
            is_tie = False
            for opp_score, _ in opponents_best_hands:
                if opp_score > my_score:
                    is_winner = False
                    break
                if opp_score == my_score:
                    is_tie = True

            if is_winner:
                if is_tie:
                    # In case of a tie, let's count it as a partial win.
                    # A more complex model would count number of tying players.
                    wins += 0.5 
                else:
                    wins += 1

        return wins / num_simulations

    def _evaluate_best_hand(self, hole_cards, community_cards):
        """Finds the best 5-card hand from the 7 available cards."""
        all_cards = hole_cards + community_cards
        best_hand_rank = (-1,)
        
        for hand_combo in itertools.combinations(all_cards, 5):
            current_rank = self._evaluate_5_card_hand(list(hand_combo))
            if current_rank > best_hand_rank:
                best_hand_rank = current_rank
        
        return best_hand_rank

    def _evaluate_5_card_hand(self, hand: List[str]):
        """
        Evaluates a 5-card hand and returns a tuple representing its rank.
        Higher tuples are better hands. (e.g., (8, 14) for four Aces).
        """
        ranks_str = '23456789TJQKA'
        ranks_map = {r: i for i, r in enumerate(ranks_str)}
        
        ranks = sorted([ranks_map[r[:-1]] for r in hand], reverse=True)
        suits = [s[-1] for s in hand]
        
        is_flush = len(set(suits)) == 1
        
        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        counts = sorted(rank_counts.values(), reverse=True)
        
        is_straight = len(set(ranks)) == 5 and (max(ranks) - min(ranks) == 4)
        # Ace-low straight (A, 2, 3, 4, 5)
        if ranks == [12, 3, 2, 1, 0]:
            is_straight = True
            ranks = [3, 2, 1, 0, -1] # Treat Ace as low for ranking

        # Hand Ranks:
        # 9: Straight Flush
        # 8: Four of a Kind
        # 7: Full House
        # 6: Flush
        # 5: Straight
        # 4: Three of a Kind
        # 3: Two Pair
        # 2: One Pair
        # 1: High Card

        if is_straight and is_flush:
            return (9, max(ranks))
        if counts[0] == 4:
            major_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (8, major_rank, kicker)
        if counts == [3, 2]:
            three_kind_rank = [r for r, c in rank_counts.items() if c == 3][0]
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return (7, three_kind_rank, pair_rank)
        if is_flush:
            return (6, tuple(ranks))
        if is_straight:
            return (5, max(ranks))
        if counts[0] == 3:
            three_kind_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (4, three_kind_rank, tuple(kickers))
        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (3, tuple(pairs), kicker)
        if counts[0] == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (2, pair_rank, tuple(kickers))
        
        return (1, tuple(ranks))
    
    def _create_preflop_strength_map(self) -> Dict[str, float]:
        """Creates a lookup table for pre-flop hand strengths."""
        # Based on Sklansky-Malmuth starting hands, broadly categorized.
        # Pairs
        strength = {
            'AA': 1.0, 'KK': 0.95, 'QQ': 0.9, 'JJ': 0.85, 'TT': 0.8,
            '99': 0.7, '88': 0.6, '77': 0.5, '66': 0.4, '55': 0.35,
            '44': 0.3, '33': 0.3, '22': 0.3
        }
        # Suited
        strength.update({
            'AKs': 0.88, 'AQs': 0.82, 'AJs': 0.78, 'ATs': 0.75, 'A9s': 0.6, 'A8s': 0.55, 'A7s': 0.5, 'A6s': 0.45, 'A5s': 0.5, 'A4s': 0.45, 'A3s': 0.4, 'A2s': 0.4,
            'KQs': 0.76, 'KJs': 0.72, 'KTs': 0.68, 'K9s': 0.6, 'K8s': 0.4, 'K7s': 0.3,
            'QJs': 0.69, 'QTs': 0.65, 'Q9s': 0.5,
            'JTs': 0.66, 'J9s': 0.5,
            'T9s': 0.6, 'T8s': 0.45,
            '98s': 0.5, '97s': 0.4,
            '87s': 0.45, '86s': 0.3,
            '76s': 0.4, '65s': 0.35
        })
        # Off-suit
        strength.update({
            'AKo': 0.80, 'AQo': 0.74, 'AJo': 0.70, 'ATo': 0.65,
            'KQo': 0.67, 'KJo': 0.63, 'KTo': 0.58,
            'QJo': 0.60, 'QTo': 0.5,
            'JTo': 0.55
        })
        return strength

# Global map to convert rank index back to character
rank_map_rev = {
    2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9',
    10: 'T', 11: 'J', 12: 'Q', 13: 'K', 14: 'A'
}