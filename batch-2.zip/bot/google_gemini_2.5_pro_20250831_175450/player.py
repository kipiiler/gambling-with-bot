from typing import List, Tuple, Dict, Any
from collections import Counter
from itertools import combinations
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class HandEvaluator:
    """
    Helper class for all poker hand evaluation logic.
    - Calculates pre-flop hand strength using the Chen formula.
    - Evaluates the best 5-card hand from 7 cards post-flop.
    - Calculates potential drawing outs.
    """
    
    RANKS = '23456789TJQKA'
    RANK_MAP = {rank: i for i, rank in enumerate(RANKS, 2)}
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Converts a card string like 'Ah' into a tuple (14, 'h')."""
        try:
            rank = self.RANK_MAP[card[0]]
            suit = card[1]
            return rank, suit
        except KeyError:
            return 0, '' # Should not happen with valid input

    def get_chen_strength(self, hole_cards: List[str]) -> float:
        """Calculates pre-flop hand strength using the Chen formula."""
        if len(hole_cards) != 2:
            return 0.0

        card1, card2 = [self._parse_card(c) for c in hole_cards]
        rank1, suit1 = card1
        rank2, suit2 = card2

        # 1. Score highest card
        high_rank = max(rank1, rank2)
        score = {14: 10, 13: 8, 12: 7, 11: 6}.get(high_rank, high_rank / 2)

        # 2. If pair, double score
        if rank1 == rank2:
            score *= 2
            if score < 5: score = 5.0
        
        # 3. If suited, add 2
        if suit1 == suit2:
            score += 2

        # 4. Gaps between cards
        gap = abs(rank1 - rank2) - 1
        if gap == 0: pass  # Connector
        elif gap == 1: score -= 1
        elif gap == 2: score -= 2
        elif gap == 3: score -= 4
        else: score -= 5

        # 5. Bonus for connectors and 1-gappers below Q
        if rank1 < 12 and rank2 < 12 and gap < 2:
            score += 1

        return math.ceil(max(0, score))

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Dict[str, Any]:
        """
        Evaluates the best 5-card hand from the given hole and community cards.
        Returns a dictionary with hand rank (integer), name (string), and value (tuple for tie-breaking).
        Hand Ranks: 9:Straight Flush, 8:4-of-a-Kind, ..., 1:High Card.
        """
        if not hole_cards:
            return {'rank': 0, 'name': 'No Cards', 'value': (0,)}

        all_cards = [self._parse_card(c) for c in hole_cards + community_cards]
        if len(all_cards) < 5:
            ranks = tuple(sorted([c[0] for c in all_cards], reverse=True))
            return {'rank': 0, 'name': 'Not Enough Cards', 'value': ranks}

        best_hand = {'rank': 0, 'name': 'High Card', 'value': (0,)}
        for combo in combinations(all_cards, 5):
            current_hand = self._evaluate_5_card_hand(list(combo))
            if current_hand['rank'] > best_hand['rank']:
                best_hand = current_hand
            elif current_hand['rank'] == best_hand['rank']:
                if current_hand['value'] > best_hand['value']:
                    best_hand = current_hand
        
        return best_hand

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]) -> Dict[str, Any]:
        hand.sort(key=lambda x: x[0], reverse=True)
        ranks = [card[0] for card in hand]
        suits = [card[1] for card in hand]
        
        is_flush = len(set(suits)) == 1
        is_wheel = ranks == [14, 5, 4, 3, 2]
        is_straight = len(set(ranks)) == 5 and (max(ranks) - min(ranks) == 4 or is_wheel)
        
        value_ranks = tuple(ranks)
        if is_wheel:
            value_ranks = (5, 4, 3, 2, 1) # Ace plays low for value

        if is_straight and is_flush:
            return {'rank': 9, 'name': 'Straight Flush', 'value': value_ranks}
        
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)
        
        if counts[0] == 4:
            value = (main_ranks[0], main_ranks[1])
            return {'rank': 8, 'name': 'Four of a Kind', 'value': value}
        if counts == [3, 2]:
            value = (main_ranks[0], main_ranks[1])
            return {'rank': 7, 'name': 'Full House', 'value': value}
        if is_flush:
            return {'rank': 6, 'name': 'Flush', 'value': value_ranks}
        if is_straight:
            return {'rank': 5, 'name': 'Straight', 'value': value_ranks}
        if counts[0] == 3:
            value = (main_ranks[0],) + tuple(sorted(main_ranks[1:], reverse=True))
            return {'rank': 4, 'name': 'Three of a Kind', 'value': value}
        if counts == [2, 2, 1]:
            value = tuple(sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)) + \
                    tuple([r for r, c in rank_counts.items() if c == 1])
            return {'rank': 3, 'name': 'Two Pair', 'value': value}
        if counts[0] == 2:
            value = tuple([r for r, c in rank_counts.items() if c == 2]) + \
                    tuple(sorted([r for r, c in rank_counts.items() if c == 1], reverse=True))
            return {'rank': 2, 'name': 'One Pair', 'value': value}
        
        return {'rank': 1, 'name': 'High Card', 'value': value_ranks}

    def calculate_outs(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Calculates the number of 'outs' to improve the hand. Naive implementation."""
        my_cards = [self._parse_card(c) for c in hole_cards + community_cards]
        my_ranks = {c[0] for c in my_cards}
        my_suits = Counter(c[1] for c in my_cards)

        # Flush draw
        flush_outs = 0
        if max(my_suits.values(), default=0) == 4:
            flush_outs = 9
        
        # Straight draw
        straight_outs = 0
        unique_ranks_sorted = sorted(list(my_ranks))
        
        for i in range(1, 11): # Check for straights starting from Ace to 10
            potential_straight = set(range(i, i + 5))
            if i == 1: potential_straight = {14, 2, 3, 4, 5} # Wheel
            
            common_ranks = my_ranks.intersection(potential_straight)
            if len(common_ranks) == 4:
                missing_rank = list(potential_straight - common_ranks)[0]
                straight_outs += 4
        
        # This is a simplification; for example, an open-ended draw adds 8 outs,
        # but this logic counts it as two separate 4-out draws. Capping at 8.
        straight_outs = min(straight_outs, 8)
        
        # Very naive combination, does not account for shared outs (straight flush)
        return flush_outs + straight_outs


class SimplePlayer(Bot):

    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount: int = 10
        self.hand_evaluator = HandEvaluator()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, amount_to_call, can_check)
        else:
            return self._get_postflop_action(round_state, remaining_chips, amount_to_call, can_check)

    def _get_preflop_action(self, state: RoundStateClient, chips: int, to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        chen_strength = self.hand_evaluator.get_chen_strength(self.hole_cards)
        my_bet = state.player_bets.get(str(self.id), 0)
        all_in_value = chips + my_bet

        active_players = len([p for p in state.player_bets if p in state.player_actions])

        # Premium Hands (AA, KK, QQ, AKs) - Chen Score >= 10
        if chen_strength >= 10:
            if all_in_value > state.min_raise and chips > to_call:
                # 3-bet if raised, open-raise otherwise
                raise_size = state.current_bet * 3 if state.current_bet > self.big_blind_amount else self.big_blind_amount * (3 + active_players)
                amount = min(all_in_value, max(state.min_raise, raise_size))
                return PokerAction.RAISE, int(amount)
            return PokerAction.ALL_IN, 0

        # Strong Playing Hands (JJ, TT, AQs, AKo, AJs) - Chen Score >= 8
        if chen_strength >= 8:
            if state.current_bet <= self.big_blind_amount: # Open raise if no one has
                if all_in_value > state.min_raise and chips > to_call:
                    amount = min(all_in_value, max(state.min_raise, self.big_blind_amount * 3))
                    return PokerAction.RAISE, int(amount)
            
            # Call small-medium raises
            if chips > to_call and to_call < 0.1 * (chips + my_bet):
                return PokerAction.CALL, 0
            elif chips <= to_call: # Committed to call if short stacked
                return PokerAction.ALL_IN, 0
        
        # Speculative Hands (mid-pairs, suited connectors) - Chen Score >= 6
        if chen_strength >= 6:
            # Play only if cheap, good for set mining or hitting draws
            if can_check:
                return PokerAction.CHECK, 0
            if chips > to_call and to_call <= self.big_blind_amount * 2:
                return PokerAction.CALL, 0
        
        # Fold all other hands unless we can check
        if can_check:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def _get_postflop_action(self, state: RoundStateClient, chips: int, to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        my_bet = state.player_bets.get(str(self.id), 0)
        all_in_value = chips + my_bet

        hand_eval = self.hand_evaluator.evaluate_hand(self.hole_cards, state.community_cards)
        hand_rank = hand_eval['rank']

        pot_total = state.pot + to_call
        pot_odds = (to_call / pot_total) if pot_total > 0 else 0
        
        outs = self.hand_evaluator.calculate_outs(self.hole_cards, state.community_cards)
        equity = outs * (0.04 if state.round == 'Flop' else 0.02)
        
        is_monster = hand_rank >= 4  # Three of a Kind or better
        is_strong_made = hand_rank >= 2 # One Pair or better
        is_strong_draw = equity > 0.30 # >7 outs on flop

        # Monster Hands: Value bet/raise
        if is_monster:
            # If short stacked relative to pot, go all-in
            if all_in_value < state.pot * 1.5:
                 return PokerAction.ALL_IN, 0

            if all_in_value > state.min_raise and chips > to_call:
                # Bet 2/3 of the pot
                bet_amount = int(state.pot * 0.66)
                amount = min(all_in_value, max(state.min_raise, bet_amount))
                return PokerAction.RAISE, int(amount)
            elif chips > to_call:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, 0

        # Strong Draws: Play with pot odds
        if is_strong_draw:
            if can_check: # Semi-bluff
                if all_in_value > state.min_raise and chips > to_call:
                    bet_amount = int(state.pot * 0.5)
                    amount = min(all_in_value, max(state.min_raise, bet_amount))
                    return PokerAction.RAISE, int(amount)
                return PokerAction.CHECK, 0

            if equity >= pot_odds: # Call if odds are good
                if chips > to_call:
                    return PokerAction.CALL, 0
                else: 
                    return PokerAction.ALL_IN, 0

        # Medium Strength Hands: Pot control
        if is_strong_made:
            if can_check:
                return PokerAction.CHECK, 0
            # Call small bets
            if chips > to_call and to_call < state.pot * 0.4:
                return PokerAction.CALL, 0

        # Weak hands or missed draws
        if can_check:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass