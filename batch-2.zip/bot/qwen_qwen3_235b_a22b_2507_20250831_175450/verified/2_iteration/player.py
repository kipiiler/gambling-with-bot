from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.position = None
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.hand_strength = 0.0
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2
        if self.id == big_blind_player_id:
            self.is_big_blind = True
            self.is_small_blind = False
        elif self.id == small_blind_player_id:
            self.is_big_blind = False
            self.is_small_blind = True
        else:
            self.is_big_blind = False
            self.is_small_blind = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hand-specific data
        self.hand_strength = 0.0

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # Simple hand strength evaluation for demonstration
        if len(community_cards) == 0:
            # Pre-flop: just value high cards and pairs
            ranks = [card[0] for card in hole_cards]
            if ranks[0] == ranks[1]:
                # Pocket pairs
                if ranks[0] in 'A':
                    return 0.9
                elif ranks[0] in 'K':
                    return 0.8
                elif ranks[0] in 'Q':
                    return 0.7
                elif ranks[0] in 'J':
                    return 0.6
                elif ranks[0] in 'T':
                    return 0.5
                else:
                    return 0.4
            else:
                # High card strength
                high_card = max(ranks)
                if high_card in 'A':
                    return 0.4 + 0.1 * ('K' in ranks)
                elif high_card in 'K':
                    return 0.3 + 0.1 * ('Q' in ranks or 'J' in ranks)
                elif high_card in 'Q':
                    return 0.25 + 0.1 * ('J' in ranks)
                elif high_card in 'J':
                    return 0.2
                elif high_card in 'T':
                    return 0.15
                else:
                    return 0.1
        else:
            # Post-flop: increase strength with community cards
            # This is a dummy simulation for simplicity
            return 0.3 + len(community_cards) * 0.1 + random.uniform(0, 0.1)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract current state
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_id = str(self.id)
        player_current_bet = round_state.player_bets.get(player_id, 0)
        
        # Determine how much the player needs to call
        call_amount = current_bet - player_current_bet

        # Estimate hand strength
        hole_cards_str = getattr(self, 'hole_cards', [])
        self.hand_strength = self.evaluate_hand_strength(hole_cards_str, community_cards)

        # Action logic
        # If we need to call more than 1/3 of our remaining chips, only strong hands call
        stack_commitment_ratio = call_amount / max(remaining_chips, 1)
        pot_odds = call_amount / max(pot, 1)

        # Avoid invalid actions
        if current_bet == 0:
            # Can check or raise
            if self.hand_strength > 0.3:
                # Raise with decent hands
                raise_amount = min(pot + call_amount, remaining_chips)
                raise_amount = max(raise_amount, min_raise)
                if raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    # If cannot raise, go all-in or check
                    if remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Facing a bet
            if self.hand_strength > 0.7:
                # Strong hand: raise or call
                if self.hand_strength > 0.8 and remaining_chips > 0:
                    # Raise aggressively with very strong hands
                    raise_amount = pot + 2 * call_amount
                    raise_amount = min(raise_amount, max_raise)
                    raise_amount = max(raise_amount, min_raise)
                    if raise_amount >= current_bet + min_raise:
                        return (PokerAction.RAISE, raise_amount)
                # Call otherwise
                if remaining_chips >= call_amount:
                    return (PokerAction.CALL, 0)
                else:
                    # Can't call, so all-in or fold
                    if remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif self.hand_strength > 0.4 and stack_commitment_ratio < 0.2:
                # Medium hand and cheap to call
                if remaining_chips >= call_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Fold weak hands
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: learn from round result
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: analysis at game end
        pass