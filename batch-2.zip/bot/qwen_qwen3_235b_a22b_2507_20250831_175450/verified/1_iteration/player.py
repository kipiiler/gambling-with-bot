from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import math

class HandStrength(Enum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_position = None
        self.num_players = 0
        self.hand_ranking_history = []
        self.opp_aggression = {}  # Track how often others raise
        self.opp_frequent_folders = {}  # Track players who fold often
        self.total_hands = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.num_players = len(all_players)
        
        # Initialize opponent tracking
        for pid in all_players:
            self.opp_aggression[pid] = 0.0
            self.opp_frequent_folders[pid] = 0.0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards at round start (in case cards are re-dealt)
        if hasattr(round_state, 'hole_cards') and self.id in round_state.hole_cards:
            self.hole_cards = round_state.hole_cards[self.id]
        else:
            # Fallback if not provided — should be handled by server
            pass

        self.total_hands += 1
        # Adjust aggression based on stack
        self.dynamic_aggression_factor = min(1.0, remaining_chips / 5000)  # More aggressive when short-stacked

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Returns a normalized hand strength score between 0 (worst) and 1 (best)"""
        all_cards = hole_cards + community_cards
        ranks = [self._card_rank(card) for card in all_cards]
        suits = [self._card_suit(card) for card in all_cards]
        
        # Count ranks and suits
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        # Sort ranks for straight detection
        sorted_ranks = sorted(set(ranks))
        # Add low end of straight for A-5
        if 14 in sorted_ranks:  # Ace
            sorted_ranks.append(1)

        # Check for straight
        def has_straight(ranks_list):
            if len(ranks_list) < 5:
                return False
            sorted_uniq = sorted(ranks_list)
            if len(sorted_uniq) < 5:
                return False
            consecutive = 1
            for i in range(1, len(sorted_uniq)):
                if sorted_uniq[i] == sorted_uniq[i-1] + 1:
                    consecutive += 1
                    if consecutive >= 5:
                        return True
                else:
                    consecutive = 1
            return False

        # Check for flush
        flush_suit = None
        for suit, count in suit_count.items():
            if count >= 5:
                flush_suit = suit
                break

        # Get high card
        hand_strength = HandStrength.HIGH_CARD
        score = 0
        kickers = sorted(ranks, reverse=True)[:5]

        # Check hand types
        pairs = []
        triples = []
        quads = []
        for rank, cnt in rank_count.items():
            if cnt == 2:
                pairs.append(rank)
            elif cnt == 3:
                triples.append(rank)
            elif cnt == 4:
                quads.append(rank)

        # Four of a kind
        if quads:
            hand_strength = HandStrength.FOUR_OF_A_KIND
            score = 7 + quads[0] / 100
        # Full house
        elif triples and pairs:
            hand_strength = HandStrength.FULL_HOUSE
            score = 6 + triples[0] / 100 + pairs[0] / 1000
        # Flush
        elif flush_suit:
            flush_cards = [r for r, s in zip(ranks, suits) if s == flush_suit]
            flush_cards = sorted([r if r != 14 else 1 for r in flush_cards], reverse=True)[:5]  # Use Ace as 14 or 1
            hand_strength = HandStrength.FLUSH
            score = 5 + sum([c / (14**i) for i, c in enumerate(flush_cards)])
        # Straight
        elif has_straight(ranks):
            # Find highest straight
            sorted_ranks = sorted(set(ranks))
            if 14 in sorted_ranks:
                sorted_ranks.append(1)
            sorted_ranks = sorted(sorted_ranks, reverse=True)
            straight_high = 5
            consecutive = 1
            for i in range(1, len(sorted_ranks)):
                if sorted_ranks[i-1] - sorted_ranks[i] == 1:
                    consecutive += 1
                    if consecutive >= 5:
                        straight_high = sorted_ranks[i-4]
                        break
                else:
                    consecutive = 1
            if straight_high == 14 and 5 in ranks:
                straight_high = 5  # 5-high straight
            hand_strength = HandStrength.STRAIGHT
            score = 4 + straight_high / 100
        # Three of a kind
        elif triples:
            kickers = [r for r in ranks if r != triples[0]]
            kickers = sorted(kickers, reverse=True)[:2]
            hand_strength = HandStrength.THREE_OF_A_KIND
            score = 3 + triples[0] / 100 + (kickers[0] if len(kickers) > 0 else 0) / 1000
        # Two pair
        elif len(pairs) >= 2:
            pairs = sorted(pairs, reverse=True)[:2]
            kickers = [r for r in ranks if r not in pairs]
            kickers = sorted(kickers, reverse=True)[:1]
            hand_strength = HandStrength.TWO_PAIR
            score = 2 + pairs[0] / 100 + pairs[1] / 1000 + (kickers[0] if kickers else 0) / 10000
        # One pair
        elif pairs:
            kickers = [r for r in ranks if r != pairs[0]]
            kickers = sorted(kickers, reverse=True)[:3]
            hand_strength = HandStrength.ONE_PAIR
            base_score = 1 + pairs[0] / 100
            for i, k in enumerate(kickers):
                base_score += k / (1000 * (10**i))
            score = base_score
        # High card
        else:
            score = sum([k / (14**i) for i, k in enumerate(kickers)]) if kickers else 0

        # Normalize score: strongest possible is ~9.14, weakest is ~0
        normalized_score = min(1.0, score / 10.0)
        return normalized_score

    def _card_rank(self, card: str) -> int:
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            return int(rank_char)

    def _card_suit(self, card: str) -> str:
        return card[-1]

    def estimate_win_probability(self, hole_cards: List[str], community_cards: List[str], simulations: int = 100) -> float:
        """Monte Carlo estimation of winning probability"""
        if len(community_cards) == 5:
            # At showdown, just evaluate
            return self.evaluate_hand_strength(hole_cards, community_cards)

        # Estimate outs and simulate
        known_cards = set(hole_cards + community_cards)
        deck = [r+s for r in '23456789TJQKA' for s in 'shdc' if r+s not in known_cards]
        wins = 0
        total = 0

        for _ in range(simulations):
            random.shuffle(deck)
            remaining_cards_needed = 5 - len(community_cards)
            simulated_board = community_cards + deck[:remaining_cards_needed]
            my_strength = self.evaluate_hand_strength(hole_cards, simulated_board)
            # Assume one opponent with random cards
            opponent_cards = deck[remaining_cards_needed:remaining_cards_needed+2]
            opp_strength = self.evaluate_hand_strength(opponent_cards, simulated_board)
            if my_strength > opp_strength:
                wins += 1
            total += 1

        # Smooth probability
        return wins / (total + 1e-8)

    def position(self, round_state: RoundStateClient) -> str:
        """Estimate position: Early, Middle, Late"""
        acting_players = round_state.current_player
        if self.id not in acting_players:
            return "Unknown"
        idx = acting_players.index(self.id)
        if idx == 0 or idx == 1:
            return "Early"
        elif idx < len(acting_players) - 2:
            return "Middle"
        else:
            return "Late"

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Ensure we're in the game
            if self.id is None:
                return PokerAction.FOLD, 0

            # Current betting context
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)  # Safety cap
            pot = round_state.pot
            community_cards = round_state.community_cards

            # Avoid zero division
            pot = max(pot, 1)

            # Get bet needed to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_current_bet

            # If already all-in
            if remaining_chips <= 0:
                return PokerAction.CHECK if current_bet == my_current_bet else PokerAction.FOLD

            # Evaluate hand
            hand_strength = 0.0
            win_prob = 0.0

            if self.hole_cards:
                hand_strength = self.evaluate_hand_strength(self.hole_cards, community_cards)
                win_prob = self.estimate_win_probability(self.hole_cards, community_cards, simulations=50)
            else:
                win_prob = 0.1  # Default low

            # Determine round
            is_preflop = round_state.round == 'Preflop'
            is_flop = round_state.round == 'Flop'
            is_turn = round_state.round == 'Turn'
            is_river = round_state.round == 'River'

            # Adjust win probability based on table image and position
            pos = self.position(round_state)
            position_multiplier = 1.0
            if pos == "Late":
                position_multiplier = 1.1
            elif pos == "Early":
                position_multiplier = 0.9

            win_prob *= position_multiplier

            # Consider stack size
            stack_to_bb = remaining_chips / max(self.blind_amount, 1)
            is_short_stack = stack_to_bb < 10

            # Aggression based on hand and position
            action_value = win_prob * 2 - 0.2  # Base threshold

            # Pre-flop starting hand adjustments
            if is_preflop:
                starting_hand_value = self._evaluate_starting_hand(self.hole_cards)
                win_prob = max(win_prob, starting_hand_value)
                action_value = win_prob * 2 - 0.1

            # Bluffing occasionally in late position on later streets if high card or draw
            can_bluff = pos == "Late" and len(community_cards) >= 3 and random.random() < 0.15
            is_bluffing = can_bluff and win_prob < 0.3 and random.random() < 0.3

            # Default action
            action = PokerAction.FOLD
            raise_amount = 0

            # Decision logic
            if to_call == 0:
                if win_prob > 0.5 or is_bluffing:
                    # Raise or bet
                    if is_preflop:
                        bet_size = min(3 * self.blind_amount, remaining_chips)
                    else:
                        bet_size = min(int(win_prob * pot), max_raise)
                    bet_size = max(min_raise, min(bet_size, max_raise))
                    if bet_size >= remaining_chips * 0.9:
                        action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.RAISE
                        raise_amount = bet_size
                else:
                    action = PokerAction.CHECK
            else:
                # Facing a bet
                pot_odds = to_call / (pot + to_call + 1e-8)
                call_ev = win_prob - pot_odds

                if call_ev > 0.1:
                    # Strong call or raise
                    if win_prob > 0.7 and pot < remaining_chips * 3:
                        raise_size = min(int(0.75 * pot), max_raise)
                        if raise_size >= remaining_chips * 0.9:
                            action = PokerAction.ALL_IN
                        elif raise_size >= min_raise:
                            action = PokerAction.RAISE
                            raise_amount = raise_size
                        else:
                            action = PokerAction.CALL
                    else:
                        action = PokerAction.CALL
                elif call_ev > -0.1 and to_call <= remaining_chips * 0.5:
                    # Marginal call (draws, position)
                    action = PokerAction.CALL
                elif is_bluffing and to_call <= pot and to_call <= remaining_chips * 0.3:
                    # Bluff raise
                    bluff_raise = min(int(0.7 * pot), max_raise)
                    if bluff_raise >= min_raise:
                        action = PokerAction.RAISE
                        raise_amount = bluff_raise
                    else:
                        action = PokerAction.CALL
                elif is_short_stack and win_prob > 0.6:
                    # Short stack push/fold
                    if to_call <= remaining_chips * 0.5:
                        action = PokerAction.RAISE
                        raise_amount = min(max(to_call * 2, min_raise), remaining_chips)
                        if raise_amount >= remaining_chips * 0.9:
                            action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

            # Safety and bounds enforcement
            if action == PokerAction.RAISE:
                if raise_amount < min_raise:
                    raise_amount = min_raise
                if raise_amount > max_raise:
                    action = PokerAction.ALL_IN
                elif raise_amount >= remaining_chips * 0.95:
                    action = PokerAction.ALL_IN

            if action == PokerAction.ALL_IN:
                raise_amount = remaining_chips

            # Final fallback: ensure valid action
            if action == PokerAction.RAISE and (raise_amount < min_raise or raise_amount > max_raise):
                # Invalid raise, fallback to call or fold
                if to_call == 0:
                    action = PokerAction.CHECK
                elif to_call < remaining_chips:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.ALL_IN

            return action, raise_amount

        except Exception as e:
            # On any error, fold to avoid penalties
            return PokerAction.FOLD, 0

    def _evaluate_starting_hand(self, hole_cards: List[str]) -> float:
        """Evaluate strength of starting hand (pre-flop)"""
        if len(hole_cards) < 2:
            return 0.1
        c1, c2 = hole_cards[0], hole_cards[1]
        r1, r2 = self._card_rank(c1), self._card_rank(c2)
        s1, s2 = self._card_suit(c1), self._card_suit(c2)

        # Pocket pairs
        if r1 == r2:
            if r1 >= 10:
                return 0.8
            elif r1 >= 8:
                return 0.6
            elif r1 >= 6:
                return 0.5
            else:
                return 0.4

        # Suited hands
        suited = s1 == s2
        connector = abs(r1 - r2) == 1
        one_gap = abs(r1 - r2) == 2
        two_gap = abs(r1 - r2) == 3

        high_card = max(r1, r2)
        avg_rank = (r1 + r2) / 2

        score = 0.0
        if high_card >= 12:  # A or K
            score += 0.2
        if high_card >= 11:  # Q
            score += 0.15
        if suited:
            score += 0.15
        if connector:
            score += 0.15
        elif one_gap:
            score += 0.1
        elif two_gap:
            score += 0.05

        # Adjust for non-connectors
        if abs(r1 - r2) > 3:
            score -= 0.05

        # Gap penalty
        if abs(r1 - r2) > 4:
            score -= 0.1

        # Minimum viable hand
        if score < 0.2:
            score = 0.15

        return min(score, 0.7)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent behavior tracking
        for pid_str, action in round_state.player_actions.items():
            pid = int(pid_str)
            if pid != self.id and pid in self.opp_aggression:
                if action in ['Raise', 'AllIn']:
                    self.opp_aggression[pid] += 1.0
                elif action == 'Fold':
                    self.opp_frequent_folders[pid] += 1.0

        # Normalize over total hands
        for pid in self.all_players:
            if pid != self.id:
                self.opp_aggression[pid] /= max(1, self.total_hands)
                self.opp_frequent_folders[pid] /= max(1, self.total_hands)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup — unused in this version
        pass