from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.my_hand = None
        self.game_state_history = []
        self.current_round_data = None
        self.position_status = None  # early, middle, late position
        self.hand_strength_estimate = 0.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {pid: hand for pid, hand in enumerate(player_hands)}
        self.my_hand = player_hands[self.id] if self.id is not None else None
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.game_state_history = []
        self._update_position_status()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_data = round_state
        self._update_position_status()

    def _update_position_status(self):
        if self.id is None or not self.all_players:
            self.position_status = "early"
            return
        active_players = [p for p in self.all_players if p >= 0]
        if not active_players:
            self.position_status = "early"
            return
        pos_index = active_players.index(self.id) if self.id in active_players else 0
        total = len(active_players)
        if total == 2:
            self.position_status = "late" if pos_index == 1 else "early"
        elif pos_index < total // 3:
            self.position_status = "early"
        elif pos_index < 2 * total // 3:
            self.position_status = "middle"
        else:
            self.position_status = "late"

    def _parse_card(self, card: str) -> Tuple[str, str]:
        return card[:-1], card[-1]

    def _card_rank_value(self, rank: str) -> int:
        if rank.isdigit():
            return int(rank)
        return {"J": 11, "Q": 12, "K": 13, "A": 14}.get(rank, 0)

    def _is_suited(self, cards: List[str]) -> bool:
        if len(cards) < 2:
            return False
        _, suit1 = self._parse_card(cards[0])
        for card in cards[1:]:
            _, suit = self._parse_card(card)
            if suit != suit1:
                return False
        return True

    def _is_connected(self, ranks: List[str]) -> bool:
        values = sorted([self._card_rank_value(r) for r in ranks])
        return all(values[i+1] - values[i] == 1 for i in range(len(values)-1))

    def _evaluate_hole_strength(self) -> float:
        if not self.my_hand:
            return 0.0

        ranks = [self._parse_card(card)[0] for card in self.my_hand]
        r1, r2 = ranks[0], ranks[1]
        v1, v2 = self._card_rank_value(r1), self._card_rank_value(r2)

        score = 0.0

        # Pocket pairs
        if r1 == r2:
            pair_value = v1
            if pair_value >= 14:  # AA
                score += 0.9
            elif pair_value >= 13:  # KK
                score += 0.8
            elif pair_value >= 12:  # QQ
                score += 0.7
            elif pair_value >= 11:  # JJ
                score += 0.6
            elif pair_value >= 10:  # TT
                score += 0.5
            else:
                score += 0.3 + (pair_value - 2) * 0.02

        # High cards
        if v1 >= 11 or v2 >= 11:  # Face cards
            score += 0.1
        if v1 == 14 or v2 == 14:  # Ace
            score += 0.2

        # Connectors and suited
        if abs(v1 - v2) == 1:  # Connected
            score += 0.15
        elif abs(v1 - v2) == 2:  # One gap
            score += 0.1
        elif abs(v1 - v2) == 3:  # Two gaps
            score += 0.05

        if self._is_suited(self.my_hand):
            score += 0.1

        # Adjust for suited connectors
        if self._is_suited(self.my_hand) and abs(v1 - v2) <= 2:
            score += 0.1

        # Broadways
        if v1 >= 11 and v2 >= 11:
            score += 0.2

        return min(score, 1.0)

    def _estimate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.my_hand:
            return 0.0

        hole_ranks = [self._parse_card(card)[0] for card in self.my_hand]
        hole_values = [self._card_rank_value(r) for r in hole_ranks]

        community_cards = round_state.community_cards
        all_cards = self.my_hand + community_cards
        all_ranks = [self._parse_card(card)[0] for card in all_cards]
        all_values = [self._card_rank_value(r) for r in all_ranks]

        # Count pairs
        rank_count = {}
        for r in all_ranks:
            rank_count[r] = rank_count.get(r, 0) + 1

        pairs = sum(1 for count in rank_count.values() if count >= 2)
        trips = sum(1 for count in rank_count.values() if count >= 3)
        quads = sum(1 for count in rank_count.values() if count >= 4)
        flush_suit_count = {}
        for card in all_cards:
            _, suit = self._parse_card(card)
            flush_suit_count[suit] = flush_suit_count.get(suit, 0) + 1
        has_flush_draw = any(count >= 4 for count in flush_suit_count.values())
        has_flush = any(count >= 5 for count in flush_suit_count.values())

        # Straight potential
        unique_values = sorted(set(all_values))
        straight_count = 0
        for i in range(len(unique_values) - 4):
            if unique_values[i+4] - unique_values[i] == 4:
                straight_count += 1

        has_straight_draw = False
        for i in range(len(unique_values) - 3):
            if unique_values[i+3] - unique_values[i] <= 4:
                has_straight_draw = True
                break

        # Initial strength from hole cards
        base_strength = self._evaluate_hole_strength()

        # Adjust based on board
        if round_state.round == "Preflop":
            return base_strength

        elif round_state.round == "Flop":
            if pairs >= 1:
                if any(count == 3 for card in self.my_hand for r in [self._parse_card(card)[0]] if rank_count.get(r,0) >= 3):
                    return 0.8  # trips with hole cards
                elif pairs == 2:
                    return 0.7  # two pair
                else:
                    return 0.5
            if has_flush_draw and self._is_suited(self.my_hand):
                return base_strength + 0.2
            if has_straight_draw:
                return base_strength + 0.15
            return base_strength * 0.7

        elif round_state.round == "Turn":
            if quads:
                return 1.0
            if trips and pairs >= 2:
                return 0.95  # full house
            if flush_suit_count and max(flush_suit_count.values()) >= 5:
                own_flush = sum(1 for card in self.my_hand for suit in [self._parse_card(card)[1]] if flush_suit_count[suit] >= 5)
                if own_flush > 0:
                    return 0.9
            if straight_count > 0:
                return 0.85
            if trips:
                return 0.6
            if pairs >= 2:
                return 0.65
            if has_flush_draw and self._is_suited(self.my_hand):
                return base_strength + 0.25
            return base_strength * 0.5

        elif round_state.round == "River":
            if quads:
                return 1.0
            if trips and pairs >= 2:
                return 0.95
            if max(flush_suit_count.values(), default=0) >= 5:
                own_flush = sum(1 for card in self.my_hand for suit in [self._parse_card(card)[1]] if flush_suit_count.get(suit,0) >= 5)
                if own_flush > 0:
                    return 0.9
            if straight_count > 0:
                return 0.85
            if trips:
                return 0.6
            if pairs == 2:
                return 0.6
            if pairs == 1:
                my_pair = any(rank_count.get(self._parse_card(card)[0],0) >= 2 for card in self.my_hand)
                if my_pair:
                    return 0.5
            # High card
            max_value_in_hand = max(hole_values)
            max_value_on_board = max(all_values) if all_values else 0
            if max_value_in_hand == 14 and max_value_in_hand == max_value_on_board:
                return 0.35
            return 0.1

        return base_strength

    def _is_check_allowed(self, round_state: RoundStateClient) -> bool:
        return round_state.current_bet == 0 or round_state.player_bets.get(str(self.id), 0) >= round_state.current_bet

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            self.current_round_data = round_state
            self.hand_strength_estimate = self._estimate_hand_strength(round_state)
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = max(0, round_state.current_bet - my_bet)
            pot_size = round_state.pot

            position_factor = {"early": 0.7, "middle": 1.0, "late": 1.2}.get(self.position_status, 1.0)

            aggro_multiplier = 1.0
            if round_state.current_player and len(round_state.current_player) > 1:
                # Adjust for multi-way pots
                aggro_multiplier = 1.5 if len(round_state.current_player) >= 3 else 1.0

            # Action decision
            action = PokerAction.FOLD
            raise_amount = 0

            if self._is_check_allowed(round_state) and round_state.current_bet == 0:
                if self.hand_strength_estimate > 0.3:
                    # Check or small raise
                    if self.hand_strength_estimate > 0.6:
                        action = PokerAction.RAISE
                        raise_amount = min(
                            round_state.min_raise + int(pot_size * 0.3),
                            round_state.max_raise,
                            remaining_chips
                        )
                    else:
                        action = PokerAction.CHECK
                else:
                    action = PokerAction.CHECK
            else:
                if to_call == 0:
                    action = PokerAction.CHECK
                elif to_call >= remaining_chips:
                    # All-in required to call
                    if self.hand_strength_estimate > 0.7:
                        action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.FOLD
                else:
                    pot_odds = to_call / (pot_size + to_call + 1e-8)
                    equity_required = pot_odds
                    equity = self.hand_strength_estimate

                    if equity > equity_required * 1.5:
                        if equity > 0.8:
                            raise_size = min(
                                int(pot_size * (2.0 if aggro_multiplier > 1.0 else 1.0)),
                                round_state.max_raise,
                                remaining_chips
                            )
                            action = PokerAction.RAISE
                            raise_amount = max(round_state.min_raise, raise_size)
                        else:
                            action = PokerAction.CALL
                    elif equity > equity_required * 0.8:
                        action = PokerAction.CALL
                    else:
                        # Bluff occasionally in late position with semi-bluff potential
                        if (self.position_status == "late" and self.hand_strength_estimate > 0.25 and
                            round_state.round in ["Flop", "Turn"] and len(round_state.community_cards) >= 3):
                            if equity > 0.15 and has_draw_potential(round_state, self.my_hand):
                                action = PokerAction.RAISE
                                raise_amount = min(
                                    int(pot_size * 0.7),
                                    round_state.max_raise,
                                    remaining_chips
                                )
                            else:
                                action = PokerAction.FOLD
                        else:
                            action = PokerAction.FOLD

            # Final validation of action
            if action == PokerAction.RAISE:
                min_raise_total = my_bet + round_state.min_raise
                if raise_amount <= 0:
                    action = PokerAction.CALL
                elif my_bet + raise_amount < min_raise_total:
                    raise_amount = min_raise_total - my_bet
                elif my_bet + raise_amount > my_bet + round_state.max_raise:
                    raise_amount = round_state.max_raise
                if raise_amount <= 0:
                    action = PokerAction.CALL
            elif action == PokerAction.ALL_IN:
                raise_amount = remaining_chips
            elif action == PokerAction.CALL:
                raise_amount = to_call
            elif action == PokerAction.CHECK:
                if round_state.current_bet > my_bet:
                    action = PokerAction.CALL
                    raise_amount = to_call
                else:
                    raise_amount = 0
            else:  # FOLD
                raise_amount = 0

            return action, raise_amount

        except Exception as e:
            # On any error, fold to avoid exception crash
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.game_state_history.append({
            'round_num': round_state.round_num,
            'round': round_state.round,
            'pot': round_state.pot,
            'remaining_chips': remaining_chips,
            'actions': round_state.player_actions
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Log final results if needed
        pass

def has_draw_potential(round_state: RoundStateClient, hole_cards: List[str]) -> bool:
    if not hole_cards or len(hole_cards) != 2:
        return False
    all_cards = hole_cards + round_state.community_cards
    rank_count = {}
    suit_count = {}
    values = []

    for card in all_cards:
        rank, suit = card[:-1], card[-1]
        rank_count[rank] = rank_count.get(rank, 0) + 1
        suit_count[suit] = suit_count.get(suit, 0) + 1
        values.append(SimplePlayer()._card_rank_value(rank))

    # Flush draw: 4 same suits including hole cards?
    for suit, count in suit_count.items():
        if count == 4:
            hole_suits = [c[-1] for c in hole_cards]
            if hole_suits.count(suit) >= 1:
                return True

    # Straight draw: check if 4 connected cards
    unique_values = sorted(set(values))
    for i in range(len(unique_values) - 3):
        if unique_values[i+3] - unique_values[i] <= 4:
            # Check if hole cards contribute
            hole_vals = [SimplePlayer()._card_rank_value(c[:-1]) for c in hole_cards]
            if any(abs(v - unique_values[i]) <= 4 for v in hole_vals):
                return True

    return False