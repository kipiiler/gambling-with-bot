from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.current_hand = []
        self.position = None  # 'small', 'big', 'others'
        self.is_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_hand = self.player_hands.copy()
        self.is_blind = (self.id == self.big_blind_player_id or self.id == self.small_blind_player_id)
        if self.id == self.small_blind_player_id:
            self.position = "small"
        elif self.id == self.big_blind_player_id:
            self.position = "big"
        else:
            self.position = "others"

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Extract state
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            community_cards = round_state.community_cards
            current_player_id = round_state.current_player[0] if round_state.current_player else None

            if current_player_id != self.id:
                return PokerAction.FOLD, 0

            # Determine round
            is_preflop = round_state.round == "Preflop"
            is_flop = round_state.round == "Flop"
            is_turn = round_state.round == "Turn"
            is_river = round_state.round == "River"

            hole_cards = self.current_hand
            total_cards = hole_cards + community_cards

            # Check the hand strength
            hand_strength = self.evaluate_hand(total_cards) if len(total_cards) >= 3 else 0.01

            # Starting hand strength for preflop
            if is_preflop:
                hand_strength = self.preflop_hand_strength(hole_cards)

            # Simple strategy based on hand strength, position, and bet pressure
            in_position = self.is_in_position()

            current_player_call = current_bet - round_state.player_bets.get(str(self.id), 0)

            # Default action to check/fold unless conditions require otherwise
            action = PokerAction.CHECK
            raise_amount = 0

            # In preflop, raise with strong hands or call if priced in
            if is_preflop:
                if hand_strength >= 0.7:
                    if current_bet == 0:
                        action = PokerAction.RAISE
                        raise_amount = min(max_raise, max(min_raise, blind_amount * 3))
                    elif current_bet <= remaining_chips * 0.1:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.RAISE
                        raise_amount = min(max_raise, max(min_raise, current_bet * 2))

                elif hand_strength >= 0.4:
                    if current_bet <= self.blind_amount or current_player_call <= blind_amount * 2:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    if current_player_call == 0:
                        action = PokerAction.CHECK
                    else:
                        action = PokerAction.FOLD
            else:
                # Post-flop decision
                if hand_strength >= 0.7:
                    if current_bet == 0:
                        action = PokerAction.RAISE
                        raise_amount = min(max_raise, max(min_raise, self.blind_amount * 3))
                    else:
                        action = PokerAction.RAISE
                        raise_amount = min(max_raise, max(current_bet * 2, min_raise))
                elif hand_strength >= 0.4:
                    if current_player_call == 0:
                        action = PokerAction.CHECK
                    elif current_player_call <= remaining_chips * 0.1:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    if current_player_call == 0:
                        action = PokerAction.CHECK
                    else:
                        action = PokerAction.FOLD

            if action == PokerAction.RAISE:
                # Ensure raise is valid
                if min_raise == 0:
                    # Sometimes min_raise is 0 when no one has raised yet
                    min_raise = max(2 * current_bet, blind_amount)
                    raise_amount = max(raise_amount, min_raise)
                raise_total = round_state.player_bets.get(str(self.id), 0) + raise_amount
                current_pot_raise = round_state.current_bet if round_state.player_bets.get(str(self.id), 0) < round_state.current_bet else 0
                if raise_total <= current_pot_raise:
                    # Invalid raise amount; fallback to CALL or FOLD
                    if round_state.current_bet > 0:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CHECK, 0

                raise_amount = min(raise_amount, max_raise)
                raise_amount = max(raise_amount, min_raise)
                return PokerAction.RAISE, raise_amount

            if action == PokerAction.CALL:
                if current_player_call > 0:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.CHECK, 0

            if action == PokerAction.FOLD:
                return PokerAction.FOLD, 0

            if current_player_call == 0:
                return PokerAction.CHECK, 0
            else:
                # Default: if we are not covered by check, and call not chosen, call anyway to avoid fold
                return PokerAction.CALL, 0

        except Exception as e:
            # Fallback to safe fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up if needed
        self.current_hand = []
        self.position = None
        self.is_blind = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game over, do nothing
        pass

    def preflop_hand_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) != 2:
            return 0.1

        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]

        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        r1 = rank_values[rank1]
        r2 = rank_values[rank2]

        # Swap to high to low
        if r1 < r2:
            r1, r2 = r2, r1

        score = 0.0

        # Pocket pairs
        if r1 == r2:
            score = 0.2 + (r1 - 2) * 0.06
        else:
            # Off-suit and suited
            is_suited = (suit1 == suit2)
            gap = r1 - r2

            # Bonus for suited
            if is_suited:
                score += 0.03

            # Bonus for connected
            if gap <= 4:
                score += 0.04 - (gap * 0.01)

            # Big cards
            if r1 >= 10:
                score += 0.05
            if r2 >= 10:
                score += 0.03

            # Pairs in high cards
            if r1 == 14 and r2 >= 10:
                score += 0.06  # AK, AQ, AJ

            # Pair of high but not paired
            if r1 == 14 and r2 == 13:
                score += 0.08  # AK

            # Scale to 0.0 to 0.6 range
            score = min(0.6, score)

            # Add gap penalty for unconnected
            if gap > 1:
                score -= (gap - 1) * 0.02
            score = max(0.0, score)

        return score

    def evaluate_hand(self, cards: List[str]) -> float:
        # Simple evaluation for 5-card hand strength
        if len(cards) < 5:
            return 0.01

        rank_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

        # Extract rank and suit
        card_ranks = [c[0] for c in cards]
        card_suits = [c[1] for c in cards]
        # Convert to values
        ranks = [rank_values[r] for r in card_ranks]
        suits = card_suits

        # Count frequencies
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        sorted_ranks = sorted(ranks, reverse=True)
        values = list(set(sorted_ranks))
        values.sort(reverse=True)

        # Check flush
        flush = False
        sf_rank = -1
        for suit in set(suits):
            if suits.count(suit) >= 5:
                flush = True
                flush_cards = [card_ranks[i] for i in range(len(suits)) if suits[i] == suit]
                flush_ranks = [rank_values[r] for r in flush_cards]
                flush_ranks = list(set(flush_ranks))
                flush_ranks.sort(reverse=True)
                if len(flush_ranks) >= 5:
                    # Check for straight within flush
                    str_list = flush_ranks
                    if 14 in str_list:
                        str_list.append(1)
                    str_list = sorted(str_list)
                    for i in range(len(str_list)-1, 3, -1):
                        if str_list[i] - str_list[i-4] == 4:
                            sf_rank = str_list[i]
                            break
                    if sf_rank != -1 and sf_rank == 14:
                        return 1.0  # Royal flush
                    if sf_rank != -1:
                        return 0.95  # Straight flush
                # Just flush
                return 0.6 + (flush_ranks[0] / 1000.0)  # High card in flush

        # Check straight
        straight_rank = -1
        if 14 in ranks:
            ranks.append(1)
        unique_ranks = sorted(set(ranks), reverse=True)
        if len(unique_ranks) >= 5:
            for i in range(0, len(unique_ranks)-4):
                if unique_ranks[i]-4 == unique_ranks[i+4]:
                    straight_rank = unique_ranks[i]
                    break
        if straight_rank != -1:
            return 0.55 + (straight_rank / 1000.0)  # Straight

        # Highest hand
        if len(rank_count) == 2 and (4 in rank_count.values()):
            return 0.8  # Four of a kind
        if len(rank_count) == 2:
            return 0.75  # Full house

        if 3 in rank_count.values() and 2 in rank_count.values():
            return 0.75
        if 3 in rank_count.values():
            return 0.4  # Three of a kind
        if list(rank_count.values()).count(2) == 2:
            return 0.3  # Two pair

        if 2 in rank_count.values():
            return 0.2  # One pair

        # High card
        return 0.1 + (sorted_ranks[0] / 2000.0)

    def is_in_position(self) -> bool:
        # Simplified: if we are in later position
        current_pos = self.position
        return current_pos == "big" or current_pos == "small"