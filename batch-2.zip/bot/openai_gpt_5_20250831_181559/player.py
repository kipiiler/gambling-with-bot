from typing import List, Tuple, Dict, Any, Optional
from dataclasses import dataclass
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Simple hand/range utilities for quick, safe decision making


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12,
              'K': 13, 'A': 14}

INV_RANK_ORDER = {v: k for k, v in RANK_ORDER.items()}


def safe_div(n: float, d: float, eps: float = 1e-9) -> float:
    return n / (d + eps)


def parse_card(card: str) -> Tuple[int, str]:
    # Card format example: 'Ah', 'Td', '7s', '2c'
    if not card or len(card) < 2:
        return 0, ''
    rank_char = card[0].upper()
    suit_char = card[1].lower()
    return RANK_ORDER.get(rank_char, 0), suit_char


def card_ranks_and_suits(cards: List[str]) -> Tuple[List[int], List[str]]:
    ranks = []
    suits = []
    for c in cards:
        r, s = parse_card(c)
        if r > 0 and s:
            ranks.append(r)
            suits.append(s)
    return ranks, suits


def count_by(items: List[Any]) -> Dict[Any, int]:
    d: Dict[Any, int] = {}
    for it in items:
        d[it] = d.get(it, 0) + 1
    return d


def is_straight(ranks: List[int]) -> bool:
    # expects ranks to be from combined 7 cards, may include duplicates
    # We check for any 5-long sequence among unique ranks.
    unique = sorted(set(ranks))
    if not unique:
        return False
    # handle wheel (A-2-3-4-5): treat Ace also as 1
    if 14 in unique:
        unique.append(1)
    longest = 1
    cur = 1
    for i in range(1, len(unique)):
        if unique[i] == unique[i - 1] + 1:
            cur += 1
            longest = max(longest, cur)
        elif unique[i] != unique[i - 1]:
            cur = 1
    return longest >= 5


def straight_draw_oesd(ranks: List[int]) -> bool:
    # naive open-ended straight draw detection: look for 4-long sequences
    unique = sorted(set(ranks))
    if 14 in unique:
        unique.append(1)
    cur = 1
    best = 1
    for i in range(1, len(unique)):
        if unique[i] == unique[i - 1] + 1:
            cur += 1
            best = max(best, cur)
        elif unique[i] != unique[i - 1]:
            cur = 1
    return best == 4


def flush_info(ranks: List[int], suits: List[str]) -> Tuple[bool, bool, Optional[str]]:
    # returns (is_flush, is_draw, suit)
    suit_counts = count_by(suits)
    flush_suit = None
    is_draw = False
    is_flush = False
    for s, c in suit_counts.items():
        if c >= 5:
            is_flush = True
            flush_suit = s
            break
        if c == 4:
            is_draw = True
            flush_suit = s
    return is_flush, is_draw, flush_suit


def evaluate_hand_category(all_cards: List[str]) -> int:
    # Returns simple category ranking: 0 high card, 1 pair, 2 two pair,
    # 3 trips, 4 straight, 5 flush, 6 full house, 7 four, 8 straight flush
    ranks, suits = card_ranks_and_suits(all_cards)
    if not ranks:
        return 0
    counts = count_by(ranks)
    quads = 4 in counts.values()
    trips_count = sum(1 for v in counts.values() if v == 3)
    pairs_count = sum(1 for v in counts.values() if v == 2)

    is_flush, _, _ = flush_info(ranks, suits)
    is_str = is_straight(ranks)
    if is_flush and is_str:
        return 8
    if quads:
        return 7
    if trips_count >= 1 and (pairs_count >= 1 or trips_count >= 2):
        return 6
    if is_flush:
        return 5
    if is_str:
        return 4
    if trips_count >= 1:
        return 3
    if pairs_count >= 2:
        return 2
    if pairs_count == 1:
        return 1
    return 0


def top_board_rank(board: List[str]) -> int:
    br, _ = card_ranks_and_suits(board)
    return max(br) if br else 0


def has_top_pair_or_overpair(hole: List[str], board: List[str]) -> Tuple[bool, bool, int]:
    # Returns (is_top_pair, is_overpair, pair_rank)
    if len(hole) < 2:
        return False, False, 0
    hr, _ = card_ranks_and_suits(hole)
    br, _ = card_ranks_and_suits(board)
    if not br or not hr:
        return False, False, 0
    board_counts = count_by(br)
    my_pair_rank = 0
    # Overpair: hole pair and both board ranks are less than hole pair
    if hr[0] == hr[1]:
        pair_rank = hr[0]
        if br and max(br) < pair_rank:
            return (False, True, pair_rank)
        # also count as top pair if ties top board (rare on paired board)
        if pair_rank == max(br):
            return (True, False, pair_rank)
        return (False, False, pair_rank)
    # Top pair: one of hole ranks matches a board rank, and that rank is the top on board
    tbr = max(br)
    for r in hr:
        if r == tbr and board_counts.get(r, 0) >= 1:
            my_pair_rank = r
            return True, False, my_pair_rank
    return False, False, my_pair_rank


def has_pair_with_board(hole: List[str], board: List[str]) -> bool:
    if len(hole) < 2 or not board:
        return False
    hr, _ = card_ranks_and_suits(hole)
    br, _ = card_ranks_and_suits(board)
    brc = count_by(br)
    for r in hr:
        if brc.get(r, 0) > 0:
            return True
    return False


def flush_draw_with_hole(hole: List[str], board: List[str]) -> bool:
    # require at least one hole card in the potential flush suit
    if len(hole) < 2:
        return False
    hr, hs = card_ranks_and_suits(hole)
    br, bs = card_ranks_and_suits(board)
    all_r = hr + br
    all_s = hs + bs
    is_flush, is_draw, suit = flush_info(all_r, all_s)
    if is_flush:
        return False
    if is_draw and suit:
        return suit in hs
    return False


def oesd_with_hole(hole: List[str], board: List[str]) -> bool:
    if len(hole) < 2:
        return False
    hr, _ = card_ranks_and_suits(hole)
    br, _ = card_ranks_and_suits(board)
    if not br:
        return False
    allr = hr + br
    return straight_draw_oesd(allr)


def preflop_strength(hole: List[str]) -> float:
    # Simple linear heuristic for HU/6-max opening:
    # pairs strong, broadways, suited, connectivity
    if len(hole) < 2:
        return 0.0
    hr, hs = card_ranks_and_suits(hole)
    r1, r2 = sorted(hr, reverse=True)
    s1, s2 = hs
    pts = 0.0
    if r1 == r2:
        # pair
        pts += 35 + r1 / 2.0
    pts += (r1 + r2) / 2.0  # high card value
    # broadways
    if r1 >= 10:
        pts += 6
    if r2 >= 10:
        pts += 4
    # suited
    if s1 == s2:
        pts += 5
    # connectivity
    gap = abs(r1 - r2)
    if gap == 0:
        pts += 5
    elif gap == 1:
        pts += 4
    elif gap == 2:
        pts += 2
    # Ax/Kx boost
    if r1 == 14 or r2 == 14:
        pts += 6
    elif r1 == 13 or r2 == 13:
        pts += 3
    return pts


def clamp(val: int, lo: int, hi: int) -> int:
    if hi < lo:
        return lo
    return max(lo, min(hi, val))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.current_hole: List[str] = []
        self.rng = random.Random(1337)
        self.last_round_num = -1
        self.is_heads_up = False
        self.table_size = 0
        self.aggression_factor = 1.0  # can tune based on results
        self.default_open_mult = 2.5

    def _update_players(self, all_players: List[int]) -> None:
        self.all_players = list(all_players) if all_players else []
        self.table_size = len(self.all_players)
        self.is_heads_up = self.table_size == 2

    def _maybe_set_hole_from_start(self, player_hands: List[str]) -> None:
        # player_hands could be None or list of our two hole cards
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            # only store first two entries; ensure they look like cards
            if all(isinstance(x, str) and len(x) >= 2 for x in player_hands[:2]):
                self.current_hole = player_hands[:2]

    def _maybe_set_hole_from_round_state(self, round_state: RoundStateClient) -> None:
        # Attempt to retrieve hole cards from potential attributes not guaranteed by spec
        # to maximize compatibility
        for attr in ['player_hands', 'hole_cards', 'hand', 'cards']:
            if hasattr(round_state, attr):
                val = getattr(round_state, attr)
                if isinstance(val, list) and len(val) >= 2 and all(isinstance(x, str) for x in val[:2]):
                    self.current_hole = val[:2]
                    return
        # If not available, keep as is (may be set at on_start) else clear for new rounds
        # In new rounds, we clear hole to avoid using stale cards
        # The caller should clear before calling this if needed.

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.starting_chips = int(starting_chips)
        except Exception:
            self.starting_chips = starting_chips or 0
        try:
            self.blind_amount = int(blind_amount)
        except Exception:
            self.blind_amount = blind_amount or 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self._update_players(all_players)
        self.current_hole = []
        self._maybe_set_hole_from_start(player_hands)
        # seed RNG with bot id to be stable across runs if id is available
        try:
            if self.id is not None:
                seed_val = 1337 + int(self.id)
                self.rng.seed(seed_val)
        except Exception:
            pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # New hand: clear hole (engine likely deals new cards)
        self.current_hole = []
        self.last_round_num = getattr(round_state, 'round_num', self.last_round_num)
        # If table size might change (eliminations), update
        self._update_players(getattr(round_state, 'current_player', self.all_players))
        # Try to acquire hole cards from round_state if provided
        self._maybe_set_hole_from_round_state(round_state)
        # Update blind guess if min_raise changed drastically (some engines increase blinds)
        try:
            mr = int(getattr(round_state, 'min_raise', self.blind_amount))
            if mr and (self.blind_amount == 0 or mr > self.blind_amount):
                self.blind_amount = mr
        except Exception:
            pass

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            pb = getattr(round_state, 'player_bets', {})
            key = str(self.id) if self.id is not None else None
            if key is not None and isinstance(pb, dict):
                return int(pb.get(key, 0))
        except Exception:
            pass
        return 0

    def _get_to_call(self, round_state: RoundStateClient) -> int:
        try:
            current_bet = int(getattr(round_state, 'current_bet', 0))
            my_bet = self._get_my_bet(round_state)
            return max(0, current_bet - my_bet)
        except Exception:
            return 0

    def _min_raise_to(self, round_state: RoundStateClient) -> int:
        # Minimum total bet we must set when raising
        try:
            current_bet = int(getattr(round_state, 'current_bet', 0))
            min_raise = int(getattr(round_state, 'min_raise', 0))
            if current_bet > 0:
                return current_bet + max(1, min_raise)
            else:
                # opening bet: at least min_raise (assumed to be 1bb)
                return max(1, min_raise)
        except Exception:
            return 1

    def _max_raise_to(self, round_state: RoundStateClient, remaining_chips: int) -> int:
        try:
            return int(min(getattr(round_state, 'max_raise', remaining_chips), remaining_chips))
        except Exception:
            return int(remaining_chips)

    def _choose_bet_total(self, round_state: RoundStateClient, remaining_chips: int, pot_frac: float,
                          min_open_mult: float = None) -> Optional[int]:
        # Compute a valid raise_to total considering pot fraction and bounds
        current_bet = int(getattr(round_state, 'current_bet', 0))
        min_raise_to = self._min_raise_to(round_state)
        max_raise_to = self._max_raise_to(round_state, remaining_chips)
        pot = int(getattr(round_state, 'pot', 0))

        if max_raise_to < min_raise_to:
            return None  # cannot raise

        desired_total = min_raise_to
        if current_bet == 0:
            # opening bet sizing
            base = int(max(pot_frac * max(1, pot), 0))
            # also consider blind heuristic
            blind_guess = max(1, self.blind_amount if self.blind_amount else min_raise_to)
            target_open = int((min_open_mult if min_open_mult is not None else self.default_open_mult) * blind_guess)
            desired_total = max(min_raise_to, base, target_open)
        else:
            # raising over a bet - choose something like pot_frac * pot over current
            add_over_current = int(max(pot_frac * max(1, pot), 0))
            desired_total = max(min_raise_to, current_bet + add_over_current)

        desired_total = clamp(desired_total, min_raise_to, max_raise_to)
        return desired_total

    def _decide_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._get_to_call(round_state)
        min_raise_to = self._min_raise_to(round_state)
        max_raise_to = self._max_raise_to(round_state, remaining_chips)

        have_hole = len(self.current_hole) >= 2
        strength = preflop_strength(self.current_hole) if have_hole else 0.0

        # thresholds tuned lightly for HU/6-max
        strong_thr = 55.0
        med_thr = 45.0

        if to_call <= 0:
            # unopened pot: open-raise with good hands; otherwise mix in some steals
            if have_hole:
                if strength >= strong_thr:
                    target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.0, min_open_mult=3.0)
                    if target is not None:
                        return PokerAction.RAISE, int(target)
                    return PokerAction.CHECK, 0
                elif strength >= med_thr:
                    target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.0, min_open_mult=2.5)
                    if target is not None:
                        return PokerAction.RAISE, int(target)
                    return PokerAction.CHECK, 0
                else:
                    # weak: mostly check; occasionally steal in HU
                    if self.is_heads_up and self.rng.random() < 0.25:
                        target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.0, min_open_mult=2.2)
                        if target is not None:
                            return PokerAction.RAISE, int(target)
                    return PokerAction.CHECK, 0
            else:
                # no hole info: small steal probability when HU
                if self.is_heads_up and self.rng.random() < 0.30:
                    target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.0, min_open_mult=2.2)
                    if target is not None:
                        return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
        else:
            # facing a bet preflop
            if have_hole:
                if strength >= strong_thr:
                    # 3-bet or call based on sizing
                    # if very small to_call, 3-bet
                    if min_raise_to <= max_raise_to:
                        # 3-bet sizing ~ 3x raise
                        current_bet = int(getattr(round_state, 'current_bet', 0))
                        target = clamp(current_bet + max(1, to_call * 2), min_raise_to, max_raise_to)
                        if target > current_bet:
                            return PokerAction.RAISE, int(target)
                    # else call or all-in if short
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                elif strength >= med_thr:
                    # call small opens, fold to large raises
                    # heuristic: call if to_call <= 4bb, else fold
                    bb = self.blind_amount if self.blind_amount else max(1, int(getattr(round_state, 'min_raise', 1)))
                    if to_call <= 4 * bb and to_call < remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    # mostly fold; tiny call chance if very cheap and HU
                    bb = self.blind_amount if self.blind_amount else max(1, int(getattr(round_state, 'min_raise', 1)))
                    if self.is_heads_up and to_call <= bb and self.rng.random() < 0.1:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            else:
                # unknown hole: fold to pressure unless very cheap in HU
                bb = self.blind_amount if self.blind_amount else max(1, int(getattr(round_state, 'min_raise', 1)))
                if self.is_heads_up and to_call <= bb and self.rng.random() < 0.15 and to_call < remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

    def _postflop_decision(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Compute general indicators
        to_call = self._get_to_call(round_state)
        pot = int(getattr(round_state, 'pot', 0))
        board = list(getattr(round_state, 'community_cards', []))
        current_bet = int(getattr(round_state, 'current_bet', 0))
        min_raise_to = self._min_raise_to(round_state)
        max_raise_to = self._max_raise_to(round_state, remaining_chips)

        have_hole = len(self.current_hole) >= 2
        category = 0
        is_top_pair = False
        is_overpair = False
        pair_rank = 0
        has_draw_flush = False
        has_draw_straight = False
        has_pair_board = False

        if have_hole:
            all_cards = self.current_hole + board
            category = evaluate_hand_category(all_cards)
            is_top_pair, is_overpair, pair_rank = has_top_pair_or_overpair(self.current_hole, board)
            has_pair_board = has_pair_with_board(self.current_hole, board)
            has_draw_flush = flush_draw_with_hole(self.current_hole, board)
            has_draw_straight = oesd_with_hole(self.current_hole, board)

        # Define strength buckets
        strong = category >= 3 or is_overpair or (len(board) >= 3 and category >= 2)  # 2pair+ on flop or trips+/overpair
        medium = (category == 1 and (is_top_pair or pair_rank >= 10)) or (has_draw_flush or has_draw_straight)
        weak = not strong and not medium

        # Betting logic
        if to_call <= 0:
            # We can bet or check
            if strong:
                # value bet ~ 65-80% pot
                frac = 0.7 + 0.1 * self.aggression_factor
                target = self._choose_bet_total(round_state, remaining_chips, pot_frac=frac)
                if target is not None and target > current_bet:
                    return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
            elif medium:
                # c-bet medium/draw ~ 45-60% pot
                frac = 0.5
                target = self._choose_bet_total(round_state, remaining_chips, pot_frac=frac)
                if target is not None and target > current_bet:
                    return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
            else:
                # weak: mostly check; occasionally bluff small in HU on dry boards
                if self.is_heads_up and len(board) >= 3 and self.rng.random() < 0.15:
                    frac = 0.4
                    target = self._choose_bet_total(round_state, remaining_chips, pot_frac=frac)
                    if target is not None and target > current_bet:
                        return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
        else:
            # Facing a bet: decide call/raise/fold
            # Pot odds for calling
            call_amount = to_call
            implied_ok = False
            if have_hole and (has_draw_flush or has_draw_straight):
                # simple pot odds thresholds
                # assume 9 outs flush (~19% to hit next card), 8 outs OESD (~17%),
                # call if to_call <= 1/4 pot (rough single-card odds)
                if call_amount <= 0.28 * pot:
                    implied_ok = True

            if strong:
                # Prefer raise, else call
                # Size raise ~ 2.5x current bet add or ~ pot
                add_frac = 0.65
                target = self._choose_bet_total(round_state, remaining_chips, pot_frac=add_frac)
                if target is not None and target > current_bet and min_raise_to <= max_raise_to:
                    return PokerAction.RAISE, int(target)
                # else call/all-in
                if call_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            elif medium:
                # With draws or top pair weak kicker, mostly call provided affordable
                if implied_ok or call_amount <= max(1, int(0.3 * pot)):
                    if call_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    # occasionally semi-bluff raise if draw and shallow
                    if have_hole and (has_draw_flush or has_draw_straight) and self.rng.random() < 0.25:
                        target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.5)
                        if target is not None and target > current_bet and min_raise_to <= max_raise_to:
                            return PokerAction.RAISE, int(target)
                    return PokerAction.FOLD, 0
            else:
                # weak: mostly fold; very rarely bluff raise if tiny bet and HU
                if self.is_heads_up and call_amount <= max(1, int(0.15 * pot)) and self.rng.random() < 0.08:
                    target = self._choose_bet_total(round_state, remaining_chips, pot_frac=0.6)
                    if target is not None and target > current_bet and min_raise_to <= max_raise_to:
                        return PokerAction.RAISE, int(target)
                # If call is extremely cheap, call sometimes to realize equity
                if call_amount <= max(1, int(0.08 * pot)) and self.rng.random() < 0.1:
                    if call_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            stage = getattr(round_state, 'round', '')
            stage_upper = stage.upper() if isinstance(stage, str) else ''
            # ensure hole cards if any present in round_state
            if not self.current_hole:
                self._maybe_set_hole_from_round_state(round_state)

            if stage_upper == 'PREFLOP' or stage_upper == 'PRE-FLOP' or stage_upper == 'PRE_FLOP':
                action, amount = self._decide_preflop(round_state, remaining_chips)
            else:
                action, amount = self._postflop_decision(round_state, remaining_chips)

            # validate actions: fallback safety
            to_call = self._get_to_call(round_state)
            if action == PokerAction.CHECK and to_call > 0:
                # cannot check facing a bet
                # choose fold if weak or call if affordable small
                if to_call <= max(1, int(0.1 * int(getattr(round_state, 'pot', 0)))) and to_call < remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            if action == PokerAction.RAISE:
                # Ensure amount is a valid raise_to
                min_to = self._min_raise_to(round_state)
                max_to = self._max_raise_to(round_state, remaining_chips)
                if amount is None or amount < min_to:
                    amount = min_to
                if amount > max_to:
                    # if cannot raise, downgrade to CALL or CHECK
                    if to_call <= 0:
                        return PokerAction.CHECK, 0
                    else:
                        if to_call >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0
                # Avoid zero/negative
                if amount <= 0:
                    if to_call <= 0:
                        return PokerAction.CHECK, 0
                    else:
                        if to_call >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0

            if action == PokerAction.CALL and to_call <= 0:
                # calling nothing effectively check
                return PokerAction.CHECK, 0

            # Final safe return
            return action, int(amount or 0)
        except Exception:
            # On any error, choose the safest legal action
            try:
                to_call = self._get_to_call(round_state)
                if to_call <= 0:
                    return PokerAction.CHECK, 0
                else:
                    # Folding is always safe
                    return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand state
        self.current_hole = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could adapt aggression based on final score to auto-tune slightly over iterations
        try:
            if player_score is not None:
                if player_score < 0 and self.aggression_factor > 0.6:
                    self.aggression_factor = max(0.6, self.aggression_factor - 0.05)
                elif player_score > 0 and self.aggression_factor < 1.4:
                    self.aggression_factor = min(1.4, self.aggression_factor + 0.05)
        except Exception:
            pass