from typing import List, Tuple, Dict, Optional
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
              '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11,
              'Q': 12, 'K': 13, 'A': 14}

CATEGORY_VALUE = {
    'high_card': 1,
    'pair': 2,
    'two_pair': 3,
    'three_kind': 4,
    'straight': 5,
    'flush': 6,
    'full_house': 7,
    'four_kind': 8,
    'straight_flush': 9
}


def clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


def safe_div(a: float, b: float) -> float:
    return a / (b + 1e-9)


def card_rank(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    return RANK_ORDER.get(card[0].upper(), 0)


def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()


def parse_cards(cards: List[str]) -> List[str]:
    return [c for c in cards if isinstance(c, str) and len(c) >= 2]


def has_straight(ranks: List[int]) -> bool:
    # Ranks unique and sorted
    uniq = sorted(set(ranks))
    if 14 in uniq:
        uniq.append(1)  # Ace-low for wheel
    streak = 1
    for i in range(1, len(uniq)):
        if uniq[i] == uniq[i - 1] + 1:
            streak += 1
            if streak >= 5:
                return True
        elif uniq[i] != uniq[i - 1]:
            streak = 1
    return False


def flush_suit(cards: List[str]) -> Optional[str]:
    suits: Dict[str, int] = {}
    for c in cards:
        s = card_suit(c)
        suits[s] = suits.get(s, 0) + 1
    for s, cnt in suits.items():
        if cnt >= 5:
            return s
    return None


def has_straight_flush(cards: List[str]) -> bool:
    fs = flush_suit(cards)
    if not fs:
        return False
    suited_cards = [c for c in cards if card_suit(c) == fs]
    ranks = [card_rank(c) for c in suited_cards]
    return has_straight(ranks)


def count_ranks(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        r = card_rank(c)
        counts[r] = counts.get(r, 0) + 1
    return counts


def categorize_hand(all_cards: List[str]) -> str:
    cards = parse_cards(all_cards)
    if not cards:
        return 'high_card'
    if has_straight_flush(cards):
        return 'straight_flush'
    ranks = [card_rank(c) for c in cards]
    counts = count_ranks(cards)
    max_count = max(counts.values()) if counts else 1
    is_flush = flush_suit(cards) is not None
    is_straight = has_straight(ranks)
    pairs = len([r for r, c in counts.items() if c >= 2])
    trips = len([r for r, c in counts.items() if c == 3])

    if max_count == 4:
        return 'four_kind'
    if (trips >= 1 and pairs >= 2) or (trips >= 2):
        return 'full_house'
    if is_flush:
        return 'flush'
    if is_straight:
        return 'straight'
    if max_count == 3:
        return 'three_kind'
    if pairs >= 2:
        return 'two_pair'
    if pairs == 1:
        return 'pair'
    return 'high_card'


def estimate_postflop_strength(hole: List[str], board: List[str]) -> float:
    # Rough heuristic equity estimate from category and draws.
    hole = parse_cards(hole)
    board = parse_cards(board)
    all_cards = hole + board

    category = categorize_hand(all_cards)
    base_strength_map = {
        'high_card': 0.12,
        'pair': 0.45,
        'two_pair': 0.70,
        'three_kind': 0.82,
        'straight': 0.88,
        'flush': 0.90,
        'full_house': 0.96,
        'four_kind': 0.99,
        'straight_flush': 1.0
    }
    strength = base_strength_map.get(category, 0.15)

    # Board-only downgrade: if board on its own has same category, reduce value
    board_cat = categorize_hand(board)
    if CATEGORY_VALUE.get(board_cat, 0) >= CATEGORY_VALUE.get(category, 0):
        strength *= 0.80  # downgrade if our hole cards don't improve category

    # Draws consideration on flop/turn
    stage_len = len(board)
    if stage_len in (3, 4):  # flop or turn
        # Flush draw?
        suits = {}
        for c in all_cards:
            s = card_suit(c)
            suits[s] = suits.get(s, 0) + 1
        max_suit_cnt = 0
        for s, cnt in suits.items():
            # Count only if our hole cards contribute to that suit potential
            hole_suit_cnt = sum(1 for h in hole if card_suit(h) == s)
            if hole_suit_cnt >= 1:
                max_suit_cnt = max(max_suit_cnt, cnt)
        flush_draw = (max_suit_cnt == 4)
        # Straight draw (open-ended or gutshot): count unique ranks
        ranks = sorted(set(card_rank(c) for c in all_cards))
        if 14 in ranks:
            ranks.append(1)
        # Check windows
        open_ended = False
        gutshot = False
        # Build 5-card windows
        for i in range(len(ranks) - 3):
            window = ranks[i:i + 4]
            if window[0] + 3 == window[-1] and len(window) == 4:
                # Need one more rank to complete
                # If both ends missing are possible, it's open-ended potential
                open_ended = True
                break
        if not open_ended:
            # Gutshot heuristic: if there are 4 ranks spanning 5 with a gap inside
            for i in range(len(ranks) - 3):
                w = ranks[i:i + 4]
                if w[-1] - w[0] == 4:  # 4 ranks within 5 range
                    gutshot = True
                    break

        # Apply draw boosts if not made hands
        if CATEGORY_VALUE.get(category, 0) <= CATEGORY_VALUE['pair']:
            if flush_draw and open_ended:
                strength = max(strength, 0.52 if stage_len == 3 else 0.40)
            elif flush_draw:
                strength = max(strength, 0.40 if stage_len == 3 else 0.28)
            elif open_ended:
                strength = max(strength, 0.36 if stage_len == 3 else 0.22)
            elif gutshot:
                strength = max(strength, 0.24 if stage_len == 3 else 0.16)

    # Cap into [0,1]
    strength = max(0.0, min(1.0, strength))
    return strength


def approx_preflop_strength(hole: List[str]) -> float:
    # Approximate preflop strength (0..1) using simple heuristics
    if not hole or len(hole) < 2:
        return 0.0
    c1, c2 = hole[0], hole[1]
    r1, r2 = card_rank(c1), card_rank(c2)
    s1, s2 = card_suit(c1), card_suit(c2)
    high, low = max(r1, r2), min(r1, r2)
    suited = (s1 == s2)
    gap = abs(r1 - r2) - 1  # 0 for connectors, 1 for 1-gap, etc.
    is_pair = (r1 == r2)

    if is_pair:
        # 22..AA -> 0.55 .. 1.0
        base = 0.55 + (high - 2) / 12.0 * 0.45
        return max(0.0, min(1.0, base))

    # Non-pair base from high card rank
    base = max(0.0, (high - 6) / 8.0) * 0.40  # up to 0.40
    # Ace-high bonus
    if high == 14:
        base += 0.10
    # Suited bonus
    if suited:
        base += 0.06
    # Connectivity bonus
    if gap <= 0:
        base += 0.12
    elif gap == 1:
        base += 0.08
    elif gap == 2:
        base += 0.04
    # Low-card penalty if both below 9
    if high < 9:
        base -= 0.06
    return max(0.0, min(1.0, base))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # Assume big blind if provided
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.current_hand: List[str] = []  # our hole cards if provided
        self.rng = random.Random(1337)
        self.last_round_num: int = -1
        self.hands_seen: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = int(blind_amount) if isinstance(blind_amount, int) else 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players else []
        # Some environments provide our initial hole cards here; store if exactly 2 are given.
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.current_hand = player_hands[:2]
        else:
            self.current_hand = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # In some environments, hole cards are updated via this callback (not provided here).
        # Reset if this is a new hand.
        if round_state and isinstance(round_state.round_num, int):
            if round_state.round_num != self.last_round_num:
                self.hands_seen += 1
                self.last_round_num = round_state.round_num
                # If the engine provides new hole cards through some other mechanism, this is where we'd update.
                # Otherwise, keep existing if provided at on_start; else empty.
                if not self.current_hand or len(self.current_hand) < 2:
                    self.current_hand = []

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _amount_to_call(self, round_state: RoundStateClient) -> int:
        try:
            return max(0, int(round_state.current_bet) - self._get_my_bet(round_state))
        except Exception:
            return 0

    def _can_check(self, round_state: RoundStateClient) -> bool:
        # Conservative rule: allow check only when current_bet == 0 and we owe nothing
        try:
            return (round_state.current_bet == 0) and (self._amount_to_call(round_state) == 0)
        except Exception:
            return False

    def _choose_raise_amount(self, round_state: RoundStateClient, factor: float = 1.0) -> Optional[int]:
        try:
            min_r = int(round_state.min_raise)
            max_r = int(round_state.max_raise)
        except Exception:
            return None
        if max_r <= 0:
            return None
        if min_r <= 0 or min_r > max_r:
            # Try to synthesize a minimal positive raise if possible
            min_r = 1
        target = int(max(min_r, min(max_r, math.floor(min_r * max(1.0, factor)))))
        target = clamp(target, min_r, max_r)
        if target <= 0:
            return None
        return target

    def _preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pot = int(getattr(round_state, 'pot', 0) or 0)
        atc = self._amount_to_call(round_state)
        can_check = self._can_check(round_state)

        have_cards = self.current_hand and len(self.current_hand) >= 2
        strength = approx_preflop_strength(self.current_hand) if have_cards else None

        # If we don't know our cards: play ultra-tight, avoid losses, occasional small steal when checked to us
        if not have_cards:
            if can_check:
                # Low frequency stab to avoid being too passive
                attempt_steal = (self.rng.random() < 0.10)
                if attempt_steal:
                    amt = self._choose_raise_amount(round_state, factor=1.0)
                    if amt is not None:
                        return (PokerAction.RAISE, int(amt))
                return (PokerAction.CHECK, 0)
            else:
                # Facing a bet without info -> fold unless it's trivially small compared to pot
                # If call is <= 10% of pot, we can peel
                if pot > 0 and safe_div(atc, pot) <= 0.10:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        # With known hole cards:
        # Thresholds
        premium = strength >= 0.85
        strong = strength >= 0.72
        playable = strength >= 0.58

        # If we can check (no raise yet), consider opening
        if can_check:
            if premium:
                amt = self._choose_raise_amount(round_state, factor=2.5)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
                return (PokerAction.CHECK, 0)
            if strong:
                amt = self._choose_raise_amount(round_state, factor=1.8)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
                return (PokerAction.CHECK, 0)
            if playable and self.rng.random() < 0.4:
                amt = self._choose_raise_amount(round_state, factor=1.0)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
            return (PokerAction.CHECK, 0)
        else:
            # Facing a raise
            # Compute simple pot odds
            call_cost = atc
            pot_odds = safe_div(call_cost, (pot + call_cost))
            # Conservative multiplier to account for reverse implied odds preflop
            required_equity = min(0.85, pot_odds * 1.2)

            if premium:
                # 3-bet or all-in if shallow
                if remaining_chips <= max(10 * max(1, self.blind_amount), pot * 2):
                    return (PokerAction.ALL_IN, 0)
                amt = self._choose_raise_amount(round_state, factor=2.2)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
                return (PokerAction.CALL, 0)

            if strong:
                # Mix between call and small 3-bet
                if self.rng.random() < 0.4:
                    amt = self._choose_raise_amount(round_state, factor=1.4)
                    if amt is not None:
                        return (PokerAction.RAISE, int(amt))
                # Otherwise call if price is right
                if strength >= required_equity:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

            if playable:
                # Call if cheap enough
                if strength >= required_equity and call_cost <= max(3 * max(1, self.blind_amount), pot // 4 + 1):
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

            # Weak hand -> fold unless very cheap
            if pot > 0 and safe_div(call_cost, (pot + call_cost)) <= 0.10 and call_cost <= max(1, self.blind_amount):
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def _postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        board = parse_cards(round_state.community_cards or [])
        atc = self._amount_to_call(round_state)
        can_check = self._can_check(round_state)
        pot = int(getattr(round_state, 'pot', 0) or 0)

        have_cards = self.current_hand and len(self.current_hand) >= 2
        if not have_cards:
            # Without hole info, be cautious: check when possible, fold to significant bets
            if can_check:
                # Token stab very occasionally
                if self.rng.random() < 0.08:
                    amt = self._choose_raise_amount(round_state, factor=1.0)
                    if amt is not None:
                        return (PokerAction.RAISE, int(amt))
                return (PokerAction.CHECK, 0)
            else:
                # If bet is tiny relative to pot, peel once
                if pot > 0 and safe_div(atc, (pot + atc)) <= 0.12:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        strength = estimate_postflop_strength(self.current_hand, board)
        call_cost = atc
        pot_odds = safe_div(call_cost, (pot + call_cost))

        # Aggression thresholds
        very_strong = strength >= 0.85          # straight+ or strong sets
        strong = strength >= 0.70               # two-pair+, good made hands
        marginal = strength >= 0.45             # pairs/draws
        bluff_ok = strength >= 0.30             # decent draws

        # If we can check
        if can_check:
            # Value bet with strong hands
            if very_strong or strong:
                # Prefer larger raise if allowed
                factor = 2.0 if very_strong else 1.4
                amt = self._choose_raise_amount(round_state, factor=factor)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
                return (PokerAction.CHECK, 0)
            # Semi-bluff with some draws on flop/turn
            if bluff_ok and len(board) in (3, 4) and self.rng.random() < 0.35:
                amt = self._choose_raise_amount(round_state, factor=1.0)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
            return (PokerAction.CHECK, 0)
        else:
            # Facing a bet: compare strength vs pot odds with small buffer
            if very_strong:
                # Raise or all-in if shallow SPR
                if remaining_chips <= max(12 * max(1, self.blind_amount), pot * 2):
                    return (PokerAction.ALL_IN, 0)
                amt = self._choose_raise_amount(round_state, factor=2.0)
                if amt is not None:
                    return (PokerAction.RAISE, int(amt))
                return (PokerAction.CALL, 0)

            required_equity = min(0.95, pot_odds * 1.05)
            if strength >= max(0.50, required_equity):
                # Call with adequate equity; occasionally raise with strong hands
                if strong and self.rng.random() < 0.35:
                    amt = self._choose_raise_amount(round_state, factor=1.5)
                    if amt is not None:
                        return (PokerAction.RAISE, int(amt))
                return (PokerAction.CALL, 0)

            # Folding threshold: keep losses small
            return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Normalize stage string
            stage = (round_state.round or '').lower() if round_state and round_state.round else ''
            if stage in ('preflop', 'pre-flop', 'pre_flop', 'pref'):
                return self._preflop_action(round_state, remaining_chips)
            else:
                return self._postflop_action(round_state, remaining_chips)
        except Exception:
            # Failsafe: avoid invalid actions
            # If we can check, do so; otherwise fold
            try:
                if self._can_check(round_state):
                    return (PokerAction.CHECK, 0)
            except Exception:
                pass
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Between rounds, clear current hand unless environment persists it
        self.current_hand = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent storage; could log or adjust RNG seed lightly for variation
        try:
            # Adjust RNG seed to add variability across games while remaining deterministic per game id if available
            seed_component = 0
            if hasattr(round_state, 'round_num'):
                seed_component = int(round_state.round_num)
            self.rng.seed(1337 + seed_component + int(player_score or 0))
        except Exception:
            pass