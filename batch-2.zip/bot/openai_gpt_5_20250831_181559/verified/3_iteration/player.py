from typing import List, Tuple, Dict, Any, Optional
import random
import itertools

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _card_value(card: str) -> int:
    # Accept formats like 'Td', '10d', 'As'
    if not card:
        return 0
    r = card[:-1]  # rank string
    if r == 'T' or r == '10':
        return 10
    if r == 'J':
        return 11
    if r == 'Q':
        return 12
    if r == 'K':
        return 13
    if r == 'A':
        return 14
    try:
        return int(r)
    except Exception:
        return 0


def _card_suit(card: str) -> str:
    return card[-1] if card else ''


def _rank_counts(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        v = _card_value(c)
        counts[v] = counts.get(v, 0) + 1
    return counts


def _suit_counts(cards: List[str]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for c in cards:
        s = _card_suit(c)
        counts[s] = counts.get(s, 0) + 1
    return counts


def _is_straight(ranks: List[int]) -> Optional[int]:
    """
    Return the high card of the straight if present, else None.
    Ranks list is 5 ranks (with duplicates already filtered before calling).
    """
    rset = set(ranks)
    # Handle 5-card input: we'll compute logic using full set to detect sequences
    uniq = sorted(set(ranks))
    # Add Ace as 1 for wheel detection
    uniq_ace_low = sorted(set([1 if x == 14 else x for x in uniq] + uniq))
    # Scan for 5 consecutive numbers
    for seq in [uniq, uniq_ace_low]:
        if len(seq) < 5:
            continue
        for i in range(len(seq) - 4):
            if seq[i] + 4 == seq[i + 4] and all(seq[i] + k in seq for k in range(5)):
                # Return the high card of this straight (with Ace-high if applicable)
                high = seq[i + 4]
                if high == 14 and seq[i] == 10:
                    return 14
                # convert ace-low high to 5 for wheel if needed
                return 5 if high == 5 and seq[i] == 1 else high
    return None


def _straight_high_from_five(cards5: List[str]) -> Optional[int]:
    ranks = [_card_value(c) for c in cards5]
    return _is_straight(ranks)


def _hand_rank_5(cards5: List[str]) -> Tuple[int, Tuple[int, ...]]:
    """
    Returns a comparable rank tuple for 5-card hand.
    Category: 8 straight flush, 7 four of a kind, 6 full house, 5 flush,
              4 straight, 3 three of a kind, 2 two pair, 1 pair, 0 high card.
    Tiebreakers are ranks sorted as needed.
    """
    ranks = sorted([_card_value(c) for c in cards5], reverse=True)
    suits = [_card_suit(c) for c in cards5]
    rank_counts = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    # Sort by count desc, then rank desc
    count_rank_sorted = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
    counts = [cr[1] for cr in count_rank_sorted]
    ordered_ranks = [cr[0] for cr in count_rank_sorted]

    is_flush = len(set(suits)) == 1
    straight_high = _straight_high_from_five(cards5)
    is_straight = straight_high is not None

    if is_flush and is_straight:
        return (8, (straight_high,))
    if counts[0] == 4:
        # four of a kind: rank of quads, then kicker
        quad_rank = ordered_ranks[0]
        kicker = ordered_ranks[1]
        return (7, (quad_rank, kicker))
    if counts[0] == 3 and counts[1] == 2:
        # full house: trips rank, then pair rank
        return (6, (ordered_ranks[0], ordered_ranks[1]))
    if is_flush:
        # flush: ranks high to low
        return (5, tuple(sorted(ranks, reverse=True)))
    if is_straight:
        return (4, (straight_high,))
    if counts[0] == 3:
        # trips: trip rank, then kickers high to low
        trip = ordered_ranks[0]
        kickers = sorted([r for r in ranks if r != trip], reverse=True)
        return (3, (trip,) + tuple(kickers))
    if counts[0] == 2 and counts[1] == 2:
        # two pairs: higher pair, lower pair, kicker
        high_pair, low_pair = sorted([ordered_ranks[0], ordered_ranks[1]], reverse=True)
        kicker = ordered_ranks[2]
        return (2, (high_pair, low_pair, kicker))
    if counts[0] == 2:
        pair = ordered_ranks[0]
        kickers = sorted([r for r in ranks if r != pair], reverse=True)[:3]
        return (1, (pair,) + tuple(kickers))
    # high card
    return (0, tuple(sorted(ranks, reverse=True)))


def _best_hand_rank(cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
    """
    Given up to 7 cards, evaluate the best 5-card hand rank.
    """
    best: Optional[Tuple[int, Tuple[int, ...]]] = None
    for combo in itertools.combinations(cards, 5):
        r = _hand_rank_5(list(combo))
        if (best is None) or (r > best):
            best = r
    # Should never be None if at least 5 cards, handle fewer defensively
    return best if best is not None else (0, (0,))


def _has_flush_draw(cards: List[str]) -> bool:
    counts = _suit_counts(cards)
    return any(cnt >= 4 for cnt in counts.values())


def _straight_draw_info(cards: List[str]) -> Dict[str, bool]:
    ranks = sorted(set(_card_value(c) for c in cards))
    # Include Ace as 1
    ranks_with_ace_low = sorted(set(ranks + [1 if r == 14 else r for r in ranks]))
    set_all = set(ranks_with_ace_low)

    open_ended = False
    gutshot = False

    for start in range(1, 11):
        window = {start + k for k in range(5)}  # 5-long window
        present = len(set_all & window)
        if present == 4:
            # Determine if the 4 present form four consecutive ranks (open-ended)
            # Check for any run of 4 consecutive within the window
            for inner_start in range(start, start + 2):
                run = {inner_start + k for k in range(4)}
                if run.issubset(set_all):
                    open_ended = True
                    break
            if not open_ended:
                gutshot = True
    return {"open_ended": open_ended, "gutshot": gutshot}


def _safe_int(x: Any, default: int = 0) -> int:
    try:
        return int(x)
    except Exception:
        return default


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Configurable parameters
        self.blind_amount: int = 10  # assumed big blind default if not provided
        self.starting_chips: int = 10000
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.num_players: int = 2

        # State tracking
        self.current_hand: List[str] = []  # our hole cards
        self.round_index: int = 0
        self.rng = random.Random(42)  # deterministic base; can reseed with id later
        self.last_round_num: int = -1

        # Performance tracking (optional lightweight)
        self.total_hands_seen: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.starting_chips = _safe_int(starting_chips, 10000)
        except Exception:
            self.starting_chips = 10000

        try:
            self.blind_amount = _safe_int(blind_amount, self.blind_amount)
        except Exception:
            pass

        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players is not None else []
        self.num_players = max(2, len(self.all_players)) if self.all_players else 2

        # Try to set RNG seed more uniquely if we know our id
        if self.id is not None:
            self.rng.seed(self.id)
        else:
            # Fallback: derive some seed
            self.rng.seed((self.starting_chips << 8) ^ self.blind_amount)

        # Try to parse hole cards if they are provided here
        self.current_hand = []
        if isinstance(player_hands, list):
            # Expect two strings like ['As', 'Kd']
            if len(player_hands) >= 2 and isinstance(player_hands[0], str) and isinstance(player_hands[1], str):
                self.current_hand = player_hands[:2]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Attempt to update hole cards from round_state if available in non-documented fields
        self._maybe_update_hole_cards(round_state)
        if round_state.round_num != self.last_round_num:
            self.total_hands_seen += 1
            self.last_round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive guards
        try:
            my_bet = _safe_int(round_state.player_bets.get(str(self.id), 0), 0) if round_state and round_state.player_bets else 0
            current_bet = _safe_int(round_state.current_bet, 0)
            pot = _safe_int(round_state.pot, 0)
            min_raise = _safe_int(round_state.min_raise, 0)
            max_raise = _safe_int(round_state.max_raise, 0)
            community = list(round_state.community_cards) if round_state and round_state.community_cards else []
            round_name = (round_state.round or "").lower() if round_state and round_state.round else "preflop"
        except Exception:
            # If anything goes wrong with state, fold to be safe
            return (PokerAction.FOLD, 0)

        # House-keeping: update hole cards if the engine sneaks them in somewhere
        self._maybe_update_hole_cards(round_state)

        call_amount = max(0, current_bet - my_bet)
        can_check = (call_amount == 0)
        can_call = (call_amount > 0 and remaining_chips >= call_amount)
        can_raise = (min_raise > 0 and max_raise >= min_raise and remaining_chips > 0)
        # Ensure raise_to affordability check will be done before returning a raise
        # Fallback raise_to is min_raise (assumed valid)
        def safe_raise_to(target: int) -> Optional[int]:
            target = int(max(min_raise, min(target, max_raise)))
            invest_needed = target - my_bet
            if invest_needed <= 0:
                return None
            if invest_needed > remaining_chips:
                return None
            return target

        # Helper: choose minimal valid raise
        def choose_min_raise() -> Optional[int]:
            return safe_raise_to(min_raise)

        # Preflop strategy (use hole cards if we have them)
        if round_name == "preflop":
            if self.current_hand and len(self.current_hand) >= 2:
                preflop_score = self._preflop_strength(self.current_hand)
                # default thresholds adjusted for heads-up vs multi-way
                hu = (self.num_players <= 3)
                open_threshold = 0.45 if hu else 0.55
                call_threshold = 0.42 if hu else 0.5
                three_bet_threshold = 0.8

                if can_check:
                    # Open the pot
                    if preflop_score >= open_threshold and can_raise:
                        # prefer minimal raise to stay valid and safe
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                    # Otherwise take a free check
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing bet
                    # If the ask is tiny (<= 2x BB), loosen calls
                    bb = max(1, self.blind_amount)
                    if preflop_score >= three_bet_threshold and can_raise:
                        rto = choose_min_raise()
                        # If very strong and short stack, consider all-in
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                        elif remaining_chips <= 10 * bb:
                            return (PokerAction.ALL_IN, 0)
                    if call_amount <= 2 * bb and preflop_score >= (call_threshold - 0.05):
                        if can_call:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.ALL_IN, 0)
                    if preflop_score >= call_threshold:
                        if can_call:
                            return (PokerAction.CALL, 0)
                    # Otherwise fold
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
            else:
                # If we don't know our hole cards, adopt a conservative but not overly passive strategy
                bb = max(1, self.blind_amount)
                if can_check:
                    # Occasionally attempt to steal with a min-raise heads-up
                    steal_prob = 0.25 if self.num_players <= 3 else 0.12
                    if can_raise and self.rng.random() < steal_prob:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet: call tiny bets occasionally; otherwise fold
                    if call_amount <= bb and self.rng.random() < 0.25 and can_call:
                        return (PokerAction.CALL, 0)
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)

        # Postflop strategy
        # If we know our hole cards, evaluate made hand strength and draws
        if self.current_hand and len(self.current_hand) >= 2 and len(community) >= 3:
            all_cards = self.current_hand + community
            category, tiebreak = _best_hand_rank(all_cards)
            made_strength = self._map_category_to_strength(category, tiebreak)
            # Draws
            fd = _has_flush_draw(all_cards)
            sd_info = _straight_draw_info(all_cards)
            open_ended = sd_info["open_ended"]
            gutshot = sd_info["gutshot"]

            # Aggression controls
            strong_made = made_strength >= 0.70  # two pair+ typically or very good one-pair with strong kicker
            decent_made = made_strength >= 0.55  # one pair top pair+ often
            draw_good = fd or open_ended
            draw_ok = gutshot

            # If we can check (no bet), decide whether to bet
            if can_check:
                # Value bet strong hands
                if strong_made or (decent_made and self.rng.random() < 0.6):
                    if can_raise:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                    return (PokerAction.CHECK, 0)
                # Semi-bluff draws sometimes
                if (draw_good and self.rng.random() < 0.6) or (draw_ok and self.rng.random() < 0.3):
                    if can_raise:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                # Otherwise take the free card
                return (PokerAction.CHECK, 0)
            else:
                # Facing a bet: consider pot odds
                eps = 1e-9
                pot_odds = call_amount / max(pot + call_amount, eps)

                if strong_made:
                    # Raise or call depending on stack and availability
                    if can_raise and self.rng.random() < 0.6:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                    # Otherwise call to control pot
                    if can_call:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)

                if decent_made:
                    # Call reasonable bets; fold to huge overbets sometimes
                    if pot_odds <= 0.5 and can_call:
                        return (PokerAction.CALL, 0)
                    elif can_raise and pot_odds <= 0.35:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                        if can_call:
                            return (PokerAction.CALL, 0)
                    # Otherwise fold/check
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)

                if draw_good:
                    # Call with decent pot odds
                    # Rough target equity ~ 0.32 for FD+SD, 0.18-0.24 for OESD/FD alone
                    target = 0.28 if fd and open_ended else 0.22
                    if pot_odds <= target and can_call:
                        return (PokerAction.CALL, 0)
                    # Semi-bluff sometimes
                    if can_raise and self.rng.random() < 0.35:
                        rto = choose_min_raise()
                        if rto is not None:
                            return (PokerAction.RAISE, rto)
                    # Otherwise fold/check
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)

                if draw_ok:
                    # Gutshot: need better pot odds
                    if pot_odds <= 0.15 and can_call:
                        return (PokerAction.CALL, 0)
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)

                # Weak hand: fold to aggression; take free check if allowed
                if can_check:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # If we don't know our hole cards postflop, keep it simple and conservative
        if can_check:
            return (PokerAction.CHECK, 0)
        else:
            # Call tiny bets seldom to avoid being too tight
            bb = max(1, self.blind_amount)
            if call_amount <= bb and self.rng.random() < 0.2 and remaining_chips >= call_amount:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset current hand for the next round; many servers will provide new hole cards next round
        self.current_hand = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent state needed between games for now
        pass

    # ----------------- Helper methods -----------------
    def _maybe_update_hole_cards(self, round_state: RoundStateClient) -> None:
        # Try several potential attributes without raising exceptions
        try:
            # Some engines might attach 'hole_cards' directly
            hc = getattr(round_state, "hole_cards", None)
            if isinstance(hc, list) and len(hc) >= 2 and isinstance(hc[0], str):
                self.current_hand = hc[:2]
                return
        except Exception:
            pass
        try:
            # Or store per-player mapping
            ph = getattr(round_state, "player_hands", None)
            if isinstance(ph, dict) and self.id is not None:
                me_key = str(self.id)
                if me_key in ph and isinstance(ph[me_key], list) and len(ph[me_key]) >= 2:
                    self.current_hand = ph[me_key][:2]
                    return
        except Exception:
            pass
        try:
            # Or a generic 'hand' field
            hand = getattr(round_state, "hand", None)
            if isinstance(hand, list) and len(hand) >= 2 and isinstance(hand[0], str):
                self.current_hand = hand[:2]
                return
        except Exception:
            pass
        # If no info found, leave as-is

    def _preflop_strength(self, hole_cards: List[str]) -> float:
        """
        Produce a rough preflop strength score in [0,1] using simple heuristics.
        """
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
        r1, r2 = _card_value(hole_cards[0]), _card_value(hole_cards[1])
        s1, s2 = _card_suit(hole_cards[0]), _card_suit(hole_cards[1])
        hi = max(r1, r2)
        lo = min(r1, r2)
        pair = (r1 == r2)
        suited = (s1 == s2)
        gap = abs(r1 - r2) - 1  # 0 for connectors, 1 for one-gap, etc.

        score = 0.0
        if pair:
            # Scale from 66% at 22 up to 100% at AA
            score = 0.66 + (hi - 2) / (14 - 2) * 0.34
        else:
            # Base on high card
            score = hi / 14.0 * 0.6 + lo / 14.0 * 0.2
            if suited:
                score += 0.08
            if gap <= 0:
                score += 0.06
            elif gap == 1:
                score += 0.03
            elif gap == 2:
                score += 0.015
            # Bonus if both are broadways (T or higher)
            if hi >= 10 and lo >= 10:
                score += 0.08
            # Penalty for very low rag combos
            if hi <= 7 and lo <= 5 and not suited:
                score -= 0.08

        # Slightly adjust for position guess: if we're likely in position (not big blind), small bump
        if self.big_blind_player_id is not None and self.id is not None and self.id != self.big_blind_player_id:
            score += 0.02

        return max(0.0, min(1.0, score))

    def _map_category_to_strength(self, category: int, tiebreak: Tuple[int, ...]) -> float:
        """
        Convert category and some kickers into a rough [0,1] strength.
        """
        base = {
            8: 1.00,  # straight flush
            7: 0.98,  # four of a kind
            6: 0.94,  # full house
            5: 0.86,  # flush
            4: 0.82,  # straight
            3: 0.72,  # three of a kind
            2: 0.60,  # two pair
            1: 0.48,  # one pair
            0: 0.22,  # high card
        }.get(category, 0.2)
        # Small tweak based on top kicker in tiebreak when applicable
        if tiebreak and len(tiebreak) > 0:
            top = tiebreak[0]
            base += (top - 7) / 30.0  # -0.2 to +0.23 roughly
        return max(0.0, min(1.0, base))