from typing import List, Tuple, Dict, Any
import itertools
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_STR = "23456789TJQKA"
RANK_TO_INT = {r: i + 2 for i, r in enumerate(RANK_STR)}
INT_TO_RANK = {v: k for k, v in RANK_TO_INT.items()}
SUITS = ['h', 'd', 'c', 's']


def safe_div(n: float, d: float) -> float:
    return n / (d if abs(d) > 1e-9 else 1e-9)


def parse_card(card: str) -> Tuple[int, str]:
    """Converts a card string like 'Ah' to (14, 'h')"""
    if not card or len(card) < 2:
        return 0, 'x'
    rank_char = card[0].upper()
    suit_char = card[1].lower()
    return RANK_TO_INT.get(rank_char, 0), suit_char


def ranks_and_suits(cards: List[str]) -> Tuple[List[int], List[str]]:
    rs = []
    ss = []
    for c in cards:
        r, s = parse_card(c)
        if r > 0:
            rs.append(r)
            ss.append(s)
    return rs, ss


def is_straight(ranks: List[int]) -> Tuple[bool, int]:
    """Return (is_straight, high_card). Considers A as both high and low for wheel."""
    rset = set(ranks)
    # Add wheel straight possibility by treating Ace as 1
    if 14 in rset:
        rset.add(1)
    uniq = sorted(rset)
    if len(uniq) < 5:
        return False, 0
    # Slide window of 5
    for i in range(len(uniq) - 4):
        window = uniq[i:i + 5]
        if window[0] + 4 == window[-1] and len(window) == 5:
            return True, window[-1] if window[-1] != 5 else 5  # high card of straight (wheel high is 5)
    return False, 0


def evaluate_5(cards5: List[str]) -> Tuple:
    """Evaluate a 5-card hand. Returns a tuple that compares correctly by strength."""
    ranks, suits = ranks_and_suits(cards5)
    ranks_sorted = sorted(ranks, reverse=True)
    # Count ranks
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts = sorted(((cnt, r) for r, cnt in rank_counts.items()), reverse=True)  # sort by count desc then rank desc

    # Check flush
    suit_counts: Dict[str, int] = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    flush = None
    for s, cnt in suit_counts.items():
        if cnt == 5:
            flush = s
            break

    # Check straight
    straight, straight_high = is_straight(ranks)

    # Straight flush
    if flush:
        flush_ranks = [r for r, s in (parse_card(c) for c in cards5) if s == flush]
        sf, sf_high = is_straight(flush_ranks)
        if sf:
            return 8, sf_high  # Straight flush

    # Four of a kind
    if counts[0][0] == 4:
        four_rank = counts[0][1]
        kicker = max(r for r in ranks if r != four_rank)
        return 7, four_rank, kicker

    # Full house
    if counts[0][0] == 3 and counts[1][0] == 2:
        return 6, counts[0][1], counts[1][1]

    # Flush
    if flush:
        flush_ranks_sorted = sorted([r for r, s in (parse_card(c) for c in cards5) if s == flush], reverse=True)
        return 5, tuple(flush_ranks_sorted)

    # Straight
    if straight:
        return 4, straight_high

    # Three of a kind
    if counts[0][0] == 3:
        trips_rank = counts[0][1]
        kickers = sorted([r for r in ranks if r != trips_rank], reverse=True)
        return 3, trips_rank, tuple(kickers[:2])

    # Two pair
    if counts[0][0] == 2 and counts[1][0] == 2:
        high_pair = max(counts[0][1], counts[1][1])
        low_pair = min(counts[0][1], counts[1][1])
        kicker = max(r for r in ranks if r != high_pair and r != low_pair)
        return 2, high_pair, low_pair, kicker

    # One pair
    if counts[0][0] == 2:
        pair_rank = counts[0][1]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
        return 1, pair_rank, tuple(kickers[:3])

    # High card
    return 0, tuple(ranks_sorted)


def best_hand_eval(all_cards: List[str]) -> Tuple[Tuple, List[str]]:
    """Return (hand_strength_tuple, cards_used_for_best_hand)"""
    best = None
    best_cards = None
    for combo in itertools.combinations(all_cards, 5):
        val = evaluate_5(list(combo))
        if best is None or val > best:
            best = val
            best_cards = list(combo)
    if best is None:
        return (0, ()), []
    return best, best_cards


def hand_category_score(hand_tuple: Tuple) -> float:
    """Map hand class to a numeric score between 0 and 1."""
    category = hand_tuple[0]  # 0..8
    # Normalize: 0 -> 0.05, 8 -> 1.0
    base = (category + 1) / 9.0
    return min(1.0, max(0.0, base))


def has_flush_draw(hole: List[str], board: List[str]) -> bool:
    """True if we have a 4-flush draw that includes at least one of our hole cards' suit."""
    if len(board) < 3:
        return False
    all_cards = hole + board
    _, suits = ranks_and_suits(all_cards)
    suit_counts: Dict[str, int] = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    # Must include at least one hole card in that suit
    for s, cnt in suit_counts.items():
        if cnt >= 4 and any(parse_card(c)[1] == s for c in hole):
            return True
    return False


def has_open_ended_straight_draw(hole: List[str], board: List[str]) -> bool:
    """Rough OESD detection using combined ranks, requiring at least one hole card involved."""
    if len(board) < 3:
        return False
    ranks_all, _ = ranks_and_suits(hole + board)
    ranks_all = sorted(set(ranks_all))
    if 14 in ranks_all:
        ranks_all.append(1)
    hranks, _ = ranks_and_suits(hole)
    hrank_set = set(hranks)
    for i in range(len(ranks_all) - 3):
        window = ranks_all[i:i + 4]  # need 4 in sequence with ends open
        # Check window covers 4 sequential ranks
        if len(window) == 4 and window[0] + 3 == window[-1]:
            # At least one hole rank in window
            if any(r in hrank_set or (r == 1 and 14 in hrank_set) for r in window):
                return True
    return False


def has_gutshot_draw(hole: List[str], board: List[str]) -> bool:
    """Rough gutshot detection: 4 ranks within 5-length window with one gap; includes a hole rank."""
    if len(board) < 3:
        return False
    rset = set(ranks_and_suits(hole + board)[0])
    if 14 in rset:
        rset.add(1)
    uniq = sorted(rset)
    hranks = set(ranks_and_suits(hole)[0])
    if 14 in hranks:
        hranks.add(1)
    if len(uniq) < 4:
        return False
    for start in range(2, 15 - 4 + 1):  # start rank for 5-long window (A as 14)
        window = set(range(start, start + 5))
        present = window & set(uniq)
        if len(present) == 4 and len(window - present) == 1:
            # Check hole involvement
            if len(present & hranks) > 0:
                return True
    return False


def preflop_strength(hole: List[str]) -> float:
    """Simple preflop strength heuristic 0..1 using pair strength, suitedness, connectivity, high cards."""
    if len(hole) != 2:
        return 0.0
    r1, s1 = parse_card(hole[0])
    r2, s2 = parse_card(hole[1])
    high = max(r1, r2)
    low = min(r1, r2)
    suited = 1 if s1 == s2 else 0
    gap = abs(r1 - r2) - 1
    pair = 1 if r1 == r2 else 0

    # Base by pair or high cards
    score = 0.0
    if pair:
        # Pair strength by rank
        score = 0.5 + (high - 2) / (14 - 2) * 0.5  # 22 -> 0.5, AA -> 1.0
    else:
        # High card component
        score = (high - 6) / (14 - 6) * 0.45  # 7x -> ~0, Ax -> ~0.45
        # Kicker helps
        score += (low - 2) / (14 - 2) * 0.15  # add up to 0.15
        # Suited bonus
        score += 0.08 * suited
        # Connectivity bonus (no gap best)
        if gap <= 0:
            score += 0.12
        elif gap == 1:
            score += 0.07
        elif gap == 2:
            score += 0.03

    # Clamp
    return max(0.0, min(1.0, score))


def is_top_pair_or_overpair(hole: List[str], board: List[str]) -> Tuple[bool, bool]:
    """Return (is_top_pair, is_overpair) on flop+."""
    if len(board) < 3:
        return False, False
    branks, _ = ranks_and_suits(board)
    if not branks:
        return False, False
    max_board = max(branks)
    hranks, _ = ranks_and_suits(hole)
    if len(hranks) < 2:
        return False, False
    # Overpair: pocket pair higher than any board card
    if hranks[0] == hranks[1] and hranks[0] > max_board:
        return False, True
    # Top pair: have a card matching highest board rank
    is_top = max_board in hranks
    return is_top, False


def get_round_name(rs: RoundStateClient) -> str:
    r = rs.round
    if not r:
        return "Preflop"
    return r


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.round_num = 0
        self.random = random.Random()
        self.last_action_info: Dict[str, Any] = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the beginning of a hand (as per environment usage). Store current hole cards and table info.
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount if blind_amount is not None else 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players or []
        self.hole_cards = player_hands or []
        # Seed random with combination of id and round to vary behavior slightly yet be deterministic per hand
        seed_base = (self.id or 0) ^ (self.round_num or 0) ^ (sum(RANK_TO_INT.get(c[0].upper(), 0) for c in self.hole_cards) if self.hole_cards else 0)
        self.random.seed(seed_base)
        self.last_action_info.clear()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update internal round counter and any state needed
        self.round_num = round_state.round_num

    def _get_our_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            # Be safe in case of unexpected formats
            try:
                return int(round_state.player_bets.get(self.id, 0))  # fall back if server uses int keys
            except Exception:
                return 0

    def _get_players_in_hand(self, round_state: RoundStateClient) -> List[int]:
        # Players that haven't folded in this hand (approx using actions log)
        folded = set()
        for pid_str, action in (round_state.player_actions or {}).items():
            if isinstance(action, str) and action.lower() == 'fold':
                try:
                    folded.add(int(pid_str))
                except Exception:
                    pass
        return [p for p in (self.all_players or []) if p not in folded]

    def _pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        total_pot_after_call = round_state.pot + call_amount
        return safe_div(call_amount, total_pot_after_call)

    def _can_check(self, round_state: RoundStateClient, our_bet: int) -> bool:
        # Check is allowed if we already match the current bet
        return our_bet >= round_state.current_bet

    def _can_raise(self, round_state: RoundStateClient, remaining_chips: int) -> bool:
        try:
            return round_state.min_raise is not None and round_state.max_raise is not None and round_state.max_raise >= max(1, round_state.min_raise) and remaining_chips >= max(1, round_state.min_raise)
        except Exception:
            return False

    def _choose_raise_amount(self, round_state: RoundStateClient, desired: int) -> int:
        """Ensure raise amount within valid [min_raise, max_raise] bounds."""
        mn = max(1, int(round_state.min_raise))
        mx = max(0, int(round_state.max_raise))
        if mx < mn:
            return 0
        amt = max(mn, min(mx, int(desired)))
        return amt

    def _betting_round_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Compute basic quantities
        our_bet = self._get_our_bet(round_state)
        call_amount = max(0, int(round_state.current_bet) - our_bet)
        can_check = self._can_check(round_state, our_bet)
        can_raise = self._can_raise(round_state, remaining_chips)
        pot_odds = self._pot_odds(round_state, call_amount) if call_amount > 0 else 0.0
        players_in_hand = self._get_players_in_hand(round_state)
        opp_count = max(1, len(players_in_hand) - 1)

        round_name = get_round_name(round_state)

        # Fallback if we somehow don't have hole cards
        if len(self.hole_cards) != 2:
            # Be ultra-safe: check if possible; otherwise fold small calls or call tiny
            if can_check:
                return PokerAction.CHECK, 0
            if call_amount <= max(2 * self.blind_amount, 10):
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Preflop decision
        if round_name.lower() == 'preflop':
            strength = preflop_strength(self.hole_cards)
            # Count raises so far this street
            raises_so_far = sum(1 for a in (round_state.player_actions or {}).values() if isinstance(a, str) and a.lower() in ('raise', 'all_in', 'all-in', 'all in'))

            # If we can check (big blind and no raise), decide to raise premium hands, otherwise check
            if can_check:
                if strength >= 0.80 and can_raise:
                    # Strong open raise
                    desired = max(round_state.min_raise, 3 * max(self.blind_amount, 1))
                    amount = self._choose_raise_amount(round_state, desired)
                    if amount > 0:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0

            # We face a bet/raise
            # Very strong: 3-bet or jam sometimes
            if strength >= 0.88 and can_raise:
                # Size up: if short or multiway, lean to all-in; else solid 3-bet
                if remaining_chips < 40 * max(self.blind_amount, 1) or opp_count > 2:
                    return PokerAction.ALL_IN, 0
                desired = max(round_state.min_raise, max(call_amount * 2, 6 * max(self.blind_amount, 1)))
                amount = self._choose_raise_amount(round_state, desired)
                if amount > 0:
                    return PokerAction.RAISE, amount
                return PokerAction.CALL, 0

            # Medium-strong: call reasonable, fold to huge
            if strength >= 0.65:
                # Call if pot odds reasonable; avoid calling huge shoves with marginal
                if pot_odds <= 0.35 or call_amount <= 6 * max(self.blind_amount, 1):
                    return PokerAction.CALL, 0
                # Otherwise fold marginal to massive raises
                return PokerAction.FOLD, 0

            # Speculative suited connectors/small pairs can call cheap
            if strength >= 0.50:
                if call_amount <= 3 * max(self.blind_amount, 1):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Weak: fold unless very cheap
            if call_amount <= max(self.blind_amount, 1) and self.random.random() < 0.1:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Postflop decision making
        board = round_state.community_cards or []
        all_cards = self.hole_cards + board
        best, best_cards = best_hand_eval(all_cards)
        hand_score = hand_category_score(best)  # 0..1

        top_pair, overpair = is_top_pair_or_overpair(self.hole_cards, board)
        flush_draw = has_flush_draw(self.hole_cards, board)
        oesd = has_open_ended_straight_draw(self.hole_cards, board)
        gutshot = has_gutshot_draw(self.hole_cards, board)

        strong_made = best[0] >= 2  # two pair or better
        medium_made = (best[0] == 1 and (top_pair or overpair)) or best[0] == 3  # pair with top/over or trips
        weak_made = best[0] == 1  # any pair

        # Approx equities
        draw_equity = 0.0
        if flush_draw and oesd:
            draw_equity = 0.48
        elif flush_draw:
            draw_equity = 0.35
        elif oesd:
            draw_equity = 0.32
        elif gutshot:
            draw_equity = 0.17

        # Multiway adjustment: tougher standards
        multi_adj = 0.04 * (opp_count - 1)
        # Round-specific aggression
        street = round_name.lower()  # flop, turn, river
        if street == 'flop':
            value_bet_frac = 0.7
            bluff_bet_frac = 0.55
        elif street == 'turn':
            value_bet_frac = 0.65
            bluff_bet_frac = 0.45
        else:  # river
            value_bet_frac = 0.7
            bluff_bet_frac = 0.35

        # If no bet to us (we can check)
        if can_check:
            # Value bet with strong hands
            if strong_made or hand_score >= 0.75:
                if self._can_raise(round_state, remaining_chips):
                    desired = max(round_state.min_raise, int(value_bet_frac * max(1, round_state.pot)))
                    amount = self._choose_raise_amount(round_state, desired)
                    if amount > 0:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0
            # Semi-bluff draws on flop/turn
            if (flush_draw or oesd) and street in ('flop', 'turn'):
                # Mix between bet and check
                if self._can_raise(round_state, remaining_chips) and self.random.random() < 0.55:
                    desired = max(round_state.min_raise, int(bluff_bet_frac * max(1, round_state.pot)))
                    amount = self._choose_raise_amount(round_state, desired)
                    if amount > 0:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0
            # Medium made: occasional thin value bet on flop/turn
            if medium_made and street in ('flop', 'turn') and self._can_raise(round_state, remaining_chips) and self.random.random() < 0.35:
                desired = max(round_state.min_raise, int(0.4 * max(1, round_state.pot)))
                amount = self._choose_raise_amount(round_state, desired)
                if amount > 0:
                    return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0

        # We face a bet
        # Value raise with strong hands
        if strong_made or hand_score >= 0.85:
            if can_raise:
                desired = max(round_state.min_raise, int(value_bet_frac * max(1, round_state.pot)))
                # With nutty hands, sometimes go all-in if short
                if remaining_chips < 25 * max(self.blind_amount, 1) and self.random.random() < 0.4:
                    return PokerAction.ALL_IN, 0
                amount = self._choose_raise_amount(round_state, desired)
                if amount > 0:
                    return PokerAction.RAISE, amount
            return PokerAction.CALL, 0

        # Medium made hands: call moderate bets, fold to very bad pot odds especially multiway
        if medium_made or (weak_made and top_pair):
            # Compute threshold: allow calling up to ~40% pot odds on flop, decreasing on later streets
            thresh = 0.40 - (0.05 if street == 'turn' else 0.0) - (0.08 if street == 'river' else 0.0) - multi_adj
            if pot_odds <= max(0.15, thresh):
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Draws: call if pot odds < equity (minus multiway adjustment)
        if draw_equity > 0:
            equity_adj = max(0.0, draw_equity - multi_adj)
            if pot_odds <= equity_adj + 0.03:
                # Occasionally semi-bluff raise on flop/turn
                if can_raise and street in ('flop', 'turn') and self.random.random() < 0.35:
                    desired = max(round_state.min_raise, int(bluff_bet_frac * max(1, round_state.pot)))
                    amount = self._choose_raise_amount(round_state, desired)
                    if amount > 0:
                        return PokerAction.RAISE, amount
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Weak/no hand: fold to sizable bets; occasionally float small bets on flop
        small_bet_threshold = 0.15 + (0.05 if street == 'flop' else 0.0)
        if pot_odds <= small_bet_threshold and street == 'flop' and self.random.random() < 0.25:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            action, amount = self._betting_round_action(round_state, remaining_chips)

            # Final safety checks to avoid invalid actions per rules
            our_bet = self._get_our_bet(round_state)
            call_amount = max(0, round_state.current_bet - our_bet)
            if action == PokerAction.CHECK:
                # Only allowed if we already matched current bet
                if our_bet < round_state.current_bet:
                    # Fallback to call if cheap, else fold
                    if call_amount == 0:
                        return PokerAction.CALL, 0
                    if call_amount <= max(2 * self.blind_amount, 10):
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                return PokerAction.CHECK, 0
            elif action == PokerAction.CALL:
                # Always valid (engine will match to call)
                if call_amount == 0:
                    # If nothing to call, check instead
                    return PokerAction.CHECK, 0
                return PokerAction.CALL, 0
            elif action == PokerAction.RAISE:
                # Ensure raise is possible and amount is valid
                if not self._can_raise(round_state, remaining_chips):
                    # Fallback: if can't raise, call if possible, else check/fold
                    if call_amount > 0:
                        return PokerAction.CALL, 0
                    return PokerAction.CHECK, 0
                # Clip amount
                amount = self._choose_raise_amount(round_state, amount if isinstance(amount, int) else 0)
                if amount <= 0:
                    # Fallback to call/check
                    if call_amount > 0:
                        return PokerAction.CALL, 0
                    return PokerAction.CHECK, 0
                return PokerAction.RAISE, int(amount)
            elif action == PokerAction.ALL_IN:
                return PokerAction.ALL_IN, 0
            elif action == PokerAction.FOLD:
                # If nothing to call, check instead
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Default conservative fallback
            if call_amount == 0:
                return PokerAction.CHECK, 0
            return PokerAction.CALL, 0
        except Exception:
            # Absolute fallback to avoid auto-fold from exceptions
            our_bet = 0
            try:
                our_bet = self._get_our_bet(round_state)
            except Exception:
                pass
            call_amount = max(0, getattr(round_state, 'current_bet', 0) - our_bet)
            if call_amount == 0:
                return PokerAction.CHECK, 0
            if call_amount <= max(2 * self.blind_amount, 10):
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Clear per-hand info
        self.hole_cards = []
        self.last_action_info.clear()

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent learning in this baseline; could log or update tendencies if allowed.
        pass