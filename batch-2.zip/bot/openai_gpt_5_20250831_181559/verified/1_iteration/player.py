from typing import List, Tuple, Dict, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session level
        self.starting_chips: int = 0
        self.small_blind_amount: int = 0  # As provided by host; may be static or initial
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.num_players: int = 0

        # Hand-level state
        self.hole_cards: Optional[List[str]] = None
        self.current_round_num: int = -1  # To detect new hands
        self.last_round_name: str = ""
        self.last_seen_player_bets: Dict[str, int] = {}

        # Basic aggression parameters
        self.overbet_factor: float = 1.5
        self.pot_bet_factor: float = 0.75

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Store session-level info
        self.starting_chips = starting_chips
        self.small_blind_amount = max(int(blind_amount), 0)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.num_players = len(self.all_players) if self.all_players else 0

        # Try to capture hole cards if provided here
        self.hole_cards = self._parse_hole_cards_from_list(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Detect new hand by change in round_num
        if round_state.round_num != self.current_round_num:
            # New hand starts
            self.current_round_num = round_state.round_num
            # Hole cards might be updated by the environment via on_start in some implementations,
            # but if not, keep existing if provided; otherwise remain unknown and play very tight.
            # If the environment later provides a way to set hole cards, we could hook it here.
            pass
        self.last_round_name = round_state.round

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_id_str = str(self.id) if self.id is not None else ""
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(round_state.current_bet)
            to_call = max(current_bet - my_bet, 0)
            pot = max(int(round_state.pot), 0)

            # If no hole cards known, be extremely conservative: check when free, otherwise fold preflop/flop/turn;
            # call only trivial amounts on river to avoid timeouts. This avoids spew due to unknown cards.
            if not self.hole_cards or len(self.hole_cards) < 2 or not self._valid_card(self.hole_cards[0]) or not self._valid_card(self.hole_cards[1]):
                return self._action_without_cards(round_state, to_call)

            community = round_state.community_cards or []
            # Estimate hand strength (0..1)
            strength = self._estimate_hand_strength(self.hole_cards, community)

            # Basic pot odds decision
            eps = 1e-9
            pot_odds = to_call / (pot + to_call + eps) if to_call > 0 else 0.0

            # Determine number of opponents still in hand (approx)
            active_count = self._estimate_active_players(round_state)
            if active_count <= 1:
                active_count = max(2, self.num_players if self.num_players > 0 else 2)

            # Increase caution with more opponents
            multiway_factor = 1.0 + max(active_count - 2, 0) * 0.07
            adjusted_strength = max(0.0, min(1.0, strength / multiway_factor))

            # Decide by street
            street = (round_state.round or "").lower()
            if to_call <= 0:
                # No bet facing: consider betting/raising for value if allowed; otherwise check
                if adjusted_strength >= 0.8:
                    # Try to raise for value if we can produce a safe amount
                    raise_to = self._suggest_bet_size(round_state, pot, remaining_chips, target="value")
                    if raise_to is not None:
                        return PokerAction.RAISE, int(raise_to)
                # With medium strength, maybe a small bet if allowed
                if 0.55 <= adjusted_strength < 0.8:
                    raise_to = self._suggest_bet_size(round_state, pot, remaining_chips, target="thin")
                    if raise_to is not None:
                        return PokerAction.RAISE, int(raise_to)
                # Otherwise check
                return PokerAction.CHECK, 0

            # We face a bet/raise
            # If we are essentially all-in to continue, decide shove or fold by equity
            if to_call >= remaining_chips:
                if adjusted_strength >= 0.5:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

            # Strong made hands: consider raising/shoving for value
            if adjusted_strength >= 0.85:
                # Prefer raise if possible, else all-in
                raise_to = self._suggest_raise_over_bet(round_state, to_call, pot, remaining_chips, strength_level="strong")
                if raise_to is not None:
                    return PokerAction.RAISE, int(raise_to)
                else:
                    return PokerAction.ALL_IN, 0

            # Good hands: call if pot odds are favorable or slightly unfavorable (we realize equity well)
            if adjusted_strength >= 0.6:
                # Consider a value raise sometimes if raise is allowed
                raise_to = self._suggest_raise_over_bet(round_state, to_call, pot, remaining_chips, strength_level="medium")
                if raise_to is not None and to_call / (remaining_chips + eps) < 0.15:
                    return PokerAction.RAISE, int(raise_to)
                # Otherwise, call if pot odds fit
                if pot_odds <= adjusted_strength + 0.05:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Drawing/medium hands: call by pot odds; fold otherwise
            if 0.35 <= adjusted_strength < 0.6:
                if pot_odds <= adjusted_strength - 0.02:  # need a small edge
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Weak hands: mostly fold; occasionally defend small bets
            small_pct = to_call / (remaining_chips + eps)
            if small_pct < 0.03 and pot_odds < 0.2:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        except Exception:
            # In case of any unexpected error, fail-safe fold (or check if free)
            my_id_str = str(self.id) if self.id is not None else ""
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            to_call = max(int(round_state.current_bet) - my_bet, 0)
            if to_call <= 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # At end of each round in a hand; no special cleanup needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game end callback; could be used for learning/statistics in a more advanced bot
        pass

    # ------------------------- Helper Methods -------------------------

    def _parse_hole_cards_from_list(self, player_hands: List[str]) -> Optional[List[str]]:
        """Try to interpret provided player_hands into our 2-card hole cards"""
        if not player_hands:
            return None
        # If list already contains two card strings like ['Ah','Kd']
        if len(player_hands) >= 2 and all(self._valid_card(c) for c in player_hands[:2]):
            return [player_hands[0], player_hands[1]]

        # If first item is a combined string, split by space or comma
        first = player_hands[0]
        if isinstance(first, str):
            tokens = [t.strip() for t in first.replace(",", " ").split() if t.strip()]
            if len(tokens) >= 2 and all(self._valid_card(t) for t in tokens[:2]):
                return [tokens[0], tokens[1]]
        return None

    def _valid_card(self, c: str) -> bool:
        if not isinstance(c, str) or len(c) < 2:
            return False
        ranks = set("23456789TJQKA")
        suits = set("cdhsCDHS")
        r = c[0].upper()
        s = c[1].lower()
        return r in ranks and s in suits

    def _card_rank(self, c: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
                    '7': 7, '8': 8, '9': 9, 'T': 10,
                    'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[c[0].upper()]

    def _card_suit(self, c: str) -> str:
        return c[1].lower()

    def _estimate_active_players(self, round_state: RoundStateClient) -> int:
        # Try to count non-folded players based on actions
        try:
            if round_state.player_actions:
                cnt = 0
                for pid, act in round_state.player_actions.items():
                    a = (act or "").lower()
                    if "fold" in a:
                        continue
                    cnt += 1
                if cnt > 0:
                    return cnt
            # Fallback to those who have bets this hand
            if round_state.player_bets:
                return len([1 for _ in round_state.player_bets.keys()])
            # Fallback to total players
            return self.num_players if self.num_players > 0 else 2
        except Exception:
            return self.num_players if self.num_players > 0 else 2

    # --------- Hand Strength Estimation ---------

    def _estimate_hand_strength(self, hole: List[str], board: List[str]) -> float:
        """Return a heuristic strength 0..1 combining made hand and draws."""
        # Preflop only
        if not board:
            return self._preflop_strength(hole)

        # Postflop: categorize made hand, detect draws, and combine
        all_cards = hole + board
        made_category = self._hand_category(all_cards)  # 0..9
        made_strength = self._category_to_strength(made_category, hole, board)

        draw_strength = self._draw_potential(hole, board)  # 0..~0.7
        # Combine: emphasize made hand but include draw equity
        strength = max(made_strength, draw_strength)
        # Slightly bump if we hold blockers and board texture good
        strength = max(0.0, min(1.0, strength))
        return strength

    def _preflop_strength(self, hole: List[str]) -> float:
        r1 = self._card_rank(hole[0])
        r2 = self._card_rank(hole[1])
        s1 = self._card_suit(hole[0])
        s2 = self._card_suit(hole[1])
        suited = (s1 == s2)
        ranks_sorted = sorted([r1, r2], reverse=True)
        high, low = ranks_sorted[0], ranks_sorted[1]
        pair = (r1 == r2)

        def is_conn(a, b):
            return abs(a - b) == 1

        # Create code string like 'AKs','AQo','TT'
        rank_to_char = {14: 'A', 13: 'K', 12: 'Q', 11: 'J', 10: 'T',
                        9: '9', 8: '8', 7: '7', 6: '6', 5: '5', 4: '4', 3: '3', 2: '2'}
        if pair:
            code = rank_to_char[high] * 2
        else:
            code = rank_to_char[high] + rank_to_char[low] + ('s' if suited else 'o')

        premium = set(['AA', 'KK', 'QQ', 'JJ', 'AKs'])
        strong = set(['TT', 'AQs', 'AJs', 'KQs', 'AKo', 'AQo'])
        medium = set(['99', '88', '77', 'ATo', 'KQo', 'KJs', 'QJs', 'JTs', 'T9s', '98s'])
        spec = set(['66', '55', '44', '33', '22', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s',
                    '87s', '76s', '65s', '54s', 'T8s', '97s', '86s'])

        if code in premium:
            return 0.92
        if code in strong:
            return 0.8
        if code in medium:
            return 0.62
        if code in spec:
            return 0.5

        # Heuristics for unlisted combos
        if pair:
            if high >= 9:
                return 0.64
            elif high >= 7:
                return 0.55
            else:
                return 0.46
        # Suited connectors / broadways
        if suited and is_conn(high, low) and high >= 11:
            return 0.58
        if suited and high >= 12 and low >= 10:
            return 0.56
        if high >= 13 and low >= 10:
            return 0.52
        if suited and is_conn(high, low):
            return 0.5
        if suited and high >= 10:
            return 0.48
        if high >= 12:
            return 0.46
        return 0.38

    def _hand_category(self, cards: List[str]) -> int:
        """
        Return category index:
        9: straight flush
        8: four of a kind
        7: full house
        6: flush
        5: straight
        4: three of a kind
        3: two pair
        2: pair
        1: high card
        0: invalid (shouldn't happen)
        """
        if not cards or len(cards) < 5:
            return 1
        ranks = [self._card_rank(c) for c in cards]
        suits = [self._card_suit(c) for c in cards]

        # Flush detection
        suit_counts: Dict[str, int] = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_suit = None
        for s, cnt in suit_counts.items():
            if cnt >= 5:
                flush_suit = s
                break

        # Rank histogram
        from collections import Counter
        rc = Counter(ranks)
        counts = sorted(rc.values(), reverse=True)

        # Straight detection helper
        def has_straight(rset: set) -> bool:
            rs = sorted(rset)
            # Ace-low
            if {14, 2, 3, 4, 5}.issubset(rset):
                return True
            consec = 1
            for i in range(1, len(rs)):
                if rs[i] == rs[i - 1] + 1:
                    consec += 1
                    if consec >= 5:
                        return True
                elif rs[i] != rs[i - 1]:
                    consec = 1
            return False

        # Straight flush
        if flush_suit is not None:
            flush_ranks = {self._card_rank(c) for c in cards if self._card_suit(c) == flush_suit}
            if has_straight(flush_ranks):
                return 9

        # Four of a kind
        if 4 in counts:
            return 8

        # Full house
        if 3 in counts and 2 in counts:
            return 7
        if counts.count(3) >= 2:
            return 7

        # Flush
        if flush_suit is not None:
            return 6

        # Straight
        if has_straight(set(ranks)):
            return 5

        # Trips
        if 3 in counts:
            return 4

        # Two pair
        if counts.count(2) >= 2:
            return 3

        # Pair
        if 2 in counts:
            return 2

        # High card
        return 1

    def _category_to_strength(self, category: int, hole: List[str], board: List[str]) -> float:
        """Map category and context to a coarse strength [0,1]."""
        # Base mapping
        if category >= 9:  # straight flush
            return 0.995
        if category == 8:  # quads
            return 0.975
        if category == 7:  # full house
            return 0.94
        if category == 6:  # flush
            return 0.88
        if category == 5:  # straight
            return 0.84
        if category == 4:  # trips
            return 0.74

        ranks_board = [self._card_rank(c) for c in board]
        ranks_hole = [self._card_rank(c) for c in hole]
        max_board = max(ranks_board) if ranks_board else 0
        pair = (self._card_rank(hole[0]) == self._card_rank(hole[1]))

        if category == 3:  # two pair
            return 0.66
        if category == 2:  # one pair
            # Distinguish top pair, overpair, etc.
            hole_ranks_sorted = sorted(ranks_hole, reverse=True)
            highest_hole = hole_ranks_sorted[0]
            # Check if pair is from board or using hole:
            # We will approximate: if pair rank >= max_board -> top pair/overpair
            if pair and highest_hole > max_board:
                return 0.66  # overpair
            if highest_hole >= max_board:
                return 0.6  # top pair
            if highest_hole >= max_board - 1:
                return 0.52  # second pair-ish
            return 0.45

        # High card
        # Consider overcards
        overcards = sum(1 for r in ranks_hole if r > max_board)
        if overcards == 2:
            return 0.36
        if overcards == 1:
            return 0.32
        return 0.28

    def _draw_potential(self, hole: List[str], board: List[str]) -> float:
        """
        Estimate draw strength: flush draw, straight draws, overcards.
        Returns approximate equity proxy in 0..0.75 range depending on street.
        """
        cards = hole + board
        suits = [self._card_suit(c) for c in cards]
        ranks = [self._card_rank(c) for c in cards]
        board_ranks = [self._card_rank(c) for c in board]
        hole_ranks = [self._card_rank(c) for c in hole]
        suit_counts: Dict[str, int] = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1

        # Flush draw: 4 of a suit among 5-6 cards and we hold at least one of them
        fd = False
        for s, cnt in suit_counts.items():
            if cnt >= 4:
                if self._card_suit(hole[0]) == s or self._card_suit(hole[1]) == s:
                    fd = True
                    break

        # Straight draw detection using distinct ranks
        unique = sorted(set(ranks))
        oesd = False
        gut = False
        # Ace-low adjust
        if 14 in unique:
            unique = sorted(set(unique + [1]))
        # Count sequences
        for i in range(len(unique) - 3):
            window = unique[i:i + 4]
            if window[-1] - window[0] == 3 and len(window) == 4:
                # Need one outside card for straight -> oesd
                oesd = True
                break
        if not oesd:
            # Gutshot: 4 ranks spanning 5 ranks range (gap of 2 in the run)
            for i in range(len(unique) - 3):
                window = unique[i:i + 4]
                if window[-1] - window[0] == 4 and len(window) == 4:
                    gut = True
                    break

        # Overcards (if no pair on board) for turn/river improvement
        max_board = max(board_ranks) if board_ranks else 0
        overcards = sum(1 for r in hole_ranks if r > max_board) if max_board > 0 else 0

        street_draw_cap = 0.0
        # Street-based caps: On flop we have two cards to come; on turn one to come.
        # This crude cap helps keep draw equity realistic.
        if len(board) == 3:
            street_draw_cap = 0.62
        elif len(board) == 4:
            street_draw_cap = 0.45
        else:
            street_draw_cap = 0.3

        base = 0.0
        if fd and oesd:
            base = 0.65  # combo draw
        elif fd:
            base = 0.5
        elif oesd:
            base = 0.44
        elif gut:
            base = 0.32

        # Add small contribution from overcards if we don't have pair
        pair_on_board = self._hand_category(board) >= 2 if len(board) >= 2 else False
        if not pair_on_board and overcards >= 2:
            base = max(base, 0.38)
        elif not pair_on_board and overcards == 1:
            base = max(base, 0.33)

        return min(base, street_draw_cap)

    # --------- Betting / Raising Helpers ---------

    def _suggest_bet_size(self, round_state: RoundStateClient, pot: int, remaining_chips: int, target: str) -> Optional[int]:
        """
        Suggest a raise-to amount when no bet is faced (i.e., betting).
        Returns a valid raise_to within [min_raise, max_raise], or None if not possible.
        """
        min_r = int(round_state.min_raise) if round_state.min_raise is not None else 0
        max_r = int(round_state.max_raise) if round_state.max_raise is not None else 0
        cur = int(round_state.current_bet)
        # If we cannot raise or constraints invalid, return None
        if min_r <= 0 or max_r <= 0 or max_r < min_r:
            return None

        # Target bet sizes
        if target == "value":
            desired = cur + max(1, int(self.pot_bet_factor * max(pot, 1)))
        else:
            desired = cur + max(1, int(0.5 * max(pot, 1)))

        # Raise-to should be within [min_r, max_r] and > current bet
        raise_to = max(min_r, min(desired, max_r))
        if raise_to <= cur or raise_to < min_r:
            return None
        return int(raise_to)

    def _suggest_raise_over_bet(self, round_state: RoundStateClient, to_call: int, pot: int,
                                remaining_chips: int, strength_level: str = "medium") -> Optional[int]:
        """
        Suggest a raise-to amount when facing a bet.
        Uses sizing around 2.5x-3.5x the bet (to_call) plus call amount, capped by limits.
        Returns None if not feasible.
        """
        min_r = int(round_state.min_raise) if round_state.min_raise is not None else 0
        max_r = int(round_state.max_raise) if round_state.max_raise is not None else 0
        cur = int(round_state.current_bet)
        if min_r <= 0 or max_r <= 0 or max_r < min_r:
            return None

        # Choose multiplier based on hand strength
        if strength_level == "strong":
            mult = 3.5
        else:
            mult = 2.5
        desired_increment = int(mult * max(to_call, 1))
        desired = cur + desired_increment
        raise_to = max(min_r, min(desired, max_r))
        # Ensure it increases the bet
        if raise_to <= cur or raise_to < min_r:
            return None
        return int(raise_to)

    def _action_without_cards(self, round_state: RoundStateClient, to_call: int) -> Tuple[PokerAction, int]:
        """
        Conservative default when hole cards are unknown: never spew chips.
        """
        if to_call <= 0:
            return PokerAction.CHECK, 0
        # In end streets if pot odds are extreme we might call small bets, but we don't know the street here.
        # Keep it simple and tight:
        # If the bet is tiny (<1% of stack), call; else fold.
        return (PokerAction.CALL, 0) if to_call <= max(1, int(0.01 * max(1, self.starting_chips))) else (PokerAction.FOLD, 0)