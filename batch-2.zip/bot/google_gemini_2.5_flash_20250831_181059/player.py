import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.player_id = -1 # Initialize with a default invalid ID
        self.starting_chips = 0
        self.hand_strength_preflop_lookup = {
            # Pair
            'AA': 1.0, 'KK': 0.98, 'QQ': 0.96, 'JJ': 0.94, 'TT': 0.92,
            '99': 0.88, '88': 0.84, '77': 0.80, '66': 0.76, '55': 0.72,
            '44': 0.68, '33': 0.64, '22': 0.60,
            # Suited connectors
            'AKs': 0.95, 'AQs': 0.93, 'AJs': 0.91, 'ATs': 0.89,
            'KQs': 0.87, 'KJs': 0.85, 'KTs': 0.83,
            'QJs': 0.81, 'QTs': 0.79,
            'JTs': 0.77,
            'T9s': 0.73, '98s': 0.69, '87s': 0.65, '76s': 0.61, '65s': 0.57, '54s': 0.53,
            # Offsuit Broadway
            'AKo': 0.90, 'AQo': 0.86, 'AJo': 0.82, 'ATo': 0.78,
            'KQo': 0.74, 'KJo': 0.70, 'KTo': 0.66,
            'QJo': 0.62, 'QTo': 0.58,
            'JTo': 0.54
        }
        self.current_round_bet = 0  # To track how much the bot has put in this round

    def set_id(self, player_id: int) -> None:
        """ Sets the player ID. """
        self.id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2
        # On start, player_hands contains the initial hole cards for the first hand.
        # This will be updated in on_round_start for subsequent hands.
        if self.id is not None:
            for hand_str in player_hands:
                # Assuming player_hands format is like 'player_id: [card1, card2]'
                # This part might need adjustment based on actual `player_hands` structure
                # For now, let's assume `player_hands` directly gives the two cards for the bot.
                # The prompt has `player_hands: List[str]`, which is ambiguous.
                # Let's assume it's just the bot's hole cards as strings e.g. ['Ah', 'Ks']
                self.hole_cards = player_hands 
        else:
            # Handles the case where set_id might not have been called yet by the time on_start is invoked.
            # This is a potential race condition or ordering issue, but for now, we'll try to get the ID later.
            pass # Self.id will be set by the server

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the new round if they are passed in round_state
        # The prompt for round_state doesn't explicitly show `player_hands`, so
        # we'll assume `on_start` is where the first hand is given, and
        # `get_action` will implicitly know about the cards or they are managed externally.
        # This is a potential point of confusion based on the provided interfaces.
        # For a robust bot, the bot needs to know its hole cards for the current hand.
        # If `player_hands` is not passed here, it means we get it once `on_start`.
        # Assuming the contest system will pass the specific player's hole cards to `get_action`
        # for a specific bot or `on_round_start` must provide it.
        # For now, we'll assume the hole cards are still stored from `on_start` or provided in `get_action` context.
        self.current_round_bet = 0 # Reset current round bet for the new round

        # A hacky way for player_hands management.
        # If the problem statement implies player_hands in `on_start` is for the first game only
        # and subsequent hands are given implicitly or as part of round_state (which it isn't),
        # this is a major gap. For competitive setup, it must be provided consistently.
        # Let's rely on `get_action` to have all necessary information or `on_round_start` has `player_hands` too.
        # The prompt for on_start takes `player_hands: List[str]`, but not on_round_start.
        #This assumes `player_hands` might be a global pool of active hands.
        # If `on_start` is providing the bot's hole cards, they should persist for that hand.
        # Since on_round_start is per hand, it's safer to rely on internal state or
        # that the hole cards are available via some other mechanism.

        # For this iteration, let's assume `self.hole_cards` is already correctly set by the system
        # or `on_start` covers it for the entire initial game.
        # The best practice would be `on_round_start` provides current player's hole cards.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_round = round_state.round
        community_cards = round_state.community_cards
        current_bet_to_match = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_bet_in_this_round = round_state.player_bets.get(str(self.id), 0)

        # Calculate amount to call or raise
        amount_to_call = current_bet_to_match - player_bet_in_this_round
        
        # Ensure player_bet_in_this_round is correctly updated within each round of betting
        # The problem statement says `player_bets` is per round.
        
        # Basic Pre-flop Strategy
        if current_round == 'Preflop':
            if len(self.hole_cards) != 2:
                # If hole cards are not set yet, fold or check defensively
                return (PokerAction.FOLD, 0)
            
            card1_rank = self._get_rank_value(self.hole_cards[0])
            card2_rank = self._get_rank_value(self.hole_cards[1])
            card1_suit = self._get_suit(self.hole_cards[0])
            card2_suit = self._get_suit(self.hole_cards[1])
            
            is_suited = (card1_suit == card2_suit)
            is_paired = (card1_rank == card2_rank)

            # Determine pre-flop hand strength
            hand_key = self._get_hand_key(self.hole_cards)
            strength = self.hand_strength_preflop_lookup.get(hand_key, 0.4) # Default for unlisted hands

            # Aggressiveness factor based on remaining chips vs total starting chips
            chip_ratio = remaining_chips / (self.starting_chips + 1e-9) # Add epsilon to prevent div by zero
            aggressiveness = 0.5 + (chip_ratio * 0.5) # More chips, more aggressive

            # Calculate desired action based on strength and current bet
            # If current bet is 0 (first to act or everyone checked before)
            if current_bet_to_match == 0:
                if strength >= 0.7:  # Strong hands
                    raise_amount = min(max_raise, self.big_blind_amount * (2 + int(strength * 5))) # Raise larger based on strength
                    return (PokerAction.RAISE, raise_amount)
                elif strength >= 0.5: # Medium hands
                    if random.random() < aggressiveness:
                        raise_amount = min(max_raise, self.big_blind_amount * 2)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0) # Check if not confident enough to raise
                else: # Weak hands
                    if random.random() < 0.2: # Occasionally limp
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
            else: # There's a bet to match
                # Check if we can afford to call
                if amount_to_call > remaining_chips:
                    return (PokerAction.FOLD, 0) # Cannot afford to call, must fold

                if strength >= 0.8: # Very strong hands, re-raise or call
                    if amount_to_call <= remaining_chips / 4: # If bet is small relative to stack, raise
                        raise_amount = min(max_raise, current_bet_to_match * 2)
                        if raise_amount < min_raise and current_bet_to_match + min_raise <= remaining_chips:
                            raise_amount = min_raise
                        elif current_bet_to_match + min_raise > remaining_chips: # Cannot afford min_raise on top of current bet
                            if amount_to_call == remaining_chips: # Only option is all-in
                                return (PokerAction.ALL_IN, 0)
                            raise_amount = remaining_chips
                            return (PokerAction.ALL_IN if raise_amount > 0 else PokerAction.CALL, raise_amount) # All-in if cant raise properly
                        
                        # Ensure we don't accidentally try to "raise" if it's just a call due to min_raise calc
                        if player_bet_in_this_round + raise_amount >= current_bet_to_match + min_raise:
                             return (PokerAction.RAISE, player_bet_in_this_round + raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                        
                    else: # If bet is large, just call
                        return (PokerAction.CALL, 0)
                elif strength >= 0.6: # Medium-strong hands
                    if amount_to_call <= remaining_chips / 8: # Call small bets
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0) # Fold to larger bets
                elif strength >= 0.4: # Margianl hands
                    if amount_to_call == self.big_blind_amount or amount_to_call <= remaining_chips / 10: # Only call minimum blind or very small bets
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else: # Weak hands
                    return (PokerAction.FOLD, 0)

        # Post-flop Strategy (Flop, Turn, River) - More dynamic
        else: # Flop, Turn, River
            # Calculate hand strength based on hole cards and community cards
            # This is a simplified hand evaluation. A real bot would calculate odds.
            
            # Simple heuristic:
            # 1. Check for pairs with community cards
            # 2. Check for flush/straight draws
            # 3. Check for high card
            
            all_cards = self.hole_cards + community_cards
            ranks = [self._get_rank_value(card) for card in all_cards]
            suits = [self._get_suit(card) for card in all_cards]
            
            # Count rank occurrences for pairs, trips, quads
            rank_counts = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1
            
            max_rank_occ = 0
            for r in rank_counts:
                max_rank_occ = max(max_rank_occ, rank_counts[r])
            
            # Check for flush draw/made flush
            flush_possible = False
            flush_made = False
            for s in ['h', 'd', 'c', 's']:
                suit_count = suits.count(s)
                if suit_count >= 5:
                    flush_made = True
                    break
                elif current_round != 'River' and suit_count >= 4: # Flush draw
                    flush_possible = True

            # Check for straight draw/made straight
            sorted_unique_ranks = sorted(list(set(ranks)))
            straight_made = False
            straight_possible = False
            
            if len(sorted_unique_ranks) >= 5:
                # Check for straight
                for i in range(len(sorted_unique_ranks) - 4):
                    if sorted_unique_ranks[i+4] - sorted_unique_ranks[i] == 4:
                        straight_made = True
                        break
                # Check for Aces high/low straight (A,2,3,4,5 or T,J,Q,K,A)
                if 14 in sorted_unique_ranks: #'A'
                    temp_ranks = sorted_unique_ranks + [1] # Add Ace as 1 for low straight check
                    temp_ranks = sorted(list(set(temp_ranks)))
                    if len(temp_ranks) >= 5:
                        for i in range(len(temp_ranks) - 4):
                            if temp_ranks[i+4] - temp_ranks[i] == 4:
                                straight_made = True
                                break

            # Check for straight draws (gutshot or open-ended) on Flop/Turn
            if not straight_made and current_round != 'River':
                # Simplified check for open-ended straight draw
                for rank in range(1, 11): # Check for 5-9, 6-10 etc.
                    required_ranks = set(range(rank, rank + 5))
                    missing_count = len(required_ranks - set(ranks))
                    if missing_count <= 1: # One card missing for straight
                        straight_possible = True
                        break
            
            hand_strength = 0.0 # Placeholder for dynamic strength evaluation
            
            if max_rank_occ >= 4: hand_strength = 0.95 # Four of a kind (very strong)
            elif max_rank_occ == 3 and len(rank_counts) <= len(ranks) - 2: # Full house (simplified) - if has trips and a pair
                has_pair = False
                for r in rank_counts:
                    if rank_counts[r] >= 2 and rank_counts[r] != 3:
                        has_pair = True
                        break
                if has_pair: hand_strength = 0.90
                else: hand_strength = 0.75 # Three of a kind
            elif straight_made: hand_strength = 0.85
            elif flush_made: hand_strength = 0.80
            elif max_rank_occ == 2:
                pair_count = sum(1 for r in rank_counts if rank_counts[r] == 2)
                if pair_count >= 2: hand_strength = 0.70 # Two Pair
                else: hand_strength = 0.60 # One Pair
            else: hand_strength = 0.3 # High card
            
            if straight_possible: hand_strength = max(hand_strength, 0.45)
            if flush_possible: hand_strength = max(hand_strength, 0.50)

            # Adjust strength based on number of community cards
            if current_round == 'Flop':
                hand_strength += 0.05 # More potential on flop
            elif current_round == 'River':
                hand_strength -= 0.05 # No more cards to come, strength is final 

            # Decision Logic for Post-flop
            if current_bet_to_match == 0: # Player to act first, or previous players checked
                if hand_strength >= 0.7: # Strong hand
                    # Value bet or check-raise
                    bet_amount = min(max_raise, int(round_state.pot * 0.75)) # Bet 75% of pot
                    return (PokerAction.RAISE, max(bet_amount, self.big_blind_amount)) # Ensure bet is at least BB
                elif hand_strength >= 0.5 and remaining_chips > self.big_blind_amount: # Medium hand
                    if random.random() < 0.6: # C-bet or smaller value bet
                        bet_amount = min(max_raise, int(round_state.pot * 0.4)) # Bet 40% of pot
                        return (PokerAction.RAISE, max(bet_amount, self.big_blind_amount))
                    else:
                        return (PokerAction.CHECK, 0)
                else: # Weak hand
                    return (PokerAction.CHECK, 0) # Check and proceed cautiously
            else: # There's a bet to match
                if amount_to_call >= remaining_chips: # Cannot afford to call, all-in or fold
                    if hand_strength >= 0.7:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)

                if hand_strength >= 0.85: # Very strong hand, raise or all-in
                    if amount_to_call < remaining_chips / 2 and current_bet_to_match + min_raise <= remaining_chips:
                        raise_amount = min(max_raise, current_bet_to_match * 2) 
                        return (PokerAction.RAISE, player_bet_in_this_round + raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength >= 0.65: # Strong hand
                    if random.random() < 0.8 or amount_to_call <= self.big_blind_amount * 2: # Call small/medium bets or bluff sometimes
                        return (PokerAction.CALL, 0)
                    else: # Consider raising if a good opportunity, but for now just call or fold
                        return (PokerAction.FOLD, 0)
                elif hand_strength >= 0.4: # Marginal hand, call small bets or fold
                    if amount_to_call <= self.big_blind_amount: # Call only minimum bets
                        return (PokerAction.CALL, 0)
                    elif random.random() < 0.1: # Small chance to bluff
                        return (PokerAction.CALL, 0) # Bluff with call
                    else:
                        return (PokerAction.FOLD, 0)
                else: # Weak hand
                    return (PokerAction.FOLD, 0)

        # Fallback in case no specific strategy is triggered, usually implies fold
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = []
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _get_rank_value(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def _get_suit(self, card: str) -> str:
        return card[1]

    def _get_hand_key(self, cards: List[str]) -> str:
        if not cards or len(cards) < 2:
            return ""
        
        r1 = self._get_rank_value(cards[0])
        r2 = self._get_rank_value(cards[1])
        s1 = self._get_suit(cards[0])
        s2 = self._get_suit(cards[1])

        ranks = sorted([r1, r2], reverse=True)
        rank_chars = {14: 'A', 13: 'K', 12: 'Q', 11: 'J', 10: 'T'}
        
        card1_char = rank_chars.get(ranks[0], str(ranks[0]))
        card2_char = rank_chars.get(ranks[1], str(ranks[1]))

        key = card1_char + card2_char
        if s1 == s2:
            key += 's'
        elif r1 != r2: # Only append 'o' if they are offsuit and not a pair
            key += 'o'
        
        return key