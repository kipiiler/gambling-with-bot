import random
from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.all_players: List[int] = []
        self.player_hands_map: Dict[int, List[str]] = {} # To store hands initialized on_start

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        # player_hands here is YOUR hand for the first game, not a map of all players' hands.
        self.hole_cards = player_hands 
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # Initialize player_hands_map for subsequent rounds if needed, though typically on_round_start gives new hands
        self.player_hands_map = {self.id: self.hole_cards}


    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # player_hands is not directly in RoundStateClient. We get our hole cards in on_start.
        # For subsequent rounds, the new hole cards are typically provided as part of a new game state.
        # This means `self.hole_cards` should be updated when our hole cards are specifically provided for a new round.
        # The competition framework handles providing hole cards. Since it's not in `round_state` here, 
        # we assume it's set just before `on_round_start` or `on_start` for the specific player.
        # If the framework doesn't provide it here, we must rely on how it's initially set.
        # The previous error "AttributeError: 'RoundStateClient' object has no attribute 'player_hands'"
        # confirms that `round_state.player_hands` is incorrect.
        pass # No action needed here to set hole cards based on round_state.

    def _get_card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'A': return 14
        if rank == 'K': return 13
        if rank == 'Q': return 12
        if rank == 'J': return 11
        if rank == 'T': return 10
        return int(rank)

    def _get_card_suit(self, card: str) -> str:
        return card[1]

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2: # Not enough cards to evaluate
            return 0.0

        # Simple pre-flop evaluation for starting hands
        if len(community_cards) == 0:
            rank1 = self._get_card_rank(hole_cards[0])
            rank2 = self._get_card_rank(hole_cards[1])
            suit1 = self._get_card_suit(hole_cards[0])
            suit2 = self._get_card_suit(hole_cards[1])

            # Pair
            if rank1 == rank2:
                # Top pairs are strong
                if rank1 >= 10: return 0.8 + (rank1 - 10) * 0.05 # TT+
                return 0.5 + rank1 * 0.01 # Any pair

            # Suited connectors/gappers
            if suit1 == suit2:
                if abs(rank1 - rank2) <= 2: return 0.4 + max(rank1, rank2) * 0.01
                if abs(rank1 - rank2) == 1: return 0.45 + max(rank1, rank2) * 0.01 # Suited connectors
                if abs(rank1 - rank2) <= 4 and max(rank1,rank2) >= 10: return 0.4 # Suited Ax, Kx
                if max(rank1, rank2) >= 12: return 0.35 # Suited broadways

            # Connectors/gappers (off-suit)
            if abs(rank1 - rank2) <= 1 and max(rank1, rank2) >= 10: return 0.3 # Broadways off-suit
            if abs(rank1 - rank2) <= 1: return 0.25 # Small connectors off-suit

            # High cards
            if max(rank1, rank2) >= 12: return 0.25 # KQ+, KJ+ (off-suit or not)
            if max(rank1, rank2) >= 10 and min(rank1, rank2) >= 8: return 0.2 # Mid-high cards

            return 0.05 # Weak hand
        
        # Post-flop evaluation (simplified)
        ranks = [self._get_card_rank(card) for card in all_cards]
        suits = [self._get_card_suit(card) for card in all_cards]
        
        # Count frequencies
        rank_counts = {rank: ranks.count(rank) for rank in ranks}
        suit_counts = {suit: suits.count(suit) for suit in suits}

        # Check for flush draw
        has_flush_draw = any(count >= 4 for count in suit_counts.values()) and len(community_cards) < 5
        
        # Check for straight draw
        unique_ranks = sorted(list(set(ranks)))
        has_straight_draw = False
        if len(unique_ranks) >= 4:
            for i in range(len(unique_ranks) - 3):
                if unique_ranks[i+3] - unique_ranks[i] <= 4: # Gap of at most 3 for a 4-card straight draw
                    has_straight_draw = True
                    break
            # Handle aces high/low for straight draws
            if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks: # A234
                has_straight_draw = True
            if 14 in unique_ranks and 13 in unique_ranks and 12 in unique_ranks and 10 in unique_ranks: # JQKA
                has_straight_draw = True

        # Check for pairs, trips, quads
        num_pairs = sum(1 for count in rank_counts.values() if count == 2)
        has_trips = any(count == 3 for count in rank_counts.values())
        has_quads = any(count == 4 for count in rank_counts.values())

        # Simple heuristic for post-flop strength
        strength = 0.0
        if has_quads: strength = 1.0
        elif has_trips and num_pairs >= 1: strength = 0.9 # Full house
        elif any(count >= 5 for count in suit_counts.values()): strength = 0.8 # Flush
        elif self._is_straight(all_cards): strength = 0.7 # Straight
        elif has_trips: strength = 0.6
        elif num_pairs >= 2: strength = 0.5
        elif num_pairs == 1: strength = 0.4
        
        if has_flush_draw and len(community_cards) < 5: strength += 0.15 # Add for draws
        if has_straight_draw and len(community_cards) < 5: strength += 0.1

        return min(strength, 1.0) # Ensure strength does not exceed 1.0
    
    def _is_straight(self, cards: List[str]) -> bool:
        """Helper to check for a straight from a list of cards."""
        ranks = sorted(list(set([self._get_card_rank(c) for c in cards])))
        if len(ranks) < 5:
            return False

        # Check for A-5 straight (A=14, so also check 1,2,3,4,5)
        if 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
            return True
            
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Count active players
        num_active_players = sum(1 for player_id in round_state.current_player if player_id != self.id and player_id in round_state.player_bets and round_state.player_bets[str(player_id)] < remaining_chips + round_state.player_bets.get(str(self.id), 0))
        # This count is tricky. A simpler way is to count players not folded yet.
        # For simplicity, during betting, current_player list gives active players.
        # Subtracting self gives count of opponents.
        num_opponents = len(round_state.current_player) - 1

        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        max_raise_amount = remaining_chips - current_bet_to_match
        min_raise_amount_valid = round_state.min_raise # This is the amount *to add* to current_bet_to_match to meet min raise

        # Adjusted for small blinds and big blinds for pre-flop
        if round_state.round == 'Preflop' and current_bet_to_match == 0:
            if self.id == self.small_blind_player_id:
                current_bet_to_match = self.blind_amount // 2
            elif self.id == self.big_blind_player_id:
                current_bet_to_match = self.blind_amount

            # This assumes that player_bets correctly reflects the blinds already posted.
            # If current_bet_to_match is still 0, implies we are not facing a bet (e.g., small blind when action folds to them for big blind)
            # Or we are big blind already posted and no one raised.
            
            # If current_bet is 0, it means the current round of betting started with no raise,
            # or the action is on BB pre-flop and no one raised.
            # If we need to call, current_bet_to_match will be > 0.
            current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)


        # Determine action based on hand strength and betting round
        if hand_strength >= 0.7:  # Strong hand (e.g., two pair+, good draws)
            if current_bet_to_match == 0: # Can check or bet
                # Aggressive play: Bet out or raise
                raise_amount = max(min_raise_amount_valid, int(round_state.pot * 0.6))
                raise_amount = min(raise_amount, max_raise_amount)
                
                if raise_amount > 0:
                    return (PokerAction.RAISE, current_bet_to_match + raise_amount)
                else: # Only all-in is possible or check
                    return (PokerAction.ALL_IN, 0) if remaining_chips > 0 else (PokerAction.CHECK, 0)
            else: # Need to call or raise
                # Strong hand, always call or raise
                if current_bet_to_match >= remaining_chips: # Opponent all-in or big bet
                    return (PokerAction.ALL_IN, 0)
                
                raise_amount = max(min_raise_amount_valid, int(current_bet_to_match * 2.5)) # Raise more
                raise_amount = min(raise_amount, max_raise_amount)
                
                if raise_amount > 0 and (current_bet_to_match + raise_amount) <= remaining_chips:
                    return (PokerAction.RAISE, current_bet_to_match + raise_amount)
                else:
                    return (PokerAction.CALL, 0) if current_bet_to_match < remaining_chips else (PokerAction.ALL_IN, 0)
        
        elif hand_strength >= 0.4:  # Medium hand (e.g., top pair, good draw)
            if current_bet_to_match == 0: # Can check or bet
                # Check if multi-way pot, bet less aggressively or check
                if num_opponents > 1:
                    return (PokerAction.CHECK, 0)
                else:
                    raise_amount = max(min_raise_amount_valid, int(round_state.pot * 0.3))
                    raise_amount = min(raise_amount, max_raise_amount)
                    if raise_amount > 0:
                        return (PokerAction.RAISE, current_bet_to_match + raise_amount)
                    else: # Can't raise, check if possible, else call 0 which signifies check
                        return (PokerAction.CHECK, 0)
            else: # Need to call or raise
                # If bet is small, call; if large, consider folding or calling cautiously
                if current_bet_to_match <= remaining_chips * 0.15 or current_bet_to_match <= round_state.pot * 0.2: # Call small bets
                    return (PokerAction.CALL, 0)
                elif current_bet_to_match >= remaining_chips * 0.5: # Facing large bet, medium hand, fold
                    return (PokerAction.FOLD, 0)
                else: # Intermediate bet, maybe call
                    return (PokerAction.CALL, 0)
        
        else:  # Weak hand
            if current_bet_to_match == 0: # Can check
                return (PokerAction.CHECK, 0)
            else: # Need to call or fold
                # Only call if bet is minimal (e.g., blinds, or less than 5% of stack)
                if current_bet_to_match <= remaining_chips * 0.05 + self.blind_amount/2: # Tolerate small calls
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # The game engine might provide player's hole cards for the next round in on_start or similar.
        # This function is usually for cleanup or logging.
        # A new hand will be dealt and `on_start` will be called for the new game, or
        # the framework sets `self.hole_cards` internally.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Logic for end of game (e.g., final logging, strategy adjustments for next tournament run)
        pass