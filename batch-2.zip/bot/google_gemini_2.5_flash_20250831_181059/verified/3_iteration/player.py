import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.id)] if str(self.id) in round_state.player_hands else []

    def _get_card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'T':
            return 10
        elif rank == 'J':
            return 11
        elif rank == 'Q':
            return 12
        elif rank == 'K':
            return 13
        elif rank == 'A':
            return 14
        else:
            return int(rank)

    def _evaluate_hand_strength(self, community_cards: List[str]) -> float:
        if not self.hole_cards:
            return 0.0

        all_cards = self.hole_cards + community_cards
        if len(all_cards) < 2:  # Need at least 2 cards to form a hand
            return 0.0

        # Simple hand strength evaluation based on high cards and pairs
        ranks = sorted([self._get_card_rank(card) for card in all_cards], reverse=True)
        suits = [card[1] for card in all_cards]

        # Check for pairs
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        num_pairs = sum(1 for count in rank_counts.values() if count == 2)
        num_trips = sum(1 for count in rank_counts.values() if count == 3)
        num_quads = sum(1 for count in rank_counts.values() if count == 4)

        if num_quads > 0:
            return 1.0  # Four of a kind (very strong)
        elif num_trips > 0 and num_pairs > 0:
            return 0.95  # Full House
        elif num_trips > 0:
            return 0.7  # Three of a kind
        elif num_pairs >= 2:
            return 0.5  # Two pair
        elif num_pairs == 1:
            return 0.25  # One pair
        else:
            # Check for flush draw
            suit_counts = {suit: suits.count(suit) for suit in set(suits)}
            if any(count >= 4 for count in suit_counts.values()):
                return 0.4 # Flush draw or flush

            # Check for straight draw
            if len(ranks) >= 5:
                unique_ranks = sorted(list(set(ranks)))
                for i in range(len(unique_ranks) - 4):
                    if unique_ranks[i+4] - unique_ranks[i] == 4:
                        return 0.6 # Straight

            # High card
            return ranks[0] / 14.0 # Normalize high card strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        hand_strength = self._evaluate_hand_strength(round_state.community_cards)

        # Pre-Flop Strategy
        if round_state.round == 'PREFLOP':
            # Aggressive with strong hands
            if hand_strength >= 0.7:  # Premium hands (AA, KK, QQ, AKs, etc. based on initial 2 cards)
                if current_bet_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, max_raise, min_raise * 3)
                else:
                    return PokerAction.RAISE, min(remaining_chips, max_raise, current_bet_to_call + min_raise * 2) # Re-raise
            # Call with decent hands or raise if no bet
            elif hand_strength >= 0.4: # Medium strength hands (pairs, suited connectors, high cards)
                if current_bet_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, max_raise, min_raise * 2)
                elif current_bet_to_call <= remaining_chips / 10: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0 # Fold to large bets
            # Fold or check/call if blinds
            else: # Weak hands
                if current_bet_to_call == 0:
                    return PokerAction.CHECK, 0 # Check if no bet
                elif current_bet_to_call < self.blind_amount: # Call small blind from Big Blind position
                     return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-Flop Strategy (Flop, Turn, River)
        elif round_state.round in ['FLOP', 'TURN', 'RIVER']:
            # All-in with very strong hands
            if hand_strength >= 0.8: # Very strong hands (e.g., set, straight, flush, full house, quads)
                return PokerAction.ALL_IN, 0
            # Raise with strong hands
            elif hand_strength >= 0.6: # Strong hands (e.g., top pair, strong draw)
                if current_bet_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, max_raise, min_raise * 2)
                else:
                    return PokerAction.RAISE, min(remaining_chips, max_raise, current_bet_to_call + min_raise)
            # Call with medium hands
            elif hand_strength >= 0.3: # Medium strength hands (e.g., middle pair, good draw)
                if current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_call <= remaining_chips / 5: # Call reasonable bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Fold with weak hands
            else: # Weak hands (e.g., high card, no draw)
                if current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Fallback for unexpected scenarios
        if current_bet_to_call == 0:
            return PokerAction.CHECK, 0
        elif current_bet_to_call < remaining_chips:
            return PokerAction.CALL, 0
        else:
            return PokerAction.ALL_IN, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass