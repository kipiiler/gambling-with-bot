import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # The player_hands in on_start is for initial distribution, actual hole cards are not passed this way.
        # We need to assume the bot knows its own hole cards implicitly.
        # For this simple bot, we'll store the hole cards when they are 'dealt' in get_action's first call if needed.
        # However, the problem description implies a bot can know its player_id and implicitly its cards.
        # Since on_round_start does not provide hole cards, we can only react to community cards and betting.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Determine the current player's bet relative to the round's current bet
        my_current_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet_in_round

        # Basic strategy:
        # 1. Pre-flop: Small Blind, Big Blind, Call, or Fold based on position
        # 2. Post-flop: Check, Call, or Fold based on conservative play

        if round_state.round == 'Preflop':
            if amount_to_call == 0:  # Player is BB or everyone checked to them
                # Check if possible, otherwise small bet
                # If current_bet is 0, we can check. This implies we are the Big Blind or button and previous players folded/called the BB.
                return (PokerAction.CHECK, 0) # Check if no bet
            elif amount_to_call < remaining_chips / 5: # Call small bets
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, amount_to_call)
                else:
                    return (PokerAction.ALL_IN, 0)
            else: # Large bet relative to stack, or we need to put in a lot
                # Aggressive play might be to call if pot odds are good, but for a simple bot, fold
                return (PokerAction.FOLD, 0)
        else: # Flop, Turn, River
            if amount_to_call == 0:
                # If no one bet, check
                return (PokerAction.CHECK, 0)
            else:
                # If there's a bet, call if it's less than 1/4 of remaining chips or 1/10 of pot, otherwise fold
                # This is a very conservative strategy to avoid losing too much
                # Calculate pot odds (simplified for this bot)
                pot_size = round_state.pot
                if remaining_chips > 0: # Avoid division by zero
                    # If amount to call is reasonable (e.g., less than 10% of our stack and less than 20% of pot)
                    if amount_to_call <= remaining_chips and \
                       (amount_to_call < remaining_chips * 0.15 + 1e-9 or \
                        amount_to_call < pot_size * 0.2 + 1e-9): # Add small delta for float comparison safety
                        return (PokerAction.CALL, amount_to_call)
                    elif amount_to_call >= remaining_chips: # If call amount is effectively all-in
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else: # No chips left (shouldn't happen for get_action, but as a safeguard)
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any per-round data if necessary
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game has ended. No action needed for this simple bot.
        pass