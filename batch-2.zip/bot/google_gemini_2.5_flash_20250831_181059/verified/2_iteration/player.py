from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.initial_chips = 0
        self.player_id_str = "" # Stores player ID as string for player_bets/actions dicts

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_chips = starting_chips
        # player_hands is a list of strings like ['Ah', 'Ks']
        # We need to store our own hole cards. player_hands is for *this* player.
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_id_str = str(self.id) # Convert to string for dictionary keys

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # The hole cards are dealt once at the start of the game (in on_start),
        # but they aren't reset by the server for each round. `on_start` is called only once per game.
        # We need to update our hole cards here, if they change per round,
        # but the provided `player_hands` in `on_start` is *that specific player's* hands.
        # Let's assume `on_start` gives us the correct hole cards for the *first* round.
        # For subsequent rounds, the game framework should implicitly deal new hands,
        # and we would ideally get them via the `round_state` or a separate `on_deal_cards` callback.
        # The problem description says `player_hands` is passed in `on_start` which implies it's for the first game.
        # However, looking at the `RoundStateClient` definition, there's no `player_hands`.
        # This implies our bot needs an internal mechanism to know its current hole cards for the round.
        # For now, I will assume the server will pass valid hole cards to `on_round_start` or `get_action`
        # if the bot needs to know them, or manage them internally.
        # Since `player_hands` is *only* in `on_start`, for subsequent hands, the bot needs to be able to
        # understand its hole cards implicitly or they will be empty.
        # Given the previous performance, the bot needs a way to evaluate its preflop hand.
        # This is typically done by storing `hole_cards` given during card distribution.
        # I am going to make a crucial assumption: `player_hands` in `on_start` is indeed *our* hole cards for the *first* game.
        # For subsequent games, the server *must* have a mechanism to tell us our new hole cards.
        # If not, the bot will play blind after the first game.
        # A common pattern is `on_round_start` to pass `my_cards` or similar. Since it's not there,
        # and `RoundStateClient` doesn't have it either, I need to assume the bot receives
        # its *own* cards dynamically via some internal game state update mechanism that isn't exposed.
        # For a basic bot, let's keep the `self.hole_cards` from `on_start` as a placeholder,
        # but acknowledge it's a potential blind spot for multi-round games if cards aren't re-dealt.

        # Looking at `PlayerHands` in the game state, this indicates the server *does* show player hands at the END of the game.
        # This means, for evaluation *during* a round, the bot is expected to know its own cards.
        # The most reliable way for me as bot developer to know *my* cards is storing them from `on_start`.
        # But this is only for the *first* game within a `on_start` context.
        # If `on_start` is called *per game* (as typically happens in tournaments), then `player_hands` is refreshed.
        # The description says "simulations run for n games ... blinds rotate and increase every n games".
        # This implies `on_start` is called for the *entire simulation*, not per game.
        # If so, `player_hands` is fixed. This is unlikely for a poker game.

        # RE-EVALUATION: The example `player_hands` is given by the server for `on_end_game`.
        # It's highly probable the `player_hands` argument in `on_start` is for *our* initial hand.
        # Let's assume for now that `player_hands` is indeed our two hole cards for the current game.
        # If `on_start` is called only once for the whole simulation, then `self.hole_cards` will be static.
        # If `on_start` is called per *game*, then it makes sense. The current system seems to imply a single `on_start`.

        # Okay, a simpler approach: use a placeholder for hand evaluation.
        # The previous iteration did not distinguish between strong/weak hands. This is a major flaw.
        # For iteration 2, let's add *very basic* preflop hand strength.

        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_current_bet = round_state.player_bets.get(self.player_id_str, 0)
        amount_to_call = round_state.current_bet - my_current_bet
        can_check = round_state.current_bet == my_current_bet

        # Basic hand strength evaluation (Preflop only, as community cards are not always available)
        # Assuming self.hole_cards are updated by the system if on_start is only called once.
        # If `on_start` gives fresh hands per game, then this is fine.
        # Given `RoundStateClient` doesn't contain hole cards, it MUST be passed to the bot via an `on_deal` or similar,
        # or the bot expects to manage them internally (unlikely for a generic competition).
        # For competitive bots, they usually receive their hand explicitly each round.
        # Lacking explicit hole cards in `RoundStateClient` and `on_round_start`,
        # the `player_hands` from `on_start` becomes the only source.
        # This is a critical ambiguity. For now, I will use a dummy "hand strength" if `self.hole_cards` is empty.
        # If `self.hole_cards` is populated (assuming it is correctly updated by the environment), then use it.

        # **Correction**: The problem statement explicitly says `on_start(..., player_hands: List[str], ...)`.
        # This `player_hands` is *our* initial hole cards. If `on_start` is called only once per simulation, this is a fixed hand.
        # This would be a very strange poker game. Most likely, a `game` = `round` in this context,
        # and `on_start` *is* called per game. Let's make that assumption.
        # This means `self.hole_cards` correctly holds our current hand.

        hand_strength = self._evaluate_hand_strength_preflop(self.hole_cards)

        # Aggressive values for calling/raising
        bluff_threshold = 0.2 # Chance to bluff
        weak_hand_call_threshold = 0.05 # For calling small bets with weak hands
        medium_hand_raise_factor = 2 # Raise 2x current bet with medium hands
        strong_hand_raise_factor = 3 # Raise 3x current bet with strong hands

        # Define thresholds for hand strength to classify them
        VERY_STRONG_HAND = 0.8
        STRONG_HAND = 0.6
        MEDIUM_HAND = 0.3
        WEAK_HAND = 0.1

        # Current betting round
        current_round = round_state.round

        # Player's position (simplified: if player is small/big blind, or else)
        is_small_blind = (self.id == self.small_blind_player_id)
        is_big_blind = (self.id == self.big_blind_player_id)
        is_preflop_blind = is_small_blind or is_big_blind

        # Strategy based on hand strength and betting round
        if current_round == 'Preflop':
            if hand_strength >= VERY_STRONG_HAND:
                # Always raise aggressively with very strong hands
                raise_amount = min(round_state.max_raise, round_state.min_raise * strong_hand_raise_factor)
                if raise_amount > amount_to_call: # Only raise if it's a valid raise
                    return PokerAction.RAISE, raise_amount
                elif amount_to_call > 0: # If we cannot raise, but need to call
                    return PokerAction.CALL, 0
                else: # If we can check and have a very strong hand, check to induce action
                    return PokerAction.CHECK, 0
            elif hand_strength >= STRONG_HAND:
                # Raise with strong hands
                raise_amount = min(round_state.max_raise, round_state.min_raise * medium_hand_raise_factor)
                if raise_amount > amount_to_call:
                     return PokerAction.RAISE, raise_amount
                elif amount_to_call > 0: # If cannot raise, but need to call
                    return PokerAction.CALL, 0
                else: # If we can check
                    return PokerAction.CHECK, 0
            elif hand_strength >= MEDIUM_HAND:
                # Call or small raise with medium hands, sometimes fold to large raises
                if amount_to_call > remaining_chips * 0.15 and not is_preflop_blind: # Don't commit too much with medium hands
                    return PokerAction.FOLD, 0
                elif amount_to_call > 0:
                    return PokerAction.CALL, 0
                else:
                    # If we can check, do it. (Could also do a small bet to test, but let's be conservative)
                    return PokerAction.CHECK, 0
            else: # Weak hands
                # Only call if amount is very small (e.g., blinds), otherwise fold or check
                if can_check:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= self.blind_amount or (amount_to_call <= remaining_chips * weak_hand_call_threshold and is_preflop_blind):
                    return PokerAction.CALL, 0
                else:
                    # Sometimes bluff, but usually fold
                    if random.random() < bluff_threshold and remaining_chips > round_state.min_raise:
                        raise_amount = min(round_state.max_raise, round_state.min_raise) # Minimum raise as a bluff
                        if raise_amount > amount_to_call:
                            return PokerAction.RAISE, raise_amount
                    return PokerAction.FOLD, 0

        else: # Flop, Turn, River - More speculative, rely less on preflop hand strength alone
              # For simplicity, let's have a more conservative post-flop strategy without full board evaluation.
              # A real bot would integrate community cards.
            if hand_strength >= STRONG_HAND: # Still strong based on pre-flop (assuming some consistency)
                if amount_to_call > 0:
                    raise_amount = min(round_state.max_raise, amount_to_call + self.blind_amount * 2) # Small raise to build pot
                    if raise_amount > amount_to_call:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CALL, 0
                else:
                    # If able to check with strong hand, bet to build pot or check to induce call
                    # Let's bet a reasonable amount if no bet currently
                    bet_amount = round_state.pot // (len(round_state.current_player) + 1) # Bet ~1/3 of pot
                    if bet_amount == 0 and can_check: bet_amount = self.blind_amount # If pot is 0, just bet big blind
                    if bet_amount > 0 and bet_amount < remaining_chips:
                        return PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, bet_amount)) # Technically a raise if current bet is 0
                    else:
                        return PokerAction.CHECK, 0
            elif hand_strength >= MEDIUM_HAND:
                if can_check:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips * 0.1: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hands post-flop
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Default fallback (should ideally not be reached if logic is complete)
        # If all else fails, fold to prevent errors
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round if on_start is not called per round
        # However, given `player_hands` in `on_start`, the most logical setup for a competition is:
        # `on_start` is called for each *game* simulation, and `player_hands` contains the cards for that game.
        # If not, the bot would have to infer its cards or rely on external information not provided.
        # So, no explicit reset here, assuming `on_start` will provide fresh hand for new game.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No specific action needed here for basic bot logic
        pass

    def _evaluate_hand_strength_preflop(self, cards: List[str]) -> float:
        """
        Evaluates the pre-flop hand strength.
        Returns a float between 0.0 (weakest) and 1.0 (strongest).
        This is a very simplistic heuristic. A real bot would use a pre-calculated equity table.
        """
        if not cards or len(cards) != 2:
            return 0.0 # Cannot evaluate without two cards

        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        card1_rank = rank_map[cards[0][0]]
        card1_suit = cards[0][1]
        card2_rank = rank_map[cards[1][0]]
        card2_suit = cards[1][1]

        strength = 0.0

        # Pair strength
        if card1_rank == card2_rank:
            if card1_rank >= 12: # AA, KK, QQ
                strength = 0.95
            elif card1_rank >= 10: # JJ, TT
                strength = 0.85
            else: # Other pairs
                strength = 0.7 + (card1_rank / 14) * 0.25 # Scales with rank

        # Suited connectors/high cards
        elif card1_suit == card2_suit: # Suited
            if card1_rank >= 10 and card2_rank >= 10: # Suited Broadway (e.g., AKs, QJs)
                strength = 0.75 + (max(card1_rank, card2_rank) / 14) * 0.1
            elif abs(card1_rank - card2_rank) <= 1: # Suited connectors (e.g., 87s, T9s)
                strength = 0.6 + (max(card1_rank, card2_rank) / 14) * 0.15
            elif max(card1_rank, card2_rank) >= 12: # Suited Ace/King with smaller card
                strength = 0.5 + (max(card1_rank, card2_rank) / 14) * 0.2

        # Off-suited high cards
        else: # Off-suited
            if card1_rank >= 12 and card2_rank >= 12: # Two high cards (e.g., AKo, KQo)
                strength = 0.65 + (max(card1_rank, card2_rank) / 14) * 0.1
            elif (card1_rank >= 10 and card2_rank >= 7) or (card2_rank >= 10 and card1_rank >= 7): # High card with medium kicker
                strength = 0.4 + (max(card1_rank, card2_rank) / 14) * 0.2
            elif max(card1_rank, card2_rank) >= 10: # One Broadway card
                strength = 0.3 + (max(card1_rank, card2_rank) / 14) * 0.1

        # Adjust for small unsuited, unconnected cards (garbage hands)
        if strength < 0.1 and max(card1_rank, card2_rank) < 9 and abs(card1_rank - card2_rank) > 2:
            strength = 0.05 # Very weak

        return min(strength, 1.0) # Ensure it doesn't exceed 1.0