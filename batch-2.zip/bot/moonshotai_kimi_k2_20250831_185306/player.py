from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength = 0.0
        self.position = 0
        self.num_players = 0
        self.tight_aggressive = False
        self.bluff_frequency = 0.0
        self.pot_odds = 0.0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.my_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind = big_blind_player_id
        self.small_blind = small_blind_player_id
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        card_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        suits = {'h':0, 'c':1, 'd':2, 's':3}
        
        all_cards = hole_cards + community_cards
        values = [card_values[card[0]] for card in all_cards]
        suits_count = [0] * 4
        for card in all_cards:
            suits_count[suits[card[1]]] += 1
            
        value_counts = {}
        for v in values:
            value_counts[v] = value_counts.get(v, 0) + 1
            
        pairs = sum(1 for count in value_counts.values() if count == 2)
        trips = sum(1 for count in value_counts.values() if count == 3)
        quads = sum(1 for count in value_counts.values() if count == 4)
        
        flush = any(count >= 5 for count in suits_count)
        
        sorted_values = sorted(set(values))
        straight = False
        if len(sorted_values) >= 5:
            for i in range(len(sorted_values) - 4):
                if sorted_values[i+4] - sorted_values[i] == 4:
                    straight = True
                    break
                    
        strength = 0.0
        if quads:
            strength = 8.0
        elif trips and pairs >= 1:
            strength = 7.0
        elif flush and straight:
            strength = 9.0
        elif flush:
            strength = 5.0
        elif straight:
            strength = 4.0
        elif trips:
            strength = 3.0
        elif pairs == 2:
            strength = 2.0
        elif pairs == 1:
            strength = 1.0
        else:
            strength = 0.5
            
        if strength < 1.0 and len(community_cards) == 0:
            card1, card2 = hole_cards
            val1 = card_values[card1[0]]
            val2 = card_values[card2[0]]
            same_suit = card1[1] == card2[1]
            
            if val1 >= 10 and val2 >= 10:
                strength += 0.3
            elif abs(val1 - val2) <= 4:
                strength += 0.2
            if same_suit:
                strength += 0.1
                
        return strength
        
    def calculate_pot_odds(self, call_amount: int, pot: int) -> float:
        if call_amount + pot == 0:
            return 0.0
        return call_amount / (call_amount + pot)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.my_cards
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        pot = round_state.pot
        
        strength = self.evaluate_hand_strength(hole_cards, community_cards)
        
        call_amount = max(0, current_bet - (round_state.player_bets.get(str(self.id), 0) if str(self.id) in round_state.player_bets else 0))
        pot_odds = self.calculate_pot_odds(call_amount, pot)
        
        if strength > 8.0:
            if remaining_chips > 0:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CALL, 0)
                
        elif strength > 6.0:
            raise_amount = min(remaining_chips, max(round_state.min_raise, int(pot * 0.75)))
            if raise_amount > 0 and raise_amount > current_bet:
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips and pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif strength > 3.0:
            if round_state.round == "Preflop" and strength > 4.5:
                raise_amount = min(remaining_chips, max(round_state.min_raise, int(pot * 0.5)))
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
                    
            if call_amount <= remaining_chips:
                if pot_odds < 0.25 or (round_state.round in ["Flop", "Turn"] and strength > 4):
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        else:
            if round_state.round == "Preflop" and len(community_cards) == 0:
                card1, card2 = hole_cards
                val1 = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}[card1[0]]
                val2 = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}[card2[0]]
                
                if (val1 >= 12 or val2 >= 12) and abs(val1 - val2) <= 2:
                    if call_amount <= int(0.15 * remaining_chips) and current_bet <= 100:
                        return (PokerAction.CALL, 0)
                    elif remaining_chips > 0 and round_state.current_bet <= 50:
                        raise_amount = min(remaining_chips, max(round_state.min_raise, 50))
                        return (PokerAction.RAISE, raise_amount)
                        
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= int(0.1 * remaining_chips) and pot_odds < 0.15 and round_state.round in ["Flop", "Turn"]:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass