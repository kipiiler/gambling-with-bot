from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.position_history = []
        self.aggression_factor = 1.0
        self.tightness = 0.7
        self.bluff_frequency = 0.15
        self.stage_factors = {
            'Preflop': 1.0,
            'Flop': 1.2,
            'Turn': 1.3,
            'River': 1.5
        }
        self.opponent_tendencies = {}
        self.hand_strength_cache = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.num_players = len(all_players)
        
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_tendencies[str(player_id)] = {
                    'vpip': 0.0,
                    'aggression': 1.0,
                    'hands_seen': 0,
                    'total_actions': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips
        
        # Update opponent tendencies based on actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_tendencies:
                self.opponent_tendencies[player_id]['total_actions'] += 1
                if action in ['Call', 'Raise', 'All-in']:
                    self.opponent_tendencies[player_id]['vpip'] += 1
        
        # Calculate position relative to button
        button_pos = (self.big_blind_player_id - 1) % self.num_players
        current_pos = (round_state.current_player[0] - button_pos) % self.num_players
        self.position = current_pos

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get hole cards from player_hands (correctly)
            hole_cards = self.hole_cards if hasattr(self, 'hole_cards') else []
            
            # Calculate hand strength
            hand_strength = self._calculate_hand_strength(round_state, hole_cards)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Adjust strategy based on position and opponents
            adjusted_strength = self._adjust_strategy(hand_strength, pot_odds, round_state, remaining_chips)
            
            # Determine action
            action = self._determine_action(adjusted_strength, round_state, remaining_chips)
            
            return action
            
        except Exception as e:
            # Fallback to conservative play
            if round_state.current_bet > 0:
                if remaining_chips > round_state.current_bet:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update tracking variables
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict):
        # Reset for new game
        self.hole_cards = []

    def _calculate_hand_strength(self, round_state: RoundStateClient, hole_cards: List[str]) -> float:
        """Calculate relative hand strength (0-1 scale)"""
        if not hole_cards and hasattr(self, 'hole_cards'):
            hole_cards = self.hole_cards
        
        if not hole_cards:
            return 0.5
            
        # Simple preflop hand ranking
        if round_state.round == 'Preflop':
            return self._preflop_strength(hole_cards)
        
        # Post-flop strength estimation
        return self._postflop_strength(hole_cards, round_state.community_cards)

    def _preflop_strength(self, hole_cards: List[str]) -> float:
        """Calculate preflop hand strength"""
        if len(hole_cards) != 2:
            return 0.5
            
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                 '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        card1, card2 = hole_cards
        rank1 = ranks[card1[0]]
        rank2 = ranks[card2[0]]
        suited = card1[1] == card2[1]
        
        # Pair
        if rank1 == rank2:
            strength = min(rank1 / 14 * 0.8 + 0.2, 0.95)
        # Suited connectors
        elif suited and abs(rank1 - rank2) <= 2:
            strength = min(0.6 + (14 - abs(rank1 - rank2)) * 0.05, 0.85)
        # High cards
        else:
            strength = max(rank1, rank2) / 14 * 0.6
            
        return strength

    def _postflop_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate post-flop hand strength"""
        if not community_cards:
            return 0.5
            
        # Simple made hand detection
        all_cards = hole_cards + community_cards
        
        # Check for pairs, sets, etc.
        ranks = [card[0] for card in all_cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        max_count = max(rank_counts.values())
        if max_count >= 3:
            return 0.8
        elif max_count == 2:
            return 0.6
        else:
            return 0.3

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds as a percentage"""
        if round_state.current_bet <= 0:
            return 1.0
            
        call_amount = min(round_state.current_bet, remaining_chips)
        pot_size = round_state.pot
        
        if call_amount + pot_size == 0:
            return 0.0
            
        return call_amount / (call_amount + pot_size)

    def _adjust_strategy(self, hand_strength: float, pot_odds: float, 
                        round_state: RoundStateClient, remaining_chips: int) -> float:
        """Adjust strategy based on position, opponents, and game state"""
        
        # Position adjustment
        position_factor = 1.0
        if self.position <= 2:  # Early position
            position_factor = 0.8
        elif self.position >= self.num_players - 2:  # Late position
            position_factor = 1.2
            
        # Stack size adjustment
        stack_factor = min(1.5, remaining_chips / (self.starting_chips + 1e-6))
        
        # Round adjustment
        round_factor = self.stage_factors.get(round_state.round, 1.0)
        
        # Opponent adjustment
        opponent_factor = 1.0
        for player_id, tendencies in self.opponent_tendencies.items():
            if tendencies['total_actions'] > 0:
                avg_vpip = tendencies['vpip'] / tendencies['total_actions']
                if avg_vpip > 0.5:  # Loose players
                    opponent_factor *= 1.1
                else:  # Tight players
                    opponent_factor *= 0.9
        
        adjusted_strength = hand_strength * position_factor * stack_factor * round_factor * opponent_factor
        
        return min(adjusted_strength, 1.0)

    def _determine_action(self, adjusted_strength: float, round_state: RoundStateClient, 
                         remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine the best action based on adjusted hand strength"""
        
        # Calculate thresholds
        fold_threshold = 0.3
        call_threshold = 0.5
        raise_threshold = 0.7
        
        # Add randomness for deception
        random_factor = random.uniform(-0.1, 0.1)
        adjusted_strength += random_factor
        
        # Current situation
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Decision logic
        if adjusted_strength < fold_threshold:
            if current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif adjusted_strength < call_threshold:
            if current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif current_bet <= remaining_chips:
                # Sometimes call with marginal hands
                if random.random() < 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif adjusted_strength < raise_threshold:
            if current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif current_bet <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
                
        else:
            # Strong hand - raise or bet
            if current_bet == 0:
                # Bet sizing
                bet_size = min(max_raise, max(min_raise, int(remaining_chips * 0.5)))
                return (PokerAction.RAISE, bet_size)
            else:
                # Raise sizing
                raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.75)))
                return (PokerAction.RAISE, raise_amount)