from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength_cache = {}
        self.aggression_factor = 1.5
        self.tightness = 0.7
        self.position_factor = 1.0
        self.stack_size_factor = 1.0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        self.position = 0
        self.hands_played = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.current_round = round_state.round
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = round_state.player_hands.get(str(self.id), [])
        if not hole_cards:
            return (PokerAction.FOLD, 0)
            
        current_bet = round_state.current_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(hole_cards, round_state.community_cards)
        
        # Position-based adjustment
        position = self.calculate_position(round_state)
        position_multiplier = 1.0 + (position * 0.2)
        
        # Stack size adjustment
        stack_ratio = remaining_chips / max(pot, 1)
        if stack_ratio > 10:
            stack_multiplier = 1.2
        elif stack_ratio < 5:
            stack_multiplier = 0.8
        else:
            stack_multiplier = 1.0
            
        # Adjusted hand strength
        adjusted_strength = hand_strength * position_multiplier * stack_multiplier
        
        # Determine action based on strength and situation
        if current_bet == 0:
            # No bet to call
            if adjusted_strength > 0.7:
                raise_amount = min(max(int(pot * 0.75), min_raise), max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength > 0.5:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Need to respond to bet
            call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
            pot_odds = call_amount / (pot + call_amount + 1e-6)
            
            if adjusted_strength > 0.8:
                raise_amount = min(max(int(pot * 1.2), min_raise), max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength > pot_odds + 0.1:
                if adjusted_strength > 0.6 and remaining_chips > call_amount * 3:
                    raise_amount = min(max(int(pot * 0.5), min_raise), max_raise)
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            else:
                if remaining_chips < call_amount * 2 and adjusted_strength > 0.3:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0
            
        # Simple hand strength evaluation
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        hole_ranks = [card[0] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Premium pairs
        if hole_ranks[0] == hole_ranks[1]:
            rank = rank_values[hole_ranks[0]]
            if rank >= 10:
                return 0.9
            elif rank >= 7:
                return 0.7
            else:
                return 0.5
                
        # Suited connectors
        if hole_suits[0] == hole_suits[1]:
            rank_diff = abs(rank_values[hole_ranks[0]] - rank_values[hole_ranks[1]])
            if rank_diff <= 2:
                min_rank = min(rank_values[hole_ranks[0]], rank_values[hole_ranks[1]])
                if min_rank >= 10:
                    return 0.8
                elif min_rank >= 8:
                    return 0.6
                else:
                    return 0.4
            else:
                return 0.3
                
        # High cards
        max_rank = max(rank_values[hole_ranks[0]], rank_values[hole_ranks[1]])
        if max_rank >= 12:
            return 0.4
        elif max_rank >= 10:
            return 0.3
        else:
            return 0.2
            
    def calculate_position(self, round_state: RoundStateClient) -> float:
        players = list(round_state.player_bets.keys())
        if str(self.id) not in players:
            return 0.5
            
        position = players.index(str(self.id)) / max(len(players), 1)
        return position