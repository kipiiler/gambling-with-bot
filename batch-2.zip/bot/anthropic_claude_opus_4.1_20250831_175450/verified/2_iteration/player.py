from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.starting_chips = 0
        self.game_count = 0
        self.total_games = 0
        self.opponent_stats = {}  # Track opponent behavior
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.game_count += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_stats:
                self.opponent_stats[player_id] = {
                    'folds': 0,
                    'calls': 0,
                    'raises': 0,
                    'checks': 0,
                    'total_actions': 0
                }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Track opponent actions
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Determine position (are we acting first or last?)
        is_last_to_act = self._is_last_to_act(round_state)
        
        # Get current betting situation
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, round_state.current_bet - my_current_bet)
        
        # Calculate minimum valid raise amount
        min_raise_amount = max(round_state.min_raise, 2 * round_state.current_bet - my_current_bet)
        
        # Aggressive preflop strategy
        if round_state.round == 'Preflop':
            if hand_strength >= 0.8:  # Premium hands (AA, KK, QQ, AK)
                if amount_to_call == 0:
                    # No one has bet, make a strong bet
                    raise_amount = min(3 * self.blind_amount, remaining_chips)
                    if raise_amount >= min_raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.ALL_IN, 0)
                elif amount_to_call < remaining_chips * 0.3:
                    # Re-raise with premium hands
                    raise_amount = min(3 * amount_to_call, remaining_chips)
                    if raise_amount >= min_raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
            
            elif hand_strength >= 0.6:  # Good hands
                if amount_to_call == 0:
                    raise_amount = min(2 * self.blind_amount, remaining_chips)
                    if raise_amount >= min_raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                elif amount_to_call <= self.blind_amount * 2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            elif hand_strength >= 0.4:  # Decent hands
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif amount_to_call <= self.blind_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            else:  # Weak hands
                if amount_to_call == 0:
                    # Occasional bluff
                    if self.game_count % 5 == 0:
                        raise_amount = min(self.blind_amount, remaining_chips)
                        if raise_amount >= min_raise_amount:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            # Adjust strategy based on community cards
            if hand_strength >= 0.75:  # Very strong hand
                if amount_to_call == 0:
                    # Value bet
                    bet_size = min(round_state.pot * 0.75, remaining_chips)
                    if bet_size >= min_raise_amount:
                        return (PokerAction.RAISE, int(bet_size))
                    return (PokerAction.CHECK, 0)
                else:
                    # Raise or call with strong hands
                    if amount_to_call < remaining_chips * 0.5:
                        raise_amount = min(2 * amount_to_call, remaining_chips)
                        if raise_amount >= min_raise_amount and raise_amount <= remaining_chips:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
            
            elif hand_strength >= 0.5:  # Medium strength
                if amount_to_call == 0:
                    # Sometimes bet for value/protection
                    if is_last_to_act or round_state.round == 'River':
                        return (PokerAction.CHECK, 0)
                    bet_size = min(round_state.pot * 0.5, remaining_chips)
                    if bet_size >= min_raise_amount:
                        return (PokerAction.RAISE, int(bet_size))
                    return (PokerAction.CHECK, 0)
                elif pot_odds > 2:  # Good pot odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            else:  # Weak hand
                if amount_to_call == 0:
                    # Check or occasional bluff
                    if round_state.round == 'River' and is_last_to_act:
                        # River bluff occasionally
                        if self.game_count % 7 == 0:
                            bluff_size = min(round_state.pot * 0.6, remaining_chips)
                            if bluff_size >= min_raise_amount:
                                return (PokerAction.RAISE, int(bluff_size))
                    return (PokerAction.CHECK, 0)
                else:
                    # Only call with very good pot odds
                    if pot_odds > 4 and amount_to_call < remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.total_games += 1
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)."""
        if not self.hole_cards:
            return 0.5
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Card rank values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                      '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        
        rank1_val = rank_values.get(rank1, 2)
        rank2_val = rank_values.get(rank2, 2)
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1_val >= 12:  # QQ+
                    return 0.95
                elif rank1_val >= 10:  # TT-JJ
                    return 0.8
                elif rank1_val >= 7:  # 77-99
                    return 0.65
                else:  # 22-66
                    return 0.55
            
            # Suited hands
            suited = (suit1 == suit2)
            high_card = max(rank1_val, rank2_val)
            low_card = min(rank1_val, rank2_val)
            gap = high_card - low_card
            
            # High cards
            if high_card == 14:  # Ace high
                if low_card >= 13:  # AK
                    return 0.85 if suited else 0.8
                elif low_card >= 12:  # AQ
                    return 0.75 if suited else 0.7
                elif low_card >= 11:  # AJ
                    return 0.7 if suited else 0.65
                elif low_card >= 10:  # AT
                    return 0.65 if suited else 0.6
                else:
                    return 0.5 if suited else 0.45
            
            # Broadway cards
            if high_card >= 12 and low_card >= 10:
                return 0.65 if suited else 0.6
            
            # Suited connectors
            if suited and gap == 1:
                if high_card >= 10:
                    return 0.6
                elif high_card >= 7:
                    return 0.5
                else:
                    return 0.4
            
            # Default
            base_strength = (high_card + low_card) / 28.0
            if suited:
                base_strength += 0.05
            if gap <= 2:
                base_strength += 0.05
            
            return min(base_strength, 0.9)
        
        # Post-flop evaluation (simplified)
        else:
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for pairs, trips, etc.
            ranks = [card[0] for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_count = max(rank_counts.values())
            
            # Check for flush
            suits = [card[1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            has_flush = max(suit_counts.values()) >= 5
            
            # Check for straight
            rank_vals = sorted([rank_values.get(r, 2) for r in ranks])
            has_straight = False
            for i in range(len(rank_vals) - 4):
                if rank_vals[i+4] - rank_vals[i] == 4:
                    has_straight = True
                    break
            
            # Assign strength based on hand type
            if has_flush and has_straight:
                return 0.95
            elif max_count == 4:  # Four of a kind
                return 0.93
            elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Full house
                return 0.9
            elif has_flush:
                return 0.85
            elif has_straight:
                return 0.8
            elif max_count == 3:  # Three of a kind
                return 0.75
            elif len([c for c in rank_counts.values() if c == 2]) >= 2:  # Two pair
                return 0.65
            elif max_count == 2:  # One pair
                # Check if we have the pair
                for rank in self.hole_cards:
                    if rank_counts[rank[0]] == 2:
                        return 0.55
                return 0.45
            else:  # High card
                hole_ranks = [rank_values.get(card[0], 2) for card in self.hole_cards]
                if max(hole_ranks) >= 12:
                    return 0.35
                return 0.25
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds."""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, round_state.current_bet - my_current_bet)
        
        if amount_to_call == 0:
            return float('inf')
        
        total_pot = round_state.pot + amount_to_call
        return total_pot / (amount_to_call + 0.001)  # Avoid division by zero
    
    def _is_last_to_act(self, round_state: RoundStateClient) -> bool:
        """Check if we're last to act in this betting round."""
        # Simplified check - in heads-up, we're last if we're not first
        active_players = [p for p in round_state.current_player]
        if len(active_players) <= 2:
            # In heads-up, big blind acts last post-flop
            return len(round_state.player_actions) > 0
        return False
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics based on their actions."""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                stats['total_actions'] += 1
                
                if 'Fold' in action:
                    stats['folds'] += 1
                elif 'Call' in action:
                    stats['calls'] += 1
                elif 'Raise' in action or 'All' in action:
                    stats['raises'] += 1
                elif 'Check' in action:
                    stats['checks'] += 1