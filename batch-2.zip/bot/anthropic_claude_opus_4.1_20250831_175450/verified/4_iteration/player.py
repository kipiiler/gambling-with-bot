from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.num_players = 0
        self.position_aggression_multiplier = 1.0
        self.hand_history = []
        self.opponent_stats = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        self.opponent_stats = {pid: {'vpip': 0, 'pfr': 0, 'hands': 0, 'aggression': 0} for pid in all_players if pid != self.id}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.position_aggression_multiplier = 1.0
        if self.num_players <= 3:
            self.position_aggression_multiplier = 1.3
            
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Update opponent statistics
            self._update_opponent_stats(round_state)
            
            # Calculate pot odds
            pot = round_state.pot
            to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = to_call / (pot + to_call + 0.001)
            
            # Get hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Adjust strategy based on round
            if round_state.round == 'Preflop':
                return self._preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, to_call)
            else:
                return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, to_call)
                
        except Exception as e:
            # Safe fallback - check or fold
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)
            
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Track opponent playing patterns"""
        for pid, action in round_state.player_actions.items():
            if pid != str(self.id) and pid in self.opponent_stats:
                if action in ['Raise', 'Call', 'All_in']:
                    self.opponent_stats[pid]['aggression'] += 1
                    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength using simple heuristics"""
        if len(self.hand_cards) < 2:
            return 0.0
            
        c1, c2 = self.hand_cards[0], self.hand_cards[1]
        rank1, rank2 = self._card_rank(c1), self._card_rank(c2)
        suited = c1[-1] == c2[-1]
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Premium hands
            if (rank1 >= 12 and rank2 >= 12):  # QQ+, AK
                return 0.95
            if (rank1 >= 11 and rank2 >= 11):  # JJ+, AQ
                return 0.85
            if (rank1 >= 10 and rank2 >= 10):  # TT+, AJ, KQ
                return 0.75
            if (rank1 >= 9 and rank2 >= 9):  # 99+, AT, KJ
                return 0.65
            if rank1 == rank2:  # Any pair
                return 0.55 + (rank1 / 14) * 0.15
            if rank1 >= 12 or rank2 >= 12:  # Any ace
                return 0.45 + (min(rank1, rank2) / 14) * 0.1
            if suited and abs(rank1 - rank2) <= 2:  # Suited connectors
                return 0.40
            if rank1 >= 10 or rank2 >= 10:  # High cards
                return 0.35
            return 0.25
        else:
            # Postflop - evaluate based on community cards
            community = round_state.community_cards
            all_cards = self.hand_cards + community
            
            # Check for made hands
            ranks = [self._card_rank(c) for c in all_cards]
            suits = [c[-1] for c in all_cards]
            
            rank_counts = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1
                
            # Check for pairs, trips, etc
            max_count = max(rank_counts.values())
            my_ranks = [self._card_rank(c) for c in self.hand_cards]
            
            if max_count >= 4:
                return 0.95  # Four of a kind
            elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
                return 0.90  # Full house
            elif max_count == 3:
                return 0.75  # Three of a kind
            elif len([c for c in rank_counts.values() if c == 2]) >= 2:
                # Two pair - check if we have one
                pair_ranks = [r for r, c in rank_counts.items() if c == 2]
                if any(r in my_ranks for r in pair_ranks):
                    return 0.65
                return 0.35
            elif max_count == 2:
                # One pair - check if it's ours
                pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
                if pair_rank in my_ranks:
                    return 0.55 + (pair_rank / 14) * 0.1
                return 0.30
                
            # High card
            return 0.25 + (max(my_ranks) / 14) * 0.15
            
    def _card_rank(self, card: str) -> int:
        """Convert card rank to numeric value"""
        if len(card) < 2:
            return 0
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0
                
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, to_call: int) -> Tuple[PokerAction, int]:
        """Aggressive preflop strategy"""
        pot = round_state.pot
        
        # Adjust aggression based on position and stack size
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        aggression_factor = self.position_aggression_multiplier
        
        # Premium hands - always raise or reraise
        if hand_strength >= 0.85:
            if to_call == 0:
                raise_amount = min(int(pot * 3.5 * aggression_factor), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.3:
                raise_amount = min(int(to_call * 3 * aggression_factor), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
                
        # Strong hands - raise or call
        elif hand_strength >= 0.65:
            if to_call == 0:
                raise_amount = min(int(pot * 2.5 * aggression_factor), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            elif hand_strength >= 0.75 and to_call < remaining_chips * 0.25:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Decent hands - call small, raise if first in
        elif hand_strength >= 0.45:
            if to_call == 0:
                raise_amount = min(int(pot * 2 * aggression_factor), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Marginal hands - only play in position or as blind
        elif hand_strength >= 0.35:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands - fold
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, to_call: int) -> Tuple[PokerAction, int]:
        """Aggressive postflop strategy with pot control"""
        pot = round_state.pot
        
        # Calculate implied odds and stack-to-pot ratio
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        
        # Very strong hands - build pot
        if hand_strength >= 0.85:
            if to_call == 0:
                bet_amount = min(int(pot * 0.75), remaining_chips)
                return (PokerAction.RAISE, bet_amount)
            elif to_call < remaining_chips * 0.5:
                raise_amount = min(int(to_call * 2.5), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
                
        # Strong hands - value bet
        elif hand_strength >= 0.65:
            if to_call == 0:
                bet_amount = min(int(pot * 0.6), remaining_chips)
                return (PokerAction.RAISE, bet_amount)
            elif pot_odds < hand_strength - 0.1:
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Medium hands - pot control
        elif hand_strength >= 0.45:
            if to_call == 0:
                # Sometimes bet for value/protection
                if round_state.round in ['Flop', 'Turn']:
                    bet_amount = min(int(pot * 0.4), remaining_chips)
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands with draws
        elif hand_strength >= 0.30:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.25 and round_state.round != 'River':
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Very weak hands - give up
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        self.hand_history.append({
            'round': round_state.round_num,
            'chips': remaining_chips,
            'pot': round_state.pot
        })
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hand_cards = []
        self.hand_history = []