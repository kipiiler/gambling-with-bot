from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.blind_amount = 10
        self.game_count = 0
        self.position = None  # 'small_blind', 'big_blind', or 'other'
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'small_blind'
        elif self.id == big_blind_player_id:
            self.position = 'big_blind'
        else:
            self.position = 'other'
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Basic hand strength evaluation
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get pot odds
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_bet)
        
        # Position-based aggression
        is_position_good = (self.position == 'big_blind' and round_state.round == 'Preflop') or \
                          (self.position == 'small_blind' and round_state.round != 'Preflop')
        
        # Decision logic based on hand strength and pot odds
        if to_call == 0:  # Can check
            if hand_strength >= 0.7:  # Strong hand
                # Proper raise calculation
                if round_state.min_raise > 0:
                    raise_amount = min(round_state.min_raise * 3, remaining_chips)
                else:
                    # When min_raise is 0, we need to set a proper raise
                    raise_amount = min(max(pot // 2, 2 * self.blind_amount), remaining_chips)
                
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength >= 0.4:  # Medium hand
                if is_position_good and round_state.round == 'Preflop':
                    # Try to steal with position
                    if round_state.min_raise > 0:
                        raise_amount = min(round_state.min_raise * 2, remaining_chips)
                    else:
                        raise_amount = min(2 * self.blind_amount, remaining_chips)
                    
                    if raise_amount > 0 and raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:  # Need to call or raise
            # Calculate pot odds
            pot_odds = to_call / (pot + to_call + 0.001)  # Avoid division by zero
            
            if hand_strength >= 0.8:  # Very strong hand
                # Re-raise strong
                if round_state.min_raise > 0 and remaining_chips > to_call:
                    raise_amount = min(round_state.min_raise * 2, remaining_chips - to_call)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                
                # Call if can't raise properly
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
                    
            elif hand_strength >= 0.5:  # Decent hand
                # Call if pot odds are good
                if pot_odds < 0.3 or (hand_strength > 0.6 and pot_odds < 0.4):
                    if to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif hand_strength >= 0.3:  # Weak hand
                # Only call small bets with good pot odds
                if pot_odds < 0.2 and to_call <= self.blind_amount * 2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Very weak hand
                # Fold unless pot odds are amazing
                if pot_odds < 0.1 and to_call <= self.blind_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Pre-flop hand strength
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 12:  # QQ+
                strength = 0.9
            elif rank1 >= 10:  # TT-JJ
                strength = 0.75
            elif rank1 >= 8:  # 88-99
                strength = 0.65
            elif rank1 >= 5:  # 55-77
                strength = 0.55
            else:  # 22-44
                strength = 0.45
        else:
            high_card = max(rank1, rank2)
            low_card = min(rank1, rank2)
            gap = high_card - low_card
            
            # High cards
            if high_card == 14:  # Ace high
                if low_card >= 11:  # AJ+
                    strength = 0.75
                elif low_card >= 9:  # A9-AT
                    strength = 0.6
                else:
                    strength = 0.45
            elif high_card == 13:  # King high
                if low_card >= 11:  # KJ+
                    strength = 0.65
                elif low_card >= 9:
                    strength = 0.5
                else:
                    strength = 0.35
            elif high_card >= 11:  # Queen/Jack high
                if gap <= 2:
                    strength = 0.5
                else:
                    strength = 0.35
            elif high_card >= 9:  # Ten/Nine high
                if gap <= 2:
                    strength = 0.4
                else:
                    strength = 0.25
            else:
                strength = 0.2
            
            # Suited bonus
            if suit1 == suit2:
                strength += 0.1
            
            # Connected cards bonus
            if gap == 1:
                strength += 0.05
        
        # Adjust for community cards
        community = round_state.community_cards
        if len(community) >= 3:
            # Rough post-flop adjustment
            strength = self._adjust_for_community(strength, community)
        
        return min(1.0, max(0.0, strength))
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank (2-14) and suit"""
        if len(card) < 2:
            return (2, 's')
        
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
    
    def _adjust_for_community(self, base_strength: float, community: List[str]) -> float:
        """Adjust strength based on community cards"""
        # Simple adjustment - could be made more sophisticated
        if not community:
            return base_strength
            
        # Check for potential straights/flushes
        community_ranks = [self._parse_card(c)[0] for c in community]
        community_suits = [self._parse_card(c)[1] for c in community]
        
        # If many high cards on board, reduce strength
        high_cards = sum(1 for r in community_ranks if r >= 11)
        if high_cards >= 2:
            base_strength *= 0.8
        
        # If potential flush on board
        for suit in set(community_suits):
            if community_suits.count(suit) >= 3:
                # Check if we have that suit
                our_suits = [self._parse_card(c)[1] for c in self.hole_cards]
                if suit not in our_suits:
                    base_strength *= 0.7
                elif our_suits.count(suit) == 2:
                    base_strength *= 1.3
        
        return min(1.0, max(0.0, base_strength))
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass