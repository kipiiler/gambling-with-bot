from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_strength_cache = {}
        self.opponent_aggression = {}
        self.hands_played = 0
        self.position_relative = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hands_played += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0, 'total': 0}
        
        # Calculate position
        if self.id:
            try:
                my_idx = all_players.index(self.id)
                bb_idx = all_players.index(big_blind_player_id)
                self.position_relative = (my_idx - bb_idx) % len(all_players)
            except:
                self.position_relative = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                stats = self.opponent_aggression[player_id]
                stats['total'] += 1
                if 'Raise' in action or 'All' in action:
                    stats['raises'] += 1
                elif 'Call' in action:
                    stats['calls'] += 1
                elif 'Fold' in action:
                    stats['folds'] += 1
        
        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(round_state)
        
        # Get pot odds
        pot = round_state.pot
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_current_bet)
        pot_odds = to_call / (pot + to_call + 0.001)
        
        # Position advantage
        position_bonus = 0.05 * (self.position_relative / max(1, len(self.all_players)))
        
        # Adjust strategy based on stack size
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        
        # Decision making
        if round_state.round == 'Preflop':
            return self.preflop_strategy(hand_strength, to_call, remaining_chips, round_state, pot_odds, position_bonus, stack_ratio)
        else:
            return self.postflop_strategy(hand_strength, to_call, remaining_chips, round_state, pot_odds, position_bonus, stack_ratio)

    def preflop_strategy(self, hand_strength, to_call, remaining_chips, round_state, pot_odds, position_bonus, stack_ratio):
        adjusted_strength = hand_strength + position_bonus
        
        # All-in with premium hands when short-stacked
        if stack_ratio < 0.15 and hand_strength > 0.8:
            return (PokerAction.ALL_IN, 0)
        
        # Premium hands
        if adjusted_strength > 0.85:
            if to_call > 0:
                if to_call < remaining_chips * 0.3:
                    raise_amount = min(round_state.pot * 3, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                elif hand_strength > 0.9:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                raise_amount = min(round_state.pot * 2 + self.blind_amount * 3, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands
        elif adjusted_strength > 0.65:
            if to_call > 0:
                if pot_odds < adjusted_strength and to_call < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                elif to_call < self.blind_amount * 3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if random.random() < 0.3:
                    raise_amount = min(self.blind_amount * 2.5, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Marginal hands
        elif adjusted_strength > 0.4:
            if to_call > 0:
                if to_call <= self.blind_amount and pot_odds < 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Weak hands
        else:
            if to_call > 0:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def postflop_strategy(self, hand_strength, to_call, remaining_chips, round_state, pot_odds, position_bonus, stack_ratio):
        adjusted_strength = hand_strength + position_bonus
        
        # All-in with very strong hands when pot is large
        if adjusted_strength > 0.9 and round_state.pot > remaining_chips:
            return (PokerAction.ALL_IN, 0)
        
        # Strong hands
        if adjusted_strength > 0.75:
            if to_call > 0:
                if to_call < remaining_chips * 0.5:
                    if adjusted_strength > 0.85:
                        raise_amount = min(round_state.pot * 0.75, remaining_chips)
                        if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                elif adjusted_strength > 0.9:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                raise_amount = min(round_state.pot * 0.6, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Medium hands
        elif adjusted_strength > 0.5:
            if to_call > 0:
                if pot_odds < adjusted_strength * 0.8 and to_call < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if random.random() < 0.2:
                    raise_amount = min(round_state.pot * 0.3, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Weak hands
        elif adjusted_strength > 0.25:
            if to_call > 0:
                if pot_odds < 0.15 and to_call < round_state.pot * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Very weak hands
        else:
            if to_call > 0:
                return (PokerAction.FOLD, 0)
            else:
                # Bluff occasionally
                if random.random() < 0.05 and round_state.pot > 0:
                    raise_amount = min(round_state.pot * 0.4, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)

    def calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards:
            return 0.5
        
        if round_state.round == 'Preflop':
            return self.preflop_hand_strength()
        else:
            return self.monte_carlo_strength(round_state.community_cards)

    def preflop_hand_strength(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.5
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self.card_rank(card1), self.card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 12:  # AA, KK, QQ
                return 0.95
            elif rank1 >= 10:  # JJ, TT
                return 0.85
            elif rank1 >= 8:  # 99, 88
                return 0.75
            elif rank1 >= 6:  # 77, 66
                return 0.65
            else:
                return 0.55
        
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        gap = high_rank - low_rank
        
        # High cards
        if high_rank == 14:  # Ace
            if low_rank >= 11:  # AK, AQ, AJ
                return 0.85 if suited else 0.80
            elif low_rank >= 9:  # AT, A9
                return 0.70 if suited else 0.65
            else:
                return 0.55 if suited else 0.50
        elif high_rank == 13:  # King
            if low_rank >= 11:  # KQ, KJ
                return 0.75 if suited else 0.70
            elif low_rank >= 9:  # KT, K9
                return 0.60 if suited else 0.55
            else:
                return 0.45 if suited else 0.40
        elif high_rank == 12:  # Queen
            if low_rank >= 10:  # QJ, QT
                return 0.65 if suited else 0.60
            elif low_rank >= 8:
                return 0.50 if suited else 0.45
            else:
                return 0.40 if suited else 0.35
        
        # Connectors
        if gap == 1:
            return 0.55 if suited else 0.50
        elif gap == 2:
            return 0.45 if suited else 0.40
        
        # Default
        return 0.35 if suited else 0.30

    def monte_carlo_strength(self, community_cards: List[str], simulations: int = 100) -> float:
        wins = 0
        ties = 0
        
        for _ in range(simulations):
            outcome = self.simulate_hand(community_cards)
            if outcome == 1:
                wins += 1
            elif outcome == 0.5:
                ties += 1
        
        return (wins + ties * 0.5) / (simulations + 0.001)

    def simulate_hand(self, community_cards: List[str]) -> float:
        all_cards = self.hole_cards + community_cards
        remaining_community = 5 - len(community_cards)
        
        deck = self.create_deck()
        for card in all_cards:
            if card in deck:
                deck.remove(card)
        
        if remaining_community > 0:
            random.shuffle(deck)
            simulated_community = community_cards + deck[:remaining_community]
            opponent_cards = deck[remaining_community:remaining_community+2]
        else:
            simulated_community = community_cards
            random.shuffle(deck)
            opponent_cards = deck[:2]
        
        my_best = self.best_hand(self.hole_cards + simulated_community)
        opp_best = self.best_hand(opponent_cards + simulated_community)
        
        if my_best > opp_best:
            return 1
        elif my_best == opp_best:
            return 0.5
        else:
            return 0

    def create_deck(self) -> List[str]:
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        suits = ['h', 'd', 'c', 's']
        return [r + s for r in ranks for s in suits]

    def best_hand(self, cards: List[str]) -> int:
        if len(cards) < 5:
            return 0
        
        from itertools import combinations
        best_score = 0
        
        for combo in combinations(cards, 5):
            score = self.evaluate_hand(list(combo))
            best_score = max(best_score, score)
        
        return best_score

    def evaluate_hand(self, cards: List[str]) -> int:
        ranks = [self.card_rank(c) for c in cards]
        suits = [c[-1] for c in cards]
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        counts = sorted(rank_counts.values(), reverse=True)
        unique_ranks = sorted(rank_counts.keys(), reverse=True)
        is_flush = len(set(suits)) == 1
        is_straight = self.is_straight(sorted(ranks))
        
        # Scoring system
        if is_straight and is_flush and max(ranks) == 14:
            return 10000000  # Royal flush
        elif is_straight and is_flush:
            return 9000000 + max(ranks)  # Straight flush
        elif counts == [4, 1]:
            return 8000000 + self.get_rank_value(rank_counts, 4) * 100  # Four of a kind
        elif counts == [3, 2]:
            return 7000000 + self.get_rank_value(rank_counts, 3) * 100  # Full house
        elif is_flush:
            return 6000000 + sum(unique_ranks[:5])  # Flush
        elif is_straight:
            return 5000000 + max(ranks)  # Straight
        elif counts == [3, 1, 1]:
            return 4000000 + self.get_rank_value(rank_counts, 3) * 100  # Three of a kind
        elif counts == [2, 2, 1]:
            pairs = [r for r, c in rank_counts.items() if c == 2]
            return 3000000 + max(pairs) * 100 + min(pairs)  # Two pair
        elif counts == [2, 1, 1, 1]:
            return 2000000 + self.get_rank_value(rank_counts, 2) * 100  # One pair
        else:
            return 1000000 + sum(unique_ranks[:5])  # High card

    def is_straight(self, ranks: List[int]) -> bool:
        ranks = sorted(set(ranks))
        if len(ranks) < 5:
            return False
        
        # Check for regular straight
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5
        if set(ranks) >= {14, 2, 3, 4, 5}:
            return True
        
        return False

    def get_rank_value(self, rank_counts: Dict[int, int], count: int) -> int:
        for rank, c in rank_counts.items():
            if c == count:
                return rank
        return 0

    def card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass