from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_count = 0
        self.is_big_blind = False
        self.is_small_blind = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        self.game_count += 1
        self.is_big_blind = (big_blind_player_id == self.id)
        self.is_small_blind = (small_blind_player_id == self.id)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current state info
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        pot = round_state.pot
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Determine position (early/late)
        is_preflop = round_state.round.lower() == 'preflop'
        
        # Calculate pot odds
        if to_call > 0 and pot > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
            
        # Strategy based on hand strength and position
        if is_preflop:
            # Preflop strategy
            if hand_strength >= 0.8:  # Premium hands
                # Raise aggressively
                if current_bet == 0:
                    raise_amount = min(3 * self.blind_amount, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                elif to_call > 0:
                    # Re-raise if we have chips
                    if remaining_chips > to_call:
                        raise_amount = min(to_call + 2 * pot // 3, remaining_chips)
                        if raise_amount > to_call:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                else:
                    # We're already in, raise more
                    raise_amount = min(pot // 2, remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                    
            elif hand_strength >= 0.6:  # Good hands
                if to_call <= 3 * self.blind_amount:
                    return (PokerAction.CALL, 0) if to_call > 0 else (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif hand_strength >= 0.4:  # Mediocre hands
                if to_call <= self.blind_amount:
                    return (PokerAction.CALL, 0) if to_call > 0 else (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Weak hands
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif self.is_big_blind and to_call <= self.blind_amount:
                    # Defend big blind with reasonable odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Post-flop strategy
            if hand_strength >= 0.75:  # Very strong hands
                if current_bet == 0:
                    # Bet for value
                    bet_amount = min(2 * pot // 3, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                elif to_call > 0:
                    # Call or raise with strong hands
                    if pot_odds < 0.3 and remaining_chips > to_call:
                        return (PokerAction.CALL, 0)
                    elif remaining_chips <= to_call:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    # Value bet
                    bet_amount = min(pot // 2, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                    
            elif hand_strength >= 0.5:  # Decent hands
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Weak hands
                if to_call == 0:
                    # Try to bluff occasionally
                    if len(round_state.community_cards) == 5 and pot > 5 * self.blind_amount:
                        # River bluff occasionally
                        if self.game_count % 5 == 0:
                            bluff_amount = min(pot // 3, remaining_chips)
                            if bluff_amount >= round_state.min_raise:
                                return (PokerAction.RAISE, bluff_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        is_suited = (suit1 == suit2)
        is_pair = (rank1 == rank2)
        high_card = max(rank1, rank2)
        low_card = min(rank1, rank2)
        gap = high_card - low_card
        
        # Preflop hand strength
        if round_state.round.lower() == 'preflop':
            # Pocket pairs
            if is_pair:
                if rank1 >= 12:  # AA, KK, QQ
                    return 0.95
                elif rank1 >= 10:  # JJ, TT
                    return 0.85
                elif rank1 >= 8:  # 99, 88
                    return 0.75
                elif rank1 >= 6:  # 77, 66
                    return 0.65
                else:  # Small pairs
                    return 0.55
                    
            # High cards
            if high_card == 14:  # Ace high
                if low_card >= 10:  # AK, AQ, AJ, AT
                    return 0.85 if is_suited else 0.80
                elif low_card >= 8:  # A9, A8
                    return 0.65 if is_suited else 0.60
                else:
                    return 0.55 if is_suited else 0.45
                    
            # King high
            if high_card == 13:
                if low_card >= 10:  # KQ, KJ, KT
                    return 0.75 if is_suited else 0.70
                elif low_card >= 8:
                    return 0.60 if is_suited else 0.55
                else:
                    return 0.45
                    
            # Connected cards
            if gap <= 1:  # Connected or one-gappers
                if high_card >= 10:
                    return 0.70 if is_suited else 0.65
                elif high_card >= 8:
                    return 0.60 if is_suited else 0.55
                else:
                    return 0.50 if is_suited else 0.45
                    
            # Suited cards
            if is_suited and gap <= 3:
                return 0.50
                
            # Default weak hands
            return 0.35
        else:
            # Post-flop: evaluate based on community cards
            community = round_state.community_cards
            if not community:
                return 0.5
                
            # Simple post-flop evaluation
            comm_ranks = [self._parse_card(c)[0] for c in community]
            comm_suits = [self._parse_card(c)[1] for c in community]
            
            # Check for pairs with board
            for comm_rank in comm_ranks:
                if rank1 == comm_rank or rank2 == comm_rank:
                    # We have at least a pair
                    if comm_rank >= 12:  # High pair
                        return 0.75
                    elif comm_rank >= 9:  # Medium pair
                        return 0.65
                    else:  # Low pair
                        return 0.55
                        
            # Check for flush draw
            all_suits = [suit1, suit2] + comm_suits
            for suit in set(all_suits):
                if all_suits.count(suit) >= 4:
                    return 0.70 if len(community) < 5 else 0.80
                    
            # Check for straight draw
            all_ranks = sorted([rank1, rank2] + comm_ranks)
            if self._has_straight_draw(all_ranks):
                return 0.60
                
            # High card only
            if high_card >= 12:
                return 0.45
            else:
                return 0.35
                
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit"""
        if len(card) < 2:
            return (2, 's')
            
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
        
    def _has_straight_draw(self, ranks: List[int]) -> bool:
        """Check if we have a straight draw"""
        unique_ranks = list(set(ranks))
        unique_ranks.sort()
        
        # Check for 4 cards in sequence
        for i in range(len(unique_ranks) - 3):
            if unique_ranks[i+3] - unique_ranks[i] <= 4:
                return True
                
        # Check ace-low straight
        if 14 in unique_ranks:
            low_ranks = [1 if r == 14 else r for r in unique_ranks]
            low_ranks.sort()
            for i in range(len(low_ranks) - 3):
                if low_ranks[i+3] - low_ranks[i] <= 4:
                    return True
                    
        return False
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass