from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.raises_this_round = 0
        self.aggression_factor = 0.5
        self.pot_odds_factor = 0.25
        self.position_strength = {'early': 0.7, 'middle': 0.85, 'late': 1.0}
        self.strength_map = {}
        self._init_strength_map()

    def _init_strength_map(self):
        pairs = ['AA', 'KK', 'QQ', 'JJ', 'TT']
        strong_faces = ['AK', 'AQ', 'AJ', 'KQ']
        medium_pairs = ['99', '88', '77']
        suited_connectors = ['AKs', 'AQs', 'AJs', 'KQs', 'KJs', 'QJs', 'JTs']
        for hand in pairs: self.strength_map[hand] = 1.0
        for hand in strong_faces: self.strength_map[hand] = 0.9
        self.strength_map['AKs'] = 0.95
        for hand in medium_pairs: self.strength_map[hand] = 0.8
        for hand in suited_connectors: self.strength_map[hand] = 0.75

    def _hand_to_key(self, cards):
        ranks = sorted([card[:-1] for card in cards], key=lambda x: ['2','3','4','5','6','7','8','9','10','J','Q','K','A'].index(x), reverse=True)
        if ranks[0] == ranks[1]: return ranks[0] + ranks[1]
        if cards[0][-1] == cards[1][-1]: return ranks[0] + ranks[1] + 's'
        return ranks[0] + ranks[1]

    def _get_position_factor(self, current_players, my_id):
        my_index = current_players.index(my_id)
        players_after = len(current_players) - my_index - 1
        if players_after >= 2: return self.position_strength['early']
        elif players_after == 1: return self.position_strength['middle']
        else: return self.position_strength['late']

    def _evaluate_hand(self, cards):
        if not cards: return (0, [])
        suits = [c[-1] for c in cards]
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '10':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        ranks = [rank_map[c[:-1]] for c in cards]
        rank_str = [c[:-1] for c in cards]
        
        flush = len(set(suits)) == 1
        sorted_ranks = sorted(ranks, reverse=True)
        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        straight_high = 0

        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks)-4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    is_straight = True
                    straight_high = unique_ranks[i]
                    break
            if not is_straight and set([2,3,4,5,14]).issubset(set(ranks)):
                is_straight = True
                straight_high = 5

        counts = sorted([(ranks.count(r), r) for r in set(ranks)], reverse=True)
        if flush and is_straight:
            if straight_high == 14 and set([10,11,12,13,14]).issubset(set(ranks)):
                return (10, [14,13,12,11,10])
            return (9, sorted([straight_high, straight_high-1, straight_high-2, straight_high-3, straight_high-4], reverse=True))
        if counts[0][0] == 4:
            return (8, [counts[0][1]]*4 + [counts[1][1]])
        if counts[0][0] == 3 and counts[1][0] >= 2:
            return (7, [counts[0][1]]*3 + [counts[1][1]]*2)
        if flush:
            return (6, sorted_ranks[:5])
        if is_straight:
            return (5, [straight_high, straight_high-1, straight_high-2, straight_high-3, straight_high-4])
        if counts[0][0] == 3:
            return (4, [counts[0][1]]*3 + sorted(r for r in ranks if r != counts[0][1], reverse=True)[:2])
        if counts[0][0] == 2 and counts[1][0] == 2:
            return (3, sorted(counts[0][1] for _ in range(counts[0][0]) + [counts[1][1] for _ in range(counts[1][0])] + [r for r in ranks if r not in [counts[0][1], counts[1][1]]], reverse=True)[:5])
        if counts[0][0] == 2:
            return (2, [counts[0][1]]*2 + sorted(r for r in ranks if r != counts[0][1], reverse=True)[:3])
        return (1, sorted_ranks[:5])

    def _hand_strength(self, all_cards):
        if not all_cards: return 0.1
        best_strength = 0
        for combo in itertools.combinations(all_cards, 5):
            strength, _ = self._evaluate_hand(list(combo))
            best_strength = max(best_strength, strength / 10.0)
        return best_strength

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        if player_hands and isinstance(player_hands[0], list) and len(player_hands) > 0:
            self.hole_cards = player_hands[0]
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.raises_this_round = 0
        self.community_cards = round_state.community_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.hole_cards: return PokerAction.FOLD, 0
        all_cards = self.hole_cards + round_state.community_cards
        hand_strength = self._hand_strength(all_cards)
        our_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - our_bet
        pot_odds = to_call / (round_state.pot + to_call + 0.001)
        position_factor = self._get_position_factor(round_state.current_player, self.id)
        base_strength = self.strength_map.get(self._hand_to_key(self.hole_cards), 0.5)
        adjusted_strength = hand_strength * position_factor

        if round_state.current_bet == 0:
            if adjusted_strength > 0.6 and self.raises_this_round < 2:
                self.raises_this_round += 1
                raise_amount = min(int(round_state.pot * 0.75), remaining_chips)
                return PokerAction.RAISE, raise_amount
            return PokerAction.CHECK, 0

        if adjusted_strength > 0.8 and self.raises_this_round < 2:
            self.raises_this_round += 1
            raise_size = min(int(round_state.pot * (0.5 + self.aggression_factor)), remaining_chips)
            return PokerAction.RAISE, raise_size
        elif adjusted_strength > max(pot_odds - self.pot_odds_factor, 0.3):
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass