from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.small_blind = None
        self.big_blind = None
        self.hole_cards = []
        self.round_num = 0
        self.opp_aggression = 0.5  # Track opponent aggression level

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.small_blind = blind_amount
        self.big_blind = 2 * blind_amount
        index = all_players.index(self.id)
        self.hole_cards = player_hands[index*2 : index*2+2]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Reset aggression tracking for new round
        self.opp_aggression = 0.5

    def card_to_tuple(self, card):
        rank_char = card[0]
        suit_char = card[1]
        rank_dict = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        return (rank_dict[rank_char], suit_char)

    def check_straight(self, cards):
        distinct_ranks = list(set(rank for rank, suit in cards))
        if len(distinct_ranks) != 5:
            return (False, None)
        
        patterns = [
            ([14,13,12,11,10], 14),
            ([13,12,11,10,9], 13),
            ([12,11,10,9,8], 12),
            ([11,10,9,8,7], 11),
            ([10,9,8,7,6], 10),
            ([9,8,7,6,5], 9),
            ([8,7,6,5,4], 8),
            ([7,6,5,4,3], 7),
            ([6,5,4,3,2], 6),
            ([5,4,3,2,14], 5)
        ]
        
        for pattern, high_card in patterns:
            if set(distinct_ranks) == set(pattern):
                return (True, high_card)
        return (False, None)

    def evaluate_5_hand(self, cards):
        suits = [suit for rank, suit in cards]
        is_flush = (len(set(suits)) == 1)
        is_straight, straight_high = self.check_straight(cards)
        
        if is_flush and is_straight:
            return (8, [straight_high])
        
        rank_count = {}
        for rank, suit in cards:
            rank_count[rank] = rank_count.get(rank, 0) + 1
        
        items = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)
        counts = [item[1] for item in items]
        ranks_in_order = [item[0] for item in items]
        
        if counts == [4,1]:
            return (7, [ranks_in_order[0], ranks_in_order[1]])
        elif counts == [3,2]:
            return (6, [ranks_in_order[0], ranks_in_order[1]])
        elif is_straight:
            return (4, [straight_high])
        elif is_flush:
            flush_ranks = sorted([rank for rank, suit in cards], reverse=True)
            return (5, flush_ranks)
        elif counts == [3,1,1]:
            kickers = sorted(ranks_in_order[1:], reverse=True)
            return (3, [ranks_in_order[0]] + kickers)
        elif counts == [2,2,1]:
            return (2, [ranks_in_order[0], ranks_in_order[1], ranks_in_order[2]])
        elif counts == [2,1,1,1]:
            kickers = sorted(ranks_in_order[1:], reverse=True)
            return (1, [ranks_in_order[0]] + kickers)
        else:
            all_ranks = sorted([rank for rank, suit in cards], reverse=True)
            return (0, all_ranks)

    def evaluate_7_hand(self, hole_cards, community_cards):
        all_cards = [self.card_to_tuple(card) for card in hole_cards + community_cards]
        best_hand = None
        
        for five_cards in combinations(all_cards, 5):
            hand_value = self.evaluate_5_hand(list(five_cards))
            if best_hand is None:
                best_hand = hand_value
            else:
                if hand_value[0] > best_hand[0] or \
                   (hand_value[0] == best_hand[0] and hand_value[1] > best_hand[1]):
                    best_hand = hand_value
                    
        return best_hand

    def get_hand_group(self, hole_cards):
        if not hole_cards or len(hole_cards) < 2:
            return 10
        
        ranks = sorted([card[0] for card in hole_cards], reverse=True)
        suits = [card[1] for card in hole_cards]
        
        if ranks[0] == ranks[1]:  # Pair
            if ranks[0] >= 12:  # JJ+
                return 1
            elif ranks[0] >= 10:  # TT
                return 2
            else:
                return 5
        else:
            suited = suits[0] == suits[1]
            gap = ranks[0] - ranks[1] - 1
            
            if ranks[0] == 14:  # Ace high
                if ranks[1] >= 12:  # AK, AQ
                    return 1 if suited else 2
                elif ranks[1] >= 10:  # AJ, AT
                    return 2 if suited else 4
                else:
                    return 6 if suited else 8
            elif ranks[0] >= 12:  # King high
                if ranks[1] >= 10 and suited:
                    return 3
                elif ranks[1] >= 10:
                    return 5
                elif gap <= 1 and suited:
                    return 5
                else:
                    return 7
            else:
                if gap == 0 and suited:  # Connected, suited
                    return 6
                elif gap <= 2:
                    return 7
                else:
                    return 9

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - our_bet
        pot = round_state.pot
        
        # Update opponent aggression based on their actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['RAISE', 'ALL_IN']:
                    self.opp_aggression = min(1.0, self.opp_aggression + 0.1)
                elif action == 'FOLD':
                    self.opp_aggression = max(0.0, self.opp_aggression - 0.1)
        
        # Evaluate hand strength
        hand_value = self.evaluate_7_hand(self.hole_cards, round_state.community_cards)
        hand_rank = hand_value[0]
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            group = self.get_hand_group([self.card_to_tuple(card) for card in self.hole_cards])
            
            # Position estimation based on table size
            table_size = len(round_state.current_player)
            position_index = round_state.current_player.index(self.id)
            is_early = position_index < table_size // 3
            is_late = position_index >= 2 * table_size // 3
            
            if to_call == 0:  # No bet to us
                if group <= 3 and is_late:
                    raise_amount = min(3 * self.big_blind, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                elif group <= 5:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0) if random.random() > 0.3 else (PokerAction.FOLD, 0)
            else:  # Facing a bet
                pot_odds = pot / (to_call + 0.001)
                if group <= 2 and pot_odds > 3:
                    return (PokerAction.CALL, 0)
                elif group <= 4 and pot_odds > 5:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            if hand_rank >= 7:  # Straight flush or four of a kind
                if to_call == 0:
                    return (PokerAction.ALL_IN, 0) if random.random() > 0.3 else (PokerAction.RAISE, min(pot // 2, remaining_chips))
                else:
                    return (PokerAction.ALL_IN, 0)
                    
            elif hand_rank >= 5:  # Flush, full house
                if to_call == 0:
                    bet_amount = min(pot // 2, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    pot_odds = pot / (to_call + 0.001)
                    if pot_odds > 3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            elif hand_rank >= 3:  # Three of a kind or straight
                if to_call == 0:
                    bet_amount = min(pot // 3, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    pot_odds = pot / (to_call + 0.001)
                    if pot_odds > 4:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            elif hand_rank >= 1:  # One pair or two pair
                if to_call == 0:
                    # Check unless we have a strong draw and position
                    if hand_rank == 2 and len(round_state.community_cards) == 5:  # Two pair on river
                        bet_amount = min(pot // 4, remaining_chips)
                        if bet_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    pot_odds = pot / (to_call + 0.001)
                    if hand_rank == 2 and pot_odds > 5:
                        return (PokerAction.CALL, 0)
                    elif hand_rank == 1 and pot_odds > 7:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:  # High card
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    pot_odds = pot / (to_call + 0.001)
                    if pot_odds > 10:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        # Default to check if no action taken
        return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass