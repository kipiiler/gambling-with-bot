from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.chips = 0
        self.round_num = None
        self.big_blind_amount = 0
        self.our_hole_cards = []
        self.player_id_index_map = {}
        self.starting_hands_set = {
            (14, 14), (13, 13), (12, 12), (11, 11), (10, 10), (9, 9), (8, 8), (7, 7),
            (14, 13), (14, 12), (14, 11), (14, 10), (14, 9), (13, 12), (13, 11), (13, 10),
            (12, 11), (12, 10), (11, 10), (10, 9)
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.chips = starting_chips
        self.big_blind_amount = blind_amount
        self.player_id_index_map = {pid: idx for idx, pid in enumerate(all_players)}
        our_index = self.player_id_index_map[self.id]
        self.our_hole_cards = player_hands[2 * our_index: 2 * our_index + 2]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.chips = remaining_chips
        self.round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.chips = remaining_chips
        
        # Only play first round for now due to hole card access limitations
        if self.round_num != 0:
            return (PokerAction.FOLD, 0)
        
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        if round_state.round == 'Preflop':
            return self.get_preflop_action(to_call, min_raise, max_raise)
        else:
            return self.get_postflop_action(round_state, to_call, min_raise, max_raise)

    def get_preflop_action(self, to_call: int, min_raise: int, max_raise: int) -> Tuple[PokerAction, int]:
        rank1 = self.card_to_rank(self.our_hole_cards[0])
        rank2 = self.card_to_rank(self.our_hole_cards[1])
        if rank1 < rank2:
            rank1, rank2 = rank2, rank1
        
        hand_tuple = (rank1, rank2)
        if hand_tuple in self.starting_hands_set:
            if to_call == 0:
                raise_amount = min(3 * self.big_blind_amount, max_raise)
                if raise_amount < min_raise:
                    raise_amount = min_raise
                return (PokerAction.RAISE, raise_amount)
            else:
                if to_call <= 4 * self.big_blind_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.FOLD, 0)

    def get_postflop_action(self, round_state: RoundStateClient, to_call: int, min_raise: int, max_raise: int) -> Tuple[PokerAction, int]:
        all_cards = self.our_hole_cards + round_state.community_cards
        strength = self.evaluate_hand(all_cards)
        score = strength[0] * 10000 + strength[1] * 100 + strength[2]
        
        if score >= 60000:
            if to_call == 0:
                bet_amount = min(round_state.pot // 2, max_raise)
                if bet_amount < min_raise:
                    bet_amount = min_raise
                return (PokerAction.RAISE, bet_amount)
            else:
                raise_amount = min(current_bet * 2, max_raise)
                if raise_amount < min_raise:
                    raise_amount = min_raise
                return (PokerAction.RAISE, raise_amount)
        elif score >= 30000:
            if to_call == 0:
                bet_amount = min(round_state.pot // 3, max_raise)
                if bet_amount < min_raise:
                    bet_amount = min_raise
                return (PokerAction.RAISE, bet_amount)
            else:
                if to_call <= round_state.pot // 4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    @staticmethod
    def card_to_rank(card: str) -> int:
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            return int(rank_char)

    @staticmethod
    def evaluate_hand(all_cards: List[str]) -> Tuple[int, int, int]:
        if len(all_cards) < 5:
            return (0, 0, 0)
            
        ranks = []
        suits = []
        for card in all_cards:
            r = SimplePlayer.card_to_rank(card[0])
            s = card[1]
            ranks.append(r)
            suits.append(s)
            
        best_hand = (0, 0, 0)
        for combo in itertools.combinations(ranks, 5):
            used_indices = []
            for i, r in enumerate(ranks):
                if r in combo:
                    used_indices.append(i)
            combo_ranks = [ranks[i] for i in used_indices]
            combo_suits = [suits[i] for i in used_indices]
            hand = SimplePlayer.evaluate_5_cards(combo_ranks, combo_suits)
            if hand > best_hand:
                best_hand = hand
                
        return best_hand

    @staticmethod
    def evaluate_5_cards(ranks: List[int], suits: List[str]) -> Tuple[int, int, int]:
        if len(ranks) != 5 or len(suits) != 5:
            return (0, 0, 0)
            
        flush = len(set(suits)) == 1
        sorted_ranks = sorted(ranks, reverse=True)
        straight = False
        straight_high = 0
        
        # Check for standard straight and A-5 straight
        if sorted_ranks[0] - sorted_ranks[4] == 4:
            straight = True
            straight_high = sorted_ranks[0]
        elif sorted_ranks == [14, 5, 4, 3, 2]:
            straight = True
            straight_high = 5
            
        count = Counter(ranks)
        sorted_rank_items = sorted(count.items(), key=lambda x: (-x[1], -x[0]))
        
        if straight and flush:
            if sorted_ranks[0] == 14 and sorted_ranks[1] == 13:
                return (9, 14, 0)
            else:
                return (8, straight_high, 0)
        elif count.most_common(1)[0][1] == 4:
            main_rank = sorted_rank_items[0][0]
            next_rank = sorted_rank_items[1][0]
            return (7, main_rank, next_rank)
        elif count.most_common(2)[0][1] == 3 and count.most_common(2)[1][1] == 2:
            main_rank = sorted_rank_items[0][0]
            next_rank = sorted_rank_items[1][0]
            return (6, main_rank, next_rank)
        elif flush:
            return (5, sorted_ranks[0], sorted_ranks[1])
        elif straight:
            return (4, straight_high, 0)
        elif count.most_common(1)[0][1] == 3:
            main_rank = sorted_rank_items[0][0]
            next_rank = sorted_rank_items[1][0]
            return (3, main_rank, next_rank)
        elif count.most_common(2)[0][1] == 2 and count.most_common(2)[1][1] == 2:
            main_rank = sorted_rank_items[0][0]
            next_rank = sorted_rank_items[1][0]
            return (2, main_rank, next_rank)
        elif count.most_common(1)[0][1] == 2:
            main_rank = sorted_rank_items[0][0]
            next_rank = sorted_rank_items[1][0]
            return (1, main_rank, next_rank)
        else:
            return (0, sorted_ranks[0], sorted_ranks[1])