from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.community_cards = []
        self.my_position = 0
        self.aggressiveness = 0.5  # Default aggressiveness level

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game state
        self.hand_cards = player_hands
        self.community_cards = []
        
        # Determine our position relative to blinds
        # This helps in making positional decisions
        players_after_us = 0
        my_index = all_players.index(self.id)
        
        # Find big blind player index
        bb_index = all_players.index(big_blind_player_id)
        
        # Calculate how many players are still to act after us
        if bb_index > my_index:
            players_after_us = bb_index - my_index - 1
        else:
            # Wrap around case
            players_after_us = (len(all_players) - my_index - 1) + bb_index
            
        self.my_position = len(all_players) - players_after_us - 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update community cards
        self.community_cards = round_state.community_cards

    def _get_hand_strength(self) -> float:
        """Calculate a basic hand strength based on hole cards and community cards"""
        # For simplicity, we'll use a basic evaluation
        # In a real implementation, this would be more sophisticated
        
        if len(self.hand_cards) < 2:
            return 0.0
            
        card1 = self.hand_cards[0]
        card2 = self.hand_cards[1]
        
        # Basic hand strength evaluation
        rank1 = card1[0]
        rank2 = card2[0]
        suit1 = card1[1]
        suit2 = card2[1]
        
        # High card values
        high_ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Convert ranks to numbers
        def get_rank_value(rank):
            if rank in high_ranks:
                return high_ranks[rank]
            else:
                return int(rank)
                
        r1 = get_rank_value(rank1)
        r2 = get_rank_value(rank2)
        
        # Pair
        if rank1 == rank2:
            return min(0.8 + (r1 * 0.01), 0.95)  # Pair strength
        
        # Suited cards get a bonus
        suited_bonus = 0.05 if suit1 == suit2 else 0
        
        # High cards get bonus
        high_card_bonus = 0
        if r1 >= 10:
            high_card_bonus += 0.02
        if r2 >= 10:
            high_card_bonus += 0.02
            
        # Connectedness bonus
        connected_bonus = 0
        if abs(r1 - r2) == 1:
            connected_bonus = 0.03
        elif abs(r1 - r2) == 2:
            connected_bonus = 0.01
            
        # Base strength based on high cards
        base_strength = (r1 + r2) / 28.0  # Normalize to roughly 0-1 range
        base_strength = min(base_strength, 0.8)  # Cap it
        
        return max(0.1, min(0.95, base_strength + suited_bonus + connected_bonus + 0.1))

    def _evaluate_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Evaluate the best action based on hand strength and game state"""
        
        # Get current betting information
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        hand_strength = self._get_hand_strength()
        
        # Adjust aggressiveness based on position and stack size
        effective_aggressiveness = self.aggressiveness
        
        # Increase aggressiveness with fewer players
        if len(round_state.current_player) <= 2:
            effective_aggressiveness += 0.1
            
        # Positional adjustment - more aggressive in late position
        if self.my_position >= 4:
            effective_aggressiveness += 0.05
            
        # Stack adjustment - more conservative with short stack
        stack_ratio = remaining_chips / 10000.0
        if stack_ratio < 0.3:
            effective_aggressiveness -= 0.2
        elif stack_ratio < 0.6:
            effective_aggressiveness -= 0.1
            
        # Preflop adjustments
        is_preflop = round_state.round == 'Preflop'
        if is_preflop:
            # Preflop we want to play premium hands more aggressively
            if hand_strength > 0.7:
                effective_aggressiveness += 0.2
            elif hand_strength < 0.3:
                effective_aggressiveness -= 0.3
        else:
            # Post-flop adjustments based on community cards
            pass  # Could add more sophisticated logic here
            
        # Determine action based on hand strength and situation
        if to_call == 0:
            # We can check or bet
            if hand_strength > 0.7:
                # Strong hand - bet aggressively
                bet_amount = int(max(min_raise, min(max_raise, remaining_chips * 0.5 * effective_aggressiveness)))
                return (PokerAction.RAISE, bet_amount)
            elif hand_strength > 0.4:
                # Medium hand - small bet or check
                bet_amount = int(max(min_raise, min(max_raise, remaining_chips * 0.2 * effective_aggressiveness)))
                if bet_amount >= min_raise:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            pot_odds = to_call / (round_state.pot + to_call) if (round_state.pot + to_call) > 0 else 0.5
            
            # Adjust hand strength based on position and pot odds
            adjusted_strength = hand_strength
            
            # More aggressive in position
            if self.my_position >= len(round_state.current_player) // 2:
                adjusted_strength += 0.05
                
            if adjusted_strength > pot_odds + 0.2:
                # We have good odds to call or raise
                if hand_strength > 0.7:
                    # Strong hand - raise
                    raise_amount = int(max(min_raise, min(max_raise, remaining_chips * 0.5 * effective_aggressiveness)))
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    # Just call
                    return (PokerAction.CALL, 0)
            elif adjusted_strength > pot_odds - 0.1:
                # Borderline - call
                return (PokerAction.CALL, 0)
            else:
                # Fold
                return (PokerAction.FOLD, 0)
                
        # Default action - check/fold
        return (PokerAction.CHECK, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Special case for preflop - we're the big blind and can check
            current_bet = round_state.current_bet
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_current_bet
            
            # If we're big blind and there's no bet to call, just check
            if to_call == 0:
                return (PokerAction.CHECK, 0)
                
            # Evaluate our action
            action, amount = self._evaluate_action(round_state, remaining_chips)
            
            # Validate the action
            if action == PokerAction.RAISE:
                # Ensure we're raising at least the minimum
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                
                # If amount is 0 or invalid, set to minimum raise
                if amount < min_raise:
                    amount = min_raise
                    
                # Make sure we don't exceed our stack
                if amount > max_raise:
                    amount = max_raise
                    
                # Ensure amount is at least min_raise
                if amount < min_raise:
                    # If we can't make a valid raise, just call
                    return (PokerAction.CALL, 0)
                    
                return (PokerAction.RAISE, amount)
            elif action == PokerAction.CALL:
                return (PokerAction.CALL, 0)
            elif action == PokerAction.FOLD:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
                
        except Exception as e:
            # If any error occurs, fold to be safe
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # No action needed here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        # No action needed here
        pass