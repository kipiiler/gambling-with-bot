from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.my_bet = 0
        self.round_num = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.remaining_chips = 0
        self.current_round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        self.my_bet = round_state.player_bets.get(str(self.id), 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        self.my_bet = round_state.player_bets.get(str(self.id), 0)

        # Basic hand strength evaluation
        hand_strength = self.evaluate_hand_strength(round_state.community_cards)
        
        # Positional awareness (simplified)
        is_preflop = round_state.round == "Preflop"
        is_in_blind = self.id == self.big_blind_player_id or self.id == self.small_blind_player_id
        num_active_players = len(round_state.current_player)
        
        # Decide action based on hand strength and situation
        if is_preflop:
            return self.preflop_strategy(hand_strength, is_in_blind, num_active_players, round_state)
        else:
            return self.postflop_strategy(hand_strength, round_state)

    def preflop_strategy(self, hand_strength: float, is_in_blind: bool, num_active_players: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        current_bet = round_state.current_bet
        
        # Adjust strategy based on position and hand strength
        if hand_strength > 0.7:  # Premium hands
            if current_bet == 0:
                raise_amount = min(max_raise, max(min_raise, int(3 * self.blind_amount)))
                return (PokerAction.RAISE, raise_amount)
            else:
                call_amount = current_bet - self.my_bet
                if hand_strength > 0.85 and random.random() < 0.7:
                    raise_amount = min(max_raise, max(min_raise, int(2 * current_bet)))
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= self.remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_strength > 0.4:  # Medium hands
            if is_in_blind and current_bet <= 2 * self.blind_amount:
                return (PokerAction.CALL, 0)
            elif current_bet == 0:
                if random.random() < 0.5:
                    raise_amount = min(max_raise, max(min_raise, int(2.5 * self.blind_amount)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif current_bet <= 3 * self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hands
            if current_bet == 0:
                if random.random() < 0.3:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

    def postflop_strategy(self, hand_strength: float, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        current_bet = round_state.current_bet
        
        pot_odds = (current_bet - self.my_bet) / (round_state.pot + 1e-8)  # Avoid division by zero
        
        # Adjust hand strength based on pot odds
        adjusted_strength = hand_strength * (1 + pot_odds)
        
        if adjusted_strength > 0.6:  # Strong hand
            if current_bet == 0:
                raise_amount = min(max_raise, max(min_raise, int(0.75 * round_state.pot)))
                return (PokerAction.RAISE, raise_amount)
            else:
                call_amount = current_bet - self.my_bet
                if adjusted_strength > 0.8 and random.random() < 0.6:
                    raise_amount = min(max_raise, max(min_raise, int(1.5 * current_bet)))
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= self.remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif adjusted_strength > 0.3:  # Marginal hand
            if current_bet == 0:
                if random.random() < 0.4:
                    raise_amount = min(max_raise, max(min_raise, int(0.5 * round_state.pot)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hand
            if current_bet == 0:
                if random.random() < 0.2:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

    def evaluate_hand_strength(self, community_cards: List[str]) -> float:
        # Simplified hand strength evaluator
        # In reality, you'd want a more sophisticated poker hand evaluator
        
        # For now, let's use a very basic heuristic
        # This is a placeholder - a real implementation would evaluate actual poker hands
        if not community_cards:  # Preflop
            # Very basic preflop hand strength based on hole cards only
            rank1 = self.hole_cards[0][0] if self.hole_cards else '2'
            rank2 = self.hole_cards[1][0] if len(self.hole_cards) > 1 else '2'
            suit1 = self.hole_cards[0][1] if self.hole_cards else 'h'
            suit2 = self.hole_cards[1][1] if len(self.hole_cards) > 1 else 'h'
            
            high_ranks = ['A', 'K', 'Q', 'J', 'T']
            is_pair = rank1 == rank2
            is_high_card = rank1 in high_ranks or rank2 in high_ranks
            is_suited = suit1 == suit2
            
            if is_pair and rank1 in ['A', 'K', 'Q']:
                return 0.9
            elif is_pair:
                return 0.7
            elif is_high_card and is_suited:
                return 0.6
            elif is_high_card:
                return 0.5
            else:
                return 0.3 * random.random()  # Some randomness for weak hands
        else:
            # Postflop - add some strength for having made it this far
            base_strength = 0.4 + 0.3 * random.random()
            community_factor = min(0.3, len(community_cards) * 0.1)
            return min(1.0, base_strength + community_factor)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass