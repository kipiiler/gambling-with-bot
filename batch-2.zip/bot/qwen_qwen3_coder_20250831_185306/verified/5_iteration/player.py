from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.position = 0  # 0 for early position, 1 for late position (button)
        self.hand_strength = 0
        self.aggression_factor = 1.5
        self.tightness_factor = 0.6

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Fix: Convert self.id to string when searching in list
        player_ids_str = [str(pid) for pid in round_state.current_player]
        try:
            self.position = 1 if player_ids_str.index(str(self.id)) == len(player_ids_str) - 1 else 0
        except ValueError:
            # Fallback if player ID not found (should not happen in normal play)
            self.position = 0

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Simple hand strength evaluation"""
        # This is a very basic hand strength evaluator
        # In a real implementation, this would be much more sophisticated
        
        # For now, we'll use a simple ranking based on card values and pairs
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                       '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        if len(self.hole_cards) < 2:
            return 0.0
            
        card1_rank = self.hole_cards[0][0]
        card2_rank = self.hole_cards[1][0]
        card1_suit = self.hole_cards[0][1]
        card2_suit = self.hole_cards[1][1]
        
        # Base strength on card ranks
        strength = (rank_values[card1_rank] + rank_values[card2_rank]) / 28.0  # Normalize to 0-1
        
        # Bonus for pocket pairs
        if card1_rank == card2_rank:
            strength += 0.2
            
        # Bonus for suited cards
        if card1_suit == card2_suit:
            strength += 0.1
            
        # Bonus for high cards
        if rank_values[card1_rank] > 10 or rank_values[card2_rank] > 10:
            strength += 0.1
            
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        self.hand_strength = self.evaluate_hand_strength(round_state)
        
        # Get current bet and player's current bet
        current_bet = round_state.current_bet
        player_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - player_bet
        
        # Determine if we're in early or late position
        is_late_position = self.position == 1
        
        # Preflop strategy
        if round_state.round == "Preflop":
            # Adjust strategy based on position
            if is_late_position:
                min_raise = round_state.min_raise
                raise_amount = min(int(current_bet * self.aggression_factor), remaining_chips)
                
                # Raise with strong hands or occasionally as a bluff
                if self.hand_strength > self.tightness_factor or (random.random() < 0.1 and to_call == 0):
                    if raise_amount >= min_raise and raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                    elif raise_amount > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                
                # Call with medium strength hands
                if self.hand_strength > 0.3 and to_call <= remaining_chips * 0.2:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                
                # Fold weak hands
                return (PokerAction.FOLD, 0)
            else:  # Early position
                # Play tighter in early position
                if self.hand_strength > 0.7:
                    min_raise = round_state.min_raise
                    raise_amount = min(int(current_bet * self.aggression_factor), remaining_chips)
                    
                    if raise_amount >= min_raise and raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                    elif raise_amount > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                        
                if self.hand_strength > 0.4 and to_call <= remaining_chips * 0.1:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                
                return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            # Simplified post-flop play
            pot_odds = to_call / (round_state.pot + to_call + 1e-8)  # Add small epsilon to prevent division by zero
            
            # If we have a strong hand or good pot odds, continue
            if self.hand_strength > 0.6 or self.hand_strength > pot_odds * 1.5:
                min_raise = round_state.min_raise
                raise_amount = min(int(current_bet * self.aggression_factor), remaining_chips)
                
                # If we can raise
                if to_call == 0 and raise_amount >= min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call > 0 and to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                elif to_call > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
            else:
                # If check is possible, check
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Otherwise fold
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used to adjust strategy based on results of the round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Can be used to analyze overall performance
        pass