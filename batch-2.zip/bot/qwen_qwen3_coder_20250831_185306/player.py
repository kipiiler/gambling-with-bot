from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.num_players = 0
        self.player_stats = {}  # Track opponent tendencies
        self.my_stack = 10000
        self.game_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_stack = starting_chips
        self.game_count += 1
        # Initialize player stats for opponents
        for player_id in all_players:
            if player_id != self.id:
                self.player_stats[player_id] = {
                    'aggression': 0.5,  # How often they raise/bet
                    'fold_frequency': 0.5,  # How often they fold
                    'volatility': 0.5  # Measure of unpredictable play
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_stack = remaining_chips

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0 to 1"""
        if not hole_cards:
            return 0.0
            
        # Simple hand evaluation based on card ranks and potential
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                 '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        hole_ranks = [card[0] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Base strength from hole cards
        rank_values = [ranks[r] for r in hole_ranks]
        high_card = max(rank_values)
        low_card = min(rank_values)
        
        # Pair bonus
        pair_bonus = 0.2 if rank_values[0] == rank_values[1] else 0
        
        # Connectedness bonus (straight potential)
        connected_bonus = 0.1 if abs(rank_values[0] - rank_values[1]) == 1 else 0
        
        # Suited bonus
        suited_bonus = 0.1 if hole_suits[0] == hole_suits[1] else 0
        
        # High card bonus
        high_card_bonus = (high_card - 7) / 100 if high_card > 7 else 0
        
        # Position bonus (later position gives more information)
        position_bonus = self.position / (self.num_players + 1) * 0.1
        
        # Community cards factor
        if len(community_cards) > 0:
            comm_ranks = [ranks[card[0]] for card in community_cards]
            # Check for made hands (pairs, two pairs, etc.)
            all_ranks = rank_values + comm_ranks
            rank_counts = {}
            for r in all_ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1
                
            # Count pairs, trips, etc.
            pair_count = sum(1 for count in rank_counts.values() if count == 2)
            trip_count = sum(1 for count in rank_counts.values() if count == 3)
            quad_count = sum(1 for count in rank_counts.values() if count == 4)
            
            # Hand strength bonus based on made hands
            made_hand_bonus = 0
            if quad_count > 0:
                made_hand_bonus = 0.9
            elif trip_count > 0:
                made_hand_bonus = 0.7
            elif pair_count >= 2:
                made_hand_bonus = 0.5  # Two pair
            elif pair_count == 1:
                made_hand_bonus = 0.3  # One pair
                
            return min(1.0, 0.2 + pair_bonus + connected_bonus + suited_bonus + 
                      high_card_bonus + position_bonus + made_hand_bonus)
        
        # Preflop evaluation
        base_strength = (high_card + low_card) / 28  # Normalize by max possible (14+14=28)
        return min(1.0, base_strength + pair_bonus + connected_bonus + suited_bonus + high_card_bonus + position_bonus)

    def _calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        """Calculate pot odds (ratio of call amount to total pot after call)"""
        if call_amount <= 0:
            return 0
        total_pot_after_call = pot_size + call_amount
        return call_amount / total_pot_after_call if total_pot_after_call > 0 else 0

    def _is_aggressive_opponent(self, player_id: int) -> bool:
        """Check if an opponent is aggressive based on stats"""
        if player_id in self.player_stats:
            return self.player_stats[player_id]['aggression'] > 0.6
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update stack
            self.my_stack = remaining_chips
            
            # Get current betting information
            current_bet = round_state.current_bet
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_current_bet
            
            # Determine hole cards
            hole_cards = getattr(self, 'hole_cards', [])
            
            # Evaluate hand strength
            hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(call_amount, round_state.pot)
            
            # Adjust strategy based on game stage
            stage_multiplier = 1.0
            if round_state.round == 'Preflop':
                stage_multiplier = 1.0
            elif round_state.round == 'Flop':
                stage_multiplier = 1.2
            elif round_state.round == 'Turn':
                stage_multiplier = 1.1
            elif round_state.round == 'River':
                stage_multiplier = 1.0
            
            # Position factor (later position is better)
            position_factor = 1.0 + (self.position / max(self.num_players, 1)) * 0.3
            
            # Stack size relative to blinds
            stack_to_blind_ratio = remaining_chips / max(round_state.min_raise, 10)
            stack_factor = min(1.0, stack_to_blind_ratio / 20)  # Normalize
            
            # Aggression factor based on opponents
            opponent_aggression = 0
            active_opponents = 0
            for player_id, bet in round_state.player_bets.items():
                if int(player_id) != self.id and bet > 0:
                    if self._is_aggressive_opponent(int(player_id)):
                        opponent_aggression += 1
                    active_opponents += 1
            
            aggression_factor = 1.0 - (opponent_aggression / max(active_opponents, 1)) * 0.3
            
            # Combined decision factors
            threshold = hand_strength * stage_multiplier * position_factor * stack_factor * aggression_factor
            
            # Decision making
            if call_amount == 0:
                # We can check
                if hand_strength > 0.3:
                    # Strong enough to bet
                    raise_amount = int(round_state.min_raise * (1.5 + hand_strength))
                    if raise_amount <= round_state.max_raise and raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif round_state.max_raise > 0:
                        return (PokerAction.ALL_IN, 0)  # Will be converted to ALL_IN
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # We need to call, fold, or raise
                if threshold > pot_odds * 1.5:  # Good pot odds
                    if threshold > 0.7 and round_state.max_raise > call_amount * 2:
                        # Strong hand, raise
                        raise_multiplier = 2.0 + (threshold * 2)
                        raise_amount = int(call_amount + (call_amount * raise_multiplier))
                        raise_amount = min(raise_amount, round_state.max_raise)
                        raise_amount = max(raise_amount, round_state.min_raise)
                        
                        if raise_amount <= round_state.max_raise and raise_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, raise_amount)
                        elif remaining_chips > call_amount:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.ALL_IN, 0)
                    elif remaining_chips > call_amount:
                        # Just call
                        return (PokerAction.CALL, 0)
                    else:
                        # All-in with good odds
                        return (PokerAction.ALL_IN, 0)
                elif threshold > pot_odds * 0.8:  # Marginal pot odds
                    if remaining_chips > call_amount:
                        # Small call with decent hand
                        if call_amount <= remaining_chips * 0.1:  # Less than 10% of stack
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.ALL_IN, 0) if threshold > 0.5 else (PokerAction.FOLD, 0)
                else:
                    # Bad pot odds, fold
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Safe fallback
            try:
                current_bet = round_state.current_bet
                my_current_bet = round_state.player_bets.get(str(self.id), 0)
                call_amount = current_bet - my_current_bet
                
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= remaining_chips * 0.05:  # Very small call
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update player statistics based on the round
        try:
            # Update aggression stats for opponents
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.player_stats:
                    if action in ['RAISE', 'BET']:
                        self.player_stats[player_id]['aggression'] = min(1.0, 
                            self.player_stats[player_id]['aggression'] * 0.9 + 0.1)
                    elif action == 'FOLD':
                        self.player_stats[player_id]['fold_frequency'] = min(1.0, 
                            self.player_stats[player_id]['fold_frequency'] * 0.9 + 0.1)
        except:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game if needed
        pass