from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.is_button = False
        self.blind_amount = 0
        self.all_players = []
        self.rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank_str = card[0]
        suit = card[1]
        rank = self.rank_map.get(rank_str, 0)
        return rank, suit

    def chen_formula(self, cards: List[str]) -> int:
        r1, s1 = self.parse_card(cards[0])
        r2, s2 = self.parse_card(cards[1])
        if r1 < r2:
            r1, r2 = r2, r1
        high = r1

        def get_rank_value(r):
            vals = {14:10, 13:8, 12:7, 11:6, 10:5, 9:4.5, 8:4, 7:3.5, 6:3, 5:2.5, 4:2, 3:1.5, 2:1}
            return vals.get(r, 0)

        score = get_rank_value(high)
        if r1 == r2:
            score *= 2
            if score < 5:
                score = 5
            return round(score)

        if s1 == s2:
            score += 2

        gap = r1 - r2
        if gap == 0:
            gap_bonus = 2
        elif gap == 1:
            gap_bonus = 1
        elif gap == 2:
            gap_bonus = 0
        elif gap == 3:
            gap_bonus = -1
        else:
            gap_bonus = -2
        score += gap_bonus

        if gap < 2 and high <= 12:
            score += 1

        if score - int(score) < 0.5:
            score = int(score)
        else:
            score = int(score) + 1
        return score

    def evaluate_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        cards = hole + community
        parsed = [self.parse_card(c) for c in cards]
        parsed.sort(key=lambda x: -x[0])
        ranks = [p[0] for p in parsed]
        suits = [p[1] for p in parsed]
        unique_ranks = sorted(set(ranks), reverse=True)

        # Suit counts for flush
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        flush_suit = next((s for s, cnt in suit_count.items() if cnt >= 5), None)
        is_flush = flush_suit is not None

        # Straight
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i + 4] == 4:
                    straight_high = unique_ranks[i]
                    break
        if straight_high == 0 and all(r in unique_ranks for r in [14, 5, 4, 3, 2]):
            straight_high = 5
        is_straight = straight_high > 0

        # Straight flush
        is_straight_flush = False
        royal = False
        sf_high = 0
        if is_flush and is_straight:
            flush_cards = [p for p in parsed if p[1] == flush_suit]
            flush_ranks = [p[0] for p in flush_cards]
            unique_flush = sorted(set(flush_ranks), reverse=True)
            if len(unique_flush) >= 5:
                for i in range(len(unique_flush) - 4):
                    if unique_flush[i] - unique_flush[i + 4] == 4:
                        sf_high = unique_flush[i]
                        break
            if sf_high == 0 and all(r in unique_flush for r in [14, 5, 4, 3, 2]):
                sf_high = 5
            if sf_high > 0:
                is_straight_flush = True
                if sf_high == 14:
                    royal = True

        # Rank counts
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1

        four_rank = next((r for r, cnt in rank_count.items() if cnt == 4), None)
        threes = [r for r, cnt in rank_count.items() if cnt == 3]
        three_rank = threes[0] if threes else None
        pairs = sorted([r for r, cnt in rank_count.items() if cnt == 2], reverse=True)
        is_full = three_rank is not None and pairs

        if royal:
            return 9, [14]
        elif is_straight_flush:
            return 8, [sf_high]
        elif four_rank:
            kicker = max(r for r in unique_ranks if r != four_rank)
            return 7, [four_rank, kicker]
        elif is_full:
            return 6, [three_rank, pairs[0]]
        elif is_flush:
            flush_ranks = sorted([r for r, s in parsed if s == flush_suit], reverse=True)[:5]
            return 5, flush_ranks
        elif is_straight:
            return 4, [5] if straight_high == 5 else [straight_high]
        elif three_rank:
            kickers = sorted([r for r in unique_ranks if r != three_rank], reverse=True)[:2]
            return 3, [three_rank] + kickers
        elif len(pairs) >= 2:
            top_two = pairs[:2]
            kicker = max([r for r in unique_ranks if r not in top_two] or [0])
            return 2, top_two + [kicker]
        elif len(pairs) == 1:
            pair_r = pairs[0]
            kickers = sorted([r for r in unique_ranks if r != pair_r], reverse=True)[:3]
            return 1, [pair_r] + kickers
        else:
            high_cards = unique_ranks[:5]
            return 0, high_cards

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.is_button = self.id == small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        num_active = len(round_state.current_player)
        is_heads_up = num_active == 2

        if round_state.round == 'Preflop':
            chen = self.chen_formula(self.hole_cards)
            threshold_fold = 5 if is_heads_up else 8
            threshold_raise = 10 if is_heads_up else 12
            threshold_reraise = 14 if is_heads_up else 16

            if to_call == 0:
                if chen >= threshold_raise:
                    desired_total = round_state.current_bet + max(2 * self.blind_amount * 2, round_state.min_raise)
                    desired_total = min(desired_total, my_bet + remaining_chips)
                    amount = desired_total - my_bet
                    if amount <= 0 or desired_total < round_state.current_bet + round_state.min_raise:
                        return PokerAction.CHECK, 0
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CHECK, 0
            else:
                if chen >= threshold_reraise and to_call > 0:
                    if remaining_chips <= to_call:
                        return PokerAction.ALL_IN, 0
                    desired_total = round_state.current_bet + max(pot, round_state.min_raise)
                    desired_total = min(desired_total, my_bet + remaining_chips)
                    amount = desired_total - my_bet
                    if amount > to_call and desired_total >= round_state.current_bet + round_state.min_raise:
                        return PokerAction.RAISE, amount
                    else:
                        return PokerAction.ALL_IN, 0
                elif chen >= threshold_fold and to_call <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            hand_type, _ = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            is_good = hand_type >= 1
            is_very_good = hand_type >= 3

            if to_call == 0:
                if is_good:
                    desired_total = round_state.current_bet + max(pot, round_state.min_raise)
                    desired_total = min(desired_total, my_bet + remaining_chips)
                    amount = desired_total - my_bet
                    if amount > 0 and desired_total >= round_state.current_bet + round_state.min_raise:
                        return PokerAction.RAISE, amount
                if random.random() < 0.2 and is_heads_up:  # bluff sometimes
                    desired_total = round_state.current_bet + max(self.blind_amount * 2, round_state.min_raise)
                    desired_total = min(desired_total, my_bet + remaining_chips)
                    amount = desired_total - my_bet
                    if amount > 0 and desired_total >= round_state.current_bet + round_state.min_raise:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0
            else:
                if remaining_chips <= to_call:
                    if is_good:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
                if is_very_good:
                    desired_total = round_state.current_bet + max(pot, round_state.min_raise)
                    desired_total = min(desired_total, my_bet + remaining_chips)
                    amount = desired_total - my_bet
                    if amount > to_call and desired_total >= round_state.current_bet + round_state.min_raise:
                        return PokerAction.RAISE, amount
                    else:
                        return PokerAction.CALL, 0
                elif is_good:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass