from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.all_players = all参见_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def parse_card(self, card: str) -> Tuple[int, str]:
        rank_str = card[0]
        suit = card[1]
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[rank_str], suit

    def evaluate_five_cards(self, ranks: List[int], suits: List[str]) -> Tuple[int, List[int]]:
        ranks = sorted(ranks, reverse=True)
        is_flush = len(set(suits)) == 1
        rank_set = set(ranks)
        is_straight = (len(rank_set) == 5) and (max(ranks) - min(ranks) == 4)
        if set(ranks) == {14, 5, 4, 3, 2}:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]  # Wheel straight ranked low

        if is_straight and is_flush:
            if ranks[0] == 14 and ranks == [14, 13, 12, 11, 10]:
                return 9, ranks  # Royal flush
            return 8, sorted(ranks, reverse=True)  # Straight flush

        from collections import Counter
        count = Counter(ranks)

        if 4 in count.values():
            quad_rank = next(r for r, c in count.items() if c == 4)
            kicker = next(r for r, c in count.items() if c == 1)
            return 7, [quad_rank, kicker]  # Quads

        if 3 in count.values() and 2 in count.values():
            three_rank = next(r for r, c in count.items() if c == 3)
            pair_rank = next(r for r, c in count.items() if c == 2)
            return 6, [three_rank, pair_rank]  # Full house

        if is_flush:
            return 5, ranks  # Flush

        if is_straight:
            return 4, ranks  # Straight

        if 3 in count.values():
            three_rank = next(r for r, c in count.items() if c == 3)
            kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
            return 3, [three_rank] + kickers  # Trips

        pairs = [r for r, c in count.items() if c == 2]
        if len(pairs) == 2:
            pairs = sorted(pairs, reverse=True)
            kicker = next(r for r, c in count.items() if c == 1)
            return 2, pairs + [kicker]  # Two pair

        if len(pairs) == 1:
            pair_rank = pairs[0]
            kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
            return 1, [pair_rank] + kickers  # Pair

        return 0, ranks  # High card

    def evaluate_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        if len(hole) != 2:
            return (0, [])
        all_cards = [self.parse_card(c) for c in hole + community]
        num_cards = len(all_cards)
        best = (0, [])

        if num_cards < 5:
            ranks = sorted([r for r, s in all_cards], reverse=True)
            return (0, ranks)  # High card for preflop

        for comb in itertools.combinations(all_cards, 5):
            ranks = [r for r, s in comb]
            suits = [s for r, s in comb]
            current = self.evaluate_five_cards(ranks, suits)
            if current > best:
                best = current
        return best

    def get_preflop_strength(self, hole: List[str]) -> int:
        ranks = sorted([self.parse_card(c)[0] for c in hole], reverse=True)
        r1, r2 = ranks
        suited = self.parse_card(hole[0])[1] == self.parse_card(hole[1])[1]
        if r1 == r2:
            if r1 >= 10:
                return 2
            if r1 >= 5:
                return 1
            return 0
        if suited:
            if r1 >= 13 or (r1 >= 11 and r1 - r2 <= 3):
                return 2 if r1 >= 13 else 1
        else:
            if r1 >= 13 and r2 >= 12:
                return 2
            if r1 >= 12 and r2 >= 10 and r1 - r2 <= 4:
                return 1
        return 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        num_active = len(round_state.current_player)
        phase = round_state.round

        if phase == 'Preflop':
            strength_level = self.get_preflop_strength(self.hole_cards)
            win_prob = 0.2 + strength_level * 0.3
        else:
            hand_tuple = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            hand_type, tiebreakers = hand_tuple
            if hand_type >= 6:
                win_prob = 0.9
            elif hand_type >= 4:
                win_prob = 0.7
            elif hand_type == 3:
                win_prob = 0.5
            elif hand_type == 2:
                win_prob = 0.4
            elif hand_type == 1:
                pair = tiebreakers[0]
                community_ranks = [self.parse_card(c)[0] for c in round_state.community_cards]
                top_board = max(community_ranks + [0])
                win_prob = 0.3 if pair > top_board or pair >= 12 else 0.2
            else:
                win_prob = 0.1
            win_prob /= max(1, (num_active - 1) * 0.5 + 0.0001)

        odds = to_call / (pot + to_call + 0.0001)

        if to_call == 0:
            if win_prob > 0.4:
                bet_size = max(self.blind_amount * 2, int(pot * 0.5))
                amount = max(min_raise, bet_size)
                amount = min(amount, max_raise)
                if amount <= remaining_chips:
                    return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0
        else:
            can_call = to_call <= remaining_chips
            if win_prob > odds + 0.1:
                raise_size = max(self.blind_amount * 3, int((pot + to_call) * 0.6))
                amount = max(min_raise, raise_size)
                amount = min(amount, max_raise)
                cost = to_call + amount
                if cost <= remaining_chips:
                    return PokerAction.RAISE, amount
                elif win_prob > odds:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            elif win_prob > odds:
                if can_call:
                    return PokerAction.CALL, 0
                else:
                    if win_prob > 0.5:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass