from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
from itertools import combinations

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hand = []
        self.all_players = []
        self.big_blind = 0
        self.starting_chips = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_hand = player_hands
        self.all_players = all_players
        self.big_blind = blind_amount
        self.starting_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        stack = remaining_chips
        min_r = round_state.min_raise
        max_r = round_state.max_raise
        phase = round_state.round

        ranks = '23456789TJQKA'

        if phase == 'Preflop':
            if len(self.my_hand) != 2:
                return PokerAction.FOLD, 0
            card1, card2 = sorted(self.my_hand, key=lambda c: ranks.index(c[0]), reverse=True)
            r1, r2 = card1[0], card2[0]
            suited = card1[1] == card2[1]
            paired = r1 == r2
            rank_idx1 = ranks.index(r1)
            rank_idx2 = ranks.index(r2)
            if paired and rank_idx1 >= 8:
                strength = 0.9
            elif paired:
                strength = 0.5
            elif suited and rank_idx1 >= 10 and rank_idx2 >= 7:
                strength = 0.6
            elif rank_idx1 >= 10 and rank_idx2 >= 9:
                strength = 0.4
            else:
                strength = 0.1
        else:
            rank_tuple = self.evaluate_best(self.my_hand, round_state.community_cards)
            rank_type = rank_tuple[0]
            strength = rank_type / 9.0

        if to_call > 0:
            if phase == 'Preflop' and to_call > 4 * self.big_blind and strength < 0.7:
                return PokerAction.FOLD, 0
            pot_odds = to_call / (pot + to_call + 1e-6)
            if strength > pot_odds * 1.5:
                if strength > 0.7 and to_call < stack * 0.2:
                    raise_by = max(min_r, pot // 2)
                    raise_by = min(raise_by, max_r)
                    if raise_by <= stack:
                        return PokerAction.RAISE, raise_by
                    else:
                        if stack > to_call:
                            return PokerAction.ALL_IN, 0
                        else:
                            if strength > 0.8:
                                return PokerAction.ALL_IN, 0
                            else:
                                return PokerAction.FOLD, 0
                if to_call <= stack:
                    return PokerAction.CALL, 0
                else:
                    if strength > 0.8:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if strength > 0.5:
                raise_by = max(min_r, pot // 3)
                raise_by = min(raise_by, max_r)
                if raise_by <= stack:
                    return PokerAction.RAISE, raise_by
                else:
                    return PokerAction.ALL_IN, 0
            else:
                return PokerAction.CHECK, 0

    def evaluate_best(self, hole: List[str], community: List[str]):
        total = hole + community
        if len(total) < 5:
            return (0, [])
        best = (-1, [])
        for combo in combinations(total, 5):
            current = self.evaluate(list(combo))
            if current > best:
                best = current
        return best

    def evaluate(self, cards: List[str]) -> Tuple[int, List[int]]:
        rank_map = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
        card_tuples = [(rank_map[c[0]], c[1]) for c in cards]
        card_tuples.sort(reverse=True)
        ranks = [r for r, s in card_tuples]
        suits = [s for r, s in card_tuples]
        is_flush = all(s == suits[0] for s in suits)
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4 or ranks == [12, 3, 2, 1, 0])
        rank_count = Counter(ranks)
        counts = sorted(rank_count.values(), reverse=True)

        if is_flush and is_straight:
            if ranks == [12, 11, 10, 9, 8]:
                return 9, ranks
            return 8, [ranks[0]] if not ranks == [12, 3, 2, 1, 0] else [4]

        if counts[0] == 4:
            quad = next(r for r, c in rank_count.items() if c == 4)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return 7, [quad, kicker]

        if counts == [3, 2]:
            trips = next(r for r, c in rank_count.items() if c == 3)
            pair_r = next(r for r, c in rank_count.items() if c == 2)
            return 6, [trips, pair_r]

        if is_flush:
            return 5, ranks

        if is_straight:
            high = 4 if ranks == [12, 3, 2, 1, 0] else ranks[0]
            return 4, [high]

        if counts[0] == 3:
            trips = next(r for r, c in rank_count.items() if c == 3)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 3, [trips] + kickers

        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return 2, pairs + [kicker]

        if counts[0] == 2:
            pair_r = next(r for r, c in rank_count.items() if c == 2)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 1, [pair_r] + kickers

        return 0, ranks

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass