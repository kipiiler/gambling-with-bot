from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.small_blind = 0
        self.big_blind = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.small_blind = blind_amount
        self.big_blind = 2 * blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        def parse_card(card: str) -> Tuple[int, str]:
            rank_str = card[0]
            suit = card[1]
            rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
            rank = rank_map[rank_str]
            return rank, suit

        def evaluate_hand(cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
            cards = sorted(cards, key=lambda x: x[0], reverse=True)
            ranks = [c[0] for c in cards]
            suits = [c[1] for c in cards]
            is_flush = all(s == suits[0] for s in suits)
            is_straight = False
            straight_ranks = ranks[:]
            if len(set(ranks)) == 5:
                if max(ranks) - min(ranks) == 4:
                    is_straight = True
                elif set(ranks) == {14, 5, 4, 3, 2}:
                    is_straight = True
                    straight_ranks = [5, 4, 3, 2, 1]
            rank_counts = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1
            if is_flush and is_straight:
                if ranks == [14, 13, 12, 11, 10]:
                    return 10, ranks
                else:
                    return 9, straight_ranks
            if 4 in rank_counts.values():
                quad_rank = [k for k, v in rank_counts.items() if v == 4][0]
                kicker = [k for k, v in rank_counts.items() if v == 1][0]
                return 8, [quad_rank, kicker]
            if 3 in rank_counts.values() and 2 in rank_counts.values():
                trip = [k for k, v in rank_counts.items() if v == 3][0]
                pair = [k for k, v in rank_counts.items() if v == 2][0]
                return 7, [trip, pair]
            if is_flush:
                return 6, ranks
            if is_straight:
                return 5, straight_ranks
            if 3 in rank_counts.values():
                trip = [k for k, v in rank_counts.items() if v == 3][0]
                kickers = sorted([k for k, v in rank_counts.items() if v == 1], reverse=True)
                return 4, [trip] + kickers
            if list(rank_counts.values()).count(2) == 2:
                pairs = sorted([k for k, v in rank_counts.items() if v == 2], reverse=True)
                kicker = [k for k, v in rank_counts.items() if v == 1][0]
                return 3, pairs + [kicker]
            if 2 in rank_counts.values():
                pair = [k for k, v in rank_counts.items() if v == 2][0]
                kickers = sorted([k for k, v in rank_counts.items() if v == 1], reverse=True)
                return 2, [pair] + kickers
            return 1, ranks

        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call <= 0
        pot = round_state.pot
        community = round_state.community_cards
        my_hole = [parse_card(c) for c in self.hole_cards]
        comm_parsed = [parse_card(c) for c in community]
        all_parsed = my_hole + comm_parsed
        is_preflop = len(community) == 0

        if is_preflop:
            r1, s1 = my_hole[0]
            r2, s2 = my_hole[1]
            ranks = sorted([r1, r2], reverse=True)
            suited = s1 == s2
            paired = r1 == r2
            score = ranks[0] + ranks[1]
            if suited:
                score += 5
            if paired:
                score += 10
            if score >= 26:
                raise_amount = max(round_state.min_raise, self.big_blind * 3)
                raise_amount = min(raise_amount, round_state.max_raise)
                if raise_amount >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                elif can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, 0
            elif score >= 20:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= self.big_blind * 2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            best_type = 0
            best_ranks = []
            if len(all_parsed) >= 5:
                for combo in itertools.combinations(all_parsed, 5):
                    typ, rnks = evaluate_hand(list(combo))
                    if typ > best_type or (typ == best_type and rnks > best_ranks):
                        best_type = typ
                        best_ranks = rnks
            if best_type >= 4:
                raise_amount = max(round_state.min_raise, pot // 2)
                raise_amount = min(raise_amount, round_state.max_raise)
                if raise_amount == round_state.max_raise and raise_amount >= pot:
                    return PokerAction.ALL_IN, 0
                if raise_amount >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                elif to_call > 0:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.CHECK, 0
            elif best_type == 3:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if to_call < pot / 4 + 0.0001:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif best_type == 2:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if to_call < pot / 10 + 0.0001:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass