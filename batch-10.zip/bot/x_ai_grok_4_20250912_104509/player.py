from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        min_r = round_state.min_raise
        max_r = round_state.max_raise
        pot = round_state.pot
        phase = round_state.round
        community = round_state.community_cards

        if remaining_chips == 0:
            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

        # Compute strength
        if phase == 'Preflop':
            strength = self.starting_strength(self.hole_cards)
        else:
            best_hand = self.get_best_hand(self.hole_cards, community)
            if best_hand is None:
                strength = 0
            else:
                (hand_type, _) = best_hand
                strength = hand_type  # 0 to 9

        # Decide action
        if to_call == 0:
            # Can check or bet
            if strength >= 2:
                # Bet
                bet_size = 3 * self.blind_amount if phase == 'Preflop' else int(pot * 0.7) + 1  # avoid zero
                total_bet = my_bet + bet_size
                if total_bet < min_r:
                    total_bet = min_r
                if total_bet > max_r:
                    if max_r >= min_r:
                        return (PokerAction.RAISE, max_r)
                    else:
                        return (PokerAction.CHECK, 0)
                return (PokerAction.RAISE, total_bet)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Can fold, call, raise
            if strength >= 2:
                # Try to raise
                raise_size = max(to_call * 2, self.blind_amount * 3)
                total_bet = my_bet + to_call + raise_size
                if total_bet < min_r:
                    total_bet = min_r
                if total_bet > max_r:
                    # Can't raise that much
                    if to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0) if remaining_chips > 0 else (PokerAction.FOLD, 0)
                return (PokerAction.RAISE, total_bet)
            elif strength >= 1 and to_call < pot * 0.3:
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0) if remaining_chips > 0 else (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def card_rank(self, card: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]

    def card_suit(self, card: str) -> str:
        return card[1]

    def starting_strength(self, hole: List[str]) -> int:
        if len(hole) != 2:
            return 0
        r1 = self.card_rank(hole[0])
        r2 = self.card_rank(hole[1])
        if r1 < r2:
            r1, r2 = r2, r1
        suited = self.card_suit(hole[0]) == self.card_suit(hole[1])
        if r1 == r2:
            if r1 >= 11:
                return 4
            if r1 >= 8:
                return 3
            if r1 >= 5:
                return 2
            return 1
        diff = r1 - r2
        if suited:
            if r1 == 14 and r2 >= 10:
                return 4
            if r1 == 13 and r2 >= 10:
                return 3
            if diff <= 4:
                return 2
            return 1
        else:
            if r1 == 14 and r2 >= 12:
                return 3
            if r1 == 13 and r2 == 12:
                return 2
            return 0

    def get_best_hand(self, hole: List[str], community: List[str]):
        if len(hole) != 2 or len(community) < 3:
            return None
        all_cards = hole + community
        best = (0, [])
        for five in itertools.combinations(all_cards, 5):
            val = self._hand_value(list(five))
            if val > best:
                best = val
        return best

    def _hand_value(self, five_cards: List[str]):
        ranks = sorted([self.card_rank(c) for c in five_cards], reverse=True)
        suits = [self.card_suit(c) for c in five_cards]
        is_flush = len(set(suits)) == 1
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4 or ranks == [14, 5, 4, 3, 2])

        if is_flush and is_straight and ranks == [14, 13, 12, 11, 10]:
            return (9, [14])

        high = ranks[0] if not (ranks == [14, 5, 4, 3, 2]) else 5
        if is_flush and is_straight:
            return (8, [high])

        count = {}
        for r in ranks:
            count[r] = count.get(r, 0) + 1
        sorted_counts = sorted(count.values(), reverse=True)

        quad_rank = trips_rank = pair_rank = second_pair = 0
        kickers = []
        for r, cnt in count.items():
            if cnt == 4:
                quad_rank = r
            elif cnt == 3:
                trips_rank = r
            elif cnt == 2:
                if pair_rank == 0:
                    pair_rank = r
                else:
                    second_pair = r
            else:
                kickers.append(r)
        kickers = sorted(kickers, reverse=True)

        if quad_rank:
            return (7, [quad_rank, kickers[0]])
        if trips_rank and pair_rank:
            return (6, [trips_rank, pair_rank])
        if is_flush:
            return (5, ranks)
        if is_straight:
            return (4, [high])
        if trips_rank:
            return (3, [trips_rank] + kickers[:2])
        if pair_rank and second_pair:
            pairs = sorted([pair_rank, second_pair], reverse=True)
            return (2, pairs + kickers[:1])
        if pair_rank:
            return (1, [pair_rank] + kickers[:3])
        return (0, ranks)