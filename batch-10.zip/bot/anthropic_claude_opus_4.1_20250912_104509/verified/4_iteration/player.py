from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.hand_count = 0
        self.opponent_stats = {}
        self.last_aggressive_hand = 0
        self.opponent_fold_rate = 0.5
        self.opponent_aggression = 0.5
        self.position = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.hand_count = 0
        self.position = 'BB' if big_blind_player_id == self.id else 'SB'
        for pid in all_players:
            if pid != self.id:
                if pid not in self.opponent_stats:
                    self.opponent_stats[pid] = {
                        'fold_count': 0,
                        'raise_count': 0,
                        'call_count': 0,
                        'check_count': 0,
                        'total_actions': 0,
                        'showdown_wins': 0,
                        'showdown_losses': 0
                    }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate pot odds
        pot = round_state.pot
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_odds = to_call / (pot + to_call + 0.001) if to_call > 0 else 0
        
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Determine aggression level based on position and opponent tendencies
        aggression_factor = self._calculate_aggression_factor(round_state, remaining_chips)
        
        # Decision making with more aggression
        if round_state.round == "Preflop":
            return self._get_preflop_action(round_state, remaining_chips, hand_strength, aggression_factor)
        else:
            return self._get_postflop_action(round_state, remaining_chips, hand_strength, pot_odds, aggression_factor)
    
    def _calculate_aggression_factor(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        # Base aggression
        base_aggression = 0.5
        
        # Position bonus
        if self.position == 'SB' and round_state.round == "Preflop":
            base_aggression += 0.2  # More aggressive in position
            
        # Stack size adjustment
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        if stack_ratio > 1.2:  # Big stack
            base_aggression += 0.15
        elif stack_ratio < 0.5:  # Short stack
            base_aggression += 0.25  # Go aggressive when short
            
        # Opponent adjustment
        if self.opponent_fold_rate > 0.6:
            base_aggression += 0.2  # Exploit tight opponents
        elif self.opponent_aggression > 0.7:
            base_aggression -= 0.1  # Tighten up against aggressive opponents
            
        # Random factor to be unpredictable
        base_aggression += random.uniform(-0.1, 0.15)
        
        return min(max(base_aggression, 0.2), 1.0)
    
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, aggression_factor: float) -> Tuple[PokerAction, int]:
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot = round_state.pot
        
        # Premium hands - always raise/reraise
        if hand_strength > 0.85:
            if to_call == 0:
                raise_amount = int(pot * random.uniform(0.6, 1.0))
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            elif to_call < remaining_chips * 0.3:
                raise_amount = int(to_call * random.uniform(2.5, 4.0))
                return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            else:
                return (PokerAction.ALL_IN, 0)
        
        # Strong hands
        elif hand_strength > 0.65:
            if to_call == 0:
                if random.random() < aggression_factor:
                    raise_amount = int(pot * random.uniform(0.5, 0.8))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            elif to_call < remaining_chips * 0.15:
                if random.random() < aggression_factor * 0.7:
                    raise_amount = int(to_call * random.uniform(2.0, 3.0))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength > 0.45:
            if to_call == 0:
                if random.random() < aggression_factor * 0.4:
                    raise_amount = int(pot * random.uniform(0.4, 0.6))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            elif to_call < remaining_chips * 0.08:
                if random.random() < 0.6:
                    return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        
        # Weak hands - occasional bluff
        else:
            if to_call == 0:
                if random.random() < aggression_factor * 0.25:
                    raise_amount = int(pot * random.uniform(0.4, 0.6))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            else:
                if random.random() < aggression_factor * 0.15 and to_call < remaining_chips * 0.05:
                    # Occasional bluff raise
                    raise_amount = int(to_call * random.uniform(2.5, 3.5))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.FOLD, 0)
    
    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, aggression_factor: float) -> Tuple[PokerAction, int]:
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot = round_state.pot
        
        # Adjust hand strength based on board texture
        adjusted_strength = self._adjust_strength_for_board(hand_strength, round_state)
        
        # Very strong hands
        if adjusted_strength > 0.8:
            if to_call == 0:
                # Mix between check-raise and bet
                if random.random() < 0.3:
                    return (PokerAction.CHECK, 0)
                else:
                    raise_amount = int(pot * random.uniform(0.5, 0.9))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
            else:
                if to_call < remaining_chips * 0.5:
                    raise_amount = int(to_call * random.uniform(2.0, 3.5))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                else:
                    return (PokerAction.ALL_IN, 0)
        
        # Good hands
        elif adjusted_strength > 0.6:
            if to_call == 0:
                if random.random() < aggression_factor * 0.7:
                    raise_amount = int(pot * random.uniform(0.4, 0.7))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            else:
                equity = adjusted_strength
                if equity > pot_odds or random.random() < aggression_factor * 0.3:
                    if random.random() < aggression_factor * 0.4:
                        raise_amount = int(to_call * random.uniform(1.5, 2.5))
                        return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Drawing hands or marginal hands
        elif adjusted_strength > 0.35:
            if to_call == 0:
                # Semi-bluff with draws
                if random.random() < aggression_factor * 0.5:
                    raise_amount = int(pot * random.uniform(0.3, 0.5))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            else:
                equity = adjusted_strength + (aggression_factor * 0.1)  # Add bluff equity
                if equity > pot_odds:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                # Pure bluff occasionally
                if random.random() < aggression_factor * 0.2 and round_state.round == "River":
                    raise_amount = int(pot * random.uniform(0.5, 0.8))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.CHECK, 0)
            else:
                # Rare bluff raise
                if random.random() < aggression_factor * 0.1 and to_call < remaining_chips * 0.1:
                    raise_amount = int(to_call * random.uniform(2.0, 3.0))
                    return (PokerAction.RAISE, min(raise_amount, remaining_chips))
                return (PokerAction.FOLD, 0)
    
    def _adjust_strength_for_board(self, base_strength: float, round_state: RoundStateClient) -> float:
        # Adjust strength based on board texture
        community = round_state.community_cards
        if not community:
            return base_strength
            
        # Check for dangerous boards
        suits = [card[1] for card in community]
        ranks = [card[0] for card in community]
        
        # Flush possibility
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        max_suited = max(suit_counts.values()) if suit_counts else 0
        
        # Straight possibility
        rank_values = []
        for rank in ranks:
            if rank == 'A':
                rank_values.append(14)
            elif rank == 'K':
                rank_values.append(13)
            elif rank == 'Q':
                rank_values.append(12)
            elif rank == 'J':
                rank_values.append(11)
            elif rank == 'T':
                rank_values.append(10)
            else:
                try:
                    rank_values.append(int(rank))
                except:
                    pass
        
        if rank_values:
            rank_values.sort()
            straight_potential = len(set(rank_values)) >= 3 and (max(rank_values) - min(rank_values)) <= 4
        else:
            straight_potential = False
        
        # Adjust strength
        adjustment = 0
        if max_suited >= 3:
            adjustment -= 0.1
        if straight_potential:
            adjustment -= 0.1
        if len(set(ranks)) < len(ranks):  # Paired board
            adjustment -= 0.05
            
        return max(0.1, min(1.0, base_strength + adjustment))
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        val1 = rank_values.get(rank1, int(rank1) if rank1.isdigit() else 0)
        val2 = rank_values.get(rank2, int(rank2) if rank2.isdigit() else 0)
        
        # Base strength calculation
        base_strength = (val1 + val2) / 28.0
        
        # Pair bonus
        if rank1 == rank2:
            base_strength += 0.4
            if val1 >= 10:
                base_strength += 0.15
        
        # Suited bonus
        if suit1 == suit2:
            base_strength += 0.1
        
        # Connector bonus
        if abs(val1 - val2) == 1:
            base_strength += 0.08
        elif abs(val1 - val2) == 2:
            base_strength += 0.04
        
        # High card bonus
        if val1 >= 12 or val2 >= 12:
            base_strength += 0.1
        
        # Post-flop adjustments
        if round_state.round != "Preflop" and round_state.community_cards:
            base_strength = self._evaluate_made_hand(round_state, base_strength)
        
        return min(1.0, base_strength)
    
    def _evaluate_made_hand(self, round_state: RoundStateClient, preflop_strength: float) -> float:
        all_cards = self.hole_cards + round_state.community_cards
        
        # Count ranks and suits
        ranks = {}
        suits = {}
        rank_values = []
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            ranks[rank] = ranks.get(rank, 0) + 1
            suits[suit] = suits.get(suit, 0) + 1
            
            if rank == 'A':
                rank_values.append(14)
            elif rank == 'K':
                rank_values.append(13)
            elif rank == 'Q':
                rank_values.append(12)
            elif rank == 'J':
                rank_values.append(11)
            elif rank == 'T':
                rank_values.append(10)
            else:
                try:
                    rank_values.append(int(rank))
                except:
                    pass
        
        rank_values.sort(reverse=True)
        
        # Check for hands
        max_rank_count = max(ranks.values()) if ranks else 0
        max_suit_count = max(suits.values()) if suits else 0
        
        # Four of a kind
        if max_rank_count >= 4:
            return 0.95
        
        # Full house
        if max_rank_count >= 3 and len([r for r in ranks.values() if r >= 2]) >= 2:
            return 0.92
        
        # Flush
        if max_suit_count >= 5:
            return 0.88
        
        # Straight
        if self._has_straight(rank_values):
            return 0.85
        
        # Three of a kind
        if max_rank_count >= 3:
            return 0.75
        
        # Two pair
        pair_count = len([r for r in ranks.values() if r >= 2])
        if pair_count >= 2:
            return 0.65
        
        # One pair
        if max_rank_count >= 2:
            # Check if we have the pair
            for card in self.hole_cards:
                if ranks[card[0]] >= 2:
                    return 0.55 + (self._get_rank_value(card[0]) / 30.0)
            return 0.45
        
        # High card
        hole_values = []
        for card in self.hole_cards:
            val = self._get_rank_value(card[0])
            hole_values.append(val)
        
        return 0.2 + (max(hole_values) / 40.0)
    
    def _has_straight(self, values: List[int]) -> bool:
        if len(values) < 5:
            return False
        
        unique_values = sorted(set(values), reverse=True)
        
        # Check for ace-low straight
        if 14 in unique_values and 2 in unique_values:
            low_straight = [14, 5, 4, 3, 2]
            if all(v in unique_values for v in low_straight):
                return True
        
        # Check for regular straight
        for i in range(len(unique_values) - 4):
            if unique_values[i] - unique_values[i+4] == 4:
                return True
        
        return False
    
    def _get_rank_value(self, rank: str) -> int:
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        return rank_values.get(rank, int(rank) if rank.isdigit() else 0)
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[int(player_id)]
                stats['total_actions'] += 1
                
                if action == 'Fold':
                    stats['fold_count'] += 1
                elif action == 'Raise' or action == 'All-in':
                    stats['raise_count'] += 1
                elif action == 'Call':
                    stats['call_count'] += 1
                elif action == 'Check':
                    stats['check_count'] += 1
                
                # Update opponent tendencies
                if stats['total_actions'] > 5:
                    self.opponent_fold_rate = stats['fold_count'] / (stats['total_actions'] + 0.001)
                    self.opponent_aggression = (stats['raise_count'] + stats.get('all_in_count', 0)) / (stats['total_actions'] + 0.001)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Learn from results
        if player_score > 0:
            self.last_aggressive_hand = self.hand_count
        
        # Update showdown stats
        for player_id in all_scores:
            if player_id != self.id and player_id in self.opponent_stats:
                if all_scores[player_id] > player_score:
                    self.opponent_stats[player_id]['showdown_wins'] = self.opponent_stats[player_id].get('showdown_wins', 0) + 1
                else:
                    self.opponent_stats[player_id]['showdown_losses'] = self.opponent_stats[player_id].get('showdown_losses', 0) + 1