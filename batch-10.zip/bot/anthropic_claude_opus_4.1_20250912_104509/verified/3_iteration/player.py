from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.game_count = 0
        self.opponent_stats = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.game_count += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001) if to_call > 0 else 0
        
        # Get hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Position awareness
        is_button = self.is_button_position(round_state)
        is_big_blind = (self.id == self.big_blind_player)
        
        # Determine action based on street
        if round_state.round == 'Preflop':
            return self.get_preflop_action(hand_strength, round_state, remaining_chips, to_call, pot_odds, is_button)
        else:
            return self.get_postflop_action(hand_strength, round_state, remaining_chips, to_call, pot_odds)
    
    def is_button_position(self, round_state: RoundStateClient) -> bool:
        """Check if we're in button position (last to act)"""
        active_players = [p for p in self.all_players if p in round_state.current_player]
        if len(active_players) == 2:  # Heads-up
            return self.id == self.small_blind_player
        return False
    
    def get_preflop_action(self, hand_strength: float, round_state: RoundStateClient, 
                           remaining_chips: int, to_call: int, pot_odds: float, is_button: bool) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        # Check if we can check
        can_check = (to_call == 0)
        
        # Premium hands (AA, KK, QQ, AK)
        if hand_strength >= 0.85:
            if round_state.current_bet < remaining_chips * 0.15:
                raise_amount = min(int(round_state.pot * 3), remaining_chips)
                if raise_amount > round_state.current_bet:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.ALL_IN, 0)
        
        # Strong hands (JJ, TT, AQ, AJ)
        elif hand_strength >= 0.70:
            if to_call <= remaining_chips * 0.10:
                if random.random() < 0.7:  # Raise 70% of the time
                    raise_amount = min(int(round_state.pot * 2.5), remaining_chips)
                    if raise_amount > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands (99-66, KQ, KJ, QJ, suited connectors)
        elif hand_strength >= 0.50:
            if can_check:
                return (PokerAction.CHECK, 0)
            elif to_call <= remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            elif is_button and to_call <= remaining_chips * 0.08:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands but playable in position
        elif hand_strength >= 0.35 and is_button:
            if can_check:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Trash hands
        else:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def get_postflop_action(self, hand_strength: float, round_state: RoundStateClient, 
                            remaining_chips: int, to_call: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        can_check = (to_call == 0)
        
        # Very strong hands (two pair or better)
        if hand_strength >= 0.80:
            if to_call > 0:
                # Value raise
                raise_amount = min(int(round_state.pot * 0.75), remaining_chips)
                if raise_amount > round_state.current_bet:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            else:
                # Bet for value
                bet_amount = min(int(round_state.pot * 0.6), remaining_chips)
                if bet_amount > 0:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands (top pair, overpair)
        elif hand_strength >= 0.60:
            if to_call <= round_state.pot * 0.5:
                return (PokerAction.CALL, 0)
            elif pot_odds < 0.25:
                return (PokerAction.CALL, 0)
            elif can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Drawing hands or marginal made hands
        elif hand_strength >= 0.40:
            if can_check:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.20:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if can_check:
                # Occasional bluff
                if random.random() < 0.15 and round_state.round == 'River':
                    bluff_amount = min(int(round_state.pot * 0.5), remaining_chips)
                    if bluff_amount > round_state.current_bet:
                        return (PokerAction.RAISE, bluff_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hand or len(self.hand) != 2:
            return 0.3
        
        card1, card2 = self.hand[0], self.hand[1]
        rank1, suit1 = self.parse_card(card1)
        rank2, suit2 = self.parse_card(card2)
        
        if round_state.round == 'Preflop':
            return self.evaluate_preflop_strength(rank1, rank2, suit1 == suit2)
        else:
            return self.evaluate_postflop_strength(round_state.community_cards)
    
    def parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank (2-14) and suit"""
        if not card or len(card) < 2:
            return (2, 's')
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map.get(card[0], 2)
        suit = card[1] if len(card) > 1 else 's'
        return (rank, suit)
    
    def evaluate_preflop_strength(self, rank1: int, rank2: int, suited: bool) -> float:
        """Evaluate preflop hand strength"""
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        gap = high_rank - low_rank
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 12:  # QQ+
                return 0.90
            elif rank1 >= 10:  # TT-JJ
                return 0.75
            elif rank1 >= 7:  # 77-99
                return 0.60
            else:  # 22-66
                return 0.50
        
        # High cards
        if high_rank == 14:  # Ace high
            if low_rank >= 12:  # AQ+
                return 0.80 if suited else 0.75
            elif low_rank >= 10:  # AT-AJ
                return 0.65 if suited else 0.60
            else:
                return 0.45 if suited else 0.40
        
        if high_rank == 13:  # King high
            if low_rank >= 11:  # KJ+
                return 0.65 if suited else 0.60
            elif low_rank >= 9:
                return 0.50 if suited else 0.45
            else:
                return 0.35 if suited else 0.30
        
        # Connected cards
        if gap <= 1:  # Connectors
            if high_rank >= 10:
                return 0.55 if suited else 0.50
            else:
                return 0.45 if suited else 0.40
        
        # Default
        return 0.35 if suited else 0.25
    
    def evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if not community_cards:
            return 0.5
        
        all_cards = self.hand + community_cards
        
        # Simple hand evaluation
        ranks = []
        suits = []
        for card in all_cards:
            if card and len(card) >= 2:
                rank, suit = self.parse_card(card)
                ranks.append(rank)
                suits.append(suit)
        
        if not ranks:
            return 0.3
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        # Check for pairs, trips, etc.
        max_count = max(rank_counts.values()) if rank_counts else 1
        
        if max_count >= 4:  # Four of a kind
            return 0.95
        elif max_count == 3:  # Three of a kind
            if len([c for c in rank_counts.values() if c >= 2]) >= 2:  # Full house
                return 0.90
            return 0.75
        elif max_count == 2:  # Pair(s)
            pairs = [r for r, c in rank_counts.items() if c == 2]
            if len(pairs) >= 2:  # Two pair
                return 0.70
            elif pairs:
                # Check if we have top pair
                board_ranks = [self.parse_card(c)[0] for c in community_cards if c]
                if board_ranks and pairs[0] >= max(board_ranks):
                    return 0.65
                return 0.55
        
        # Check for flush
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        if any(count >= 5 for count in suit_counts.values()):
            return 0.85
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    return 0.80
        
        # High card
        my_ranks = [self.parse_card(c)[0] for c in self.hand if c]
        if my_ranks and max(my_ranks) >= 12:  # High card Q+
            return 0.40
        
        return 0.30
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass