from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_strength_cache = {}
        self.opponent_stats = {}
        self.round_aggression = {}
        self.position = 0
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hands_played += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_stats:
                self.opponent_stats[player_id] = {
                    'vpip': 0,  # Voluntarily put in pot
                    'pfr': 0,   # Pre-flop raise
                    'aggression': 0,  # Overall aggression factor
                    'hands': 0
                }
        
        # Calculate position
        if self.id == small_blind_player_id:
            self.position = 0
        elif self.id == big_blind_player_id:
            self.position = 1
        else:
            self.position = 2 + all_players.index(self.id)
            
        self.round_aggression = {'Preflop': 0, 'Flop': 0, 'Turn': 0, 'River': 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats based on actions
        self._update_opponent_stats(round_state)
        
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Estimate hand strength
        hand_strength = self._estimate_hand_strength(round_state)
        
        # Get position-adjusted strategy
        action, amount = self._get_strategic_action(
            round_state, remaining_chips, hand_strength, pot_odds
        )
        
        # Validate and adjust action
        return self._validate_action(action, amount, round_state, remaining_chips)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id == str(self.id):
                continue
            
            pid = int(player_id)
            if pid not in self.opponent_stats:
                self.opponent_stats[pid] = {
                    'vpip': 0, 'pfr': 0, 'aggression': 0, 'hands': 0
                }
            
            stats = self.opponent_stats[pid]
            
            if round_state.round == 'Preflop':
                if action in ['Call', 'Raise', 'All_in']:
                    stats['vpip'] += 1
                if action in ['Raise', 'All_in']:
                    stats['pfr'] += 1
                stats['hands'] += 1
            
            if action in ['Raise', 'All_in']:
                stats['aggression'] += 2
            elif action == 'Call':
                stats['aggression'] += 0.5
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int):
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return float('inf')
        
        pot_after_call = round_state.pot + call_amount
        return pot_after_call / (call_amount + 0.001)
    
    def _estimate_hand_strength(self, round_state: RoundStateClient):
        # Cache key for performance
        cache_key = (tuple(self.hole_cards), tuple(round_state.community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        # Basic hand strength evaluation
        strength = 0.5
        
        if not round_state.community_cards:  # Preflop
            strength = self._evaluate_preflop_strength()
        else:
            strength = self._evaluate_postflop_strength(round_state.community_cards)
        
        # Adjust for number of opponents
        num_opponents = len([p for p in round_state.current_player if p != self.id])
        strength = strength ** max(1, num_opponents)
        
        self.hand_strength_cache[cache_key] = strength
        return strength
    
    def _evaluate_preflop_strength(self):
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Premium hands
        if (rank1 >= 12 and rank2 >= 12) or (rank1 == 14 and rank2 >= 10) or (rank2 == 14 and rank1 >= 10):
            return 0.85 + (0.05 if suited else 0)
        
        # Good hands
        if rank1 >= 10 and rank2 >= 10:
            return 0.7 + (0.05 if suited else 0)
        
        # Pairs
        if rank1 == rank2:
            return 0.6 + (rank1 / 30.0)
        
        # Suited connectors
        if suited and abs(rank1 - rank2) == 1:
            return 0.55
        
        # Ace high
        if rank1 == 14 or rank2 == 14:
            return 0.5
        
        # Default
        return 0.35 + (min(rank1, rank2) / 50.0)
    
    def _evaluate_postflop_strength(self, community_cards):
        # Simplified post-flop evaluation
        all_cards = self.hole_cards + community_cards
        
        # Check for made hands
        ranks = [self._card_rank(c) for c in all_cards]
        suits = [c[-1] for c in all_cards]
        
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        # Check for pairs, trips, etc.
        max_same_rank = max(rank_counts.values()) if rank_counts else 0
        max_same_suit = max(suit_counts.values()) if suit_counts else 0
        
        # Flush
        if max_same_suit >= 5:
            return 0.85
        
        # Trips or better
        if max_same_rank >= 3:
            return 0.75
        
        # Two pair
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        if pairs >= 2:
            return 0.65
        
        # One pair
        if max_same_rank == 2:
            pair_rank = max(r for r, c in rank_counts.items() if c == 2)
            return 0.45 + (pair_rank / 40.0)
        
        # High card
        return 0.25 + (max(ranks) / 60.0)
    
    def _card_rank(self, card):
        if not card or len(card) < 1:
            return 2
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            try:
                return int(rank_char)
            except:
                return 2
    
    def _get_strategic_action(self, round_state, remaining_chips, hand_strength, pot_odds):
        # Calculate call amount
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Stack to pot ratio
        spr = remaining_chips / (round_state.pot + 0.001)
        
        # Position advantage
        position_bonus = 0.05 * (self.position / max(1, len(self.all_players)))
        adjusted_strength = hand_strength + position_bonus
        
        # Determine action based on strength and pot odds
        if adjusted_strength > 0.8:
            # Very strong hand - raise aggressively
            if spr < 2:
                return PokerAction.ALL_IN, 0
            else:
                raise_size = min(int(round_state.pot * 0.75), remaining_chips)
                return PokerAction.RAISE, raise_size
        
        elif adjusted_strength > 0.6:
            # Good hand - raise or call
            if pot_odds > 3 and adjusted_strength * pot_odds > 2:
                raise_size = min(int(round_state.pot * 0.5), remaining_chips)
                return PokerAction.RAISE, raise_size
            elif call_amount <= remaining_chips * 0.3:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        elif adjusted_strength > 0.4:
            # Marginal hand - call if good pot odds
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif pot_odds > 2.5 and call_amount <= remaining_chips * 0.2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        else:
            # Weak hand - check or fold
            if call_amount == 0:
                # Occasional bluff
                if random.random() < 0.15 and round_state.round in ['Turn', 'River']:
                    bluff_size = min(int(round_state.pot * 0.4), remaining_chips)
                    return PokerAction.RAISE, bluff_size
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
    
    def _validate_action(self, action, amount, round_state, remaining_chips):
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Validate and adjust actions
        if action == PokerAction.CHECK:
            if call_amount > 0:
                # Can't check when there's a bet to call
                if call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            return PokerAction.CHECK, 0
        
        elif action == PokerAction.CALL:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        
        elif action == PokerAction.RAISE:
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            min_raise_total = round_state.current_bet + round_state.min_raise
            
            # Calculate the actual raise amount (amount to add to current bet)
            if amount <= 0:
                amount = round_state.min_raise
            
            total_bet = my_current_bet + amount
            
            if total_bet < min_raise_total:
                # Adjust to minimum raise
                amount = min_raise_total - my_current_bet
            
            if amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            
            # Ensure raise is valid
            if amount < round_state.min_raise:
                if call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            
            return PokerAction.RAISE, min(amount, remaining_chips)
        
        elif action == PokerAction.ALL_IN:
            return PokerAction.ALL_IN, 0
        
        else:  # FOLD
            return PokerAction.FOLD, 0