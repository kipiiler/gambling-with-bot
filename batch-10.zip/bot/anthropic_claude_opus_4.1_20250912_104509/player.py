from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.game_count = 0
        self.position_stats = {'win': 0, 'loss': 0}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.game_count += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get basic state info
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
            
        # Get hand strength estimate
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Decision logic based on hand strength and pot odds
        if to_call == 0:  # Can check
            if hand_strength > 0.7:
                # Strong hand - try to build pot with proper raise amount
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                if min_raise > 0 and max_raise > 0:
                    # Calculate raise amount based on pot size
                    raise_amount = max(min_raise, min(int(pot * 0.6), max_raise))
                    if raise_amount >= min_raise and raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                # If we can't raise properly, just check
                return (PokerAction.CHECK, 0)
            elif hand_strength > 0.5:
                # Medium hand - check to see more cards
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check if free
                return (PokerAction.CHECK, 0)
        else:  # Need to call, raise, or fold
            # Check if we can afford to call
            if to_call >= remaining_chips:
                # All-in decision
                if hand_strength > 0.6:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            # Regular betting decision
            if hand_strength > 0.75 and pot_odds < 0.4:
                # Very strong hand and good pot odds - consider raising
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                
                # Make sure we can actually raise
                if min_raise > 0 and max_raise > 0 and min_raise <= remaining_chips:
                    # Calculate a proper raise amount
                    target_raise = max(min_raise, min(int(pot * 0.5), max_raise))
                    if target_raise >= min_raise and target_raise <= remaining_chips:
                        return (PokerAction.RAISE, target_raise)
                # If we can't raise, just call
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.5 and pot_odds < 0.3:
                # Decent hand with good pot odds - call
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.4 and pot_odds < 0.2:
                # Marginal hand but very good pot odds - call
                return (PokerAction.CALL, 0)
            else:
                # Weak hand or bad pot odds - fold
                return (PokerAction.FOLD, 0)
                
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on cards and round."""
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[:-1], card1[-1]
        rank2, suit2 = card2[:-1], card2[-1]
        
        # Convert face cards to values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for r in range(2, 10):
            rank_values[str(r)] = r
            
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Base strength from hole cards
        is_pair = (rank1 == rank2)
        is_suited = (suit1 == suit2)
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        gap = high_card - low_card
        
        # Calculate pre-flop strength
        strength = 0.0
        
        if is_pair:
            # Pocket pairs are strong
            strength = 0.5 + (val1 / 14.0) * 0.4
        else:
            # High cards
            strength += (high_card / 14.0) * 0.3
            strength += (low_card / 14.0) * 0.1
            
            # Suited bonus
            if is_suited:
                strength += 0.1
                
            # Connectivity bonus (for straights)
            if gap == 1:
                strength += 0.08
            elif gap == 2:
                strength += 0.05
            elif gap == 3:
                strength += 0.03
                
        # Adjust based on community cards
        community = round_state.community_cards
        if community:
            # Post-flop adjustments
            strength = self._adjust_for_community(strength, community, is_pair, 
                                                 rank1, rank2, suit1, suit2)
                                                 
        # Adjust based on number of active players
        active_players = len([p for p in round_state.current_player if p])
        if active_players > 2:
            strength *= (0.9 ** (active_players - 2))
            
        return min(1.0, max(0.0, strength))
        
    def _adjust_for_community(self, base_strength: float, community: List[str], 
                            is_pair: bool, rank1: str, rank2: str, 
                            suit1: str, suit2: str) -> float:
        """Adjust strength based on community cards."""
        strength = base_strength
        
        # Parse community cards
        comm_ranks = []
        comm_suits = []
        for card in community:
            if card:
                comm_ranks.append(card[:-1])
                comm_suits.append(card[-1])
                
        # Check for pairs with community
        for comm_rank in comm_ranks:
            if comm_rank == rank1 or comm_rank == rank2:
                strength += 0.25  # Made a pair
                
        # Check for flush potential
        all_suits = [suit1, suit2] + comm_suits
        for suit in set(all_suits):
            if all_suits.count(suit) >= 4:
                strength += 0.2  # Flush draw or made
            if all_suits.count(suit) >= 5:
                strength += 0.3  # Made flush
                
        # Check for straight potential (simplified)
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for r in range(2, 10):
            rank_values[str(r)] = r
            
        all_values = []
        for rank in [rank1, rank2] + comm_ranks:
            val = rank_values.get(rank, 2)
            all_values.append(val)
            
        all_values = sorted(set(all_values))
        
        # Check for straights
        for i in range(len(all_values) - 3):
            if all_values[i+3] - all_values[i] <= 4:
                strength += 0.15  # Straight draw or made
                
        return min(1.0, strength)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        if player_score > 0:
            self.position_stats['win'] += 1
        else:
            self.position_stats['loss'] += 1