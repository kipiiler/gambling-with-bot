from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction, PokerRound
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength = 0
        self.position = 0
        self.total_players = 0
        self.player_count = 0
        self.aggression_factor = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_count = len(all_players)
        self.aggression_factor = 1.0 + (6 - self.player_count) * 0.1  # Adjust aggression based on player count

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.position = 0  # Reset position tracking for new round

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        # This is a simplified evaluation - in practice you'd want a more robust evaluator
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
            
        # Parse cards
        card_ranks = []
        card_suits = []
        for card in hole_cards + community_cards:
            if len(card) == 2:
                rank, suit = card[0], card[1]
            else:
                rank, suit = card[:2], card[2]
                
            card_ranks.append(rank_values.get(rank, 0))
            card_suits.append(suit)
            
        # Simple strength calculation based on pairs and high cards
        strength = 0
        
        # Check for pairs, trips, etc.
        rank_counts = {}
        for rank in card_ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        # Add strength for pairs
        for count in rank_counts.values():
            if count >= 2:
                strength += count * 0.1
                
        # Add strength for high cards
        high_card_value = max(card_ranks) if card_ranks else 0
        strength += high_card_value / 100
        
        return min(strength, 1.0)

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, hole_cards: List[str]) -> Tuple[PokerAction, int]:
        """Determine action preflop based on hand strength and position"""
        # Basic hand ranking
        card1, card2 = hole_cards[0][0], hole_cards[1][0]
        suit1, suit2 = hole_cards[0][1], hole_cards[1][1]
        
        # Pocket pairs
        is_pair = card1 == card2
        # Suited cards
        is_suited = suit1 == suit2
        
        # High cards
        high_cards = ['A', 'K', 'Q', 'J']
        is_high_card = card1 in high_cards or card2 in high_cards
        is_both_high = card1 in high_cards and card2 in high_cards
        
        # Position factor (later position = more aggressive)
        position_factor = 1.0 + (self.position * 0.1)
        
        # Determine action based on hand strength
        if is_pair and card1 in ['A', 'K']:
            # Premium pocket pairs - raise aggressively
            raise_amount = min(round_state.min_raise * 3, remaining_chips)
            return (PokerAction.RAISE, raise_amount)
        elif is_both_high or (is_pair and card1 in ['Q', 'J', 'T']):
            # Strong hands - raise
            raise_amount = min(round_state.min_raise * 2, remaining_chips)
            return (PokerAction.RAISE, raise_amount)
        elif is_high_card or is_suited:
            # Decent hands - call or small raise
            if round_state.current_bet <= remaining_chips * 0.05:  # If bet is small
                if random.random() < 0.7:
                    raise_amount = min(round_state.min_raise, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
        else:
            # Weak hands - fold unless very cheap to call
            if round_state.current_bet <= remaining_chips * 0.02:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, hole_cards: List[str]) -> Tuple[PokerAction, int]:
        """Determine action postflop based on hand strength"""
        # Evaluate current hand strength
        hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
        
        # Calculate pot odds
        if round_state.current_bet > 0:
            pot_odds = round_state.pot / (round_state.current_bet + 1e-10)  # Add small epsilon to prevent division by zero
        else:
            pot_odds = float('inf')
            
        # Adjust hand strength based on number of players
        player_multiplier = max(1.0, self.player_count / 6.0)
        adjusted_strength = hand_strength * player_multiplier
        
        # Decision based on strength and pot odds
        if adjusted_strength > 0.7:  # Strong hand
            if round_state.current_bet == 0:
                raise_amount = min(max(round_state.min_raise, int(round_state.pot * 0.5)), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                # Decide whether to call, raise, or fold based on pot odds
                if pot_odds > 2.0:
                    if random.random() < 0.8:
                        raise_amount = min(round_state.current_bet * 2, remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
        elif adjusted_strength > 0.4:  # Medium hand
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds > 3.0:  # Good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hand
            if round_state.current_bet == 0:
                if random.random() < 0.3:  # Occasionally bluff
                    raise_amount = min(round_state.min_raise, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Fold unless pot odds are very good
                if pot_odds > 5.0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        # Get our hole cards - they should be stored in the bot somewhere
        # For now we'll assume they're passed in round_state or we track them
        # Since we don't have access to hole cards directly from round_state,
        # we'll need to make some assumptions or use a basic strategy
        
        try:
            # Simple strategy based on round
            if round_state.round == 'Preflop':
                # For preflop, we need to make assumptions about our hole cards
                # Since we can't access them directly, we'll use a position-based strategy
                if round_state.current_bet == 0:
                    # We can raise
                    if self.position > self.player_count // 2:  # Late position
                        raise_amount = min(round_state.min_raise * int(self.aggression_factor), remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)  # Just call the big blind
                else:
                    # There's a bet, decide whether to call or fold
                    # If the bet is small relative to our stack, call
                    if round_state.current_bet <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Postflop - use a more conservative strategy
                if round_state.current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # There's a bet - call if it's small, fold if it's big
                    if round_state.current_bet <= remaining_chips * 0.2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # If there's any error, fold to be safe
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update our position based on results if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Adjust aggression based on performance
        if player_score > 0:
            self.aggression_factor = min(2.0, self.aggression_factor * 1.1)
        else:
            self.aggression_factor = max(0.5, self.aggression_factor * 0.9)