import random
from typing import List, Tuple, Dict
from collections import Counter
import itertools

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound


def evaluate_hand(cards: List[str]) -> int:
    """Evaluates a 5-card poker hand and returns a numeric score."""
    if len(cards) != 5:
        raise ValueError("Exactly 5 cards are required for evaluation.")

    values = '23456789TJQKA'
    value_map = {v: i for i, v in enumerate(values)}
    
    suits = [card[1] for card in cards]
    ranks = sorted([value_map[card[0]] for card in cards], reverse=True)

    is_flush = len(set(suits)) == 1
    is_straight = all(ranks[i] - 1 == ranks[i+1] for i in range(4))
    
    if is_straight and is_flush:
        return 8000 + ranks[0]  # Straight flush (or royal)
        
    rank_counts = Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    most_common_rank = rank_counts.most_common(1)[0][0]

    if counts == [4, 1]:
        return 7000 + most_common_rank  # Four of a kind
    elif counts == [3, 2]:
        return 6000 + most_common_rank  # Full house
    elif is_flush:
        return 5000 + ranks[0]  # Flush
    elif is_straight:
        return 4000 + ranks[0]  # Straight
    elif counts == [3, 1, 1]:
        return 3000 + most_common_rank  # Three of a kind
    elif counts == [2, 2, 1]:
        pair_ranks = [rank for rank, count in rank_counts.items() if count == 2]
        return 2000 + max(pair_ranks) * 14 + min(pair_ranks)  # Two pair
    elif counts == [2, 1, 1, 1]:
        return 1000 + most_common_rank  # One pair
    else:
        return ranks[0]  # High card


def best_possible_hand(hole_cards: List[str], community_cards: List[str]) -> int:
    """Returns the best possible hand strength from available cards."""
    all_cards = hole_cards + community_cards
    
    if len(all_cards) < 5:
        # Not enough cards to evaluate fully -- use heuristics based on hole cards
        ranks = [card[0] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        
        score = 0
        if ranks[0] == ranks[1]:
            # Pocket pair
            value_map = {'2':0,'3':1,'4':2,'5':3,'6':4,'7':5,'8':6,'9':7,'T':8,'J':9,'Q':10,'K':11,'A':12}
            val = value_map[ranks[0]]
            score += val * 100
        
        if suits[0] == suits[1]:
            score += 50
            
        gap = abs(('23456789TJQKA'.index(ranks[0])) - ('23456789TJQKA'.index(ranks[1])))
        score -= gap * 5
        return score
        
    combinations = itertools.combinations(all_cards, 5)
    max_score = 0
    
    for combo in combinations:
        score = evaluate_hand(list(combo))
        if score > max_score:
            max_score = score
            
    return max_score


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hand = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.remaining_chips = 0
        self.hand_strength_thresholds = {
            'PreFlop': 1600,
            'Flop': 1500,
            'Turn': 3000,
            'River': 3000
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_hand = self.player_hands.copy()
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = round_state.current_bet - my_current_bet

            # Estimate our hand strength
            strength = best_possible_hand(self.my_hand, round_state.community_cards)
            
            stage = round_state.round
            
            if stage not in self.hand_strength_thresholds:
                stage_name_fix = 'PreFlop' if stage.lower() == 'preflop' else stage
            else:
                stage_name_fix = stage
                
            threshold = self.hand_strength_thresholds.get(stage_name_fix, 1000)

            aggressive_play_probability = min(0.9, max(0.1, strength / 8000))
            
            if random.random() < aggressive_play_probability or strength >= threshold:
                
                if to_call <= 0:
                    if round_state.min_raise > 0 and remaining_chips >= round_state.min_raise:
                        multiplier = 2.0 + random.random()*1.5
                        raise_amt = int(round(multiplier * round_state.min_raise))
                        
                        # Clamp within allowed range
                        raise_amt = min(max(raise_amt, round_state.min_raise), round_state.max_raise)
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.CHECK, 0)
                
                else:
                    # Decide whether to call, raise or go all-in
                    call_ratio_to_stack = to_call / (remaining_chips + 1e-8)
                    
                    if call_ratio_to_stack <= 0.3 and remaining_chips > to_call:
                        if random.random() < 0.3 and round_state.min_raise > 0:
                            extra = int(random.uniform(0.5, 1.5) * round_state.min_raise)
                            raise_total = to_call + extra
                            if raise_total >= round_state.min_raise and raise_total <= round_state.max_raise:
                                return (PokerAction.RAISE, raise_total)
                        return (PokerAction.CALL, 0)
                        
                    elif call_ratio_to_stack <= 0.5 and remaining_chips >= to_call:
                        return (PokerAction.CALL, 0)
                        
                    elif remaining_chips > 0:
                        prob_allin = max(0.0, min(1.0, call_ratio_to_stack - 0.4)) * 2
                        
                        if random.random() < prob_allin:
                            return (PokerAction.ALL_IN, 0)
                            
            # Default defensive/fold behavior
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                fold_prob = 0.7
                
                if strength > threshold * 0.8:
                    fold_prob = 0.3
                    
                if random.random() < fold_prob:
                    return (PokerAction.FOLD, 0)
                else:
                    if remaining_chips >= to_call:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)

        except Exception as e:
            print(f"[ERROR] Exception during decision making: {str(e)}")
            return (PokerAction.FOLD, 0)

        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass