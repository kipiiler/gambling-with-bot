from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _rank_value(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    r = card[0]
    if r.isdigit():
        return int(r)
    mapping = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    return mapping.get(r.upper(), 0)


def _suit_value(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[-1].lower()


def _sorted_ranks_desc(cards: List[str]) -> List[int]:
    return sorted([_rank_value(c) for c in cards], reverse=True)


def _is_suited(cards: List[str]) -> bool:
    if len(cards) < 2:
        return False
    return _suit_value(cards[0]) == _suit_value(cards[1])


def _gap(r1: int, r2: int) -> int:
    return abs(r1 - r2)


def _count_suits(cards: List[str]) -> Dict[str, int]:
    suits: Dict[str, int] = {}
    for c in cards:
        s = _suit_value(c)
        suits[s] = suits.get(s, 0) + 1
    return suits


def _count_ranks(cards: List[str]) -> Dict[int, int]:
    ranks: Dict[int, int] = {}
    for c in cards:
        r = _rank_value(c)
        ranks[r] = ranks.get(r, 0) + 1
    return ranks


def _has_straight(ranks_set: set) -> bool:
    if not ranks_set:
        return False
    # Ace can be low in A-2-3-4-5 straight
    vals = set(ranks_set)
    if 14 in vals:
        vals.add(1)
    seq = sorted(vals)
    run = 1
    for i in range(1, len(seq)):
        if seq[i] == seq[i-1] + 1:
            run += 1
            if run >= 5:
                return True
        elif seq[i] != seq[i-1]:
            run = 1
    return False


def _has_straight_with_hole(board: List[str], hole: List[str]) -> bool:
    # Detect if made straight that uses at least one hole card
    all_cards = board + hole
    ranks_all = set(_rank_value(c) for c in all_cards)
    ranks_board = set(_rank_value(c) for c in board)
    # Check all 5-card windows that include at least one hole rank
    hole_ranks = set(_rank_value(c) for c in hole)
    vals = set(ranks_all)
    if 14 in vals:
        vals_wheel = set(vals)
        vals_wheel.add(1)
    else:
        vals_wheel = vals
    seq = sorted(vals_wheel)
    # For each possible 5-seq, check if present and involves hole
    for start in range(len(seq)):
        window = [seq[start]]
        for j in range(start + 1, len(seq)):
            if seq[j] == window[-1] + 1:
                window.append(seq[j])
                if len(window) == 5:
                    # Translate 1 back to 14 (A) for overlap logic
                    window_set = set(window)
                    # Map any 1 in window to 14 for comparison with hole ranks
                    mapped = set(14 if x == 1 else x for x in window_set)
                    if hole_ranks & mapped:
                        # Ensure not board-only by verifying at least one of the ranks is not fully provided by board (approx)
                        if not window_set.issubset(set(ranks_board)):
                            return True
                    window.pop(0)
            elif seq[j] != window[-1]:
                # Gap
                window = [seq[j]]
    return False


def _flush_count_with_hole(board: List[str], hole: List[str]) -> int:
    all_cards = board + hole
    suits = _count_suits(all_cards)
    best_suit = max(suits.values()) if suits else 0
    if best_suit < 5:
        return 0
    # Ensure at least one hole card contributes
    s_needed = None
    for s, cnt in suits.items():
        if cnt >= 5:
            s_needed = s
            break
    if s_needed is None:
        return 0
    uses_hole = any(_suit_value(h) == s_needed for h in hole)
    return best_suit if uses_hole else 0


def _made_trips_or_better_with_hole(board: List[str], hole: List[str]) -> bool:
    all_cards = board + hole
    counts = _count_ranks(all_cards)
    # Board-only counts
    board_counts = _count_ranks(board)
    for r, cnt in counts.items():
        if cnt >= 3:
            # Check that at least one of the three comes from hole
            board_cnt = board_counts.get(r, 0)
            if cnt > board_cnt:
                return True
    return False


def _two_pair_with_hole(board: List[str], hole: List[str]) -> bool:
    all_cards = board + hole
    counts = _count_ranks(all_cards)
    # pairs including at least one from hole
    board_counts = _count_ranks(board)
    pair_ranks = []
    for r, cnt in counts.items():
        if cnt >= 2:
            if cnt > board_counts.get(r, 0):
                pair_ranks.append(r)
    return len(pair_ranks) >= 2


def _overpair(hole: List[str], board: List[str]) -> bool:
    if len(hole) < 2 or len(board) == 0:
        return False
    r1, r2 = _rank_value(hole[0]), _rank_value(hole[1])
    if r1 != r2:
        return False
    max_board = max((_rank_value(c) for c in board), default=0)
    return r1 > max_board


def _top_pair_with_hole(hole: List[str], board: List[str]) -> bool:
    if len(board) == 0:
        return False
    max_board = max((_rank_value(c) for c in board), default=0)
    hole_ranks = [_rank_value(h) for h in hole]
    return max_board in hole_ranks


def _second_pair_with_hole(hole: List[str], board: List[str]) -> bool:
    if len(board) == 0:
        return False
    board_ranks = sorted(set(_rank_value(c) for c in board), reverse=True)
    if len(board_ranks) < 2:
        return False
    second = board_ranks[1]
    hole_ranks = [_rank_value(h) for h in hole]
    return second in hole_ranks


def _pair_in_hole(hole: List[str]) -> bool:
    if len(hole) < 2:
        return False
    return _rank_value(hole[0]) == _rank_value(hole[1])


def _flush_draw_with_hole(board: List[str], hole: List[str]) -> bool:
    all_cards = board + hole
    suits = _count_suits(all_cards)
    # Need 4 to a flush and at least one hole card contributing
    for s, cnt in suits.items():
        if cnt == 4 and any(_suit_value(h) == s for h in hole):
            return True
    return False


def _oesd_with_hole(board: List[str], hole: List[str]) -> bool:
    # Approximate OESD: check windows of 4 in sequence that include at least one hole rank
    all_ranks = set(_rank_value(c) for c in (board + hole))
    hole_ranks = set(_rank_value(h) for h in hole)
    vals = set(all_ranks)
    if 14 in vals:
        vals.add(1)
    seq = sorted(vals)
    for i in range(len(seq) - 3):
        window = [seq[i], seq[i+1], seq[i+2], seq[i+3]]
        if window[3] - window[0] == 3:
            mapped = set(14 if x == 1 else x for x in window)
            if hole_ranks & mapped:
                # Ensure at least one missing card to make straight (draw not made)
                # Check if full 5 sequence exists (then it's a straight)
                start = window[0]
                five = set([start, start+1, start+2, start+3, start+4])
                five_mapped = set(14 if x == 1 else x for x in five)
                # If full five present with board only, then it's made straight; else it's a draw
                if not _has_straight(set(all_ranks)):
                    return True
    return False


def _gutshot_with_hole(board: List[str], hole: List[str]) -> bool:
    # Very rough gutshot detection: if we have 4 ranks within a span of 5 that include both hole cards
    all_ranks = set(_rank_value(c) for c in (board + hole))
    hole_ranks = set(_rank_value(h) for h in hole)
    vals = set(all_ranks)
    if 14 in vals:
        vals.add(1)
    seq = sorted(vals)
    for i in range(len(seq) - 4):
        window = seq[i:i+5]
        if window[-1] - window[0] == 5:
            mapped = set(14 if x == 1 else x for x in window)
            if hole_ranks & mapped:
                # Not OESD and not straight
                if not _oesd_with_hole(board, hole) and not _has_straight(set(all_ranks)):
                    return True
    return False


def _preflop_strength(hole: List[str]) -> float:
    # Heuristic preflop strength 0..1
    if len(hole) < 2:
        return 0.0
    r = sorted([_rank_value(h) for h in hole], reverse=True)
    r1, r2 = r[0], r[1]
    suited = _is_suited(hole)
    pair = r1 == r2
    if pair:
        # 22 -> ~0.55, AA -> ~0.91 (cap 0.9)
        strength = 0.55 + (r1 - 2) * 0.03
        return min(0.9, strength)
    base = 0.35 + ((r1 + r2) / 28.0) * 0.35
    bonus = 0.0
    gapv = _gap(r1, r2)
    if gapv == 1:
        bonus += 0.03
    elif gapv == 2:
        bonus += 0.015
    if suited:
        bonus += 0.04
    if r1 == 14:  # Ace-x
        if r2 >= 10:
            bonus += 0.06 if not suited else 0.08
        elif suited:
            bonus += 0.03
    if r1 >= 10 and r2 >= 10:
        bonus += 0.05
    if r2 <= 5:
        bonus -= 0.02
    return max(0.0, min(0.85, base + bonus))


def _estimate_postflop_strength(hole: List[str], board: List[str], round_name: str) -> Tuple[float, str]:
    # Coarse EHS estimate and category
    if len(hole) < 2:
        return 0.0, "unknown"
    if len(board) == 0:
        return _preflop_strength(hole), "preflop"

    # Made hands
    has_flush = _flush_count_with_hole(board, hole) >= 5
    has_straight = _has_straight_with_hole(board, hole)
    trips_or_better = _made_trips_or_better_with_hole(board, hole)
    two_pair = _two_pair_with_hole(board, hole)
    overpair = _overpair(hole, board)
    top_pair = _top_pair_with_hole(hole, board)
    second_pair = _second_pair_with_hole(hole, board)
    pair_in_hole = _pair_in_hole(hole)

    # Draws
    fd = _flush_draw_with_hole(board, hole)
    oesd = _oesd_with_hole(board, hole)
    gut = _gutshot_with_hole(board, hole)

    # Assign rough equities
    if has_flush:
        return 0.9, "flush"
    if has_straight:
        return 0.85, "straight"
    if trips_or_better:
        return 0.88, "trips+"
    if two_pair:
        return 0.75, "two_pair"
    if overpair:
        # Stronger if TT+ and early streets
        high_pair = max(_rank_value(hole[0]), _rank_value(hole[1])) >= 10
        return (0.78 if high_pair else 0.72), "overpair"
    if top_pair and pair_in_hole:
        # Top pair top kicker not guaranteed; estimate by highest hole rank
        high = max(_rank_value(hole[0]), _rank_value(hole[1]))
        return (0.68 if high >= 13 else 0.62), "top_pair_pairhole"
    if top_pair:
        high = max(_rank_value(hole[0]), _rank_value(hole[1]))
        return (0.63 if high >= 13 else 0.58), "top_pair"
    if fd and oesd:
        return 0.55, "combo_draw"
    if fd:
        return 0.46, "flush_draw"
    if oesd:
        return 0.45, "oesd"
    if second_pair:
        return 0.48, "second_pair"
    if gut:
        return 0.28, "gutshot"

    # Weak pair check (pair with board but not top/second)
    hole_ranks = [_rank_value(h) for h in hole]
    board_ranks = [_rank_value(c) for c in board]
    if any(hr in board_ranks for hr in hole_ranks):
        return 0.4, "weak_pair"

    # Air
    return 0.2, "air"


def _safe_raise_amount(min_raise: int, max_raise: int, target: int) -> Optional[int]:
    try:
        lo = int(min_raise)
        hi = int(max_raise)
        t = int(target)
    except Exception:
        return None
    if hi < lo or lo <= 0:
        return None
    t = max(lo, min(hi, t))
    return t


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.num_players = 0

        self.hole_cards: List[str] = []
        self.round_num = 0

        # Stats
        self.total_hands = 0
        self.aggression_factor = 1.0  # can adapt slightly

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the start of each hand (assumed from environment)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players or []
        self.num_players = len(self.all_players) if self.all_players else max(self.num_players, 2)
        # Update hole cards for this hand
        self.hole_cards = list(player_hands) if player_hands else []
        self.total_hands += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track round info
        try:
            self.round_num = round_state.round_num
        except Exception:
            pass

    def _decide_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        strength = _preflop_strength(self.hole_cards)
        my_bet = round_state.player_bets.get(str(self.id), 0) if round_state.player_bets else 0
        call_amount = max(0, round_state.current_bet - my_bet)
        can_check = call_amount == 0
        min_raise = int(max(0, round_state.min_raise))
        max_raise = int(max(0, min(round_state.max_raise, remaining_chips)))

        # Heads-up loosen slightly; multi-way tighten
        if self.num_players <= 2:
            strong_thr = 0.66
            med_thr = 0.58
            marginal_thr = 0.50
        else:
            strong_thr = 0.7
            med_thr = 0.6
            marginal_thr = 0.52

        # If facing an all-in size call, tighten heavily
        stack = max(1, remaining_chips)
        if call_amount >= stack:
            if strength >= 0.82:
                return PokerAction.ALL_IN, 0
            else:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # If can check (no bet to you)
        if can_check:
            if strength >= strong_thr:
                # Open raise
                target = int(3.0 * max(1, min_raise))
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            elif strength >= med_thr:
                target = int(2.5 * max(1, min_raise))
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            elif strength >= marginal_thr:
                # Mix between raise/check: be cautious multiway
                if self.num_players <= 3:
                    target = int(2.0 * max(1, min_raise))
                    amt = _safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None:
                        return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Facing a raise
            # Pot odds based decision to call with medium hands
            pot = round_state.pot
            denom = pot + call_amount + 1e-9
            pot_odds = call_amount / denom
            # Cap very large raises: if raise > 8bb and we are not strong, fold
            bb = max(1, self.blind_amount if self.blind_amount else min_raise)
            if call_amount > 8 * bb and strength < 0.75:
                return PokerAction.FOLD, 0

            if strength >= (strong_thr + 0.06):
                # 3-bet
                target = max(int(2.8 * call_amount), int(3.0 * min_raise))
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                # If cannot raise, prefer calling if pot odds okay
                if pot_odds < 0.45:
                    return PokerAction.CALL, 0 if call_amount < remaining_chips else (PokerAction.ALL_IN, 0)
                return PokerAction.CALL, 0 if call_amount < remaining_chips else (PokerAction.ALL_IN, 0)
            elif strength >= med_thr and pot_odds <= 0.42:
                # Call moderate raises, avoid dominated offsuit aces multiway
                return (PokerAction.CALL, 0) if call_amount < remaining_chips else (PokerAction.ALL_IN, 0)
            elif strength >= marginal_thr and call_amount <= 2 * bb and pot_odds <= 0.35 and self.num_players <= 3:
                return (PokerAction.CALL, 0) if call_amount < remaining_chips else (PokerAction.ALL_IN, 0)
            else:
                return PokerAction.FOLD, 0

    def _decide_postflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        board = list(round_state.community_cards or [])
        strength, category = _estimate_postflop_strength(self.hole_cards, board, round_state.round)
        my_bet = round_state.player_bets.get(str(self.id), 0) if round_state.player_bets else 0
        call_amount = max(0, round_state.current_bet - my_bet)
        can_check = call_amount == 0
        min_raise = int(max(0, round_state.min_raise))
        max_raise = int(max(0, min(round_state.max_raise, remaining_chips)))

        # If call would be all-in
        if call_amount >= remaining_chips:
            if strength >= 0.66:
                return PokerAction.ALL_IN, 0
            else:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # Compute pot odds for calls
        pot = round_state.pot
        denom = pot + call_amount + 1e-9
        pot_odds = call_amount / denom

        # Aggression sizing heuristics
        def bet_size_by_strength(s: float) -> int:
            # Prefer between 0.5p and 0.9p; translate roughly in terms of min_raise if pot unknown
            target_pot = int(max(min_raise, 0.7 * pot))
            if s >= 0.80:
                return int(min(max(0.8 * pot, 3 * min_raise), max_raise))
            elif s >= 0.7:
                return int(min(max(0.65 * pot, 2.5 * min_raise), max_raise))
            elif s >= 0.6:
                return int(min(max(0.5 * pot, 2.0 * min_raise), max_raise))
            else:
                return int(min(max(0.4 * pot, 1.5 * min_raise), max_raise if max_raise >= min_raise else min_raise))

        # If no bet to us
        if can_check:
            if strength >= 0.78:
                # Value bet
                target = bet_size_by_strength(strength)
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            elif strength >= 0.62:
                # Thin value / protection
                target = bet_size_by_strength(strength)
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            elif 0.42 <= strength < 0.62 and round_state.round in ("Flop", "TURN", "Turn"):
                # Semi-bluff some draws
                if category in ("flush_draw", "oesd", "combo_draw") and pot > 0:
                    target = int(max(1.5 * min_raise, 0.5 * pot))
                    amt = _safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None:
                        return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Facing bet: decide call/raise/fold
            if strength >= 0.82:
                # Strong value: raise
                target = int(max(2.2 * call_amount, 0.7 * pot))
                amt = _safe_raise_amount(min_raise, max_raise, target)
                if amt is not None:
                    return PokerAction.RAISE, amt
                # If cannot raise, call
                return PokerAction.CALL, 0
            elif strength >= 0.68:
                # Often call, sometimes raise small
                if call_amount <= 0.4 * pot:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.CALL, 0
            elif category in ("flush_draw", "oesd", "combo_draw"):
                # Draws: call if pot odds reasonable
                # Use implied odds bump
                eq_est = 0.45 if category in ("combo_draw", "oesd") else 0.35
                # If very small bet, can semi-bluff raise
                if call_amount <= min_raise and pot > 0 and eq_est > pot_odds + 0.05:
                    target = int(max(1.8 * call_amount, 0.5 * pot))
                    amt = _safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None:
                        return PokerAction.RAISE, amt
                if eq_est + 0.02 >= pot_odds:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif strength >= 0.5 and call_amount <= 0.33 * pot:
                # Thin call vs small bet
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Safety checks
            if remaining_chips <= 0:
                return PokerAction.CHECK, 0

            # Ensure we have our id set; if not, play ultra safe
            if self.id is None:
                # Default to check/fold
                if round_state.current_bet == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Make sure keys are strings in player_bets
            my_bet = round_state.player_bets.get(str(self.id), 0) if round_state.player_bets else 0
            call_amount = max(0, round_state.current_bet - my_bet)
            can_check = call_amount == 0

            # If we somehow have no hole cards, play ultra safe
            if not self.hole_cards or len(self.hole_cards) < 2:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

            round_name = (round_state.round or "").lower()
            if round_name in ("preflop", "pre-flop", "pre_flop", "prefloP"):
                return self._decide_preflop(round_state, remaining_chips)
            else:
                return self._decide_postflop(round_state, remaining_chips)
        except Exception:
            # On any unexpected error, avoid invalid action: check if possible, else fold
            try:
                my_bet = round_state.player_bets.get(str(self.id), 0) if round_state and round_state.player_bets else 0
                call_amount = max(0, (round_state.current_bet if round_state else 0) - my_bet)
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Adjust slight aggression based on chip trend
        try:
            delta_stack = remaining_chips - self.starting_chips
            if delta_stack > 0:
                self.aggression_factor = min(1.15, self.aggression_factor + 0.01)
            else:
                self.aggression_factor = max(0.85, self.aggression_factor - 0.01)
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset or log if needed; keep minimal to avoid exceptions
        try:
            # Slightly adjust strategy next game based on performance
            if player_score < 0:
                self.aggression_factor = max(0.9, self.aggression_factor - 0.02)
            else:
                self.aggression_factor = min(1.1, self.aggression_factor + 0.02)
        except Exception:
            pass