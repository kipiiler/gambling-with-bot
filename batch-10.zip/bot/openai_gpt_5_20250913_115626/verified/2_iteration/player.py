from typing import List, Tuple, Dict, Any
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _safe_div(n: float, d: float) -> float:
    return n / (d + 1e-9)


class SimplePlayer(Bot):
    """
    A conservative, position-agnostic, low-variance poker bot designed to be robust and valid-action safe.
    Strategy:
      - Tight/passive preflop with occasional opens/3-bets at controlled frequency.
      - Postflop c-bets at moderated frequency when available; otherwise stab occasionally.
      - Facing bets, use pot-odds and bet-size buckets to choose fold/call/raise with small bluff frequency.
      - Uses blind amount and pot sizes; does not assume hole-card availability (handles both cases).
      - Ensures all returned actions are valid given min/max raise constraints.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.all_players: List[int] = []
        self.rng = random.Random(1337)  # Deterministic base; still varies per action.
        self.was_aggressor: bool = False  # Track if we bet/raised earlier this hand
        self.round_num: int = 0
        self.seen_hands: int = 0

        # Opponent simple stats (best-effort - not heavily used)
        # {player_id: {'bets_raises': int, 'acts': int}}
        self.opp_stats: Dict[int, Dict[str, int]] = {}

        # We attempt to store hole cards if ever provided (not required)
        self.my_hole_cards: List[str] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = max(1, blind_amount)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []

        # If initial hand info is provided, store it (may not be updated later in some engines)
        if player_hands and isinstance(player_hands, list):
            # Expecting two cards strings like ['As','Kd']
            self.my_hole_cards = player_hands[:]

        # Initialize opponent stats
        for pid in self.all_players:
            if pid != self.id:
                self.opp_stats[pid] = {'bets_raises': 0, 'acts': 0}

        # Re-seed per match with our id to add diversity among bots
        try:
            if self.id is not None:
                self.rng.seed(7919 + int(self.id))
        except Exception:
            # Fallback deterministic seed
            self.rng.seed(7919)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand trackers
        self.was_aggressor = False
        self.round_num = round_state.round_num if hasattr(round_state, 'round_num') else self.round_num + 1
        self.seen_hands += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Extract state
            my_id_str = str(self.id) if self.id is not None else ""
            current_bet = int(round_state.current_bet)
            min_raise = int(max(0, round_state.min_raise))
            max_raise = int(max(0, round_state.max_raise))
            pot = int(max(0, round_state.pot))
            player_bets = round_state.player_bets or {}
            my_bet = int(player_bets.get(my_id_str, 0))
            to_call = max(0, current_bet - my_bet)
            remaining_chips = int(max(0, remaining_chips))
            can_check = (to_call == 0)

            # Active players (best-effort)
            num_active = 2
            try:
                if hasattr(round_state, 'current_player') and round_state.current_player:
                    num_active = max(1, len(round_state.current_player))
            except Exception:
                pass

            stage = self._stage_from_round(round_state.round)

            # Basic guardrails: if we are nearly all-in
            if remaining_chips <= 0:
                # No chips left, CHECK if possible else CALL (should auto-all-in), else FOLD safe.
                if can_check:
                    return PokerAction.CHECK, 0
                if to_call > 0:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Decide action based on stage
            if stage == 'preflop':
                action, amt = self._decide_preflop_action(to_call, pot, min_raise, max_raise, can_check, num_active)
            else:
                action, amt = self._decide_postflop_action(to_call, pot, min_raise, max_raise, can_check, current_bet, num_active, stage)

            # Final validity checks and adjustments
            action, amt = self._ensure_valid_action(action, amt, to_call, min_raise, max_raise, can_check, remaining_chips)

            # Track aggressor if we RAISE/ALL_IN
            if action in (PokerAction.RAISE, PokerAction.ALL_IN):
                self.was_aggressor = True

            return action, amt
        except Exception:
            # In case of any unexpected issue, fail-safe to a valid conservative action
            try:
                my_id_str = str(self.id) if self.id is not None else ""
                current_bet = int(round_state.current_bet)
                player_bets = round_state.player_bets or {}
                my_bet = int(player_bets.get(my_id_str, 0))
                to_call = max(0, current_bet - my_bet)
            except Exception:
                to_call = 0
            if to_call == 0:
                return PokerAction.CHECK, 0
            # If we can't safely call, just fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update simple opponent stats from player_actions if available
        try:
            actions = round_state.player_actions or {}
            for pid_str, act in actions.items():
                try:
                    pid = int(pid_str)
                except Exception:
                    continue
                if pid == self.id:
                    continue
                a = str(act).lower()
                if pid not in self.opp_stats:
                    self.opp_stats[pid] = {'bets_raises': 0, 'acts': 0}
                self.opp_stats[pid]['acts'] += 1
                if any(k in a for k in ['raise', 'all_in', 'bet']):
                    self.opp_stats[pid]['bets_raises'] += 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally adapt seed slightly between games for minor variability
        try:
            tweak = int(abs(player_score)) + self.seen_hands
            self.rng.seed(15485863 + int(self.id or 0) + tweak)
        except Exception:
            pass

    # =========================
    # Helper methods
    # =========================

    def _stage_from_round(self, round_name: Any) -> str:
        if not isinstance(round_name, str):
            return 'unknown'
        r = round_name.strip().lower()
        if 'pre' in r:
            return 'preflop'
        if 'flop' in r and 'pre' not in r:
            return 'flop'
        if 'turn' in r:
            return 'turn'
        if 'river' in r:
            return 'river'
        return 'unknown'

    def _clamp(self, x: int, lo: int, hi: int) -> int:
        if hi < lo:
            return lo
        return max(lo, min(hi, x))

    def _pot_odds(self, to_call: int, pot: int) -> float:
        return _safe_div(to_call, pot + to_call)

    def _choose_bet_from_pot(self, pot: int, min_raise: int, max_raise: int, frac: float) -> int:
        # When current_bet == 0, "bet" is a raise amount in this engine
        target = int(max(1, frac) * pot * frac)  # Light smoothing, still scales with pot
        # Prefer a cleaner formula: half-pot = pot * 0.5; just ensure int and within limits
        target = int(pot * frac)
        bet = self._clamp(max(min_raise, target), min_raise, max_raise)
        return bet

    def _choose_raise_multiple(self, current_bet: int, min_raise: int, max_raise: int, multiple: float) -> int:
        # Raise to 'multiple' times the current bet; amount param is incremental raise over current_bet
        target_new_cb = int(current_bet * max(1.1, multiple))  # ensure it actually raises
        inc = target_new_cb - current_bet
        inc = self._clamp(max(min_raise, inc), min_raise, max_raise)
        return inc

    def _decide_preflop_action(self, to_call: int, pot: int, min_raise: int, max_raise: int,
                               can_check: bool, num_active: int) -> Tuple[PokerAction, int]:
        # Conservative heads-up/multi-way preflop policy without hole-card visibility
        bb = max(1, self.blind_amount)
        # Open when checking is possible
        if can_check:
            # Open (raise) occasionally to steal blinds: ~30%
            if max_raise >= min_raise and self.rng.random() < 0.30:
                # Open size ~2.5bb if possible
                target = int(2.5 * bb)
                amount = self._clamp(max(min_raise, target), min_raise, max_raise)
                return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0

        # Facing a bet preflop (likely the blind or open/3bet)
        # Use size buckets relative to big blind
        if to_call <= bb:
            r = self.rng.random()
            if r < 0.70:  # call majority
                return PokerAction.CALL, 0
            elif r < 0.90 and max_raise >= min_raise:
                # Light 3-bet ~ 3x
                amount = self._clamp(int(2.0 * bb), min_raise, max_raise)
                return PokerAction.RAISE, amount
            else:
                return PokerAction.FOLD, 0
        elif to_call <= 3 * bb:
            r = self.rng.random()
            if r < 0.40:
                return PokerAction.CALL, 0
            elif r < 0.50 and max_raise >= min_raise:
                amount = self._clamp(int(2.0 * bb), min_raise, max_raise)
                return PokerAction.RAISE, amount
            else:
                return PokerAction.FOLD, 0
        elif to_call <= 5 * bb:
            r = self.rng.random()
            if r < 0.25:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # Large open/3bet: mostly fold, rarely call
            if self.rng.random() < 0.10:
                # If calling equals all-in, prefer fold unless small stack
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _decide_postflop_action(self, to_call: int, pot: int, min_raise: int, max_raise: int,
                                can_check: bool, current_bet: int, num_active: int, stage: str) -> Tuple[PokerAction, int]:
        # Determine c-bet frequencies by street
        if stage == 'flop':
            cbet_freq = 0.55
            stab_freq = 0.25
            bet_frac = 0.50
        elif stage == 'turn':
            cbet_freq = 0.40
            stab_freq = 0.20
            bet_frac = 0.60
        elif stage == 'river':
            cbet_freq = 0.30
            stab_freq = 0.15
            bet_frac = 0.66
        else:
            cbet_freq = 0.35
            stab_freq = 0.20
            bet_frac = 0.50

        # If we can check
        if can_check:
            # If we were the aggressor, continuation bet with some frequency
            if self.was_aggressor and max_raise >= min_raise and self.rng.random() < cbet_freq:
                # Bet based on pot fraction
                amount = self._choose_bet_from_pot(pot, min_raise, max_raise, bet_frac)
                return PokerAction.RAISE, amount
            # If not aggressor, stab occasionally
            if not self.was_aggressor and max_raise >= min_raise and self.rng.random() < stab_freq:
                amount = self._choose_bet_from_pot(pot, min_raise, max_raise, 0.50)
                return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0

        # We are facing a bet
        # Bucket by bet size relative to pot
        bet_size = to_call
        bet_to_pot = _safe_div(bet_size, max(1, pot))
        pot_odds = self._pot_odds(to_call, pot)

        # Heuristic reactions
        # Small bet: call often, sometimes raise if aggressor
        if bet_to_pot <= 0.33:
            r = self.rng.random()
            if r < 0.75:
                return PokerAction.CALL, 0
            elif r < 0.85 and max_raise >= min_raise:
                # Light raise to ~2.5x current bet increment
                amount = self._choose_raise_multiple(current_bet, min_raise, max_raise, 2.5)
                return PokerAction.RAISE, amount
            else:
                return PokerAction.CALL, 0

        # Medium bet: mix folds and calls; occasional raises if we were aggressor
        if bet_to_pot <= 0.66:
            r = self.rng.random()
            if r < 0.50:
                return PokerAction.CALL, 0
            elif r < 0.55 and self.was_aggressor and max_raise >= min_raise:
                amount = self._choose_raise_multiple(current_bet, min_raise, max_raise, 2.2)
                return PokerAction.RAISE, amount
            else:
                return PokerAction.FOLD, 0

        # Large bet: mostly fold, sometimes call if pot odds somewhat reasonable
        if bet_to_pot <= 1.10:
            r = self.rng.random()
            if r < 0.20:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Overbet: fold almost always
        if self.rng.random() < 0.10:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def _ensure_valid_action(self, action: PokerAction, amt: int, to_call: int,
                             min_raise: int, max_raise: int, can_check: bool,
                             remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Ensure the action is valid under engine rules, adjust conservatively if needed.
        """
        # Sanity limit
        if remaining_chips <= 0:
            if can_check:
                return PokerAction.CHECK, 0
            if to_call > 0:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # If attempting to CHECK but not allowed
        if action == PokerAction.CHECK and not can_check:
            # Default to CALL if affordable, else FOLD or ALL_IN if to_call >= stack
            if to_call <= 0:
                return PokerAction.CHECK, 0
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        # If attempting to CALL but no one bet
        if action == PokerAction.CALL and can_check:
            return PokerAction.CHECK, 0

        # If attempting to CALL but to_call >= remaining, use ALL_IN (safer)
        if action == PokerAction.CALL and to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0

        # If attempting to RAISE, validate bounds
        if action == PokerAction.RAISE:
            # If cannot raise, fallback
            if max_raise < max(1, min_raise):
                # If faced a bet, call if we can; else check
                if to_call > 0:
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                return PokerAction.CHECK, 0
            # Clamp amount
            amt = int(self._clamp(max(1, amt), min_raise, max_raise))
            return PokerAction.RAISE, amt

        # If attempting ALL_IN with zero chips guard
        if action == PokerAction.ALL_IN:
            # If we can check, checking is strictly better unless strategy says jam
            if can_check and remaining_chips > 0:
                return PokerAction.CHECK, 0
            return PokerAction.ALL_IN, 0

        # FOLD is always valid; prefer CHECK when available
        if action == PokerAction.FOLD and can_check:
            return PokerAction.CHECK, 0

        # Default return
        return action, int(max(0, amt))