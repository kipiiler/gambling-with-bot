from typing import List, Tuple, Optional, Dict
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game configuration/state
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Basic bookkeeping
        self.current_hand_cards: List[str] = []  # if cards are ever provided by the engine
        self.round_started: bool = False
        self.total_hands_played: int = 0
        self.total_delta: int = 0
        self.last_known_chips: Optional[int] = None

        # Randomness for mixed strategy (seeded per player for stability)
        self.rng = random.Random(12345)

        # Strategy tuning (can be tweaked with feedback)
        self.hud_stats: Dict[int, Dict[str, int]] = {}  # rudimentary opponent stats if ever needed

        # Safety epsilon for divisions
        self.EPS = 1e-9

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.last_known_chips = starting_chips
        self.current_hand_cards = list(player_hands) if player_hands else []
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players)

        # Seed RNG with a combination of player id and blinds for reproducibility across games
        seed_val = (self.id or 0) ^ (blind_amount << 1) ^ (big_blind_player_id or 0) ^ (small_blind_player_id or 0)
        self.rng.seed(seed_val)

        # Initialize HUD stats
        for pid in self.all_players:
            self.hud_stats[pid] = {
                "hands": 0,
                "folds": 0,
                "bets": 0,
                "calls": 0,
                "raises": 0,
                "checks": 0,
            }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_started = True
        self.total_hands_played += 1
        self.current_hand_cards = []  # reset; we may not be given cards explicitly in this interface

        # Update last known chips for delta tracking
        if self.last_known_chips is None:
            self.last_known_chips = remaining_chips

    def _my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _amount_to_call(self, round_state: RoundStateClient) -> int:
        try:
            to_call = round_state.current_bet - self._my_bet(round_state)
            return max(0, int(to_call))
        except Exception:
            return 0

    def _legal_raise_bounds(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[int, int]:
        try:
            min_r = int(round_state.min_raise)
        except Exception:
            min_r = 0
        try:
            max_r = int(min(round_state.max_raise, remaining_chips))
        except Exception:
            max_r = 0
        return max(0, min_r), max(0, max_r)

    def _clamp(self, val: int, lo: int, hi: int) -> int:
        return max(lo, min(hi, val))

    def _street(self, round_state: RoundStateClient) -> str:
        # Expect 'Preflop', 'Flop', 'Turn', 'River'
        try:
            return str(round_state.round)
        except Exception:
            return "Preflop"

    def _num_active(self, round_state: RoundStateClient) -> int:
        try:
            return max(0, len(round_state.current_player))
        except Exception:
            return 0

    def _bet_when_checked_to(self, round_state: RoundStateClient, remaining_chips: int, base_prob: float) -> Tuple[PokerAction, int]:
        # Bet sizing: choose ~1/2 pot bet subject to bounds
        allowed_min, allowed_max = self._legal_raise_bounds(round_state, remaining_chips)
        if allowed_min > allowed_max or allowed_min <= 0 or allowed_max <= 0:
            return PokerAction.CHECK, 0

        if self.rng.random() < base_prob:
            pot = max(0, int(round_state.pot))
            desired = int(0.5 * pot)
            if desired <= 0:
                desired = allowed_min
            amt = self._clamp(desired, allowed_min, allowed_max)
            if amt < allowed_min:  # fallback if clamping failed
                return PokerAction.CHECK, 0
            return PokerAction.RAISE, amt
        else:
            return PokerAction.CHECK, 0

    def _defend_vs_bet_postflop(self, round_state: RoundStateClient, remaining_chips: int, n_active: int, street: str) -> Tuple[PokerAction, int]:
        to_call = self._amount_to_call(round_state)
        pot = max(0, int(round_state.pot))
        pot_plus_call = pot + to_call + self.EPS

        # Small bet defense: call fairly often HU, less in multi-way
        if to_call <= 0.10 * pot_plus_call:
            call_freq = 0.55 if n_active <= 2 else 0.30
            if self.rng.random() < call_freq:
                return PokerAction.CALL, 0

        # Medium bet defense: occasional calls HU on earlier streets
        if to_call <= 0.20 * pot_plus_call:
            call_freq = 0.35 if (n_active <= 2 and street in ("Flop", "Turn")) else 0.15
            if self.rng.random() < call_freq:
                return PokerAction.CALL, 0

        # Occasional bluff-raise on small bets HU on flop/turn
        if n_active <= 2 and street in ("Flop", "Turn") and to_call <= 0.25 * pot_plus_call:
            allowed_min, allowed_max = self._legal_raise_bounds(round_state, remaining_chips)
            if allowed_min <= allowed_max and allowed_min > 0 and allowed_max > 0:
                if self.rng.random() < 0.08:
                    desired = int(3.0 * to_call) if to_call > 0 else allowed_min
                    amt = self._clamp(max(desired, allowed_min), allowed_min, allowed_max)
                    if amt >= allowed_min:
                        return PokerAction.RAISE, amt

        # Default fold
        return PokerAction.FOLD, 0

    def _preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._amount_to_call(round_state)
        allowed_min, allowed_max = self._legal_raise_bounds(round_state, remaining_chips)
        n_active = self._num_active(round_state)

        # If nothing to call, we're typically the BB; consider isolating limps or taking initiative
        if to_call == 0:
            # Heads-up: ISO/raise some %; Multi-way: more cautious
            raise_freq = 0.35 if n_active <= 2 else 0.15
            if allowed_min <= allowed_max and allowed_min > 0 and self.rng.random() < raise_freq:
                # Open size ~ 3x min raise (rough proxy for 3bb)
                desired = max(allowed_min, int(3 * allowed_min))
                amt = self._clamp(desired, allowed_min, allowed_max)
                if amt >= allowed_min:
                    return PokerAction.RAISE, amt
            return PokerAction.CHECK, 0

        # There is something to call
        pot = max(0, int(round_state.pot))
        pot_plus_call = pot + to_call + self.EPS

        # If the call is just the difference between SB and BB (limp/call), prefer raising often HU
        if to_call <= max(allowed_min, self.blind_amount or allowed_min):
            if allowed_min <= allowed_max and allowed_min > 0:
                # Raise very often HU; sometimes in multi-way
                raise_freq = 0.65 if n_active <= 2 else 0.35
                if self.rng.random() < raise_freq:
                    desired = max(allowed_min, int(3 * allowed_min))
                    amt = self._clamp(desired, allowed_min, allowed_max)
                    if amt >= allowed_min:
                        return PokerAction.RAISE, amt
                # Call sometimes to keep pot small
                if self.rng.random() < (0.35 if n_active <= 2 else 0.25):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Facing an open/raise: defend occasionally when price is good
        if to_call <= 0.12 * pot_plus_call:
            # Cheap call threshold
            if self.rng.random() < (0.30 if n_active <= 2 else 0.15):
                return PokerAction.CALL, 0

        # Light 3-bet bluff occasionally HU if sizing allows
        if n_active <= 2 and allowed_min <= allowed_max and allowed_min > 0 and self.rng.random() < 0.07:
            desired = max(allowed_min, int(3.5 * to_call)) if to_call > 0 else int(3 * allowed_min)
            amt = self._clamp(desired, allowed_min, allowed_max)
            if amt >= allowed_min:
                return PokerAction.RAISE, amt

        # Otherwise fold
        return PokerAction.FOLD, 0

    def _postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        street = self._street(round_state)
        n_active = self._num_active(round_state)
        to_call = self._amount_to_call(round_state)

        # If we aren't facing a bet, decide whether to bet as a bluff
        if to_call == 0:
            # Bet probabilities by street and table size (more aggressive HU)
            if n_active <= 2:
                base = {"Flop": 0.55, "Turn": 0.40, "River": 0.30}
            else:
                base = {"Flop": 0.30, "Turn": 0.22, "River": 0.15}
            base_prob = base.get(street, 0.30)
            return self._bet_when_checked_to(round_state, remaining_chips, base_prob)

        # Facing a bet
        return self._defend_vs_bet_postflop(round_state, remaining_chips, n_active, street)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            stage = self._street(round_state)

            # Safety checks for allowed actions
            to_call = self._amount_to_call(round_state)
            allowed_min, allowed_max = self._legal_raise_bounds(round_state, remaining_chips)

            # If we are effectively out of chips, ALL_IN when required to continue
            if remaining_chips <= 0:
                # If nothing to call, just CHECK; else we cannot continue (engine will handle)
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            if stage.lower() == "preflop" or stage.lower() == "prefloP".lower():
                action, amount = self._preflop_action(round_state, remaining_chips)
            else:
                action, amount = self._postflop_action(round_state, remaining_chips)

            # Validate chosen action; fallback safely if needed
            if action == PokerAction.CHECK:
                if to_call > 0:
                    # Can't check when there's a bet; fallback to CALL small or FOLD
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    # If cheap, call; else fold
                    pot = max(0, int(round_state.pot))
                    if to_call <= 0.1 * (pot + to_call + self.EPS):
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

            if action == PokerAction.CALL:
                if to_call == 0:
                    # Nothing to call; just check
                    return PokerAction.CHECK, 0
                return PokerAction.CALL, 0

            if action == PokerAction.RAISE:
                # Ensure bounds
                if allowed_min <= 0 or allowed_max <= 0 or allowed_min > allowed_max:
                    # Can't raise; fallback
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    else:
                        # If price is tiny, call; else fold
                        pot = max(0, int(round_state.pot))
                        if to_call <= 0.1 * (pot + to_call + self.EPS):
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                # Clamp amount
                amt = self._clamp(int(amount), allowed_min, allowed_max)
                if amt < allowed_min:
                    # Fallback again
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    else:
                        pot = max(0, int(round_state.pot))
                        if to_call <= 0.1 * (pot + to_call + self.EPS):
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                return PokerAction.RAISE, amt

            if action == PokerAction.ALL_IN:
                # Always valid if we have chips
                if remaining_chips > 0:
                    return PokerAction.ALL_IN, 0
                # No chips; fallback
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            if action == PokerAction.FOLD:
                if to_call == 0:
                    # Nothing to fold to; check instead
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Default ultra-safe fallback
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                # Call small bets, else fold
                pot = max(0, int(round_state.pot))
                if to_call <= 0.1 * (pot + to_call + self.EPS):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        except Exception:
            # Absolute fallback: avoid invalid action
            try:
                to_call = self._amount_to_call(round_state)
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
            except Exception:
                # If even state access fails, fold (engine should handle safely)
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        try:
            if self.last_known_chips is not None:
                self.total_delta += int(remaining_chips - self.last_known_chips)
            self.last_known_chips = remaining_chips
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset or log if necessary; keep minimal to stay within resource limits
        pass