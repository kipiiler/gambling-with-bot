from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
REVERSE_RANK_ORDER = {v: k for k, v in RANK_ORDER.items()}


def parse_card(card: str) -> Tuple[int, str]:
    """Parse a card like 'Ah', 'Ks', '3d' to (rank_int, suit_char)."""
    if not card or len(card) != 2:
        return (0, 'x')
    r = card[0].upper()
    s = card[1].lower()
    return (RANK_ORDER.get(r, 0), s)


def chen_score(hole_cards: List[str]) -> float:
    """
    Compute a simplified Chen formula score for starting hands.
    """
    if not hole_cards or len(hole_cards) < 2:
        return 0.0
    (r1, s1) = parse_card(hole_cards[0])
    (r2, s2) = parse_card(hole_cards[1])
    ranks = sorted([r1, r2], reverse=True)
    r_high, r_low = ranks[0], ranks[1]
    suited = (s1 == s2)

    # base from highest card
    def base_from_rank(r: int) -> float:
        mapping = {
            14: 10, 13: 8, 12: 7, 11: 6, 10: 5, 9: 4.5, 8: 4, 7: 3.5,
            6: 3, 5: 2.5, 4: 2, 3: 1.5, 2: 1
        }
        return mapping.get(r, 0)

    # Pair case
    if r1 == r2:
        pair_base = max(5, 2 * base_from_rank(r_high))
        return pair_base

    score = base_from_rank(r_high)

    if suited:
        score += 2

    gap = r_high - r_low - 1
    if gap == 0:
        score += 1
    elif gap == 1:
        score -= 1
    elif gap == 2:
        score -= 2
    elif gap == 3:
        score -= 4
    else:
        score -= 5

    # small card bonus for connected/1-gap and both >= 6
    if (gap <= 1) and (r_high <= 11) and (r_low >= 6):
        score += 1

    return max(score, 0.0)


def best_five_from_seven(cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
    """
    Evaluate best 5-card hand from up to 7 cards (hole + community).
    Returns a tuple (category, tiebreakers...), higher is better.
    Categories (higher is stronger):
      9: Straight Flush
      8: Four of a Kind
      7: Full House
      6: Flush
      5: Straight
      4: Three of a Kind
      3: Two Pair
      2: One Pair
      1: High Card
    """
    # Parse cards
    parsed = [parse_card(c) for c in cards if c]
    parsed = [c for c in parsed if c[0] > 0]
    if len(parsed) == 0:
        return (1, (0, 0, 0, 0, 0))
    # Limit to max 7
    parsed = parsed[:7]

    ranks = [r for r, s in parsed]
    suits = [s for r, s in parsed]

    # Count maps
    rank_counts: Dict[int, int] = {}
    suit_counts: Dict[str, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1

    # Prepare sorted unique ranks (for straights)
    unique_ranks = sorted(set(ranks))
    # Add Ace low for straight (A as 1)
    if 14 in unique_ranks:
        unique_ranks_with_ace_low = [1] + [r for r in unique_ranks]
    else:
        unique_ranks_with_ace_low = unique_ranks[:]

    def highest_straight(rlist: List[int]) -> int:
        """Return the high card of the best straight in rlist, or 0 if none."""
        if not rlist:
            return 0
        rset = set(rlist)
        best = 0
        # Consider straights up to Ace high (14) and Ace low (5)
        for high in range(14, 4, -1):
            seq = [high - i for i in range(5)]
            # For wheel straight, treat A as 1; already handled by using rlist that may include 1
            if set(seq).issubset(rset):
                best = high if high != 5 else 5  # 5-high straight (A2345)
                return best
        return best

    # Detect flush
    flush_suit: Optional[str] = None
    for s, c in suit_counts.items():
        if c >= 5:
            flush_suit = s
            break

    # Straight Flush
    if flush_suit:
        flush_cards = [r for r, s in parsed if s == flush_suit]
        fr_unique = sorted(set(flush_cards))
        # Ace low support for straight flush
        if 14 in fr_unique:
            fr_with_ace_low = [1] + [r for r in fr_unique]
        else:
            fr_with_ace_low = fr_unique
        sf_high = highest_straight(fr_with_ace_low)
        if sf_high:
            return (9, (sf_high,))

    # Four of a Kind
    fours = [r for r, c in rank_counts.items() if c == 4]
    if fours:
        quad = max(fours)
        kickers = sorted([r for r in ranks if r != quad], reverse=True)
        kicker = kickers[0] if kickers else 0
        return (8, (quad, kicker))

    # Full House
    trips = sorted([r for r, c in rank_counts.items() if c == 3], reverse=True)
    pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
    if trips:
        # Use highest trip
        trip_high = trips[0]
        # Find best pair/trip for full house (second trip counts as pair)
        remaining_trips = trips[1:]
        candidates = pairs + remaining_trips
        if candidates:
            pair_high = max(candidates)
            return (7, (trip_high, pair_high))

    # Flush
    if flush_suit:
        flush_ranks = sorted([r for r, s in parsed if s == flush_suit], reverse=True)
        top5 = tuple(flush_ranks[:5] + [0] * (5 - len(flush_ranks[:5])))
        return (6, top5)

    # Straight
    straight_high = highest_straight(unique_ranks_with_ace_low)
    if straight_high:
        return (5, (straight_high,))

    # Three of a Kind
    if trips:
        trip_high = trips[0]
        kickers = sorted([r for r in ranks if r != trip_high], reverse=True)
        top2 = kickers[:2] + [0] * (2 - len(kickers[:2]))
        return (4, (trip_high, top2[0], top2[1]))

    # Two Pair
    if len(pairs) >= 2:
        pair1, pair2 = pairs[0], pairs[1]
        kicker = max([r for r in ranks if r != pair1 and r != pair2] or [0])
        return (3, (pair1, pair2, kicker))

    # One Pair
    if len(pairs) == 1:
        pair = pairs[0]
        kickers = sorted([r for r in ranks if r != pair], reverse=True)
        k = kickers[:3] + [0] * (3 - len(kickers[:3]))
        return (2, (pair, k[0], k[1], k[2]))

    # High Card
    hi = sorted(unique_ranks, reverse=True)
    top5 = hi[:5] + [0] * (5 - len(hi[:5]))
    return (1, tuple(top5))


def approximate_equity(hole_cards: List[str], community_cards: List[str], players_in_hand: int, street: str) -> float:
    """
    Rough equity estimation based on hand category and simple draws, adjusted for players count.
    Returns a value in [0, 1].
    """
    if not hole_cards or len(hole_cards) < 2:
        return 0.0

    all_cards = hole_cards + (community_cards or [])
    category, tiebreak = best_five_from_seven(all_cards)

    # Draw detection (very approximate)
    ranks = [parse_card(c)[0] for c in all_cards]
    suits = [parse_card(c)[1] for c in all_cards]
    suit_counts: Dict[str, int] = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    # Flush draw if 4 cards of same suit on board+hand and at least one of hole in that suit
    flush_draw = False
    for s, cnt in suit_counts.items():
        if cnt == 4:
            # ensure at least one of ours contributes to draw
            if parse_card(hole_cards[0])[1] == s or parse_card(hole_cards[1])[1] == s:
                flush_draw = True
                break

    # Straight draw approx: if there are 4 unique ranks in a 5-long span.
    unique_ranks = sorted(set(ranks))
    # Add Ace low
    if 14 in unique_ranks:
        unique_ranks_low = [1] + [r for r in unique_ranks]
    else:
        unique_ranks_low = unique_ranks[:]
    straight_draw = False
    for high in range(14, 4, -1):
        seq = [high - i for i in range(5)]
        present = sum(1 for x in seq if x in unique_ranks_low)
        if present == 4:
            straight_draw = True
            break

    # Overcards (if unpaired and hole card ranks above board ranks)
    board_ranks = [parse_card(c)[0] for c in (community_cards or [])]
    hole_ranks = [parse_card(c)[0] for c in hole_cards]
    paired = False
    for br in set(board_ranks):
        if hole_ranks.count(br) > 0:
            paired = True
            break
    overcards = 0
    if board_ranks and not paired:
        max_board = max(board_ranks)
        overcards = sum(1 for hr in hole_ranks if hr > max_board)

    # Base equity by category (heads-up baseline)
    base_by_cat = {
        9: 0.98,  # straight flush
        8: 0.95,  # quads
        7: 0.90,  # full house
        6: 0.78,  # flush
        5: 0.72,  # straight
        4: 0.65,  # trips
        3: 0.58,  # two pair
        2: 0.52,  # one pair
        1: 0.30,  # high card
    }
    equity = base_by_cat.get(category, 0.3)

    # Adjust for draws when hand is weak
    if category <= 2:
        if street.lower() == 'flop':
            draw_equity = 0.0
            if flush_draw:
                draw_equity = max(draw_equity, 0.35)
            if straight_draw:
                draw_equity = max(draw_equity, 0.32)
            if overcards >= 2:
                draw_equity = max(draw_equity, 0.24)
            equity = max(equity, draw_equity)
        elif street.lower() == 'turn':
            draw_equity = 0.0
            if flush_draw:
                draw_equity = max(draw_equity, 0.18)
            if straight_draw:
                draw_equity = max(draw_equity, 0.16)
            if overcards >= 2:
                draw_equity = max(draw_equity, 0.12)
            equity = max(equity, draw_equity)

    # Multiway adjustment: decrease equity with more opponents
    players = max(players_in_hand, 1)
    if players > 2:
        # Reduce equity by about 7% per extra opponent for made hands, more for weak hands
        if category >= 3:
            equity *= max(0.4, 1.0 - 0.07 * (players - 2))
        else:
            equity *= max(0.3, 1.0 - 0.10 * (players - 2))

    # Clamp
    return max(0.0, min(1.0, equity))


def safe_get_player_bet(round_state: RoundStateClient, pid: int) -> int:
    try:
        return int(round_state.player_bets.get(str(pid), 0))
    except Exception:
        # Fallback in case dict keys are not strings
        try:
            return int(round_state.player_bets.get(pid, 0))
        except Exception:
            return 0


def compute_to_call(round_state: RoundStateClient, player_id: int) -> int:
    current_bet = int(round_state.current_bet or 0)
    my_bet = safe_get_player_bet(round_state, player_id)
    to_call = current_bet - my_bet
    return max(0, to_call)


def can_check(round_state: RoundStateClient, player_id: int) -> bool:
    return compute_to_call(round_state, player_id) == 0


def can_raise(round_state: RoundStateClient) -> bool:
    try:
        mn = int(round_state.min_raise or 0)
        mx = int(round_state.max_raise or 0)
        return mn > 0 and mx >= mn
    except Exception:
        return False


def choose_raise_amount(round_state: RoundStateClient, pot: int, to_call: int, remaining_chips: int, aggression: float) -> int:
    """
    Choose a raise amount (the 'raise by' amount as per interface).
    Clamped between min_raise and max_raise.
    """
    mn = int(round_state.min_raise or 0)
    mx = int(round_state.max_raise or 0)
    if mx <= 0:
        return 0
    # Target sizing based on pot and to_call, scaled by aggression
    target = int(max(mn, min(mx, max(mn, int((0.5 + aggression * 0.5) * (pot + to_call))))))
    # Ensure within bounds
    amt = max(mn, min(mx, target))
    # Ensure we don't attempt to use more than remaining chips (engine should already cap mx)
    amt = min(amt, max(0, remaining_chips))
    return int(amt)


def randomize() -> float:
    try:
        return random.random()
    except Exception:
        return 0.5


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.aggression: float = 0.5  # 0 passive, 1 aggressive
        self.round_num_seen: int = 0

    def _try_update_hole_cards_from_any(self, maybe_list: Optional[List[str]]) -> None:
        if isinstance(maybe_list, list) and len(maybe_list) >= 2 and all(isinstance(c, str) and len(c) == 2 for c in maybe_list[:2]):
            self.hole_cards = maybe_list[:2]

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = int(starting_chips or 0)
        self.blind_amount = int(blind_amount or 0)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players or []
        self._try_update_hole_cards_from_any(player_hands)
        # Seed randomness for consistent but varied play
        seed_val = (self.id or 1) * 7919 + self.starting_chips * 31 + self.blind_amount * 7
        random.seed(seed_val)
        # Set aggression a bit differently per player id
        self.aggression = 0.45 + 0.15 * (randomize())

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num_seen = int(getattr(round_state, 'round_num', 0) or 0)
        # Try to fetch hole cards from round_state if available (engine may extend)
        for attr in ['player_hands', 'hole_cards', 'hand', 'my_cards']:
            hc = getattr(round_state, attr, None)
            if hc:
                self._try_update_hole_cards_from_any(hc)
                break
        # Slightly adapt aggression as stacks change
        try:
            stack_ratio = max(0.1, min(2.0, remaining_chips / (self.starting_chips + 1e-6)))
            if stack_ratio < 0.5:
                self.aggression = max(0.35, self.aggression - 0.05)
            elif stack_ratio > 1.2:
                self.aggression = min(0.7, self.aggression + 0.03)
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Basic round info
            stage_str = (round_state.round or '').lower()
            community_cards = round_state.community_cards or []
            pot = int(round_state.pot or 0)
            to_call = compute_to_call(round_state, self.id)
            my_can_check = can_check(round_state, self.id)
            my_can_raise = can_raise(round_state)
            players_in_hand = len(getattr(round_state, 'current_player', []) or self.all_players or [])
            players_in_hand = max(players_in_hand, 2)

            # If no hole cards known, play very tight to avoid spew
            if not self.hole_cards or len(self.hole_cards) < 2:
                if my_can_check:
                    return (PokerAction.CHECK, 0)
                # If affordable tiny call, we may call; else fold
                if to_call <= max(1, self.blind_amount) and remaining_chips > to_call:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

            # Determine action by stage
            if stage_str == 'preflop':
                s = chen_score(self.hole_cards)
                # Slight noise
                s += (randomize() - 0.5) * 0.5
                # Facing action or first in?
                if to_call == 0:
                    # We can check if we're BB facing no raise, otherwise to open-raise we must RAISE
                    if my_can_raise and s >= (9.5 - self.aggression * 2.0 - max(0, (6 - players_in_hand)) * 0.3):
                        # Open raise
                        raise_amt = choose_raise_amount(round_state, pot=max(pot, self.blind_amount * 3), to_call=to_call, remaining_chips=remaining_chips, aggression=self.aggression)
                        if raise_amt >= int(round_state.min_raise or 0):
                            return (PokerAction.RAISE, int(raise_amt))
                        # If cannot raise due to bounds, just CHECK
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet/raise
                    # If the cost to continue is too large (all-in or near), be selective
                    if to_call >= remaining_chips:
                        if s >= 11.0:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    # 3-bet with strong hands
                    if my_can_raise and s >= 12.0:
                        raise_amt = choose_raise_amount(round_state, pot=pot, to_call=to_call, remaining_chips=remaining_chips, aggression=self.aggression)
                        if raise_amt >= int(round_state.min_raise or 0):
                            return (PokerAction.RAISE, int(raise_amt))
                        else:
                            # If can't raise, default to CALL with strong
                            return (PokerAction.CALL, 0)
                    # Call with reasonable hands, else fold
                    if s >= max(7.5, 8.5 - self.aggression * 2.0):
                        # Pot odds sanity: if huge bet relative to pot, fold more often
                        pot_odds = to_call / (pot + to_call + 1e-9)
                        if pot_odds <= 0.35 or s >= 10.0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)

            else:
                # Postflop
                equity = approximate_equity(self.hole_cards, community_cards, players_in_hand, stage_str)
                # Pot odds
                pot_odds = to_call / (pot + to_call + 1e-9)

                # If to_call is zero (can check), decide to bet/raise for value or bluff
                if my_can_check:
                    # Value bet when strong
                    if equity >= 0.70:
                        if my_can_raise:
                            raise_amt = choose_raise_amount(round_state, pot=max(pot, 1), to_call=0, remaining_chips=remaining_chips, aggression=self.aggression)
                            if raise_amt >= int(round_state.min_raise or 0):
                                return (PokerAction.RAISE, int(raise_amt))
                    # Semi-bluff occasionally with draws
                    if equity >= 0.30 and randomize() < 0.25 and my_can_raise:
                        raise_amt = choose_raise_amount(round_state, pot=max(pot, 1), to_call=0, remaining_chips=remaining_chips, aggression=self.aggression * 0.8)
                        if raise_amt >= int(round_state.min_raise or 0):
                            return (PokerAction.RAISE, int(raise_amt))
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet
                    if to_call >= remaining_chips:
                        # Decision for all-in calls
                        if equity > 0.55:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)

                    # Strong hands: raise for value
                    if equity >= 0.75 and can_raise(round_state):
                        raise_amt = choose_raise_amount(round_state, pot=pot, to_call=to_call, remaining_chips=remaining_chips, aggression=min(1.0, self.aggression + 0.2))
                        if raise_amt >= int(round_state.min_raise or 0):
                            return (PokerAction.RAISE, int(raise_amt))
                        else:
                            # If cannot raise, calling is fine
                            return (PokerAction.CALL, 0)

                    # Call if equity comfortably exceeds pot odds
                    if equity >= pot_odds + 0.05:
                        return (PokerAction.CALL, 0)

                    # Occasionally bluff-raise when near-threshold and aggressive
                    if can_raise(round_state) and (equity > 0.33) and (equity < 0.55) and randomize() < (0.1 + 0.15 * self.aggression):
                        raise_amt = choose_raise_amount(round_state, pot=pot, to_call=to_call, remaining_chips=remaining_chips, aggression=self.aggression)
                        if raise_amt >= int(round_state.min_raise or 0):
                            return (PokerAction.RAISE, int(raise_amt))

                    # Otherwise fold
                    return (PokerAction.FOLD, 0)

        except Exception:
            # Failsafe: never crash; default to check/fold conservative
            try:
                if can_check(round_state, self.id):
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: adapt aggression slightly based on chip trend
        try:
            delta = remaining_chips - self.starting_chips
            if delta > 0:
                self.aggression = min(0.75, self.aggression + 0.01)
            else:
                self.aggression = max(0.35, self.aggression - 0.01)
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset between games
        try:
            self.hole_cards = []
        except Exception:
            pass