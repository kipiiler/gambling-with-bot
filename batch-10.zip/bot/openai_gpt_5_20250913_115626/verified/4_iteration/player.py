from typing import List, Tuple, Dict, Any, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
              'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
RANK_STR = '23456789TJQKA'
SUITS = 'cdhs'


def card_rank(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    return RANK_ORDER.get(card[0].upper(), 0)


def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()


def chen_value_for_rank(rank_char: str) -> float:
    # Chen formula base values
    mapping = {
        'A': 10, 'K': 8, 'Q': 7, 'J': 6, 'T': 5,
        '9': 4.5, '8': 3.5, '7': 3, '6': 2.5,
        '5': 2, '4': 1.5, '3': 1.5, '2': 1
    }
    return mapping.get(rank_char.upper(), 0.0)


def chen_score_two_cards(cards: List[str]) -> float:
    # Return 0..20-ish scale; higher is better
    if not cards or len(cards) != 2:
        return 0.0
    c1, c2 = cards[0], cards[1]
    r1c, r2c = c1[0].upper(), c2[0].upper()
    s1, s2 = c1[1].lower(), c2[1].lower()
    v1 = chen_value_for_rank(r1c)
    v2 = chen_value_for_rank(r2c)
    # Order so r1 >= r2 by rank value
    if RANK_ORDER.get(r2c, 0) > RANK_ORDER.get(r1c, 0):
        r1c, r2c = r2c, r1c
        s1, s2 = s2, s1
        v1, v2 = v2, v1

    # Pair
    if r1c == r2c:
        score = max(5.0, v1 * 2.0)
    else:
        score = v1
        # Suited
        if s1 == s2:
            score += 2.0
        # Gap penalties
        gap = abs(RANK_ORDER[r1c] - RANK_ORDER[r2c]) - 1
        if gap == 0:
            score += 0.0
        elif gap == 1:
            score -= 1.0
        elif gap == 2:
            score -= 2.0
        elif gap == 3:
            score -= 4.0
        else:
            score -= 5.0
        # Bonus for T+ connectors
        if gap == 0 and RANK_ORDER[r1c] >= 11:
            score += 1.0

    return max(0.0, score)


def is_straight(ranks: List[int]) -> bool:
    """Detect if a set of ranks contains a straight (best 5)"""
    if not ranks:
        return False
    uniq = sorted(set(ranks))
    # Wheel: treat Ace as 1 as well
    if 14 in uniq:
        uniq = [1] + uniq
    cnt = 1
    for i in range(1, len(uniq)):
        if uniq[i] == uniq[i-1] + 1:
            cnt += 1
            if cnt >= 5:
                return True
        elif uniq[i] == uniq[i-1]:
            continue
        else:
            cnt = 1
    return False


def straight_draw_exists(ranks: List[int]) -> bool:
    """Approximate OESD or gutshot draw detection."""
    if not ranks:
        return False
    uniq = sorted(set(ranks))
    # Add Ace low
    if 14 in uniq:
        uniq = [1] + uniq
    # Check any 4-in-5 window holds 4 ranks (OESD-ish)
    for i in range(len(uniq) - 3):
        window = uniq[i:i+5]
        if len(window) < 4:
            break
        # Count unique within window
        if window[-1] - window[0] <= 5 and len(window) >= 4:
            # There are at least 4 within range of length <=5
            return True
    return False


def categorize_hand(hole: List[str], board: List[str]) -> Dict[str, Any]:
    """Return a simple category and features for decision: made hand strength and draws."""
    cards = list(hole) + list(board)
    ranks = [card_rank(c) for c in cards if c]
    suits = [card_suit(c) for c in cards if c]
    # Suit counts
    suit_counts: Dict[str, int] = {}
    for s in suits:
        if not s:
            continue
        suit_counts[s] = suit_counts.get(s, 0) + 1
    flush = any(cnt >= 5 for cnt in suit_counts.values())
    # Flush draw (exactly 4 of a suit with one card to come)
    flush_draw = any(cnt == 4 for cnt in suit_counts.values())

    # Rank counts
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        if r == 0:
            continue
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts = sorted(rank_counts.values(), reverse=True)  # e.g., [3,2,1,1]
    has_quads = (4 in counts)
    has_trips = (3 in counts)
    pairs = [r for r, c in rank_counts.items() if c == 2]
    has_two_pair = len(pairs) >= 2
    has_pair = (2 in counts)
    straight = is_straight(ranks)
    straight_draw = straight_draw_exists(ranks)

    # Contribution check: do our hole cards actually help?
    hole_ranks = [card_rank(c) for c in hole]
    hole_suits = [card_suit(c) for c in hole]
    board_ranks = [card_rank(c) for c in board]
    board_suits = [card_suit(c) for c in board]

    # Top pair check
    top_board_rank = max(board_ranks) if board_ranks else 0
    made_top_pair = any(r == top_board_rank for r in hole_ranks) and top_board_rank > 0

    # Overpair: pocket pair higher than any board rank
    overpair = False
    if len(hole_ranks) == 2 and hole_ranks[0] == hole_ranks[1]:
        if (max(board_ranks) if board_ranks else 0) < hole_ranks[0]:
            overpair = True

    # Board-only hand?
    board_only = False
    # If best pairs/trips/quads don't include hole ranks, tag board_only
    # Heuristic: if we have at least pair on the table but neither hole card rank matches any paired rank in rank_counts
    if has_quads or has_trips or has_two_pair or has_pair:
        board_pairs_ranks = set([r for r, c in rank_counts.items() if c >= 2])
        if all(r not in board_pairs_ranks for r in hole_ranks):
            board_only = True

    # Category strength numeric (higher is better)
    # baseline from made hands
    strength = 0.0
    category = 'high_card'
    if has_quads:
        strength = 0.99
        category = 'quads'
    elif has_trips and has_pair:
        strength = 0.95
        category = 'full_house'
    elif flush:
        strength = 0.9
        category = 'flush'
    elif straight:
        strength = 0.85
        category = 'straight'
    elif has_trips:
        strength = 0.8
        category = 'trips'
    elif has_two_pair:
        strength = 0.7
        category = 'two_pair'
    elif overpair:
        strength = 0.68
        category = 'overpair'
    elif made_top_pair:
        # Kicker unknown; approximate
        strength = 0.6
        category = 'top_pair'
    elif has_pair:
        strength = 0.5
        category = 'pair'
    else:
        strength = 0.2
        category = 'high_card'

    # Draw bonuses
    if not flush and flush_draw:
        # Add draw equity depending on street
        strength = max(strength, 0.4)
    if not straight and straight_draw:
        strength = max(strength, 0.38)

    # If the made hand is board-only, reduce aggression
    if board_only and strength >= 0.5:
        strength = min(strength, 0.55)

    return {
        'strength': strength,
        'category': category,
        'flush': flush,
        'flush_draw': flush_draw,
        'straight': straight,
        'straight_draw': straight_draw,
        'top_pair': made_top_pair,
        'overpair': overpair,
        'board_only': board_only
    }


def clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.random = random.Random()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.last_round_num_seen: Optional[int] = None
        self.hand_counter: int = 0
        self.table_size: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.table_size = len(self.all_players) if self.all_players else 0
        # Use any provided hole cards (some environments may pass the current hand here)
        if player_hands and len(player_hands) >= 2:
            self.hole_cards = player_hands[:2]
        else:
            self.hole_cards = []
        # seed random for reproducibility per player
        try:
            seed_val = (self.id or 0) ^ starting_chips ^ blind_amount ^ (self.table_size or 0)
            self.random.seed(seed_val)
        except Exception:
            self.random.seed()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Detect new hand by round number and street
        try:
            if round_state.round and str(round_state.round).lower().startswith('pre'):
                if self.last_round_num_seen != round_state.round_num:
                    # New hand
                    self.hole_cards = self.hole_cards if self.hole_cards else []  # keep if environment set in on_start
                    self.hand_counter += 1
                    self.last_round_num_seen = round_state.round_num
        except Exception:
            # Be robust
            pass

    def _my_bet_this_street(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _to_call(self, round_state: RoundStateClient) -> int:
        try:
            to_call = int(round_state.current_bet) - int(self._my_bet_this_street(round_state))
            return max(0, to_call)
        except Exception:
            return 0

    def _num_active_players_estimate(self, round_state: RoundStateClient) -> int:
        try:
            # Use players present in bets map as a proxy
            return max(2, len(round_state.player_bets)) if round_state.player_bets else 2
        except Exception:
            return 2

    def _street_name(self, round_state: RoundStateClient) -> str:
        try:
            return (round_state.round or '').lower()
        except Exception:
            return 'preflop'

    def _choose_bet_amount(self, round_state: RoundStateClient, desired: int) -> Optional[int]:
        try:
            mn = int(round_state.min_raise)
            mx = int(round_state.max_raise)
            if mx <= 0 or mn <= 0:
                return None
            amt = clamp(int(desired), mn, mx)
            if amt < mn or amt > mx:
                return None
            return amt
        except Exception:
            return None

    def _should_cbet_without_hand(self, street: str) -> bool:
        # Semi-randomized continuation betting when cards unknown
        if street == 'preflop':
            return self.random.random() < 0.2
        if street == 'flop':
            return self.random.random() < 0.33
        if street == 'turn':
            return self.random.random() < 0.25
        if street == 'river':
            return self.random.random() < 0.2
        return False

    def _estimate_equity_from_features(self, feats: Dict[str, Any], street: str) -> float:
        # Map our heuristic strength to an "equity" like value
        base = float(feats.get('strength', 0.2))
        # Slightly reduce on earlier streets due to realization issues
        if street == 'flop':
            return base * 0.95
        if street == 'turn':
            return base * 0.98
        return base

    def _preflop_action(self, to_call: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        blind = max(1, int(self.blind_amount or 1))
        min_raise = max(0, int(round_state.min_raise))
        max_raise = max(0, int(round_state.max_raise))
        pot = int(round_state.pot or 0)

        have_cards = bool(self.hole_cards) and len(self.hole_cards) == 2
        score = chen_score_two_cards(self.hole_cards) if have_cards else None

        if to_call == 0:
            # Opening or checking
            if have_cards and score is not None:
                # Value open with good hands
                if score >= 8.0:
                    desired_bet = max(3 * blind, int(0.35 * max(pot, 3 * blind)))
                    amt = self._choose_bet_amount(round_state, desired_bet)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                elif score >= 6.0:
                    # Smaller open or check sometimes
                    if self.random.random() < 0.5:
                        desired_bet = max(2 * blind, int(0.25 * max(pot, 2 * blind)))
                        amt = self._choose_bet_amount(round_state, desired_bet)
                        if amt is not None:
                            return (PokerAction.RAISE, amt)
                    return (PokerAction.CHECK, 0)
                else:
                    # Mostly check
                    if self.random.random() < 0.1 and min_raise > 0:
                        desired_bet = max(min_raise, blind * 2)
                        amt = self._choose_bet_amount(round_state, desired_bet)
                        if amt is not None:
                            return (PokerAction.RAISE, amt)
                    return (PokerAction.CHECK, 0)
            else:
                # No cards known: occasional steal attempt
                if self._should_cbet_without_hand('preflop') and min_raise > 0:
                    desired_bet = max(min_raise, 2 * blind)
                    amt = self._choose_bet_amount(round_state, desired_bet)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
        else:
            # Facing a raise
            if have_cards and score is not None:
                # Strong: continue
                if score >= 9.5:
                    # Premium: sometimes shove when short or vs big bet
                    if to_call > 8 * blind or to_call > remaining_chips // 3:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        # Prefer call to keep pot manageable (avoid RAISE ambiguity)
                        return (PokerAction.CALL, 0)
                elif score >= 7.0:
                    # Call reasonable raises up to ~5bb
                    if to_call <= 5 * blind or to_call <= pot // 2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif score >= 5.0:
                    # Call small raises
                    if to_call <= 2 * blind:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Without hole cards: be conservative
                if to_call <= blind and self.random.random() < 0.3:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def _postflop_action(self, to_call: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        street = self._street_name(round_state)
        pot = int(round_state.pot or 0)
        min_raise = max(0, int(round_state.min_raise))
        max_raise = max(0, int(round_state.max_raise))

        have_cards = bool(self.hole_cards) and len(self.hole_cards) == 2
        board = list(round_state.community_cards or [])

        if not have_cards:
            # No hole cards known: simple strategy
            if to_call == 0:
                # Occasional bluff bet when checked to
                if self._should_cbet_without_hand(street) and min_raise > 0:
                    desired = max(min_raise, int(0.33 * max(1, pot)))
                    amt = self._choose_bet_amount(round_state, desired)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
            else:
                # Call small bets, fold to larger
                # Compare to pot odds
                if pot <= 0:
                    return (PokerAction.FOLD, 0)
                pot_odds = to_call / (pot + to_call + 1e-9)
                if pot_odds <= 0.2 and to_call <= pot // 2:
                    return (PokerAction.CALL, 0)
                if to_call <= max(1, self.blind_amount) and self.random.random() < 0.3:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        # With hole cards: evaluate made hand / draw
        feats = categorize_hand(self.hole_cards, board)
        eq = self._estimate_equity_from_features(feats, street)

        # Aggression thresholds
        strong = feats['category'] in ('quads', 'full_house', 'flush', 'straight', 'trips', 'two_pair', 'overpair')
        medium = feats['category'] in ('top_pair', 'pair') and not feats.get('board_only', False)
        draw = feats.get('flush_draw', False) or feats.get('straight_draw', False)

        if to_call == 0:
            # We can bet for value or bluff with draws
            if strong:
                # Value bet around 60-75% pot
                desired = int(max(min_raise, 0.66 * max(1, pot)))
                amt = self._choose_bet_amount(round_state, desired)
                if amt is not None:
                    return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
            elif medium:
                # Smaller value/protection bet 40-60% pot, else check-back
                if self.random.random() < 0.7 and min_raise > 0:
                    desired = int(max(min_raise, 0.5 * max(1, pot)))
                    amt = self._choose_bet_amount(round_state, desired)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
            elif draw:
                # Semi-bluff sometimes
                if self.random.random() < 0.5 and min_raise > 0:
                    desired = int(max(min_raise, 0.4 * max(1, pot)))
                    amt = self._choose_bet_amount(round_state, desired)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
            else:
                # Mostly check, occasional small stab
                if self.random.random() < 0.2 and min_raise > 0:
                    desired = max(min_raise, int(0.33 * max(1, pot)))
                    amt = self._choose_bet_amount(round_state, desired)
                    if amt is not None:
                        return (PokerAction.RAISE, amt)
                return (PokerAction.CHECK, 0)
        else:
            # Facing a bet
            pot_odds = to_call / (pot + to_call + 1e-9)
            if strong:
                # With very strong hands and shallow stacks, allow shoving
                if eq >= 0.8 and (to_call > remaining_chips // 3 or remaining_chips < 10 * max(1, self.blind_amount)):
                    return (PokerAction.ALL_IN, 0)
                # Otherwise, prefer calling (avoid ambiguous raise semantics), sometimes shove if pot small
                if self.random.random() < 0.2 and eq > 0.9 and to_call <= pot:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            elif medium:
                # Call reasonable bets up to ~60-70% pot
                if pot <= 0:
                    return (PokerAction.CALL, 0) if to_call <= max(1, self.blind_amount) else (PokerAction.FOLD, 0)
                if to_call <= 0.7 * pot:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif draw:
                # Call with pot odds; fold if too expensive
                # Approx equity for strong draw on flop ~ 0.35-0.38; turn ~0.18-0.2
                if eq >= pot_odds + 0.03:
                    # Mix in occasional semi-bluff shove when short and cheap
                    if self.random.random() < 0.1 and to_call <= pot // 2 and remaining_chips < 20 * max(1, self.blind_amount):
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hands: mostly fold; call tiny bets with some frequency
                if to_call <= max(1, self.blind_amount) and self.random.random() < 0.25:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive defaults
        try:
            to_call = self._to_call(round_state)
            street = self._street_name(round_state)
            # If we somehow have no chips, we can only fold/check
            if remaining_chips <= 0:
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

            if street.startswith('pre'):
                return self._preflop_action(to_call, round_state, remaining_chips)
            else:
                return self._postflop_action(to_call, round_state, remaining_chips)
        except Exception:
            # Fail-safe: never crash; choose a valid conservative action
            try:
                to_call = int(round_state.current_bet) - int(round_state.player_bets.get(str(self.id), 0))
                to_call = max(0, to_call)
            except Exception:
                to_call = 0
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                # If cheap, call; otherwise fold
                blind = max(1, int(self.blind_amount or 1))
                return (PokerAction.CALL, 0) if to_call <= blind else (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: could update stats, reset per-hand fields if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally, adjust random seed for next games or log stats.
        pass