from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.all_players = []
        self.hole_cards = []
        self.rank_value_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        self.opponent_model = {}  # Track opponent tendencies
        
    def rank_value(self, rank_char: str) -> int:
        return self.rank_value_map.get(rank_char, 0)
    
    def parse_cards(self, cards_str: str) -> List[str]:
        """Parse a string of card representations into a list of 2-character card strings"""
        valid_cards = []
        for i in range(0, len(cards_str), 2):
            card = cards_str[i:i+2]
            if len(card) == 2:
                valid_cards.append(card)
        return valid_cards[:2]  # Return at most 2 cards
    
    def evaluate_hand_strength(self, cards: List[str]) -> float:
        """Evaluate hand strength with proper error handling"""
        if not cards:
            return 0.0
            
        rank_count = {}
        suit_count = {}
        
        for card in cards:
            if len(card) < 2:
                continue
            rank, suit = card[0], card[1]
            rank_count[rank] = rank_count.get(rank, 0) + 1
            suit_count[suit] = suit_count.get(suit, 0) + 1
        
        if not rank_count:
            return 0.0
            
        # Basic hand strength evaluation
        counts = sorted(rank_count.values(), reverse=True)
        is_flush = max(suit_count.values()) >= 5
        ranks = sorted([self.rank_value(r) for r in rank_count.keys()])
        
        # Check for straight
        is_straight = False
        if len(ranks) >= 5:
            unique_ranks = sorted(set(ranks))
            for i in range(len(unique_ranks)-4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    is_straight = True
                    break
            # Check for A-2-3-4-5 straight
            if set(ranks) >= {14, 2, 3, 4, 5}:
                is_straight = True
        
        # Hand strengths (higher is better)
        if counts[0] >= 4:
            strength = 7.0 + counts[0] * 0.1  # Four of a kind
        elif counts[0] >= 3 and counts[1] >= 2:
            strength = 6.0 + counts[0] * 0.1  # Full house
        elif is_flush and is_straight:
            strength = 8.0 + max(ranks) * 0.01  # Straight flush
        elif is_flush:
            strength = 5.0 + max(ranks) * 0.01  # Flush
        elif is_straight:
            strength = 4.0 + max(ranks) * 0.01  # Straight
        elif counts[0] >= 3:
            strength = 3.0 + counts[0] * 0.1  # Three of a kind
        elif counts[0] >= 2 and counts[1] >= 2:
            strength = 2.0 + max(c for r, c in rank_count.items() if c == 2) * 0.05  # Two pair
        elif counts[0] >= 2:
            strength = 1.0 + counts[0] * 0.1  # One pair
        else:
            strength = max(ranks) / 14.0  # High card
            
        return min(strength, 9.0)  # Cap at royal flush (9.0)

    def pre_flop_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength pre-flop (only hole cards)"""
        return self.evaluate_hand_strength(self.hole_cards)
    
    def post_flop_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength post-flop (hole cards + community cards)"""
        all_cards = self.hole_cards + round_state.community_cards
        valid_cards = [card for card in all_cards if len(card) == 2]
        return self.evaluate_hand_strength(valid_cards)
    
    def decide_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        """Decide action based on hand strength and game state"""
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot + remaining_chips  # Total chips at stake
        to_call = current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Adjust strategy based on hand strength
        if hand_strength < 0.3:
            # Very weak hand - fold unless no bet
            if to_call > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        elif hand_strength < 0.6:
            # Weak hand - check/call small bets, fold to big bets
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= pot * 0.1:  # Call small bets
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif hand_strength < 0.8:
            # Medium hand - value bet small, call moderate bets
            if to_call == 0:
                # Bet 30-50% of pot
                bet_size = max(min_raise, int(pot * 0.4))
                bet_size = min(bet_size, max_raise)
                return PokerAction.RAISE, bet_size
            elif to_call <= pot * 0.3:  # Call moderate bets
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # Strong hand - aggressive betting
            if to_call == 0:
                # Bet 60-100% of pot
                bet_size = max(min_raise, int(pot * 0.8))
                bet_size = min(bet_size, max_raise)
                return PokerAction.RAISE, bet_size
            elif to_call <= pot * 0.5:  # Call or raise
                # Consider raising with strong hands
                if hand_strength > 0.85 and remaining_chips > pot * 2:
                    raise_size = to_call + int(pot * 0.5)
                    raise_size = min(raise_size, max_raise)
                    return PokerAction.RAISE, raise_size
                else:
                    return PokerAction.CALL, 0
            else:
                # Large bet - consider all-in with strongest hands
                if hand_strength > 0.9:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Parse hole cards for first hand
        idx = all_players.index(self.id)
        our_hole_string = player_hands[idx]
        self.hole_cards = self.parse_cards(our_hole_string)
        
        # Initialize opponent model
        for player in all_players:
            if player != self.id:
                self.opponent_model[player] = {'aggression': 0.5, 'fold_rate': 0.5}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # No hole card updates available in API - using first hand's hole cards
        # In a real implementation, we would need a way to get fresh hole cards each hand
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if round_state.round in ['Flop', 'Turn', 'River']:
                strength = self.post_flop_strength(round_state)
            else:  # Pre-flop
                strength = self.pre_flop_strength(round_state)
            
            # Special case: if no other players, just check
            if len(round_state.current_player) == 1 and round_state.current_player[0] == self.id:
                return PokerAction.CHECK, 0
                
            return self.decide_action(round_state, remaining_chips, strength)
            
        except Exception as e:
            # Fallback to check/fold if any error occurs
            current_bet = round_state.current_bet
            to_call = current_bet - round_state.player_bets.get(str(self.id), 0)
            if to_call > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent model based on observed actions
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hole_cards = []