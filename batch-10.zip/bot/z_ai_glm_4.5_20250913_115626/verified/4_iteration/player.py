from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        self.premium_hands = {('A','A'): 10, ('K','K'): 9, ('Q','Q'): 8, ('A','K'): 7}
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.blind_amount = blind_amount
        idx = all_players.index(self.id)
        self.hole_cards = [player_hands[idx][:2], player_hands[idx][2:]]
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def pre_flop_strength(self) -> int:
        if not self.hole_cards: 
            return 0
        r1, r2 = self.hole_cards[0][0], self.hole_cards[1][0]
        suited = self.hole_cards[0][1] == self.hole_cards[1][1]
        key = tuple(sorted([r1, r2], key=lambda x: self.rank_map[x], reverse=True))
        base_strength = self.premium_hands.get(key, 0)
        if base_strength and suited:
            return base_strength
        return base_strength if key == ('A','K') else base_strength

    def post_flop_strength(self, round_state: RoundStateClient) -> int:
        combined = self.hole_cards + round_state.community_cards
        ranks = {}
        suits = {}
        for card in combined:
            rank = card[0]
            suit = card[1]
            ranks[rank] = ranks.get(rank, 0) + 1
            suits[suit] = suits.get(suit, 0) + 1
        
        strength = 0
        if max(suits.values()) >= 5: 
            strength = 5
        for count in ranks.values():
            if count == 4:
                strength = max(strength, 7)
            elif count == 3:
                strength = max(strength, 3)
            elif count == 2:
                if strength == 3:
                    strength = 6
                else:
                    strength = max(strength, 2)
        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - our_bet
        min_total_bet = round_state.current_bet + round_state.min_raise
        max_total_bet = our_bet + remaining_chips
        
        if round_state.round == 'Preflop':
            strength = self.pre_flop_strength()
            if to_call == 0:
                if strength >= 8:
                    total_bet = min(max_total_bet, our_bet + 4 * self.blind_amount)
                    return (PokerAction.RAISE, total_bet)
                elif strength >= 7:
                    return (PokerAction.CALL, to_call)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if strength >= 10:
                    total_bet = min(max_total_bet, max(min_total_bet, round_state.current_bet + to_call * 2))
                    return (PokerAction.RAISE, total_bet)
                elif strength >= 7:
                    if to_call <= remaining_chips * 0.15:
                        return (PokerAction.CALL, to_call)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            strength = self.post_flop_strength(round_state)
            if to_call == 0:
                if strength >= 3:
                    total_bet = min(max_total_bet, our_bet + min(round_state.pot // 2, round_state.max_raise))
                    return (PokerAction.RAISE, total_bet)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if strength >= 5:
                    total_bet = min(max_total_bet, max(min_total_bet, round_state.current_bet + round_state.pot // 3))
                    return (PokerAction.RAISE, total_bet)
                elif strength >= 3:
                    if to_call <= remaining_chips * 0.2:
                        return (PokerAction.CALL, to_call)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass