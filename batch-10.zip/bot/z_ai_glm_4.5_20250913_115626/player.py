from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import itertools

class Suit(Enum):
    HEARTS = 'h'
    DIAMONDS = 'd'
    CLUBS = 'c'
    SPADES = 's'

class PokerHandRank(Enum):
    HIGH_CARD = 0
    PAIR = 1
    TWO_PAIR = 2
    THREE_OF_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

def card_rank(card: str) -> int:
    rank = card[0]
    if rank == 'A':
        return 14
    elif rank == 'K':
        return 13
    elif rank == 'Q':
        return 12
    elif rank == 'J':
        return 11
    elif rank == 'T':
        return 10
    else:
        return int(rank)

def card_suit(card: str) -> Suit:
    return Suit(card[1])

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.chips = 10000
        self.hand_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.chips = starting_chips
        index = all_players.index(self.id)
        if index < len(player_hands):
            self.hole_cards = player_hands[index].split() if player_hands[index] else []
        self.blind_amount = blind_amount
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.chips = remaining_chips
        self.current_state = round_state
        
    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[PokerHandRank, List[int]]:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return (PokerHandRank.HIGH_CARD, sorted([card_rank(c) for c in all_cards], reverse=True))
        
        best_hand = None
        best_rank = PokerHandRank.HIGH_CARD
        
        for five_cards in itertools.combinations(all_cards, 5):
            ranks = sorted([card_rank(c) for c in five_cards], reverse=True)
            suits = [card_suit(c) for c in five_cards]
            suit_counts = {}
            rank_counts = {}
            
            for suit in Suit:
                suit_counts[suit] = 0
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            for card in five_cards:
                suit_counts[card_suit(card)] += 1
                
            is_flush = max(suit_counts.values()) >= 5
            is_straight = False
            straight_high = 0
            
            # Check for straight
            for i in range(len(ranks)-4):
                if ranks[i] - ranks[i+4] == 4:
                    is_straight = True
                    straight_high = ranks[i]
                    break
            if not is_straight and 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
                is_straight = True
                straight_high = 5
                
            # Check for straight flush
            if is_straight and is_flush:
                flush_suit = None
                for suit in suit_counts:
                    if suit_counts[suit] >= 5:
                        flush_suit = suit
                        break
                if flush_suit:
                    flush_ranks = sorted([card_rank(c) for c in five_cards if card_suit(c) == flush_suit], reverse=True)
                    for i in range(len(flush_ranks)-4):
                        if flush_ranks[i] - flush_ranks[i+4] == 4:
                            straight_high = flush_ranks[i]
                            return (PokerHandRank.STRAIGHT_FLUSH, [straight_high])
            if is_straight and is_flush:
                return (PokerHandRank.STRAIGHT_FLUSH, [straight_high])
                
            # Check for four of a kind
            pair_ranks = []
            three_rank = None
            for rank, count in rank_counts.items():
                if count == 4:
                    other_card = [r for r in ranks if r != rank][0]
                    return (PokerHandRank.FOUR_OF_KIND, [rank] + [other_card])
                elif count == 3:
                    three_rank = rank
                elif count == 2:
                    pair_ranks.append(rank)
                    
            # Check for full house
            if three_rank and pair_ranks:
                return (PokerHandRank.FULL_HOUSE, [three_rank] + sorted(pair_ranks, reverse=True))
                
            # Check for flush
            if is_flush:
                return (PokerHandRank.FLUSH, ranks)
                
            # Check for straight
            if is_straight:
                return (PokerHandRank.STRAIGHT, [straight_high])
                
            # Check for three of a kind
            if three_rank:
                other_cards = sorted([r for r in ranks if r != three_rank], reverse=True)
                return (PokerHandRank.THREE_OF_KIND, [three_rank] + other_cards)
                
            # Check for two pair
            if len(pair_ranks) >= 2:
                pair_ranks_sorted = sorted(pair_ranks, reverse=True)
                other_card = [r for r in ranks if r not in pair_ranks_sorted][0]
                return (PokerHandRank.TWO_PAIR, pair_ranks_sorted[:2] + [other_card])
                
            # Check for one pair
            if pair_ranks:
                pair_rank = pair_ranks[0]
                other_cards = sorted([r for r in ranks if r != pair_rank], reverse=True)
                return (PokerHandRank.PAIR, [pair_rank] + other_cards)
                
            # High card
            return (PokerHandRank.HIGH_CARD, ranks)
            
        return best_rank if best_hand else (PokerHandRank.HIGH_CARD, sorted([card_rank(c) for c in all_cards], reverse=True))
        
    def preflop_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) < 2:
            return 0.0
        ranks = sorted([card_rank(c) for c in hole_cards], reverse=True)
        high, low = ranks[0], ranks[1]
        suited = hole_cards[0][1] == hole_cards[1][1]
        base = high * 2 + low
        if suited:
            base += 4
        if high == low:
            base += 15
        strength = min(base / 30.0, 1.0)
        return max(strength, 0.0)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.chips = remaining_chips
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        pot_odds = to_call / (pot + to_call + 1e-6)
        
        if round_state.round == 'Preflop':
            strength = self.preflop_strength(self.hole_cards)
        else:
            hand_rank, _ = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            strength = hand_rank.value / 10.0
            
        # Edge case: split pot
        if to_call == 0 and strength < 0.3:
            return (PokerAction.CHECK, 0)
            
        # All-in scenario
        if to_call >= remaining_chips:
            if strength > pot_odds * 1.1:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Normal betting
        if to_call > 0:
            if strength < pot_odds * 0.9:
                return (PokerAction.FOLD, 0)
            elif strength > 0.75:
                raise_amount = min(round_state.min_raise * 2, remaining_chips)
                if raise_amount < to_call + round_state.min_raise:
                    raise_amount = to_call + round_state.min_raise
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CALL, 0)
        else:
            if strength > 0.8:
                raise_amount = min(round_state.min_raise * 3, remaining_chips)
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_history.append({
            'id': round_state.round_num,
            'chips': remaining_chips,
            'action': 'completed'
        })
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass