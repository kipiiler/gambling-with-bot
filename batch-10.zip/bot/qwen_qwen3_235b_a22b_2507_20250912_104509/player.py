from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re
from math import log, sqrt

# Helper functions for hand evaluation
def parse_card(card: str) -> tuple:
    """Convert card string to (rank, suit), rank as int: 2-14 (Ace=14)"""
    if len(card) != 2 and not (len(card) == 3 and card[0] == '1' and card[1] == '0'):
        raise ValueError(f"Invalid card format: {card}")
    rank_char = card[0] if len(card) == 2 else '10'
    suit = card[-1]
    rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    rank = rank_map.get(rank_char, int(rank_char) if rank_char.isdigit() else 0)
    return (rank, suit)

def rank_to_str(rank: int) -> str:
    if rank == 14: return 'A'
    if rank == 13: return 'K'
    if rank == 12: return 'Q'
    if rank == 11: return 'J'
    if rank == 10: return 'T'
    return str(rank)

def evaluate_hand(hole_cards: List[str], community_cards: List[str]) -> int:
    """
    Evaluate the best 5-card poker hand strength.
    Returns a score where higher = better hand (crude approximation).
    """
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        # Not enough cards to evaluate, return high card
        ranks = sorted([parse_card(c)[0] for c in all_cards], reverse=True)
        score = 0
        for i, r in enumerate(ranks):
            score += r * (15 ** (5 - i))
        return score

    cards = [parse_card(c) for c in all_cards]
    ranks = [c[0] for c in cards]
    suits = [c[1] for c in cards]
    
    # Count frequencies
    rank_count = {}
    suit_count = {}
    for r in ranks:
        rank_count[r] = rank_count.get(r, 0) + 1
    for s in suits:
        suit_count[s] = suit_count.get(s, 0) + 1

    # Sort by frequency then rank
    sorted_ranks = sorted(rank_count.items(), key=lambda x: (-x[1], -x[0]))
    freqs = [f for _, f in sorted_ranks]

    # Check flush
    flush_suit = None
    for s, cnt in suit_count.items():
        if cnt >= 5:
            flush_suit = s
            break
    is_flush = flush_suit is not None

    # Check straight
    unique_ranks = sorted(set(ranks), reverse=True)
    # Handle A-5-4-3-2 straight
    if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
        is_straight = True
        high_card = 5
    else:
        is_straight = False
        high_card = 0
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] == unique_ranks[i+1] + 1 == unique_ranks[i+2] + 2 == unique_ranks[i+3] + 3 == unique_ranks[i+4] + 4:
                is_straight = True
                high_card = unique_ranks[i]
                break

    # Build hand from best 5 cards
    hand_strength = 0

    # Straight Flush (including Royal Flush)
    if is_straight and is_flush:
        straight_flush_cards = [c for c in cards if c[1] == flush_suit]
        sf_ranks = sorted([r for r, s in straight_flush_cards], reverse=True)
        # Check for straight
        for i in range(len(sf_ranks) - 4):
            if sf_ranks[i] == sf_ranks[i+1] + 1 == sf_ranks[i+2] + 2 == sf_ranks[i+3] + 3 == sf_ranks[i+4] + 4:
                hand_strength = 8_000_000 + sf_ranks[i]  # Straight flush high card
                return hand_strength
        # Check A-5-4-3-2
        if 14 in sf_ranks and 2 in sf_ranks and 3 in sf_ranks and 4 in sf_ranks and 5 in sf_ranks:
            hand_strength = 8_000_000 + 5
            return hand_strength

    # Four of a Kind
    if 4 in freqs:
        quad_rank = next(r for r, f in sorted_ranks if f == 4)
        kicker = next(r for r, f in sorted_ranks if f != 4)
        hand_strength = 7_000_000 + quad_rank * 100 + kicker
        return hand_strength

    # Full House
    if freqs.count(3) >= 2 or (3 in freqs and 2 in freqs):
        # Get highest triplet and highest pair
        trips = [r for r, f in sorted_ranks if f >= 3]
        pair = [r for r, f in sorted_ranks if f >= 2 and r not in trips]
        trip_rank = max(trips)
        pair_rank = max(pair) if pair else trip_rank  # In case there are two trips, use second as pair
        hand_strength = 6_000_000 + trip_rank * 100 + pair_rank
        return hand_strength

    # Flush
    if is_flush:
        flush_cards = sorted([r for r, s in cards if s == flush_suit], reverse=True)[:5]
        score = 5_000_000
        for i, r in enumerate(flush_cards):
            score += r * (15 ** (4 - i))
        return score

    # Straight
    if is_straight:
        return 4_000_000 + high_card

    # Three of a Kind
    if 3 in freqs:
        trip_rank = next(r for r, f in sorted_ranks if f == 3)
        kickers = sorted([r for r, f in sorted_ranks if f != 3], reverse=True)[:2]
        score = 3_000_000 + trip_rank * 1000
        for i, k in enumerate(kickers):
            score += k * (15 ** (1 - i))
        return score

    # Two Pair
    if freqs.count(2) >= 2:
        pairs = [r for r, f in sorted_ranks if f >= 2][:2]
        kicker = next((r for r, f in sorted_ranks if f == 1), 0)
        score = 2_000_000 + pairs[0] * 150 + pairs[1] * 10 + kicker
        return score

    # One Pair
    if 2 in freqs:
        pair_rank = next(r for r, f in sorted_ranks if f == 2)
        kickers = sorted([r for r, f in sorted_ranks if f == 1], reverse=True)[:3]
        score = 1_000_000 + pair_rank * 10000
        for i, k in enumerate(kickers):
            score += k * (15 ** (2 - i))
        return score

    # High Card
    high_cards = sorted(ranks, reverse=True)[:5]
    score = 0
    for i, r in enumerate(high_cards):
        score += r * (15 ** (4 - i))
    return score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = {}
        self.my_hand = []
        self.game_log = []
        self.opponent_models = {}  # Track opponent tendencies
        self.hand_strength_cache = {}
        self.previous_round_pot = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_hands = {}
        for pid, hand in zip(all_players, player_hands):
            self.player_hands[pid] = hand
            if pid == self.id:
                self.my_hand = hand
        # Initialize opponent models
        for pid in all_players:
            if pid != self.id:
                self.opponent_models[pid] = {
                    'total_actions': 0,
                    'folds': 0,
                    'calls': 0,
                    'raises': 0,
                    'aggression_freq': 0.0,
                    'voluntary_put_in_pot': 0,
                    'hands_played': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round cache
        self.hand_strength_cache = {}
        # Update opponent actions from previous round if available
        if len(self.game_log) > 0:
            prev_state = self.game_log[-1]
            for pid_str, action in prev_state.player_actions.items():
                pid = int(pid_str)
                if pid != self.id and pid in self.opponent_models:
                    model = self.opponent_models[pid]
                    model['total_actions'] += 1
                    if action == 'FOLD':
                        model['hands_played'] += 1  # Only count when they fold post-start
                        model['folds'] += 1
                    elif action == 'CALL':
                        model['calls'] += 1
                        model['voluntary_put_in_pot'] += 1
                    elif action in ['RAISE', 'BET']:
                        model['raises'] += 1
                        model['voluntary_put_in_pot'] += 1
                    if model['total_actions'] > 0:
                        model['aggression_freq'] = (model['raises']) / (model['calls'] + model['raises'] + 1e-8)
        self.game_log.append(round_state)

    def _get_my_hand_strength(self, round_state: RoundStateClient) -> float:
        """Estimate hand strength as percent of max possible hand"""
        if not self.my_hand:
            return 0.0

        community_cards = round_state.community_cards
        all_cards = self.my_hand + community_cards

        # Convert to standard format if needed
        hole_cards = self.my_hand
        hand_score = evaluate_hand(hole_cards, community_cards)

        # Estimate max possible hand score
        # Best possible hand: Royal Flush = 8_000_014
        max_score = 8_000_014
        strength = hand_score / max_score

        # If we don't have full board, estimate by counting outs and potential
        if len(community_cards) < 5:
            # Add some logic to improve preflop and flop strength estimation
            strength = self._improve_hand_strength_estimate(hole_cards, community_cards, strength)

        return min(max(strength, 0.0), 1.0)

    def _improve_hand_strength_estimate(self, hole_cards: List[str], community_cards: List[str], base_strength: float) -> float:
        """Improve hand strength estimation based on draws and position"""
        if len(community_cards) == 0:  # Preflop
            # Use standard preflop hand ranking
            ranks = [parse_card(c)[0] for c in hole_cards]
            suits = [parse_card(c)[1] for c in hole_cards]
            high_card = max(ranks)
            low_card = min(ranks)
            is_suited = suits[0] == suits[1]
            is_pair = ranks[0] == ranks[1]
            gap = abs(ranks[0] - ranks[1])

            # Simple preflop hand strength table
            if is_pair:
                return (high_card / 14) * 0.9 + 0.1  # Pairs are strong
            if is_suited and gap <= 3:
                return (high_card / 14) * 0.6 + 0.05  # Suited connectors
            if is_suited:
                return (high_card / 14) * 0.4 + 0.05
            if gap <= 3:
                return (high_card / 14) * 0.5  # Connectors
            return (high_card / 14) * 0.3  # Weak hands

        else:  # Flop or Turn - look for draws
            all_cards = hole_cards + community_cards
            ranks = [parse_card(c)[0] for c in all_cards]
            suits = [parse_card(c)[1] for c in all_cards]
            rank_count = {}
            suit_count = {}
            for r in ranks:
                rank_count[r] = rank_count.get(r, 0) + 1
            for s in suits:
                suit_count[s] = suit_count.get(s, 0) + 1

            # Potential flush draw?
            max_suit = max(suit_count.values())
            flush_draw = max_suit == 4 and len(community_cards) == 4  # Backdoor or actual draw
            open_flush_draw = max_suit >= 2 and len(community_cards) == 3  # Can still become flush

            # Potential straight draw?
            unique_ranks = sorted(set(ranks))
            straight_possibilities = 0
            for i in range(len(unique_ranks) - 2):
                if unique_ranks[i+2] - unique_ranks[i] <= 4:
                    straight_possibilities += 1

            # Improve base strength if draws exist
            improvement = 0.0
            if flush_draw or straight_possibilities > 0:
                improvement = 0.2
            elif open_flush_draw or straight_possibilities > 0:
                improvement = 0.1

            return min(base_strength + improvement, 0.95)

        return base_strength

    def _get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling"""
        if remaining_chips <= 0:
            return float('inf')
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if to_call == 0:
            return float('inf')  # Free to call
        if to_call > remaining_chips:
            return 0.0  # Can't call
        return round_state.pot / to_call if to_call > 0 else float('inf')

    def _get_position_multiplier(self, round_state: RoundStateClient) -> float:
        """Adjust strategy based on position"""
        # Simple: assume later position is better
        players = round_state.current_player
        if len(players) == 0:
            return 1.0
        my_index = players.index(self.id) if self.id in players else -1
        if my_index < 0:
            return 1.0
        # Later position gets multiplier > 1
        return 1.0 + (my_index / len(players)) * 0.5

    def _should_raise(self, hand_strength: float, pot_odds: float, position_mult: float, round_state: RoundStateClient, remaining_chips: int) -> bool:
        """Determine if we should raise"""
        # Don't raise if very short stacked
        if remaining_chips < 2 * self.blind_amount:
            return False

        # Don't raise if pot odds are terrible and hand is weak
        if pot_odds < 2 and hand_strength < 0.3:
            return False

        # Strong hand -> raise aggressively
        if hand_strength > 0.7:
            return True

        # Medium hand with good pot odds and position
        if hand_strength > 0.4 and pot_odds > 3 and position_mult > 1.2:
            return True

        # Draw hand with good implied odds
        if hand_strength > 0.3 and pot_odds > 5:
            return True

        return False

    def _calculate_raise_amount(self, hand_strength: float, pot_odds: float, round_state: RoundStateClient, remaining_chips: int) -> int:
        """Calculate appropriate raise amount"""
        min_raise = round_state.min_raise
        max_raise = min(remaining_chips, round_state.max_raise)

        if min_raise >= max_raise:
            return max_raise

        # Base raise on pot size
        pot_based_raise = int(round_state.pot * 0.7)
        hand_multiplier = 1.0
        if hand_strength > 0.8:
            hand_multiplier = 2.0
        elif hand_strength > 0.6:
            hand_multiplier = 1.5
        elif hand_strength < 0.3:
            hand_multiplier = 0.5

        target_raise = int(pot_based_raise * hand_multiplier)
        target_raise = max(min_raise, min(target_raise, max_raise))

        # Ensure it's a valid raise
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        total_bet_after_raise = my_current_bet + target_raise
        if total_bet_after_raise <= current_bet:
            return min_raise  # Default to minimum raise

        return target_raise

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update internal state
            self.game_log[-1] = round_state  # Update latest state

            # Get hand strength
            hand_strength = self._get_my_hand_strength(round_state)
            pot_odds = self._get_pot_odds(round_state, remaining_chips)
            position_mult = self._get_position_multiplier(round_state)

            current_bet = round_state.current_bet
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = current_bet - my_current_bet

            # Can't do anything if already all in
            if remaining_chips <= 0:
                return (PokerAction.CALL, 0)

            # If no bet, we can check
            if amount_to_call <= 0:
                if hand_strength > 0.2:  # Don't check with total junk
                    return (PokerAction.CHECK, 0)
                else:
                    # Occasionally fold weak hands even when can check
                    if random.random() < 0.3:
                        return (PokerAction.FOLD, 0)
                    return (PokerAction.CHECK, 0)

            # If we need to call, decide whether to fold, call or raise
            if amount_to_call > 0:
                # Fold very weak hands
                if hand_strength < 0.15 and pot_odds < 3:
                    return (PokerAction.FOLD, 0)

                # Consider raise
                if self._should_raise(hand_strength, pot_odds, position_mult, round_state, remaining_chips):
                    raise_amount = self._calculate_raise_amount(hand_strength, pot_odds, round_state, remaining_chips)
                    # Validate raise amount: must be at least min_raise and create a higher bet
                    if raise_amount >= round_state.min_raise:
                        total_bet = my_current_bet + raise_amount
                        if total_bet > current_bet:  # Valid raise
                            return (PokerAction.RAISE, raise_amount)

                # Call if we have decent hand or good pot odds
                if hand_strength > 0.2 or pot_odds > 4:
                    return (PokerAction.CALL, 0)

                # Otherwise fold
                return (PokerAction.FOLD, 0)

            # Default action
            return (PokerAction.CALL, 0)

        except Exception as e:
            # Safety net: if any error, fold to avoid crash
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Log result and update statistics
        self.game_log.append(round_state)
        # Could analyze result here, but not necessary for now
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup, could save stats or learn from game
        pass