from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = {}
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.current_round = None
        self.positional_advantage = 0
        self.aggression_factor = 1.0
        self.tightness_threshold = 0.8
        self.hand_strength_estimate = 0.0
        self.tight_aggressive_profile = True
        self.opp_action_history = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): None for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.opp_action_history = {str(pid): [] for pid in all_players if pid != self.id}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        if str(self.id) in round_state.player_bets:
            self_position = self.all_players.index(self.id)
            num_players = len(self.all_players)
            # later position is better
            self.positional_advantage = (num_players - self_position) / num_players
        else:
            self.positional_advantage = 0.5

        if self.current_round == 'Preflop':
            self.hand_strength_estimate = self._evaluate_preflop_hand(self.player_hands.get(str(self.id), []))
        else:
            self.hand_strength_estimate = self._simulate_hand_strength(
                self.player_hands.get(str(self.id), []),
                round_state.community_cards,
                len(self.all_players)
            )

    def _evaluate_preflop_hand(self, hole_cards: List[str]) -> float:
        if not hole_cards or len(hole_cards) != 2:
            return 0.1
        card1, card2 = hole_cards[0], hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]

        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        r1 = rank_values[rank1]
        r2 = rank_values[rank2]

        is_pair = 1.0 if rank1 == rank2 else 0.0
        is_suited = 1.0 if suit1 == suit2 else 0.0
        connected = 1.0 if abs(r1 - r2) == 1 else 0.5 if abs(r1 - r2) == 2 else 0.0
        high_card = max(r1, r2) / 14.0

        score = (
            0.6 * is_pair +
            0.3 * high_card +
            0.15 * is_suited +
            0.1 * connected
        )

        # Normalize to [0,1]
        return min(score, 1.0)

    def _simulate_hand_strength(self, hole_cards: List[str], community_cards: List[str], num_players: int) -> float:
        if len(community_cards) == 0:
            return self._evaluate_preflop_hand(hole_cards)
        # Very simplified strength: check made hands
        all_cards = hole_cards + community_cards
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]

        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        suit_counts = {s: suits.count(s) for s in set(suits)}

        is_flush = max(suit_counts.values()) >= 5
        sorted_ranks = sorted([{'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}[r] for r in ranks])
        sorted_ranks = sorted(set(sorted_ranks))
        is_straight = False
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    is_straight = True
                    break

        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)

        if quads > 0: return 0.95
        if trips and pairs >= 1: return 0.90
        if is_flush and is_straight:
            if max(sorted_ranks) == 14: return 1.0  # Royal
            return 0.98
        if is_flush: return 0.8
        if is_straight: return 0.75
        if trips: return 0.7
        if pairs >= 2: return 0.6
        if pairs == 1: return 0.4
        return max(rank_counts.keys(), key=lambda x: {'A':14,'K':13,'Q':12,'J':11,'T':10}.get(x, int(x)) if x.isdigit() else 0) / 14.0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_player_id = str(self.id)
            current_bet = round_state.current_bet
            my_current_bet = round_state.player_bets.get(current_player_id, 0)
            to_call = current_bet - my_current_bet

            pot_size = round_state.pot
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise

            active_players = len([p for p in round_state.player_bets.keys() if round_state.player_bets[p] >= 0])
            phase = round_state.round

            # Position factor
            position_factor = self.positional_advantage
            hand_strength = self.hand_strength_estimate

            # Adjust tightness based on stack and blinds
            effective_stack = remaining_chips
            big_blind = self.blind_amount * 2 if self.blind_amount > 0 else 50  # default
            stack_in_bb = effective_stack / (big_blind + 1e-8)

            # looser with short stack
            if stack_in_bb < 10:
                self.tightness_threshold = 0.4
            elif stack_in_bb < 20:
                self.tightness_threshold = 0.6
            else:
                self.tightness_threshold = 0.8

            # Estimate odds
            if pot_size > 0:
                pot_odds = to_call / (pot_size + to_call + 1e-8)
            else:
                pot_odds = 0

            # Decision logic
            if to_call == 0:
                if hand_strength >= self.tightness_threshold * 0.7 or (hand_strength >= 0.5 and phase != 'Preflop'):
                    return (PokerAction.RAISE, min(max(min_raise, pot_size // 3), max_raise))
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                if hand_strength >= self.tightness_threshold:
                    if hand_strength > 0.9 and remaining_chips > 100:
                        return (PokerAction.RAISE, min(max(min_raise, pot_size), max_raise))
                    elif hand_strength > 0.7 and stack_in_bb > 15:
                        raise_amount = min(pot_size, max(min_raise, to_call * 2))
                        return (PokerAction.RAISE, min(raise_amount, max_raise))
                    else:
                        if to_call <= remaining_chips * 0.5:  # Call if not committing half stack
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif hand_strength >= 0.5:
                    if pot_odds <= 0.3:  # Good pot odds
                        if to_call <= remaining_chips * 0.3:
                            return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    # Weak hand
                    if to_call > pot_size * 0.5:
                        return (PokerAction.FOLD, 0)
                    # Small chance of bluff when late position and small raise
                    if position_factor > 0.7 and to_call <= min_raise * 2 and stack_in_bb > 20:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

        except Exception as e:
            # On any error, fold to avoid penalty
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent action history if possible (to model future behavior)
        for pid, action in round_state.player_actions.items():
            if pid != str(self.id):
                self.opp_action_history[pid].append({
                    'round': round_state.round,
                    'action': action,
                    'bet': round_state.player_bets.get(pid, 0)
                })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No clean-up needed, but available for logging if extended
        pass