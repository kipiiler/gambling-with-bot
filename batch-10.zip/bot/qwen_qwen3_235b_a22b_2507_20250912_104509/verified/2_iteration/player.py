from typing import List, Tuple, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.hand_strength_estimate = 0.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called when the game starts. """
        if self.id is not None and str(self.id) in player_hands:
            self.hand_cards = player_hands[str(self.id)]
        else:
            self.hand_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each round. """
        community_cards = round_state.community_cards if round_state.community_cards is not None else []
        hole_cards = self.hand_cards if self.hand_cards is not None else []
        
        # Simulate hand strength only if we have our hole cards
        if hole_cards:
            self.hand_strength_estimate = self._simulate_hand_strength(hole_cards, community_cards)
        else:
            self.hand_strength_estimate = 0.5  # Default if we don't know our cards

    def _simulate_hand_strength(self, hole_cards: List[str], community_cards: List[str], simulations=100) -> float:
        """Simulates hand strength by completing hands and comparing."""
        if len(hole_cards) != 2:
            return 0.5

        # If we're pre-flop and don't yet have community cards
        if not community_cards:
            return self._preflop_hand_strength(hole_cards)
        
        # Post-flop: evaluate odds more accurately
        total_wins = 0
        total_simulations = 0

        # Complete the board for simulation
        known_cards = set(hole_cards + community_cards)
        all_ranks = ['A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K']
        all_suits = ['h', 'd', 's', 'c']
        deck = [r + s for r in all_ranks for s in all_suits]
        unknown_cards = [card for card in deck if card not in known_cards]

        for _ in range(simulations):
            # Build full board
            if len(community_cards) == 3:  # Flop
                if len(unknown_cards) < 2:
                    continue
                # Pick turn and river
                remaining = unknown_cards.copy()
                random.shuffle(remaining)
                turn = remaining.pop()
                river = remaining.pop()
                full_board = community_cards + [turn, river]
            elif len(community_cards) == 4:  # Turn
                if not unknown_cards:
                    continue
                random.shuffle(unknown_cards)
                full_board = community_cards + [unknown_cards[0]]
            else:  # River
                full_board = community_cards

            # Evaluate own hand
            my_full_hand = hole_cards + full_board
            my_score = self._evaluate_hand(my_full_hand)

            # Simulate opponents: pick two random cards and evaluate
            if len(full_board) == 5 and len(unknown_cards) >= 2:
                try:
                    remaining_for_opp = [c for c in unknown_cards if c not in full_board]
                    if len(remaining_for_opp) < 2:
                        continue
                    random.shuffle(remaining_for_opp)
                    opp_hole = remaining_for_opp[:2]
                    opp_full = opp_hole + full_board
                    opp_score = self._evaluate_hand(opp_full)
                    
                    if my_score > opp_score:
                        total_wins += 1
                    elif my_score == opp_score:
                        total_wins += 0.5
                except:
                    continue
            total_simulations += 1

        return total_wins / total_simulations if total_simulations > 0 else 0.5

    def _preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """Simple preflop hand strength based on known starting hand rankings."""
        ranks = ['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2']
        rank_values = {r: i for i, r in enumerate(ranks)}
        
        card1, card2 = hole_cards[0][0], hole_cards[1][0]
        suit1, suit2 = hole_cards[0][1], hole_cards[1][1]
        
        is_suited = (suit1 == suit2)
        is_pair = (card1 == card2)
        
        if is_pair:
            rank = max(rank_values[card1], rank_values[card2])
            if rank <= 1:  # AA, KK
                return 0.85
            elif rank <= 3:  # QQ, JJ
                return 0.75
            elif rank <= 5:  # TT, 99
                return 0.65
            else:
                return 0.55
        elif is_suited:
            high_rank = min(rank_values[card1], rank_values[card2])
            if high_rank == 0:  # A + suited
                return 0.6 + (13 - rank_values[max(card1, card2)]) * 0.01
            elif high_rank <= 3:  # KQs, KJs, QJs
                return 0.6
            else:
                return 0.5 + (13 - high_rank) * 0.01
        else:
            high_rank = min(rank_values[card1], rank_values[card2])
            if high_rank == 0:  # A + offsuit
                return 0.55
            else:
                return 0.5 + (13 - high_rank) * 0.005

    def _evaluate_hand(self, cards: List[str]) -> int:
        """Evaluates a 5-card hand strength with a simplified hand value system."""
        if len(cards) > 5:
            from itertools import combinations
            best_score = 0
            for combo in combinations(cards, 5):
                score = self._evaluate_5_card_hand(list(combo))
                if score > best_score:
                    best_score = score
            return best_score
        elif len(cards) == 5:
            return self._evaluate_5_card_hand(cards)
        else:
            # Fallback for edge cases
            return sum([self._card_rank(c) for c in cards])

    def _evaluate_5_card_hand(self, cards: List[str]) -> int:
        """Simplified hand evaluation for 5 cards."""
        def _card_rank(c):
            r = c[0]
            return 14 if r == 'A' else 13 if r == 'K' else 12 if r == 'Q' else 11 if r == 'J' else 10 if r == 'T' else int(r)

        ranks = sorted([_card_rank(c) for c in cards], reverse=True)
        suits = [c[1] for c in cards]

        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] - ranks[i + 1] == 1 for i in range(4))
        
        # Special case for A-5 straight
        if ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]  # Assign A as 1

        # Royal flush, straight flush
        if is_straight and is_flush:
            return 8000000 + ranks[0]
        
        # Four of a kind
        for r in set(ranks):
            if ranks.count(r) == 4:
                kicker = [k for k in ranks if k != r][0]
                return 7000000 + r * 100 + kicker
        
        # Full house
        set_ranks = list(set(ranks))
        if any(ranks.count(r) == 3 for r in set_ranks) and any(ranks.count(r) == 2 for r in set_ranks):
            triplet = next(r for r in set_ranks if ranks.count(r) == 3)
            pair = next(r for r in set_ranks if ranks.count(r) == 2)
            return 6000000 + triplet * 100 + pair
        
        # Flush
        if is_flush:
            return 5000000 + ranks[0] * 10000 + ranks[1] * 100 + ranks[2]
        
        # Straight
        if is_straight:
            return 4000000 + ranks[0]
        
        # Three of a kind
        for r in set_ranks:
            if ranks.count(r) == 3:
                kickers = sorted([k for k in ranks if k != r], reverse=True)
                return 3000000 + r * 100 + kickers[0]
        
        # Two pair
        pairs = [r for r in set_ranks if ranks.count(r) == 2]
        if len(pairs) == 2:
            pairs = sorted(pairs, reverse=True)
            kicker = next(k for k in ranks if ranks.count(k) == 1)
            return 2000000 + pairs[0] * 100 + pairs[1] + kicker
        
        # One pair
        for r in set_ranks:
            if ranks.count(r) == 2:
                kickers = sorted([k for k in ranks if k != r], reverse=True)
                return 1000000 + r * 100 + kickers[0]
        
        # High card
        return ranks[0] * 10000 + ranks[1] * 100 + ranks[2]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards if round_state.community_cards is not None else []
        round_name = round_state.round
        
        # If current_bet is 0, we can check
        if current_bet == 0:
            # Decide whether to bet based on hand strength
            if self.hand_strength_estimate > 0.5:
                amount = min(pot // 2, max_raise)
                amount = max(min_raise, amount) if amount > 0 else min_raise
                return PokerAction.RAISE, amount
            else:
                return PokerAction.CHECK, 0
        
        # Calculate odds: pot odds and equity
        cost_to_call = current_bet
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0
        
        # Avoid division by zero
        pot_odds = cost_to_call / (pot + cost_to_call + 1e-9)
        equity = self.hand_strength_estimate

        # Call if equity > pot odds (pot odds rule)
        if equity > pot_odds:
            # Raise if strong hand
            if equity > 0.7:
                raise_amount = min(pot, max_raise)
                raise_amount = max(min_raise, raise_amount) if raise_amount > 0 else min_raise
                return PokerAction.RAISE, raise_amount
            # Call if marginal
            elif equity > 0.5 or pot_odds < 0.4:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # If behind, consider semi-bluff or fold
            if equity > 0.4 and round_name != "River":
                # Semi-bluff on draws
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Reset per-round state if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        # Clean up if needed
        self.hand_cards = []
        self.hand_strength_estimate = 0.5