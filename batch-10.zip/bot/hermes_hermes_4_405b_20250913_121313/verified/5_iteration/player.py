import itertools
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    
    def _card_to_tuple(self, card_str: str) -> Tuple[int, str]:
        rank_char = card_str[0]
        suit = card_str[1]
        return (self.rank_map[rank_char], suit)
    
    def _evaluate_five(self, five_cards: List[Tuple[int, str]]) -> int:
        ranks = sorted([c[0] for c in five_cards])
        suits = [c[1] for c in five_cards]
        
        flush = len(set(suits)) == 1
        
        straight = False
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) == 5:
            if unique_ranks[-1] - unique_ranks[0] == 4:
                straight = True
            elif set(unique_ranks) == {2, 3, 4, 5, 14}:
                straight = True
        
        count_dict = {}
        for r in ranks:
            count_dict[r] = count_dict.get(r, 0) + 1
        counts = sorted(count_dict.values(), reverse=True)
        
        if straight and flush:
            return 8
        if flush:
            return 5
        if straight:
            return 4
        if counts[0] == 4:
            return 7
        if counts[0] == 3 and len(counts) > 1 and counts[1] == 2:
            return 6
        if counts[0] == 3:
            return 3
        if counts[0] == 2 and len(counts) > 1 and counts[1] == 2:
            return 2
        if counts[0] == 2:
            return 1
        return 0
    
    def evaluate_hand(self, community_cards: List[str]) -> int:
        hole_tuples = [self._card_to_tuple(card) for card in self.hole_cards]
        community_tuples = [self._card_to_tuple(card) for card in community_cards]
        all_tuples = hole_tuples + community_tuples
        
        best_score = -1
        for combo in itertools.combinations(all_tuples, 5):
            score = self._evaluate_five(list(combo))
            if score > best_score:
                best_score = score
        return best_score

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            
            if round_state.round == 'Preflop':
                card1_rank = self.rank_map[self.hole_cards[0][0]]
                card2_rank = self.rank_map[self.hole_cards[1][0]]
                suited = self.hole_cards[0][1] == self.hole_cards[1][1]
                
                has_pair = card1_rank == card2_rank
                has_high_cards = (card1_rank >= 10 and card2_rank >= 10)
                has_ace_king = (card1_rank == 14 and card2_rank == 13) or (card1_rank == 13 and card2_rank == 14)
                has_ace_queen = (card1_rank == 14 and card2_rank == 12) or (card1_rank == 12 and card2_rank == 14)
                
                if has_pair or (suited and has_high_cards) or has_ace_king or has_ace_queen:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        if has_pair or has_ace_king:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                hand_strength = self.evaluate_hand(round_state.community_cards)
                
                if hand_strength >= 4:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        if round_state.max_raise >= round_state.min_raise:
                            return (PokerAction.RAISE, round_state.min_raise)
                        else:
                            return (PokerAction.ALL_IN, 0)
                elif hand_strength == 3:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength == 2:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < round_state.pot / 2:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif hand_strength == 1:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < round_state.pot / 3:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass