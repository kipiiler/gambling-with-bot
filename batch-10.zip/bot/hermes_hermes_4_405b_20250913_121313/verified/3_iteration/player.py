import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.hand_strength_cache = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            
            if round_state.round == 'Preflop':
                return self.handle_preflop(round_state, remaining_chips, call_amount)
            else:
                return self.handle_postflop(round_state, remaining_chips, call_amount)
        except Exception as e:
            return PokerAction.FOLD, 0

    def handle_preflop(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        strong_hands = {'AA', 'KK', 'QQ', 'JJ', 'TT', 'AKs', 'AQs', 'AJs', 'ATs', 'KQs', 'AKo', 'AQo', 'AJo', 'ATo', 'KQo'}
        hand_key = self.get_hand_key(self.hole_cards)
        
        if hand_key not in strong_hands:
            return PokerAction.FOLD, 0
        
        if call_amount == 0:
            if self.id == self.big_blind_player_id:
                if hand_key in {'AA', 'KK', 'QQ'}:
                    amount = max(round_state.min_raise, 3 * self.blind_amount)
                    if amount > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CALL, 0
            else:
                amount = max(round_state.min_raise, 3 * self.blind_amount)
                if amount > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, amount
        else:
            if call_amount > 10 * self.blind_amount:
                return PokerAction.FOLD, 0
            return PokerAction.CALL, 0

    def handle_postflop(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        hand_strength = self.evaluate_hand(self.hole_cards, round_state.community_cards)
        
        if call_amount == 0:
            if hand_strength[0] >= 1:
                bet_amount = max(round_state.min_raise, int(0.66 * round_state.pot))
                if bet_amount > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            else:
                return PokerAction.CALL, 0
        else:
            if hand_strength[0] >= 1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_hand_key(self, cards: List[str]) -> str:
        ranks = [self.card_rank(card) for card in cards]
        suits = [card[1] for card in cards]
        ranks.sort(reverse=True)
        suit_str = 's' if len(set(suits)) == 1 else 'o'
        return f"{self.rank_to_char(ranks[0])}{self.rank_to_char(ranks[1])}{suit_str}"

    def card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        elif rank == 'J': return 11
        elif rank == 'Q': return 12
        elif rank == 'K': return 13
        elif rank == 'A': return 14
        else: return int(rank)

    def rank_to_char(self, rank: int) -> str:
        if rank == 10: return 'T'
        elif rank == 11: return 'J'
        elif rank == 12: return 'Q'
        elif rank == 13: return 'K'
        elif rank == 14: return 'A'
        else: return str(rank)

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple:
        cache_key = (tuple(hole_cards), tuple(community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        cards = hole_cards + community_cards
        if len(cards) < 5:
            return (0,)
        
        best = None
        for combo in itertools.combinations(cards, 5):
            result = self.evaluate_five(combo)
            if best is None or result > best:
                best = result
        
        self.hand_strength_cache[cache_key] = best
        return best

    def evaluate_five(self, combo: Tuple[str]) -> Tuple:
        ranks = sorted([self.card_rank(card) for card in combo], reverse=True)
        suits = [card[1] for card in combo]
        is_flush = len(set(suits)) == 1
        
        is_straight = False
        unique_ranks = list(ranks)
        if len(set(unique_ranks)) == 5:
            if unique_ranks[0] - unique_ranks[4] == 4:
                is_straight = True
            elif set(unique_ranks) == {14, 2, 3, 4, 5}:
                is_straight = True
                unique_ranks = [5, 4, 3, 2, 14]
        
        count = {}
        for r in unique_ranks:
            count[r] = count.get(r, 0) + 1
        count_values = sorted(count.values(), reverse=True)
        count_ranks = sorted(unique_ranks, key=lambda x: (-count[x], -x))
        
        if is_straight and is_flush:
            return (8, unique_ranks[0] if not set(ranks) == {14, 2, 3, 4, 5} else 5)
        
        if count_values[0] == 4:
            quad_rank = count_ranks[0]
            kicker = count_ranks[4]
            return (7, quad_rank, kicker)
        
        if count_values[0] == 3 and count_values[1] == 2:
            trips_rank = count_ranks[0]
            pair_rank = count_ranks[3]
            return (6, trips_rank, pair_rank)
        
        if is_flush:
            return (5,) + tuple(ranks)
        
        if is_straight:
            return (4, unique_ranks[0] if not set(ranks) == {14, 2, 3, 4, 5} else 5)
        
        if count_values[0] == 3:
            trips_rank = count_ranks[0]
            kickers = count_ranks[3:5]
            return (3, trips_rank, kickers[0], kickers[1])
        
        if count_values[0] == 2 and count_values[1] == 2:
            pairs = []
            for r in count_ranks:
                if count[r] == 2 and r not in pairs:
                    pairs.append(r)
                if len(pairs) == 2:
                    break
            kicker = [r for r in count_ranks if count[r] == 1][0]
            return (2, pairs[0], pairs[1], kicker)
        
        if count_values[0] == 2:
            pair_rank = count_ranks[0]
            kickers = [r for r in count_ranks if count[r] == 1][:3]
            return (1, pair_rank, kickers[0], kickers[1], kickers[2])
        
        return (0,) + tuple(ranks)