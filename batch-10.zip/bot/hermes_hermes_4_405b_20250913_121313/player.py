import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_amount = 0
        self.our_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.our_id = self.id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = round_state.player_bets.get(str(self.our_id), 0)
        amount_to_call = round_state.current_bet - our_bet
        if amount_to_call < 0:
            amount_to_call = 0

        if amount_to_call > 0 and amount_to_call >= remaining_chips:
            return (PokerAction.ALL_IN, 0)

        round_name = round_state.round
        if round_name == 'Preflop':
            return self.handle_preflop(round_state, remaining_chips, amount_to_call, our_bet)
        else:
            return self.handle_postflop(round_state, remaining_chips, amount_to_call, our_bet)

    def handle_preflop(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, our_bet: int) -> Tuple[PokerAction, int]:
        hand_key = self.get_hand_key(self.hole_cards)
        strong_hands = ["AA", "KK", "QQ", "JJ", "TT", "AKs", "AQs", "AJs", "KQs"]
        medium_hands = ["AKo", "AQo", "AJo", "KQo", "ATs", "KJs", "QJs", "JTs", "T9s", "99", "88", "77"]

        if hand_key in strong_hands:
            if amount_to_call == 0:
                total_bet = min(round_state.current_bet + round_state.min_raise * 3, our_bet + round_state.max_raise)
                return (PokerAction.RAISE, total_bet)
            else:
                if amount_to_call <= remaining_chips:
                    total_bet = min(round_state.current_bet + round_state.min_raise * 3, our_bet + round_state.max_raise)
                    return (PokerAction.RAISE, total_bet)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_key in medium_hands:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        else:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def handle_postflop(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, our_bet: int) -> Tuple[PokerAction, int]:
        all_cards = self.hole_cards + round_state.community_cards
        hand_rank = self.evaluate_hand(all_cards)
        hand_rank_num = hand_rank[0]

        if hand_rank_num >= 3:  # Three of a kind or better
            if amount_to_call == 0:
                total_bet = min(round_state.current_bet + round_state.min_raise * 2, our_bet + round_state.max_raise)
                return (PokerAction.RAISE, total_bet)
            else:
                if amount_to_call <= remaining_chips:
                    total_bet = min(round_state.current_bet + round_state.min_raise * 2, our_bet + round_state.max_raise)
                    return (PokerAction.RAISE, total_bet)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_rank_num == 2:  # Two pair
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_rank_num == 1:  # One pair
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                if amount_to_call <= remaining_chips and amount_to_call < 2 * self.big_blind_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:  # High card or worse
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    @staticmethod
    def get_hand_key(hole_cards: List[str]) -> str:
        ranks = []
        suits = []
        for card in hole_cards:
            rank_char = card[0]
            suit_char = card[1]
            if rank_char.isdigit():
                rank = int(rank_char)
            else:
                rank = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank_char]
            ranks.append(rank)
            suits.append(suit_char)
        
        ranks_sorted = sorted(ranks, reverse=True)
        key = ""
        if ranks_sorted[0] == ranks_sorted[1]:
            key = f"{ranks_sorted[0]}{ranks_sorted[1]}"
        else:
            key = f"{ranks_sorted[0]}{ranks_sorted[1]}"
            if suits[0] == suits[1]:
                key += "s"
            else:
                key += "o"
        return key

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, ...]:
        card_tuples = []
        for card in cards:
            rank_char = card[0]
            suit_char = card[1]
            if rank_char.isdigit():
                rank = int(rank_char)
            else:
                rank = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank_char]
            card_tuples.append((rank, suit_char))
        
        if len(card_tuples) < 5:
            return (0,)
        
        best_hand = None
        for combo in itertools.combinations(card_tuples, 5):
            hand_eval = self.evaluate_five_card(combo)
            if best_hand is None or hand_eval > best_hand:
                best_hand = hand_eval
        
        return best_hand

    @staticmethod
    def evaluate_five_card(cards: List[Tuple[int, str]]) -> Tuple[int, ...]:
        ranks = sorted([c[0] for c in cards], reverse=True)
        suits = [c[1] for c in cards]
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        count_ranks = sorted(rank_count.values(), reverse=True)
        distinct_ranks = sorted(list(set(ranks)), reverse=True)

        is_flush = len(set(suits)) == 1

        straight_high = None
        if len(distinct_ranks) >= 5:
            for i in range(len(distinct_ranks) - 4):
                if distinct_ranks[i] - distinct_ranks[i+4] == 4:
                    straight_high = distinct_ranks[i]
                    break
            if straight_high is None and set(distinct_ranks) >= {14, 2, 3, 4, 5}:
                straight_high = 5
        is_straight = straight_high is not None

        if is_straight and is_flush:
            return (8, straight_high)
        elif 4 in count_ranks:
            quad_rank = [r for r, c in rank_count.items() if c == 4][0]
            kicker = [r for r in ranks if r != quad_rank][0]
            return (7, quad_rank, kicker)
        elif 3 in count_ranks and 2 in count_ranks:
            three_rank = [r for r, c in rank_count.items() if c == 3][0]
            pair_rank = [r for r, c in rank_count.items() if c == 2][0]
            return (6, three_rank, pair_rank)
        elif is_flush:
            return (5, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])
        elif is_straight:
            return (4, straight_high)
        elif 3 in count_ranks:
            three_rank = [r for r, c in rank_count.items() if c == 3][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)[:2]
            return (3, three_rank, kickers[0], kickers[1])
        elif count_ranks[0] == 2 and count_ranks[1] == 2:
            pairs = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return (2, pairs[0], pairs[1], kicker)
        elif 2 in count_ranks:
            pair_rank = [r for r, c in rank_count.items() if c == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
            return (1, pair_rank, kickers[0], kickers[1], kickers[2])
        else:
            return (0, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])