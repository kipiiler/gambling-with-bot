from typing import List, Tuple
from itertools import combinations
from collections import Counter

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Hand Evaluation Utilities ---

# Card ranks mapping from card character to numeric value for comparison
RANKS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

# Internal Hand Ranking Enum for clarity and comparison
class HandRank:
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8

def _parse_cards(cards: List[str]) -> List[Tuple[int, str]]:
    """ Parses a list of card strings like ['As', 'Th'] into [(14, 's'), (10, 'h')] """
    if not cards:
        return []
    return [(RANKS[c[:-1]], c[-1]) for c in cards]

def _evaluate_5_cards(hand: List[Tuple[int, str]]):
    """ Evaluates a single 5-card hand and returns a comparable tuple (rank, high_cards...). """
    if not hand or len(hand) != 5:
        return (HandRank.HIGH_CARD, 0)
    
    ranks = sorted([card[0] for card in hand], reverse=True)
    suits = [card[1] for card in hand]
    
    is_flush = len(set(suits)) == 1
    
    unique_ranks = sorted(list(set(ranks)), reverse=True)
    is_straight = len(unique_ranks) == 5 and (unique_ranks[0] - unique_ranks[4] == 4)
    
    # Handle Ace-low (A-5) straight
    ace_low_ranks = []
    if not is_straight and unique_ranks == [14, 5, 4, 3, 2]:
        is_straight = True
        ace_low_ranks = [5, 4, 3, 2, 1]

    # Straight Flush / Royal Flush
    if is_straight and is_flush:
        if ace_low_ranks:
            return (HandRank.STRAIGHT_FLUSH, 5)
        return (HandRank.STRAIGHT_FLUSH, ranks[0])

    # For other hands, group by ranks
    rank_counts = Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    main_ranks = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)
    
    # Four of a Kind
    if counts[0] == 4:
        return (HandRank.FOUR_OF_A_KIND, main_ranks[0], main_ranks[1])

    # Full House
    if counts[0] == 3 and len(counts) > 1 and counts[1] == 2:
        return (HandRank.FULL_HOUSE, main_ranks[0], main_ranks[1])
        
    # Flush
    if is_flush:
        return (HandRank.FLUSH,) + tuple(ranks)
        
    # Straight
    if is_straight:
        if ace_low_ranks:
             return (HandRank.STRAIGHT, 5)
        return (HandRank.STRAIGHT, ranks[0])
        
    # Three of a Kind
    if counts[0] == 3:
        kickers = tuple(r for r in main_ranks if r != main_ranks[0])
        return (HandRank.THREE_OF_A_KIND, main_ranks[0]) + kickers
        
    # Two Pair
    if counts[0] == 2 and len(counts) > 1 and counts[1] == 2:
        kicker = tuple(r for r in main_ranks if r != main_ranks[0] and r != main_ranks[1])
        return (HandRank.TWO_PAIR, main_ranks[0], main_ranks[1]) + kicker

    # One Pair
    if counts[0] == 2:
        kickers = tuple(r for r in main_ranks if r != main_ranks[0])
        return (HandRank.ONE_PAIR, main_ranks[0]) + kickers
        
    # High Card
    return (HandRank.HIGH_CARD,) + tuple(ranks)

def _get_best_hand(hole_cards: List[Tuple[int, str]], community_cards: List[Tuple[int, str]]):
    """ Finds the best 5-card hand from a combination of hole and community cards. """
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        # Should not typically happen post-flop, but handles edge cases
        return _evaluate_5_cards(all_cards + [(0, 'x')] * (5 - len(all_cards)))

    best_hand_rank = (-1,)
    for hand_combo in combinations(all_cards, 5):
        current_rank = _evaluate_5_cards(list(hand_combo))
        if current_rank > best_hand_rank:
            best_hand_rank = current_rank
            
    return best_hand_rank

def _get_preflop_tier(hole_cards: List[Tuple[int, str]]) -> int:
    """ Classifies a starting hand into a tier from 1 (best) to 5 (worst). """
    card1, card2 = hole_cards
    rank1, rank2 = sorted([card1[0], card2[0]], reverse=True)
    is_suited = card1[1] == card2[1]
    is_pair = rank1 == rank2
    
    # Tier 1: Super premium
    if is_pair and rank1 >= RANKS['J']: return 1  # JJ, QQ, KK, AA
    if is_suited and rank1 == RANKS['A'] and rank2 == RANKS['K']: return 1 # AKs

    # Tier 2: Very Strong
    if is_pair and rank1 == RANKS['T']: return 2  # TT
    if rank1 == RANKS['A'] and rank2 == RANKS['K']: return 2 # AKo
    if is_suited and rank1 == RANKS['A'] and rank2 >= RANKS['Q']: return 2 # AQs, AKs
    if is_suited and rank1 == RANKS['K'] and rank2 >= RANKS['Q']: return 2 # KQs
    if is_suited and rank1 == RANKS['A'] and rank2 == RANKS['J']: return 2 # AJs

    # Tier 3: Good, playable
    if is_pair and rank1 >= RANKS['8']: return 3 # 88, 99
    if rank1 == RANKS['A'] and rank2 == RANKS['Q']: return 3 # AQo
    if is_suited and rank1 == RANKS['K'] and rank2 == RANKS['J']: return 3 # KJs
    if is_suited and rank1 == RANKS['Q'] and rank2 == RANKS['J']: return 3 # QJs
    if is_suited and rank1 == RANKS['J'] and rank2 == RANKS['T']: return 3 # JTs
    if is_suited and rank1 == RANKS['A'] and rank2 >= RANKS['T']: return 3 # ATs

    # Tier 4: Speculative
    if is_pair: return 4 # 22-77
    if is_suited and (rank1 - rank2 == 1 or (rank1 == 5 and rank2 == 2)): return 4 # Suited connectors
    if is_suited and rank1 == RANKS['A']: return 4 # Suited Aces A2s-A9s
    if rank1 >= RANKS['T'] and rank2 >= RANKS['T']: return 4 # Broadway hands like KTo, QTo

    return 5 # Everything else (trash)

# --- End of Hand Evaluation Utilities ---


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.all_players: List[int] = []
        self.big_blind_amount: int = 10

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called once at the start of the simulation. """
        self.hole_cards = player_hands
        self.all_players = all_players
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each hand. """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Main decision-making function, called when it's our turn. """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        # --- Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            parsed_hole_cards = _parse_cards(self.hole_cards)
            tier = _get_preflop_tier(parsed_hole_cards)

            if tier == 1: # AA, KK, QQ, JJ, AKs
                raise_amount = 3 * self.big_blind_amount
                if round_state.current_bet > self.big_blind_amount: # If there was a prior raise
                    raise_amount = 3 * round_state.current_bet
                return self._make_raise(raise_amount, round_state)

            elif tier == 2: # TT, AKo, AQs, KQs, AJs
                if round_state.current_bet <= self.big_blind_amount: # If unopened
                     raise_amount = int(2.5 * self.big_blind_amount)
                     return self._make_raise(raise_amount, round_state)
                else: # Facing a raise
                    if amount_to_call > remaining_chips / 3: # Fold to very large raises
                        return PokerAction.FOLD, 0
                    return PokerAction.CALL, 0
            
            elif tier <= 4: # Mid-strength and speculative hands
                if can_check: # Free play from big blind
                    return PokerAction.CHECK, 0
                if amount_to_call <= 2 * self.big_blind_amount: # Call small raises
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            else: # Tier 5 (trash)
                return PokerAction.CHECK, 0 if can_check else (PokerAction.FOLD, 0)

        # --- Post-flop Strategy ---
        else:
            parsed_hole = _parse_cards(self.hole_cards)
            parsed_comm = _parse_cards(round_state.community_cards)
            best_hand = _get_best_hand(parsed_hole, parsed_comm)
            hand_rank = best_hand[0]

            # Monster hand: Full House or better
            if hand_rank >= HandRank.FULL_HOUSE:
                raise_amount = round_state.pot  # Bet the pot for value
                return self._make_raise(raise_amount, round_state)

            # Strong hand: Straight or Flush
            elif hand_rank >= HandRank.STRAIGHT:
                raise_amount = int(0.75 * round_state.pot)
                if can_check: # Bet if checked to
                    return self._make_raise(raise_amount, round_state)
                else: # Raise if facing a bet
                    return self._make_raise(raise_amount, round_state)

            # Good hand: Two Pair or Three of a Kind
            elif hand_rank >= HandRank.TWO_PAIR:
                if can_check:
                    # Bet for value if nobody has bet yet
                    bet_amount = int(0.5 * round_state.pot)
                    return self._make_raise(bet_amount, round_state)
                else:
                    # Call reasonable bets, don't get pushed off a good hand easily
                    if amount_to_call < round_state.pot:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            
            # Weak/Drawing hand: One Pair or High Card
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    # Use simple pot odds; only call with weak hands if it's cheap
                    pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)
                    if pot_odds < 0.25: # Calling if contributing <25% of the pot
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

        # Fallback action if no other logic is met
        return PokerAction.CHECK, 0 if can_check else (PokerAction.FOLD, 0)

    def _make_raise(self, amount: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        """
        A robust helper function to safely make a raise.
        It handles invalid raise amounts and short stacks, preventing the bot from
        making illegal moves and getting folded. This fixes the primary error from Iteration 1.
        """
        min_r = round_state.min_raise
        max_r = round_state.max_raise
        
        # If raising is not possible (e.g., minimum raise is more than our stack),
        # our only aggressive option is to go all-in.
        if min_r > max_r:
            return PokerAction.ALL_IN, 0

        raise_amount = int(amount)

        # Clamp our desired raise amount to be within the legal min/max
        final_raise = min(max(raise_amount, min_r), max_r)
        
        # If the clamped amount is our entire stack, it's an ALL_IN, not a RAISE
        if final_raise >= max_r:
            return PokerAction.ALL_IN, 0
            
        # If we can make a valid, positive raise, do it.
        if final_raise > 0:
            return PokerAction.RAISE, final_raise
        
        # Fallback: if our raise calculation resulted in 0 or an invalid amount,
        # default to a safer, passive action to avoid an error.
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        else:
            # If we can't raise, we will just call.
            return PokerAction.CALL, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each hand. Can be used for opponent modeling. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game simulation. """
        pass