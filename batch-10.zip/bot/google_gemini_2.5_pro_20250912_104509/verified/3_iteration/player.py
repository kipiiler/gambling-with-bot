from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.starting_chips: int = 0
        self.big_blind_amount: int = 0
        self.all_player_ids: List[int] = []

        # Hand rank constants for clarity
        self.HIGH_CARD = 0
        self.ONE_PAIR = 1
        self.TWO_PAIR = 2
        self.THREE_OF_A_KIND = 3
        self.STRAIGHT = 4
        self.FLUSH = 5
        self.FULL_HOUSE = 6
        self.FOUR_OF_A_KIND = 7
        self.STRAIGHT_FLUSH = 8
        self.ROYAL_FLUSH = 9

        self.rank_map = {
            "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
            "T": 10, "J": 11, "Q": 12, "K": 13, "A": 14
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.all_player_ids = all_players
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Converts a card string like 'Ah' to a tuple (14, 'h')."""
        rank = self.rank_map[card[:-1]]
        suit = card[-1]
        return rank, suit

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]) -> Tuple:
        """Evaluates a 5-card hand and returns a score tuple for comparison."""
        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        
        is_flush = len(set(suits)) == 1
        
        # Ace-low straight check
        is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)) or (ranks == [14, 5, 4, 3, 2])
        
        # If ace-low straight, treat Ace as 1 for ranking purposes
        straight_ranks = ranks
        if ranks == [14, 5, 4, 3, 2]:
            straight_ranks = [5, 4, 3, 2, 1]

        if is_straight and is_flush:
            if ranks == [14, 13, 12, 11, 10]:
                return (self.ROYAL_FLUSH,)
            return (self.STRAIGHT_FLUSH, *straight_ranks)

        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)

        if counts[0] == 4:
            four_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r in ranks if r != four_rank][0]
            return (self.FOUR_OF_A_KIND, four_rank, kicker)
        if counts == [3, 2]:
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            two_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return (self.FULL_HOUSE, three_rank, two_rank)
        if is_flush:
            return (self.FLUSH, *ranks)
        if is_straight:
            return (self.STRAIGHT, *straight_ranks)
        if counts[0] == 3:
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)
            return (self.THREE_OF_A_KIND, three_rank, *kickers)
        if counts == [2, 2, 1]:
            pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (self.TWO_PAIR, *pair_ranks, kicker)
        if counts[0] == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return (self.ONE_PAIR, pair_rank, *kickers)
        
        return (self.HIGH_CARD, *ranks)

    def _get_best_hand_score(self, hole_cards: List[str], community_cards: List[str]) -> Tuple:
        """Finds the best 5-card hand from available cards and returns its score."""
        all_cards_str = hole_cards + community_cards
        if len(all_cards_str) < 5:
            return self._evaluate_5_card_hand([self._parse_card(c) for c in all_cards_str])

        parsed_cards = [self._parse_card(c) for c in all_cards_str]
        
        best_score = (-1,)
        for hand_combo in combinations(parsed_cards, 5):
            score = self._evaluate_5_card_hand(list(hand_combo))
            if score > best_score:
                best_score = score
        
        return best_score

    def _get_preflop_strength(self, hand: List[str]) -> str:
        """Categorizes pre-flop hand strength for heads-up and multi-way."""
        card1, card2 = self._parse_card(hand[0]), self._parse_card(hand[1])
        r1, s1 = card1
        r2, s2 = card2
        
        high, low = (r1, r2) if r1 > r2 else (r2, r1)
        is_suited = s1 == s2
        is_pair = r1 == r2

        if is_pair and high >= 10: return "strong"  # TT+
        if high == 14 and low >= 11: return "strong"  # AK, AQ, AJ
        if high == 13 and low >= 12 and is_suited: return "strong" # KQs

        if is_pair: return "medium" # 22-99
        if high == 14: return "medium" # Any Ace
        if high >= 11 and is_suited: return "medium" # Suited broadway
        if high >= 10 and low >= 8 and (is_suited or high - low < 3): return "medium" # Connectors

        return "weak"

    def _get_draw_info(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[bool, bool, bool]:
        """Detects flush and straight draws."""
        all_cards_p = [self._parse_card(c) for c in hole_cards + community_cards]
        hole_cards_p = [self._parse_card(c) for c in hole_cards]
        
        suits = Counter(c[1] for c in all_cards_p)
        has_flush_draw = False
        if 4 in suits.values():
            f_suit = [s for s, count in suits.items() if count == 4][0]
            if any(card[1] == f_suit for card in hole_cards_p):
                has_flush_draw = True

        all_ranks = set(c[0] for c in all_cards_p)
        hole_ranks = set(c[0] for c in hole_cards_p)
        
        is_oesd = False
        has_gutshot = False
        
        if hole_ranks.isdisjoint(all_ranks): # Should not happen
            return has_flush_draw, False, False

        possible_straights = [set(range(r, r + 5)) for r in range(2, 11)] + [{14, 2, 3, 4, 5}]
        
        outs = 0
        for s_set in possible_straights:
            matches = all_ranks.intersection(s_set)
            if len(matches) == 4 and hole_ranks.intersection(matches):
                missing = s_set.difference(all_ranks).pop()
                is_end = (missing == min(s_set) or missing == max(s_set))
                
                # Special handling for A-5 straight (ranks 2 and 14 are ends)
                if s_set == {14,2,3,4,5} and missing not in [2,14]:
                    outs = max(outs, 4) # Gutshot
                elif is_end:
                    outs = max(outs, 8) # OESD
                else:
                    outs = max(outs, 4) # Gutshot

        is_oesd = outs >= 8
        has_straight_draw = outs >= 4
        return has_flush_draw, has_straight_draw, is_oesd

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot

        if to_call >= remaining_chips:
            score = self._get_best_hand_score(self.hand, round_state.community_cards)
            if round_state.round == 'Preflop' and self._get_preflop_strength(self.hand) == "strong":
                return PokerAction.ALL_IN, 0
            if score[0] >= self.TWO_PAIR:
                return PokerAction.ALL_IN, 0
            if round_state.round != 'River':
                has_flush_draw, _, is_oesd = self._get_draw_info(self.hand, round_state.community_cards)
                if has_flush_draw or is_oesd:
                    pot_odds = to_call / (pot + to_call + 1e-9)
                    if pot_odds < 0.4:  # Call if getting better than 2.5:1
                        return PokerAction.ALL_IN, 0
            return PokerAction.FOLD, 0

        if round_state.round == 'Preflop':
            strength = self._get_preflop_strength(self.hand)
            if strength == 'strong':
                raise_amt = round_state.current_bet * 3 if round_state.current_bet > self.big_blind_amount else self.big_blind_amount * 3
                return PokerAction.RAISE, int(min(max(raise_amt, round_state.min_raise), remaining_chips))
            elif strength == 'medium':
                if to_call == 0: return PokerAction.CHECK, 0
                if to_call <= remaining_chips * 0.05 and to_call <= self.big_blind_amount * 4:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else: # Weak
                return PokerAction.CHECK, 0 if to_call == 0 else PokerAction.FOLD, 0
        
        score = self._get_best_hand_score(self.hand, round_state.community_cards)
        hand_rank = score[0]
        has_flush_draw, has_straight_draw, is_oesd = self._get_draw_info(self.hand, round_state.community_cards)

        if hand_rank >= self.THREE_OF_A_KIND: # Monster hand
            if to_call == 0:
                bet = int(pot * 0.75)
                return PokerAction.RAISE, min(bet, remaining_chips)
            else:
                raise_amt = min(to_call * 2 + pot, remaining_chips)
                return PokerAction.RAISE, int(max(raise_amt, round_state.min_raise))

        if hand_rank == self.TWO_PAIR: # Strong hand
            if to_call == 0:
                bet = int(pot * 0.6)
                return PokerAction.RAISE, min(bet, remaining_chips)
            else:
                if to_call < pot * 0.5:
                    raise_amt = min(to_call * 3, remaining_chips)
                    return PokerAction.RAISE, int(max(raise_amt, round_state.min_raise))
                return PokerAction.CALL, 0

        if hand_rank == self.ONE_PAIR: # Medium hand
            if to_call == 0:
                bet = int(pot * 0.5)
                return PokerAction.RAISE, min(bet, remaining_chips)
            else:
                if to_call < pot * 0.4: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        if (has_flush_draw or is_oesd) and round_state.round != 'River': # Strong draw
            pot_odds = to_call / (pot + to_call + 1e-9) if to_call > 0 else 0
            equity = 0.35 if round_state.round == 'Flop' else 0.18 # Approx. equity
            if to_call == 0: # Semi-bluff
                bet = int(pot * 0.6)
                return PokerAction.RAISE, min(bet, remaining_chips)
            elif equity > pot_odds:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Trash / Busted Draw
        return PokerAction.CHECK, 0 if to_call == 0 else PokerAction.FOLD, 0