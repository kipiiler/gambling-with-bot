import collections
from itertools import combinations
from typing import List, Tuple, Any

# These enums and the Bot class are provided by the competition framework.
# They are included here for context and so the file can be run standalone for testing.
from enum import Enum

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

from dataclasses import dataclass
from typing import Dict

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

from abc import ABC, abstractmethod

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass
    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass
    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

# --- Constants and Card Utilities ---

RANKS = '23456789TJQKA'
SUITS = 'shdc'

def _parse_card(card: str) -> Tuple[int, str]:
    """Parses a card string like 'Ah' into a tuple (rank, suit), e.g., (14, 'h')."""
    rank = card[:-1]
    suit = card[-1]
    rank_value = RANKS.find(rank) + 2
    return rank_value, suit

def _get_hand_score(hand: List[Tuple[int, str]]) -> Tuple:
    """
    Evaluates a 5-card hand and returns a tuple representing its rank.
    Higher tuples are better hands.
    (hand_rank, high_card_1, high_card_2, ...)
    - 9: Straight flush
    - 8: Four of a kind
    - 7: Full house
    - 6: Flush
    - 5: Straight
    - 4: Three of a kind
    - 3: Two pair
    - 2: One pair
    - 1: High card
    """
    if not hand or len(hand) != 5:
        return (0,)

    ranks = sorted([card[0] for card in hand], reverse=True)
    suits = [card[1] for card in hand]
    
    is_flush = len(set(suits)) == 1
    # Ace-low (wheel) straight: A,2,3,4,5 becomes ranks 14,5,4,3,2
    is_straight = (ranks[0] - ranks[4] == 4 and len(set(ranks)) == 5) or (ranks == [14, 5, 4, 3, 2])

    if is_straight and is_flush:
        # Handle Ace-low straight flush case
        return (9, ranks[0] if ranks != [14, 5, 4, 3, 2] else 5)
    
    rank_counts = collections.Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    main_ranks = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)
    
    if counts[0] == 4:
        return (8, main_ranks[0], main_ranks[1])
    if counts == [3, 2]:
        return (7, main_ranks[0], main_ranks[1])
    if is_flush:
        return (6,) + tuple(ranks)
    if is_straight:
        return (5, ranks[0] if ranks != [14, 5, 4, 3, 2] else 5)
    if counts[0] == 3:
        kickers = tuple(r for r in main_ranks[1:])
        return (4, main_ranks[0]) + kickers
    if counts == [2, 2, 1]:
        return (3, main_ranks[0], main_ranks[1], main_ranks[2])
    if counts[0] == 2:
        kickers = tuple(r for r in main_ranks[1:])
        return (2, main_ranks[0]) + kickers
        
    return (1,) + tuple(ranks)

def _evaluate_7_card_hand(hole_cards: List[str], community_cards: List[str]) -> Tuple:
    """Finds the best 5-card hand from a combination of 7 cards."""
    if not hole_cards: return (0,)
    
    parsed_hole = [_parse_card(c) for c in hole_cards]
    parsed_community = [_parse_card(c) for c in community_cards]
    all_cards = parsed_hole + parsed_community
    
    if len(all_cards) < 5:
        # Not enough cards for a full hand, score what we have
        if len(all_cards) == 0: return (0, )
        ranks = sorted([c[0] for c in all_cards], reverse=True)
        is_pair = len(set(ranks)) != len(ranks)
        if is_pair:
            return (2,) + tuple(ranks)
        else:
            return (1,) + tuple(ranks)

    best_score = (0,)
    for combo in combinations(all_cards, 5):
        score = _get_hand_score(list(combo))
        if score > best_score:
            best_score = score
            
    return best_score

def _get_preflop_strength(hand: List[str]) -> float:
    """Assigns a strength score to a pre-flop hand (0-1)."""
    if not hand or len(hand) != 2:
        return 0.0

    c1, c2 = _parse_card(hand[0]), _parse_card(hand[1])
    r1, s1 = c1
    r2, s2 = c2

    if r1 < r2:
        r1, r2 = r2, r1

    score = (r1 + r2) / 28.0 # Base score on high cards (max A+A = 28)
    
    # Bonus for pairs
    if r1 == r2:
        score += 0.5
        if r1 >= 10: # Premium pairs (TT+)
             score += (r1 - 9) * 0.05
    # Bonus for suited connectors
    elif s1 == s2:
        score += 0.1
        if abs(r1 - r2) < 5: # Connected or 1-gap
            score += (5 - abs(r1-r2)) * 0.03
    
    return min(score, 1.0)

# --- The Bot Implementation ---

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.all_players: List[int] = []
        self.starting_chips: int = 0
        self.player_bets: dict = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the game simulation."""
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round (hand)."""
        self.player_bets = round_state.player_bets

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Core decision-making function."""
        amount_to_call = round_state.current_bet - self.player_bets.get(str(self.id), 0)
        can_check = amount_to_call == 0
        is_all_in = remaining_chips <= amount_to_call

        if is_all_in:
            return PokerAction.ALL_IN, 0

        pot = round_state.pot

        if round_state.round == "Preflop":
            strength = _get_preflop_strength(self.my_hand)
            
            # Raise with very strong hands
            if strength > 0.8:  # AA, KK, QQ, AKs
                raise_amount = min(max(pot * 2, round_state.min_raise), round_state.max_raise)
                return PokerAction.RAISE, int(raise_amount)
            
            # Play strong-to-good hands
            elif strength > 0.65:  # JJ, TT, AQs, AKo, AJs
                if amount_to_call == 0:  # If no one has raised yet
                    raise_amount = min(max(pot, round_state.min_raise), round_state.max_raise)
                    return PokerAction.RAISE, int(raise_amount)
                elif amount_to_call <= remaining_chips * 0.1:  # Call small raises
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Play speculative hands
            elif strength > 0.5:
                # Call small amounts to see the flop
                if amount_to_call <= remaining_chips * 0.05 and amount_to_call < pot * 0.2:
                    return PokerAction.CALL, 0
                else:
                    return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
            
            else:  # Weak hands
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        else: # Post-flop (Flop, Turn, River)
            hand_score_tuple = _evaluate_7_card_hand(self.my_hand, round_state.community_cards)
            hand_rank = hand_score_tuple[0]

            # Monster hand (Full House or better)
            if hand_rank >= 7:
                raise_amount = min(int(pot * 0.8), round_state.max_raise)
                if raise_amount > round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0

            # Strong hand (Straight, Flush, Trips)
            elif hand_rank >= 4:
                bet_amount = int(pot * 0.6)
                if can_check:
                    raise_amount = min(bet_amount, round_state.max_raise)
                    if raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CHECK, 0
                elif amount_to_call < remaining_chips * 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Medium hand (Two Pair, Top Pair)
            elif hand_rank >= 2:
                # Rudimentary check if we have top pair or better
                board_ranks = [_parse_card(c)[0] for c in round_state.community_cards]
                board_high_rank = max(board_ranks) if board_ranks else 0
                is_top_pair = hand_rank == 2 and hand_score_tuple[1] >= board_high_rank

                if is_top_pair or hand_rank == 3: # Two pair or top pair
                    bet_amount = int(pot * 0.4)
                    if can_check:
                        raise_amount = min(bet_amount, round_state.max_raise)
                        if raise_amount >= round_state.min_raise:
                            return PokerAction.RAISE, raise_amount
                        return PokerAction.CHECK, 0
                    
                    if amount_to_call < remaining_chips * 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Lower pair
                    if can_check:
                        return PokerAction.CHECK, 0
                    if amount_to_call < pot * 0.1: # Call tiny bets
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

            # Weak hand / Draw
            else:
                # Very simple draw/bluff logic for now: check/fold
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
            
        # Fallback Logic (should not be reached)
        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass