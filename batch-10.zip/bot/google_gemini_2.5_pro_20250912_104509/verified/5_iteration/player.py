import random
from typing import List, Tuple
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Card and Hand Evaluation Utilities ---

CARD_RANKS = '23456789TJQKA'
RANK_MAP = {rank: i for i, rank in enumerate(CARD_RANKS)}

class Card:
    """Represents a single playing card."""
    def __init__(self, rank_str: str, suit_str: str):
        self.rank_str = rank_str
        self.suit_str = suit_str
        self.rank = RANK_MAP[rank_str]
        self.suit = suit_str

    def __str__(self) -> str:
        return f"{self.rank_str}{self.suit_str}"

    def __repr__(self) -> str:
        return self.__str__()

def parse_card(card_str: str) -> Card:
    """Parses a card string like 'Th' into a Card object."""
    return Card(card_str[0], card_str[1])

def get_hand_rank(hand: List[Card]) -> Tuple:
    """
    Evaluates a 5-card hand and returns a sortable tuple representing its rank.
    Higher tuples represent better hands.
    e.g., (8, (12,)) for a Straight Flush, King high.
          (1, (10, 12, 9, 8)) for a pair of Jacks with A,T,9 kickers.
    """
    if len(hand) != 5:
        return (-1,)

    ranks = sorted([card.rank for card in hand], reverse=True)
    suits = {card.suit for card in hand}
    is_flush = len(suits) == 1
    
    is_straight = all(ranks[i] - 1 == ranks[i+1] for i in range(4))
    if not is_straight and ranks == [12, 3, 2, 1, 0]: # Ace-low straight: A,5,4,3,2
        is_straight = True
        ranks = [3, 2, 1, 0, -1] # Re-assign ranks for comparison

    if is_straight and is_flush:
        return (8, tuple(ranks)) # Straight Flush (and Royal Flush)

    rank_counts = {r: ranks.count(r) for r in set(ranks)}
    counts = sorted(rank_counts.values(), reverse=True)
    
    if counts[0] == 4: # Four of a Kind
        major = [r for r, c in rank_counts.items() if c == 4][0]
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (7, (major, kicker))
    
    if counts == [3, 2]: # Full House
        three = [r for r, c in rank_counts.items() if c == 3][0]
        two = [r for r, c in rank_counts.items() if c == 2][0]
        return (6, (three, two))

    if is_flush:
        return (5, tuple(ranks))
    
    if is_straight:
        return (4, tuple(ranks))
    
    if counts[0] == 3: # Three of a Kind
        three = [r for r, c in rank_counts.items() if c == 3][0]
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return (3, (three, *kickers))

    if counts == [2, 2, 1]: # Two Pair
        pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (2, (*pairs, kicker))

    if counts[0] == 2: # One Pair
        pair = [r for r, c in rank_counts.items() if c == 2][0]
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return (1, (pair, *kickers))

    return (0, tuple(ranks)) # High Card

def get_best_hand(cards: List[Card]) -> Tuple:
    """Finds the best 5-card hand from a list of cards (usually 7)."""
    best_rank = (-1,)
    for combo in combinations(cards, 5):
        rank = get_hand_rank(list(combo))
        if rank > best_rank:
            best_rank = rank
    return best_rank

# --- Bot Implementation ---

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[Card] = []
        self.all_players_at_start: List[int] = []
        self.big_blind_amount: int = 0
        self.num_simulations: int = 500

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = [ parse_card(c) for c in player_hands ]
        self.all_players_at_start = all_players
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _get_hand_strength(self, round_state: RoundStateClient) -> float:
        """
        Calculates hand strength via Monte Carlo simulation.
        Returns a win probability from 0.0 to 1.0.
        """
        community_cards = [parse_card(c) for c in round_state.community_cards]

        used_card_strs = {str(c) for c in self.hole_cards} | {str(c) for c in community_cards}
        deck = [parse_card(f"{r}{s}") for r in CARD_RANKS for s in 'shdc' if f"{r}{s}" not in used_card_strs]

        my_id_str = str(self.id)
        active_opponents_ids = [
            pid for pid in self.all_players_at_start 
            if str(pid) in round_state.player_bets 
            and pid != self.id 
            and round_state.player_actions.get(str(pid), '') != 'Fold'
        ]
        
        if not active_opponents_ids:
            return 1.0

        wins = 0
        num_opponents = len(active_opponents_ids)
        cards_to_deal = 5 - len(community_cards)

        for _ in range(self.num_simulations):
            random.shuffle(deck)
            
            sim_community = community_cards + deck[:cards_to_deal]
            my_best_hand = get_best_hand(self.hole_cards + sim_community)
            
            is_winner = True
            deck_idx_start = cards_to_deal
            for i in range(num_opponents):
                opp_hand = deck[deck_idx_start : deck_idx_start + 2]
                opp_best_hand = get_best_hand(opp_hand + sim_community)
                if opp_best_hand > my_best_hand:
                    is_winner = False
                    break
                deck_idx_start += 2
            
            if is_winner:
                wins += 1

        return wins / self.num_simulations

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        call_cost = round_state.current_bet - my_bet
        can_check = call_cost == 0

        pot_odds = 0
        if call_cost > 0:
            total_pot_if_call = round_state.pot + call_cost
            pot_odds = call_cost / (total_pot_if_call + 1e-9) # Avoid division by zero

        win_rate = self._get_hand_strength(round_state)

        # --- Decision Making ---

        is_preflop = round_state.round == 'Preflop'
        num_active_players = sum(1 for pid in self.all_players_at_start if round_state.player_actions.get(str(pid), '') != 'Fold')

        # Adjust confidence thresholds based on number of players
        strong_hand_threshold = 0.6 + 0.05 * (num_active_players - 2)
        decent_hand_threshold = 0.4 + 0.05 * (num_active_players - 2)

        # 1. Strong hands: Value bet or raise
        if win_rate > strong_hand_threshold:
            if is_preflop:
                # Standard opening raise: 3x Big Blind. If facing a raise, min_raise again.
                raise_amount = max(3 * self.big_blind_amount, round_state.min_raise)
            else:
                # Post-flop: Bet 50-75% of the pot for value
                raise_amount = int(round_state.pot * random.uniform(0.5, 0.75))
            
            # --- Action Validation ---
            if raise_amount >= remaining_chips or raise_amount >= round_state.max_raise:
                return PokerAction.ALL_IN, 0
            
            # Ensure raise is at least min_raise
            validated_raise = max(raise_amount, round_state.min_raise)
            
            # If we don't have enough chips for a min_raise, our only aggressive option is all-in
            if round_state.min_raise > round_state.max_raise:
                return PokerAction.ALL_IN, 0

            return PokerAction.RAISE, int(validated_raise)

        # 2. Medium hands or drawing hands with good odds
        if win_rate > pot_odds:
            # If facing a large bet, be more cautious
            if not is_preflop and call_cost > (round_state.pot * 0.75):
                # Fold to oversized bets unless we have a very strong draw
                if win_rate < (pot_odds * 1.2): # Need better odds to call big bets
                    return PokerAction.FOLD, 0

            if can_check:
                # Check with medium hands to keep the pot small
                return PokerAction.CHECK, 0
            
            if call_cost < remaining_chips * 0.3: # Don't commit too much with a medium hand
                return PokerAction.CALL, 0
            else: # Bet is too large for a medium strength hand
                return PokerAction.FOLD, 0

        # 3. Weak hands: Fold or check
        if can_check:
            return PokerAction.CHECK, 0
        else:
            # Special case for small blind call pre-flop
            if is_preflop and call_cost == (self.big_blind_amount / 2):
                if win_rate > 0.25: # Very loose call from SB if no one raised
                    return PokerAction.CALL, 0
            
            return PokerAction.FOLD, 0