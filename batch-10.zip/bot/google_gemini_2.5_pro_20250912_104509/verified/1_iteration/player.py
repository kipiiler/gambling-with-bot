from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import itertools
from collections import Counter

# Constants for card and hand evaluation
RANKS = '23456789TJQKA'
RANK_MAP = {rank: i for i, rank in enumerate(RANKS, 2)}

HAND_STRENGTH_MAP = {
    "ROYAL_FLUSH": 10,
    "STRAIGHT_FLUSH": 9,
    "FOUR_OF_A_KIND": 8,
    "FULL_HOUSE": 7,
    "FLUSH": 6,
    "STRAIGHT": 5,
    "THREE_OF_A_KIND": 4,
    "TWO_PAIR": 3,
    "ONE_PAIR": 2,
    "HIGH_CARD": 1,
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.all_my_hands: List[List[str]] = []
        self.current_hand: List[str] = []
        self.starting_chips = 0
        self.big_blind_amount = 0
        self.preflop_aggressor_id = None

    def _get_preflop_hand_key(self, cards: List[str]) -> str:
        """Generates a canonical key for a 2-card hand, e.g., 'AKs', 'T9o', '77'."""
        card1_rank_char, card1_suit = cards[0][0], cards[0][1]
        card2_rank_char, card2_suit = cards[1][0], cards[1][1]
        
        rank1_val = RANK_MAP[card1_rank_char]
        rank2_val = RANK_MAP[card2_rank_char]
        
        suited_char = 's' if card1_suit == card2_suit else 'o'
        
        if rank1_val == rank2_val:
            return card1_rank_char + card2_rank_char
            
        if rank1_val > rank2_val:
            return card1_rank_char + card2_rank_char + suited_char
        else:
            return card2_rank_char + card1_rank_char + suited_char

    def _get_preflop_strength(self, cards: List[str]) -> float:
        """Returns pre-flop hand strength (0-1) based on a simplified chart."""
        preflop_chart = {
            'AA': 90, 'KK': 85, 'QQ': 80, 'JJ': 75, 'TT': 70, '99': 65, '88': 60, '77': 55, '66': 50, '55': 45, '44': 40, '33': 35, '22': 30,
            'AKs': 68, 'AQs': 66, 'AJs': 64, 'ATs': 62, 'A9s': 55, 'A8s': 53, 'A7s': 51, 'A6s': 49, 'A5s': 47, 'A4s': 45, 'A3s': 43, 'A2s': 41,
            'KQs': 62, 'KJs': 60, 'KTs': 58, 'QJs': 56, 'QTs': 54, 'JTs': 52,
            'AKo': 66, 'AQo': 64, 'AJo': 62, 'ATo': 60, 'KQo': 60,
        }
        key = self._get_preflop_hand_key(cards)
        base_strength = preflop_chart.get(key, 0)

        if base_strength == 0:
            rank1, suit1 = cards[0][0], cards[0][1]
            rank2, suit2 = cards[1][0], cards[1][1]
            r1_val, r2_val = RANK_MAP[rank1], RANK_MAP[rank2]
            
            non_chart_base = (r1_val + r2_val) * 1.5
            if suit1 == suit2:
                non_chart_base += 10
            if abs(r1_val - r2_val) == 1:
                non_chart_base += 5
            base_strength = non_chart_base

        return base_strength / 100.0

    def _parse_cards(self, cards_str: List[str]) -> List[Tuple[int, str]]:
        return [(RANK_MAP[c[0]], c[1]) for c in cards_str]

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]):
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        
        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] == ranks[0] - i for i in range(5))
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        
        if is_ace_low_straight:
            is_straight = True
            ranks_for_eval = [5, 4, 3, 2, 1]
        else:
            ranks_for_eval = ranks
            
        if is_straight and is_flush:
            return (HAND_STRENGTH_MAP["STRAIGHT_FLUSH"], ranks_for_eval)
            
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)
        
        if counts[0] == 4:
            return (HAND_STRENGTH_MAP["FOUR_OF_A_KIND"], main_ranks)
        if counts == [3, 2]:
            return (HAND_STRENGTH_MAP["FULL_HOUSE"], main_ranks)
        if is_flush:
            return (HAND_STRENGTH_MAP["FLUSH"], ranks)
        if is_straight:
            return (HAND_STRENGTH_MAP["STRAIGHT"], ranks_for_eval)
        if counts[0] == 3:
            return (HAND_STRENGTH_MAP["THREE_OF_A_KIND"], main_ranks)
        if counts == [2, 2, 1]:
            return (HAND_STRENGTH_MAP["TWO_PAIR"], main_ranks)
        if counts[0] == 2:
            return (HAND_STRENGTH_MAP["ONE_PAIR"], main_ranks)
        
        return (HAND_STRENGTH_MAP["HIGH_CARD"], ranks)

    def _evaluate_7_cards(self, hole_cards: List[str], community_cards: List[str]):
        if not hole_cards: return ((0, []), 0)
        
        all_cards_str = hole_cards + community_cards
        all_cards = self._parse_cards(all_cards_str)
        
        best_rank = (0, [])
        if len(all_cards) >= 5:
            for hand_combo in itertools.combinations(all_cards, 5):
                rank = self._evaluate_5_card_hand(list(hand_combo))
                if rank[0] > best_rank[0] or (rank[0] == best_rank[0] and rank[1] > best_rank[1]):
                    best_rank = rank
        
        outs = self._calculate_outs(all_cards, best_rank)
        return best_rank, outs

    def _calculate_outs(self, all_cards, best_rank):
        if len(all_cards) >= 7 or best_rank[0] >= HAND_STRENGTH_MAP["STRAIGHT_FLUSH"]:
            return 0

        my_card_ranks = [c[0] for c in all_cards]
        my_card_suits = [c[1] for c in all_cards]
        outs = set()

        # Flush draw
        suit_counts = Counter(my_card_suits)
        for suit, count in suit_counts.items():
            if count == 4:
                for rank_val in range(2, 15):
                    if rank_val not in my_card_ranks or (rank_val in my_card_ranks and (rank_val, suit) not in all_cards):
                         outs.add((rank_val, suit))

        # Straight draw
        unique_ranks = sorted(list(set(my_card_ranks)))
        for i in range(len(unique_ranks) - 3):
            sub_ranks = unique_ranks[i:i+4]
            if max(sub_ranks) - min(sub_ranks) == 3: # 4 connected
                low_end, high_end = min(sub_ranks), max(sub_ranks)
                if low_end > 2:
                    outs.add((low_end - 1, 'any'))
                if high_end < 14:
                    outs.add((high_end + 1, 'any'))

        if {2, 3, 4, 5}.issubset(set(unique_ranks)):
            outs.add((14, 'any'))
        
        unique_ranks_set = set(unique_ranks)
        for r in range(2, 11):
            window = set(range(r, r + 5))
            missing = window - unique_ranks_set
            if len(missing) == 1:
                outs.add((list(missing)[0], 'any'))
        if {14,2,3,4}.issubset(unique_ranks_set): # A,2,3,4
            outs.add((5,'any'))
        
        # Improvement to pair, three of a kind etc
        my_ranks_set = set(my_card_ranks)
        for rank in my_ranks_set:
            if my_card_ranks.count(rank) == 1:
                outs.add((rank, 'any'))
            if my_card_ranks.count(rank) == 2:
                outs.add((rank, 'any'))
        
        return len(outs)


    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        # This is a critical assumption about the game engine's behavior
        if player_hands and isinstance(player_hands[0], list):
            self.all_my_hands = player_hands
        else:
            self.all_my_hands = [player_hands] * 1000 # Fallback for single hand given

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round_num <= len(self.all_my_hands):
            self.current_hand = self.all_my_hands[round_state.round_num - 1]
        self.preflop_aggressor_id = None

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        pot_total = round_state.pot

        active_players_ids = [pid for pid, action in round_state.player_actions.items() if action not in ['Fold', None]]
        num_active_players = len(active_players_ids)

        if remaining_chips / max(1, self.big_blind_amount) < 20 and round_state.round == 'Preflop':
            return self._get_short_stack_action(to_call)

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, to_call, num_active_players)
        
        return self._get_postflop_action(round_state, remaining_chips, to_call, pot_total, num_active_players)

    def _get_short_stack_action(self, to_call: int) -> Tuple[PokerAction, int]:
        strength = self._get_preflop_strength(self.current_hand)
        if strength > 0.6: 
            return PokerAction.ALL_IN, 0
        if to_call == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0
    
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, num_active_players: int):
        strength = self._get_preflop_strength(self.current_hand)
        is_unopened = round_state.current_bet <= self.big_blind_amount
        
        strength_threshold = 0.5 + (num_active_players * 0.02)
        
        if strength > 0.70: # Premium
            bet_amount = round_state.current_bet * 3 + self.big_blind_amount if not is_unopened else self.big_blind_amount * 3
            raise_amount = min(max(bet_amount, round_state.min_raise), remaining_chips)
            if raise_amount > to_call:
                self.preflop_aggressor_id = self.id
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0
        
        if strength > strength_threshold: # Playable
            if is_unopened:
                bet_amount = int(self.big_blind_amount * 2.5)
                raise_amount = min(max(bet_amount, round_state.min_raise), remaining_chips)
                self.preflop_aggressor_id = self.id
                return PokerAction.RAISE, raise_amount
            elif to_call < remaining_chips * 0.1:
                return PokerAction.CALL, 0

        if to_call == 0:
            return PokerAction.CHECK, 0
        
        if to_call <= self.big_blind_amount and strength > 0.3:
             return PokerAction.CALL, 0

        return PokerAction.FOLD, 0

    def _get_postflop_action(self, rs: RoundStateClient, chips: int, to_call: int, pot: int, num_players: int):
        (hand_info, outs) = self._evaluate_7_cards(self.current_hand, rs.community_cards)
        rank_val = hand_info[0]

        made_hand_strength = (rank_val / 10.0)**2
        unseen = 47 if rs.round == 'Flop' else 46
        draw_equity = outs / max(1, unseen)
        equity = made_hand_strength + (1 - made_hand_strength) * draw_equity
        win_prob = equity ** num_players

        pot_odds = to_call / max(1, pot + to_call)

        if rank_val >= HAND_STRENGTH_MAP["FULL_HOUSE"]:
            bet = int(pot * 0.8)
            return PokerAction.RAISE, min(max(bet, rs.min_raise), chips)

        if win_prob > 0.7 or rank_val >= HAND_STRENGTH_MAP["TWO_PAIR"]:
            if to_call == 0:
                bet = int(pot * 0.6)
                return PokerAction.RAISE, min(max(bet, rs.min_raise), chips)
            else:
                if to_call < pot * 0.6:
                    raise_amt = int(to_call * 2.2 + pot)
                    return PokerAction.RAISE, min(max(raise_amt, rs.min_raise), chips)
                return PokerAction.CALL, 0
        
        is_preflop_aggressor = self.preflop_aggressor_id == self.id
        if to_call == 0 and is_preflop_aggressor and rs.round == 'Flop' and num_players <= 3 and random.random() < 0.6:
            bet = int(pot * 0.5)
            return PokerAction.RAISE, min(max(bet, rs.min_raise), chips)

        if to_call > 0:
            if win_prob > pot_odds and to_call < chips * 0.2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        return PokerAction.CHECK, 0
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass