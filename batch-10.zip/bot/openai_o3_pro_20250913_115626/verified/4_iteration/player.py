from __future__ import annotations

import random
from typing import List, Tuple, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# ----  Utility functions ---------------------------------------------------- #
RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i for i, r in enumerate(RANK_ORDER, start=2)}


def chen_formula(card1: str, card2: str) -> float:
    """
    Computes a simplified Chen strength score for a starting hand.
    Source: http://www.suffe.com/chen_formula.htm
    """
    rank1, suit1 = card1[0], card1[1]
    rank2, suit2 = card2[0], card2[1]

    v1 = chen_rank_value(rank1)
    v2 = chen_rank_value(rank2)
    high, low = max(v1, v2), min(v1, v2)
    score = high

    # Pair
    if rank1 == rank2:
        score = max(5, score * 2)
    else:
        # Suited bonus
        if suit1 == suit2:
            score += 2

        # Gap penalty
        gap = abs(RANK_ORDER.index(rank1) - RANK_ORDER.index(rank2)) - 1
        if gap == 0:
            score += 0
        elif gap == 1:
            score -= 1
        elif gap == 2:
            score -= 2
        elif gap == 3:
            score -= 4
        elif gap >= 4:
            score -= 5

        # Small straight bonus
        if gap <= 1 and (
            {rank1, rank2} & {"A", "2"} or {rank1, rank2} & {"K", "Q"} or {rank1, rank2} & {"Q", "J"}
        ):
            score += 1

    return max(score, 0)


def chen_rank_value(rank_char: str) -> float:
    values = {
        "A": 10,
        "K": 8,
        "Q": 7,
        "J": 6,
        "T": 5,
        "9": 4.5,
        "8": 4,
        "7": 3.5,
        "6": 3,
        "5": 2.5,
        "4": 2,
        "3": 1.5,
        "2": 1,
    }
    return values[rank_char]


# --- SimplePlayer ----------------------------------------------------------- #
class SimplePlayer(Bot):
    """
    A relatively straight-forward no-limit hold’em strategy:
    • Uses Chen formula pre-flop to decide whether to raise, call or fold.
    • Post-flop equity versus ONE random opponent is estimated via Monte-Carlo
      simulation (treys Evaluator).  Decisions are based on that equity and the
      cost to continue.
    • Keeps logic extremely defensive to avoid costly mistakes while still
      being able to capitalise on strong hands.
    """

    # Monte-Carlo simulations for equity estimation
    MC_SIM_COUNT = 400

    def __init__(self) -> None:
        super().__init__()

        # Runtime / round state
        self.starting_stack: int = 0
        self.blind_amount: int = 0
        self.hole_cards: Optional[List[str]] = None

        # Keeps equity cached for current street to avoid recalculation
        self._cached_round: Optional[str] = None
        self._cached_equity: Optional[float] = None

        # Lazy import of treys to avoid failure if package missing at import-time
        from treys import Evaluator  # type: ignore
        self._evaluator = Evaluator()

    # ------------------------------ Life-cycle hooks ------------------------ #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_stack = starting_chips
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the beginning of a new hand.  We expect our hole cards to be
        present in the round_state in one of the common fields.
        """
        self._cached_round = None
        self._cached_equity = None
        self.hole_cards = self._extract_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide action based on street (pre-flop / post-flop) and simple
        heuristics.
        """
        # Safety – default fold if something goes wrong
        if self.hole_cards is None or len(self.hole_cards) != 2:
            return PokerAction.FOLD, 0

        to_call = self._amount_to_call(round_state)
        pot = max(round_state.pot, 1)  # avoid division by 0

        # ---------------- Pre-flop logic ---------------- #
        if round_state.round.lower() == "preflop":
            chen_score = chen_formula(*self.hole_cards)

            if chen_score >= 8:
                return self._raise_amount(round_state, pot, pct=0.75)
            elif chen_score >= 6:
                if to_call == 0:
                    # Limp if we can
                    return PokerAction.CHECK, 0
                elif to_call <= self.blind_amount * 3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif chen_score >= 4.5:
                if to_call <= self.blind_amount * 2:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                # Defend big blind very lightly
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        # ---------------- Post-flop logic ---------------- #
        equity = self._get_equity(round_state)

        # If we can check, decide whether to bet
        if to_call == 0:
            if equity > 0.65:
                return self._raise_amount(round_state, pot, pct=0.7)
            # Occasionally semi-bluff when we have decent equity
            if equity > 0.45 and random.random() < 0.2:
                return self._raise_amount(round_state, pot, pct=0.5)
            return PokerAction.CHECK, 0

        # We are facing a bet
        effective_price = to_call / (pot + to_call)
        # Call if we have the odds
        if equity > effective_price + 0.05:
            # Consider raising with very strong hands
            if equity > 0.8 and random.random() < 0.5:
                return self._raise_amount(round_state, pot, pct=1.0)
            return PokerAction.CALL, 0

        # Desperation: if equity huge go all-in
        if equity > 0.9:
            return PokerAction.ALL_IN, 0

        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # ------------------------------ Helpers --------------------------------- #
    def _extract_hole_cards(self, round_state: RoundStateClient) -> Optional[List[str]]:
        """
        Attempts to find our hole cards in the round_state. Different engines
        name this field differently – handle common patterns gracefully.
        """
        possible_fields = [
            "player_hands",
            "hands",
            "hole_cards",
            "player_cards",
        ]
        for field in possible_fields:
            if hasattr(round_state, field):
                all_hands = getattr(round_state, field)
                if isinstance(all_hands, dict):
                    # Player ID may be stored as str or int
                    key_str = str(self.id)
                    key_int = int(self.id) if self.id is not None else None
                    for k in (key_str, key_int):
                        if k in all_hands:
                            return all_hands[k]
        return None

    def _amount_to_call(self, round_state: RoundStateClient) -> int:
        """
        Calculates chips we must commit to match current bet.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0) or round_state.player_bets.get(
            self.id, 0
        )
        return max(0, round_state.current_bet - my_bet)

    # ----- Raising helpers ----- #
    def _raise_amount(
        self, round_state: RoundStateClient, pot: int, pct: float = 0.7
    ) -> Tuple[PokerAction, int]:
        """
        Returns a valid raise sized at percentage of pot (plus call amount).
        Always clamps between min_raise and max_raise.
        """
        to_call = self._amount_to_call(round_state)
        target = to_call + int(pot * pct)
        # Respect game constraints
        amount = max(round_state.min_raise, target)
        amount = min(amount, round_state.max_raise)
        # If we cannot legally raise because min > remaining stack, fallback to CALL
        if amount <= to_call or amount < round_state.min_raise:
            if to_call == 0:
                return PokerAction.CHECK, 0
            if to_call >= round_state.max_raise:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        return PokerAction.RAISE, amount

    # ----- Equity calculation ----- #
    def _get_equity(self, round_state: RoundStateClient) -> float:
        """
        Returns cached or freshly computed equity for current street.
        """
        if self._cached_round == round_state.round and self._cached_equity is not None:
            return self._cached_equity

        equity = self._estimate_equity(self.hole_cards, round_state.community_cards)
        self._cached_round = round_state.round
        self._cached_equity = equity
        return equity

    def _estimate_equity(self, hole_cards: List[str], board: List[str]) -> float:
        """
        Monte-Carlo equity estimate versus ONE random opponent using treys.
        """
        from treys import Card  # type: ignore

        used = [Card.new(c) for c in hole_cards + board]
        deck = [Card.new(rank + suit) for rank in "23456789TJQKA" for suit in "shdc"]
        deck = [c for c in deck if c not in used]

        wins = ties = 0
        sims = max(self.MC_SIM_COUNT, 1)

        needed_board = 5 - len(board)
        evaluator = self._evaluator

        for _ in range(sims):
            random.shuffle(deck)

            opp_hand = deck[:2]
            rest_board = deck[2 : 2 + needed_board]

            our_score = evaluator.evaluate(
                [Card.new(c) for c in board] + rest_board,
                [Card.new(c) for c in hole_cards],
            )
            opp_score = evaluator.evaluate(
                [Card.new(c) for c in board] + rest_board,
                opp_hand,
            )

            if our_score < opp_score:
                wins += 1
            elif our_score == opp_score:
                ties += 1

        equity = (wins + ties / 2) / sims
        return equity