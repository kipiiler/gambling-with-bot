# player.py
from typing import List, Tuple, Dict, Any
from itertools import combinations
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5,
              '6': 6, '7': 7, '8': 8, '9': 9,
              'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def chen_formula(card1: str, card2: str) -> float:
    """
    Simple Chen formula implementation which returns a numeric rating
    of pre-flop hand strength.  Higher is better (max ≈ 20).
    """
    rank1, suit1 = card1[0], card1[1]
    rank2, suit2 = card2[0], card2[1]

    # ensure card1 is the higher rank
    if RANK_ORDER[rank1] < RANK_ORDER[rank2]:
        rank1, rank2 = rank2, rank1
        suit1, suit2 = suit2, suit1

    base_values = {14: 10, 13: 8, 12: 7, 11: 6,
                   10: 5, 9: 4.5, 8: 4, 7: 3.5,
                   6: 3, 5: 2.5, 4: 2, 3: 1.5, 2: 1}
    score = base_values[RANK_ORDER[rank1]]

    # Pair
    if rank1 == rank2:
        score = max(5, score * 2)

    # Suited
    if suit1 == suit2:
        score += 2

    # Gap penalty
    gap = abs(RANK_ORDER[rank1] - RANK_ORDER[rank2]) - 1
    if gap == 0:
        penalty = 0
    elif gap == 1:
        penalty = 1
    elif gap == 2:
        penalty = 2
    elif gap == 3:
        penalty = 4
    else:
        penalty = 5
    score -= penalty

    # Bonus for small gap and high cards
    if gap <= 1 and RANK_ORDER[rank1] >= 11 and RANK_ORDER[rank2] >= 11:
        score += 1

    return max(score, 0)


def card_ranks(cards: List[str]) -> List[int]:
    return sorted([RANK_ORDER[c[0]] for c in cards], reverse=True)


def is_flush(cards: List[str]) -> bool:
    suits = [c[1] for c in cards]
    return max(suits.count(s) for s in 'shdc') >= 5


def is_straight(ranks: List[int]) -> bool:
    ranks = list(dict.fromkeys(ranks))  # remove duplicates, preserve order
    # Handle wheel straight A-5
    if 14 in ranks:
        ranks.append(1)
    for i in range(len(ranks) - 4):
        window = ranks[i:i + 5]
        if window[0] - window[4] == 4:
            return True
    return False


def hand_category(hole_cards: List[str], community: List[str]) -> str:
    """
    Very coarse hand classifier (does NOT give exact poker ordering but is
    sufficient for simple strategic buckets).
    """
    all_cards = hole_cards + community
    ranks = card_ranks(all_cards)
    counts = {}
    for r in ranks:
        counts[r] = counts.get(r, 0) + 1
    freq = sorted(counts.values(), reverse=True)

    flush = is_flush(all_cards)
    straight = is_straight(ranks)

    if flush and straight:
        return 'straight_flush'
    if 4 in freq:
        return 'four_kind'
    if 3 in freq and 2 in freq:
        return 'full_house'
    if flush:
        return 'flush'
    if straight:
        return 'straight'
    if 3 in freq:
        return 'three_kind'
    if freq.count(2) >= 2:
        return 'two_pair'
    if 2 in freq:
        return 'one_pair'
    return 'high_card'


def categorize_preflop_strength(score: float) -> str:
    if score >= 10:
        return 'premium'
    if score >= 8:
        return 'strong'
    if score >= 6:
        return 'medium'
    return 'weak'


def categorize_postflop_strength(category: str) -> str:
    if category in ('straight_flush', 'four_kind', 'full_house', 'flush', 'straight'):
        return 'strong'
    if category in ('three_kind', 'two_pair'):
        return 'medium'
    return 'weak'


# ---------------------------------------------------------------------------
# Bot implementation
# ---------------------------------------------------------------------------

class SimplePlayer(Bot):
    """
    A very lightweight, rule-based Texas Hold’em bot that uses
    Chen formula pre-flop and simple made-hand evaluation post-flop.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.big_blind = 0
        self.hole_cards: List[str] = []
        self.all_players: List[int] = []

    # -----------------------------------------------------------------------
    # Lifecycle hooks
    # -----------------------------------------------------------------------

    def on_start(self, starting_chips: int, player_hands: List[str],
                 blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient,
                       remaining_chips: int):
        # Attempt to read hole cards if provided by engine
        hole_cards = getattr(round_state, 'player_hands', {}).get(str(self.id), None)
        if hole_cards is None:
            hole_cards = getattr(round_state, 'player_hands', {}).get(self.id, None)
        if hole_cards:
            self.hole_cards = hole_cards
        else:
            # Fallback – create placeholder if engine does not expose hole cards.
            self.hole_cards = ['2c', '7d']  # ultra-weak; encourages tight play
        # Random seed to keep behaviour somewhat unpredictable
        random.seed(round_state.round_num + self.id)

    def get_action(self, round_state: RoundStateClient,
                   remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Core decision logic.  Always returns a legal action.
        """
        # Helper values
        my_bet = round_state.player_bets.get(str(self.id),
                                             round_state.player_bets.get(self.id, 0))
        to_call = max(0, round_state.current_bet - my_bet)
        pot = max(round_state.pot, 1)  # prevent divide-by-zero
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        stage = round_state.round.lower()  # 'preflop', 'flop', 'turn', 'river'

        # -------------------------------------------------------------------
        # PREFLOP STRATEGY
        # -------------------------------------------------------------------
        if stage == 'preflop':
            pre_score = chen_formula(self.hole_cards[0], self.hole_cards[1])
            strength = categorize_preflop_strength(pre_score)

            # If no one has raised yet
            if to_call == 0:
                if strength in ('premium', 'strong'):
                    # Choose a raise size between 3-4 BB
                    raise_to = min(self.big_blind * random.choice((3, 4)),
                                   max_raise)
                    if raise_to >= round_state.current_bet + min_raise:
                        return PokerAction.RAISE, raise_to
                # Limp / check
                return PokerAction.CHECK, 0

            # Facing a bet
            else:
                # Very large bet relative to pot – tighten up
                if to_call > pot * 0.75 and strength == 'medium':
                    strength = 'weak'

                if strength in ('premium', 'strong'):
                    # Occasionally 3-bet
                    if remaining_chips > to_call + min_raise and random.random() < 0.4:
                        raise_to = min(round_state.current_bet + to_call + pot,
                                       max_raise)
                        if raise_to >= round_state.current_bet + min_raise:
                            return PokerAction.RAISE, raise_to
                    # Otherwise just call
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                elif strength == 'medium' and to_call <= pot * 0.3:
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # -------------------------------------------------------------------
        # POSTFLOP STRATEGY
        # -------------------------------------------------------------------
        else:
            category = hand_category(self.hole_cards, round_state.community_cards)
            post_strength = categorize_postflop_strength(category)

            # No bet to us
            if to_call == 0:
                if post_strength == 'strong':
                    # Value bet between 60-100% of pot
                    factor = random.uniform(0.6, 1.0)
                    raise_to = min(int(pot * factor), max_raise)
                    if raise_to >= round_state.current_bet + min_raise:
                        return PokerAction.RAISE, raise_to
                    # If we cannot legally bet (stack too short), go all-in
                    if remaining_chips > 0:
                        return PokerAction.ALL_IN, 0
                elif post_strength == 'medium' and random.random() < 0.25:
                    # Occasional bluff/semibluff ~½ pot
                    bet_amt = min(int(pot * 0.5), max_raise)
                    if bet_amt >= round_state.current_bet + min_raise:
                        return PokerAction.RAISE, bet_amt
                # Check behind
                return PokerAction.CHECK, 0

            # Facing a bet
            else:
                if post_strength == 'strong':
                    # Fast-play good hands
                    if remaining_chips > to_call + min_raise and random.random() < 0.7:
                        raise_to = min(round_state.current_bet + to_call + int(pot * 0.75),
                                       max_raise)
                        if raise_to >= round_state.current_bet + min_raise:
                            return PokerAction.RAISE, raise_to
                    # Otherwise call
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                elif post_strength == 'medium':
                    # Call modest bets, fold to large ones
                    if to_call <= pot * 0.4 or to_call <= remaining_chips * 0.15:
                        if to_call >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    # Occasional light bluff-raise if small c-bet
                    if to_call <= pot * 0.15 and random.random() < 0.15:
                        bluff_raise = min(round_state.current_bet + to_call + int(pot * 0.4),
                                          max_raise)
                        if bluff_raise >= round_state.current_bet + min_raise:
                            return PokerAction.RAISE, bluff_raise
                    return PokerAction.FOLD, 0

        # Fallback – should not be reached
        return PokerAction.CHECK, 0

    # -----------------------------------------------------------------------

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No persistent tracking required for this simple bot.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float,
                    all_scores: Dict[Any, float], active_players_hands: Dict[Any, List[str]]):
        pass