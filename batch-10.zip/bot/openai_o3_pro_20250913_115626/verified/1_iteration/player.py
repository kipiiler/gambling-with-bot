# player.py
from typing import List, Tuple, Dict
import random
import math
from collections import Counter

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Try to use the strong “treys” evaluator if it is available – fall back to a
# very light-weight high-card approximation otherwise.  This keeps the bot
# functional even if the package install somehow fails.
try:
    from treys import Card as TCard, Evaluator as TEvaluator, Deck as TDeck

    def _str_to_tcard(card_str: str) -> int:
        """Convert 'Ah' -> treys Card integer."""
        return TCard.new(card_str[0] + card_str[1].lower())

    TREYS_AVAILABLE = True
except Exception:  # pragma: no cover
    TREYS_AVAILABLE = False


class SimplePlayer(Bot):
    """
    A surprisingly reasonable no-limit Texas Hold’em bot that mixes
    rule-based pre-flop play with Monte-Carlo post-flop equity estimation.
    The implementation follows every rule/constraint laid out in the
    competition specification.
    """

    ####################################################################
    # INITIALISATION & EVENT HANDLERS                                  #
    ####################################################################
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.total_players: int = 0

        # Hole cards management: we store the current hand here.  The engine
        # supplies it either in `on_start` or inside RoundStateClient (engine
        # dependent) – both are handled.
        self.hole_cards: List[str] = []
        self._current_round: int = 0

        # Treys helpers (only once to save overhead).
        if TREYS_AVAILABLE:
            self._evaluator = TEvaluator()

        # Pre-flop strength cache to avoid recomputation.
        self._preflop_strength_cache: Dict[str, float] = {}

    # -----------------------------------------------------------------
    # Game start
    # -----------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.total_players = len(all_players)

        # Engine might deliver the first hand here.
        if player_hands:
            # Make a shallow copy to stay safe from accidental outside changes.
            self.hole_cards = list(player_hands)

        # Small random seed – each player gets deterministic-yet-different
        # behaviour anchored on its unique id.
        random.seed(self.id or 0)

    # -----------------------------------------------------------------
    # Round start
    # -----------------------------------------------------------------
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self._current_round = round_state.round_num

        # Some servers send hole cards inside the round_state – handle it if so.
        possible_holes = getattr(round_state, "player_hands", None)
        if possible_holes and str(self.id) in possible_holes:
            self.hole_cards = list(possible_holes[str(self.id)])

    # -----------------------------------------------------------------
    # Main decision point
    # -----------------------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:

        # ------------------------------------------------------------------
        # Helpers for convenience & safety checks.
        # ------------------------------------------------------------------
        my_bet_so_far = round_state.player_bets.get(str(self.id), 0)
        to_call = max(round_state.current_bet - my_bet_so_far, 0)
        can_check = to_call == 0

        # If we do not have hole cards for any reason – be extremely cautious.
        if len(self.hole_cards) != 2:
            return (
                PokerAction.CHECK if can_check else PokerAction.FOLD,
                0,
            )

        stage = round_state.round.lower()  # 'preflop', 'flop', …

        # Decide branch: pre-flop uses a quick heuristic, later streets rely on
        # equity estimation (MC).
        if stage == "preflop":
            return self._decide_preflop(round_state, remaining_chips, to_call)
        else:
            return self._decide_postflop(round_state, remaining_chips, to_call)

    # -----------------------------------------------------------------
    # Round end
    # -----------------------------------------------------------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear hole cards – next round will bring new ones.
        self.hole_cards = []

    # -----------------------------------------------------------------
    # Game end (nothing fancy – placeholder for completeness)
    # -----------------------------------------------------------------
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    ####################################################################
    # STRATEGY IMPLEMENTATION                                           #
    ####################################################################
    # ======================== PRE-FLOP =============================== #
    def _decide_preflop(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
        to_call: int,
    ) -> Tuple[PokerAction, int]:

        strength = self._get_preflop_strength(self.hole_cards)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Aggressive line for top ~10 % hands.
        if strength >= 0.8:
            # 3-Bet / open big.
            raise_amount = min(
                max(min_raise * 3, to_call * 2 + min_raise), max_raise
            )
            if remaining_chips <= to_call:  # Short stacked – shove.
                return PokerAction.ALL_IN, 0
            if to_call == 0:
                return PokerAction.RAISE, raise_amount
            elif to_call <= remaining_chips * 0.25:
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0

        # Medium strength (roughly 30-35 %)
        elif strength >= 0.55:
            if to_call == 0:
                # Limp or small raise.
                if random.random() < 0.4 and remaining_chips > min_raise * 2:
                    return PokerAction.RAISE, min(min_raise * 2, max_raise)
                return PokerAction.CHECK, 0
            else:
                # Call modest openings, fold to huge pressure.
                if to_call <= remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Weak hands – defend blinds extremely selectively.
        else:
            if to_call == 0:
                return PokerAction.CHECK, 0
            # Pot odds occasionally justify a call if price is tiny.
            pot_odds = to_call / (round_state.pot + 1e-9 + to_call)
            if pot_odds < 0.07 and remaining_chips > to_call:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    # ======================= POST-FLOP =============================== #
    def _decide_postflop(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
        to_call: int,
    ) -> Tuple[PokerAction, int]:
        """
        Compute equity via Monte-Carlo simulations (vs one random opponent per
        remaining villain).  Uses pot-odds logic for call / raise decisions.
        """

        equity = self._estimate_equity(
            self.hole_cards, round_state.community_cards, len(round_state.current_player)
        )

        # Basic pot-odds call/fold.
        if to_call > 0:
            pot_odds = to_call / (round_state.pot + to_call + 1e-9)
            if equity < pot_odds - 0.05:
                return PokerAction.FOLD, 0

        # Aggression if strong.
        if equity > 0.75 and remaining_chips > to_call:
            # Big bet for value.
            raise_amount = min(
                max(round_state.min_raise, int(round_state.pot * 0.75)),
                round_state.max_raise,
            )
            if to_call == 0:
                return PokerAction.RAISE, raise_amount
            elif to_call / remaining_chips < 0.33:
                return PokerAction.RAISE, raise_amount
            # If we are already facing huge bet just call.
            return (
                PokerAction.CALL if remaining_chips > to_call else PokerAction.ALL_IN,
                0,
            )

        # Medium strength → call small bets, bet occasionally when checked to.
        if 0.45 < equity <= 0.75:
            if to_call == 0:
                # 30 % of the time probe bet half pot.
                if random.random() < 0.3 and remaining_chips > round_state.min_raise:
                    raise_amt = min(
                        max(round_state.min_raise, int(round_state.pot * 0.5)),
                        round_state.max_raise,
                    )
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CHECK, 0
            else:
                # Respect pot odds.
                return (
                    PokerAction.CALL
                    if remaining_chips > to_call
                    else PokerAction.ALL_IN,
                    0,
                )

        # Weak equity – bluff occasionally when checked to, otherwise fold/check.
        if to_call == 0:
            # Tiny bluff 15 % of the time.
            if random.random() < 0.15 and remaining_chips > round_state.min_raise:
                raise_amt = min(round_state.min_raise, round_state.max_raise)
                return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    ####################################################################
    # HELPER METHODS                                                   #
    ####################################################################
    # ----------------- Pre-flop strength evaluator ------------------- #
    RANK_VALUE = {
        "2": 2,
        "3": 3,
        "4": 4,
        "5": 5,
        "6": 6,
        "7": 7,
        "8": 8,
        "9": 9,
        "T": 10,
        "J": 11,
        "Q": 12,
        "K": 13,
        "A": 14,
    }

    def _get_preflop_strength(self, hand: List[str]) -> float:
        """
        Fast heuristic translated to a [0,1] score.  Cached for speed.
        """
        key = "".join(sorted(hand))
        if key in self._preflop_strength_cache:
            return self._preflop_strength_cache[key]

        r1, s1 = hand[0][0], hand[0][1]
        r2, s2 = hand[1][0], hand[1][1]
        v1, v2 = self.RANK_VALUE[r1], self.RANK_VALUE[r2]

        # Base score is high-card power.
        score = max(v1, v2) * 1.5 + min(v1, v2)

        # Pair bonus.
        if r1 == r2:
            score += 20

        # Suited bonus.
        if s1 == s2:
            score += 4

        # Connectivity bonus (small gap better).
        gap = abs(v1 - v2)
        if gap == 1:
            score += 3
        elif gap == 2:
            score += 1

        # Map typical range (approx 0-60) to 0-1.
        strength = max(0.0, min(1.0, score / 60.0))
        self._preflop_strength_cache[key] = strength
        return strength

    # ------------------ Post-flop equity estimator ------------------- #
    def _estimate_equity(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        num_active_players: int,
        simulations: int = 200,
    ) -> float:
        """
        Monte-Carlo equity vs `num_active_players`-1 random opponents.
        """

        # Heads-up equity will be off if >1 villains; we simply discount by
        # raising to the power of (villains) to approximate multiway.
        villains = max(num_active_players - 1, 1)

        if TREYS_AVAILABLE:
            hero_cards_int = [_str_to_tcard(c) for c in hole_cards]
            board_int = [_str_to_tcard(c) for c in community_cards]

            wins = 0
            deck = TDeck()
            for c in hero_cards_int + board_int:
                deck.cards.remove(c)

            for _ in range(simulations):
                deck.shuffle()
                # Fill missing community cards.
                needed_board = 5 - len(board_int)
                sim_board = board_int + [deck.draw(1)[0] for _ in range(needed_board)]

                # Draw villains.
                villain_hands = [
                    [deck.draw(1)[0], deck.draw(1)[0]] for _ in range(villains)
                ]

                hero_score = self._evaluator.evaluate(sim_board, hero_cards_int)
                villain_best = min(
                    self._evaluator.evaluate(sim_board, v_cards)
                    for v_cards in villain_hands
                )

                if hero_score <= villain_best:
                    wins += 1

                # Return drawn cards to the deck for next simulation.
                for card in sim_board[len(board_int) :]:
                    deck.cards.append(card)
                for v_cards in villain_hands:
                    deck.cards.extend(v_cards)

            equity = wins / simulations

        else:
            # Extremely lightweight approximation if treys unavailable.
            # Use high-card comparison only (not great but better than nothing).
            rank_counts = Counter(
                card[0]
                for card in hole_cards + community_cards
                if card and len(card) > 0
            )
            pair_present = any(count >= 2 for count in rank_counts.values())
            equity = 0.55 if pair_present else 0.3

        # Discount for multiway pots.
        if villains > 1:
            equity = equity ** villains
        return equity