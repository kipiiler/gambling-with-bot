from typing import List, Tuple, Dict, Any
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# external pure-python hand evaluator
from treys import Card, Evaluator  # type: ignore


class SimplePlayer(Bot):
    """
    A very small, self-contained NLHE bot that
    1) uses a simple pre-flop starting-hand chart
    2) estimates post-flop equity from the Treys Evaluator score
    3) produces only legal actions under every circumstance
    It is intentionally lightweight and robust so that it never crashes or
    times out while still playing reasonably competitive poker.
    """

    def __init__(self) -> None:
        super().__init__()
        # Evaluator is deterministic & stateless – keep one instance
        self.evaluator: Evaluator = Evaluator()

        # book-keeping
        self.starting_stack: int = 0
        self.hand_number: int = 0
        self.hole_cards: List[str] = []  # e.g. ['Ah', 'Kd']

    # ---------- Life-cycle callbacks ---------- #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ) -> None:
        self.starting_stack = starting_chips
        self.hole_cards = player_hands

    def on_round_start(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
    ) -> None:
        # Every round we increment hand number and, if new hole cards were
        # offered by the engine, store them.
        self.hand_number += 1
        if hasattr(round_state, "player_hands"):
            ph = round_state.player_hands  # type: ignore
            if isinstance(ph, dict) and str(self.id) in ph:
                self.hole_cards = ph[str(self.id)]

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine. Always returns a legal action.
        """

        # ------------------------------------------------------------ #
        # 1. Parse basic round information
        # ------------------------------------------------------------ #
        stage = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'
        player_bets: Dict[str, int] = round_state.player_bets
        my_bet = player_bets.get(str(self.id), 0)
        to_call = max(round_state.current_bet - my_bet, 0)
        min_raise_total = round_state.min_raise  # absolute total amount
        max_raise_total = round_state.max_raise  # we may not exceed this
        pot = max(round_state.pot, 1)  # avoid div-0
        can_check = to_call == 0

        # ------------------------------------------------------------ #
        # 2. Compute hand strength
        # ------------------------------------------------------------ #
        win_prob: float
        if stage.lower() == "preflop":
            win_prob = self._preflop_strength(self.hole_cards)
        else:
            win_prob = self._postflop_strength(
                self.hole_cards, round_state.community_cards
            )

        # ------------------------------------------------------------ #
        # 3. Decide on an action
        # ------------------------------------------------------------ #
        # Very aggressive with monsters, conservative otherwise.
        action: PokerAction
        amount: int = 0

        # Tiny epsilon to avoid fp bugs
        eps = 1e-9

        # All-in thresh: if short stacked (< pot size) and strong
        if (
            remaining_chips <= pot
            and win_prob > 0.7
            and remaining_chips > 0  # sanity
        ):
            return (PokerAction.ALL_IN, 0)

        # Decision tree
        if can_check:
            # When we face no bet
            if win_prob > 0.75 and min_raise_total <= remaining_chips:
                # Big raise with premium hands
                amount = min(
                    max(min_raise_total, int(pot * 0.75 + eps)), remaining_chips
                )
                # Guarantee legal raise
                amount = max(amount, min_raise_total)
                action = (
                    PokerAction.ALL_IN
                    if amount >= remaining_chips
                    else PokerAction.RAISE
                )
                return (action, amount if action == PokerAction.RAISE else 0)

            elif win_prob > 0.4:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)

        else:  # We are facing a bet
            # If pot odds favourable or hand strong enough – call / raise
            pot_odds = to_call / (pot + to_call + eps)
            if win_prob - pot_odds > 0.25 or win_prob > 0.8:
                # Consider raise with very strong hands
                if win_prob > 0.8 and remaining_chips > to_call + min_raise_total:
                    amount = min(
                        max(min_raise_total, to_call + int(pot * 0.75 + eps)),
                        remaining_chips,
                    )
                    amount = max(amount, min_raise_total)
                    action = (
                        PokerAction.ALL_IN
                        if amount >= remaining_chips
                        else PokerAction.RAISE
                    )
                    return (action, amount if action == PokerAction.RAISE else 0)
                else:
                    return (
                        PokerAction.ALL_IN
                        if remaining_chips <= to_call
                        else PokerAction.CALL,
                        0,
                    )

            # Marginal calls for cheap price
            elif win_prob > 0.5 and to_call <= pot * 0.1:
                return (
                    PokerAction.ALL_IN
                    if remaining_chips <= to_call
                    else PokerAction.CALL,
                    0,
                )
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> None:
        # nothing to store yet
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ) -> None:
        # Can log or learn here. For simplicity we do nothing.
        pass

    # ---------- Helper methods ---------- #

    def _preflop_strength(self, hole: List[str]) -> float:
        """
        Extremely light-weight pre-flop strength heuristic.
        Returns a win-probability estimate in [0,1].
        """
        if len(hole) != 2:
            return 0.0

        ranks = "23456789TJQKA"
        r1, s1 = hole[0][0], hole[0][1]
        r2, s2 = hole[1][0], hole[1][1]
        suited = s1 == s2
        # build canonical key like 'AKs' or 'QJo'
        if ranks.index(r1) < ranks.index(r2):
            r1, r2 = r2, r1  # ensure r1 is higher
        key = f"{r1}{r2}{'s' if suited else 'o'}" if r1 != r2 else f"{r1}{r2}"

        # tiers taken from simplified chart
        premium = {
            "AA",
            "KK",
            "QQ",
            "JJ",
            "AKs",
        }
        strong = {
            "TT",
            "AQs",
            "AJs",
            "KQs",
            "AKo",
        }
        medium = {
            "99",
            "88",
            "ATs",
            "KJs",
            "QJs",
            "JTs",
            "AQo",
        }

        if key in premium:
            return 0.82
        if key in strong:
            return 0.7
        if key in medium:
            return 0.58

        # weaker hands – use gap & suitedness rules
        gap = abs(ranks.index(h1 := hole[0][0]) - ranks.index(h2 := hole[1][0]))
        base = 0.45 - 0.03 * gap
        if suited:
            base += 0.02
        return max(0.05, min(base, 0.55))

    def _postflop_strength(
        self, hole: List[str], community: List[str], n_samples: int = 0
    ) -> float:
        """
        Use Treys Evaluator score to approximate equity.
        7462 is the total number of distinct hand ranks in Treys –
        mapping score -> ~percentile.
        """
        if not hole:
            return 0.0

        try:
            hole_int = [Card.new(c) for c in hole]
            board_int = [Card.new(c) for c in community]
            score = self.evaluator.evaluate(board_int, hole_int)
            win_prob = 1.0 - score / 7462.0
            # Slight smoothing so that monsters stand out
            return max(0.0, min(1.0, win_prob))
        except Exception:
            # Any parsing / evaluator failure – return conservative estimate
            return 0.5