from typing import List, Tuple, Dict, Any
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i for i, r in enumerate(RANK_ORDER, 2)}


def card_rank(card: str) -> str:
    return card[0]


def card_suit(card: str) -> str:
    return card[1]


def starting_hand_notation(card1: str, card2: str) -> str:
    r1, r2 = card_rank(card1), card_rank(card2)
    s1, s2 = card_suit(card1), card_suit(card2)

    if RANK_VALUE[r1] < RANK_VALUE[r2]:
        r1, r2 = r2, r1
        s1, s2 = s2, s1

    if r1 == r2:
        return r1 + r2  # e.g. 'AA'
    suited = 's' if s1 == s2 else 'o'
    return f"{r1}{r2}{suited}"  # e.g. 'AKs', 'QJo'


# Pre-flop categories (very compact – feel free to enlarge in later iterations)
PREMIUM = {
    'AA', 'KK', 'QQ', 'JJ', 'AKs'
}
STRONG = {
    'TT', '99', '88', 'AKo', 'AQs', 'AJs', 'KQs'
}
MEDIUM = {
    '77', '66', '55', 'AQo', 'ATs', 'KJs', 'QJs',
    'JTs', 'T9s', '98s', '87s', '76s'
}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.big_blind = 0
        self.small_blind = 0
        self.hole_cards: List[str] = []
        self.seen_round_num = -1

    # ---------- Callback helpers ---------- #

    def _update_hole_cards(self, round_state: RoundStateClient):
        """
        Many frameworks include the player's hole cards either in round_state.player_hands
        or they are passed only once at game start.  Handle both gracefully.
        """
        # RoundStateClient may carry a dict mapping player_id to cards.
        if hasattr(round_state, "player_hands") and round_state.player_hands:
            try:
                self.hole_cards = round_state.player_hands.get(str(self.id), self.hole_cards)
            except Exception:
                # Fallback to keep previous
                pass

    # ---------- Simple post-flop evaluator ---------- #
    @staticmethod
    def _simple_postflop_strength(all_cards: List[str]) -> int:
        """
        Return an integer strength estimate.
        7  – straight or better
        6  – flush
        5  – trips
        4  – two pair
        3  – pair
        1  – high card
        A very crude evaluator but good enough for tight-aggressive play.
        """
        ranks = [card_rank(c) for c in all_cards]
        suits = [card_suit(c) for c in all_cards]

        # Flush
        for s in 'cdhs':
            if suits.count(s) >= 5:
                return 6

        # Count duplicates
        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        counts = sorted(rank_counts.values(), reverse=True)
        if counts and counts[0] == 4:
            return 7
        if 3 in counts and 2 in counts:
            return 7  # full house
        if counts and counts[0] == 3:
            return 5
        if counts.count(2) >= 2:
            return 4
        if 2 in counts:
            return 3

        # Straight
        rank_nums = sorted({RANK_VALUE[r] for r in ranks})
        # Handle wheel straight
        if {14, 5, 4, 3, 2}.issubset(set(rank_nums)):
            return 7
        for i in range(len(rank_nums) - 4):
            if rank_nums[i + 4] - rank_nums[i] == 4:
                return 7

        return 1

    # ---------- Bot logic callbacks ---------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        # Store blind sizes and initial hole cards
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        if isinstance(player_hands, dict):
            self.hole_cards = player_hands.get(str(self.id), [])
        else:
            self.hole_cards = player_hands  # sometimes list directly

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Each new hand might update blinds and hole cards
        self._update_hole_cards(round_state)
        self.seen_round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Safety first – make sure we always return a legal move
        try:
            self._update_hole_cards(round_state)
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(round_state.current_bet - my_bet, 0)
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            # If we have no chips left, must check/fold
            if remaining_chips <= 0:
                return PokerAction.CHECK, 0

            # -------- Pre-flop decision -------- #
            if round_state.round.lower() == 'preflop' and len(self.hole_cards) == 2:
                notation = starting_hand_notation(self.hole_cards[0], self.hole_cards[1])

                # Determine category
                if notation in PREMIUM:
                    category = 'premium'
                elif notation in STRONG:
                    category = 'strong'
                elif notation in MEDIUM:
                    category = 'medium'
                else:
                    category = 'weak'

                # Play premium aggressively
                if category == 'premium':
                    if call_amount == 0 and min_raise <= max_raise:
                        # Open raise to 3×BB or minimum allowed
                        raise_to = max(self.big_blind * 3, round_state.current_bet + min_raise)
                        raise_to = min(raise_to, max_raise)
                        return PokerAction.RAISE, raise_to
                    elif call_amount > 0:
                        # Re-raise if possible
                        if min_raise <= max_raise and call_amount < remaining_chips / 2:
                            raise_to = round_state.current_bet + max(min_raise, self.big_blind * 2)
                            raise_to = min(raise_to, max_raise)
                            return PokerAction.RAISE, raise_to
                        return PokerAction.CALL, 0

                # Strong hands: call small raises or raise when first in
                if category == 'strong':
                    if call_amount == 0:
                        if min_raise <= max_raise:
                            raise_to = max(self.big_blind * 2, round_state.current_bet + min_raise)
                            raise_to = min(raise_to, max_raise)
                            return PokerAction.RAISE, raise_to
                        return PokerAction.CHECK, 0
                    elif call_amount <= self.big_blind * 2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Medium: limp if free, else fold to raises larger than BB
                if category == 'medium':
                    if call_amount == 0:
                        return PokerAction.CHECK, 0
                    elif call_amount <= self.big_blind:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Weak: fold against any bet, else check
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # -------- Post-flop decision -------- #
            all_cards = self.hole_cards + round_state.community_cards
            strength = self._simple_postflop_strength(all_cards)
            pot = round_state.pot
            # Some safety when pot == 0
            pot = max(pot, self.big_blind * 2)

            # Strong made hand – play aggressively
            if strength >= 5:
                # If no bet – bet pot
                if call_amount == 0:
                    bet_size = min(pot, max_raise)
                    # Make sure bet_size is legal
                    if bet_size >= min_raise:
                        return PokerAction.RAISE, bet_size
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Consider re-raise or call
                    if min_raise <= max_raise and call_amount < remaining_chips / 2:
                        raise_to = min(round_state.current_bet + pot, max_raise)
                        if raise_to >= round_state.current_bet + min_raise:
                            return PokerAction.RAISE, raise_to
                    return PokerAction.CALL, 0

            # Medium hand – pot-control
            if strength == 4 or strength == 3:
                # Cheap call, otherwise fold
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                elif call_amount <= pot * 0.25:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Weak/no hand
            if call_amount == 0:
                # Occasional bluff: small bet 10% of pot when checked to us
                if round_state.current_bet == 0 and min_raise <= max_raise and pot > self.big_blind * 2:
                    bluff_bet = max(self.big_blind, int(pot * 0.1))
                    bluff_bet = min(bluff_bet, max_raise)
                    if bluff_bet >= min_raise:
                        return PokerAction.RAISE, bluff_bet
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        except Exception:
            # Any unexpected issue – fold safely
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards to avoid leakage between hands
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict[str, Any],
    ):
        # Nothing special to clean up
        pass