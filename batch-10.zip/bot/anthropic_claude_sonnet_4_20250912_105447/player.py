from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.position = None
        self.starting_chips = 0
        self.blind_amount = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # Determine position
        if self.id == big_blind_player_id:
            self.position = "BB"
        elif self.id == small_blind_player_id:
            self.position = "SB"
        else:
            self.position = "BTN"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hand, round_state.community_cards)
        
        # Get betting context
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = call_amount / (round_state.pot + call_amount + 1)  # +1 to avoid division by zero
        
        # Aggressive strategy based on hand strength
        if hand_strength >= 0.8:  # Very strong hand
            if call_amount == 0:
                # Bet for value
                bet_size = min(round_state.pot // 2, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Raise or call depending on pot odds
                if pot_odds < 0.3 and remaining_chips > call_amount * 3:
                    raise_size = min(call_amount * 2, remaining_chips, round_state.max_raise)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
                
        elif hand_strength >= 0.6:  # Good hand
            if call_amount == 0:
                # Check or small bet
                if round_state.round == "Preflop":
                    bet_size = min(round_state.pot // 3, remaining_chips)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Call if pot odds are favorable
                if pot_odds < 0.4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        elif hand_strength >= 0.4:  # Marginal hand
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Only call with very good pot odds
                if pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        else:  # Weak hand
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Parse hole cards
        card1_rank, card1_suit = self._parse_card(hole_cards[0])
        card2_rank, card2_suit = self._parse_card(hole_cards[1])
        
        if card1_rank is None or card2_rank is None:
            return 0.0
        
        strength = 0.0
        
        # Pre-flop hand strength
        if not community_cards:
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 10:  # TT+
                    strength = 0.9
                elif card1_rank >= 7:  # 77-99
                    strength = 0.7
                else:  # 22-66
                    strength = 0.5
            # High cards
            elif card1_rank >= 12 or card2_rank >= 12:  # Ace or King
                if (card1_rank >= 12 and card2_rank >= 10) or (card2_rank >= 12 and card1_rank >= 10):
                    strength = 0.8
                else:
                    strength = 0.6
            # Suited connectors
            elif card1_suit == card2_suit and abs(card1_rank - card2_rank) <= 1:
                strength = 0.6
            # Connected cards
            elif abs(card1_rank - card2_rank) <= 1:
                strength = 0.5
            else:
                strength = 0.3
        else:
            # Post-flop: basic made hand detection
            all_cards = hole_cards + community_cards
            strength = self._evaluate_made_hand(all_cards)
            
        return min(1.0, max(0.0, strength))
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank and suit"""
        if len(card) != 2:
            return None, None
            
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        return rank_map.get(rank_char), suit
    
    def _evaluate_made_hand(self, cards: List[str]) -> float:
        """Basic evaluation of made hands"""
        if len(cards) < 2:
            return 0.0
            
        ranks = []
        suits = []
        
        for card in cards:
            rank, suit = self._parse_card(card)
            if rank is not None:
                ranks.append(rank)
                suits.append(suit)
        
        if not ranks:
            return 0.0
            
        # Count rank frequencies
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        # Count suit frequencies
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        max_rank_count = max(rank_counts.values())
        max_suit_count = max(suit_counts.values())
        
        # Four of a kind
        if max_rank_count >= 4:
            return 0.95
        # Full house or three of a kind
        elif max_rank_count >= 3:
            if len([count for count in rank_counts.values() if count >= 2]) >= 2:
                return 0.9  # Full house
            else:
                return 0.75  # Three of a kind
        # Flush
        elif max_suit_count >= 5:
            return 0.85
        # Straight (simplified check)
        elif self._has_straight(ranks):
            return 0.8
        # Two pair
        elif len([count for count in rank_counts.values() if count >= 2]) >= 2:
            return 0.65
        # One pair
        elif max_rank_count >= 2:
            pair_rank = max([rank for rank, count in rank_counts.items() if count >= 2])
            if pair_rank >= 10:  # High pair
                return 0.6
            else:
                return 0.45
        # High card
        else:
            max_rank = max(ranks)
            if max_rank >= 14:  # Ace high
                return 0.4
            elif max_rank >= 12:  # King high
                return 0.35
            else:
                return 0.3
    
    def _has_straight(self, ranks: List[int]) -> bool:
        """Check for straight (simplified)"""
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) < 5:
            return False
            
        # Check for consecutive sequences
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5 straight
        if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
            return True
            
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass