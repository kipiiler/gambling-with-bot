from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.opponent_stats = {}
        self.hands_played = 0
        self.position_stats = {'small_blind': 0, 'big_blind': 0}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Track position
        if self.id == small_blind_player_id:
            self.position_stats['small_blind'] += 1
        elif self.id == big_blind_player_id:
            self.position_stats['big_blind'] += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Get betting context
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            pot_odds = self._calculate_pot_odds(round_state, call_amount)
            
            # Aggressive strategy based on hand strength and position
            if hand_strength >= 0.8:  # Very strong hand
                return self._aggressive_action(round_state, remaining_chips)
            elif hand_strength >= 0.6:  # Good hand
                return self._moderate_action(round_state, remaining_chips, pot_odds)
            elif hand_strength >= 0.4:  # Marginal hand
                return self._cautious_action(round_state, remaining_chips, pot_odds)
            else:  # Weak hand
                return self._weak_hand_action(round_state, remaining_chips, pot_odds)
                
        except Exception as e:
            # Fallback to safe action
            return self._safe_action(round_state, remaining_chips)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        high_card, low_card = max(val1, val2), min(val1, val2)
        
        # Base strength calculation
        strength = 0.0
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # High pairs (TT+)
                strength = 0.85 + (val1 - 10) * 0.03
            elif val1 >= 7:  # Medium pairs (77-99)
                strength = 0.6 + (val1 - 7) * 0.08
            else:  # Low pairs (22-66)
                strength = 0.4 + (val1 - 2) * 0.04
        else:
            # High cards
            if high_card == 14:  # Ace
                if low_card >= 10:  # AK, AQ, AJ, AT
                    strength = 0.75 + (low_card - 10) * 0.05
                elif low_card >= 7:  # A9-A7
                    strength = 0.55 + (low_card - 7) * 0.05
                else:  # A6-A2
                    strength = 0.45 + (low_card - 2) * 0.02
            elif high_card >= 11:  # King or Queen
                if low_card >= 9:  # KQ, KJ, QJ, etc.
                    strength = 0.6 + (low_card - 9) * 0.05
                else:
                    strength = 0.35 + (high_card - 11) * 0.05
            else:
                # Connected cards
                if abs(val1 - val2) <= 4 and low_card >= 6:
                    strength = 0.3 + (low_card - 6) * 0.02
                else:
                    strength = 0.1 + (high_card - 2) * 0.02
        
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
            
        # Adjust based on community cards
        if round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
            
        return min(1.0, max(0.0, strength))

    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        if not community_cards:
            return base_strength
            
        # Simple adjustment - if we have potential draws or made hands
        all_cards = self.hole_cards + community_cards
        
        # Look for pairs, straights, flushes
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Count pairs
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        max_count = max(rank_counts.values()) if rank_counts else 1
        
        if max_count >= 3:  # Three of a kind or better
            return min(1.0, base_strength + 0.3)
        elif max_count == 2:  # Pair
            return min(1.0, base_strength + 0.15)
            
        # Flush potential
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        max_suit_count = max(suit_counts.values()) if suit_counts else 1
        if max_suit_count >= 4:
            return min(1.0, base_strength + 0.2)
            
        return base_strength

    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return float('inf')
        return round_state.pot / (call_amount + 0.01)  # Add small value to avoid division by zero

    def _aggressive_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Strong hand - bet/raise aggressively"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if round_state.current_bet == 0:
            # No one has bet - make a strong bet
            bet_size = max(round_state.min_raise, min(round_state.pot // 2 + round_state.min_raise, remaining_chips))
            return (PokerAction.RAISE, bet_size)
        elif call_amount > 0:
            if call_amount < remaining_chips // 3:
                # Raise if call is reasonable
                raise_amount = max(round_state.min_raise, min(call_amount * 2 + round_state.current_bet, remaining_chips))
                return (PokerAction.RAISE, raise_amount)
            else:
                # Call if raise would be too much
                return (PokerAction.CALL, 0)
        else:
            # Can check - bet for value
            bet_size = max(round_state.min_raise, min(round_state.pot // 3 + round_state.min_raise, remaining_chips))
            return (PokerAction.RAISE, bet_size)

    def _moderate_action(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Good hand - play solid"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount == 0:
            if round_state.current_bet == 0:
                # Bet for value
                bet_size = max(round_state.min_raise, min(round_state.pot // 3 + round_state.min_raise, remaining_chips))
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        elif pot_odds >= 2.0 or call_amount <= remaining_chips // 4:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _cautious_action(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Marginal hand - play carefully"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif pot_odds >= 3.0 and call_amount <= remaining_chips // 6:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _weak_hand_action(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Weak hand - fold or check"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif pot_odds >= 5.0 and call_amount <= remaining_chips // 10:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _safe_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Fallback safe action"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 10:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Track round results"""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Track game results"""
        pass