from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.position = 0
        self.game_history = []
        self.opponent_stats = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 0  # Small blind
        elif self.id == big_blind_player_id:
            self.position = 1  # Big blind
        else:
            self.position = 2  # Other positions

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds and betting metrics
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = call_amount / (round_state.pot + call_amount + 0.001)  # Add small epsilon
            
            # Get number of active players
            active_players = len([p for p in round_state.current_player if p in round_state.current_player])
            
            # Aggressive strategy based on hand strength and position
            if hand_strength >= 0.85:  # Very strong hands
                if round_state.current_bet == 0:
                    # Bet aggressively
                    bet_size = min(round_state.pot * 0.8, remaining_chips // 4)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, int(bet_size))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Consider raising or calling based on pot size
                    if call_amount < remaining_chips * 0.3:
                        if round_state.round in ['Preflop', 'Flop'] and call_amount < round_state.pot:
                            raise_size = min(round_state.pot * 1.2, round_state.max_raise)
                            if raise_size >= round_state.min_raise:
                                return (PokerAction.RAISE, int(raise_size))
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)
            
            elif hand_strength >= 0.7:  # Strong hands
                if round_state.current_bet == 0:
                    # Value bet
                    bet_size = min(round_state.pot * 0.6, remaining_chips // 5)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, int(bet_size))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if pot_odds < 0.4 or call_amount < remaining_chips * 0.2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            elif hand_strength >= 0.5:  # Medium hands
                if round_state.current_bet == 0:
                    if round_state.round == 'Preflop' or active_players <= 2:
                        bet_size = min(round_state.pot * 0.4, remaining_chips // 8)
                        if bet_size >= round_state.min_raise:
                            return (PokerAction.RAISE, int(bet_size))
                    return (PokerAction.CHECK, 0)
                else:
                    if pot_odds < 0.3 and call_amount < remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            elif hand_strength >= 0.3:  # Marginal hands
                if round_state.current_bet == 0:
                    if round_state.round == 'Preflop' and self.position > 0:
                        # Sometimes bluff from good position
                        bet_size = min(round_state.pot * 0.3, remaining_chips // 10)
                        if bet_size >= round_state.min_raise and active_players <= 2:
                            return (PokerAction.RAISE, int(bet_size))
                    return (PokerAction.CHECK, 0)
                else:
                    if pot_odds < 0.2 and call_amount < remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            else:  # Weak hands
                if round_state.current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Only call very small bets with drawing potential
                    if call_amount < self.big_blind and self._has_draw_potential(round_state):
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception:
            # Fallback strategy
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
                if call_amount <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        try:
            if not self.hole_cards or len(self.hole_cards) < 2:
                return 0.2
            
            card1, card2 = self.hole_cards[0], self.hole_cards[1]
            rank1, suit1 = card1[:-1], card1[-1]
            rank2, suit2 = card2[:-1], card2[-1]
            
            # Convert ranks to numerical values
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                          '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            
            val1 = rank_values.get(rank1, 7)
            val2 = rank_values.get(rank2, 7)
            
            base_strength = 0.0
            
            # Preflop hand strength
            if round_state.round == 'Preflop':
                # Pocket pairs
                if rank1 == rank2:
                    if val1 >= 10:  # TT+
                        base_strength = 0.85
                    elif val1 >= 7:  # 77+
                        base_strength = 0.7
                    else:
                        base_strength = 0.55
                
                # Suited connectors and high cards
                elif suit1 == suit2:
                    if val1 >= 12 or val2 >= 12:  # Suited with A, K, Q
                        base_strength = 0.75
                    elif abs(val1 - val2) <= 2:  # Suited connectors
                        base_strength = 0.6
                    else:
                        base_strength = 0.4
                
                # Offsuit hands
                else:
                    if (val1 >= 13 and val2 >= 10) or (val1 >= 10 and val2 >= 13):  # AK, AQ, KQ type
                        base_strength = 0.65
                    elif val1 >= 12 or val2 >= 12:  # Any face card
                        base_strength = 0.45
                    else:
                        base_strength = 0.25
            
            # Post-flop evaluation
            else:
                community_cards = round_state.community_cards
                all_cards = self.hole_cards + community_cards
                
                # Basic made hand detection
                ranks = [self._get_rank_value(card) for card in all_cards]
                suits = [card[-1] for card in all_cards]
                
                rank_counts = {}
                for rank in ranks:
                    rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
                suit_counts = {}
                for suit in suits:
                    suit_counts[suit] = suit_counts.get(suit, 0) + 1
                
                # Check for strong made hands
                if max(rank_counts.values()) >= 4:  # Quads
                    base_strength = 0.95
                elif max(rank_counts.values()) >= 3:  # Trips or full house
                    if len([r for r in rank_counts.values() if r >= 2]) >= 2:
                        base_strength = 0.9  # Full house
                    else:
                        base_strength = 0.8  # Trips
                elif max(suit_counts.values()) >= 5:  # Flush
                    base_strength = 0.85
                elif self._has_straight(ranks):  # Straight
                    base_strength = 0.8
                elif max(rank_counts.values()) >= 2:  # Pair
                    pairs = [r for r, count in rank_counts.items() if count >= 2]
                    if len(pairs) >= 2:  # Two pair
                        base_strength = 0.65
                    else:  # One pair
                        pair_rank = pairs[0]
                        if pair_rank >= 10:  # High pair
                            base_strength = 0.6
                        else:
                            base_strength = 0.4
                else:  # High card
                    highest = max(val1, val2)
                    if highest >= 13:  # Ace or King high
                        base_strength = 0.35
                    else:
                        base_strength = 0.2
            
            return min(base_strength, 1.0)
            
        except Exception:
            return 0.3

    def _get_rank_value(self, card: str) -> int:
        """Convert card rank to numerical value"""
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(card[:-1], 7)

    def _has_straight(self, ranks: List[int]) -> bool:
        """Check if ranks contain a straight"""
        try:
            unique_ranks = sorted(set(ranks))
            if len(unique_ranks) < 5:
                return False
            
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    return True
            
            # Check for A-2-3-4-5 straight
            if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
                return True
                
            return False
        except Exception:
            return False

    def _has_draw_potential(self, round_state: RoundStateClient) -> bool:
        """Check if hand has drawing potential"""
        try:
            if round_state.round in ['Turn', 'River']:
                return False
            
            community_cards = round_state.community_cards
            if len(community_cards) < 3:
                return True  # Always has potential preflop
            
            all_cards = self.hole_cards + community_cards
            suits = [card[-1] for card in all_cards]
            ranks = [self._get_rank_value(card) for card in all_cards]
            
            # Flush draw
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            if max(suit_counts.values()) >= 4:
                return True
            
            # Straight draw
            unique_ranks = sorted(set(ranks))
            if len(unique_ranks) >= 4:
                for i in range(len(unique_ranks) - 3):
                    if unique_ranks[i+3] - unique_ranks[i] <= 4:
                        return True
            
            return False
        except Exception:
            return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track performance for learning
        chip_change = remaining_chips - self.remaining_chips
        self.game_history.append({
            'round': round_state.round_num,
            'chip_change': chip_change,
            'final_pot': round_state.pot
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Store game results for future improvement
        pass