from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.opponent_stats = {}
        self.position_stats = {}
        self.hand_history = []
        self.current_hand = {}
        self.big_blind = 0
        self.all_players = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.all_players = all_players
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[str(player_id)] = {
                    'hands_played': 0,
                    'vpip': 0,  # voluntarily put money in pot
                    'pfr': 0,   # preflop raise
                    'aggression': 0,
                    'showdowns': 0,
                    'wins': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            # Extract hole cards from community cards or maintain from previous state
            self.current_hand = {
                'round_num': round_state.round_num,
                'preflop_actions': [],
                'postflop_actions': []
            }

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate pot odds and hand strength
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            
            # Safety checks
            if call_amount < 0:
                call_amount = 0
            if call_amount > remaining_chips:
                call_amount = remaining_chips
                
            pot_odds = call_amount / (round_state.pot + call_amount + 0.001)  # avoid division by zero
            
            # Get hand strength based on round
            if round_state.round == 'Preflop':
                hand_strength = self.evaluate_preflop_hand()
            else:
                hand_strength = self.evaluate_postflop_hand(round_state.community_cards)
            
            # Calculate position factor
            position_factor = self.get_position_factor(round_state)
            
            # Opponent modeling
            aggression_factor = self.get_opponent_aggression(round_state)
            
            # Stack size consideration
            stack_bb = remaining_chips / (self.big_blind + 0.001)
            
            # Decision logic
            if round_state.current_bet == 0:
                # We can check
                if hand_strength > 0.7:
                    # Strong hand - bet for value
                    bet_size = max(round_state.min_raise, int(round_state.pot * 0.6))
                    bet_size = min(bet_size, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                elif hand_strength > 0.4 and position_factor > 0.6:
                    # Decent hand in position - small bet
                    bet_size = max(round_state.min_raise, int(round_state.pot * 0.3))
                    bet_size = min(bet_size, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # There's a bet to call
                if call_amount >= remaining_chips * 0.95:
                    # Basically all-in decision
                    if hand_strength > 0.8:
                        return (PokerAction.ALL_IN, 0)
                    elif hand_strength > 0.6 and stack_bb < 15:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                
                # Normal betting decision
                if hand_strength > pot_odds + 0.2:
                    # Good hand relative to pot odds
                    if hand_strength > 0.8:
                        # Very strong - raise
                        raise_size = max(round_state.min_raise, int(round_state.pot * 0.8))
                        raise_size = min(raise_size, round_state.max_raise)
                        if raise_size >= round_state.min_raise:
                            return (PokerAction.RAISE, raise_size)
                        else:
                            return (PokerAction.CALL, 0)
                    elif hand_strength > 0.6:
                        # Strong - call or small raise
                        if position_factor > 0.6 and aggression_factor < 0.7:
                            raise_size = max(round_state.min_raise, int(round_state.pot * 0.4))
                            raise_size = min(raise_size, round_state.max_raise)
                            if raise_size >= round_state.min_raise:
                                return (PokerAction.RAISE, raise_size)
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > pot_odds - 0.1:
                    # Marginal hand
                    if position_factor > 0.7 and call_amount < remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Safety fallback
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif round_state.current_bet - round_state.player_bets.get(str(self.id), 0) <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent statistics based on actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                self.opponent_stats[player_id]['hands_played'] += 1
                if action in ['Call', 'Raise', 'All_in']:
                    self.opponent_stats[player_id]['vpip'] += 1
                if action in ['Raise', 'All_in'] and round_state.round == 'Preflop':
                    self.opponent_stats[player_id]['pfr'] += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Update final statistics
        pass

    def evaluate_preflop_hand(self) -> float:
        """Evaluate preflop hand strength without knowing exact hole cards"""
        # Since we don't have access to exact hole cards, use statistical approach
        # This is a simplified heuristic based on typical preflop ranges
        return random.uniform(0.3, 0.9)  # Placeholder - in real implementation would use actual cards

    def evaluate_postflop_hand(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if not community_cards:
            return self.evaluate_preflop_hand()
        
        # Simplified evaluation based on community texture
        # In practice, would combine hole cards with community cards
        num_cards = len(community_cards)
        base_strength = 0.4
        
        # Adjust based on board texture
        if num_cards >= 3:
            # Check for potential draws and made hands
            suits = [card[-1] for card in community_cards]
            ranks = [card[:-1] for card in community_cards]
            
            # Flush potential
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            
            if max_suit_count >= 3:
                base_strength += 0.1
            
            # Pair potential
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            if max(rank_counts.values()) >= 2:
                base_strength += 0.2
        
        return min(base_strength + random.uniform(-0.2, 0.3), 1.0)

    def get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage"""
        num_players = len(round_state.current_player)
        if num_players <= 1:
            return 0.5
        
        # Simplified position calculation
        player_indices = list(round_state.current_player)
        if self.id in player_indices:
            position = player_indices.index(self.id)
            return position / (len(player_indices) - 1 + 0.001)
        return 0.5

    def get_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Estimate opponent aggression level"""
        aggression_sum = 0
        count = 0
        
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All_in']:
                    aggression_sum += 1.0
                elif action in ['Call']:
                    aggression_sum += 0.5
                count += 1
        
        return aggression_sum / (count + 0.001)