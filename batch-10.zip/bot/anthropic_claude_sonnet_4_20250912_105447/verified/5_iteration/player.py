from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.games_played = 0
        self.total_profit = 0
        self.aggressive_factor = 0.3
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        
    def evaluate_hand_strength(self) -> float:
        """Evaluate hole cards strength (0.0 to 1.0)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.3
            
        card1, card2 = self.hole_cards
        
        # Extract ranks and suits
        rank1 = card1[0]
        suit1 = card1[1] if len(card1) > 1 else 'x'
        rank2 = card2[0]
        suit2 = card2[1] if len(card2) > 1 else 'x'
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 7)
        val2 = rank_values.get(rank2, 7)
        
        # Base strength from high cards
        strength = (val1 + val2) / 28.0
        
        # Pair bonus
        if rank1 == rank2:
            strength += 0.4
            if val1 >= 10:  # High pairs
                strength += 0.3
                
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
            
        # High card bonus
        if val1 >= 11 or val2 >= 11:  # Face cards or Ace
            strength += 0.1
            
        # Connected cards bonus
        if abs(val1 - val2) == 1:
            strength += 0.05
            
        return min(strength, 1.0)
    
    def calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        """Calculate pot odds for calling"""
        if call_amount <= 0:
            return float('inf')
        total_pot = round_state.pot + call_amount
        return total_pot / (call_amount + 0.001)  # Avoid division by zero

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Calculate how much we need to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_current_bet)
            
            # Evaluate hand strength
            hand_strength = self.evaluate_hand_strength()
            
            # Get pot odds
            pot_odds = self.calculate_pot_odds(round_state, call_amount) if call_amount > 0 else float('inf')
            
            # Adjust strategy based on position and game state
            is_heads_up = len([p for p in round_state.current_player if p in round_state.current_player]) <= 2
            
            # Pre-flop strategy
            if round_state.round == "Preflop":
                return self.preflop_strategy(round_state, remaining_chips, hand_strength, call_amount, is_heads_up)
            
            # Post-flop strategy
            else:
                return self.postflop_strategy(round_state, remaining_chips, hand_strength, call_amount, pot_odds)
                
        except Exception as e:
            # Fallback to safe action
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_current_bet)
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, is_heads_up: bool) -> Tuple[PokerAction, int]:
        """Pre-flop strategy"""
        
        # Very strong hands - always play aggressively
        if hand_strength >= 0.8:
            if call_amount == 0:
                # No bet to call, make a strong bet
                bet_size = max(round_state.min_raise, min(remaining_chips, round_state.pot // 2 + self.blind_amount * 3))
                return (PokerAction.RAISE, bet_size)
            elif call_amount < remaining_chips * 0.3:
                if remaining_chips > call_amount * 3:
                    # Raise with strong hand
                    raise_amount = max(round_state.min_raise, min(remaining_chips, call_amount * 3))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
        
        # Good hands
        elif hand_strength >= 0.6:
            if call_amount == 0:
                if is_heads_up:
                    bet_size = max(round_state.min_raise, min(remaining_chips, self.blind_amount * 2))
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Marginal hands
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount and is_heads_up:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Post-flop strategy"""
        
        # Very strong hands - bet for value
        if hand_strength >= 0.8:
            if call_amount == 0:
                bet_size = max(round_state.min_raise, min(remaining_chips, round_state.pot // 2))
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CALL, 0)
        
        # Good hands - play based on pot odds
        elif hand_strength >= 0.6:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds >= 3.0 or call_amount < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Marginal hands - be cautious
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds >= 4.0 and call_amount < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - mostly fold
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds >= 6.0 and call_amount <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.games_played += 1
        self.total_profit += player_score
        
        # Adjust aggression based on performance
        if self.games_played >= 3:
            avg_profit = self.total_profit / self.games_played
            if avg_profit < -2:  # Losing too much
                self.aggressive_factor = max(0.1, self.aggressive_factor * 0.9)
            elif avg_profit > 2:  # Winning
                self.aggressive_factor = min(0.5, self.aggressive_factor * 1.1)