from typing import List, Tuple, Dict, Any
import random
import math
from collections import defaultdict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 50
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.hand_history = []
        self.position = {}
        self.stack_sizes = {}
        self.aggression_factor = defaultdict(int)
        self.player_tightness = defaultdict(int)
        self.ranges = defaultdict(list)
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        for player in all_players:
            self.stack_sizes[player] = starting_chips
            self.aggression_factor[player] = 0
            self.player_tightness[player] = 0
            
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        all_cards = hole_cards + community_cards
        values = [card[:-1] for card in all_cards]
        suits = [card[-1] for card in all_cards]
        
        value_counts = {}
        for v in values:
            value_counts[v] = value_counts.get(v, 0) + 1
            
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
            
        # Check for pairs and sets
        pairs = sum(1 for count in value_counts.values() if count == 2)
        trips = sum(1 for count in value_counts.values() if count == 3)
        quads = sum(1 for count in value_counts.values() if count == 4)
        
        strength = 0.0
        
        if quads > 0:
            strength = 0.9
        elif trips > 0 and pairs > 0:
            strength = 0.85  # Full house
        elif trips > 0:
            strength = 0.75
        elif pairs >= 2:
            strength = 0.65
        elif pairs == 1:
            strength = 0.5
        else:
            strength = 0.3
            
        # Check for flush potential
        for suit_count in suit_counts.values():
            if suit_count >= 5 and len(community_cards) >= 3:
                if all_cards[0][-1] == all_cards[1][-1] and all_cards[0][-1] in [s[-1] for s in community_cards if s[-1] == all_cards[0][-1]]:
                    strength = max(strength, 0.8)
                    
        # Check for straight potential
        value_mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                         '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        unique_values = list(set([value_mapping[v] for v in values]))
        unique_values.sort()
        
        straight_count = 1
        for i in range(len(unique_values) - 1):
            if unique_values[i + 1] - unique_values[i] == 1:
                straight_count += 1
                if straight_count >= 5:
                    strength = max(strength, 0.8)
                    break
            elif unique_values[i + 1] - unique_values[i] != 0:
                straight_count = 1
                
        return strength
    
    def _get_position_advantage(self, round_state: RoundStateClient) -> float:
        """Calculate positional advantage based on order of action"""
        if len(round_state.current_player) <= 2:
            # Heads up: check if we're dealer or not
            if self.id == round_state.current_player[0]:
                return 0.8  # In position
            else:
                return 0.4  # Out of position
        else:
            # Multi-way: later position is better
            total_players = len(round_state.player_bets)
            pos = list(round_state.player_bets.keys()).index(str(self.id))
            return (total_players - pos) / total_players
            
    def _pot_odds_calculation(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling decision"""
        current_bet = round_state.current_bet
        if current_bet == 0:
            return 0.0
            
        call_amount = current_bet
        pot = round_state.pot
        
        # Calculate implied odds
        effective_stack = min(remaining_chips, max(int(round_state.player_bets.get(str(p), 0)) for p in round_state.current_player))
        implied_pot = pot + int(0.2 * effective_stack)  # Conservative estimate
        
        return call_amount / implied_pot
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands
        community_cards = round_state.community_cards
        
        # Current bet situation
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        position_advantage = self._get_position_advantage(round_state)
        pot_odds = self._pot_odds_calculation(round_state, remaining_chips)
        
        # Adjust based on round
        round_factor = {
            'Preflop': 0.8,
            'Flop': 1.0,
            'Turn': 1.2,
            'River': 1.3
        }.get(round_state.round, 1.0)
        
        # Calculate expected value
        ev = hand_strength * position_advantage * round_factor
        
        # Check if we should call based on pot odds
        should_call = ev > pot_odds
        
        # Pre-flop specific logic
        if round_state.round == 'Preflop':
            # Good starting hands
            values = [card[:-1] for card in hole_cards]
            suited = hole_cards[0][-1] == hole_cards[1][-1]
            
            high_cards = sum(1 for v in values if v in ['T', 'J', 'Q', 'K', 'A'])
            pairs = values[0] == values[1]
            connectors = abs(['23456789TJQKA'.index(values[0]), '23456789TJQKA'.index(values[1])][0] - 
                           ['23456789TJQKA'.index(values[0]), '23456789TJQKA'.index(values[1])][1]) == 1
            
            if pairs or (high_cards >= 1 and suited) or (values[0] in ['K', 'A'] or values[1] in ['K', 'A']):
                if current_bet == 0:
                    # Open raise
                    raise_amount = min(3 * round_state.current_bet if round_state.current_bet > 0 else 3 * self.blind_amount, max_raise)
                    return PokerAction.RAISE, max(raise_amount, min_raise)
                elif should_call and current_bet <= remaining_chips * 0.15:
                    return PokerAction.CALL, 0
                elif current_bet > remaining_chips * 0.25:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CALL, 0
            else:
                # Weak starting hand
                if current_bet > 0 and not should_call:
                    return PokerAction.FOLD, 0
                elif current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, 0
        
        # Post-flop play
        if ev > 0.7:
            # Strong hand - bet for value
            bet_size = min(int(round_state.pot * 0.7), max_raise)
            if bet_size < min_raise:
                bet_size = min_raise
            if current_bet == 0:
                return PokerAction.RAISE, bet_size
            elif should_call:
                if remaining_chips * 0.5 <= current_bet and hand_strength > 0.8:
                    return PokerAction.ALL_IN, 0
                elif hand_strength > 0.7:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
                
        elif ev > 0.4:
            # Moderate hand - check-call small bets or bet if checked to
            if current_bet == 0:
                if random.random() < 0.3 and round_state.round != 'River':
                    bet_size = min(int(round_state.pot * 0.4), max_raise)
                    return PokerAction.RAISE, max(bet_size, min_raise)
                else:
                    return PokerAction.CHECK, 0
            elif should_call and current_bet <= remaining_chips * 0.1:
                return PokerAction.CALL, 0
            elif current_bet <= remaining_chips * 0.05:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
                
        else:
            # Weak hand
            if current_bet == 0:
                return PokerAction.CHECK, 0
            elif should_call and hand_strength > 0.3 and current_bet <= remaining_chips * 0.05:
                # Pot odds might justify call
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                   all_scores: dict, active_players_hands: dict):
        pass