from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.player_id = None
        self.hand_strength_preflop_map = {
            # Premium pairs
            ('A', 'A'): 0.95, ('K', 'K'): 0.90, ('Q', 'Q'): 0.85, ('J', 'J'): 0.80, ('T', 'T'): 0.75,
            # Suited connectors/A-suited
            ('A', 'K', True): 0.80, ('A', 'Q', True): 0.75, ('A', 'J', True): 0.70, ('A', 'T', True): 0.65,
            ('K', 'Q', True): 0.60, ('J', 'T', True): 0.55, ('T', '9', True): 0.50, ('9', '8', True): 0.45,
            # Big unsuited
            ('A', 'K', False): 0.70, ('A', 'Q', False): 0.65, ('K', 'Q', False): 0.55,
            # Medium pairs
            ('9', '9'): 0.60, ('8', '8'): 0.55, ('7', '7'): 0.50, ('6', '6'): 0.45,
            # Other suited connectors
            ('Q', 'J', True): 0.55, ('K', 'J', True): 0.50, ('Q', 'T', True): 0.45,
            ('5', '5'): 0.40, ('4', '4'): 0.35, ('3', '3'): 0.30, ('2', '2'): 0.25,
        }
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10,
            'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        self.opponent_count = 0

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.player_id_map = {p: i for i, p in enumerate(all_players)}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_my_hole_cards(round_state)
        self.opponent_count = len(round_state.current_player) - 1 # Subtract self

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)

        if self.determine_if_folded(round_state):
            return (PokerAction.FOLD, 0)

        # Calculate pot size
        pot_size = round_state.pot

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            hand_strength = self._calculate_preflop_strength()
            
            # Aggressive play with strong hands
            if hand_strength >= 0.75: # AA, KK, QQ, AKs, AKo
                if current_bet_to_call == 0: # No raise yet
                    return (PokerAction.RAISE, min(round_state.max_raise, 3 * self.blind_amount)) # 3x big blind
                elif current_bet_to_call < remaining_chips / 4: # Small raise, re-raise
                    raise_amount = min(round_state.max_raise, current_bet_to_call * 2)
                    if raise_amount > 0 and raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else: # Can't raise enough, call or all in
                        return (PokerAction.CALL if current_bet_to_call <= remaining_chips else PokerAction.ALL_IN, 0)
                else: # Big raise, consider all-in or fold
                     if current_bet_to_call >= remaining_chips:
                         return (PokerAction.ALL_IN, 0)
                     elif current_bet_to_call < remaining_chips / 2 and current_bet_to_call <= pot_size / 2: # Relatively small call
                         return (PokerAction.CALL, 0)
                     elif remaining_chips <= pot_size or self.opponent_count <= 1: # High risk, but good hand, go all-in
                        return (PokerAction.ALL_IN, 0)
                     else:
                        return (PokerAction.FOLD, 0) # Too expensive for pre-flop
            # Medium hands
            elif hand_strength >= 0.50: # JJ, TT, 99, AQ, ATs, KQs
                if current_bet_to_call == 0: # Check or min raise
                    return (PokerAction.RAISE, min(round_state.max_raise, 2 * self.blind_amount)) # 2x big blind or check
                elif current_bet_to_call <= remaining_chips / 5 and current_bet_to_call <= pot_size / 3: # Call small raises
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0) # Too expensive pre-flop
            # Speculative hands or blinds, try to see flop cheaply
            elif hand_strength >= 0.25: # Smaller pairs, suited connectors, A-xs
                if current_bet_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif current_bet_to_call <= self.blind_amount * 2 and current_bet_to_call <= remaining_chips / 10: # Call small raises (up to 2x BB) if cheap
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            # Weak hands
            else:
                return (PokerAction.FOLD, 0)

        # Post-flop strategy (Flop, Turn, River)
        current_board = self.hole_cards + round_state.community_cards
        hand_rank, _ = self._evaluate_hand(current_board)

        # Define thresholds for different hand strengths
        # Hand ranks: 0 (High Card) - 8 (Straight Flush)
        strong_hand_threshold = 6 # Two Pair or better
        medium_hand_threshold = 4 # One Pair or better (excluding very low pairs)
        bluff_threshold = 2 # Weak pair or high card 
        
        # Consider pot odds
        pot_odds_call = current_bet_to_call / (pot_size + current_bet_to_call + 1e-9)
        
        # Aggressiveness based on round
        aggressiveness_factor = 1.0
        if round_state.round == 'Flop':
            aggressiveness_factor = 1.2
        elif round_state.round == 'Turn':
            aggressiveness_factor = 1.5
        elif round_state.round == 'River':
            aggressiveness_factor = 2.0

        # Strong hands: Bet/Raise aggressively
        if hand_rank >= strong_hand_threshold:
            if current_bet_to_call == 0: # Check or bet
                bet_amount = int(pot_size * 0.75 * aggressiveness_factor)
                raise_amount = max(round_state.min_raise, bet_amount)
                return (PokerAction.RAISE, min(round_state.max_raise, raise_amount))
            else: # Call or re-raise
                if current_bet_to_call <= remaining_chips: # If we can call
                    # Re-raise if pot is not too big and we have good value
                    if current_bet_to_call <= pot_size * 0.5 and remaining_chips > current_bet_to_call * 2:
                        re_raise_amount = min(round_state.max_raise, current_bet_to_call * 2 + int(pot_size * 0.25))
                        if re_raise_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, re_raise_amount)
                        else: # Not enough to min-raise, just call
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)
                else: # Cannot call, all-in
                    return (PokerAction.ALL_IN, 0)

        # Medium hands: Call small bets, bet small if checked to, fold to big raises
        elif hand_rank >= medium_hand_threshold:
            if current_bet_to_call == 0: # Check or bet small
                bet_amount = int(pot_size * 0.4 * aggressiveness_factor)
                raise_amount = max(round_state.min_raise, bet_amount)
                return (PokerAction.RAISE, min(round_state.max_raise, raise_amount))
            elif current_bet_to_call <= remaining_chips * 0.25 and pot_odds_call < 0.3: # Call if cheap enough and good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

        # Weak hands or draws: Check, fold, or bluff occasionally
        else:
            # Check if no bet
            if current_bet_to_call == 0:
                # Small chance to bluff if no one has bet yet and we have few opponents
                if self.opponent_count <= 2 and (hand_rank >= bluff_threshold or self._has_draw(current_board)):
                    if self._should_bluff(round_state.round, remaining_chips, pot_size):
                        bet_amount = int(pot_size * 0.6 * aggressiveness_factor)
                        raise_amount = max(round_state.min_raise, bet_amount)
                        return (PokerAction.RAISE, min(round_state.max_raise, raise_amount))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            # Fold to any bet if hand is weak and no strong draws
            else:
                if self._has_draw(current_board) and pot_odds_call < 0.25: # Call small bets with draws
                    return (PokerAction.CALL, 0)
                elif current_bet_to_call >= remaining_chips: # Must go all-in
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_my_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """ Extracts the player's hole cards from the round state. """
        player_id_str = str(self.player_id)
        if hasattr(round_state, 'player_hands') and player_id_str in round_state.player_hands:
            return round_state.player_hands[player_id_str]
        return self.hole_cards # Fallback in case player_hands isn't always updated on time

    def _calculate_preflop_strength(self) -> float:
        """ Estimates pre-flop hand strength based on common poker hand rankings. """
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.0

        card1_rank = self.hole_cards[0][:-1]
        card1_suit = self.hole_cards[0][-1]
        card2_rank = self.hole_cards[1][:-1]
        card2_suit = self.hole_cards[1][-1]

        rank1_val = self.rank_map.get(card1_rank, 0)
        rank2_val = self.rank_map.get(card2_rank, 0)

        suited = (card1_suit == card2_suit)
        pair = (card1_rank == card2_rank)

        # Ensure consistent order for lookup
        ranks = tuple(sorted([card1_rank, card2_rank], key=lambda x: self.rank_map[x], reverse=True))

        if pair:
            return self.hand_strength_preflop_map.get((ranks[0], ranks[1]), 0.20) # Default for low pairs
        else:
            return self.hand_strength_preflop_map.get((ranks[0], ranks[1], suited), 0.10) # Default for unlisted or very weak

    def _evaluate_hand(self, cards: List[str]) -> Tuple[int, List[str]]:
        """
        Evaluates the best 5-card poker hand from given cards.
        Returns a tuple: (hand_rank, kicker_cards).
        Hand ranks:
            0: High Card
            1: One Pair
            2: Two Pair
            3: Three of a Kind
            4: Straight
            5: Flush
            6: Full House
            7: Four of a Kind
            8: Straight Flush
            9: Royal Flush
        Kicker cards are ranked from highest to lowest.
        """
        if len(cards) < 5:
            return 0, [] # Not enough cards to form a hand

        all_hands = []
        import itertools
        for combo in itertools.combinations(cards, 5):
            all_hands.append(self._get_hand_details(list(combo)))

        best_rank = -1
        best_kickers = []

        for rank, kickers in all_hands:
            if rank > best_rank:
                best_rank = rank
                best_kickers = kickers
            elif rank == best_rank:
                # Compare kickers for tie-breaking
                for i in range(min(len(kickers), len(best_kickers))):
                    if self.rank_map[kickers[i]] > self.rank_map[best_kickers[i]]:
                        best_rank = rank
                        best_kickers = kickers
                        break
                    elif self.rank_map[kickers[i]] < self.rank_map[best_kickers[i]]:
                        break
        return best_rank, best_kickers

    def _get_hand_details(self, hand: List[str]) -> Tuple[int, List[str]]:
        """
        Helper for _evaluate_hand: determines hand rank and kickers for a specific 5-card hand.
        """
        ranks = sorted([self.rank_map[card[:-1]] for card in hand], reverse=True)
        suits = [card[-1] for card in hand]

        is_flush = len(set(suits)) == 1
        is_straight = self._is_straight(ranks)

        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1

        counts_sorted = sorted(rank_counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
        # Eg: [(14, 2), (10, 1), (8, 1), (7, 1)] for AATTK
        # [(7, 3), (2, 2)] for 77722

        if is_straight and is_flush:
            if ranks[0] == 14 and ranks[1] == 13 and ranks[2] == 12 and ranks[3] == 11 and ranks[4] == 10:
                return 9, ranks # Royal Flush
            return 8, ranks # Straight Flush
        if counts_sorted[0][1] == 4:
            return 7, [counts_sorted[0][0], counts_sorted[1][0]] # Four of a Kind
        if counts_sorted[0][1] == 3 and counts_sorted[1][1] == 2:
            return 6, [counts_sorted[0][0], counts_sorted[1][0]] # Full House
        if is_flush:
            return 5, ranks # Flush
        if is_straight:
            return 4, ranks # Straight
        if counts_sorted[0][1] == 3:
            return 3, [counts_sorted[0][0]] + sorted([c[0] for c in counts_sorted[1:] if c[1] == 1], reverse=True) # Three of a Kind
        if counts_sorted[0][1] == 2 and counts_sorted[1][1] == 2:
            return 2, [counts_sorted[0][0], counts_sorted[1][0], counts_sorted[2][0]] # Two Pair
        if counts_sorted[0][1] == 2:
            return 1, [counts_sorted[0][0]] + sorted([c[0] for c in counts_sorted[1:] if c[1] == 1], reverse=True) # One Pair
        return 0, ranks # High Card

    def _is_straight(self, ranks: List[int]) -> bool:
        """Checks if a list of 5 sorted ranks forms a straight."""
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        if len(unique_ranks) < 5:
            return False
        
        # Check for standard straight
        is_regular_straight = all(unique_ranks[i] - 1 == unique_ranks[i+1] for i in range(len(unique_ranks) - 1))
        if is_regular_straight:
            return True
        
        # Check for A-5 straight (Ace low)
        if set(unique_ranks) == {14, 2, 3, 4, 5}:
            return True
        return False

    def _has_draw(self, cards: List[str]) -> bool:
        """
        Checks if the player has a strong flush or straight draw with current board.
        (e.g., 4 cards to a flush, open-ended straight draw)
        """
        if len(cards) < 3: # Need at least flop
            return False

        # Flush draw check
        suits = [card[-1] for card in cards]
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        for count in suit_counts.values():
            if count >= 4:
                return True # Has a 4-card flush

        # Straight draw check (open-ended or gutshot with high cards)
        current_ranks = sorted([self.rank_map[card[:-1]] for card in cards], reverse=True)
        unique_ranks = sorted(list(set(current_ranks)))

        # Check for open-ended or gutshot straight draws
        if len(unique_ranks) >= 4:
            for i in range(len(unique_ranks) - 3):
                # Check for open-ended straight draw (e.g., [4,5,6,7] needs 3 or 8)
                sub_ranks = unique_ranks[i:i+4]
                if (sub_ranks[3] - sub_ranks[0] == 3) and (len(sub_ranks) == 4):
                    return True # Open-ended: e.g., 4,5,6,7. Needs 3 or 8.
                
            # Check for gutshot where a high card could complete it, e.g. T, J, Q, A or J,Q,K,A
            if len(unique_ranks) >= 4:
                # Consider A-5 straight draw
                if {2,3,4,5}.issubset(set(unique_ranks)) or {14,2,3,4}.issubset(set(unique_ranks)) or \
                   {14,13,12,11}.issubset(set(unique_ranks)):
                    return True
                
                for i in range(len(unique_ranks) - 2):
                    if unique_ranks[i+2] - unique_ranks[i] == 2 and len(unique_ranks) >= 3: # Check for gaps of 1, e.g., [8,T] on board means we need 9.
                        # Need at least one more card to form a 4-card sequence if unique ranks are fewer than 5
                        # This condition is tricky. A simple check for gutshot:
                        # e.g., have 7, 9, T, J. Need 8 for a straight.
                        # Sort all cards, check for 4 consecutive ranks with one missing.
                        for r_idx in range(len(unique_ranks) - 3):
                            segment = unique_ranks[r_idx : r_idx + 4]
                            if len(segment) == 4:
                                # Example: [5, 6, 8, 9] requires 7. Sum of differences is 4, not 3.
                                # Example: [5, 6, 7, 9] requires 8. Sum of differences is 4.
                                # Need to be more precise: count consecutive sequences.
                                missing_count = 0
                                for j in range(len(segment) - 1):
                                    if segment[j+1] - segment[j] > 1:
                                        missing_count += (segment[j+1] - segment[j] - 1)
                                if missing_count == 1: # One card missing for a straight
                                    return True # Has a gutshot draw

        return False

    def _should_bluff(self, current_round: str, remaining_chips: int, pot_size: int) -> bool:
        """
        Determines if a bluff is advisable based on round, number of opponents, and stack depth.
        More likely to bluff on later streets with fewer opponents.
        """
        # Only bluff if heads-up or 3-way pot
        if self.opponent_count > 2:
            return False
        
        # Don't bluff if stack is very small relative to pot (all-in bluff is okay if calculated)
        if remaining_chips < pot_size / 2 and remaining_chips < self.blind_amount * 5:
            return False

        # Bluff based on round
        if current_round == 'Flop':
            return self.opponent_count <= 1 # Bluff heads-up
        elif current_round == 'Turn':
            return self.opponent_count <= 2
        elif current_round == 'River':
            return self.opponent_count <= 2 and (remaining_chips > pot_size * 0.75) # Only bluff if we have significant stack and can make a big bet

        return False

    def determine_if_folded(self, round_state: RoundStateClient) -> bool:
        """
        Checks if the current player has folded in the current round.
        """
        player_id_str = str(self.player_id)
        if player_id_str in round_state.player_actions:
            if round_state.player_actions[player_id_str] == 'Fold':
                return True
        return False