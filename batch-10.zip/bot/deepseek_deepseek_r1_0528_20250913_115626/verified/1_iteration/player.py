from typing import List, Tuple, Dict, Any, Optional
from enum import Enum
import itertools

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class Bot(ABC):
    def __init__(self) -> None:
        """ Initializes the player. """
        self.id = None
        pass

    def set_id(self, player_id: int) -> None:
        """ Sets the player ID. """
        self.id = player_id

    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        """ Called when the game starts. """
        pass

    @abstractmethod
    def on_round_start(self, round_state: Any, remaining_chips: int) -> None:
        """ Called at the start of each round. """
        pass

    @abstractmethod
    def get_action(self, round_state: Any, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Called when it is the player's turn to act. """
        pass

    @abstractmethod
    def on_end_round(self, round_state: Any, remaining_chips: int) -> None:
        """ Called at the end of each round. """
        pass

    @abstractmethod
    def on_end_game(self, round_state: Any, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        """ Called at the end of the game. """
        pass

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: List[Dict[str, any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.player_order = []
        self.blind_amount = 0
        self.pre_flop_table = {
            'AA': 10, 'KK': 10, 'QQ': 10, 'JJ': 10, 'TT': 9, '99': 8, '88': 7, '77': 6, '66': 5, '55': 4, '44': 3, '33': 2, '22': 1,
            'AKs': 10, 'AQs': 9, 'AJs': 8, 'ATs': 7, 'KQs': 7, 'QJs': 6, 'JTs': 6, 'T9s': 5, '98s': 4, '87s': 3, '76s': 3, '65s': 2, '54s': 1,
            'AKo': 8, 'AQo': 7, 'KQo': 6, 'AJo': 5, 'KJo': 4, 'QJo': 3, 'JTo': 2, 'T9o': 1
        }
        self.rank_order = 'AKQJT98765432'
        self.suits = 'cdhs'

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_order = all_players
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def evaluate_5card(self, cards):
        if len(cards) != 5:
            return 0
        
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        suits = [card[1] for card in cards]
        ranks = sorted([rank_map[card[0]] for card in cards], reverse=True)
        
        is_flush = len(set(suits)) == 1
        is_straight = (ranks[0] - ranks[-1] == 4 and len(set(ranks)) == 5) or (ranks == [14,5,4,3,2] and len(set(ranks)) == 5)
        
        if is_straight and is_flush:
            return 8000000 + ranks[0]
        
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r,0) + 1
        count_values = sorted(rank_counts.values(), reverse=True)
        
        if count_values[0] == 4:
            quad_rank = [r for r, count in rank_counts.items() if count == 4][0]
            kicker = [r for r in ranks if r != quad_rank][0]
            return 7000000 + quad_rank * 100 + kicker
        
        if count_values[0] == 3 and count_values[1] == 2:
            three_rank = [r for r, count in rank_counts.items() if count == 3][0]
            two_rank = [r for r, count in rank_counts.items() if count == 2][0]
            return 6000000 + three_rank * 100 + two_rank
        
        if is_flush:
            return 5000000 + ranks[0]*14**4 + ranks[1]*14**3 + ranks[2]*14**2 + ranks[3]*14 + ranks[4]
        
        if is_straight:
            return 4000000 + ranks[0]
        
        if count_values[0] == 3:
            three_rank = [r for r, count in rank_counts.items() if count == 3][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)
            return 3000000 + three_rank * 10000 + kickers[0]*100 + kickers[1]
        
        if count_values[0] == 2 and count_values[1] == 2:
            pairs = sorted([r for r, count in rank_counts.items() if count == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return 2000000 + pairs[0]*10000 + pairs[1]*100 + kicker
        
        if count_values[0] == 2:
            pair_rank = [r for r, count in rank_counts.items() if count == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return 1000000 + pair_rank * 10000 + kickers[0]*100 + kickers[1]
        
        return 0 + ranks[0]*14**4 + ranks[1]*14**3 + ranks[2]*14**2 + ranks[3]*14 + ranks[4]

    def evaluate_hand(self, cards):
        if len(cards) < 5:
            return 0
        best_rank = 0
        for combo in itertools.combinations(cards, 5):
            rank = self.evaluate_5card(combo)
            if rank > best_rank:
                best_rank = rank
        return best_rank

    def count_outs(self, hole_cards, community_cards):
        return 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.hole_cards is None:
            return (PokerAction.FOLD, 0)
        
        if round_state.round == 'Preflop':
            hole_cards = self.hole_cards
            card1, card2 = hole_cards
            rank1 = card1[0]
            suit1 = card1[1]
            rank2 = card2[0]
            suit2 = card2[1]
            
            if self.rank_order.index(rank1) < self.rank_order.index(rank2):
                rank1, rank2 = rank2, rank1
            if rank1 == rank2:
                key = rank1 + rank2
            else:
                if suit1 == suit2:
                    key = rank1 + rank2 + 's'
                else:
                    key = rank1 + rank2 + 'o'
            
            score = self.pre_flop_table.get(key, 0)
            
            try:
                index = round_state.current_player.index(self.id)
                position = len(round_state.current_player) - index - 1
            except:
                position = 0
            
            our_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - our_bet
            
            if call_amount == 0:
                if score >= 8 or (score >= 6 and position >= 2) or (score >= 4 and position >= 4):
                    raise_amount = 3 * (2 * self.blind_amount)
                    raise_amount = min(raise_amount, remaining_chips)
                    if raise_amount < round_state.min_raise:
                        raise_amount = round_state.min_raise
                    if raise_amount > round_state.max_raise:
                        raise_amount = round_state.max_raise
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if score >= 8:
                    raise_amount = 3 * call_amount
                    raise_amount = min(raise_amount, remaining_chips)
                    if raise_amount < round_state.min_raise:
                        if remaining_chips >= round_state.min_raise:
                            return (PokerAction.RAISE, round_state.min_raise)
                        else:
                            return (PokerAction.ALL_IN, 0)
                    else:
                        if raise_amount > round_state.max_raise:
                            raise_amount = round_state.max_raise
                        return (PokerAction.RAISE, raise_amount)
                elif score >= 7 and call_amount <= 0.05 * (remaining_chips + our_bet + call_amount):
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            hole_cards = self.hole_cards
            community_cards = round_state.community_cards
            hand_strength = self.evaluate_hand(hole_cards + community_cards)
            our_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - our_bet
            
            if hand_strength >= 6000000:
                category = 4
            elif hand_strength >= 4000000:
                category = 3
            elif hand_strength >= 3000000:
                category = 2
            elif hand_strength >= 2000000:
                category = 1
            else:
                category = 0
            
            if call_amount == 0:
                if category >= 2:
                    bet_amount = round_state.pot // 2
                    bet_amount = min(bet_amount, remaining_chips)
                    if bet_amount < round_state.min_raise:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if category >= 3:
                    additional = 3 * call_amount
                    if additional < round_state.min_raise:
                        additional = round_state.min_raise
                    total_bet = our_bet + call_amount + additional
                    if total_bet > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, additional)
                elif category >= 2:
                    return (PokerAction.CALL, 0)
                else:
                    outs = self.count_outs(hole_cards, community_cards)
                    if round_state.round == 'Flop':
                        cards_left = 47
                    elif round_state.round == 'Turn':
                        cards_left = 46
                    else:
                        cards_left = 0
                    
                    if cards_left > 0:
                        prob = outs / cards_left
                        required_prob = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 1.0
                        if prob >= required_prob:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass