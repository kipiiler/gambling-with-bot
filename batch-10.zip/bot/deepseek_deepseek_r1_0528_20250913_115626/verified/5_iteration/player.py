from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import enum
import itertools

class Rank(enum.IntEnum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8

def rank_to_value(rank: str) -> int:
    rank_map = {
        '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
        'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
    }
    return rank_map[rank[0]]

def suited_key(hole_cards: List[str]) -> bool:
    return hole_cards[0][1] == hole_cards[1][1]

def hand_key(hole_cards: List[str]) -> Tuple[int, int, bool]:
    card1, card2 = hole_cards
    r1, r2 = rank_to_value(card1), rank_to_value(card2)
    high, low = max(r1, r2), min(r1, r2)
    suited = suited_key(hole_cards)
    return (high, low, suited)

hand_groups = {
    # Group 1: Premium hands
    (14, 14, False): 1, # AA
    (13, 13, False): 1, # KK
    (12, 12, False): 1, # QQ
    (11, 11, False): 1, # JJ
    (14, 13, True): 1,  # AKs
    # Group 2: Strong hands
    (14, 12, True): 2,  # AQs
    (10, 10, False): 2, # TT
    (14, 13, False): 2, # AKo
    # Group 3: Good hands
    (14, 11, True): 3,  # AJs
    (13, 12, True): 3,  # KQs
    (9, 9, False): 3,   # 99
    # Group 4: Playable hands
    (14, 10, True): 4,  # ATs
    (13, 11, True): 4,  # KJs
    (12, 11, True): 4,  # QJs
    (11, 10, True): 4,  # JTs
    (8, 8, False): 4,   # 88
    # Group 5: Speculative hands
    (14, 9, True): 5,   # A9s
    (13, 10, True): 5,  # KTs
    (12, 10, True): 5,  # QTs
    (11, 9, True): 5,   # J9s
    (10, 9, True): 5,   # T9s
    (9, 8, True): 5,    # 98s
    (7, 7, False): 5,   # 77
    (14, 12, False): 5, # AQo
    # Group 6: Marginal hands
    (14, 8, True): 6,   # A8s
    (13, 9, True): 6,   # K9s
    (12, 9, True): 6,   # Q9s
    (11, 8, True): 6,   # J8s
    (10, 8, True): 6,   # T8s
    (9, 7, True): 6,    # 97s
    (8, 7, True): 6,    # 87s
    (7, 6, True): 6,    # 76s
    (6, 6, False): 6,   # 66
    (14, 9, False): 6,  # A9o
    (13, 12, False): 6, # KQo
    (12, 11, False): 6, # QJo
    (11, 10, False): 6, # JTo
    # Group 7: Weak hands
    (14, 7, True): 7, (14, 6, True): 7, (14, 5, True): 7, (14, 4, True): 7, (14, 3, True): 7, (14, 2, True): 7,
    (13, 8, True): 7, (12, 8, True): 7, (11, 7, True): 7, (10, 7, True): 7, (9, 6, True): 7, (8, 6, True): 7,
    (7, 5, True): 7, (6, 5, True): 7, (5, 5, False): 7, (5, 4, True): 7,
    (14, 10, False): 7,  # ATo
    (13, 10, False): 7,  # KTo
    (12, 10, False): 7,  # QTo
    (10, 9, False): 7,  # T9o
    (9, 8, False): 7,   # 98o
    # Group 8: Trash hands (everything else)
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_list = []
        self.hand = None
        self.position_offs = []
        self.button_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_list = all_players
        self.button_id = (all_players.index(small_blind_player_id) - 2) % len(all_players)
        self.hand = player_hands

        # Calculate positions for the bot
        our_id = self.id
        n = len(all_players)
        # The button is the dealer. Positions are from the dealer: 0 is button, then 1 is small blind, ... 
        # Our position index relative to button
        button_index = self.player_list.index(self.button_id)
        our_index = self.player_list.index(our_id)
        # position_off: the distance from the button, higher is worst (acts earlier)
        self.position_off = (our_index - button_index) % n
        # Classify position: Early: close to the big blind (UTG, UTG+1, ...), Mid: middle, Late: cutoff and button
        # If n=6: positions: 0 (button)=late, 1 (small blind)=early? -> We'll redefine: for preflop play the position is based on how many players have to act after us.
        # Instead, let's calculate the order of next players: after us until the button? We want to know if we are early (act first) or late (act later)
        # Actually, after the hole cards, the first to act is UTG (one after big blind) and the last is big blind.
        # The big blind is the last, then button, then cutoff.
        # So we compute the position from the big blind: after_blinds? 
        # How much from the big blind we are? But the button is not acting until the turn? For preflop, the order: UTG -> UTG+1 ... -> cutoff -> button (if any) -> small blind -> big blind
        # But note: the blinds have already posted. The first to act in preflop is the player after big blind (with exception if we are heads up). 
        # We'll just use a simple off for now: 
        self.relative_position = (our_id - self.big_blind_player_id) % len(self.all_players)
        # But we'll wait until the game state

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def preflop_eval(self, hole_cards) -> int:
        key = hand_key(hole_cards)
        # Also check for same hand but reversed
        rev_key = (key[1], key[0], key[2])
        if key in hand_groups:
            return hand_groups[key]
        elif rev_key in hand_groups:
            return hand_groups[rev_key]
        else:
            return 8  # trash by default

    def get_board_type(self, board):
        if len(board) == 0:
            return 0  # dry board preflop

        # Check for possible flushes: count suits
        suits = [card[1] for card in board]
        from collections import defaultdict
        suit_count = defaultdict(int)
        for s in suits:
            suit_count[s] += 1
        max_suit = max(suit_count.values()) if suit_count else 0
        if max_suit >= 3:
            return 1  # flush draw present
        # Check for straights: ranks
        ranks = sorted([rank_to_value(card) for card in board])
        unique_ranks = sorted(set(ranks))
        if 14 in unique_ranks:
            unique_ranks.append(1)  # for wheel
        unique_ranks.sort()
        consecutive_count = 0
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i] == unique_ranks[i-1] + 1:
                consecutive_count += 1
                if consecutive_count >= 3:  # 4 cards? at least 3 consec at flop?
                    return 2  # straight draw
            else:
                consecutive_count = 0
        return 0  # relatively dry

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hand_stage = round_state.round
        if not self.hand:
            # Emergency: if we lost our hand, return fold
            return (PokerAction.FOLD, 0)

        my_id = self.id
        our_bet = round_state.player_bets.get(str(my_id), 0)
        to_call = round_state.current_bet - our_bet
        can_check = to_call == 0

        # Pot size
        pot_size = round_state.pot

        # Calculate pot odds
        pot_odds = (pot_size + to_call) / to_call if to_call > 0 else float('inf')

        # Check the board texture
        board_type = self.get_board_type(round_state.community_cards)

        # Pre-flop strategy
        if hand_stage == 'Preflop':
            group = self.preflop_eval(self.hand)
            # Default action: fold
            action = PokerAction.FOLD
            raise_amount = 0

            if group in [1,2]:
                # Raise first in
                action = PokerAction.RAISE
                # Raise 3bb to 4bb
                bb = round_state.min_raise // 2  # big blind is the min_raise? Actually min_raise is the amount to at least raise to. In the first round, min_raise? 
                if to_call > 0:
                    if group == 1:
                        # 3-bet: raise 3x the current raise amount? Or 3x the bet we face? But no, we need to raise to a total of 3x the current bet (which is the last bet to call)
                        # The min_raise requires that we raise to at least current_bet + (current_bet - current min_raise) ... but the min_raise is already provided
                        # How about: we raise to at least current_bet + min_raise
                        # But no: standard: the min_raise = current bet (last bet) + the amount that is at least the difference since the last raise? 
                        # Actually the state gives: min_raise and max_raise
                        if remaining_chips > to_call * 10:  # deep stack
                            raise_amount = min(remaining_chips, to_call * 4)  # 4x as an initial reraise
                        else:
                            action = PokerAction.ALL_IN
                    else:
                        # Group 2: call
                        if to_call <= 0.3 * remaining_chips:
                            action = PokerAction.CALL
                        else:
                            action = PokerAction.FOLD
                else:
                    # We are first to act or after limpers: open raise
                    raise_amount = round_state.min_raise * 2
            elif group in [3,4]:
                if to_call == 0:
                    action = PokerAction.RAISE
                    raise_amount = round_state.min_raise * 2
                elif to_call <= 0.2 * remaining_chips:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD
            elif group in [5,6]:
                if to_call == 0:
                    # Only raise in late position? 
                    # If we are in the last 3 positions (blinds), then we can raise? Or just call? 
                    # But we don't have position in pre-flop defined. We'll base on relative position: if we are the button or cutoff? 
                    if self.position_off >= 3:  # we are playing from an early position: fold
                        action = PokerAction.FOLD
                    else:
                        action = PokerAction.CALL  # just limp? But default to fold if someone raised? 
                elif to_call <= round_state.min_raise // 2:  # the big blind
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD
            elif group in [7]:
                if to_call == 0 and self.position_off <= 1:  # late position: we are the button or cutoff
                    action = PokerAction.CALL
                elif to_call == round_state.min_raise // 2:  # big blind, so we check
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD
            else:
                # group 8: only the big blind if no raise
                if to_call == 0:
                    action = PokerAction.CALL
                elif to_call == round_state.min_raise // 2:  # small blind facing a min raise? Actually, small blind has already put in half the big blind. 
                    # If we are the big blind? But the to_call would be half of the big blind? Let me think: 
                    # The small blind already put SB, so when action comes to small blind, to_call is BB - SB = SB amount. 
                    # We are in big blind? When action comes to big blind, the to_call is 0? 
                    # Actually, the big blind is the last to act. 
                    # So if we are in the big blind, we can check? 
                    # So if to_call is 0 and we are the big blind, we check? 
                    # But we don't know if we are big blind? So we have stored big_blind_player_id? 
                    if my_id == self.big_blind_player_id and to_call == 0:
                        action = PokerAction.CHECK
                    else:
                        action = PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

            # Validate the action: if we choose check and to_call is not zero, then must fold
            if action == PokerAction.CHECK:
                if can_check:
                    return (action, 0)
                else:
                    action = PokerAction.FOLD

            if action == PokerAction.RAISE:
                # We might not be able to raise more than max_raise, and at least min_raise
                min_raise = round_state.min_raise
                max_raise = round_state.max_raise
                if raise_amount < min_raise:
                    raise_amount = min_raise
                if raise_amount > max_raise:
                    raise_amount = max_raise
                return (action, raise_amount)

            if action == PokerAction.CALL and to_call > 0:
                # If calling is going all in? But the server handles that
                return (action, 0)
            if action == PokerAction.ALL_IN:
                return (action, 0)
            return (action, 0)

        else:
            hand_values = [rank_to_value(card) for card in self.hand]
            board_values = [rank_to_value(card) for card in round_state.community_cards]

            # Check if we have top pair or better: pair with at least top 50%? 
            made_hand = any(c in board_values for c in hand_values)
            draw_hand = False
            # Very basic: if we don't have any pair on the board and no draw, and we are at turn/river -> fold
            if not made_hand and hand_stage in ['Turn', 'River']:
                # Maybe we have a draw? But we didn't make it, so fold
                return (PokerAction.FOLD, 0)

            # If at flop and we have no pair, but we have a draw? 
            if hand_stage == 'Flop':
                # Check for flush draws: are we suited and one of the suit on board?
                suit_hole = [card[1] for card in self.hand]
                suit_board = [card[1] for card in round_state.community_cards]
                from collections import Counter
                c_board = Counter(suit_board)
                c_hole = Counter(suit_hole)
                if suit_hole[0] == suit_hole[1]:
                    if suit_hole[0] in c_board and c_board[suit_hole[0]] + 2 >= 5:
                        draw_hand = True
                else:
                    for suit in suit_hole:
                        if suit in c_board and c_board[suit] + 1 >= 4:
                            draw_hand = True

                # Check for straight draws? 

            # If we are in the river and we are weak, we fold to big bets
            if hand_stage == 'River' and made_hand and (max(hand_values) < max(board_values) + 1):
                # We are at river and we have a weak pair, and the board has a higher card
                if to_call > 0:
                    # If the pot odds are bad, fold
                    if pot_odds < 5 and not draw_hand:  # we need at least 20% equity
                        return (PokerAction.FOLD, 0)
                else:
                    # we can check
                    return (PokerAction.CHECK, 0)

            # If we get to here and have a made hand but not strong, and it's dry board, we might have the best
            if board_type == 0: # dry board, use made_hand
                if made_hand and to_call == 0:
                    return (PokerAction.CHECK, 0)
                if made_hand and to_call > 0:
                    if to_call < pot_size / 10:  # small bet, call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # but we have a draw -> use pot odds to determine
                    if draw_hand and pot_odds >= 4:  # 4 to 1 so we need 20%
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Wet board: we need stronger to continue
                if to_call == 0:
                    # If we have a draw, consider a bet? Or check to see free card
                    return (PokerAction.CHECK, 0)
                else:
                    # Only continue if we have a very strong hand
                    if max(hand_values) >= 12 and made_hand:  # at least a queen pair?
                        return (PokerAction.CALL, 0)
                    else:
                        if draw_hand and pot_odds >= 5:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)

            # If nothing above matched, default to fold
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass