from typing import List, Tuple, Dict, Any
import collections
from abc import ABC, abstractmethod
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hand = []
        self.community_cards = []
        self.big_blind = 0
        self.remaining_chips = 10000
        self.player_bets = {}
        self.player_actions = {}
        self.round_num = 0
        self.current_round = ""
        self.current_player_id = 0
        self.id = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        if isinstance(player_hands, list) and self.id < len(player_hands):
            self.my_hand = player_hands[self.id].split(',')
        self.remaining_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.community_cards = round_state.community_cards
        self.remaining_chips = remaining_chips
        self.player_bets = round_state.player_bets
        self.player_actions = round_state.player_actions
        self.round_num = round_state.round_num
        self.current_round = round_state.round
        self.current_player_id = round_state.current_player

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.community_cards = round_state.community_cards
        self.remaining_chips = remaining_chips
        self.player_bets = round_state.player_bets
        self.round_num = round_state.round_num
        self.current_round = round_state.round
        
        if "Preflop" in round_state.round:
            return self.preflop_strategy(round_state)
        else:
            return self.postflop_strategy(round_state)

    def eval_hand(self) -> int:
        all_cards = self.my_hand + self.community_cards
        ranks = [card[:-1] for card in all_cards]
        rank_count = collections.Counter(ranks)
        
        for rank, count in rank_count.items():
            if count >= 2:
                pocket_pair = any(rank == c[:-1] for c in self.my_hand)
                if pocket_pair:
                    if count >= 4: return 3
                    elif count == 3: return 3
                    return 2
        return 0

    def preflop_strategy(self, state: RoundStateClient) -> Tuple[PokerAction, int]:
        hand = sorted([card[:-1] for card in self.my_hand])
        
        premium = hand in [['A','A'], ['K','K'], ['Q','Q']]
        call_amount = state.current_bet - state.player_bets.get(str(self.id), 0)
        
        if call_amount <= 0:
            if premium:
                return (PokerAction.RAISE, min(5 * self.big_blind, self.remaining_chips))
            return (PokerAction.CHECK, 0)
        else:
            if premium and 'A' in hand:
                return (PokerAction.CALL, 0)
            if premium:
                raise_amt = min(max(3 * self.big_blind, call_amount + state.min_raise), state.max_raise)
                return (PokerAction.RAISE, int(raise_amt))
            return (PokerAction.FOLD, 0)

    def postflop_strategy(self, state: RoundStateClient) -> Tuple[PokerAction, int]:
        call_amount = state.current_bet - state.player_bets.get(str(self.id), 0)
        strength = self.eval_hand()
        
        if strength >= 2:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.CALL, 0)
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.community_cards = round_state.community_cards
        self.remaining_chips = remaining_chips
        self.player_bets = round_state.player_bets

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        self.remaining_chips = player_score