from typing import List, Tuple, Dict
from collections import defaultdict
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

def evaluate_hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    """
    A simplified hand evaluation function.
    Returns a strength value between 0.0 and 1.0.
    This is a heuristic and not a perfect poker hand calculator for performance.
    """
    all_cards = hole_cards + community_cards
    
    ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    suits = {'h': 0, 'd': 1, 'c': 2, 's': 3}
    
    rank_counts = defaultdict(int)
    suit_counts = defaultdict(int)
    card_ranks = []

    for card in all_cards:
        rank = card[0]
        suit = card[1]
        rank_counts[rank] += 1
        suit_counts[suit] += 1
        card_ranks.append(ranks[rank])
        
    card_ranks.sort(reverse=True)

    is_flush = any(count >= 5 for count in suit_counts.values())
    
    is_straight = False
    straight_high_rank = 0
    # Check for normal straight
    for i in range(len(card_ranks) - 4):
        if card_ranks[i] - card_ranks[i+4] == 4:
            is_straight = True
            straight_high_rank = card_ranks[i]
            break
    # Check for A-5 straight (wheel)
    if set(card_ranks) >= {14, 5, 4, 3, 2}:
        is_straight = True
        straight_high_rank = 5

    # Count occurrences of ranks
    count_values = sorted(rank_counts.values(), reverse=True)
    
    # Assign strength score
    # High Card: 0.0 - 0.4
    # One Pair: 0.4 - 0.5
    # Two Pair: 0.5 - 0.6
    # Three of a Kind: 0.6 - 0.7
    # Straight: 0.7 - 0.8
    # Flush: 0.8 - 0.9
    # Full House: 0.9 - 0.95
    # Four of a Kind: 0.95 - 0.99
    # Straight Flush / Royal Flush: 0.99 - 1.0

    score = 0.0
    
    if count_values[0] == 4: # Four of a kind
        score = 0.95 + (card_ranks[0] / 140.0) 
    elif count_values[0] == 3 and count_values[1] >= 2: # Full house
        score = 0.9 + (card_ranks[0] / 140.0)
    elif is_flush: # Flush
        score = 0.8 + (max(card_ranks) / 140.0)
    elif is_straight: # Straight
        score = 0.7 + (straight_high_rank / 140.0)
    elif count_values[0] == 3: # Three of a kind
        score = 0.6 + (card_ranks[0] / 140.0)
    elif count_values[0] == 2 and count_values[1] >= 2: # Two pair
        score = 0.5 + (max(card_ranks) / 140.0)
    elif count_values[0] == 2: # One pair
        score = 0.4 + (max(card_ranks) / 140.0)
    else: # High card
        score = max(card_ranks) / 140.0
    
    # Bonus for straight flush
    if is_flush and is_straight:
        score = 0.99 + (max(card_ranks) / 1400.0)
        if straight_high_rank == 14: # Royal flush
            score = 1.0
            
    return score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hole_cards: List[str] = []
        self.starting_chips: int = 0
        self.aggression_factor = 0.75
        self.blind_amount: int = 0
        self.my_id_str: str = ""

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hole_cards = player_hands
        self.blind_amount = blind_amount
        # Ensure my_id_str is set as soon as possible
        if self.id is not None:
            self.my_id_str = str(self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # This is called at the start of a new hand, so reset hole cards
        self.my_hole_cards = []
        # Ensure my_id_str is updated in case set_id was called late
        if self.id is not None:
            self.my_id_str = str(self.id)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.my_id_str and self.id is not None:
            self.my_id_str = str(self.id)
        if not self.my_hole_cards: # Should have been set by now, but as a fallback
             # This indicates a problem, but we must return an action.
             # Check is safest if no bet, else fold.
            if round_state.current_bet == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        effective_stack = remaining_chips
        pot_size = round_state.pot
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(self.my_id_str, 0)
        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max raise_amount

        hand_strength = evaluate_hand_strength(self.my_hole_cards, round_state.community_cards)
        
        current_round_enum = PokerRound[round_state.round.upper()]

        pot_odds = 0.0
        if current_bet_to_call > 0:
            pot_odds = current_bet_to_call / (pot_size + current_bet_to_call + 1e-9) # add delta to avoid div by zero

        # --- Betting Logic ---

        # 1. Fold if hand is very weak and cost to call is high
        if hand_strength < 0.2 and pot_odds > 0.4 and current_bet_to_call > 0:
            return PokerAction.FOLD, 0

        # 2. Check/Call with weak/medium hands based on pot odds
        action PokerAction.CALL
        bet_amount = 0

        if current_bet_to_call == 0: # Can check
            if hand_strength < 0.4: # Check weak hands
                action = PokerAction.CHECK
            # Semi-bluff with medium strength hands or bet strong hands
            elif hand_strength > 0.6 and random.random() < self.aggression_factor:
                action = PokerAction.RAISE
                # Raise a fraction of the pot
                bet_amount = min(max_raise_amount, int(pot_size * 0.75))
                bet_amount = max(min_raise_amount, bet_amount) # Ensure raise is legal
            else: # Check medium hands or sometimes strong hands for pot control
                action = PokerAction.CHECK
        else: # Must call, raise, or fold
            # Call if hand strength is greater than pot odds suggests
            if hand_strength > pot_odds + 0.1: 
                action = PokerAction.CALL
            # Value bet with strong hands
            elif hand_strength > 0.8 and current_bet_to_call < effective_stack * 0.3:
                action = PokerAction.RAISE
                bet_amount = min(max_raise_amount, int(pot_size * (0.8 + hand_strength))) # Bigger bet for stronger hand
                bet_amount = max(min_raise_amount, bet_amount)
            # Bluff raise with nothing if we sense weakness (e.g., if min_raise is small compared to pot)
            elif hand_strength < 0.3 and current_bet_to_call < pot_size * 0.1 and random.random() < 0.15:
                action = PokerAction.RAISE
                bet_amount = min(max_raise_amount, int(pot_size * 0.5)) # A standard bluff size
                bet_amount = max(min_raise_amount, bet_amount)
            else # Default to fold if calling is not profitable and we don't want to raise
                if hand_strength > 0.15 and current_bet_to_call < effective_stack * 0.05: # Call very small bets with almost anything
                    action = PokerAction.CALL
                else:
                    action = PokerAction.FOLD
        
        # 3. Go All-in as a last resort with strong hands or a desperate bluff
        if action == PokerAction.RAISE:
            # All-in with very strong hands (top 10%) or when short stacked
            if (hand_strength > 0.9 and effective_stack < pot_size * 2) or \
               (hand_strength > 0.7 and effective_stack < pot_size * 0.5) or \
               (hand_strength < 0.2 and effective_stack < pot_size * 0.2 and random.random() < 0.1): # Desperate bluff
                action = PokerAction.ALL_IN
                bet_amount = 0 # Amount is ignored for ALL_IN
                
        # Final validation of action
        if action == PokerAction.CHECK and current_bet_to_call > 0:
            action = PokerAction.FOLD # Cannot check if there's a bet to call
            
        if action == PokerAction.RAISE:
            # Bet amount must be at least min_raise and at most max_raise
            if bet_amount < min_raise_amount or bet_amount > max_raise_amount:
                # If our calculated raise is invalid, fallback to a safe action.
                # If raise is too small, make it min, if too big, go all-in if that's the intent, or call.
                if bet_amount < min_raise_amount:
                    if min_raise_amount <= max_raise_amount:
                        bet_amount = min_raise_amount
                    else: # Should not happen, min raise cant be > max raise
                        action = PokerAction.CALL if current_bet_to_call <= effective_stack else PokerAction.FOLD
                elif bet_amount > max_raise_amount: # Effectively an all-in
                    action = PokerAction.ALL_IN
                    bet_amount = 0

        if action == PokerAction.CALL and current_bet_to_call > effective_stack:
            action = PokerAction.ALL_IN # If calling costs more than you have, you must go all-in
        
        return action, bet_amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # This could be used to adjust strategy based on the outcome of the round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This could be used for long-term learning or adaptation
        pass