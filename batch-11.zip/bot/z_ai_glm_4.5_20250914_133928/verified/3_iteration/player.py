from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import itertools
from collections import defaultdict

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hole_cards = []
        self.position = 0
        self.opponent_model = defaultdict(lambda: {'aggression': 0.5, 'vpip': 0.5, 'pfr': 0.5, 'hands_played': 0})
        self.hand_strength_cache = {}
        self.pot_odds_calculator = PotOddsCalculator()
        self.hand_evaluator = HandEvaluator()
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.starting_chips = 10000
        self.current_round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_cache = {}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_state = round_state
        if round_state.round == 'Preflop':
            self.my_hole_cards = [self.my_hole_cards[0]] if len(self.my_hole_cards) > 0 else []
            if len(self.my_hole_cards) == 0 and self.id in round_state.player_bets:
                pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.current_round_state = round_state
        try:
            # Calculate hand strength
            hand_strength = self._calculate_hand_strength(round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self.pot_odds_calculator.calculate(
                round_state.pot, 
                round_state.current_bet - round_state.player_bets.get(str(self.id), 0), 
                remaining_chips
            )
            
            # Get position factor
            position_factor = self._calculate_position_factor(round_state)
            
            # Get opponent modeling
            opponent_factor = self._get_opponent_factor(round_state)
            
            # Calculate final action probability
            action_prob = (hand strength * 0.5) + (pot_odds * 0.2) + (position_factor * 0.15) + (opponent_factor * 0.15)
            
            # Determine action based on probability and game state
            current_bet_for_me = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - current_bet_for_me
            
            # If we need to call but have no chips, we must fold or go all-in with what we have
            if amount_to_call > remaining_chips:
                if remaining_chips > 0:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Check if we can check
            if amount_to_call == 0:
                if action_prob > 0.6 and remaining_chips > round_state.min_raise:
                    raise_amount = min(random.randint(round_state.min_raise, round_state.min_raise * 3), remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, raise_amount
                elif action_prob > 0.3:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                if action_prob > 0.8 and remaining_chips > amount_to_call + round_state.min_raise:
                    raise_amount = min(random.randint(amount_to_call + round_state.min_raise, amount_to_call + round_state.min_raise * 4), remaining_chips)
                    if raise_amount >= (amount_to_call + round_state.min_raise):
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.ALL_IN, 0
                elif action_prob > pot_odds + 0.1:
                    if amount_to_call <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                elif action_prob > 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
        except Exception as e:
            print(f"Error in get_action: {e}")
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent model based on observed actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                self.opponent_model[player_id]['hands_played'] += 1
                if action in ['Raise', 'All-in']:
                    self.opponent_model[player_id]['aggression'] = min(1.0, self.opponent_model[player_id]['aggression'] + 0.05)
                elif action == 'Fold':
                    self.opponent_model[player_id]['aggression'] = max(0.0, self.opponent_model[player_id]['aggression'] - 0.02)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _calculate_hand_strength(self, community_cards: List[str]) -> float:
        cards = self.my_hole_cards + community_cards if self.my_hole_cards else []
        if not cards:
            return 0.0
        
        cache_key = tuple(sorted(cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        strength = self.hand_evaluator.evaluate(cards)
        self.hand_strength_cache[cache_key] = strength
        return strength

    def _calculate_position_factor(self, round_state: RoundStateClient) -> float:
        if not round_state.current_player:
            return 0.5
        
        try:
            my_index = round_state.current_player.index(self.id)
            num_players = len(round_state.current_player)
            
            if num_players == 2:  # Heads-up
                return 0.8 if my_index == 0 else 0.5
            else:
                # Better position gives an advantage
                return 0.3 + (0.6 * (my_index / (num_players - 1)))
        except (ValueError, IndexError):
            return 0.5

    def _get_opponent_factor(self, round_state: RoundStateClient) -> float:
        if not round_state.current_player or len(round_state.current_player) <= 1:
            return 0.5
        
        # Analyze remaining opponents
        opponents = [p for p in round_state.current_player if p != self.id]
        if not opponents:
            return 0.5
        
        opponent_agg = sum(self.opponent_model[str(p)]['aggression'] for p in opponents) / len(opponents)
        
        # Adjust strategy based on opponent aggression
        if opponent_agg > 0.7:  # Against aggressive opponents
            return 0.3  # Play tighter
        elif opponent_agg < 0.3:  # Against passive opponents
            return 0.7  # Play looser
        else:
            return 0.5

class HandEvaluator:
    def __init__(self):
        self.card_rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suits = ['h', 'd', 'c', 's']
    
    def evaluate(self, cards: List[str]) -> float:
        if len(cards) < 2:
            return 0.0
        
        # Extract ranks and suits
        ranks = []
        suits = []
        for card in cards:
            if len(card) >= 2:
                ranks.append(self.card_rank_values.get(card[0], 0))
                suits.append(card[1] if len(card) > 1 else '')
        
        if not ranks:
            return 0.0
        
        # Count rank occurrences
        rank_counts = defaultdict(int)
        for r in ranks:
            rank_counts[r] += 1
        
        # Check for pairs, three of a kind, etc.
        counts = sorted(rank_counts.values(), reverse=True)
        is_flush = len(set(suits)) == 1 and len(suits) >= 5
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        is_straight = False
        straight_high = 0
        
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    is_straight = True
                    straight_high = unique_ranks[i+4]
                    break
        
        # Handle wheel straight (A,2,3,4,5)
        if not is_straight and set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            is_straight = True
            straight_high = 5
        
        # Evaluate hand strength
        if is_straight and is_flush:
            return 0.95  # Straight flush (royal flush very rare)
        elif counts[0] == 4:
            return 0.9  # Four of a kind
        elif counts[0] == 3 and counts[1] >= 2:
            return 0.8  # Full house
        elif is_flush:
            return 0.7  # Flush
        elif is_straight:
            return 0.6  # Straight
        elif counts[0] == 3:
            return 0.5  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 0.4  # Two pair
        elif counts[0] == 2:
            return 0.3  # One pair
        else:
            # High card
            high_card = max(ranks) if ranks else 0
            return min(0.2, high_card / 100.0)

class PotOddsCalculator:
    def calculate(self, pot: int, call_amount: int, remaining_chips: int) -> float:
        if call_amount == 0:
            return 1.0
        
        # Required equity to call
        try:
            odds = call_amount / (pot + call_amount + 1e-6)  # Avoid division by zero
            return min(1.0, odds)
        except:
            return 0.5