from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import Counter
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.id = None
        self.hole_cards = []
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.blind_amount = 0
        self.current_hand_strength = 0.0
        self.rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.all_players = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.blind_amount = blind_amount
        
        if self.id in all_players:
            idx = all_players.index(self.id)
            hand_str = player_hands[idx]
            self.hole_cards = [hand_str[i:i+2] for i in range(0, len(hand_str), 2)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_hand_strength = self._get_hand_strength(self.hole_cards, round_state.community_cards)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        community_cards = round_state.community_cards
        hole_cards = self.hole_cards
        current_bet = round_state.current_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_bets = round_state.player_bets
        current_players = round_state.current_player
        
        our_id_str = str(self.id)
        our_bet_so_far = player_bets.get(our_id_str, 0)
        amount_to_call = current_bet - our_bet_so_far
        
        hand_strength = self._get_hand_strength(hole_cards, community_cards)
        
        pot_odds = 0.0
        if pot > 0:
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-6)
        
        position_factor = 0.0
        if current_players:
            try:
                our_index = current_players.index(self.id)
                n_players = len(current_players)
                position_factor = (n_players - our_index - 1) / max(1, n_players - 1)
            except ValueError:
                position_factor = 0.5
        
        opponent_factor = 0.0
        aggressive_actions = sum(1 for pid, action in round_state.player_actions.items() 
                                if pid != our_id_str and action in ['Raise', 'AllIn'])
        if current_players:
            opponent_factor = min(1.0, aggressive_actions / max(1, len(current_players) - 1))
        
        action_prob = (hand_strength * 0.5) + (pot_odds * 0.2) + (position_factor * 0.15) + (opponent_factor * 0.15)
        
        if amount_to_call == 0:
            if action_prob > 0.6:
                raise_amount = min(min_raise, pot * 0.75)
                raise_amount = min(max_raise, max(min_raise, int(raise_amount)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CHECK, 0)
        else:
            if amount_to_call > remaining_chips:
                if action_prob > 0.5:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            if action_prob < 0.3:
                return (PokerAction.FOLD, 0)
            elif action_prob > 0.7:
                raise_amount = min(min_raise, pot * 0.75)
                raise_amount = min(max_raise, max(min_raise, int(raise_amount)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _get_hand_strength(self, hole_cards, community_cards):
        if not community_cards:
            return self._get_preflop_strength(hole_cards)
        else:
            return self._get_postflop_strength(hole_cards, community_cards)

    def _get_preflop_strength(self, hole_cards):
        if len(hole_cards) < 2:
            return 0.5
            
        rank1 = self.rank_map.get(hole_cards[0][0], 0)
        rank2 = self.rank_map.get(hole_cards[1][0], 0)
        suited = hole_cards[0][1] == hole_cards[1][1]
        
        if rank1 == rank2:
            base_strength = 0.3 + (rank1 - 2) * (0.7 / 12)
            return min(1.0, base_strength)
        
        high_card = max(rank1, rank2)
        low_card = min(rank1, rank2)
        
        base_strength = 0.1 + (high_card - 2) * (0.5 / 12)
        if suited:
            base_strength += 0.1
        
        card_diff = high_card - low_card
        if card_diff == 1:
            base_strength += 0.1
        elif card_diff == 2:
            base_strength += 0.05
        elif card_diff <= 4:
            base_strength += 0.02
        
        return min(1.0, base_strength)

    def _get_postflop_strength(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._get_preflop_strength(hole_cards)
            
        best_hand_rank = 0
        for combo in combinations(all_cards, 5):
            hand_rank = self._evaluate_hand_rank(list(combo))
            if hand_rank > best_hand_rank:
                best_hand_rank = hand_rank
        
        return best_hand_rank / 9.0

    def _evaluate_hand_rank(self, five_cards):
        suits = [card[1] for card in five_cards]
        suit_counts = Counter(suits)
        is_flush = max(suit_counts.values()) >= 5
        
        ranks = [self.rank_map.get(card[0], 0) for card in five_cards]
        rank_counts = Counter(ranks)
        count_values = sorted(rank_counts.values(), reverse=True)
        
        unique_ranks = sorted(set(ranks))
        is_straight = False
        if unique_ranks == [2, 3, 4, 5, 14]:
            is_straight = True
        else:
            for i in range(1, len(unique_ranks)):
                if unique_ranks[i] != unique_ranks[i-1] + 1:
                    break
            else:
                is_straight = True
        
        if is_straight and is_flush:
            return 9
        if count_values[0] == 4:
            return 8
        if count_values[0] == 3 and count_values[1] == 2:
            return 7
        if is_flush:
            return 6
        if is_straight:
            return 5
        if count_values[0] == 3:
            return 4
        if count_values[0] == 2 and count_values[1] == 2:
            return 3
        if count_values[0] == 2:
            return 2
        return 1