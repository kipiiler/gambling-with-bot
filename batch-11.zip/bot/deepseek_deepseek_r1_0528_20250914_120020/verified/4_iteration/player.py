import random
from enum import Enum
from typing import List, Tuple, Dict, Any
import time

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

RANK_ORDER = "23456789TJQKA"
SUITS = "shdc"

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.precomputed_evals = {}
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.total_players = 0
        self.position = 0
        self.round_num = 0
        self.hand_strength = 0.0
        self.hand = None
        self.position_rank = 0
        self.memo = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = [str(p) for p in all_players]
        self.total_players = len(all_players)
        
        # Set starting hand
        self.hand = player_hands
        self.set_position_rank()

    def set_position_rank(self):
        """Assign position rank: late positions get higher numbers"""
        if self.id is None:
            return
            
        try:
            idx = self.all_players.index(str(self.id))
            self.position_rank = (self.total_players - idx - 1) * 100 // self.total_players
        except (ValueError, IndexError):
            self.position_rank = 50
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self.set_position_rank()
        if round_state.round == "Preflop":
            # Reset memo cache for new hand
            self.memo = {}
        
        # Compute hand strength if we have community cards
        if round_state.community_cards:
            self.hand_strength = self.calculate_hand_strength(
                self.hand, round_state.community_cards, 
                self.total_players - len(round_state.current_player) + 1,
                time.time(),  # Start time
                2.5  # Max seconds to compute
            )

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_id_str = str(self.id)
            my_bet = round_state.player_bets.get(my_id_str, 0)
            current_bet = round_state.current_bet
            to_call = max(0, current_bet - my_bet)
            min_raise = max(round_state.min_raise, 1)
            max_raise = min(round_state.max_raise, remaining_chips)
            
            in_sb = self.id == self.small_blind_player_id
            in_bb = self.id == self.big_blind_player_id
            heads_up = self.total_players == 2
            
            ev_factor = self.position_rank
            
            # Preflop strategy
            if round_state.round == "Preflop":
                return self.preflop_strategy(
                    to_call, min_raise, max_raise, 
                    remaining_chips, in_sb, in_bb, heads_up,
                    ev_factor
                )
                
            # Postflop strategy
            pot = round_state.pot
            pot_odds = to_call / (pot + to_call + 1e-8)
            
            if round_state.round in ["Flop", "Turn", "River"]:
                return self.postflop_strategy(
                    self.hand_strength, to_call, min_raise, max_raise,
                    pot_odds, pot, remaining_chips, ev_factor
                )
                
            # Default: check if possible, otherwise fold
            if to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0
            
        except Exception as e:
            # Safety: fold on any error
            return PokerAction.FOLD, 0

    def preflop_strategy(self, to_call, min_raise, max_raise, remaining_chips, in_sb, in_bb, heads_up, ev_factor):
        # Calculate hand value (value between 1-14)
        card1_val = RANK_ORDER.index(self.hand[0][0])
        card2_val = RANK_ORDER.index(self.hand[1][0])
        hole_value = max(card1_val, card2_val) * 2 + min(card1_val, card2_val)
        suited = self.hand[0][1] == self.hand[1][1]
        
        # Adjust value for suited cards
        hole_value += 3 if suited else 0
        
        # Generate hand key for memoization
        hand_key = (card1_val, card2_val, suited)
        
        # Get memoized hand strength if available
        if hand_key in self.memo:
            preflop_strength = self.memo[hand_key]
        else:
            preflop_strength = self.calculate_preflop_equity(self.hand)
            self.memo[hand_key] = preflop_strength
        
        # Raise conditions
        if to_call == 0:
            # First action opportunity
            if heads_up and in_sb:
                # Heads-up small blind actions
                if preflop_strength > 0.65:
                    raise_amt = min(3 * self.big_blind, max_raise)
                    return PokerAction.RAISE, min(raise_amt, max_raise)
                elif preflop_strength > 0.55:
                    return PokerAction.CALL, to_call
                else:
                    return PokerAction.FOLD, 0
                    
            # Non-heads-up or big blind
            if preflop_strength > 0.5 + ev_factor * 0.002:
                raise_amt = min(3 * self.big_blind, max_raise)
                return PokerAction.RAISE, min(raise_amt, max_raise)
            return PokerAction.CHECK, 0
            
        else:  # Facing a bet
            if preflop_strength > 0.58:
                return PokerAction.RAISE, min(2.5 * to_call, max_raise)
            pot_odds = to_call / (to_call + max(to_call * 4, 1))
            if preflop_strength > pot_odds:
                return PokerAction.CALL, to_call
            return PokerAction.FOLD, 0
            
        # Fold if no other action selected
        return PokerAction.FOLD, 0

    def postflop_strategy(self, hand_strength, to_call, min_raise, max_raise, pot_odds, pot, remaining_chips, ev_factor):
        # Classify hand strength
        if hand_strength > 0.85:
            # Very strong hand, force bets
            if to_call == 0:
                bet = min(pot // 2, max_raise)
                return PokerAction.RAISE, min(bet, max_raise)
            else:
                return PokerAction.RAISE, min(max_raise, min_raise * 2)

        elif hand_strength > 0.7:
            # Strong hand, seek value with moderate bets
            if to_call == 0:
                bet = min(pot // 3, max_raise)
                return PokerAction.RAISE, min(bet, max_raise)
            elif pot_odds < hand_strength:
                return PokerAction.CALL, to_call

        elif hand_strength > 0.5:
            # Moderate hand
            if to_call == 0:
                # Bluff sometimes in good positions
                if ev_factor > 50 and random.random() < 0.25:
                    bet = min(pot // 4, max_raise)
                    return PokerAction.RAISE, min(bet, max_raise)
                return PokerAction.CHECK, 0
            elif pot_odds < hand_strength:
                return PokerAction.CALL, to_call
            else:
                return PokerAction.FOLD, 0

        elif hand_strength > 0.3:
            # Weak hand, mainly play passively
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif pot_odds < 0.3:
                return PokerAction.CALL, to_call
            else:
                return PokerAction.FOLD, 0

        else:
            # Very weak hand
            if to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Default action
        if to_call > 0:
            return PokerAction.FOLD, 0
        return PokerAction.CHECK, 0
        
    def calculate_preflop_equity(self, hole_cards):
        """Estimate preflop equity against one random hand"""
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit1 = card2[0], card2[1]
        is_pair = rank1 == rank2
        is_suited = suit1 == suit1
        
        # Assign base value based on high card
        high_val = max(RANK_ORDER.index(rank1), RANK_ORDER.index(rank2))
        med_val = min(RANK_ORDER.index(rank1), RANK_ORDER.index(rank2))
        
        hand_val = high_val * 2
        
        # Bonus for pairs
        if is_pair:
            return min(0.95, 0.65 + hand_val * 0.015)
        
        # Bonus for suited
        if is_suited:
            hand_val += 8
                
        # Bonus for connectors
        if abs(high_val - med_val) == 1:
            hand_val += 4
            
        # Cap at 0.85 for non-monster hands
        return min(0.85, hand_val * 0.017)
        
    def calculate_hand_strength(self, hole_cards, community, player_count, start_time, max_time=1.0):
        """Monte Carlo simulation to estimate hand equity"""
        # Key for memoization
        key = (tuple(hole_cards), tuple(community))
        if key in self.memo:
            return self.memo[key]
            
        full_deck = self.generate_deck(hole_cards + community)
        n_sims = 500 if self.round_num == 0 else 100
        wins = 0
        
        our_best = self.get_best_hand(hole_cards + community)
        
        for _ in range(n_sims):
            if time.time() - start_time > max_time:
                break
                
            # Deal more cards if needed
            if len(community) < 5:
                # Quick exit if not enough time
                if time.time() - start_time > max_time:
                    break
                    
                future_com = random.sample(full_deck, 5 - len(community))
                all_com = community + future_com
            else:
                all_com = community
                
            # Generate opponent hands
            oppo_deck = [c for c in full_deck if c not in all_com]
            oppo_hands = random.sample(oppo_deck, 2 * (player_count - 1))
            
            # Check against opponents
            win_flag = True
            for i in range(0, len(oppo_hands), 2):
                opp_hand = oppo_hands[i:i+2]
                opp_best = self.get_best_hand(opp_hand + all_com)
                if self.compare_hands(our_best, opp_best) < 0:
                    win_flag = False
                    break
                    
            wins += 1 if win_flag else 0
            
        result = wins / n_sims if n_sims > 0 else 0.0
        self.memo[key] = result
        return result
        
    def generate_deck(self, exclude=[]):
        """Generate deck excluding known cards"""
        return [f"{r}{s}" for r in RANK_ORDER for s in SUITS 
                if f"{r}{s}" not in exclude]

    def get_best_hand(self, seven_cards):
        """Evaluate best 5-card hand from 7 cards"""
        cards = sorted(seven_cards, key=lambda card: RANK_ORDER.index(card[0]), reverse=True)
        return cards[:5]  # Simplified evaluation - real poker needs proper hand eval
        
    def compare_hands(self, hand1, hand2):
        """Simplified hand comparison - real implementation needed"""
        # For proper implementation, use a poker hand evaluator
        # This is a placeholder that only compares high cards
        for card1, card2 in zip(sorted(hand1, reverse=True), sorted(hand2, reverse=True)):
            r1 = RANK_ORDER.index(card1[0])
            r2 = RANK_ORDER.index(card2[0])
            if r1 != r2:
                return r1 - r2
        return 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hand strength at round end
        self.hand_strength = 0.0

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for new game
        self.hand = None
        self.starting_chips = 10000
        self.position_rank = 0
        self.memo = {}