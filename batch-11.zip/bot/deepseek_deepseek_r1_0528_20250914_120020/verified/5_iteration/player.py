import sys
import os
import random
from collections import defaultdict
from enum import Enum
from typing import Dict, List, Tuple, Optional, cast
import math

# Add the current directory to sys.path to fix bot module import
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound

class HandStrength(Enum):
    PREMIUM = 4
    STRONG = 3
    MEDIUM = 2
    WEAK = 1
    FOLD = 0

class Card:
    SUITS = ['c', 'd', 'h', 's']
    RANKS = '23456789TJQKA'

    def __init__(self, rank: str, suit: str) -> None:
        self.rank = rank
        self.suit = suit

    @classmethod
    def from_str(cls, s: str) -> 'Card':
        return cls(s[0], s[1])

    def __str__(self) -> str:
        return self.rank + self.suit
    
    def __repr__(self) -> str:
        return str(self)
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Card):
            return False
        return self.rank == other.rank and self.suit == other.suit
    
    def __hash__(self) -> int:
        return hash((self.rank, self.suit))
    
    def get_rank_value(self) -> int:
        return Card.RANKS.index(self.rank)

class HandEvaluator:
    RANKINGS = {
        "Straight Flush": 9,
        "Four of a Kind": 8,
        "Full House": 7,
        "Flush": 6,
        "Straight": 5,
        "Three of a Kind": 4,
        "Two Pair": 3,
        "One Pair": 2,
        "High Card": 1
    }

    @classmethod
    def evaluate_hand(cls, cards: List[Card]) -> int:
        """Evaluate the strength of a hand (list of cards) and return a numerical rank."""
        if len(cards) < 5:
            raise ValueError("At least 5 cards required for evaluation")

        best_rank = 0
        for combination in cls.generate_combinations(cards, 5):
            hand_type = cls.get_hand_type(combination)
            rank_value = cls.RANKINGS[hand_type] * 1000000
            hand_value = rank_value + cls.lexographical_value(combination)
            if hand_value > best_rank:
                best_rank = hand_value
        return best_rank

    @classmethod
    def get_hand_type(cls, hand: List[Card]) -> str:
        is_flush = cls.is_flush(hand)
        is_straight, high_card = cls.is_straight(hand)
        ranks = [card.rank for card in hand]
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        values = sorted([Card.RANKS.index(rank) for rank in set(ranks)], reverse=True)

        if is_straight and is_flush:
            return "Straight Flush"
        if max(rank_counts.values()) == 4:
            return "Four of a Kind"
        if sorted(rank_counts.values()) == [2, 3]:
            return "Full House"
        if is_flush:
            return "Flush"
        if is_straight:
            return "Straight"
        if max(rank_counts.values()) == 3:
            return "Three of a Kind"
        if list(rank_counts.values()).count(2) == 2:
            return "Two Pair"
        if max(rank_counts.values()) == 2:
            return "One Pair"
        return "High Card"

    @staticmethod
    def is_flush(hand: List[Card]) -> bool:
        suits = [card.suit for card in hand]
        return len(set(suits)) == 1

    @staticmethod
    def is_straight(hand: List[Card]) -> Tuple[bool, int]:
        rank_values = sorted(set(Card.RANKS.index(card.rank) for card in hand))
        if len(rank_values) < 5:
            return False, 0

        # Check for Ace-low straight (A,2,3,4,5)
        if (rank_values[0] == 0 and rank_values[-1] == 12 and 
            rank_values[1] == 1 and rank_values[2] == 2 and 
            rank_values[3] == 3):
            return True, 3  # Highest card is 5 (index 3)
        
        for i in range(len(rank_values)-4):
            if rank_values[i+4] - rank_values[i] == 4:
                return True, rank_values[i+4]
        return False, 0

    @staticmethod
    def lexographical_value(hand: List[Card]) -> int:
        rank_count = defaultdict(int)
        for card in hand:
            rank_count[card.rank] += 1
        ranks = sorted(hand, key=lambda card: (
            rank_count[card.rank],
            Card.RANKS.index(card.rank)
        ), reverse=True)
        total = 0
        for card in ranks:
            total = total * len(Card.RANKS) + Card.RANKS.index(card.rank)
        return total

    @staticmethod
    def generate_combinations(cards: List[Card], k: int) -> List[List[Card]]:
        if k == 0:
            return [[]]
        if not cards:
            return []
        head, tail = cards[0], cards[1:]
        without_head = HandEvaluator.generate_combinations(tail, k)
        with_head = HandEvaluator.generate_combinations(tail, k-1)
        return with_head + [combination + [head] for combination in without_head]

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[Card] = []
        self.community_cards: List[Card] = []
        self.hand_strength: float = 0.0
        self.preflop_evaluation: HandStrength = HandStrength.FOLD
        self.players_bets: Dict[str, int] = {}
        self.players_remaining_chips: Dict[str, int] = {}
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.blind_amount: int = 0
        self.starting_chips: int = 10000
        self.opponents = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players_remaining_chips = {str(player): starting_chips for player in all_players}
        self.players_bets = {}
        self.opponents = [str(p) for p in all_players if p != self.id]
        
        # Get our hole cards
        if self.id is not None:
            player_id_index = all_players.index(self.id) if self.id in all_players else -1
            if player_id_index >= 0:
                self.hole_cards = [Card(rank=h[0], suit=h[1]) for h in player_hands[player_id_index]]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        round_community = round_state.community_cards
        self.community_cards = [Card.from_str(card) for card in round_community]
        self.players_remaining_chips[str(self.id)] = remaining_chips
        self.hand_strength = self._evaluate_hand_strength(num_opponents=len(self.opponents), num_simulations=100 if round_state.round == "Preflop" else 50)
        self._update_preflop_strength()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not hasattr(self, 'id') or self.id is None:
            return (PokerAction.FOLD, 0)
        
        my_id = str(self.id)
        self.community_cards = [Card.from_str(card) for card in round_state.community_cards]
        self.players_remaining_chips[my_id] = remaining_chips
        player_bets = round_state.player_bets
        self.players_bets = player_bets

        current_round = round_state.round
        my_bet = player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        stack = remaining_chips
        opponents_in_hand = [p for p in self.opponents if p in round_state.current_player]
        num_opponents = len(opponents_in_hand)
        odds = to_call / (pot + to_call) if (pot + to_call) > 0 else 10.0  # Max when free
        
        if current_round == PokerRound.PREFLOP.value:
            return self._preflop_action(my_bet, to_call, min_raise, max_raise, stack, opponents_in_hand)
        
        # Decide based on equity and position
        call = False
        raise_action = False
        min_commit = 0.0
        
        if to_call > 0:
            equity = self._evaluate_hand_strength(num_opponents=num_opponents, num_simulations=200)
            min_commit = 0.7 - (0.1 * num_opponents)
            if equity >= odds or equity > min_commit:
                if (equity > 0.9 and stack > to_call + min_raise * 2 and
                        min_raise <= stack and equity < 0.99):  # Don't scare weak hands
                    return (PokerAction.RAISE, min(my_bet + to_call + min_raise, stack))
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            equity = self._evaluate_hand_strength(num_opponents=num_opponents, num_simulations=100)
            min_commit = 0.6 - (0.08 * num_opponents)
            if equity >= min_commit:
                amount = min_raise
                if amount < max_raise:
                    return (PokerAction.RAISE, min_raise)
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        my_id = str(self.id)
        self.players_remaining_chips[my_id] = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

    def _update_preflop_strength(self) -> None:
        ranks = [card.rank for card in self.hole_cards]
        suits = [card.suit for card in self.hole_cards]
        is_suited = suits[0] == suits[1]
        is_pair = ranks[0] == ranks[1]
        
        if is_pair:
            rank_val = '23456789TJQKA'.index(ranks[0])
            if rank_val >= 10:  # TT to AA
                self.preflop_evaluation = HandStrength.PREMIUM
            elif rank_val >= 6:  # 77 to 99
                self.preflop_evaluation = HandStrength.STRONG
            elif rank_val >= 2:  # 22 to 66
                self.preflop_evaluation = HandStrength.MEDIUM
            else:
                self.preflop_evaluation = HandStrength.WEAK
        else:
            high_val = max('23456789TJQKA'.index(ranks[0]), '23456789TJQKA'.index(ranks[1]))
            low_val = min('23456789TJQKA'.index(ranks[0]), '23456789TJQKA'.index(ranks[1]))
            gap = high_val - low_val
            if high_val > 10:  # A or K
                if is_suited and low_val >= 9 and gap == 1:  # AKs, KQs, etc.
                    self.preflop_evaluation = HandStrength.PREMIUM
                elif (is_suited and high_val - low_val <= 2 when high_val>=10) or (not is_suited and high_val==12 and low_val>=10):
                    self.preflop_evaluation = HandStrength.STRONG
                else:
                    self.preflop_evaluation = HandStrength.MEDIUM
            else:
                if is_suited and gap <= 1:
                    self.preflop_evaluation = HandStrength.MEDIUM
                else:
                    self.preflop_evaluation = HandStrength.WEAK

    def _preflop_action(self, my_bet: int, to_call: int, min_raise: int, max_raise: int, stack: int, opponents: List[str]) -> Tuple[PokerAction, int]:
        play_strength = self.preflop_evaluation
        
        # If we are big blind
        if self.id == self.big_blind_player_id and my_bet >= self.blind_amount and to_call == 0:
            # Free play: check any hand
            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

        elif to_call > 0:
            factors_map = {
                HandStrength.PREMIUM: 0.8,
                HandStrength.STRONG: 0.6,
                HandStrength.MEDIUM: 0.4,
                HandStrength.WEAK: 0.2
            }
            factor = factors_map.get(play_strength, 0.0)
            max_acceptable_call = factor * stack
            if to_call > max_acceptable_call:
                return (PokerAction.FOLD, 0)
            # Re-raise? 
            elite = play_strength in [HandStrength.PREMIUM, HandStrength.STRONG]
            if elite and stack > to_call + min_raise >= min_raise:
                return (PokerAction.RAISE, min_raise + to_call)
            return (PokerAction.CALL, 0)
        else:
            rnd = min_raise * random.randint(8, 12) // 5
            play = play_strength
            if play == HandStrength.PREMIUM:
                return (PokerAction.RAISE, min(rnd, max_raise))
            elif play == HandStrength.STRONG:
                return (PokerAction.RAISE, min(min_raise * 4, max_raise))
            elif play == HandStrength.MEDIUM:
                return (PokerAction.CHECK, 0) if my_bet == self.blind_amount or to_call==0 else (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _get_deck(self) -> List[Card]:
        """ All cards except hole and community. """
        deck = []
        for suit in Card.SUITS:
            for rank in Card.RANKS:
                card = Card(rank, suit)
                if card not in self.hole_cards + self.community_cards:
                    deck.append(card)
        return deck

    def _evaluate_hand_strength(self, num_opponents: int, num_simulations: int) -> float:
        if num_opponents == 0:
            return 1.0  # Winner by default

        wins = total = 0
        deck = self._get_deck()

        for _ in range(num_simulations):
            random.shuffle(deck)
            
            opp_hands = []
            remaining = num_opponents
            used = cast(list[Card], deck[2 * num_opponents:2 * num_opponents])
            community_to_draw = 5 - len(self.community_cards)
            sim_community = self.community_cards + [deck[i] for i in range(remaining, community_to_draw + remaining)]
            
            for i in range(num_opponents):
                hand = deck[2*i:2*i+2]
                opp_hands.append(hand)
            
            my_value = HandEvaluator.evaluate_hand(self.hole_cards + sim_community)
            
            win_flag = True
            for hand in opp_hands:
                opp_value = HandEvaluator.evaluate_hand(hand + sim_community)
                if opp_value > my_value:
                    win_flag = False
                    break
                elif opp_value == my_value:
                    win_flag = False  # Split, not a win
            
            wins += 1 if win_flag else 0
            total += 1

        if total <= 0:
            return 1.0 if len(self.community_cards) == 5 else 0.5
        return math.sqrt((wins/total) + (1/(1+len(deck))))