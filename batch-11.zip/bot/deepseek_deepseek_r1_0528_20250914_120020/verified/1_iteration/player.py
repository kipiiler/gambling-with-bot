from typing import List, Tuple, Dict, Any
from enum import Enum
from dataclasses import dataclass
from abc import ABC, abstractmethod
import collections
from itertools import combinations

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: List[Dict[str, Any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None
        
    def set_id(self, player_id: int) -> None:
        self.id = player_id

    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass

    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass

    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.bb = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.hand_strength = 0
        self.group = 5
        self.hand = []
        self.position = -1
        self.player_count = 0
        self.preflop_groups = {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs'],
            2: ['AKo', 'TT', '99', 'AQs', 'AJs', 'KQs'],
            3: ['88', '77', 'AQo', 'ATs', 'KJs', 'QJs', 'JTs'],
            4: ['66', '55', '44', '33', '22', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 
                'A4s', 'A3s', 'A2s', 'KQo', 'KTs', 'QTs']
        }
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        self.prev_action = PokerAction.CHECK
        self.aggressiveness = 1.0
        self.tightness = 1.0
        self.active_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.player_count = len(all_players)
        self.active_players = all_players.copy()
        self.bb = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        if round_state.pot > 0:
            self.bb = round_state.pot / 1.5
        self.hand = []
        self.group = 5
        self.prev_action = PokerAction.CHECK

        if self.id == self.big_blind_player_id:
            self.position = 2
        elif self.id == self.small_blind_player_id:
            self.position = 1
        else:
            self.position = 0

    def get_preflop_hand_group(self, cards):
        card1, card2 = cards
        r1, s1 = card1[0], card1[1]
        r2, s2 = card2[0], card2[1]
        pair = (r1 == r2)
        suited = (s1 == s2)
        key = ('s' if suited else 'o')
        hand_str = ''.join(sorted([r1, r2], key=lambda x: self.rank_map[x], reverse=True)) + key

        for group, hands in self.preflop_groups.items():
            if hand_str in hands:
                return group
        return 5

    def evaluate_5card_hand(self, card_strings):
        cards = []
        for card in card_strings:
            rank_char = card[0]
            suit = card[1].lower()
            cards.append((self.rank_map[rank_char], suit))

        cards.sort(key=lambda x: x[0], reverse=True)
        ranks = [card[0] for card in cards]
        unique_ranks = sorted(set(ranks), reverse=True)
        suits = [card[1] for card in cards]
        
        # Check flush
        flush = all(s == suits[0] for s in suits)
        
        # Check straight
        straight = False
        straight_high = 0
        window = sorted(ranks, reverse=True)
        if window[0] == 14 and window[1] == 5 and window[2] == 4 and window[3] == 3 and window[4] == 2:
            straight = True
            straight_high = 5
        else:
            straight_high = window[0]
            for i in range(len(window)-1):
                if window[i] - window[i+1] != 1:
                    straight_high = 0
                    break
            straight = (straight_high > 0)

        if flush and straight:
            return (8, straight_high)
        
        rank_counter = collections.Counter(ranks)
        counts = sorted([(count, rank) for rank, count in rank_counter.items()], key=lambda x: (x[0], x[1]), reverse=True)
        primary = counts[0][1]
        secondary = counts[1][1] if len(counts) > 1 else 0

        if counts[0][0] == 4:
            return (7, primary, max(set(ranks).difference({primary})))
        elif counts[0][0] == 3 and counts[1][0] == 2:
            return (6, primary, secondary)
        elif flush:
            return (5,) + tuple(sorted(ranks, reverse=True))
        elif straight:
            return (4, straight_high)
        elif counts[0][0] == 3:
            kickers = sorted(set(ranks).difference({primary}), reverse=True)[:2]
            return (3, primary) + tuple(kickers)
        elif counts[0][0] == 2:
            if counts[1][0] == 2:
                pair_ranks = [p for c, p in counts[:2]]
                kicker = next(r for r in sorted(unique_ranks, reverse=True) if r not in pair_ranks)
                return (2, max(pair_ranks), min(pair_ranks), kicker)
            else:
                kickers = sorted(set(ranks).difference({primary}), reverse=True)[:3]
                return (1, primary) + tuple(kickers)
        else:
            return (0,) + tuple(ranks)

    def evaluate_hand_strength(self, hole_cards, community_cards, remaining_opponents):
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.0
            
        best_hand = None
        for combo in combinations(all_cards, 5):
            value = self.evaluate_5card_hand(combo)
            if best_hand is None or value > best_hand:
                best_hand = value
                
        if len(community_cards) < 3:
            return 0.6 if best_hand[0] > 3 else 0.4
            
        strength = best_hand[0] * 10.0
        for i in range(1, len(best_hand)):
            strength += best_hand[i] / (10**i)
            
        return strength / 100.0

    def should_bluff(self, round_state, hand_strength):
        return (
            hand_strength < 0.6 and 
            len(round_state.community_cards) > 0 and 
            self.aggressiveness > 0.7 and 
            self.tightness < 0.5
        )

    def adjust_aggressiveness(self, remaining_chips):
        stack_ratio = remaining_chips / self.starting_chips
        if stack_ratio < 0.3:
            self.aggressiveness = 0.8
            self.tightness = 0.2
        elif stack_ratio > 1.5:
            self.aggressiveness = 0.9
            self.tightness = 0.1
        else:
            self.aggressiveness = 0.7
            self.tightness = 0.3

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.adjust_aggressiveness(remaining_chips)
        player_id_str = str(self.id)
        our_bet = round_state.player_bets.get(player_id_str, 0)
        cost_to_call = round_state.current_bet - our_bet
        min_raise = round_state.min_raise + round_state.current_bet - our_bet
        max_raise = min(round_state.max_raise, remaining_chips)
        pot_odds = cost_to_call / (cost_to_call + round_state.pot + 0.001)

        if round_state.round == "Preflop" and len(self.hand) < 2:
            self.hand = round_state.community_cards[:2]
            if self.hand and len(self.hand) == 2:
                self.group = self.get_preflop_hand_group(self.hand)

        hand_strength = 0.0
        if round_state.round != "Preflop" and self.hand:
            hand_strength = self.evaluate_hand_strength(
                self.hand, 
                round_state.community_cards, 
                len(round_state.current_player) - 1
            )

        if round_state.round == "Preflop":
            return self.preflop_action(round_state, cost_to_call, min_raise, max_raise, our_bet, remaining_chips)
        else:
            return self.postflop_action(round_state, cost_to_call, min_raise, max_raise, hand_strength, pot_odds, remaining_chips)

    def preflop_action(self, round_state, cost_to_call, min_raise, max_raise, our_bet, remaining_chips):
        group = self.group
        if cost_to_call > (5 * self.bb):
            if group <= 1 and self.prev_action != PokerAction.RAISE:
                return (PokerAction.RAISE, min_raise)
            if group <= 1:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        elif cost_to_call > 0:
            if group <= 3 or (group == 4 and cost_to_call <= self.bb):
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            if group <= 4:
                if group <= 2:
                    return (PokerAction.RAISE, min_raise)
                else:
                    return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def postflop_action(self, round_state, cost_to_call, min_raise, max_raise, hand_strength, pot_odds, remaining_chips):
        weighted_strength = hand_strength * self.aggressiveness
        if self.should_bluff(round_state, hand_strength):
            weighted_strength = 0.65
            
        if cost_to_call > 0:
            effective_odds = min(1.5, pot_odds)
            if weighted_strength > effective_odds + 0.2 and min_raise <= max_raise:
                if min_raise < remaining_chips * 0.3:
                    return (PokerAction.RAISE, min_raise)
                return (PokerAction.CALL, 0)
            elif weighted_strength > effective_odds:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            if weighted_strength > 0.6:
                raise_size = min(int(round_state.pot * 0.6), max_raise)
                return (PokerAction.RAISE, raise_size)
            elif weighted_strength > 0.4:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass