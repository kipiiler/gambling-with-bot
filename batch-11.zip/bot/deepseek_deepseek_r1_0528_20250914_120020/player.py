from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

# Card rank to numeric value mapping
rank_to_value = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, 
    '7': 7, '8': 8, '9': 9, 'T': 10, 
    'J': 11, 'Q': 12, 'K': 13, 'A': 14
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.position = -1
        self.pre_flop_group = 0
        self.hand_strength = 0.0
        self.min_raise = 0
        self.max_raise = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Calculate position relative to button
        if self.id in all_players:
            idx = all_players.index(self.id)
            self.position = (idx - all_players.index(small_blind_player_id)) % len(all_players)
        
        # Classify pre-flop hand
        self._classify_pre_flop_hand()

    def _classify_pre_flop_hand(self):
        if len(self.hole_cards) != 2:
            self.pre_flop_group = 6
            return

        card1, card2 = self.hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        val1, val2 = rank_to_value[rank1], rank_to_value[rank2]
        suited = suit1 == suit2
        high_val, low_val = max(val1, val2), min(val1, val2)
        
        # Pair
        if rank1 == rank2:
            hand_str = rank1 + rank2
            groups = {
                'AA': 1, 'KK': 1, 'QQ': 1, 'JJ': 1,
                'TT': 2, '99': 3, '88': 4, '77': 5, '66': 6,
                '55': 7, '44': 8, '33': 8, '22': 8
            }
            self.pre_flop_group = groups.get(hand_str, 8)
            return
        
        # Non-pair hands
        hand_str = rank1 + rank2 + ('s' if suited else 'o')
        hand_str_alt = rank2 + rank1 + ('s' if suited else 'o')
        
        # Group 1: Premium hands
        group1 = ['AKs', 'AKo']
        # Group 2: Strong hands
        group2 = ['AQs', 'AJs', 'KQs', 'AKo', 'AQo']
        # Group 3: Playable hands
        group3 = ['ATs', 'KJs', 'QJs', 'JTs', 'AJo', 'KQo']
        # Group 4: Marginal hands
        group4 = ['A9s', 'KTs', 'QTs', 'J9s', 'T9s', 'A9o', 'KJo', 'QJo']
        # Group 5: Speculative hands
        group5 = ['A8s', 'K9s', 'Q9s', 'J8s', 'T8s', '98s', 'A8o', 'KTo', 'QTo']
        
        if hand_str in group1 or hand_str_alt in group1:
            self.pre_flop_group = 1
        elif hand_str in group2 or hand_str_alt in group2:
            self.pre_flop_group = 2
        elif hand_str in group3 or hand_str_alt in group3:
            self.pre_flop_group = 3
        elif hand_str in group4 or hand_str_alt in group4:
            self.pre_flop_group = 4
        elif hand_str in group5 or hand_str_alt in group5:
            self.pre_flop_group = 5
        else:
            self.pre_flop_group = 6

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round state
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        
        # Evaluate hand strength if community cards exist
        if round_state.community_cards:
            self.hand_strength = self._evaluate_hand_strength(
                self.hole_cards, 
                round_state.community_cards
            )

    def _evaluate_five_cards(self, cards):
        values = [rank_to_value[card[0]] for card in cards]
        suits = [card[1] for card in cards]
        values.sort(reverse=True)
        value_counts = {val: values.count(val) for val in set(values)}
        sorted_counts = sorted(value_counts.items(), key=lambda x: (-x[1], -x[0]))
        is_flush = len(set(suits)) == 1
        is_straight = self._is_straight(values)
        
        # Straight flush
        if is_flush and is_straight:
            return (8, values[0])
        
        # Four of a kind
        if sorted_counts[0][1] == 4:
            return (7, sorted_counts[0][0], sorted_counts[1][0])
        
        # Full house
        if sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
            return (6, sorted_counts[0][0], sorted_counts[1][0])
        
        # Flush
        if is_flush:
            return (5, values)
        
        # Straight
        if is_straight:
            return (4, values[0])
        
        # Three of a kind
        if sorted_counts[0][1] == 3:
            kickers = [val for val in values if val != sorted_counts[0][0]]
            return (3, sorted_counts[0][0], kickers)
        
        # Two pair
        if sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
            pairs = [sorted_counts[0][0], sorted_counts[1][0]]
            kicker = sorted_counts[2][0]
            return (2, max(pairs), min(pairs), kicker)
        
        # One pair
        if sorted_counts[0][1] == 2:
            pair_val = sorted_counts[0][0]
            kickers = [val for val in values if val != pair_val]
            return (1, pair_val, kickers)
        
        # High card
        return (0, values)

    def _is_straight(self, values):
        # Handle Ace-low straight
        if 14 in values:
            low_values = values.copy()
            low_values.remove(14)
            low_values.append(1)
            low_values.sort(reverse=True)
            if self._is_consecutive(low_values):
                return True
        
        return self._is_consecutive(values)

    def _is_consecutive(self, values):
        return all(values[i] - values[i+1] == 1 for i in range(len(values)-1))

    def _evaluate_hand_strength(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.0
        
        best_rank = (0, [])
        for combo in itertools.combinations(all_cards, 5):
            rank_val = self._evaluate_five_cards(list(combo))
            if rank_val > best_rank:
                best_rank = rank_val
        
        # Normalize strength (0-1)
        hand_rank = best_rank[0]
        base_strength = hand_rank / 8.0
        
        # Adjust strength based on high cards
        if hand_rank in [0, 1, 5]:  # High card, pair, flush
            high_card = max(rank_to_value[card[0]] for card in hole_cards)
            base_strength += high_card / 140.0
        
        return min(max(base_strength, 0.0), 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        player_id_str = str(self.id)
        my_bet = round_state.player_bets.get(player_id_str, 0)
        to_call = round_state.current_bet - my_bet
        pot_odds = to_call / (round_state.pot + to_call + 1e-8)
        is_preflop = round_state.round == 'Preflop'
        in_position = self.position > len(round_state.current_player) / 2
        
        # Handle all-in situations
        if to_call >= remaining_chips and to_call > 0:
            return (PokerAction.ALL_IN, 0)
        
        # Pre-flop strategy
        if is_preflop:
            return self._pre_flop_action(to_call, remaining_chips, in_position)
        
        # Post-flop strategy
        return self._post_flop_action(to_call, pot_odds, remaining_chips, in_position)

    def _pre_flop_action(self, to_call, remaining_chips, in_position):
        # Big blind special case
        is_big_blind = self.id == self.big_blind_player_id
        can_check = is_big_blind and to_call == 0
        
        # Premium hands
        if self.pre_flop_group <= 2:
            if to_call == 0:
                raise_amount = min(3 * self.blind_amount, self.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif to_call <= 3 * self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif self.pre_flop_group <= 4:
            if to_call == 0:
                if in_position:
                    return (PokerAction.RAISE, min(2 * self.blind_amount, self.max_raise))
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if can_check:
                return (PokerAction.CHECK, 0)
            elif to_call == 0 and in_position:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _post_flop_action(self, to_call, pot_odds, remaining_chips, in_position):
        # Strong hands (top 20%)
        if self.hand_strength >= 0.8:
            if to_call > 0:
                if pot_odds < 0.2:
                    return (PokerAction.RAISE, min(self.max_raise, max(self.min_raise, 3 * to_call)))
                return (PokerAction.CALL, 0)
            else:
                bet_size = min(int(0.6 * remaining_chips), self.max_raise)
                return (PokerAction.RAISE, max(self.min_raise, bet_size))
        
        # Good hands (top 20-40%)
        elif self.hand_strength >= 0.6:
            if to_call > 0:
                if pot_odds < 0.15:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                if in_position:
                    bet_size = min(int(0.3 * remaining_chips), self.max_raise)
                    return (PokerAction.RAISE, max(self.min_raise, bet_size))
                return (PokerAction.CHECK, 0)
        
        # Marginal hands (top 40-60%)
        elif self.hand_strength >= 0.4:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0 and in_position:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hand-specific state
        self.hole_cards = []
        self.pre_flop_group = 0
        self.hand_strength = 0.0

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: Implement learning from game results
        pass