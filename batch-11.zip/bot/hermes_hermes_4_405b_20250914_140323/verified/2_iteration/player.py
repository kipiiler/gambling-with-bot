from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.remaining_chips = 0
        self.pot = 0
        self.community_cards = []
        self.player_bets = {}
        self.current_bet = 0
        self.min_raise = 0
        self.max_raise = 0
        self.round = ""
        self.hand_strength = 0
        self.position = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.remaining_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players
        self.position = all_players.index(self.id) if self.id in all_players else 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.pot = round_state.pot
        self.community_cards = round_state.community_cards
        self.player_bets = round_state.player_bets
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.round = round_state.round
        self.hand_strength = self.evaluate_hand_strength()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        self.pot = round_state.pot
        self.community_cards = round_state.community_cards
        self.player_bets = round_state.player_bets
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.round = round_state.round
        
        amount_to_call = self.current_bet - self.player_bets.get(str(self.id), 0)
        
        if self.round == 'Preflop':
            return self.handle_preflop(amount_to_call)
        else:
            return self.handle_postflop(amount_to_call)

    def handle_preflop(self, amount_to_call: int) -> Tuple[PokerAction, int]:
        card1, card2 = self.hole_cards
        rank1 = card1[0]
        rank2 = card2[0]
        suit1 = card1[1]
        suit2 = card2[1]
        
        # Pocket pairs
        if rank1 == rank2:
            return self.bet_or_raise(amount_to_call, self.min_raise)
        
        # High card combos
        high_cards = ['A', 'K', 'Q', 'J']
        if (rank1 in high_cards and rank2 in high_cards) or (rank1 == 'A' and rank2 == 'K'):
            return self.bet_or_raise(amount_to_call, self.min_raise * 2)
        
        # Suited connectors
        if suit1 == suit2 and abs(self.rank_to_value(rank1) - self.rank_to_value(rank2)) == 1:
            if amount_to_call < self.remaining_chips * 0.1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        # Default action
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif amount_to_call < self.remaining_chips * 0.05:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def handle_postflop(self, amount_to_call: int) -> Tuple[PokerAction, int]:
        self.hand_strength = self.evaluate_hand_strength()
        
        if self.hand_strength >= 0.7:  # Strong made hand
            return self.bet_or_raise(amount_to_call, self.pot // 2)
        elif self.hand_strength >= 0.4:  # Decent hand
            if amount_to_call < self.pot * 0.1:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:  # Weak hand
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def bet_or_raise(self, amount_to_call: int, bet_amount: int) -> Tuple[PokerAction, int]:
        if amount_to_call > 0:
            if bet_amount < self.min_raise:
                bet_amount = self.min_raise
            total_bet = amount_to_call + bet_amount
            if total_bet > self.remaining_chips:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.RAISE, total_bet
        else:
            if bet_amount < self.min_raise:
                bet_amount = self.min_raise
            if bet_amount > self.remaining_chips:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.RAISE, bet_amount

    def rank_to_value(self, rank: str) -> int:
        return {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, 
            '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 
            'Q': 12, 'K': 13, 'A': 14
        }.get(rank, 0)

    def evaluate_hand_strength(self) -> float:
        all_cards = self.hole_cards + self.community_cards
        ranks = [self.rank_to_value(card[0]) for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Check for pairs
        unique_ranks = set(ranks)
        if len(unique_ranks) < len(ranks):
            return 0.5
        
        # Check for flush potential
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}
        if max(suit_counts.values()) >= 3:
            return 0.4
        
        # Check for straight potential
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                return 0.35
                
        return 0.0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass