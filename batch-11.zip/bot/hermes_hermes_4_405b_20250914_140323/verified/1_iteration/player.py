from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.player_id = None
        self.strong_hands = {
            'AA', 'KK', 'QQ', 'JJ', 'TT', '99', '88', '77',
            'AKs', 'AQs', 'AJs', 'ATs', 'KQs', 'KJs', 'QJs', 'JTs', 'T9s', '98s', '87s',
            'AK', 'AQ', 'AJ', 'AT', 'KQ'
        }

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.blind_amount = blind_amount
        try:
            idx = all_players.index(self.player_id)
            self.hole_cards = player_hands[idx]
        except (ValueError, IndexError):
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        if hasattr(round_state, 'hole_cards'):
            self.hole_cards = round_state.hole_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            hole_cards = self.hole_cards
            if not hole_cards or len(hole_cards) != 2:
                return (PokerAction.FOLD, 0)
        except:
            return (PokerAction.FOLD, 0)

        current_bet = round_state.current_bet
        player_bets = round_state.player_bets
        our_bet = player_bets.get(str(self.player_id), 0)
        amount_to_call = current_bet - our_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards

        if round_state.round == 'Preflop':
            return self.handle_preflop(hole_cards, amount_to_call, min_raise, max_raise, pot)
        else:
            return self.handle_postflop(hole_cards, community_cards, amount_to_call, min_raise, max_raise, pot)

    def handle_preflop(self, hole_cards, amount_to_call, min_raise, max_raise, pot):
        hand_str = self.get_hand_string(hole_cards)
        if hand_str in self.strong_hands:
            if amount_to_call == 0:
                raise_amount = max(min_raise, min(3 * self.blind_amount, max_raise))
                return (PokerAction.RAISE, raise_amount)
            else:
                if hand_str in ['AA', 'KK', 'QQ', 'AKs', 'AK']:
                    if amount_to_call <= 200:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call <= pot / 2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.FOLD, 0)

    def handle_postflop(self, hole_cards, community_cards, amount_to_call, min_raise, max_raise, pot):
        all_cards = hole_cards + community_cards
        made_hand, hand_score = self.evaluate_hand(all_cards)
        flush_draw = self.has_flush_draw(all_cards)

        if amount_to_call == 0:
            if made_hand:
                bet_amount = min(max_raise, pot // 2)
                return (PokerAction.RAISE, bet_amount)
            else:
                return (PokerAction.CHECK, 0)
        else:
            if made_hand:
                if hand_score >= 2:
                    return (PokerAction.CALL, 0)
                else:
                    if amount_to_call <= pot / 2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif flush_draw:
                if amount_to_call <= pot / 4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

    def get_hand_string(self, hole_cards):
        ranks = sorted([self.card_rank(card) for card in hole_cards], reverse=True)
        suits = [card[1] for card in hole_cards]
        suited = 's' if len(set(suits)) == 1 else ''
        rank_names = {10: 'T', 11: 'J', 12: 'Q', 13: 'K', 14: 'A'}
        rank_str = ''.join(rank_names.get(r, str(r)) for r in ranks)
        return rank_str + suited

    def card_rank(self, card):
        rank = card[0]
        if rank == 'T':
            return 10
        elif rank == 'J':
            return 11
        elif rank == 'Q':
            return 12
        elif rank == 'K':
            return 13
        elif rank == 'A':
            return 14
        else:
            return int(rank)

    def evaluate_hand(self, cards):
        if len(cards) < 5:
            return False, 0
        
        ranks = [self.card_rank(card) for card in cards]
        count = Counter(ranks)
        values = sorted(count.values(), reverse=True)
        
        if values[0] == 4:
            return True, 7
        elif values[0] == 3 and values[1] == 2:
            return True, 6
        elif values[0] == 3:
            return True, 3
        elif values[0] == 2 and values[1] == 2:
            return True, 2
        elif values[0] == 2:
            return True, 1
        else:
            return False, 0

    def has_flush_draw(self, cards):
        suits = [card[1] for card in cards]
        suit_count = Counter(suits)
        return max(suit_count.values()) >= 4

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass