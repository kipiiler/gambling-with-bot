import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.small_blind = 0
        self.big_blind = 0
        self.hand_strength = 0.0
        self.ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suits = {'s': 1, 'h': 2, 'd': 3, 'c': 4}
        self.strong_preflop_hands = {'AA', 'KK', 'QQ', 'JJ', 'TT', 'AKs', 'AQs', 'AJs', 'KQs', 'AK'}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.small_blind = blind_amount
        self.big_blind = 2 * blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.hand_strength = self._preflop_hand_strength()
        else:
            self.hand_strength = self._calculate_hand_strength(round_state.community_cards)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = max(0, round_state.current_bet - our_bet)
            
            if round_state.round == 'Preflop':
                return self._preflop_action(amount_to_call, round_state.min_raise, round_state.max_raise)
            else:
                return self._postflop_action(amount_to_call, round_state.min_raise, round_state.max_raise, round_state.pot)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _preflop_hand_strength(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.0
        
        card1, card2 = self.hole_cards
        rank1 = self.ranks[card1[0]]
        rank2 = self.ranks[card2[0]]
        suit1 = card1[1]
        suit2 = card2[1]
        
        if rank1 < rank2:
            rank1, rank2 = rank2, rank1
            suit1, suit2 = suit2, suit1
        
        if rank1 == rank2:
            hand_rep = f"{card1[0]}{card2[0]}"
        else:
            hand_rep = f"{card1[0]}{card2[0]}{'s' if suit1 == suit2 else 'o'}"
        
        return 1.0 if hand_rep in self.strong_preflop_hands else 0.0

    def _calculate_hand_strength(self, community_cards: List[str]) -> float:
        hole_cards = self.hole_cards
        all_cards = hole_cards + community_cards
        remaining_cards = self._get_remaining_cards(hole_cards, community_cards)
        wins = 0
        ties = 0
        total = 0
        
        if not remaining_cards:
            return 0.0
        
        for opp_hand in itertools.combinations(remaining_cards, 2):
            our_best = self._best_hand(hole_cards, community_cards)
            opp_best = self._best_hand(list(opp_hand), community_cards)
            if our_best > opp_best:
                wins += 1
            elif our_best == opp_best:
                ties += 1
            total += 1
        
        return (wins + ties / 2) / total if total > 0 else 0.0

    def _get_remaining_cards(self, hole_cards: List[str], community_cards: List[str]) -> List[str]:
        deck = [rank + suit for suit in ['s', 'h', 'd', 'c'] for rank in ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']]
        used_cards = set(hole_cards + community_cards)
        return [card for card in deck if card not in used_cards]

    def _best_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        cards = hole_cards + community_cards
        if len(cards) < 5:
            return (0, [])
        
        best = (0, [])
        for combo in itertools.combinations(cards, 5):
            rank = self._evaluate_combo(combo)
            if rank > best[0]:
                best = (rank, self._get_tie_breaker(combo, rank))
            elif rank == best[0]:
                tie_breaker = self._get_tie_breaker(combo, rank)
                if self._compare_tie_breaker(tie_breaker, best[1]) > 0:
                    best = (rank, tie_breaker)
        return best

    def _evaluate_combo(self, combo: Tuple[str]) -> int:
        ranks = sorted([self.ranks[card[0]] for card in combo], reverse=True)
        suits = [card[1] for card in combo]
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        
        flush = len(set(suits)) == 1
        straight = (max(ranks) - min(ranks) == 4 and len(set(ranks)) == 5) or (set(ranks) == {14, 2, 3, 4, 5})
        
        if flush and straight:
            if ranks[0] == 14 and ranks[-1] == 10:
                return 10
            return 9
        if 4 in rank_counts.values():
            return 8
        if 3 in rank_counts.values() and 2 in rank_counts.values():
            return 7
        if flush:
            return 6
        if straight:
            return 5
        if 3 in rank_counts.values():
            return 4
        pair_count = list(rank_counts.values()).count(2)
        if pair_count == 2:
            return 3
        if pair_count == 1:
            return 2
        return 1

    def _get_tie_breaker(self, combo: Tuple[str], rank: int) -> List[int]:
        ranks = sorted([self.ranks[card[0]] for card in combo], reverse=True)
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        
        if rank == 10:  # Royal flush
            return [14, 13, 12, 11, 10]
        if rank == 9:   # Straight flush
            if max(ranks) == 14 and min(ranks) == 2:
                return [5, 4, 3, 2, 14]
            return ranks
        if rank == 8:   # Four of a kind
            quads = [r for r in ranks if ranks.count(r) == 4][0]
            kicker = [r for r in ranks if r != quads][0]
            return [quads, quads, quads, quads, kicker]
        if rank == 7:   # Full house
            trips = [r for r in ranks if ranks.count(r) == 3][0]
            pair = [r for r in ranks if ranks.count(r) == 2][0]
            return [trips, trips, trips, pair, pair]
        if rank == 6:   # Flush
            return ranks
        if rank == 5:   # Straight
            if max(ranks) == 14 and min(ranks) == 2:
                return [5, 4, 3, 2, 14]
            return ranks
        if rank == 4:   # Three of a kind
            trips = [r for r in ranks if ranks.count(r) == 3][0]
            kickers = sorted([r for r in ranks if r != trips], reverse=True)[:2]
            return [trips, trips, trips] + kickers
        if rank == 3:   # Two pair
            pairs = sorted([r for r in ranks if ranks.count(r) == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return [pairs[0], pairs[0], pairs[1], pairs[1], kicker]
        if rank == 2:   # One pair
            pair = [r for r in ranks if ranks.count(r) == 2][0]
            kickers = sorted([r for r in ranks if r != pair], reverse=True)[:3]
            return [pair, pair] + kickers
        return ranks  # High card

    def _compare_tie_breaker(self, tb1: List[int], tb2: List[int]) -> int:
        for i in range(min(len(tb1), len(tb2))):
            if tb1[i] > tb2[i]:
                return 1
            elif tb1[i] < tb2[i]:
                return -1
        return 0

    def _preflop_action(self, amount_to_call: int, min_raise: int, max_raise: int) -> Tuple[PokerAction, int]:
        if self.hand_strength < 0.5:
            return (PokerAction.FOLD, 0)
        
        if amount_to_call == 0:
            raise_amount = max(min_raise, min(3 * self.big_blind, max_raise))
            return (PokerAction.RAISE, raise_amount)
        else:
            if self.hand_strength == 1.0:
                return (PokerAction.ALL_IN, 0)
            raise_amount = max(min_raise, min(3 * self.big_blind, max_raise))
            return (PokerAction.RAISE, raise_amount)

    def _postflop_action(self, amount_to_call: int, min_raise: int, max_raise: int, pot: int) -> Tuple[PokerAction, int]:
        if amount_to_call == 0:
            if self.hand_strength >= 0.7:
                bet_amount = min(max(min_raise, (2 * pot) // 3), max_raise)
                return (PokerAction.RAISE, bet_amount)
            return (PokerAction.CHECK, 0)
        else:
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-5)
            if self.hand_strength >= 0.5 or self.hand_strength >= pot_odds:
                if self.hand_strength >= 0.8:
                    if max_raise >= amount_to_call + min_raise:
                        return (PokerAction.RAISE, amount_to_call + min_raise)
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)