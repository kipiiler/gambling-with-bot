from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 0
        self.rank_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, ...]:
        parsed = [(self.rank_values[c[0]], c[1]) for c in cards]
        parsed.sort(key=lambda x: x[0], reverse=True)
        ranks = [p[0] for p in parsed]
        suits = [p[1] for p in parsed]
        suit_count = {s: suits.count(s) for s in set(suits)}
        is_flush = max(suit_count.values()) >= 5
        unique_ranks = sorted(set(ranks), reverse=True)
        straight = False
        high_straight = 0
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight = True
                high_straight = unique_ranks[i]
                break
        if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
            straight = True
            high_straight = 5
        rank_count = {r: ranks.count(r) for r in set(ranks)}
        quads = [r for r, c in rank_count.items() if c == 4]
        trips = [r for r, c in rank_count.items() if c == 3]
        pairs = [r for r, c in rank_count.items() if c == 2]
        if is_flush:
            flush_suit = max(suit_count, key=suit_count.get)
            flush_ranks = sorted([r for r, s in parsed if s == flush_suit], reverse=True)
            if len(flush_ranks) >= 5:
                unique_flush = sorted(set(flush_ranks), reverse=True)
                for i in range(len(unique_flush) - 4):
                    if unique_flush[i] - unique_flush[i+4] == 4:
                        return (8, unique_flush[i])
                if 14 in flush_ranks and 2 in flush_ranks and 3 in flush_ranks and 4 in flush_ranks and 5 in flush_ranks:
                    return (8, 5)
        if quads:
            quad = max(quads)
            kicker = max([r for r in unique_ranks if r != quad])
            return (7, quad, kicker)
        if trips and pairs:
            trip = max(trips)
            pair = max(pairs)
            return (6, trip, pair)
        if is_flush:
            flush_high = tuple(sorted([r for r, s in parsed if s == flush_suit], reverse=True)[:5])
            return (5,) + flush_high
        if straight:
            return (4, high_straight)
        if trips:
            trip = max(trips)
            kickers = tuple(sorted([r for r in unique_ranks if r != trip], reverse=True)[:2])
            return (3, trip) + kickers
        if len(pairs) >= 2:
            pairs_sorted = sorted(pairs, reverse=True)[:2]
            kicker = max([r for r in unique_ranks if r not in pairs_sorted])
            return (2, pairs_sorted[0], pairs_sorted[1], kicker)
        if pairs:
            pair = max(pairs)
            kickers = tuple(sorted([r for r in unique_ranks if r != pair], reverse=True)[:3])
            return (1, pair) + kickers
        high_cards = tuple(sorted(unique_ranks, reverse=True)[:5])
        return (0,) + high_cards

    def is_good_preflop(self, hole: List[str]) -> bool:
        if len(hole) != 2:
            return False
        r1, s1 = hole[0][0], hole[0][1]
        r2, s2 = hole[1][0], hole[1][1]
        v1 = self.rank_values[r1]
        v2 = self.rank_values[r2]
        suited = s1 == s2
        if v1 < v2:
            v1, v2 = v2, v1
        if v1 == v2:
            return True
        if suited:
            if v1 == 14:
                return True
            if v1 == 13 and v2 >= 4:
                return True
            if v1 == 12 and v2 >= 8:
                return True
            if v1 == 11 and v2 >= 8:
                return True
            if v1 == 10 and v2 >= 7:
                return True
            if v1 == 9 and v2 >= 6:
                return True
            if v1 == 8 and v2 >= 5:
                return True
            if v1 == 7 and v2 >= 4:
                return True
            if v1 == 6 and v2 == 5:
                return True
            return False
        else:
            if v1 == 14 and v2 >= 10:
                return True
            if v1 == 13 and v2 >= 12:
                return True
            if v1 == 12 and v2 >= 11:
                return True
            return False

    def is_strong_hand(self, round_name: str, hole: List[str], community: List[str]) -> bool:
        if round_name == 'Preflop':
            return self.is_good_preflop(hole)
        else:
            hand = self.evaluate_hand(hole + community)
            category = hand[0]
            if category >= 4:
                return True
            board_ranks = [self.rank_values[c[0]] for c in community]
            max_board = max(board_ranks) if board_ranks else 0
            if category == 3 or category == 2:
                return True
            if category == 1:
                pair_rank = hand[1]
                if pair_rank > max_board:
                    return True
            return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        amount_to_call = round_state.current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        strong = self.is_strong_hand(round_state.round, self.hole_cards, round_state.community_cards)

        if amount_to_call > remaining_chips:
            if strong:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
        # No separate case for ==, since CALL would all-in

        if strong:
            if amount_to_call == 0:
                intended_raise_by = 3 * self.big_blind
            else:
                intended_raise_by = 3 * amount_to_call
            if intended_raise_by >= min_raise and intended_raise_by <= max_raise:
                return (PokerAction.RAISE, intended_raise_by)
            elif intended_raise_by > max_raise and min_raise <= max_raise:
                return (PokerAction.RAISE, max_raise)
            else:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CALL, 0)
        else:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass