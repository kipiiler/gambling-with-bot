from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.hole_cards = None
        self.is_heads_up = False
        self.small_blind = 0
        self.big_blind = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.is_heads_up = len(all_players) == 2
        self.small_blind = blind_amount
        self.big_blind = 2 * blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        if to_call >= remaining_chips:
            if self.has_good_hand(round_state):
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        if to_call > 0:
            if self.has_very_good_hand(round_state):
                raise_amount = max(to_call * 2, round_state.min_raise)
                raise_amount = min(raise_amount, remaining_chips)
                if raise_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif self.has_good_hand(round_state) and (to_call <= 4 * self.big_blind or to_call <= (round_state.pot + 0.001) * 0.3):
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if self.has_good_hand(round_state):
                pot = round_state.pot
                raise_amount = 3 * self.big_blind if round_state.round == 'Preflop' else int(pot / (2 + 1e-6))
                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, remaining_chips)
                if raise_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0

    def preflop_strength(self, hole: List[str]) -> int:
        r1 = self.rank_map[hole[0][0]]
        r2 = self.rank_map[hole[1][0]]
        high, low = max(r1, r2), min(r1, r2)
        suited = hole[0][1] == hole[1][1]
        pair = high == low
        score = high + low
        if pair:
            score += 20 + high
        if suited:
            score += 8
        if high - low <= 3 and not pair:
            score += 5
        if high >= 11:
            score += 5
        if low >= 9:
            score += 3
        return score

    def evaluate_5cards(self, cards: List[Tuple[int, str]]) -> tuple:
        ranks = sorted([r for r, s in cards], reverse=True)
        suits = [s for r, s in cards]
        suit_count = Counter(suits)
        is_flush = max(suit_count.values()) == 5
        is_straight = False
        straight_high = 0
        if all(ranks[i] - ranks[i + 1] == 1 for i in range(4)):
            is_straight = True
            straight_high = ranks[0]
        elif ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            straight_high = 5
        rank_count = Counter(ranks)
        count_list = sorted(rank_count.values(), reverse=True)
        if is_straight and is_flush:
            if straight_high == 14:
                return (10, straight_high)
            return (9, straight_high)
        if count_list == [4, 1]:
            quad = max(r for r, c in rank_count.items() if c == 4)
            kicker = [r for r in ranks if r != quad][0]
            return (8, quad, kicker)
        if count_list == [3, 2]:
            trip = max(r for r, c in rank_count.items() if c == 3)
            pair = max(r for r, c in rank_count.items() if c == 2)
            return (7, trip, pair)
        if is_flush:
            return (6, ranks)
        if is_straight:
            return (5, straight_high)
        if count_list == [3, 1, 1]:
            trip = max(r for r, c in rank_count.items() if c == 3)
            kickers = sorted([r for r in ranks if r != trip], reverse=True)
            return (4, trip, kickers)
        if count_list == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return (3, pairs[0], pairs[1], kicker)
        if count_list == [2, 1, 1, 1]:
            pair = max(r for r, c in rank_count.items() if c == 2)
            kickers = sorted([r for r in ranks if r != pair], reverse=True)
            return (2, pair, kickers)
        return (1, ranks)

    def has_good_hand(self, round_state: RoundStateClient) -> bool:
        if round_state.round == 'Preflop':
            score = self.preflop_strength(self.hole_cards)
            thresh = 25 if self.is_heads_up else 35
            return score >= thresh
        else:
            if len(round_state.community_cards) < 3:
                return False
            all_cards = self.hole_cards + round_state.community_cards
            card_tuples = [(self.rank_map[c[0]], c[1]) for c in all_cards]
            combos = itertools.combinations(card_tuples, 5)
            best = max(self.evaluate_5cards(combo) for combo in combos)
            return best[0] >= 2

    def has_very_good_hand(self, round_state: RoundStateClient) -> bool:
        if round_state.round == 'Preflop':
            score = self.preflop_strength(self.hole_cards)
            thresh = 40 if self.is_heads_up else 50
            return score >= thresh
        else:
            if len(round_state.community_cards) < 3:
                return False
            all_cards = self.hole_cards + round_state.community_cards
            card_tuples = [(self.rank_map[c[0]], c[1]) for c in all_cards]
            combos = itertools.combinations(card_tuples, 5)
            best = max(self.evaluate_5cards(combo) for combo in combos)
            return best[0] >= 4

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass