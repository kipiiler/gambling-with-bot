from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        call_amount = round_state.current_bet - my_bet
        pot = round_state.pot

        # Evaluate hand strength
        cards = self.hole_cards + round_state.community_cards
        strength = self.evaluate_hand(cards)

        if round_state.round == 'Preflop':
            ranks = [self.get_rank(c[0]) for c in self.hole_cards]
            suits = [c[1] for c in self.hole_cards]
            ranks.sort(reverse=True)
            high, low = ranks
            suited = suits[0] == suits[1]
            paired = high == low

            if paired or (high >= 12 and low >= 10) or (high == 14 and low >= 9 and suited):
                # Good hand, raise 3x blind
                raise_by = 3 * self.blind_amount
                amount = call_amount + raise_by
                amount = max(amount, round_state.min_raise)
                amount = min(amount, round_state.max_raise)
                if amount > 0:
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CHECK, 0
            elif high >= 10 or suited or (high - low <= 3):
                # Medium, call or check
                if call_amount > 0:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Bad, fold if facing bet, else check
                if call_amount > 0:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CHECK, 0
        else:
            # Postflop
            hand_type = strength
            if hand_type >= 1:  # Pair or better
                raise_by = pot // 2 + 1  # Avoid zero
                amount = call_amount + raise_by
                amount = max(amount, round_state.min_raise)
                amount = min(amount, round_state.max_raise)
                if amount > 0:
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CALL, 0
            elif hand_type == 0 and call_amount < pot / (4 + 1e-6) and call_amount > 0:
                return PokerAction.CALL, 0
            else:
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_rank(self, rank_char: str) -> int:
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return ranks.get(rank_char, 0)

    def evaluate_hand(self, cards: List[str]) -> int:
        if len(cards) < 5:
            ranks = sorted([self.get_rank(c[0]) for c in cards], reverse=True)
            rank_counts = Counter(ranks)
            max_count = max(rank_counts.values())
            if max_count >= 3:
                return 3
            if max_count == 2:
                return 1
            return 0
        else:
            best_type = 0
            for combo in itertools.combinations(cards, 5):
                type_ = self.get_five_card_type(list(combo))
                if type_ > best_type:
                    best_type = type_
            return best_type

    def get_five_card_type(self, five_cards: List[str]) -> int:
        ranks = sorted([self.get_rank(c[0]) for c in five_cards])
        suits = [c[1] for c in five_cards]
        is_flush = len(set(suits)) == 1
        is_straight = len(set(ranks)) == 5 and (ranks[4] - ranks[0] == 4 or ranks == [2, 3, 4, 5, 14])
        if is_flush and is_straight:
            if ranks == [10, 11, 12, 13, 14]:
                return 9
            return 8
        count = Counter(ranks)
        counts = sorted(count.values(), reverse=True)
        if counts[0] == 4:
            return 7
        if counts == [3, 2]:
            return 6
        if is_flush:
            return 5
        if is_straight:
            return 4
        if counts[0] == 3:
            return 3
        if counts[:2] == [2, 2]:
            return 2
        if counts[0] == 2:
            return 1
        return 0