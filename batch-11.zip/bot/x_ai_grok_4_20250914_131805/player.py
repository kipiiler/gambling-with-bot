from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import itertools
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 10
        self.small_blind = 5
        self.is_heads_up = False
        self.is_small_blind = False
        self.is_big_blind = False
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.stack = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.num_players = len(all_players)
        self.is_heads_up = self.num_players == 2
        self.is_small_blind = self.id == small_blind_player_id
        self.is_big_blind = self.id == big_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        min_raise_to = round_state.current_bet + round_state.min_raise
        max_raise_to = my_bet + remaining_chips
        phase = len(round_state.community_cards)
        num_active = len(round_state.current_player)
        strength = self.calculate_hand_strength(round_state)

        # special for heads-up preflop as small blind initial action
        if self.is_heads_up and phase == 0 and to_call == self.small_blind and my_bet == self.small_blind and not round_state.player_actions.get(my_id_str):
            # initial action as small blind
            if strength > 0.6:
                raise_to = 4 * self.big_blind
            elif strength > 0.3:
                raise_to = 3 * self.big_blind
            elif strength > 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
            raise_to = min(max(raise_to, min_raise_to), max_raise_to)
            return (PokerAction.RAISE, raise_to)

        # general logic
        pot_odds = to_call / (pot + to_call + 1e-6)
        bluff_prob = 0.1 if to_call == 0 else 0.0
        if random.random() < bluff_prob:
            raise_to = my_bet + int(pot * 0.7)
            raise_to = min(max(raise_to, min_raise_to), max_raise_to)
            if raise_to > my_bet:
                return (PokerAction.RAISE, raise_to)

        if to_call == 0:
            if strength > 0.5:
                bet_size = int(pot * 0.7)
                raise_to = my_bet + max(bet_size, round_state.min_raise)
                raise_to = min(max(raise_to, min_raise_to), max_raise_to)
                if raise_to > my_bet:
                    return (PokerAction.RAISE, raise_to)
            return (PokerAction.CHECK, 0)
        else:
            if strength > pot_odds + 0.3 and random.random() < 0.8:
                raise_size = int(to_call + pot * 0.7)
                raise_to = my_bet + raise_size
                raise_to = min(max(raise_to, min_raise_to), max_raise_to)
                if raise_to >= min_raise_to:
                    return (PokerAction.RAISE, raise_to)
            if strength > pot_odds:
                if to_call >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def card_rank(self, char):
        if char.isdigit():
            return int(char)
        return {'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}[char]

    def get_deck(self):
        ranks = '23456789TJQKA'
        suits = 'cdhs'
        return [r + s for r in ranks for s in suits]

    def preflop_strength(self):
        if not self.hole_cards:
            return 0.0
        r = [self.card_rank(c[0]) for c in self.hole_cards]
        s = [c[1] for c in self.hole_cards]
        r1, r2 = sorted(r, reverse=True)
        suited = s[0] == s[1]
        paired = r1 == r2
        diff = r1 - r2
        score = r1 * 1.2 + r2
        if paired:
            score += 20
        if suited:
            score += 8
        if diff <= 2 and not paired:
            score += 5
        return (score - 5) / (63 - 5 + 1e-6)

    def evaluate_hand(self, five_cards):
        parsed = [(self.card_rank(c[0]), c[1]) for c in five_cards]
        ranks = sorted([r for r, s in parsed], reverse=True)
        suits = [s for r, s in parsed]
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)
        unique_ranks_set = sorted(set(ranks))
        is_flush = max(suit_counts.values()) == 5
        is_straight = False
        wheel = False
        if len(unique_ranks_set) == 5:
            if unique_ranks_set[-1] - unique_ranks_set[0] == 4:
                is_straight = True
            elif unique_ranks_set == [2, 3, 4, 5, 14]:
                is_straight = True
                wheel = True
        if is_flush and is_straight:
            if wheel:
                return (8, [5, 4, 3, 2, 1])
            return (8, sorted(ranks, reverse=True))
        if 4 in rank_counts.values():
            quad = [rank for rank, count in rank_counts.items() if count == 4][0]
            kicker = max([rank for rank in ranks if rank != quad])
            return (7, [quad, kicker])
        if 3 in rank_counts.values() and 2 in rank_counts.values():
            trip = [rank for rank, count in rank_counts.items() if count == 3][0]
            pair = [rank for rank, count in rank_counts.items() if count == 2][0]
            return (6, [trip, pair])
        if is_flush:
            return (5, sorted(ranks, reverse=True))
        if is_straight:
            if wheel:
                return (4, [5, 4, 3, 2, 1])
            return (4, sorted(ranks, reverse=True))
        if 3 in rank_counts.values():
            trip = [rank for rank, count in rank_counts.items() if count == 3][0]
            kickers = sorted([rank for rank in ranks if rank != trip], reverse=True)[:2]
            return (3, [trip] + kickers)
        pairs = [rank for rank, count in rank_counts.items() if count == 2]
        if len(pairs) == 2:
            pairs_sorted = sorted(pairs, reverse=True)
            kicker = max([rank for rank in ranks if rank not in pairs_sorted])
            return (2, pairs_sorted + [kicker])
        if len(pairs) == 1:
            pair = pairs[0]
            kickers = sorted([rank for rank in ranks if rank != pair], reverse=True)[:3]
            return (1, [pair] + kickers)
        return (0, sorted(ranks, reverse=True))

    def get_best_hand(self, hole, community):
        all_cards = hole + community
        n = len(all_cards)
        if n < 5:
            return (0, [0] * 5)
        best = (-1, [])
        for combo in itertools.combinations(all_cards, 5):
            score = self.evaluate_hand(list(combo))
            if score > best:
                best = score
        return best

    def calculate_hand_strength(self, round_state):
        community = round_state.community_cards
        phase = len(community)
        if phase == 0:
            return self.preflop_strength()
        num_active = len(round_state.current_player)
        best = self.get_best_hand(self.hole_cards, community)
        heuristic = best[0] / 8.0
        if phase < 5 or num_active > 2:
            return heuristic
        # exact for river heads-up
        deck = self.get_deck()
        known = set(self.hole_cards + community)
        remaining = [c for c in deck if c not in known]
        wins = 0
        ties = 0
        total = 0
        for opp_hole in itertools.combinations(remaining, 2):
            opp_best = self.get_best_hand(list(opp_hole), community)
            my_best = best
            if my_best > opp_best:
                wins += 1
            elif my_best == opp_best:
                ties += 1
            total += 1
        return (wins + ties * 0.5) / (total + 1e-6)