from typing import List, Tuple, Dict, Any
from enum import Enum
import itertools
from dataclasses import dataclass

# --- Provided Type Definitions ---

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

class Bot:
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

# --- Custom Hand Rank Enum ---
class HandRank(Enum):
    HIGH_CARD = 1
    ONE_PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9
    ROYAL_FLUSH = 10


# --- Bot Implementation ---

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.big_blind_amount = 20  # A default, will be updated in on_start

    # --- Static Helper Methods for Card/Hand Evaluation ---
    @staticmethod
    def _parse_card(card: str) -> tuple:
        """Parses a card string 'Rs' into rank and suit, e.g., 'Kh' -> (13, 'h')."""
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        if not card or len(card) < 2: return (0, ' ')
        rank = rank_map.get(card[:-1])
        suit = card[-1]
        return rank, suit

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[HandRank, List[int]]:
        """Evaluates the best 5-card hand from the available cards."""
        if not hole_cards:
            return HandRank.HIGH_CARD, []
        
        all_cards_str = hole_cards + community_cards
        if len(all_cards_str) < 5:
             # Evaluate hole cards if not enough community cards yet
             parsed_hole = [self._parse_card(c) for c in hole_cards]
             ranks = sorted([r for r, s in parsed_hole], reverse=True)
             if ranks[0] == ranks[1]:
                 return HandRank.ONE_PAIR, ranks
             return HandRank.HIGH_CARD, ranks

        all_cards = [self._parse_card(c) for c in all_cards_str]
        best_rank = (HandRank.HIGH_CARD, [])

        for hand_combination in itertools.combinations(all_cards, 5):
            current_rank = self._get_5_card_rank(list(hand_combination))
            if current_rank[0].value > best_rank[0].value:
                best_rank = current_rank
            elif current_rank[0] == best_rank[0] and len(current_rank[1]) > 0 and len(best_rank[1]) > 0:
                # Tie-breaking logic based on ordered kicker/card values
                for i in range(len(current_rank[1])):
                    if current_rank[1][i] > best_rank[1][i]:
                        best_rank = current_rank
                        break
                    if current_rank[1][i] < best_rank[1][i]:
                        break
        return best_rank

    @staticmethod
    def _get_5_card_rank(hand: list) -> Tuple[HandRank, List[int]]:
        """Determines the rank of a specific 5-card hand."""
        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        is_flush = len(set(suits)) == 1
        
        is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)) or (ranks == [14, 5, 4, 3, 2])
        
        straight_ranks = ranks
        if ranks == [14, 5, 4, 3, 2]: # Ace-low straight (wheel)
            straight_ranks = [5, 4, 3, 2, 1] 

        if is_straight and is_flush:
            if ranks[0] == 14: return (HandRank.ROYAL_FLUSH, straight_ranks)
            return (HandRank.STRAIGHT_FLUSH, straight_ranks)

        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4:
            four_kind_rank = next(r for r, c in rank_counts.items() if c == 4)
            kicker = next(r for r in ranks if r != four_kind_rank)
            return (HandRank.FOUR_OF_A_KIND, [four_kind_rank, kicker])
            
        if counts == [3, 2]:
            three_kind_rank = next(r for r, c in rank_counts.items() if c == 3)
            pair_rank = next(r for r, c in rank_counts.items() if c == 2)
            return (HandRank.FULL_HOUSE, [three_kind_rank, pair_rank])

        if is_flush: return (HandRank.FLUSH, ranks)
        if is_straight: return (HandRank.STRAIGHT, straight_ranks)
            
        if counts[0] == 3:
            three_kind_rank = next(r for r, c in rank_counts.items() if c == 3)
            kickers = sorted([r for r in ranks if r != three_kind_rank], reverse=True)
            return (HandRank.THREE_OF_A_KIND, [three_kind_rank] + kickers)

        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = next(r for r, c in rank_counts.items() if c == 1)
            return (HandRank.TWO_PAIR, pairs + [kicker])

        if counts[0] == 2:
            pair_rank = next(r for r, c in rank_counts.items() if c == 2)
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return (HandRank.ONE_PAIR, [pair_rank] + kickers)

        return (HandRank.HIGH_CARD, ranks)

    # --- Bot Lifecycle Methods ---
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # This is the FIX for the AttributeError: store the hand received at the start.
        self.hand = player_hands
        self.big_blind_amount = blind_amount
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Core logic for deciding a poker action."""
        
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, amount_to_call)
        else:
            return self._get_postflop_action(round_state, remaining_chips, amount_to_call)

    def _get_preflop_opening_strength(self) -> int:
        """Categorizes hole cards into tiers of strength. Returns 1 (best) to 5 (worst)."""
        card1, card2 = self._parse_card(self.hand[0]), self._parse_card(self.hand[1])
        r1, s1 = card1; r2, s2 = card2
        
        high_rank, low_rank = (max(r1, r2), min(r1, r2))
        is_suited = s1 == s2
        is_pair = r1 == r2

        if (is_pair and high_rank >= 12) or (is_suited and high_rank == 14 and low_rank == 13): return 1 # AA, KK, QQ, AKs
        if (is_pair and high_rank >= 10) or (is_suited and high_rank >= 12) or (high_rank == 14 and low_rank == 13): return 2 # JJ, TT, AQs, AJs, KQs, AKo
        if (is_pair and high_rank >= 8) or (is_suited and high_rank >= 10) or (high_rank >= 12 and low_rank >= 12): return 3 # 99, 88, KJs, QJs, JTs, ATs, AQo
        if is_pair or is_suited or (high_rank >= 10 and high_rank - low_rank <= 2): return 4 # Other pairs, suited cards, connectors
        return 5

    def _get_preflop_action(self, round_state: RoundStateClient, my_chips: int, amount_to_call: int) -> Tuple[PokerAction, int]:
        """Decide pre-flop action based on hand strength and table action."""
        strength = self._get_preflop_opening_strength()
        has_been_raised = round_state.current_bet > self.big_blind_amount
        
        if my_chips < 15 * self.big_blind_amount: # Short-stack push/fold
            if strength <= 3: return PokerAction.ALL_IN, 0
            return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)
        
        if has_been_raised: # Responding to a raise
            call_cost_ratio = amount_to_call / my_chips if my_chips > 0 else 1
            if strength == 1:
                raise_amount = round_state.current_bet * 3
                if raise_amount >= my_chips: return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(max(raise_amount, round_state.min_raise), round_state.max_raise)
            if strength <= 3 and call_cost_ratio < 0.2:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else: # Opening action
            if strength <= 2:
                raise_amount = 3 * self.big_blind_amount
                return PokerAction.RAISE, min(max(raise_amount, round_state.min_raise), round_state.max_raise)
            if strength <= 4:
                return (PokerAction.CALL, 0) if amount_to_call > 0 else (PokerAction.CHECK, 0)
            return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)

    def _get_postflop_action(self, round_state: RoundStateClient, my_chips: int, amount_to_call: int) -> Tuple[PokerAction, int]:
        """Decide post-flop action based on hand rank and pot dynamics."""
        hand_rank, _ = self._evaluate_hand(self.hand, round_state.community_cards)

        if amount_to_call > 0: # Facing a bet
            pot_total = round_state.pot
            bet_ratio_to_pot = amount_to_call / (pot_total + 1)
            
            if hand_rank.value >= HandRank.THREE_OF_A_KIND.value:
                raise_amount = round_state.pot + 2 * round_state.current_bet
                if raise_amount >= my_chips: return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(max(raise_amount, round_state.min_raise), round_state.max_raise)
            
            if hand_rank.value >= HandRank.TWO_PAIR.value:
                if bet_ratio_to_pot < 0.75: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            if hand_rank.value >= HandRank.ONE_PAIR.value:
                if bet_ratio_to_pot < 0.33: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            
            return PokerAction.FOLD, 0
        else: # Not facing a bet (can check or bet)
            if hand_rank.value >= HandRank.TWO_PAIR.value:
                bet_amount = int(round_state.pot * 0.6)
                if bet_amount == 0 and round_state.pot > 0: bet_amount = self.big_blind_amount # Min bet if pot is small
                if bet_amount >= my_chips: return PokerAction.ALL_IN, 0
                if bet_amount >= round_state.min_raise:
                    return PokerAction.RAISE, min(bet_amount, round_state.max_raise)
            
            return PokerAction.CHECK, 0