import collections
import itertools
import random
from typing import List, Tuple, Dict, Any

# These definitions are provided in the problem description.
# They are included here to make the script self-contained and for clarity.

from enum import Enum

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

from dataclasses import dataclass

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

from abc import ABC, abstractmethod

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass
    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass
    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass
    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

# --- End of provided definitions ---

class SimplePlayer(Bot):
    """
    A poker bot for No-Limit Texas Hold'em.
    Strategy:
    - Pre-flop: Uses a starting hand chart to decide whether to play.
    - Post-flop: Uses Monte Carlo simulation to estimate hand equity (win probability).
    - Betting: Based on equity, pot odds, and game state. It value bets strong hands
      and folds weak hands, with simple logic for raises and calls.
    - It assumes that the on_start method is called for each new hand,
      which is the only way to receive hole cards based on the provided API.
    """
    
    # Constants for Monte Carlo simulation
    NUM_SIMULATIONS = 300 # Balancing accuracy and speed

    def __init__(self):
        super().__init__()
        self.hand = []
        self.all_players = []
        self.big_blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # This method is assumed to be called at the start of each hand.
        self.hand = player_hands
        self.all_players = all_players
        self.big_blind_amount = blind_amount
        # We can also store other initial states if needed
        # self.remaining_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # This method can be used to reset any state at the start of a betting round
        # e.g., tracking opponent actions within this round.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player based on the current game state.
        """
        try:
            # Determine active opponents
            active_players_ids = [pid for pid in self.all_players if round_state.player_actions.get(str(pid)) != 'Fold']
            num_opponents = len(active_players_ids) - 1 if self.id in active_players_ids else len(active_players_ids)
            if num_opponents < 0: num_opponents = 0

            # Pre-flop strategy
            if round_state.round == 'Preflop':
                return self._get_preflop_action(round_state, remaining_chips)

            # Post-flop strategy (Flop, Turn, River)
            return self._get_postflop_action(round_state, remaining_chips, num_opponents)

        except Exception:
            # If any error occurs, fold to be safe
            return PokerAction.FOLD, 0

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int):
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet

        hand_category = self._get_preflop_category(self.hand)

        # Tier 1: Premium hands (AA, KK, QQ, JJ, AKs) -> Always raise/reraise
        if hand_category == 1:
            if round_state.current_bet <= self.big_blind_amount: # No one has raised yet
                raise_amount = 3 * self.big_blind_amount
            else: # Someone has raised
                raise_amount = 3 * round_state.current_bet
            
            raise_amount = self._validate_raise_amount(raise_amount, round_state.min_raise, remaining_chips)
            if raise_amount > 0:
                return PokerAction.RAISE, raise_amount
            elif amount_to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CALL, 0

        # Tier 2: Very Strong hands -> Raise if first in, call raises
        if hand_category == 2:
            if round_state.current_bet <= self.big_blind_amount:
                raise_amount = 3 * self.big_blind_amount
                raise_amount = self._validate_raise_amount(raise_amount, round_state.min_raise, remaining_chips)
                return PokerAction.RAISE, raise_amount
            else:
                if amount_to_call < 0.2 * remaining_chips: # Call if not too expensive
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Tier 3: Strong Playable hands -> Call small bets/raises
        if hand_category == 3:
            if round_state.current_bet <= self.big_blind_amount:
                 return PokerAction.CALL, 0 # Limp in
            else:
                if amount_to_call < 0.1 * remaining_chips: # Call small raises
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Tier 4: Speculative hands -> Play cheaply
        if hand_category == 4:
            if amount_to_call == 0: # Can check for free
                return PokerAction.CHECK, 0
            if amount_to_call <= self.big_blind_amount: # Call a single blind
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Tier 5: Fold
        if amount_to_call > 0:
            return PokerAction.FOLD, 0
        else:
            return PokerAction.CHECK, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, num_opponents: int):
        if num_opponents <= 0:
            return PokerAction.CHECK, 0

        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet

        # Estimate win probability using Monte Carlo simulation
        win_prob = self._estimate_win_prob(
            my_cards=self.hand,
            community_cards=round_state.community_cards,
            num_opponents=num_opponents,
            num_simulations=self.NUM_SIMULATIONS
        )

        # Decision logic based on win probability
        
        # If no one has bet yet
        if amount_to_call == 0:
            if win_prob > 0.8: # Very strong hand, bet big
                bet_amount = int(0.75 * round_state.pot)
            elif win_prob > 1.0 / (num_opponents + 1): # Good hand, value bet
                bet_amount = int(0.5 * round_state.pot)
            else: # Weak hand, check
                return PokerAction.CHECK, 0
            
            # Validate and make the bet
            bet_amount = self._validate_raise_amount(bet_amount, round_state.min_raise, remaining_chips)
            if bet_amount > 0:
                return PokerAction.RAISE, bet_amount
            else:
                return PokerAction.CHECK, 0

        # If facing a bet
        else:
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)

            if win_prob > pot_odds:
                # Strong enough to call, consider raising
                if win_prob > 0.85 or (win_prob > pot_odds * 2 and round_state.round != 'River'): # Raise with monster hands or strong draws
                    raise_amount = 2 * amount_to_call + round_state.pot
                    raise_amount = self._validate_raise_amount(raise_amount, round_state.min_raise, remaining_chips)
                    if raise_amount > 0 and raise_amount > amount_to_call:
                         return PokerAction.RAISE, raise_amount
                    else:
                         return PokerAction.CALL, 0
                else:
                    # Just call
                    return PokerAction.CALL, 0
            else:
                # Not getting the right price to call, fold
                return PokerAction.FOLD, 0

    def _validate_raise_amount(self, amount, min_raise, max_raise):
        if amount >= max_raise:
            return max_raise
        if amount < min_raise:
            return 0 # Indicates not to raise
        return amount

    # --- Helper methods for hand evaluation and simulation ---

    @staticmethod
    def _get_preflop_category(hand: List[str]) -> int:
        """
        Categorizes starting hands into tiers.
        Tier 1: Premium, Tier 2: Very Strong, Tier 3: Strong, Tier 4: Speculative, Tier 5: Fold.
        """
        ranks = "23456789TJQKA"
        card1_rank_str, card2_rank_str = hand[0][0], hand[1][0]
        rank1_val, rank2_val = ranks.index(card1_rank_str), ranks.index(card2_rank_str)
        
        high_rank_str, low_rank_str = (card1_rank_str, card2_rank_str) if rank1_val > rank2_val else (card2_rank_str, card1_rank_str)
        is_suited = hand[0][1] == hand[1][1]
        is_pair = high_rank_str == low_rank_str
        
        if is_pair:
            pair_rank_val = ranks.index(high_rank_str)
            if pair_rank_val >= ranks.index('J'): return 1 # AA, KK, QQ, JJ
            if pair_rank_val >= ranks.index('9'): return 2 # TT, 99
            if pair_rank_val >= ranks.index('7'): return 3 # 88, 77
            return 4 # 66-22

        hand_code = high_rank_str + low_rank_str
        
        if is_suited:
            if hand_code == 'AK': return 1
            if hand_code in ['AQ', 'AJ', 'KQ']: return 2
            if hand_code in ['AT', 'KJ', 'QJ', 'JT']: return 3
            if high_rank_str == 'A' or ranks.index(high_rank_str) - ranks.index(low_rank_str) <= 2: return 4 # Suited aces and connectors/gappers
        else: # Offsuit
            if hand_code == 'AK': return 2
            if hand_code in ['AQ', 'AJ', 'KQ']: return 3
            if hand_code in ['AT', 'KJ', 'QJ']: return 4

        return 5 # Fold everything else


    @staticmethod
    def _parse_cards(cards_str: List[str]) -> List[Tuple[int, str]]:
        """ Parses string representations of cards into (rank, suit) tuples. """
        ranks_map = {"2":0, "3":1, "4":2, "5":3, "6":4, "7":5, "8":6, "9":7, "T":8, "J":9, "Q":10, "K":11, "A":12}
        return [(ranks_map[c[0]], c[1]) for c in cards_str]

    @staticmethod
    def _get_hand_rank(hand: List[Tuple[int, str]]):
        """ Evaluates a 5-card hand and returns its rank and tie-breaking values. """
        if len(hand) != 5:
            return (0, [])

        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        is_flush = len(set(suits)) == 1
        
        is_straight = (len(set(ranks)) == 5) and (ranks[0] - ranks[4] == 4)
        is_ace_low_straight = ranks == [12, 3, 2, 1, 0] # A, 5, 4, 3, 2
        
        if is_ace_low_straight:
            is_straight = True
            tie_breaker_ranks = [3, 2, 1, 0, -1] # Ace-low is the lowest straight
        else:
            tie_breaker_ranks = ranks

        if is_straight and is_flush:
            return (9, tie_breaker_ranks)  # Straight Flush
        
        counts = collections.Counter(ranks)
        count_vals = sorted(counts.values(), reverse=True)
        
        if count_vals[0] == 4:
            quad_rank = [r for r, c in counts.items() if c == 4][0]
            kicker = [r for r, c in counts.items() if c == 1][0]
            return (8, [quad_rank] * 4 + [kicker])
        
        if count_vals == [3, 2]:
            trip_rank = [r for r, c in counts.items() if c == 3][0]
            pair_rank = [r for r, c in counts.items() if c == 2][0]
            return (7, [trip_rank, pair_rank])
        
        if is_flush:
            return (6, ranks) # Flush
        
        if is_straight:
            return (5, tie_breaker_ranks) # Straight
            
        if count_vals[0] == 3:
            trip_rank = [r for r, c in counts.items() if c == 3][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return (4, [trip_rank] + kickers)

        if count_vals == [2, 2, 1]:
            pairs = sorted([r for r, c in counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in counts.items() if c == 1][0]
            return (3, pairs + [kicker])

        if count_vals[0] == 2:
            pair_rank = [r for r, c in counts.items() if c == 2][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return (2, [pair_rank] + kickers)
        
        return (1, ranks)

    @classmethod
    def _estimate_win_prob(cls, my_cards: List[str], community_cards: List[str], num_opponents: int, num_simulations: int) -> float:
        """ Estimates win probability via Monte Carlo simulation. """
        my_hand_parsed = cls._parse_cards(my_cards)
        community_parsed = cls._parse_cards(community_cards)

        deck = [(r, s) for r in range(13) for s in 'shdc']
        
        for card in my_hand_parsed + community_parsed:
            deck.remove(card)

        wins = 0
        ties = 0

        for _ in range(num_simulations):
            sim_deck = deck[:]
            random.shuffle(sim_deck)

            opponents_hands = [sim_deck[i*2:i*2+2] for i in range(num_opponents)]
            
            num_remaining_community = 5 - len(community_parsed)
            sim_community = community_parsed + sim_deck[num_opponents*2 : num_opponents*2 + num_remaining_community]
            
            my_best_rank = cls._get_best_7_card_hand(my_hand_parsed + sim_community)

            opponents_best_ranks = [cls._get_best_7_card_hand(opp_hand + sim_community) for opp_hand in opponents_hands]
            
            if not opponents_best_ranks: # I am the only one left
                wins +=1
                continue

            max_opp_rank = max(opponents_best_ranks)
            
            if my_best_rank > max_opp_rank:
                wins += 1
            elif my_best_rank == max_opp_rank:
                ties += 1
        
        return (wins + ties / 2) / num_simulations if num_simulations > 0 else 0

    @classmethod
    def _get_best_7_card_hand(cls, seven_cards: List[Tuple[int, str]]):
        """ Finds the best 5-card hand from a list of 7 cards. """
        best_rank = (-1, [])
        for five_card_combo in itertools.combinations(seven_cards, 5):
            rank = cls._get_hand_rank(list(five_card_combo))
            if rank > best_rank:
                best_rank = rank
        return best_rank

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass