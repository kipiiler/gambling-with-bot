import collections
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Hand rank constants for evaluation
HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8

RANKS_MAP = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}


class SimplePlayer(Bot):

    def __init__(self):
        super().__init__()
        self.hand = []
        self.all_players = []
        self.starting_chips = 0
        self.big_blind_amount = 20 # Default, will be updated
        self.bb_player_id = None
        self.sb_player_id = None

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """Converts a card string like 'Ah' to a tuple (14, 'h')."""
        if not card_str or len(card_str) < 2:
            return 0, ' '
        rank = RANKS_MAP.get(card_str[:-1])
        suit = card_str[-1]
        return rank, suit

    def _evaluate_5_cards(self, hand: List[Tuple[int, str]]):
        """Evaluates a 5-card hand and returns its rank and tie-breaking values."""
        if not hand or len(hand) != 5:
            return (HIGH_CARD, (0,))

        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        is_flush = len(set(suits)) == 1

        is_straight = all(ranks[i] == ranks[i + 1] + 1 for i in range(4))
        # Ace-low straight (A, 2, 3, 4, 5)
        if not is_straight and ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]

        if is_straight and is_flush:
            return (STRAIGHT_FLUSH, tuple(ranks))

        rank_counts = collections.Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        major_ranks = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)

        if counts[0] == 4:
            return (FOUR_OF_A_KIND, major_ranks[0], major_ranks[1])
        if counts == [3, 2]:
            return (FULL_HOUSE, major_ranks[0], major_ranks[1])
        if is_flush:
            return (FLUSH, tuple(ranks))
        if is_straight:
            return (STRAIGHT, tuple(ranks))
        if counts[0] == 3:
            return (THREE_OF_A_KIND, major_ranks[0], major_ranks[1], major_ranks[2])
        if counts == [2, 2, 1]:
            return (TWO_PAIR, major_ranks[0], major_ranks[1], major_ranks[2])
        if counts[0] == 2:
            return (ONE_PAIR, major_ranks[0], major_ranks[1], major_ranks[2], major_ranks[3])
        
        return (HIGH_CARD, tuple(ranks))
    
    def _get_best_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple:
        """Finds the best 5-card hand from the available cards."""
        all_cards_str = hole_cards + community_cards
        if not all_cards_str:
            return (HIGH_CARD, (0,))

        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        if len(all_cards) < 5:
            ranks = sorted([card[0] for card in all_cards], reverse=True)
            return (HIGH_CARD, tuple(ranks))

        best_rank = (HIGH_CARD, (0,))
        for combo in combinations(all_cards, 5):
            rank = self._evaluate_5_cards(list(combo))
            if rank[0] > best_rank[0] or (rank[0] == best_rank[0] and rank[1:] > best_rank[1:]):
                best_rank = rank
        return best_rank

    def _calculate_outs(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, str]:
        """Calculates outs for flush and straight draws."""
        my_cards = [self._parse_card(c) for c in hole_cards]
        board = [self._parse_card(c) for c in community_cards]
        all_cards = my_cards + board
        all_ranks = {c[0] for c in all_cards}
        
        # Flush draw
        suit_counts = collections.Counter(c[1] for c in all_cards)
        is_flush_draw = any(count == 4 for count in suit_counts.values())
        flush_outs = 9 if is_flush_draw else 0
        
        # Straight draw
        straight_outs = 0
        possible_ranks = sorted(list(all_ranks))
        for r in range(1, 11): # Check for sequences like starting from A-4 up to T-K
            seq = {r, r+1, r+2, r+3, r+4}
            matched = all_ranks.intersection(seq)
            if len(matched) == 4:
                missing_rank = list(seq - matched)[0]
                straight_outs = max(straight_outs, 4) # Gutshot
                # Open-ended
                if missing_rank != r and missing_rank != r+4:
                    straight_outs = max(straight_outs, 8)
        # Ace-low special case
        if len(all_ranks.intersection({14, 2, 3, 4, 5})) == 4:
            straight_outs = max(straight_outs, 4)

        total_outs = flush_outs
        if straight_outs == 8 and is_flush_draw: total_outs = 15 # Combo draw
        elif straight_outs > 0: total_outs += straight_outs

        return total_outs, "Draw"

    def _get_preflop_hand_category(self, hand: List[str]) -> int:
        """Categorizes starting hands into groups from 1 (best) to 6 (worst)."""
        if not hand or len(hand) != 2: return 6
        
        c1, c2 = self._parse_card(hand[0]), self._parse_card(hand[1])
        r1, r2 = sorted([c1[0], c2[0]], reverse=True)
        suited = c1[1] == c2[1]
        pair = r1 == r2
        
        if pair and r1 >= 13: return 1 # AA, KK
        if r1 == 14 and r2 == 13: return 1 # AKs, AKo

        if pair and r1 >= 10: return 2 # QQ, JJ, TT
        if suited and r1 == 14 and r2 >= 11: return 2 # AQs, AJs
        if suited and r1 == 13 and r2 == 12: return 2 # KQs

        if pair and r1 >= 8: return 3 # 99, 88
        if r1 == 14 and r2 == 12: return 3 # AQo
        if suited and ((r1 == 14 and r2 == 10) or (r1, r2) == (13, 11) or (r1, r2) == (12, 11)): return 3
        
        if pair: return 4 # 77..22
        if suited and (r1 - r2) < 5: return 4 # Suited connectors/gappers
        if not suited and r1 >= 10 and r2 >= 9 and (r1 - r2) <= 2: return 4

        if r1 == 14: return 5 # Any other Ace
        if suited or (r1-r2) < 4: return 5

        return 6

    def _get_my_position(self, big_blind_player_id: int):
        if self.id in [self.bb_player_id, self.sb_player_id]:
            return 'BLIND'
        if not self.all_players or big_blind_player_id not in self.all_players:
            return 'MIDDLE' # Fallback
        
        num_players = len(self.all_players)
        try:
            bb_idx = self.all_players.index(big_blind_player_id)
            my_idx = self.all_players.index(self.id)
        except ValueError:
            return 'MIDDLE'

        # Relative position to BB in action order
        # player after BB -> UTG -> early
        # player before SB/BB -> Button/CO -> late
        distance = (my_idx - bb_idx + num_players) % num_players
        
        if num_players > 6:
            if distance <= 2: return 'EARLY'
            elif distance <= num_players - 3: return 'MIDDLE'
            else: return 'LATE'
        else: # 6-max
            if distance <= 1: return 'EARLY' # UTG
            elif distance <= 2: return 'MIDDLE' # MP
            else: return 'LATE' # CO, Button

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.all_players = all_players
        self.big_blind_amount = blind_amount
        self.bb_player_id = big_blind_player_id
        self.sb_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # In a real game, the hand would be updated here. We assume the game framework
        # updates `self.hand` before calling get_action.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        active_players = [p for p, act in round_state.player_actions.items() if act != 'Fold']
        num_active_players = len(active_players)

        if round_state.round == "Preflop":
            position = self._get_my_position(self.bb_player_id)
            category = self._get_preflop_hand_category(self.hand)
            action_is_on_me_unopened = round_state.current_bet <= self.big_blind_amount
            
            # Categories 1-2: Premium hands - raise aggressively
            if category <= 2:
                if action_is_on_me_unopened:
                    raise_amount = self.big_blind_amount * 3
                else: # Re-raise (3-bet)
                    raise_amount = round_state.current_bet + round_state.pot
                
                # Ensure raise is valid
                raise_amount = min(max(raise_amount, round_state.min_raise), remaining_chips + my_bet)
                if raise_amount > round_state.current_bet:
                    return PokerAction.RAISE, int(raise_amount)
                return PokerAction.CALL, 0

            # Category 3: Strong hands - raise from good position, call otherwise
            if category == 3:
                if action_is_on_me_unopened and position in ['LATE', 'MIDDLE']:
                    raise_amount = min(max(self.big_blind_amount * 2.5, round_state.min_raise), remaining_chips + my_bet)
                    return PokerAction.RAISE, int(raise_amount)
                if amount_to_call < remaining_chips * 0.1: # Call small raises
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            
            # Category 4-5: Speculative - call small bets, see a cheap flop
            if category <= 5:
                if amount_to_call <= self.big_blind_amount * 2 and (amount_to_call < remaining_chips * 0.05):
                    return PokerAction.CALL, 0
                if self.id == self.bb_player_id and action_is_on_me_unopened:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
            
            # Category 6: Garbage - fold unless in BB and can check
            if self.id == self.bb_player_id and action_is_on_me_unopened:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Post-flop strategy
        else:
            best_rank, _ = self._get_best_hand(self.hand, round_state.community_cards)
            outs, _ = self._calculate_outs(self.hand, round_state.community_cards)

            if best_rank[0] >= THREE_OF_A_KIND: hand_strength = 'MONSTER'
            elif best_rank[0] == TWO_PAIR: hand_strength = 'STRONG'
            elif best_rank[0] == ONE_PAIR: hand_strength = 'MEDIUM'
            else: hand_strength = 'GARBAGE'
            
            is_strong_draw = outs >= 8

            if amount_to_call == 0:  # Check or Bet
                if hand_strength in ['MONSTER', 'STRONG']:
                    bet_amount = min(max(round_state.pot * 0.7, round_state.min_raise), remaining_chips)
                    return PokerAction.RAISE, int(bet_amount)
                if is_strong_draw and round_state.round != "River":
                    bet_amount = min(max(round_state.pot * 0.5, round_state.min_raise), remaining_chips)
                    return PokerAction.RAISE, int(bet_amount)
                return PokerAction.CHECK, 0

            else:  # Fold, Call, or Raise
                pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)

                if hand_strength == 'MONSTER':
                    raise_amount = min(max(round_state.current_bet * 2.5, round_state.min_raise), remaining_chips + my_bet)
                    return PokerAction.RAISE, int(raise_amount)
                
                win_prob = 0
                if is_strong_draw and round_state.round != "River":
                    win_prob = (outs * 4 if round_state.round == "Flop" else outs * 2) / 100.0
                
                if win_prob > pot_odds:
                    return PokerAction.CALL, 0

                if hand_strength == 'STRONG':
                    if pot_odds < 0.35: # call if getting decent odds
                         return PokerAction.CALL, 0
                
                if hand_strength == 'MEDIUM':
                     if pot_odds < 0.2: # Call only small bets
                         return PokerAction.CALL, 0

                return PokerAction.FOLD, 0
        
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # A good place to confirm the hand dealing mechanism for future iterations
        if str(self.id) in active_players_hands:
            self.hand = active_players_hands[str(self.id)]