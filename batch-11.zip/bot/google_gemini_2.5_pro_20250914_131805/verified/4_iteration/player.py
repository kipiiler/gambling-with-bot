import random
import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for card and hand evaluation
RANKS = '23456789TJQKA'
SUITS = 'shdc'
RANK_VALUES = {r: i for i, r in enumerate(RANKS)}

HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8
ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand charts, Monte Carlo simulation for post-flop equity,
    and pot odds to make decisions.
    """
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.starting_chips: int = 0
        self.big_blind_amount: int = 0
        self.all_players: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the game."""
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of a new hand."""
        # The server might update our hand if it was not available at on_start
        if str(self.id) in round_state.player_hands:
            self.hand = round_state.player_hands[str(self.id)]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        It is called when it is the bot's turn to act.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        # Count active players who have not folded
        num_active_players = sum(1 for pid, bet in round_state.player_bets.items() if round_state.player_actions.get(pid) != 'Fold')
        if num_active_players == 0: # Can be 0 at the very start of a round before actions are recorded
            num_active_players = len([p for p in self.all_players if p in round_state.player_bets])

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, num_active_players, amount_to_call, can_check)
        else:
            return self._get_postflop_action(round_state, remaining_chips, num_active_players, amount_to_call, can_check)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each hand."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass
    
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, num_active_players: int, amount_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        """Determines the action to take during the pre-flop round."""
        hand_score = self._evaluate_preflop_hand(self.hand)

        # Define thresholds based on number of players. Tighter for more players.
        if num_active_players <= 2: # Heads-up is looser
            raise_threshold = 8
            call_threshold = 5
        elif num_active_players <= 4:
            raise_threshold = 9
            call_threshold = 6
        else: # 5+ players is tighter
            raise_threshold = 10
            call_threshold = 7

        # Adjust thresholds if facing a raise
        is_raised = round_state.current_bet > self.big_blind_amount
        if is_raised:
            call_threshold += 2  # Be more selective when calling a raise
            raise_threshold += 2 # For 3-betting

        # Decision to Raise/3-bet
        if hand_score >= raise_threshold:
            if is_raised:
                # 3-bet sizing: pot size raise
                raise_amount = round_state.pot + 2 * amount_to_call
            else:
                # Standard opening raise
                raise_amount = 3 * self.big_blind_amount
            
            raise_amount = max(round_state.min_raise, int(raise_amount))
            
            if remaining_chips > raise_amount:
                # Ensure raise is within valid bounds
                return PokerAction.RAISE, min(raise_amount, round_state.max_raise)
            else:
                return PokerAction.ALL_IN, remaining_chips

        # Decision to Call
        if hand_score >= call_threshold and amount_to_call > 0:
            if remaining_chips > amount_to_call:
                return PokerAction.CALL, amount_to_call
            else:
                return PokerAction.ALL_IN, remaining_chips

        # Decision to Check or Fold
        if can_check:
            return PokerAction.CHECK, 0
        
        return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, num_active_players: int, amount_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        """Determines the action to take after the flop."""
        if num_active_players <= 1:
            return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0
        
        # Estimate win rate using Monte Carlo simulation
        win_rate = self._estimate_win_rate(
            my_hand=self.hand,
            community_cards=round_state.community_cards,
            num_opponents=num_active_players - 1,
            nb_simulations=150 # Balance of speed and accuracy
        )

        pot_size = round_state.pot
        pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9) if amount_to_call > 0 else 0

        # Go all-in with monster hands and a reasonable stack-to-pot ratio
        if win_rate > 0.9 and (remaining_chips < pot_size * 2 or round_state.round == 'River'):
             return PokerAction.ALL_IN, remaining_chips

        if can_check:
            # Bet for value if we have a strong hand
            if win_rate > 0.75:
                bet_amount = int(pot_size * 0.7)
            elif win_rate > 0.5:
                bet_amount = int(pot_size * 0.5)
            else:
                # Check marginal or weak hands, hoping to see a free card or get to showdown
                return PokerAction.CHECK, 0
            
            # Make the bet if we decided to
            bet_amount = max(round_state.min_raise, bet_amount)
            return PokerAction.RAISE, min(bet_amount, round_state.max_raise)
        
        else: # Facing a bet
            # Raise for value with very strong hands
            if win_rate > 0.8 or (win_rate > 0.7 and round_state.round == 'River'):
                raise_amount = amount_to_call + pot_size # Pot-sized raise
                raise_amount = max(round_state.min_raise, int(raise_amount))
                return PokerAction.RAISE, min(raise_amount, round_state.max_raise)

            # Call if the pot odds are favorable
            if win_rate > pot_odds:
                if remaining_chips > amount_to_call:
                    return PokerAction.CALL, amount_to_call
                else:
                    return PokerAction.ALL_IN, remaining_chips
            
            # Fold if odds are not in our favor
            return PokerAction.FOLD, 0

    def _evaluate_preflop_hand(self, hand: List[str]) -> float:
        """Evaluates pre-flop hand strength using a Chen-formula-like point system."""
        card1, card2 = hand
        rank1_str, suit1 = card1[0], card1[1]
        rank2_str, suit2 = card2[0], card2[1]

        rank1 = RANK_VALUES[rank1_str]
        rank2 = RANK_VALUES[rank2_str]

        high_card_rank = max(rank1, rank2)
        score = 0
        if high_card_rank == RANK_VALUES['A']: score = 10
        elif high_card_rank == RANK_VALUES['K']: score = 8
        elif high_card_rank == RANK_VALUES['Q']: score = 7
        elif high_card_rank == RANK_VALUES['J']: score = 6
        else: score = (high_card_rank + 2) / 2.0

        is_pair = (rank1 == rank2)
        if is_pair:
            score *= 2
            if score < 5: score = 5  # Min score for any pair is 5

        if suit1 == suit2:
            score += 2

        gap = abs(rank1 - rank2) - 1
        if not is_pair:
            if gap == 0: pass
            elif gap == 1: score -= 1
            elif gap == 2: score -= 2
            elif gap == 3: score -= 4
            else: score -= 5
        
        if not is_pair and gap < 2 and high_card_rank < RANK_VALUES['Q']:
            score += 1
            
        return score

    def _estimate_win_rate(self, my_hand: List[str], community_cards: List[str], num_opponents: int, nb_simulations: int) -> float:
        """Estimates win rate using Monte Carlo simulation."""
        wins = 0
        
        deck = [r + s for r in RANKS for s in SUITS]
        
        known_cards = set(my_hand) | set(community_cards)
        for card in known_cards:
            if card in deck:
                deck.remove(card)
        
        for _ in range(nb_simulations):
            sim_deck = deck[:]
            random.shuffle(sim_deck)
            
            opponents_hands = [sim_deck[i*2:i*2+2] for i in range(num_opponents)]
            cards_drawn = num_opponents * 2
            
            num_community_to_draw = 5 - len(community_cards)
            sim_community = community_cards + sim_deck[cards_drawn:cards_drawn + num_community_to_draw]
            
            my_best_rank = self._eval_7_cards(my_hand + sim_community)
            
            opp_best_rank = (-1, [])
            is_winner = True
            for opp_hand in opponents_hands:
                opp_rank = self._eval_7_cards(opp_hand + sim_community)
                if self._compare_hands(my_best_rank, opp_rank) < 0:
                    is_winner = False
                    break
            
            if is_winner:
                wins += 1
        
        return wins / nb_simulations if nb_simulations > 0 else 0

    def _eval_7_cards(self, cards: List[str]) -> Tuple:
        """Evaluates the best 5-card hand from a list of 7 cards."""
        best_rank = (-1, [])
        for hand_combo in itertools.combinations(cards, 5):
            current_rank = self._get_hand_rank(list(hand_combo))
            if self._compare_hands(current_rank, best_rank) > 0:
                best_rank = current_rank
        return best_rank

    def _get_hand_rank(self, hand: List[str]) -> Tuple:
        """Calculates the rank of a 5-card hand, returning a tuple for comparison."""
        values = sorted([RANK_VALUES[c[0]] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        is_flush = len(set(suits)) == 1
        
        unique_values = sorted(list(set(values)), reverse=True)
        is_straight = len(unique_values) == 5 and (unique_values[0] - unique_values[4] == 4)
        # Ace-low straight
        if not is_straight and unique_values == [RANK_VALUES['A'], RANK_VALUES['5'], RANK_VALUES['4'], RANK_VALUES['3'], RANK_VALUES['2']]:
            is_straight = True
            values = [RANK_VALUES['5'], RANK_VALUES['4'], RANK_VALUES['3'], RANK_VALUES['2'], -1] # Ace as low card

        if is_straight and is_flush:
            if values[0] == RANK_VALUES['A']: return (ROYAL_FLUSH, values)
            return (STRAIGHT_FLUSH, values)

        counts = {v: values.count(v) for v in unique_values}
        rank_counts = sorted(counts.values(), reverse=True)
        
        if rank_counts[0] == 4:
            four = [k for k, v in counts.items() if v == 4][0]
            kicker = [v for v in values if v != four][0]
            return (FOUR_OF_A_KIND, [four, kicker])

        if rank_counts == [3, 2]:
            three = [k for k, v in counts.items() if v == 3][0]
            pair = [k for k, v in counts.items() if v == 2][0]
            return (FULL_HOUSE, [three, pair]) 

        if is_flush:
            return (FLUSH, values)

        if is_straight:
            return (STRAIGHT, values)

        if rank_counts[0] == 3:
            three = [k for k, v in counts.items() if v == 3][0]
            kickers = sorted([v for v in values if v != three], reverse=True)
            return (THREE_OF_A_KIND, [three] + kickers)

        if rank_counts == [2, 2, 1]:
            pairs = sorted([k for k, v in counts.items() if v == 2], reverse=True)
            kicker = [k for k, v in counts.items() if v == 1][0]
            return (TWO_PAIR, pairs + [kicker])
        
        if rank_counts[0] == 2:
            pair = [k for k, v in counts.items() if v == 2][0]
            kickers = sorted([v for v in values if v != pair], reverse=True)
            return (ONE_PAIR, [pair] + kickers)

        return (HIGH_CARD, values)

    def _compare_hands(self, hand1: Tuple, hand2: Tuple) -> int:
        """Compares two hand ranks. Returns >0 if hand1 is better, <0 if hand2 is better, 0 for a tie."""
        rank1, values1 = hand1
        rank2, values2 = hand2
        
        if rank1 != rank2:
            return rank1 - rank2
        
        # Compare kickers
        for v1, v2 in zip(values1, values2):
            if v1 != v2:
                return v1 - v2
        
        return 0