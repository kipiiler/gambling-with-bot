from typing import List, Tuple, Dict, Any
from collections import Counter
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_MAP = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
    '7': 7, '8': 8, '9': 9, 'T': 10,
    'J': 11, 'Q': 12, 'K': 13, 'A': 14
}

CHEN_BASE = {
    14: 10.0,  # A
    13: 8.0,   # K
    12: 7.0,   # Q
    11: 6.0,   # J
    10: 5.0,   # T
    9: 4.5,
    8: 4.0,
    7: 3.5,
    6: 3.0,
    5: 2.5,
    4: 2.0,
    3: 1.5,
    2: 1.0
}

# Hand category ranking (higher is stronger)
CATEGORY_STRENGTH = {
    'straight_flush': 0.99,
    'four_kind': 0.95,
    'full_house': 0.90,
    'flush': 0.80,
    'straight': 0.75,
    'three_kind': 0.65,
    'two_pair': 0.58,
    'one_pair': 0.45,
    'high_card': 0.20
}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.my_hole_cards: List[str] = []  # Updated each hand in on_round_start if available
        self.round_number = 0
        self.random = random.Random(1337)  # deterministic randomness
        self.debug = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # player_hands may not be provided here in some engines; keep placeholder
        self.my_hole_cards = player_hands[:] if player_hands else []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_number = round_state.round_num
        # Some engines may pass our hole cards via player_actions or a separate call; here we keep the latest known
        # Ensure hole cards reset between hands if not provided
        # We'll rely on external game server to supply hole cards where applicable

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_id_str = str(self.id)
            my_bet = round_state.player_bets.get(my_id_str, 0) if round_state.player_bets else 0
            current_bet = max(0, round_state.current_bet)
            to_call = max(0, current_bet - my_bet)

            min_raise = max(0, round_state.min_raise)
            max_raise = max(0, min(round_state.max_raise, remaining_chips))

            pot = max(0, round_state.pot)
            community = round_state.community_cards or []
            stage = (round_state.round or '').lower()  # 'preflop','flop','turn','river' expected

            num_active = self._estimate_active_players(round_state)
            # guard
            num_active = max(1, num_active)

            # If we don't have our hole cards via this interface, try to find from actions if provided (not guaranteed)
            # We'll assume self.my_hole_cards is set externally; if not, act conservatively
            hole = self.my_hole_cards if self.my_hole_cards else []

            # Decide action based on stage
            if stage.startswith('pre'):
                strength = self._preflop_strength(hole) if len(hole) == 2 else 0.3  # conservative default
                action, amount = self._decide_preflop_action(strength, to_call, min_raise, max_raise, pot, remaining_chips, num_active)
            else:
                made_strength, info = self._postflop_strength(hole, community)
                # Draw bonuses
                draw_bonus = 0.0
                if info.get('flush_draw', False):
                    draw_bonus += 0.12
                if info.get('open_ended', False):
                    draw_bonus += 0.10
                elif info.get('gutshot', False):
                    draw_bonus += 0.05

                # If best hand is purely on board, reduce value
                if info.get('board_dominates', False):
                    made_strength = min(made_strength, 0.35)

                strength = min(1.0, max(0.0, made_strength + draw_bonus))
                action, amount = self._decide_postflop_action(strength, to_call, min_raise, max_raise, pot, remaining_chips, num_active, info, stage)

            # Final safety checks
            if action == PokerAction.CHECK:
                # Only check if there is nothing to call
                if to_call > 0:
                    # fallback to CALL if affordable else FOLD/ALL_IN
                    if to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
            elif action == PokerAction.CALL:
                if to_call == 0:
                    # No one bet; checking is safer than calling 0 (might be invalid in some engines)
                    return (PokerAction.CHECK, 0)
                if to_call > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
            elif action == PokerAction.RAISE:
                # Ensure raise amount is within bounds
                if min_raise <= 0 or max_raise <= 0 or amount < min_raise:
                    # Cannot raise; fallback to CALL/CHECK
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                amount = int(max(min_raise, min(amount, max_raise)))
                if amount < min_raise:
                    # Still invalid
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
            elif action == PokerAction.ALL_IN:
                # Always allowed; nothing to clamp
                pass
            elif action == PokerAction.FOLD:
                # If we can check for free, prefer check
                if to_call == 0:
                    return (PokerAction.CHECK, 0)

            return (action, int(amount))
        except Exception:
            # In case of any unexpected error, be conservative: if we can check, check; else fold to avoid penalties
            try:
                my_bet = round_state.player_bets.get(str(self.id), 0) if round_state.player_bets else 0
                to_call = max(0, round_state.current_bet - my_bet)
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand data if needed
        self.my_hole_cards = []  # will be set again by platform when next hand starts if available

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could log or adapt strategy; keep lightweight
        pass

    # =============================
    # Strategy helpers
    # =============================

    def _estimate_active_players(self, round_state: RoundStateClient) -> int:
        # Estimate number of players still in the hand (not folded)
        if not self.all_players:
            # Fallback: use the players who have any action entry unless folded
            actions = round_state.player_actions or {}
            active = 0
            seen_ids = set()
            for pid_str, act in actions.items():
                seen_ids.add(pid_str)
                if str(act).lower() != 'fold':
                    active += 1
            # If we have some current players list, include them as active
            if round_state.current_player:
                active = max(active, len(round_state.current_player))
            return max(2, active) if active > 0 else 2
        actions = round_state.player_actions or {}
        active = 0
        for pid in self.all_players:
            act = actions.get(str(pid), None)
            if act is None:
                active += 1  # hasn't folded
            else:
                if str(act).lower() != 'fold':
                    active += 1
        return max(2, active)

    def _decide_preflop_action(self, strength: float, to_call: int, min_raise: int, max_raise: int, pot: int, stack: int, num_active: int) -> Tuple[PokerAction, int]:
        # Adjust strength for multiway pots (decrease with more opponents)
        if num_active > 2:
            strength = max(0.0, strength - 0.06 * (num_active - 2))

        # To avoid spew when short-stacked, tighten up
        if stack < max(20 * self.blind_amount, 1):
            strength *= 1.05  # slightly more shovey

        # If nothing to call: consider open-raise
        if to_call == 0:
            if strength >= 0.70:
                # Strong hands: 3-4x open
                target = max(min_raise, int(3.5 * (min_raise if min_raise > 0 else max(1, self.blind_amount))))
                return self._safe_raise(min_raise, max_raise, target)
            elif strength >= 0.50:
                # Medium hands: 2.5-3x open or check behind if min_raise is big and we want pot control
                if min_raise <= 0 or max_raise <= 0:
                    return (PokerAction.CHECK, 0)
                target = max(min_raise, int(2.5 * (min_raise if min_raise > 0 else max(1, self.blind_amount))))
                # Randomize between raise and check to mix strategy if possible to check
                if pot == 0 and self.random.random() < 0.15:
                    return (PokerAction.CHECK, 0)
                return self._safe_raise(min_raise, max_raise, target)
            else:
                # Weak hands: check
                return (PokerAction.CHECK, 0)

        # Facing a bet
        # Pot odds
        denom = pot + to_call + 1e-9
        pot_odds = to_call / denom

        # If all-in (can't cover call)
        if to_call >= stack:
            if strength >= 0.62:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)

        # 3-bet / isolation with strong hands
        if strength >= 0.80 and min_raise > 0 and max_raise > 0:
            # Size: ~3x raise or 0.6 pot
            target = max(int(3.0 * max(min_raise, to_call)), int(0.6 * (pot + to_call)))
            target = max(min_raise, target)
            if target > max_raise:
                if stack - to_call < max(min_raise, 1):
                    return (PokerAction.ALL_IN, 0)
                # else fall back to call if cannot properly raise
                return (PokerAction.CALL, 0)
            return (PokerAction.RAISE, int(target))

        # Call if equity justifies pot odds
        if strength >= pot_odds + 0.05:
            # Occasionally raise as a semi-bluff/value
            if strength >= 0.65 and min_raise > 0 and max_raise > 0 and self.random.random() < 0.25:
                target = max(int(2.5 * max(min_raise, to_call)), int(0.6 * (pot + to_call)))
                target = min(target, max_raise)
                if target >= min_raise:
                    return (PokerAction.RAISE, int(target))
            return (PokerAction.CALL, 0)

        # Otherwise fold marginal hands
        return (PokerAction.FOLD, 0)

    def _decide_postflop_action(self, strength: float, to_call: int, min_raise: int, max_raise: int, pot: int, stack: int, num_active: int, info: Dict[str, Any], stage: str) -> Tuple[PokerAction, int]:
        # Heuristic aggression factors
        very_strong = strength >= 0.80
        strong = strength >= 0.68
        medium = strength >= 0.50
        weak = strength < 0.35

        # If nothing to call, consider betting
        if to_call == 0:
            if very_strong:
                # Value bet ~65-80% pot
                target = self._bet_pot_fraction(0.7 + 0.1 * self.random.random(), pot)
                return self._safe_raise(min_raise, max_raise, target)
            elif strong:
                # Value bet ~50-70% pot
                target = self._bet_pot_fraction(0.55 + 0.1 * self.random.random(), pot)
                return self._safe_raise(min_raise, max_raise, target)
            elif medium:
                # Thin value or pot control: sometimes bet small
                if self.random.random() < 0.45:
                    target = self._bet_pot_fraction(0.45, pot)
                    return self._safe_raise(min_raise, max_raise, target)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Bluff draws sometimes on flop/turn
                if (info.get('flush_draw') or info.get('open_ended') or info.get('gutshot')) and stage in ('flop', 'turn'):
                    if self.random.random() < 0.55:
                        target = self._bet_pot_fraction(0.5, pot)
                        return self._safe_raise(min_raise, max_raise, target)
                return (PokerAction.CHECK, 0)

        # Facing a bet
        denom = pot + to_call + 1e-9
        pot_odds = to_call / denom

        # If we cannot cover the call -> decide to go all-in or fold
        if to_call >= stack:
            if strong or very_strong or (info.get('flush_draw') and stage in ('flop', 'turn')) or (info.get('open_ended') and stage in ('flop', 'turn')):
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)

        # With very strong hands, raise for value
        if very_strong and min_raise > 0 and max_raise > 0:
            target = max(int(2.5 * max(min_raise, to_call)), int(0.65 * (pot + to_call)))
            target = min(target, max_raise)
            if target >= min_raise:
                return (PokerAction.RAISE, int(target))
            else:
                return (PokerAction.CALL, 0)

        # Strong hands: mix raises and calls
        if strong:
            if min_raise > 0 and max_raise > 0 and self.random.random() < 0.45:
                target = max(int(2.2 * max(min_raise, to_call)), int(0.55 * (pot + to_call)))
                target = min(target, max_raise)
                if target >= min_raise:
                    return (PokerAction.RAISE, int(target))
            return (PokerAction.CALL, 0)

        # Drawing hands: consider semi-bluff raises or calls with good odds
        drawing = info.get('flush_draw') or info.get('open_ended') or info.get('gutshot')
        if drawing and stage in ('flop', 'turn'):
            # Rough equity assumptions: flush/open-ended ~32-36% (8-9 outs to turn, 15-18 to river), gutshot ~16-18%
            draw_equity = 0.35 if (info.get('flush_draw') or info.get('open_ended')) else 0.18
            effective_equity = max(strength, draw_equity)
            if effective_equity >= pot_odds + 0.04:
                # Sometimes raise as semi-bluff
                if min_raise > 0 and max_raise > 0 and self.random.random() < 0.35:
                    target = max(int(2.2 * max(min_raise, to_call)), int(0.55 * (pot + to_call)))
                    target = min(target, max_raise)
                    if target >= min_raise:
                        return (PokerAction.RAISE, int(target))
                return (PokerAction.CALL, 0)
            else:
                # If odds are bad, fold weakest gutshots
                if info.get('gutshot') and not info.get('flush_draw') and not info.get('open_ended'):
                    return (PokerAction.FOLD, 0)
                # Otherwise call occasionally to realize equity if cheap
                if to_call <= max(self.blind_amount, 1) and self.random.random() < 0.5:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        # Medium strength: call if pot odds are decent
        if medium:
            if strength >= pot_odds + 0.03:
                return (PokerAction.CALL, 0)
            else:
                # Occasionally bluff-raise to deny equity if allowed
                if min_raise > 0 and max_raise > 0 and self.random.random() < 0.15:
                    target = max(int(2.0 * max(min_raise, to_call)), int(0.5 * (pot + to_call)))
                    target = min(target, max_raise)
                    if target >= min_raise:
                        return (PokerAction.RAISE, int(target))
                return (PokerAction.FOLD, 0)

        # Weak hands: fold unless very cheap call with implied odds
        if weak:
            cheap_threshold = max(self.blind_amount, int(0.08 * max(pot, 1)))
            if to_call <= cheap_threshold and self.random.random() < 0.25:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # Default safe
        return (PokerAction.CALL, 0)

    def _safe_raise(self, min_raise: int, max_raise: int, target: int) -> Tuple[PokerAction, int]:
        if min_raise <= 0 or max_raise <= 0:
            return (PokerAction.CHECK, 0)
        amount = int(max(min_raise, min(target, max_raise)))
        if amount < min_raise:
            return (PokerAction.CHECK, 0)
        return (PokerAction.RAISE, amount)

    def _bet_pot_fraction(self, frac: float, pot: int) -> int:
        frac = max(0.1, min(frac, 1.2))
        return max(1, int(frac * max(0, pot)))

    # =============================
    # Hand evaluation helpers
    # =============================

    def _preflop_strength(self, hole: List[str]) -> float:
        if len(hole) != 2:
            return 0.3
        r1, s1 = hole[0][0], hole[0][-1]
        r2, s2 = hole[1][0], hole[1][-1]
        a = RANK_MAP.get(r1, 2)
        b = RANK_MAP.get(r2, 2)
        high = max(a, b)
        low = min(a, b)
        suited = (s1 == s2)
        pair = (a == b)
        gap = max(0, abs(a - b) - 1)

        # Chen formula approximation
        base = CHEN_BASE.get(high, 1.0)
        if pair:
            score = max(5.0, 2 * base)
        else:
            score = base
            if suited:
                score += 2.0
            # gap penalties
            if gap == 0:
                pass
            elif gap == 1:
                score -= 1.0
            elif gap == 2:
                score -= 2.0
            elif gap == 3:
                score -= 4.0
            else:
                score -= 5.0
            # straight bonus when connected and both below Q
            if gap == 0 and high < 12:
                score += 1.0
            elif gap == 1 and high < 12:
                score += 0.5

        # Additional tweak: small pairs get modest boost preflop heads-up
        # Already captured by Chen; keep as is

        # Clamp and normalize to [0,1] roughly (AA ~20 => 1.0)
        score = max(0.0, min(score, 20.0))
        strength = score / 20.0
        return float(max(0.0, min(1.0, strength)))

    def _postflop_strength(self, hole: List[str], board: List[str]) -> Tuple[float, Dict[str, Any]]:
        cards = []
        for c in hole:
            if len(c) >= 2 and c[0] in RANK_MAP:
                cards.append(c)
        for c in board:
            if len(c) >= 2 and c[0] in RANK_MAP:
                cards.append(c)
        made_cat = self._best_category(cards)
        board_cat = self._best_category(board) if len(board) >= 3 else 'high_card'

        info = self._draw_info(hole, board)
        board_dominates = self._category_rank(board_cat) >= self._category_rank(made_cat)
        info['board_dominates'] = board_dominates

        strength = CATEGORY_STRENGTH.get(made_cat, 0.2)
        return strength, info

    def _best_category(self, cards: List[str]) -> str:
        # Determine best category among 7 cards set (or fewer).
        if not cards:
            return 'high_card'
        ranks = [RANK_MAP.get(c[0], 2) for c in cards]
        suits = [c[-1] for c in cards]
        rank_counter = Counter(ranks)
        suit_counter = Counter(suits)
        max_suit, max_suit_count = ('', 0)
        for s, cnt in suit_counter.items():
            if cnt > max_suit_count:
                max_suit, max_suit_count = s, cnt

        # Straight and straight-flush detection
        unique_ranks = set(ranks)
        # Ace low handling
        if 14 in unique_ranks:
            unique_ranks.add(1)
        straight_high = self._has_straight_high(unique_ranks)

        # Straight flush
        if max_suit_count >= 5:
            suit_ranks = [RANK_MAP.get(c[0], 2) for c in cards if c[-1] == max_suit]
            suit_set = set(suit_ranks)
            if 14 in suit_set:
                suit_set.add(1)
            if self._has_straight_high(suit_set) is not None:
                return 'straight_flush'

        # Four of a kind
        if any(cnt >= 4 for cnt in rank_counter.values()):
            return 'four_kind'

        # Full house
        trips = [r for r, cnt in rank_counter.items() if cnt >= 3]
        pairs = [r for r, cnt in rank_counter.items() if cnt >= 2 and r not in trips]
        if len(trips) >= 1 and (len(pairs) >= 1 or len(trips) >= 2):
            return 'full_house'

        # Flush
        if max_suit_count >= 5:
            return 'flush'

        # Straight
        if straight_high is not None:
            return 'straight'

        # Three of a kind
        if len(trips) >= 1:
            return 'three_kind'

        # Two pair
        if len([r for r, cnt in rank_counter.items() if cnt >= 2]) >= 2:
            return 'two_pair'

        # One pair
        if any(cnt >= 2 for cnt in rank_counter.values()):
            return 'one_pair'

        # High card
        return 'high_card'

    def _has_straight_high(self, unique_ranks: set) -> int or None:
        if not unique_ranks:
            return None
        seq = sorted(unique_ranks)
        longest = 1
        current = 1
        last = None
        best_high = None
        for r in seq:
            if last is None:
                current = 1
                best_high = r
            else:
                if r == last + 1:
                    current += 1
                    best_high = r
                elif r != last:
                    current = 1
                    best_high = r
            if current >= 5:
                return best_high
            last = r
        return None

    def _category_rank(self, cat: str) -> int:
        order = ['high_card', 'one_pair', 'two_pair', 'three_kind', 'straight', 'flush', 'full_house', 'four_kind', 'straight_flush']
        try:
            return order.index(cat)
        except ValueError:
            return 0

    def _draw_info(self, hole: List[str], board: List[str]) -> Dict[str, Any]:
        info = {'flush_draw': False, 'open_ended': False, 'gutshot': False}
        cards = []
        for c in hole:
            if len(c) >= 2 and c[0] in RANK_MAP:
                cards.append(c)
        for c in board:
            if len(c) >= 2 and c[0] in RANK_MAP:
                cards.append(c)
        if not cards:
            return info

        suits = [c[-1] for c in cards]
        suit_counter = Counter(suits)
        # Flush draw (exactly 4 to a suit among hole+board)
        if any(cnt == 4 for cnt in suit_counter.values()):
            info['flush_draw'] = True

        # Straight draws using unique ranks
        ranks = [RANK_MAP.get(c[0], 2) for c in cards]
        uniq = set(ranks)
        if 14 in uniq:
            uniq.add(1)
        # Check 5-card windows for missing 1 (open-ended/gutshot)
        for start in range(1, 11):  # 1..10 as starting rank for 5-card sequence
            window = set(range(start, start + 5))
            missing = len(window - uniq)
            if missing == 1:
                # Open-ended if missing is at either end (start or start+4)
                if (start not in uniq) or ((start + 4) not in uniq):
                    info['open_ended'] = True
                else:
                    info['gutshot'] = True
            elif missing == 0:
                # Already a straight: don't mark draws
                pass
        return info