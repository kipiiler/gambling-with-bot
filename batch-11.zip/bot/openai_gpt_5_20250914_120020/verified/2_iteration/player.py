from typing import List, Tuple, Dict, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.blind_amount: int = 10  # we will treat as a base blind hint if provided
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Hand/round state
        self.hole_cards: List[str] = []  # our two cards if provided
        self.was_preflop_raiser: bool = False
        self.preflop_tier: int = 4  # default weakest
        self.last_round_num: int = -1

        # Helper constants
        self.eps: float = 1e-9

        # Preflop tiers sets
        self.tier1_pairs = {"AA", "KK", "QQ", "JJ", "TT"}
        self.tier1_broadway = {"AKs", "AQs", "AKo"}

        self.tier2_pairs = {"99", "88"}
        self.tier2_broadway = {"AJs", "AQo", "KQs", "KQo", "ATs", "KJs", "QJs", "JTs"}

        self.tier3_pairs = {"77", "66"}
        self.tier3_suited = {"ATo", "KJo", "QJo", "T9s", "98s", "87s", "76s",
                              "A9s", "A8s", "A7s", "A6s", "A5s", "KTs", "QTs", "J9s"}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize for a new hand/game start
        try:
            self.starting_chips = starting_chips
        except Exception:
            self.starting_chips = self.starting_chips or 0

        # Store hole cards if provided (expected 2 cards like ['As','Kd'])
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.hole_cards = player_hands[:2]
            self.preflop_tier = self._compute_preflop_tier(self.hole_cards)
        else:
            # If not provided, keep previous or empty
            if not self.hole_cards:
                self.hole_cards = []

        # Blind amount hint (can be small blind; we will use as generic base)
        if isinstance(blind_amount, int) and blind_amount > 0:
            self.blind_amount = blind_amount

        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if isinstance(all_players, list) else []

        # Reset per-hand flags
        self.was_preflop_raiser = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # If we detect a new hand via round_num, reset flags
        if round_state is None:
            return
        if round_state.round_num != self.last_round_num:
            self.was_preflop_raiser = False
            # Keep hole cards; some environments may refresh them on_start only
            # If we somehow receive hole cards later via a custom mechanism, we would update here.
            self.last_round_num = round_state.round_num

        # Recompute tier if we have hole cards and it's preflop
        if round_state.round.lower() == 'preflop':
            if self.hole_cards and len(self.hole_cards) >= 2:
                self.preflop_tier = self._compute_preflop_tier(self.hole_cards)
            else:
                self.preflop_tier = 4

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            if round_state is None:
                return (PokerAction.CHECK, 0)

            my_id_str = str(self.id) if self.id is not None else ""
            player_bets: Dict[str, int] = round_state.player_bets or {}
            my_bet = int(player_bets.get(my_id_str, 0) or 0)

            current_bet = int(round_state.current_bet or 0)
            call_amount = max(0, current_bet - my_bet)

            pot = int(round_state.pot or 0)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)

            # Determine stage
            stage = (round_state.round or "").lower()  # 'preflop', 'flop', 'turn', 'river'
            bb_guess = max(int(self.blind_amount or 10), 2)  # a conservative blind guess

            # Allowed actions sanity
            can_check = (call_amount <= 0)
            can_call = (call_amount > 0 and call_amount <= max(0, remaining_chips))
            can_raise = (min_raise > 0 and max_raise >= min_raise)
            can_all_in = remaining_chips > 0

            # Fallback if not allowed to call (i.e., price > stack): then it's a de-facto all-in or fold
            if call_amount > remaining_chips and can_all_in:
                # Decide whether to call-off with all-in (very conservative)
                # Only do so with premium preflop or on later streets with very small SPR
                if stage == 'preflop':
                    if self.preflop_tier <= 1:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Postflop: allow call-off only if pot >> stack (SPR < ~0.5)
                    spr = (remaining_chips + self.eps) / (pot + self.eps)
                    if spr < 0.5 and self.preflop_tier <= 2:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.FOLD, 0)

            # PRE-FLOP strategy
            if stage == 'preflop':
                # If we don't know our cards, default tight-passive
                if not self.hole_cards or len(self.hole_cards) < 2:
                    if can_check:
                        # Check when free
                        return (PokerAction.CHECK, 0)
                    # Call only very small amounts; else fold
                    if call_amount <= min(bb_guess, max(10, int(0.01 * max(remaining_chips, 1)))):
                        if can_call:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)

                # We have hole cards, use tiered strategy
                tier = self.preflop_tier

                # Unopened pot (we can check)
                if can_check:
                    # Open raise by tier
                    if can_raise:
                        if tier <= 1:
                            # Strong open: raise minimum safe amount
                            return (PokerAction.RAISE, self._clamp_raise(min_raise, max_raise, int(3 * bb_guess)))
                        elif tier == 2:
                            # Medium open: small raise
                            return (PokerAction.RAISE, self._clamp_raise(min_raise, max_raise, int(2 * bb_guess)))
                        elif tier == 3:
                            # Weak-medium: limp/check
                            return (PokerAction.CHECK, 0)
                        else:
                            # Trash: check
                            return (PokerAction.CHECK, 0)
                    else:
                        # Can't raise, just check
                        return (PokerAction.CHECK, 0)
                else:
                    # Facing a raise preflop
                    if tier <= 1:
                        # Strong hand: 3-bet if allowed, else call
                        if can_raise:
                            target = max(min_raise, call_amount + int(2 * bb_guess))
                            return (PokerAction.RAISE, self._clamp_raise(min_raise, max_raise, target))
                        elif can_call:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    elif tier == 2:
                        # Medium: call small raises, fold to large
                        threshold = max(2 * bb_guess, int(0.03 * max(remaining_chips, 1)))
                        if call_amount <= threshold:
                            if can_call:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    elif tier == 3:
                        # Weak-medium: call only minuscule raises
                        threshold = max(bb_guess, int(0.015 * max(remaining_chips, 1)))
                        if call_amount <= threshold and can_call:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Trash: fold to any raise
                        return (PokerAction.FOLD, 0)

            # POST-FLOP strategy
            else:
                # Defensive postflop: pot control; small c-bet when we were preflop raiser
                if can_check:
                    # Consider a small continuation bet only if we were the aggressor and allowed to raise
                    if self.was_preflop_raiser and can_raise:
                        # C-bet small with decent hand tiers; otherwise check
                        if self.preflop_tier <= 2:
                            # Attempt a small raise-size bet
                            target = max(min_raise, int(0.3 * max(pot, 1)))
                            return (PokerAction.RAISE, self._clamp_raise(min_raise, max_raise, target))
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet postflop: use pot-odds heuristics
                    # Call thresholds by tier
                    if pot <= 0:
                        pot = call_amount  # minimal safeguard

                    # Determine max fraction of pot we're willing to call
                    if self.preflop_tier <= 1:
                        max_frac = 0.5  # stronger: call up to 50% pot
                    elif self.preflop_tier == 2:
                        max_frac = 0.3
                    elif self.preflop_tier == 3:
                        max_frac = 0.2
                    else:
                        max_frac = 0.12

                    max_call = max(int(max_frac * pot), int(0.015 * max(remaining_chips, 1)))
                    if call_amount <= max_call and can_call:
                        return (PokerAction.CALL, 0)
                    else:
                        # Consider a bluff-raise very rarely only when allowed and very small min_raise compared to pot
                        if can_raise and self.preflop_tier <= 2 and call_amount <= int(0.15 * pot):
                            target = max(min_raise, int(0.5 * pot))
                            return (PokerAction.RAISE, self._clamp_raise(min_raise, max_raise, target))
                        return (PokerAction.FOLD, 0)

        except Exception:
            # Any error, default to safe action to avoid auto-fold penalties
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Reset hand-specific aggressor flag at the end of a full hand
        # Keep hole_cards as they may be updated on next on_start
        self.was_preflop_raiser = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent learning across games in this simple bot
        pass

    # ---------------- Helper methods ---------------- #

    def _clamp_raise(self, min_raise: int, max_raise: int, target: int) -> int:
        """Clamp desired raise to valid range. Falls back to min_raise if needed."""
        if max_raise < min_raise:
            return max_raise
        # Ensure target is within bounds
        if target < min_raise:
            return min_raise
        if target > max_raise:
            return max_raise
        return target

    def _compute_preflop_tier(self, hole_cards: List[str]) -> int:
        """Compute a rough preflop tier (1 strongest to 4 weakest) for the two cards."""
        try:
            if not hole_cards or len(hole_cards) < 2:
                return 4
            c1, c2 = hole_cards[0], hole_cards[1]
            rank_order = "23456789TJQKA"
            r1, s1 = c1[0], c1[1]
            r2, s2 = c2[0], c2[1]
            # Normalize order high-first
            if rank_order.index(r2) > rank_order.index(r1):
                r1, r2 = r2, r1
                s1, s2 = s2, s1

            suited = (s1 == s2)
            if r1 == r2:
                pair = r1 + r2
                if pair in self.tier1_pairs:
                    return 1
                if pair in self.tier2_pairs:
                    return 2
                if pair in self.tier3_pairs:
                    return 3
                return 4

            combo = f"{r1}{r2}{'s' if suited else 'o'}"
            if combo in self.tier1_broadway:
                return 1
            if combo in self.tier2_broadway:
                return 2
            if combo in self.tier3_suited:
                return 3

            # Additional simple heuristics
            # High card A/K with decent kicker
            if r1 == 'A':
                if suited and r2 in "TQJ9":
                    return 2
                if r2 in "QJT":
                    return 3
                return 4
            if r1 == 'K':
                if suited and r2 in "QJT":
                    return 3
                if r2 in "QJ":
                    return 3
                return 4
            if suited and r1 in "QJT" and r2 in "T987":
                return 3

            return 4
        except Exception:
            return 4

    # Override get_action to track if we raised preflop
    def _postprocess_action(self, action: Tuple[PokerAction, int], stage: str) -> Tuple[PokerAction, int]:
        """Track aggressor flags based on action."""
        try:
            a, amt = action
            if stage == 'preflop' and a == PokerAction.RAISE:
                self.was_preflop_raiser = True
        except Exception:
            pass
        return action

    # Ensure our get_action uses postprocess
    def _safe_return(self, round_state: RoundStateClient, action: Tuple[PokerAction, int]) -> Tuple[PokerAction, int]:
        stage = (round_state.round or "").lower() if round_state else ""
        return self._postprocess_action(action, stage)