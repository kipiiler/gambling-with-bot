from typing import List, Tuple, Optional, Dict, Any
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

# Chen formula base values
CHEN_BASE = {'A': 10.0, 'K': 8.0, 'Q': 7.0, 'J': 6.0, 'T': 5.0,
             '9': 4.5, '8': 4.0, '7': 3.5, '6': 3.0, '5': 2.5,
             '4': 2.0, '3': 1.5, '2': 1.0}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game / table info
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # May be small blind or big blind, unknown; will infer from state
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Per hand state
        self.round_num: int = 0
        self.stage: str = 'Preflop'
        self.my_hole_cards: Optional[List[str]] = None
        self.preflop_aggressor: bool = False
        self.last_aggressive_street: Optional[str] = None

        # RNG
        self.rng = random.Random()

        # Opponent modeling (very light)
        self.villain_aggression_count: Dict[int, int] = {}
        self.villain_seen: set[int] = set()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game info
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players is not None else []
        # Seed RNG with deterministic seed to avoid being exploitable but still non-constant
        seed_val = (starting_chips + blind_amount + (big_blind_player_id or 0) + (small_blind_player_id or 0))
        self.rng.seed(seed_val)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand state
        self.round_num = getattr(round_state, 'round_num', 0)
        self.stage = self._normalize_round_name(getattr(round_state, 'round', 'Preflop'))
        self.my_hole_cards = self._extract_my_hole_cards(round_state)
        self.preflop_aggressor = False
        self.last_aggressive_street = None

        # Reset or update blind info if present
        # Nothing to do; blinds may change; we infer bet sizing from min_raise each street

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Defensive reads
            my_id_str = str(self.id)
            pot = max(0, int(getattr(round_state, 'pot', 0)))
            min_raise = max(0, int(getattr(round_state, 'min_raise', 0)))
            max_raise = max(0, int(getattr(round_state, 'max_raise', 0)))
            current_bet = max(0, int(getattr(round_state, 'current_bet', 0)))
            player_bets: Dict[str, int] = getattr(round_state, 'player_bets', {}) or {}
            player_actions: Dict[str, str] = getattr(round_state, 'player_actions', {}) or {}
            community_cards: List[str] = getattr(round_state, 'community_cards', []) or []
            current_players: List[int] = getattr(round_state, 'current_player', []) or []

            my_bet = int(player_bets.get(my_id_str, 0)) if my_id_str in player_bets else 0
            call_amount = max(0, current_bet - my_bet)
            can_check = (call_amount == 0)

            self.stage = self._normalize_round_name(getattr(round_state, 'round', self.stage))

            # Estimate big blind from min_raise if possible
            # Use min_raise as a proxy for BB, clamp to at least 1
            bb = max(1, min_raise if min_raise > 0 else self.blind_amount if self.blind_amount > 0 else 10)

            # Use pot-based bet sizing fallbacks
            bet_1_3_pot = max(min_raise, min(max_raise, max(1, int(0.33 * (pot + 1)))))
            bet_1_2_pot = max(min_raise, min(max_raise, max(1, int(0.50 * (pot + 1)))))
            bet_2_3_pot = max(min_raise, min(max_raise, max(1, int(0.66 * (pot + 1)))))
            bet_3_4_pot = max(min_raise, min(max_raise, max(1, int(0.75 * (pot + 1)))))

            # Compute preflop hand strength if available
            chen = None
            if self.my_hole_cards and len(self.my_hole_cards) == 2:
                chen = self._chen_score(self.my_hole_cards)

            # Determine if any raise has occurred on this street already
            street_has_raise = self._street_has_raise(player_actions)

            # Heads-up vs multiway indicator
            num_active = len(current_players) if isinstance(current_players, list) and current_players else 2

            # Decide action per street
            if self.stage == 'preflop':
                # Preflop strategy
                # - If can check (BB facing no raise): mostly check; occasionally raise
                # - If facing a bet (SB open), decide raise/call/fold by chen or random
                action, amount = self._preflop_action(
                    chen=chen,
                    can_check=can_check,
                    call_amount=call_amount,
                    min_raise=min_raise,
                    max_raise=max_raise,
                    bb=bb,
                    num_active=num_active,
                    player_actions=player_actions
                )
                # Track aggressor
                if action == PokerAction.RAISE:
                    self.preflop_aggressor = True
                    self.last_aggressive_street = 'preflop'
                return action, amount

            # Postflop strategy (flop/turn/river combined with simple heuristics)
            board = community_cards
            hand_strength = self._hand_strength_category(self.my_hole_cards, board) if self.my_hole_cards else 'unknown'

            # If no bet to us
            if can_check:
                # Decide whether to bet (raise) or check
                # C-bet logic if we were aggressor preflop
                if self.preflop_aggressor:
                    # C-bet frequency based on strength
                    if hand_strength in ('very_strong', 'strong'):
                        # Value betting
                        bet_size = bet_2_3_pot if self.stage == 'flop' else bet_1_2_pot
                        if self._can_raise(min_raise, max_raise, bet_size):
                            self.last_aggressive_street = self.stage
                            return PokerAction.RAISE, bet_size
                        else:
                            return PokerAction.CHECK, 0
                    elif hand_strength in ('medium', 'draw'):
                        # C-bet small on flop, less on later streets
                        if self.stage == 'flop' and self.rng.random() < 0.70:
                            bet_size = bet_1_3_pot
                            if self._can_raise(min_raise, max_raise, bet_size):
                                self.last_aggressive_street = self.stage
                                return PokerAction.RAISE, bet_size
                        elif self.stage in ('turn', 'river') and self.rng.random() < 0.30:
                            bet_size = bet_1_3_pot
                            if self._can_raise(min_raise, max_raise, bet_size):
                                self.last_aggressive_street = self.stage
                                return PokerAction.RAISE, bet_size
                        return PokerAction.CHECK, 0
                    else:
                        # Weak or unknown hand: occasional stab on flop only
                        if self.stage == 'flop' and self.rng.random() < 0.30:
                            bet_size = bet_1_3_pot
                            if self._can_raise(min_raise, max_raise, bet_size):
                                self.last_aggressive_street = self.stage
                                return PokerAction.RAISE, bet_size
                        return PokerAction.CHECK, 0
                else:
                    # Not aggressor pre: generally check, occasionally probe with made hands
                    if hand_strength in ('very_strong', 'strong'):
                        bet_size = bet_2_3_pot if self.stage == 'flop' else bet_1_2_pot
                        if self._can_raise(min_raise, max_raise, bet_size):
                            self.last_aggressive_street = self.stage
                            return PokerAction.RAISE, bet_size
                    elif hand_strength == 'medium' and self.stage == 'flop' and self.rng.random() < 0.30:
                        bet_size = bet_1_3_pot
                        if self._can_raise(min_raise, max_raise, bet_size):
                            self.last_aggressive_street = self.stage
                            return PokerAction.RAISE, bet_size
                    elif hand_strength == 'draw' and self.stage == 'flop' and self.rng.random() < 0.40:
                        bet_size = bet_1_3_pot
                        if self._can_raise(min_raise, max_raise, bet_size):
                            self.last_aggressive_street = self.stage
                            return PokerAction.RAISE, bet_size
                    return PokerAction.CHECK, 0
            else:
                # Facing a bet (call_amount > 0)
                # Pot odds calculation (defensive against zero)
                effective_pot = pot + 1
                call_odds = (call_amount) / (effective_pot + call_amount + 1e-9)

                # With strong hands: call or occasional raise
                if hand_strength in ('very_strong', 'strong'):
                    # Prefer call to avoid sizing pitfalls; occasionally raise on flop/turn
                    if self.stage in ('flop', 'turn') and self.rng.random() < 0.35:
                        # Choose a raise size as (call + 2x current bet) clamp within bounds
                        desired_raise_to = current_bet * 2 + max(1, int(0.25 * (pot + 1)))
                        raise_by = max(min_raise + call_amount, desired_raise_to - (round_state.player_bets.get(str(self.id), 0) or 0))
                        raise_by = min(max_raise, max(min_raise + call_amount, raise_by))
                        if raise_by >= min_raise + call_amount and raise_by <= max_raise and raise_by > 0:
                            self.last_aggressive_street = self.stage
                            return PokerAction.RAISE, raise_by
                    # Default strong line: call
                    return PokerAction.CALL, 0

                # Medium strength: call if price decent, otherwise fold
                if hand_strength == 'medium':
                    threshold = 0.35 if self.stage == 'flop' else 0.25
                    if call_odds <= threshold or self.rng.random() < 0.15:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Draws: call with good price, rarely semi-bluff raise on flop
                if hand_strength == 'draw':
                    if call_odds <= 0.25 or (self.stage == 'flop' and self.rng.random() < 0.15):
                        if self.stage == 'flop' and self.rng.random() < 0.20:
                            # Occasional semi-bluff raise
                            desired_raise_to = current_bet + max(min_raise, int(0.5 * (pot + 1)))
                            raise_by = max(min_raise + call_amount, desired_raise_to - (round_state.player_bets.get(str(self.id), 0) or 0))
                            raise_by = min(max_raise, max(min_raise + call_amount, raise_by))
                            if raise_by >= min_raise + call_amount and raise_by <= max_raise and raise_by > 0:
                                self.last_aggressive_street = self.stage
                                return PokerAction.RAISE, raise_by
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Unknown or weak hand: fold mostly; call tiny bets
                small_price_threshold = 0.12 if self.stage == 'flop' else 0.08
                if call_odds <= small_price_threshold and call_amount <= (bb * 2):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        except Exception:
            # On any unexpected error, choose a safe default action to avoid folds by exception
            # If can check we do that, else fold to avoid invalid action
            try:
                my_id_str = str(self.id)
                my_bet = int(getattr(round_state, 'player_bets', {}).get(my_id_str, 0))
                current_bet = int(getattr(round_state, 'current_bet', 0))
                call_amount = max(0, current_bet - my_bet)
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Fold safe
                    return PokerAction.FOLD, 0
            except Exception:
                # Final fallback
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Very light tracking
        self.my_hole_cards = None
        self.preflop_aggressor = False
        self.last_aggressive_street = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset between games
        self.villain_aggression_count.clear()
        self.villain_seen.clear()

    # -------------- Helper methods --------------

    def _normalize_round_name(self, round_name: str) -> str:
        if not isinstance(round_name, str):
            return 'preflop'
        r = round_name.strip().lower()
        if r in ('preflop', 'pre-flop', 'PREFLOP'.lower()):
            return 'preflop'
        if r in ('flop',):
            return 'flop'
        if r in ('turn',):
            return 'turn'
        if r in ('river',):
            return 'river'
        return r

    def _extract_my_hole_cards(self, round_state: RoundStateClient) -> Optional[List[str]]:
        # Try multiple possible places robustly
        # 1) round_state has attribute 'my_cards' or 'hole_cards'
        for attr in ('my_cards', 'hole_cards'):
            if hasattr(round_state, attr):
                try:
                    cards = getattr(round_state, attr)
                    if isinstance(cards, (list, tuple)) and len(cards) >= 2:
                        return list(cards[:2])
                except Exception:
                    pass
        # 2) round_state has 'player_hands' dict mapping player IDs to cards
        if hasattr(round_state, 'player_hands'):
            try:
                ph = getattr(round_state, 'player_hands')
                my_id_str = str(self.id)
                if isinstance(ph, dict) and my_id_str in ph:
                    cards = ph[my_id_str]
                    if isinstance(cards, (list, tuple)) and len(cards) >= 2:
                        return list(cards[:2])
                # If it's a list with exactly two strings, assume it's ours
                if isinstance(ph, list) and len(ph) == 2 and all(isinstance(c, str) for c in ph):
                    return list(ph)
            except Exception:
                pass
        # 3) on_start may have provided player_hands; not stored here across rounds
        return None

    def _street_has_raise(self, player_actions: Dict[str, str]) -> bool:
        if not player_actions:
            return False
        for v in player_actions.values():
            try:
                s = str(v).lower()
                if 'raise' in s or 'all_in' in s or 'all-in' in s or 'all in' in s:
                    return True
            except Exception:
                continue
        return False

    def _chen_score(self, cards: List[str]) -> float:
        """Approximate Chen formula for preflop strength."""
        try:
            if len(cards) < 2:
                return 0.0
            r1, s1 = cards[0][0], cards[0][-1]
            r2, s2 = cards[1][0], cards[1][-1]
            # Ensure r1 is the higher rank
            def base_val(r):
                return CHEN_BASE.get(r, 0.0)
            # Sort by base value
            if base_val(r2) > base_val(r1):
                r1, r2, s1, s2 = r2, r1, s2, s1

            # Pair
            if r1 == r2:
                val = base_val(r1) * 2
                if val < 5:
                    val = 5.0
                val += 10.0
                return val

            val = base_val(r1)

            # Suited
            suited = (s1 == s2)
            if suited:
                val += 2.0

            # Gap penalty
            gap = abs(RANK_ORDER.get(r1, 0) - RANK_ORDER.get(r2, 0)) - 1
            if gap == 0:
                pass
            elif gap == 1:
                val -= 1.0
            elif gap == 2:
                val -= 2.0
            elif gap == 3:
                val -= 4.0
            else:  # 4 or more
                val -= 5.0

            # Bonus for connected or near-connected low cards (if both below Q)
            high_is_below_Q = CHEN_BASE.get(r1, 0.0) < CHEN_BASE.get('Q', 7.0)
            if high_is_below_Q and gap <= 1 and not suited:
                val += 1.0

            # Round up to nearest half
            val = max(0.0, val)
            return val
        except Exception:
            return 0.0

    def _can_raise(self, min_raise: int, max_raise: int, desired_amount: int) -> bool:
        return max_raise > 0 and desired_amount >= max(min_raise, 1) and desired_amount <= max_raise

    def _card_rank(self, c: str) -> str:
        return c[0] if isinstance(c, str) and len(c) >= 2 else 'X'

    def _card_suit(self, c: str) -> str:
        return c[-1] if isinstance(c, str) and len(c) >= 2 else 'X'

    def _hand_strength_category(self, hole: Optional[List[str]], board: List[str]) -> str:
        """Very crude classification: very_strong, strong, medium, draw, weak, unknown."""
        if not hole or len(hole) < 2:
            return 'unknown'
        try:
            ranks_h = [self._card_rank(c) for c in hole]
            suits_h = [self._card_suit(c) for c in hole]
            ranks_b = [self._card_rank(c) for c in board]
            suits_b = [self._card_suit(c) for c in board]
            all_cards = hole + board

            # Count occurrences
            rank_counts: Dict[str, int] = {}
            for c in all_cards:
                r = self._card_rank(c)
                rank_counts[r] = rank_counts.get(r, 0) + 1

            # Suits for flush checks
            suit_counts: Dict[str, int] = {}
            for c in all_cards:
                s = self._card_suit(c)
                suit_counts[s] = suit_counts.get(s, 0) + 1

            # Made hand detection
            # - Trips or better (on 7 cards)
            max_count = max(rank_counts.values()) if rank_counts else 1
            pairs = sum(1 for v in rank_counts.values() if v >= 2)
            trips_or_more = any(v >= 3 for v in rank_counts.values())

            # Overpair detection
            overpair = False
            if ranks_h[0] == ranks_h[1] and board:
                my_rank_val = RANK_ORDER.get(ranks_h[0], 0)
                max_board_val = max(RANK_ORDER.get(r, 0) for r in ranks_b) if ranks_b else 0
                if my_rank_val > max_board_val:
                    overpair = True

            # Top/second pair: check if any hole card pairs the board
            pair_with_board = [r for r in ranks_h if r in ranks_b]
            top_pair = False
            second_pair = False
            if pair_with_board:
                board_vals = sorted([RANK_ORDER.get(r, 0) for r in ranks_b], reverse=True)
                top_board_val = board_vals[0] if board_vals else 0
                for r in pair_with_board:
                    if RANK_ORDER.get(r, 0) == top_board_val:
                        top_pair = True
                    elif RANK_ORDER.get(r, 0) >= (board_vals[1] if len(board_vals) > 1 else 0):
                        second_pair = True

            # Flush made or draw
            flush_made = any(cnt >= 5 for cnt in suit_counts.values())
            flush_draw = False
            if not flush_made:
                # If exactly 4 to a suit including at least one of our hole cards
                for s in set(suits_b + suits_h):
                    total = sum(1 for c in all_cards if self._card_suit(c) == s)
                    if total == 4 and s in suits_h:
                        flush_draw = True
                        break

            # Straight made or draw (approx)
            ranks_vals = sorted(set(RANK_ORDER.get(self._card_rank(c), 0) for c in all_cards))
            straight_made = self._has_straight(ranks_vals)
            straight_draw = False
            if not straight_made:
                straight_draw = self._has_oesd_or_gutshot(ranks_vals)

            # Classification
            if trips_or_more or flush_made or straight_made or overpair:
                return 'very_strong'
            if top_pair and (self.stage in ('flop', 'turn') or len(board) >= 3):
                return 'strong'
            if second_pair or (top_pair and self.stage == 'river'):
                return 'medium'
            if flush_draw or straight_draw:
                return 'draw'
            return 'weak'
        except Exception:
            return 'unknown'

    def _has_straight(self, ranks_vals: List[int]) -> bool:
        """Check for any 5-consecutive ranks (A can be high only in this simple algo)."""
        if not ranks_vals:
            return False
        count = 1
        for i in range(1, len(ranks_vals)):
            if ranks_vals[i] == ranks_vals[i - 1] + 1:
                count += 1
                if count >= 5:
                    return True
            elif ranks_vals[i] != ranks_vals[i - 1]:
                count = 1
        # A-5 wheel simple check
        if set([14, 5, 4, 3, 2]).issubset(set(ranks_vals)):
            return True
        return False

    def _has_oesd_or_gutshot(self, ranks_vals: List[int]) -> bool:
        """Approx detect if ranks have 4 in a 5-long window (OESD) or gutshot (4 ranks with single gap)."""
        if len(ranks_vals) < 4:
            return False
        s = set(ranks_vals)
        # OESD check: any sequence of length 4
        for start in range(2, 11):  # 2..10 as start
            window = {start, start + 1, start + 2, start + 3}
            # OESD if all four present and either start-1 or start+4 exists as outs
            if window.issubset(s):
                return True
            # Gutshot: 4 out of 5 in sequence
            window5 = {start, start + 1, start + 2, start + 3, start + 4}
            if len(window5.intersection(s)) >= 4:
                return True
        # Wheel draw A-2-3-4
        if {14, 2, 3, 4}.issubset(s):
            return True
        return False

    def _preflop_action(self, chen: Optional[float], can_check: bool, call_amount: int, min_raise: int,
                        max_raise: int, bb: int, num_active: int, player_actions: Dict[str, str]) -> Tuple[PokerAction, int]:
        """Decide preflop action with simple strategy."""
        # Determine desired open size (raise-to) in chips
        open_to = int(3.0 * bb)
        open_to = max(open_to, min_raise if min_raise > 0 else bb)
        # Convert to "raise amount": desired_to - my_bet (we don't know my_bet here; we handle in get_action when executing)
        # But our caller will directly execute the returned amount, so we must compute raise_by directly.
        # Since get_action already computed my_bet, we instead craft raise_by at call site. However we don't have my_bet here.
        # We'll instead return raise_by as a generic valid amount using min_raise; the engine should accept.
        # To better size, we return a reasonable absolute bet on empty streets using min_raise and pot fractions.
        # Preflop: If can_check (BB, no raise), we can either check or raise by a multiple of bb.
        # We approximate by sending raise_by that equals open_to when can_check (as bet size on empty round),
        # and equals call_amount + min_raise or more when facing a bet.

        # Strongness thresholds from Chen
        strong_th = 8.0
        playable_th = 6.0

        # Facing no raise (BB check option)
        if can_check:
            # Default: check most of time; raise with decent strength or occasionally bluff
            do_raise = False
            if chen is not None:
                if chen >= strong_th:
                    do_raise = True
                elif chen >= playable_th and self._rand() < 0.35:
                    do_raise = True
                elif self._rand() < 0.15:
                    do_raise = True  # occasional bluff
            else:
                # Unknown cards: raise some frequency to avoid bleeding blinds
                do_raise = self._rand() < 0.25

            if do_raise and max_raise >= max(min_raise, bb):
                raise_amount = min(max_raise, max(min_raise, open_to))
                if raise_amount >= max(min_raise, 1):
                    return PokerAction.RAISE, raise_amount
            # Otherwise check
            return PokerAction.CHECK, 0

        # Facing a raise/open (SB to act or BB facing raise)
        # Use chen to decide: raise/3bet with strong, call with medium, fold weak
        if chen is not None:
            if chen >= strong_th:
                # 3-bet size: call + (2*bb to 3*bb)
                desired = call_amount + max(min_raise, int(2.5 * bb))
                raise_by = min(max_raise, max(min_raise + call_amount, desired))
                if raise_by >= (min_raise + call_amount) and raise_by > 0:
                    return PokerAction.RAISE, raise_by
                # If cannot raise, call
                if call_amount > 0:
                    return PokerAction.CALL, 0
                return PokerAction.CHECK, 0
            elif chen >= playable_th:
                # Prefer call if affordable
                # If the raise is huge relative to bb, mix in folds
                if call_amount <= 3 * bb or self._rand() < 0.40:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hand: fold mostly; call tiny completes
                if call_amount <= bb and self._rand() < 0.25:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
        else:
            # Unknown cards: be conservative but not too nitty
            if call_amount <= bb:
                # Cheap complete/call sometimes
                if self._rand() < 0.60:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif call_amount <= 2 * bb:
                # Mix calling and folding
                if self._rand() < 0.35:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # Versus big raises, occasionally 3-bet bluff small frequency
                if self._rand() < 0.08 and max_raise >= (min_raise + call_amount):
                    raise_by = min(max_raise, max(min_raise + call_amount, int(2.5 * bb) + call_amount))
                    if raise_by >= (min_raise + call_amount):
                        return PokerAction.RAISE, raise_by
                return PokerAction.FOLD, 0

    def _rand(self) -> float:
        return self.rng.random()