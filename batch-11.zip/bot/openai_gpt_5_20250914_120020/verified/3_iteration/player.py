from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math
from collections import Counter

# Helpers for card parsing and evaluation

RANK_STR_TO_INT = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}
INT_TO_RANK_STR = {v: k for k, v in RANK_STR_TO_INT.items()}
SUITS = ['h', 'd', 'c', 's']
ALL_CARDS = [r + s for r in RANK_STR_TO_INT.keys() for s in SUITS]

def parse_card(card: str) -> Tuple[int, str]:
    # card like 'Ah'
    return RANK_STR_TO_INT.get(card[0], 0), card[1]

def best_straight_high(ranks: List[int]) -> int:
    # returns highest card of any straight, or 0 if none
    # ranks are unique sorted ascending
    if not ranks:
        return 0
    rset = set(ranks)
    # handle wheel straight: A(14) can count as 1
    if 14 in rset:
        rset.add(1)
    sorted_r = sorted(rset)
    consec = 1
    best_high = 0
    prev = None
    for r in sorted_r:
        if prev is None or r == prev + 1:
            consec += 1 if prev is not None else 1
        else:
            consec = 1
        if consec >= 5:
            best_high = r
        prev = r
    return best_high

def evaluate_7cards(cards: List[str]) -> Tuple[int, Tuple[int, ...]]:
    # Returns comparable tuple: (category, tiebreakers...)
    # Categories: 8 Straight Flush, 7 Four Kind, 6 Full House, 5 Flush, 4 Straight, 3 Trips, 2 Two Pair, 1 One Pair, 0 High
    # Higher is better
    ranks = []
    suits = []
    for c in cards:
        r, s = parse_card(c)
        ranks.append(r)
        suits.append(s)
    rank_counts = Counter(ranks)
    suit_counts = Counter(suits)

    # Flush detection
    flush_suit = None
    for s, cnt in suit_counts.items():
        if cnt >= 5:
            flush_suit = s
            break
    flush_ranks = []
    if flush_suit is not None:
        flush_ranks = sorted([r for r, s in zip(ranks, suits) if s == flush_suit], reverse=True)

    # Straight flush / straight detection
    def straight_high_from_ranks(rank_list: List[int]) -> int:
        uniq = sorted(set(rank_list))
        if 14 in uniq:
            uniq.append(1)
        consec = 1
        best_high = 0
        for i in range(1, len(uniq)):
            if uniq[i] == uniq[i - 1] + 1:
                consec += 1
                if consec >= 5:
                    best_high = uniq[i]
            elif uniq[i] != uniq[i - 1]:
                consec = 1
        return best_high

    # Straight flush
    if flush_suit is not None:
        sf_high = straight_high_from_ranks([r for r, s in zip(ranks, suits) if s == flush_suit])
        if sf_high >= 5:
            # Royal flush if high is Ace(14)
            return (8, (sf_high,))

    # Four of a kind, trips, pairs
    counts_by_rank = sorted(((cnt, r) for r, cnt in rank_counts.items()), reverse=True)
    # counts_by_rank sorted by count desc then rank desc
    # Identify quads
    if counts_by_rank and counts_by_rank[0][0] == 4:
        quad_rank = counts_by_rank[0][1]
        kicker = max([r for r in ranks if r != quad_rank])
        return (7, (quad_rank, kicker))

    # Full house: one triple and another triple or pair
    trips = sorted([r for r, cnt in rank_counts.items() if cnt == 3], reverse=True)
    pairs = sorted([r for r, cnt in rank_counts.items() if cnt == 2], reverse=True)
    if trips:
        if len(trips) >= 2:
            return (6, (trips[0], trips[1]))
        if pairs:
            return (6, (trips[0], pairs[0]))

    # Flush
    if flush_suit is not None:
        top5 = tuple(flush_ranks[:5])
        return (5, top5)

    # Straight
    s_high = straight_high_from_ranks(ranks)
    if s_high >= 5:
        return (4, (s_high,))

    # Trips
    if trips:
        # fill with top two kickers
        kickers = sorted([r for r in ranks if r != trips[0]], reverse=True)[:2]
        return (3, (trips[0],) + tuple(kickers))

    # Two pair
    if len(pairs) >= 2:
        high_pair, low_pair = pairs[0], pairs[1]
        kicker = max([r for r in ranks if r != high_pair and r != low_pair])
        return (2, (high_pair, low_pair, kicker))

    # One pair
    if len(pairs) == 1:
        pair_rank = pairs[0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
        return (1, (pair_rank,) + tuple(kickers))

    # High card
    top5 = tuple(sorted(ranks, reverse=True)[:5])
    return (0, top5)

def compare_7cards(a_cards: List[str], b_cards: List[str]) -> int:
    a = evaluate_7cards(a_cards)
    b = evaluate_7cards(b_cards)
    if a > b:
        return 1
    elif a < b:
        return -1
    return 0

def hand_to_key(card1: str, card2: str) -> Tuple[int, int, bool]:
    r1, s1 = parse_card(card1)
    r2, s2 = parse_card(card2)
    if r1 < r2:
        r1, r2 = r2, r1
        s1, s2 = s2, s1
    suited = s1 == s2
    return r1, r2, suited

def preflop_category(hole: Optional[List[str]]) -> int:
    # Returns a category 0..5 (5 strongest)
    if not hole or len(hole) < 2:
        return 1
    r1, r2, suited = hand_to_key(hole[0], hole[1])
    # Pairs
    if r1 == r2:
        if r1 >= 14:  # AA
            return 5
        if r1 >= 12:  # KK, QQ
            return 5
        if r1 == 11 or r1 == 10:  # JJ, TT
            return 4
        if r1 >= 7:
            return 3
        return 2
    # Premium broadways
    if r1 == 14 and r2 >= 13:  # AK
        return 4 if not suited else 5
    if r1 == 14 and r2 == 12:  # AQ
        return 3 if not suited else 4
    if r1 == 13 and r2 == 12:  # KQ
        return 3 if not suited else 4
    # Strong suited aces and broadways
    if suited:
        if r1 == 14 and r2 >= 10:  # AJs, ATs
            return 3
        if r1 >= 12 and r2 >= 10:  # QJs, KJs, KTs, QTs, JTs
            return 3
        # Suited connectors 98s-54s
        if r1 - r2 == 1 and r1 <= 9 and r2 >= 4:
            return 2
        # Any suited Ace
        if r1 == 14:
            return 2
    else:
        if r1 == 14 and r2 == 11:  # AJo
            return 2
        if r1 >= 12 and r2 >= 11:  # KJo, QJo
            return 2
        if r1 == 14 and r2 == 10:  # ATo
            return 2
    # Default weak
    return 1

def preflop_equity_estimate(cat: int, num_opps: int) -> float:
    # Rough estimates vs number of opponents
    # Heads-up baseline
    base = {
        5: 0.75,
        4: 0.65,
        3: 0.58,
        2: 0.52,
        1: 0.46,
        0: 0.42
    }.get(cat, 0.45)
    # Adjust for more opponents (reduce equity slightly)
    adj = base - 0.04 * max(0, num_opps - 1)
    return max(0.05, min(0.95, adj))

def estimate_equity_mc(hole: Optional[List[str]], community: List[str], num_opps: int, samples: int, rng: random.Random) -> float:
    if not hole or len(hole) < 2:
        # Fallback neutral if unknown hand
        return 0.5
    known = set(community + hole)
    deck = [c for c in ALL_CARDS if c not in known]
    if len(deck) < 2 * num_opps:
        # Shouldn't happen, fallback
        return 0.5
    wins = 0.0
    trials = 0
    # For speed, pre-parse hero hole cards and community
    for _ in range(samples):
        rng.shuffle(deck)
        idx = 0
        # draw opp hands
        opp_hands = []
        for _o in range(num_opps):
            if idx + 2 > len(deck):
                break
            opp_hands.append([deck[idx], deck[idx + 1]])
            idx += 2
        # board completion
        board = list(community)
        needed = 5 - len(board)
        if needed > 0:
            if idx + needed > len(deck):
                continue
            board += deck[idx:idx + needed]
            idx += needed
        # Evaluate
        hero_best = evaluate_7cards(hole + board)
        best_rank = hero_best
        best_players = 1  # hero included if tied
        hero_is_best = True
        for opp in opp_hands:
            opp_rank = evaluate_7cards(opp + board)
            if opp_rank > best_rank:
                best_rank = opp_rank
                best_players = 1
                hero_is_best = False
            elif opp_rank == best_rank:
                if hero_is_best:
                    best_players += 1
                else:
                    # someone else ties with current best (not hero)
                    best_players += 1
        # Determine hero result compared against all opponents
        if hero_best == best_rank:
            wins += 1.0 / best_players
        # else 0
        trials += 1
    if trials == 0:
        return 0.5
    return wins / (trials + 1e-9)

def clamp(val: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, val))

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_id: Optional[int] = None
        self.small_blind_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: Optional[List[str]] = None
        self.rng = random.Random(1337)
        self.hand_round_num: int = 0  # track per-hand id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the start of a new hand (game)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Store our hole cards if provided
        try:
            # player_hands likely contains our two cards
            if isinstance(player_hands, list) and len(player_hands) >= 2:
                self.hole_cards = player_hands[:2]
            else:
                self.hole_cards = None
        except Exception:
            self.hole_cards = None
        # Reseed RNG slightly to add variability per hand
        self.rng.seed((self.id or 0) ^ (starting_chips or 0) ^ (blind_amount or 0) ^ (big_blind_player_id or 0) ^ (small_blind_player_id or 0))

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Not strictly needed; could track street changes if desired
        self.hand_round_num = round_state.round_num

    def _my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _num_active_players(self, round_state: RoundStateClient) -> int:
        # Estimate number of players still in the hand (not folded)
        try:
            if round_state.player_actions:
                alive = 0
                for pid_str in round_state.player_actions.keys():
                    act = round_state.player_actions.get(pid_str, "")
                    if act != "Fold":
                        alive += 1
                if alive > 0:
                    return alive
            # Fallback to all players list
            if self.all_players:
                return len(self.all_players)
        except Exception:
            pass
        # Default heads-up
        return 2

    def _valid_raise_to(self, round_state: RoundStateClient, desired_total: int, my_bet: int) -> Optional[int]:
        # Convert desired_total (our total bet after raise) into a valid raise target
        current_bet = int(round_state.current_bet)
        min_raise = int(round_state.min_raise)
        max_raise = int(round_state.max_raise)
        # Ensure desired_total at least current_bet + min_raise and also > my_bet
        floor_total = max(current_bet + min_raise, my_bet + min_raise)
        target = max(desired_total, floor_total)
        target = clamp(target, 0, max_raise)
        if target <= current_bet or target <= my_bet:
            return None
        return target

    def _decide_open_raise(self, round_state: RoundStateClient, category: int, pot: int, my_bet: int) -> Optional[int]:
        # Decide an opening bet/raise when we can check
        # Size by 2.5-3x blind preflop; postflop bet half-pot
        street = (round_state.round or "").lower()
        if street == "preflop":
            if category >= 4:
                base = int(3.0 * max(1, self.blind_amount))
            elif category == 3:
                base = int(2.5 * max(1, self.blind_amount))
            elif category == 2 and self.rng.random() < 0.25:
                base = int(2.2 * max(1, self.blind_amount))
            else:
                return None
            desired_total = my_bet + base
        else:
            # Postflop, value bet if strong via equity, handle elsewhere; default half-pot stab sometimes
            desired_total = None
        if desired_total is None:
            return None
        return self._valid_raise_to(round_state, desired_total, my_bet)

    def _decide_postflop_bet(self, round_state: RoundStateClient, equity: float, pot: int, my_bet: int) -> Optional[int]:
        # Bet/raise when no bet to you (you can check)
        # Value thresholds by street
        street = (round_state.round or "").lower()
        if street == "flop":
            thr = 0.60
            size = 0.6
        elif street == "turn":
            thr = 0.65
            size = 0.55
        else:  # river
            thr = 0.70
            size = 0.55
        if equity >= thr:
            add_amount = max(int(size * max(0, pot)), int(round_state.min_raise))
            desired_total = my_bet + add_amount
            return self._valid_raise_to(round_state, desired_total, my_bet)
        # Occasional small bluff if checked to us and equity modest
        if equity >= 0.45 and self.rng.random() < 0.15:
            add_amount = max(int(0.4 * max(0, pot)), int(round_state.min_raise))
            desired_total = my_bet + add_amount
            return self._valid_raise_to(round_state, desired_total, my_bet)
        return None

    def _decide_raise_over_bet(self, round_state: RoundStateClient, equity: float, pot: int, call_amount: int, my_bet: int) -> Optional[int]:
        # Decide to raise over an existing bet for value
        if equity < 0.68:
            return None
        # Size to about 3x the bet or pot-sized if small
        current_bet = int(round_state.current_bet)
        to_call = max(0, current_bet - my_bet)
        # Choose raise size as to_call + additional
        total_add = to_call + max(int(1.5 * to_call), int(0.6 * pot))
        desired_total = my_bet + total_add
        return self._valid_raise_to(round_state, desired_total, my_bet)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_bet = self._my_bet(round_state)
            current_bet = int(round_state.current_bet)
            call_amount = max(0, current_bet - my_bet)
            pot = int(round_state.pot)
            community = round_state.community_cards or []
            street = (round_state.round or "").lower()
            num_active = max(2, self._num_active_players(round_state))
            num_opps = max(1, num_active - 1)

            # Determine our equity estimate
            if street == "preflop":
                cat = preflop_category(self.hole_cards)
                equity = preflop_equity_estimate(cat, num_opps)
            else:
                # Monte Carlo estimation postflop
                samples = 280 if street == "flop" else 320 if street == "turn" else 360
                equity = estimate_equity_mc(self.hole_cards, community, num_opps, samples, self.rng)
                # Clamp sanity
                equity = max(0.02, min(0.98, equity))

            # Pot odds
            pot_odds = 0.0
            if call_amount > 0:
                pot_odds = call_amount / (pot + call_amount + 1e-9)

            # Decision branches
            if call_amount <= 0:
                # We can check or bet/raise
                if street == "preflop":
                    cat = preflop_category(self.hole_cards)
                    raise_to = self._decide_open_raise(round_state, cat, pot, my_bet)
                    if raise_to is not None:
                        return (PokerAction.RAISE, int(raise_to))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Postflop logic
                    raise_to = self._decide_postflop_bet(round_state, equity, pot, my_bet)
                    if raise_to is not None:
                        return (PokerAction.RAISE, int(raise_to))
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                # Preflop tightness controls
                if street == "preflop":
                    cat = preflop_category(self.hole_cards)
                    # Adjust thresholds by raise size relative to blind
                    blind = max(1, self.blind_amount)
                    ratio = call_amount / (blind + 1e-9)
                    # Strong hands call/raise, weak fold to big raises
                    if ratio >= 6.0 and cat < 4:
                        return (PokerAction.FOLD, 0)
                    if ratio >= 3.0 and cat < 3:
                        return (PokerAction.FOLD, 0)
                    # Decide call vs small 3bet
                    if cat >= 4 and self.rng.random() < 0.35:
                        # occasional 4bet
                        desired_total = my_bet + int(max(6.0 * blind, call_amount * 2.5))
                        raise_to = self._valid_raise_to(round_state, desired_total, my_bet)
                        if raise_to is not None:
                            return (PokerAction.RAISE, int(raise_to))
                    # Call if equity supports pot odds
                    eq = preflop_equity_estimate(cat, num_opps)
                    if eq > pot_odds + 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Postflop: compare equity to pot odds
                    # Add a small margin for rake/uncertainty
                    margin = 0.04
                    if equity > pot_odds + margin:
                        # Sometimes raise for value with strong equity
                        raise_to = self._decide_raise_over_bet(round_state, equity, pot, call_amount, my_bet)
                        if raise_to is not None and self.rng.random() < 0.40:
                            return (PokerAction.RAISE, int(raise_to))
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        except Exception:
            # Failsafe: never crash; fold if something goes wrong
            if round_state.current_bet > self._my_bet(round_state):
                return (PokerAction.FOLD, 0)
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand state if needed
        self.hole_cards = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent storage required
        pass