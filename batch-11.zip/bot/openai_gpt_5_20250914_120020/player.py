from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Simple helper mappings and utilities for hand parsing and evaluation
RANK_CHAR_TO_VAL = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}
VAL_TO_RANK_CHAR = {v: k for k, v in RANK_CHAR_TO_VAL.items()}
SUITS = {'h', 'd', 'c', 's'}

def safe_div(a: float, b: float) -> float:
    return a / (b if abs(b) > 1e-12 else 1e-12)

def parse_card(card: str) -> Tuple[int, str]:
    # card format like 'As', 'Td'
    if not card or len(card) < 2:
        return (0, 'x')
    rank_char = card[0].upper()
    suit_char = card[1].lower()
    return (RANK_CHAR_TO_VAL.get(rank_char, 0), suit_char if suit_char in SUITS else 'x')

def unique_sorted_ranks(cards: List[str]) -> List[int]:
    ranks = {parse_card(c)[0] for c in cards if c}
    # Handle Ace-low straight by adding 1 for Ace
    if 14 in ranks:
        ranks.add(1)
    return sorted(ranks)

def get_rank_counts(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        r, _ = parse_card(c)
        if r > 0:
            counts[r] = counts.get(r, 0) + 1
    return counts

def get_suit_counts(cards: List[str]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for c in cards:
        _, s = parse_card(c)
        if s in SUITS:
            counts[s] = counts.get(s, 0) + 1
    return counts

def has_straight(cards: List[str]) -> Tuple[bool, int]:
    """Return (has_straight, high_rank)"""
    ranks = unique_sorted_ranks(cards)
    if not ranks:
        return (False, 0)
    streak = 1
    high = ranks[0]
    best_high = 0
    for i in range(1, len(ranks)):
        if ranks[i] == ranks[i - 1] + 1:
            streak += 1
        else:
            streak = 1
        if streak >= 5:
            best_high = ranks[i]
    return (best_high > 0, best_high)

def has_straight_flush(cards: List[str]) -> Tuple[bool, int]:
    """Return (has_straight_flush, high_rank)"""
    suit_groups: Dict[str, List[str]] = {}
    for c in cards:
        r, s = parse_card(c)
        if s in SUITS and r > 0:
            suit_groups.setdefault(s, []).append(c)
    for s, group in suit_groups.items():
        ok, high = has_straight(group)
        if ok:
            return (True, high)
    return (False, 0)

def get_flush_info(cards: List[str]) -> Tuple[bool, str, List[int]]:
    """Return (has_flush, suit, top5_ranks_desc)"""
    counts = get_suit_counts(cards)
    flush_suit = None
    for s, cnt in counts.items():
        if cnt >= 5:
            flush_suit = s
            break
    if not flush_suit:
        return (False, '', [])
    ranks = [parse_card(c)[0] for c in cards if parse_card(c)[1] == flush_suit]
    ranks.sort(reverse=True)
    return (True, flush_suit, ranks[:5])

def straight_draw_info(cards: List[str]) -> Tuple[bool, bool]:
    """Return (has_oesd, has_gutshot) approximate from all available cards."""
    ranks = unique_sorted_ranks(cards)
    if not ranks:
        return (False, False)
    # Check windows of length 5 with 1 missing = gutshot; with 0 missing but only 4 cards available can't happen
    # We approximate OESD if there are 4 consecutive ranks present
    # OESD: four in a row present in ranks (e.g., 5,6,7,8 or 6,7,8,9)
    # Gutshot: window size 5 with exactly 4 present but not the ends OESD shape.
    set_r = set(ranks)
    oesd = False
    gut = False
    # consider windows starting at A-low (1) through 10
    lows = [1] + list(range(2, 11))
    for low in lows:
        window = {low, low + 1, low + 2, low + 3, low + 4}
        present = len(window & set_r)
        if present >= 4:
            # determine whether it's a true 4-in-a-row OESD or inside gutshot
            # For OESD, need any continuous 4 ranks present
            for start in range(low, low + 2):
                seq = {start, start + 1, start + 2, start + 3}
                if seq.issubset(set_r):
                    oesd = True
                    break
            if not oesd:
                gut = True
    return (oesd, gut)

def flush_draw_info(cards: List[str]) -> bool:
    counts = get_suit_counts(cards)
    for s, cnt in counts.items():
        if cnt == 4:
            return True
    return False

def evaluate_hand_category(hole: List[str], board: List[str]) -> Tuple[int, Dict[str, Any]]:
    """
    Return (category, info)
    category order:
    8 Straight Flush
    7 Four of a Kind
    6 Full House
    5 Flush
    4 Straight
    3 Three of a Kind
    2 Two Pair
    1 One Pair
    0 High Card
    info may include pair_rank/top_pair flags, draw info, etc.
    """
    all_cards = hole + board
    info: Dict[str, Any] = {}
    # Straight flush
    sf, sf_high = has_straight_flush(all_cards)
    if sf:
        info['sf_high'] = sf_high
        return (8, info)

    # Quads / Full House / Trips / Two pair / Pair
    rank_counts = get_rank_counts(all_cards)
    counts_sorted = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
    counts = sorted(rank_counts.values(), reverse=True)

    if counts and counts[0] == 4:
        info['quad_rank'] = counts_sorted[0][0]
        return (7, info)

    if counts and counts[0] == 3:
        three_rank = counts_sorted[0][0]
        pair_rank = None
        for r, c in counts_sorted[1:]:
            if c >= 2 and r != three_rank:
                pair_rank = r
                break
        if pair_rank is not None:
            info['three_rank'] = three_rank
            info['pair_rank'] = pair_rank
            return (6, info)  # Full house

    # Flush
    has_flush, fs, top5 = get_flush_info(all_cards)
    if has_flush:
        info['flush_suit'] = fs
        info['flush_top'] = top5
        return (5, info)

    # Straight
    st, st_high = has_straight(all_cards)
    if st:
        info['st_high'] = st_high
        return (4, info)

    # Trips / Two pair / Pair
    if counts and counts[0] == 3:
        info['trip_rank'] = counts_sorted[0][0]
        return (3, info)

    pair_ranks = [r for r, c in counts_sorted if c == 2]
    if len(pair_ranks) >= 2:
        info['pair_ranks'] = pair_ranks[:2]
        return (2, info)
    if len(pair_ranks) == 1:
        info['pair_rank'] = pair_ranks[0]
        return (1, info)

    # High card, add draw info
    oesd, gut = straight_draw_info(all_cards)
    fdraw = flush_draw_info(all_cards)
    info['oesd'] = oesd
    info['gutshot'] = gut
    info['flush_draw'] = fdraw
    return (0, info)

def board_top_rank(board: List[str]) -> int:
    if not board:
        return 0
    return max(parse_card(c)[0] for c in board if c)

def classify_pair_type(hole: List[str], board: List[str], info: Dict[str, Any]) -> str:
    """
    Given one-pair info, classify as overpair, top pair, second pair, underpair, board pair only etc.
    """
    pair_rank = info.get('pair_rank', 0)
    if pair_rank == 0:
        return 'none'
    board_ranks = [parse_card(c)[0] for c in board if c]
    hole_ranks = [parse_card(c)[0] for c in hole if c]
    top_board = max(board_ranks) if board_ranks else 0
    if all(r != pair_rank for r in board_ranks) and any(r == pair_rank for r in hole_ranks):
        # pair made from hole cards only
        if pair_rank > top_board:
            return 'overpair'
        elif pair_rank == top_board:
            return 'top_pair'  # rare when board empty
        else:
            # under top board but still hole pair; check if > second board rank
            sorted_board = sorted(board_ranks, reverse=True)
            second = sorted_board[1] if len(sorted_board) >= 2 else 0
            if pair_rank == second:
                return 'second_pair'
            return 'underpair'
    # pair involving board rank
    if pair_rank == top_board:
        # do we pair top board via our hole?
        if any(r == pair_rank for r in hole_ranks):
            return 'top_pair'
        else:
            return 'board_pair'
    sorted_board = sorted(board_ranks, reverse=True)
    second = sorted_board[1] if len(sorted_board) >= 2 else 0
    if pair_rank == second and any(r == pair_rank for r in hole_ranks):
        return 'second_pair'
    return 'weak_pair'

def estimate_equity(hole: List[str], board: List[str], num_active: int) -> float:
    """
    Heuristic equity estimate vs num_active opponents (>=2 including us).
    """
    # Preflop estimate if no board
    if len(board) == 0:
        pf = preflop_score(hole)
        # Adjust for number of opponents (multiway)
        opponents = max(1, num_active - 1)
        # Rough discount for each extra opponent beyond heads-up
        discount = 0.85 ** max(0, opponents - 1)
        return max(0.05, min(0.98, pf * discount))

    cat, info = evaluate_hand_category(hole, board)
    equity = 0.25  # baseline high card
    if cat >= 8:
        equity = 0.99
    elif cat == 7:
        equity = 0.99
    elif cat == 6:
        equity = 0.95
    elif cat == 5:
        equity = 0.85
    elif cat == 4:
        equity = 0.80
    elif cat == 3:
        equity = 0.70
    elif cat == 2:
        equity = 0.60
    elif cat == 1:
        # Refine one pair
        ptype = classify_pair_type(hole, board, info)
        if ptype == 'overpair':
            equity = 0.65
        elif ptype == 'top_pair':
            # Kicker rough heuristic
            hole_ranks = [parse_card(c)[0] for c in hole if c]
            high_kicker = max(hole_ranks) if hole_ranks else 0
            equity = 0.58 if high_kicker >= 12 else 0.54
        elif ptype == 'second_pair':
            equity = 0.48
        elif ptype == 'underpair':
            equity = 0.40
        elif ptype == 'board_pair':
            equity = 0.38
        else:
            equity = 0.36
    else:
        # High card with draws
        oesd, gut = straight_draw_info(hole + board)
        fdraw = flush_draw_info(hole + board)
        combo = (oesd or gut) and fdraw
        if combo:
            equity = 0.50
        elif fdraw:
            # Overcard bonus
            hole_ranks = [parse_card(c)[0] for c in hole if c]
            top_board = board_top_rank(board)
            has_over = any(r > top_board for r in hole_ranks)
            equity = 0.42 if has_over else 0.38
        elif oesd:
            equity = 0.36
        elif gut:
            equity = 0.22
        else:
            # Two overcards to board?
            hole_ranks = sorted([parse_card(c)[0] for c in hole if c], reverse=True)
            top_board = board_top_rank(board)
            if hole_ranks and hole_ranks[0] > top_board and (len(hole_ranks) < 2 or hole_ranks[1] > top_board):
                equity = 0.32
            else:
                equity = 0.25

    # Adjust for number of opponents (multiway): reduce equity vs more players
    opponents = max(1, num_active - 1)
    discount = 0.88 ** max(0, opponents - 1)
    equity = max(0.02, min(0.995, equity * discount))
    return equity

def preflop_score(hole: List[str]) -> float:
    """Simple preflop hand strength estimate in [0,1]"""
    if len(hole) < 2:
        return 0.0
    r1, s1 = parse_card(hole[0])
    r2, s2 = parse_card(hole[1])
    if r1 == 0 or r2 == 0:
        return 0.0
    high = max(r1, r2)
    low = min(r1, r2)
    suited = (s1 == s2)
    pair = (r1 == r2)
    gap = abs(r1 - r2)

    if pair:
        # 22 -> ~0.50, AA -> ~1.0
        score = 0.5 + (high - 2) / 20.0  # (0..0.6)
    else:
        high_comp = max(0.0, (high - 6) / 8.0) * 0.45   # 6..14 -> 0..0.45
        low_comp = max(0.0, (low - 2) / 12.0) * 0.25    # 2..14 -> 0..0.25
        suited_bonus = 0.06 if suited else 0.0
        # Connectivity bonus: smaller gap better
        conn_base = max(0, 5 - gap)  # 5->0, 0->5
        conn_mult = 0.03 if suited else 0.02
        conn_bonus = conn_base * conn_mult
        # Ace-X suited extra boost for A9s+
        axs_bonus = 0.05 if suited and high == 14 and low >= 9 else 0.0
        score = high_comp + low_comp + suited_bonus + conn_bonus + axs_bonus
    # Small tweak for Broadway hands
    if {r1, r2}.issubset({10, 11, 12, 13, 14}) and not pair:
        score += 0.05
    # Clamp
    score = max(0.0, min(0.99, score))
    return score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/round tracking
        self.starting_chips = 0
        self.blind_amount = 0  # unknown if small or big; we'll use min_raise mostly
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []  # our private cards for the current hand
        self.round_num = 0
        # Opponent behavior tracking (simple)
        self.vpip: Dict[int, int] = {}
        self.pfr: Dict[int, int] = {}
        self.hands_seen = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize at the start of each game/hand (assumption based on framework behavior)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Store our hole cards if provided
        self.hole_cards = player_hands[:] if player_hands else []
        self.hands_seen += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track round number within the hand
        if round_state:
            self.round_num = round_state.round_num

    def _num_active_players(self, round_state: RoundStateClient) -> int:
        # Try to infer active players in the pot (not folded)
        if round_state is None:
            return max(2, len(self.all_players))
        actions = round_state.player_actions or {}
        active = 0
        # If actions are empty, fallback to current players list length
        if not actions:
            cp = round_state.current_player or []
            if cp:
                return len(cp)
            # fallback to known players in the hand
            pb = round_state.player_bets or {}
            if pb:
                return len(pb.keys())
            return max(2, len(self.all_players)) if self.all_players else 2
        for _, act in actions.items():
            if act is None:
                continue
            if str(act).lower() != 'fold':
                active += 1
        if active == 0:
            # No actions yet -> likely all active
            pb = round_state.player_bets or {}
            if pb:
                return len(pb.keys())
            return max(2, len(self.all_players)) if self.all_players else 2
        return active

    def _my_bet(self, round_state: RoundStateClient) -> int:
        if round_state is None:
            return 0
        pb = round_state.player_bets or {}
        return int(pb.get(str(self.id), 0))

    def _call_amount(self, round_state: RoundStateClient) -> int:
        if round_state is None:
            return 0
        current_bet = int(round_state.current_bet or 0)
        my_bet = self._my_bet(round_state)
        return max(0, current_bet - my_bet)

    def _can_check(self, round_state: RoundStateClient) -> bool:
        return self._call_amount(round_state) == 0

    def _valid_raise(self, round_state: RoundStateClient, desired_raise_by: int, remaining_chips: int) -> Tuple[bool, int]:
        """Return (is_valid, raise_by_clamped)"""
        if round_state is None:
            return (False, 0)
        min_r = int(round_state.min_raise or 0)
        max_r = int(round_state.max_raise or 0)
        if remaining_chips <= 0:
            return (False, 0)
        if max_r <= 0:
            return (False, 0)
        # Raise-by must be >= min_raise and <= max_raise
        rb = max(min_r, min(desired_raise_by, min(max_r, remaining_chips)))
        # Also ensure that your_bet + raise_by > current_bet to be a proper raise
        if self._my_bet(round_state) + rb <= int(round_state.current_bet or 0):
            # bump to at least make it a raise if possible
            needed = int(round_state.current_bet or 0) - self._my_bet(round_state) + 1
            rb = max(rb, needed)
        if rb < min_r:
            return (False, 0)
        if rb > max_r:
            rb = max_r
        # Final sanity check
        if self._my_bet(round_state) + rb <= int(round_state.current_bet or 0):
            return (False, 0)
        return (True, rb)

    def _bet_size_from_pot(self, round_state: RoundStateClient, fraction: float, remaining_chips: int) -> int:
        pot = int(round_state.pot or 0)
        target = int(max(1, pot * fraction))
        ok, rb = self._valid_raise(round_state, target, remaining_chips)
        if ok:
            return rb
        # fallback to min_raise if possible
        min_r = int(round_state.min_raise or 0)
        ok, rb = self._valid_raise(round_state, min_r, remaining_chips)
        return rb if ok else 0

    def _choose_preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amt = self._call_amount(round_state)
        can_check = self._can_check(round_state)
        strength = preflop_score(self.hole_cards)
        # Basic ranges
        strong = strength >= 0.72
        medium = strength >= 0.58
        marginal = strength >= 0.48

        # If we can check (unopened pot), consider opening a raise with good hands
        if can_check:
            if strong:
                rb = self._bet_size_from_pot(round_state, 0.75, remaining_chips)
                if rb > 0:
                    return (PokerAction.RAISE, rb)
            if medium:
                # Smaller open
                min_r = int(round_state.min_raise or 0)
                ok, rb = self._valid_raise(round_state, max(min_r, int(min_r * 3)), remaining_chips)
                if ok:
                    return (PokerAction.RAISE, rb)
            # Otherwise, check
            return (PokerAction.CHECK, 0)
        else:
            # Facing a raise
            # If we cannot afford the call fully, decide all-in or fold
            if call_amt >= remaining_chips:
                # Go with top of range only
                if strong and remaining_chips > 0:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.FOLD, 0)

            if strong:
                # 3-bet for value
                desired = max(int(round_state.min_raise or 0) * 4, int(call_amt * 2))
                ok, rb = self._valid_raise(round_state, desired, remaining_chips)
                if ok:
                    return (PokerAction.RAISE, rb)
                # fallback call
                return (PokerAction.CALL, 0)
            if medium:
                # Flat call
                return (PokerAction.CALL, 0)
            if marginal:
                # Tighten up heads-up: call small raises only
                pot = int(round_state.pot or 0)
                if call_amt <= max(1, pot // 6):
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            # Trash -> fold
            return (PokerAction.FOLD, 0)

    def _choose_postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amt = self._call_amount(round_state)
        can_check = self._can_check(round_state)
        pot = int(round_state.pot or 0)
        num_active = self._num_active_players(round_state)
        equity = estimate_equity(self.hole_cards, round_state.community_cards or [], num_active)
        # Required equity to call
        req_eq = safe_div(call_amt, pot + call_amt)

        # If no bet to us, consider betting for value or protection/draws
        if can_check:
            # Value bet with strong hands
            # Thresholds by equity
            if equity >= 0.80:
                rb = self._bet_size_from_pot(round_state, 0.85, remaining_chips)
                if rb > 0:
                    return (PokerAction.RAISE, rb)
            elif equity >= 0.65:
                rb = self._bet_size_from_pot(round_state, 0.66, remaining_chips)
                if rb > 0:
                    return (PokerAction.RAISE, rb)
            elif equity >= 0.55:
                # Thin value / protection half-pot
                rb = self._bet_size_from_pot(round_state, 0.5, remaining_chips)
                if rb > 0:
                    return (PokerAction.RAISE, rb)
            # Otherwise, check
            return (PokerAction.CHECK, 0)

        # Facing a bet
        # If we can't afford full call
        if call_amt >= remaining_chips:
            # All-in only with strong equity
            if equity >= 0.58 and remaining_chips > 0:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.FOLD, 0)

        # If we have monster hand, raise (or shove if short)
        if equity >= 0.85:
            # If effective stacks are small relative to pot, shove
            if remaining_chips <= max(1, pot * 1):
                return (PokerAction.ALL_IN, 0)
            # Otherwise raise big (around 0.9 pot)
            rb = self._bet_size_from_pot(round_state, 0.9, remaining_chips)
            if rb > 0:
                return (PokerAction.RAISE, rb)
            return (PokerAction.CALL, 0)

        # Good made hands: sometimes raise, else call if pot odds ok
        if equity >= 0.65:
            if equity - req_eq >= 0.12:
                rb = self._bet_size_from_pot(round_state, 0.75, remaining_chips)
                if rb > 0:
                    return (PokerAction.RAISE, rb)
            # Call if equity beats requirement
            if equity >= req_eq * 1.03:
                return (PokerAction.CALL, 0)
            # Else fold if bet too large
            return (PokerAction.FOLD, 0)

        # Medium showdown value or strong draws: prefer calling reasonable bets
        if equity >= 0.50:
            # Semi-bluff raise occasionally when price is cheap enough
            if call_amt <= max(1, pot // 6):
                rb = self._bet_size_from_pot(round_state, 0.6, remaining_chips)
                if rb > 0 and equity - req_eq >= 0.10:
                    return (PokerAction.RAISE, rb)
            # Call if pot odds justify
            if equity >= req_eq * 1.05:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # Weak draws / weak hands: only call very small bets with decent equity
        if equity >= 0.35 and call_amt <= max(1, pot // 8) and equity >= req_eq * 1.08:
            return (PokerAction.CALL, 0)

        return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            if round_state is None:
                # Extremely defensive fallback
                return (PokerAction.CHECK, 0)

            # Determine stage
            stage = (round_state.round or '').lower()
            if stage == 'preflop' or stage == 'pre-flop' or stage == 'Preflop':
                action, amount = self._choose_preflop_action(round_state, remaining_chips)
            else:
                action, amount = self._choose_postflop_action(round_state, remaining_chips)

            # Validate action to avoid invalid moves
            call_amt = self._call_amount(round_state)
            can_check = self._can_check(round_state)
            min_r = int(round_state.min_raise or 0)
            max_r = int(round_state.max_raise or 0)

            if action == PokerAction.CHECK:
                if not can_check:
                    # If we cannot check, prefer call if affordable
                    if remaining_chips >= call_amt and call_amt > 0:
                        return (PokerAction.CALL, 0)
                    # else fold
                    return (PokerAction.FOLD, 0)
                return (PokerAction.CHECK, 0)

            if action == PokerAction.CALL:
                if call_amt == 0 and can_check:
                    return (PokerAction.CHECK, 0)
                # If can't fully call, decide on all-in or fold
                if call_amt > remaining_chips:
                    # Consider as all-in call if decent
                    # Use crude threshold here
                    pot = int(round_state.pot or 0)
                    req_eq = safe_div(call_amt, pot + call_amt)
                    equity = estimate_equity(self.hole_cards, round_state.community_cards or [], self._num_active_players(round_state))
                    if equity >= max(0.45, req_eq * 0.9) and remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.FOLD, 0)
                return (PokerAction.CALL, 0)

            if action == PokerAction.RAISE:
                # Validate raise amount
                ok, rb = self._valid_raise(round_state, int(amount), remaining_chips)
                if not ok or rb <= 0:
                    # Fall back to call/check safely
                    if call_amt > 0 and remaining_chips >= call_amt:
                        return (PokerAction.CALL, 0)
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    # else fold
                    return (PokerAction.FOLD, 0)
                return (PokerAction.RAISE, int(rb))

            if action == PokerAction.ALL_IN:
                # Always valid if we have chips, else just fold
                if remaining_chips > 0:
                    return (PokerAction.ALL_IN, 0)
                # else consider check or fold
                if can_check:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)

            # Fallback
            if can_check:
                return (PokerAction.CHECK, 0)
            if call_amt > 0 and remaining_chips >= call_amt:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        except Exception:
            # Safety net: never crash -> choose the safest legal action
            try:
                call_amt = self._call_amount(round_state) if round_state else 0
                can_check = self._can_check(round_state) if round_state else True
                if can_check:
                    return (PokerAction.CHECK, 0)
                if round_state and call_amt > 0 and remaining_chips >= call_amt:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Clear any per-hand state that shouldn't persist
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Can be used to adjust strategy based on results across games (not implemented - keep stateless for safety)
        pass