from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    """
    A very conservative, always-valid No-Limit Hold’em bot.

    Main goals:
        1. NEVER send an illegal action (no more auto-fold penalties).
        2. Act quickly and stay within all technical limits.
        3. Use a super-simple, risk-averse strategy that at least calls
           cheap bets and checks when free, otherwise folds.
    """

    def __init__(self):
        super().__init__()

        # Game-level tracking (reset every new game via on_start)
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0

        # Round-level tracking (reset every on_round_start)
        self.my_hole_cards: List[str] = []
        self.round_number: int = 0

    # --------------------------------------------------------------------- #
    #  Interface methods required by the competition framework
    # --------------------------------------------------------------------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        """
        Called once when a new *game* (i.e., collection of hands) starts.
        """
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        # The first two elements of `player_hands` should be our initial hole
        # cards for the first hand.
        self.my_hole_cards = player_hands[:2]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the beginning of every new hand/round.
        We receive fresh hole cards in the message’s `player_actions`
        under the key 'hole_cards' for our player ID if the server
        implements it.  If not present, we keep whatever we had.
        """
        self.round_number = round_state.round_num

        # Try to fetch hole cards from the round-start state if present
        try:
            hole_cards = round_state.player_actions.get(str(self.id), "")
            if isinstance(hole_cards, list) and len(hole_cards) == 2:
                self.my_hole_cards = hole_cards
        except Exception:
            # Safety catch – server may not provide cards this way
            pass

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decides an action each time the server requests one.

        The very simple strategy:
            • If we can check, we always check.
            • Else compute the amount required to call.
                 – If that amount is less than 5 % of our stack
                   AND never larger than 4 big blinds, we call.
                 – Otherwise we fold.
        """

        # Convert id to string because the RoundState dict keys are strings
        my_id_str = str(self.id)

        # How much we have already put into the pot in this betting round
        my_bet: int = round_state.player_bets.get(my_id_str, 0)

        # The required amount to *match* the current best bet (call)
        call_amount: int = max(round_state.current_bet - my_bet, 0)

        # 1. If no bet to match -> we can CHECK
        if call_amount == 0:
            return PokerAction.CHECK, 0

        # 2. Small call?  (<= 5 % of our stack or <= 4 BB)
        max_affordable_call = int(0.05 * max(remaining_chips, 1))
        max_reasonable_call = max(self.big_blind * 4, self.big_blind)
        call_threshold = min(max_affordable_call, max_reasonable_call)

        if call_amount <= call_threshold and call_amount < remaining_chips:
            return PokerAction.CALL, 0  # Amount ignored by engine for CALL

        # 3. Otherwise FOLD
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Nothing special to do; we just update the stored hole cards if the
        server revealed them at showdown.
        """
        try:
            revealed = round_state.player_actions.get(str(self.id), "")
            if isinstance(revealed, list) and len(revealed) == 2:
                self.my_hole_cards = revealed
        except Exception:
            pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict[str, List[str]],
    ):
        """
        Reset any per-game data if needed (currently no persistent state).
        """
        self.my_hole_cards = []
        self.round_number = 0