# player.py
import itertools
import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# ------------------------  Helper utilities ------------------------ #
RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i for i, r in enumerate(RANK_ORDER)}  # 0 .. 12
CATEGORY_VALUE = {
    "high_card": 0,
    "pair": 1,
    "two_pair": 2,
    "trips": 3,
    "straight": 4,
    "flush": 5,
    "full_house": 6,
    "quads": 7,
    "straight_flush": 8,
    "royal_flush": 9,
}

def _card_rank(card: str) -> int:
    return RANK_VALUE[card[0]]

def _card_suit(card: str) -> str:
    return card[1]

def _is_straight(ranks: List[int]) -> Tuple[bool, int]:
    """Return (is_straight, high_rank)"""
    ranks = sorted(set(ranks))
    # Wheel straight (A2345)
    if ranks == [0, 1, 2, 3, 12]:
        return True, 3
    if len(ranks) != 5:
        return False, -1
    if ranks[-1] - ranks[0] == 4:
        return True, ranks[-1]
    return False, -1

def _evaluate_five(cards: List[str]) -> Tuple[int, List[int]]:
    """Return (category_value, tiebreaker ranks list)"""
    ranks = [_card_rank(c) for c in cards]
    suits = [_card_suit(c) for c in cards]
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts = sorted(rank_counts.values(), reverse=True)
    unique_ranks_sorted = sorted(rank_counts.keys(), reverse=True)

    is_flush = len(set(suits)) == 1
    is_straight, straight_high = _is_straight(ranks)

    if is_flush and is_straight:
        if straight_high == 12:  # AKQJT
            return CATEGORY_VALUE["royal_flush"], [straight_high]
        return CATEGORY_VALUE["straight_flush"], [straight_high]
    if counts[0] == 4:
        quad_rank = max(rank_counts, key=lambda r: rank_counts[r])
        kicker = max([r for r in ranks if r != quad_rank])
        return CATEGORY_VALUE["quads"], [quad_rank, kicker]
    if counts[0] == 3 and counts[1] == 2:
        trips_rank = max(rank_counts, key=lambda r: (rank_counts[r], r))
        pair_rank = max([r for r in rank_counts if rank_counts[r] == 2])
        return CATEGORY_VALUE["full_house"], [trips_rank, pair_rank]
    if is_flush:
        return CATEGORY_VALUE["flush"], sorted(ranks, reverse=True)
    if is_straight:
        return CATEGORY_VALUE["straight"], [straight_high]
    if counts[0] == 3:
        trips_rank = max(rank_counts, key=lambda r: (rank_counts[r], r))
        kickers = sorted([r for r in ranks if r != trips_rank], reverse=True)
        return CATEGORY_VALUE["trips"], [trips_rank] + kickers
    if counts[0] == 2 and counts[1] == 2:
        pair_ranks = sorted([r for r in rank_counts if rank_counts[r] == 2], reverse=True)
        kicker = max([r for r in ranks if rank_counts[r] == 1])
        return CATEGORY_VALUE["two_pair"], pair_ranks + [kicker]
    if counts[0] == 2:
        pair_rank = max(rank_counts, key=lambda r: (rank_counts[r], r))
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
        return CATEGORY_VALUE["pair"], [pair_rank] + kickers
    return CATEGORY_VALUE["high_card"], sorted(ranks, reverse=True)

def evaluate_best(cards: List[str]) -> Tuple[int, List[int]]:
    """Evaluate the best 5-card hand out of 5-7 cards."""
    best_cat = -1
    best_tie: List[int] = []
    for comb in itertools.combinations(cards, 5):
        cat, tie = _evaluate_five(list(comb))
        if cat > best_cat or (cat == best_cat and tie > best_tie):
            best_cat = cat
            best_tie = tie
    return best_cat, best_tie

# ------------------------  SimplePlayer bot ------------------------ #
class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.current_round_num: int = -1
        random.seed()

    # ------------------------  Callbacks ------------------------ #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_num = round_state.round_num
        # Try to fetch new hole cards if provided
        cards = getattr(round_state, "player_hands", None)
        if cards and str(self.id) in cards:
            self.hole_cards = cards[str(self.id)]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive helpers
        def safe_min_raise() -> int:
            return max(round_state.min_raise, 0)

        def can_check() -> bool:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            return round_state.current_bet <= my_bet

        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(round_state.current_bet - my_bet, 0)
        pot_after_call = round_state.pot + call_amount
        # ---------------- STRATEGY ---------------- #
        if round_state.round.lower() == "preflop":
            action, amt = self._preflop_decision(
                call_amount, remaining_chips, round_state, can_check()
            )
        else:
            action, amt = self._postflop_decision(
                call_amount, remaining_chips, round_state, can_check()
            )

        # -------------  Final validation ------------- #
        if action == PokerAction.RAISE:
            if remaining_chips <= call_amount:
                action = PokerAction.ALL_IN
                amt = 0
            else:
                raise_amt = max(safe_min_raise(), amt)
                raise_amt = min(raise_amt, remaining_chips - call_amount)
                if raise_amt < safe_min_raise():
                    # Cannot legally raise, fallback
                    if call_amount == 0:
                        action = PokerAction.CHECK
                    elif call_amount < remaining_chips:
                        action = PokerAction.CALL
                        amt = 0
                    else:
                        action = PokerAction.ALL_IN
                        amt = 0
                else:
                    amt = raise_amt

        # Ensure we don't exceed stack
        if action in (PokerAction.CALL, PokerAction.ALL_IN) and call_amount > remaining_chips:
            action = PokerAction.ALL_IN
            amt = 0

        return action, amt

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass  # Not used but kept for interface compliance

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # Not used but kept for interface compliance

    # --------------------  Strategy helpers -------------------- #
    def _hand_strength_preflop(self) -> int:
        """Return a discrete strength bucket 0-3 for preflop hands."""
        if len(self.hole_cards) != 2:
            return 0
        r1, r2 = self.hole_cards
        rank1, rank2 = r1[0], r2[0]
        suited = r1[1] == r2[1]
        pair = rank1 == rank2
        high_card = max(RANK_VALUE[rank1], RANK_VALUE[rank2])
        low_card = min(RANK_VALUE[rank1], RANK_VALUE[rank2])

        # Bucket 3: Premium
        if pair and high_card >= RANK_VALUE["T"]:
            return 3
        if {rank1, rank2} == {"A", "K"} and suited:
            return 3

        # Bucket 2: Strong
        if pair and high_card >= RANK_VALUE["7"]:
            return 2
        if high_card >= RANK_VALUE["A"] and low_card >= RANK_VALUE["T"]:
            return 2
        if suited and {rank1, rank2} <= {"A", "Q"} and high_card >= RANK_VALUE["K"]:
            return 2

        # Bucket 1: Playable
        if pair:
            return 1
        if suited and high_card >= RANK_VALUE["T"]:
            return 1
        if high_card >= RANK_VALUE["K"] and low_card >= RANK_VALUE["9"]:
            return 1

        return 0  # Trash

    def _preflop_decision(
        self, call_amount: int, remaining_chips: int, round_state: RoundStateClient, can_check: bool
    ) -> Tuple[PokerAction, int]:
        strength = self._hand_strength_preflop()
        aggressive = random.random() < 0.15  # occasional bluff or aggression

        # No bet to us
        if call_amount == 0:
            if strength >= 2 or (strength == 1 and aggressive):
                raise_amt = max(round_state.min_raise, self.big_blind * (3 if strength == 2 else 4))
                raise_amt = min(raise_amt, remaining_chips)
                return PokerAction.RAISE, raise_amt
            else:
                return PokerAction.CHECK, 0

        # Facing bet
        if strength == 3:
            # Premium — re-raise or call small bets
            if call_amount < remaining_chips * 0.15 and round_state.min_raise < remaining_chips * 0.25:
                return PokerAction.RAISE, round_state.min_raise
            elif call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.CALL, 0
        if strength == 2:
            if call_amount <= remaining_chips * 0.1:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        if strength == 1 and call_amount <= self.big_blind:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def _postflop_decision(
        self, call_amount: int, remaining_chips: int, round_state: RoundStateClient, can_check: bool
    ) -> Tuple[PokerAction, int]:
        # Evaluate hand strength
        board = round_state.community_cards
        cards = self.hole_cards + board
        category, _ = evaluate_best(cards)
        bluff_chance = 0.05

        # Very strong hand
        if category >= CATEGORY_VALUE["full_house"]:
            # Value raise or bet
            if call_amount == 0:
                raise_amt = max(round_state.min_raise, int(round_state.pot * 0.75))
                raise_amt = min(raise_amt, remaining_chips)
                if raise_amt >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amt
                return PokerAction.ALL_IN, 0
            else:
                if remaining_chips > call_amount + round_state.min_raise:
                    return PokerAction.RAISE, round_state.min_raise
                return PokerAction.ALL_IN, 0

        # Strong made hand
        if category >= CATEGORY_VALUE["trips"]:
            if call_amount == 0:
                bet = max(round_state.min_raise, int(round_state.pot * 0.5))
                bet = min(bet, remaining_chips)
                return PokerAction.RAISE, bet
            else:
                if call_amount <= remaining_chips * 0.25:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Medium hand (pair / two pair)
        if category >= CATEGORY_VALUE["pair"]:
            if call_amount == 0:
                if random.random() < 0.3:
                    bet = max(round_state.min_raise, int(round_state.pot * 0.4))
                    bet = min(bet, remaining_chips)
                    return PokerAction.RAISE, bet
                return PokerAction.CHECK, 0
            else:
                pot_odds = call_amount / (round_state.pot + call_amount + 1e-5)
                if pot_odds < 0.25 and call_amount <= remaining_chips * 0.15:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # Weak / drawing hand
        if call_amount == 0:
            # Occasional bluff
            if random.random() < bluff_chance and round_state.min_raise <= remaining_chips * 0.1:
                return PokerAction.RAISE, round_state.min_raise
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0