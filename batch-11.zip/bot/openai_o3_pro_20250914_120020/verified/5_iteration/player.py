from typing import List, Tuple, Dict, Any
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# External, pure-python hand evaluator
from treys import Card, Evaluator  # type: ignore


class SimplePlayer(Bot):
    """
    A light-weight, rule-based No-Limit Texas Hold’em bot that
    • uses the Chen formula pre-flop
    • evaluates exact hand strength post-flop with `treys`
    • always returns actions that respect the server’s bounds
    The strategy is intentionally simple but robust – avoiding
    illegal moves, exceptions or timeouts is prioritised.
    """

    # Chen formula rank order
    _CHEN_RANK = {
        'A': 10, 'K': 8, 'Q': 7, 'J': 6, 'T': 5,
        '9': 4.5, '8': 4, '7': 3.5, '6': 3,
        '5': 2.5, '4': 2, '3': 1.5, '2': 1
    }

    def __init__(self):
        super().__init__()
        # Will contain our current two hole cards as strings, e.g., ['Ah', 'Kd']
        self.hole_cards: List[str] = []
        # Blind info just for sizing pre-flop raises
        self.big_blind: int = 0
        self.evaluator = Evaluator()
        # Statistics (can be extended later)
        self.round_counter = 0

    # ---------------------- Helper utilities ----------------------

    @staticmethod
    def _card_rank(card: str) -> str:
        """Return the rank character of a card such as 'A', 'K', 'Q', 'T', '9'."""
        return card[0]

    def _chen_score(self, cards: List[str]) -> float:
        """
        Quick Chen formula implementation for pre-flop hand value.
        The result is a number typically ranging 0–20.
        """
        if len(cards) != 2:
            return 0.0
        r1, r2 = self._card_rank(cards[0]), self._card_rank(cards[1])
        s1, s2 = cards[0][1], cards[1][1]  # suits for suited bonus
        high = max(self._CHEN_RANK[r1], self._CHEN_RANK[r2])
        low = min(self._CHEN_RANK[r1], self._CHEN_RANK[r2])

        score = high

        # Pair bonus
        if r1 == r2:
            score = max(5, high * 2)
            # AA is 20 in the traditional Chen formula but we cap to 20
            score = min(score, 20)

        # Suited bonus
        if s1 == s2 and r1 != r2:
            score += 2

        # Gap penalty
        gap = abs(
            "23456789TJQKA".index(r1) - "23456789TJQKA".index(r2)
        ) - 1  # number of gaps between ranks
        if gap == 0 and r1 != r2:  # connected, not a pair
            score += 1
        elif gap == 1:
            score -= 1
        elif gap == 2:
            score -= 2
        elif gap == 3:
            score -= 4
        elif gap >= 4:
            score -= 5

        # Small card penalty for unsuited low hands
        if max(self._CHEN_RANK[r1], self._CHEN_RANK[r2]) < 10 and gap >= 2:
            score -= 1

        return max(score, 0.0)

    def _hand_strength_pct(self, community: List[str], hole: List[str]) -> float:
        """
        Convert treys score (0 best … 7462 worst) to a 0-1 percentile
        where 1 is the nuts and 0 the worst hand.
        """
        try:
            board = [Card.new(c) for c in community]
            hand = [Card.new(c) for c in hole]
            score = self.evaluator.evaluate(board, hand)
            percentile = 1.0 - (score / 7462.0)  # 0 worst ⇒ 0.0, 0 best ⇒ 1.0
            return max(0.0, min(percentile, 1.0))
        except Exception:
            # In case of any unforeseen parsing/evaluation error return neutral 0.5
            return 0.5

    # ---------------------- Lifecycle hooks ----------------------

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.big_blind = blind_amount * 2  # small_blind == blind_amount
        # We receive our first two cards here
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        A new hand begins – extract our fresh hole cards if provided
        inside the round_state (implementation dependent).
        """
        self.round_counter += 1
        # Try to grab our private cards in a fault-tolerant way
        possible_attrs = ['player_hands', 'hole_cards', 'hand']
        for attr in possible_attrs:
            if hasattr(round_state, attr):
                data = getattr(round_state, attr)
                # Assume mapping id->two cards or list[str]
                if isinstance(data, dict):
                    self.hole_cards = data.get(str(self.id), self.hole_cards)
                elif isinstance(data, list):
                    # If it’s directly the list of our cards
                    self.hole_cards = data
                break  # stop at first attr found

    # --------------------------- Action ---------------------------

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Main decision engine – must always return a legal action.
        """
        try:
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = max(0, current_bet - my_bet)

            # Determine stage
            stage = round_state.round.lower()  # e.g., 'preflop', 'flop', ...

            # -------------------- PRE-FLOP --------------------
            if stage == 'preflop':
                chen = self._chen_score(self.hole_cards)

                # Very strong premium: AA, KK, QQ, AKs … – shove if stacks are <40bb
                if chen >= 11:
                    if remaining_chips <= self.big_blind * 40:
                        return PokerAction.ALL_IN, 0
                    # Otherwise raise 4×BB
                    raise_amt = max(round_state.min_raise, self.big_blind * 4)
                    raise_amt = min(raise_amt, round_state.max_raise)
                    if raise_amt >= to_call + round_state.min_raise:
                        return PokerAction.RAISE, raise_amt
                    # Fallback to call
                    return (
                        PokerAction.CALL,
                        0,
                    )

                # Good hands (tier 2)
                if chen >= 8:
                    # If no bet to us – open raise
                    if to_call == 0:
                        raise_amt = max(round_state.min_raise, self.big_blind * 3)
                        raise_amt = min(raise_amt, round_state.max_raise)
                        return PokerAction.RAISE, raise_amt
                    # Facing a raise – call as long as it’s not huge (<=10% stack)
                    if to_call <= remaining_chips * 0.10:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

                # Marginal hands – limp / call small, otherwise fold
                if chen >= 5:
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    if to_call <= self.big_blind:  # call small blind or BB
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

                # Trash
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # -------------------- POST-FLOP --------------------
            # Flop / Turn / River
            strength = self._hand_strength_pct(round_state.community_cards, self.hole_cards)

            # Pot odds simple calc
            pot = max(1.0, round_state.pot)  # avoid div-by-zero
            pot_odds = to_call / (pot + to_call + 1e-9)

            # Aggressive with >80% equity
            if strength > 0.8:
                if to_call == 0:
                    # Bet ~70% of pot
                    bet = int(min(round_state.max_raise, max(round_state.min_raise, pot * 0.7)))
                    return PokerAction.RAISE, bet
                # Facing bet – raise or shove small stacks
                if remaining_chips <= self.big_blind * 20:
                    return PokerAction.ALL_IN, 0
                raise_amt = int(min(round_state.max_raise, max(round_state.min_raise, to_call * 2)))
                if raise_amt >= to_call + round_state.min_raise:
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CALL, 0

            # Solid made/strong draw (50-80%)
            if strength > 0.5:
                # Call favourable odds
                if pot_odds < strength:
                    if to_call <= remaining_chips:
                        return PokerAction.CALL, 0
                # If checked to us – make a value bet
                if to_call == 0:
                    bet = int(min(round_state.max_raise, max(round_state.min_raise, pot * 0.5)))
                    return PokerAction.RAISE, bet
                # Fold if price too high
                return PokerAction.FOLD, 0

            # Weak hand
            if to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        except Exception:
            # Fail-safe – never crash, just fold
            return PokerAction.FOLD, 0

    # --------------------- End-of-round hooks ---------------------

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing fancy yet – could collect statistics later
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict[str, Any],
    ):
        # Final logging placeholder
        pass