import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# We use the pure-python hand evaluator shipped with the ‘treys’ package
from treys import Card, Deck, Evaluator


class SimplePlayer(Bot):
    """
    A very small, robust No-Limit Texas Hold’em bot.

    Main ideas
    1.  Estimate our equity (winning probability) against the remaining field
        with a light Monte-Carlo simulation that uses treys’ fast evaluator.
    2.  Compare equity to pot odds to decide whether to fold / call / bet.
    3.  Play tightly-aggressive pre-flop so we avoid spewing chips with
        marginal hands, yet attack when strong.
    4.  Stay well within the 30-second / 100 MB limits – equity simulation
        is capped to a few hundred iterations and uses only pure python.
    """

    # ---------- constructor / life-cycle hooks --------------------------------

    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.total_players: int = 0

        # treys helpers
        self.evaluator: Evaluator = Evaluator()
        self.rng: random.Random = random.Random()

        # updated every round
        self.hole_cards: List[str] = []

    # -------------------------------------------------------------------------

    # noinspection PyUnusedLocal
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.total_players = max(2, len(all_players))

    # -------------------------------------------------------------------------

    def _extract_hole_cards(self, round_state: RoundStateClient) -> None:
        """
        The competition API isn’t fully fixed yet – hole cards might live in
        different fields depending on server version.  We try the common
        variants and fall back to previously stored cards (useful between
        get_action calls within the same hand).
        """
        possible_fields = ("hand", "hole_cards", "player_hands")
        for name in possible_fields:
            if hasattr(round_state, name):
                value = getattr(round_state, name)
                if value:
                    # player_hands can be either mapping or list – try both
                    if isinstance(value, dict):
                        my_cards = value.get(self.id) or value.get(str(self.id))
                        if my_cards:
                            self.hole_cards = list(my_cards)
                            return
                    elif isinstance(value, list) and len(value) >= 2:
                        self.hole_cards = list(value[:2])
                        return
        # If nothing found we keep whatever was stored previously.

    # noinspection PyUnusedLocal
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self._extract_hole_cards(round_state)

    # -------------------------------------------------------------------------

    # --------------------- core decision logic --------------------------------

    @staticmethod
    def _card_str_list_to_int(cards: List[str]) -> List[int]:
        """Convert ['Ah', 'Td'] → [int, int] using treys.Card.new()."""
        return [Card.new(c) for c in cards]

    def _estimate_equity(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        num_players: int,
        iterations: int,
    ) -> float:
        """
        Monte-Carlo equity estimation using treys’ fast evaluator.
        Returns a number in [0, 1].
        """
        if num_players < 2:
            num_players = 2

        known_hole = self._card_str_list_to_int(hole_cards)
        known_board = self._card_str_list_to_int(community_cards)
        used_ints = set(known_hole + known_board)

        wins = ties = 0
        evaluator = self.evaluator

        for _ in range(iterations):
            deck = Deck()
            # remove known cards
            deck.cards = [c for c in deck.cards if c not in used_ints]
            self.rng.shuffle(deck.cards)

            # draw missing community
            missing_board = 5 - len(known_board)
            sim_board = known_board + deck.draw(missing_board)

            # opponents’ hole cards
            opp_hands = [deck.draw(2) for _ in range(num_players - 1)]

            hero_score = evaluator.evaluate(sim_board, known_hole)
            opp_scores = [evaluator.evaluate(sim_board, hand) for hand in opp_hands]

            best_score = min([hero_score] + opp_scores)

            hero_best = hero_score == best_score
            num_best = sum(score == best_score for score in opp_scores) + (1 if hero_best else 0)

            if hero_best:
                if num_best == 1:
                    wins += 1
                else:
                    ties += 1  # we count tie as 0.5 win later

        return (wins + ties * 0.5) / max(1, iterations)

    # --------------------- helper: pre-flop tight range -----------------------

    def _is_playable_preflop(self, hole_cards: List[str]) -> bool:
        """
        Very small, conservative pre-flop range.
        Keeps us from leaking chips with junk.
        """
        rank_order = "23456789TJQKA"
        ranks = sorted((rank_order.index(c[0]) for c in hole_cards), reverse=True)
        r1, r2 = ranks
        suited = hole_cards[0][1] == hole_cards[1][1]

        # pairs
        if hole_cards[0][0] == hole_cards[1][0]:
            return r1 >= rank_order.index("7")  # 77+

        # big ace
        if "A" in (hole_cards[0][0], hole_cards[1][0]):
            other = hole_cards[0][0] if hole_cards[1][0] == "A" else hole_cards[1][0]
            if other in "KQJ":
                return True
            if suited and other in "T9":
                return True
            return False

        # suited broadways / connectors
        if suited and {hole_cards[0][0], hole_cards[1][0]} <= set("KQJT"):
            return True
        if suited and r1 - r2 == 1 and r1 >= rank_order.index("6"):
            return True  # e.g. 87s+

        return False

    # -------------------------------------------------------------------------

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Main decision function.
        Returns (action_enum, amount – 0 unless RAISE).
        """
        self._extract_hole_cards(round_state)
        if len(self.hole_cards) < 2:
            # should never happen, but stay safe
            return PokerAction.FOLD, 0

        # -------------------------------- basic bookkeeping -------------------
        my_bet = round_state.player_bets.get(self.id) or round_state.player_bets.get(
            str(self.id), 0
        )
        call_amount = max(0, round_state.current_bet - my_bet)
        pot_size = round_state.pot
        players_alive = max(2, len(round_state.current_player))

        # quick exit: no-chip situation
        if remaining_chips <= call_amount:
            return PokerAction.ALL_IN, 0

        # --------------- pre-flop shortcut: tight-aggressive style ------------
        if round_state.round.lower().startswith("pre"):
            playable = self._is_playable_preflop(self.hole_cards)
            if not playable:
                # fold junk facing pressure, otherwise just limp/check
                if call_amount > 0:
                    return PokerAction.FOLD, 0
                return PokerAction.CHECK, 0

            # we have a playable hand → raise or call
            if call_amount == 0:
                # open ~3× blind or min-raise if bigger
                open_size = max(round_state.min_raise, self.blind_amount * 3)
                open_size = min(open_size, round_state.max_raise)
                return (
                    PokerAction.RAISE,
                    open_size,
                )
            else:
                # facing a raise – occasionally 3-bet strong range
                three_bet = call_amount * 3
                if (
                    self.hole_cards[0][0] == self.hole_cards[1][0]  # pair
                    or "A" in (self.hole_cards[0][0], self.hole_cards[1][0])
                ) and three_bet <= round_state.max_raise:
                    return PokerAction.RAISE, max(round_state.min_raise, three_bet)
                return PokerAction.CALL, 0

        # --------------- post-flop: equity vs pot odds ------------------------
        # Monte-Carlo iterations: more streets → more certainty
        iterations = 200 if round_state.round.lower().startswith("flop") else 400

        equity = self._estimate_equity(
            self.hole_cards,
            round_state.community_cards,
            players_alive,
            iterations,
        )

        # pot odds
        pot_odds = call_amount / (pot_size + call_amount + 1e-9)

        # -------------------------------- actions ----------------------------
        # 1. No bet facing us ➜ decide to bet or check
        if call_amount == 0:
            if equity > 0.6 and round_state.max_raise >= round_state.min_raise:
                # value bet ≈ ¾ pot
                raise_amt = int(pot_size * 0.75)
                raise_amt = min(round_state.max_raise, max(round_state.min_raise, raise_amt))
                return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0

        # 2. We must decide whether to call / raise / fold
        if equity < pot_odds - 0.05:
            return PokerAction.FOLD, 0

        # equity beats pot odds → call or raise
        # strong edge → raise for value
        if equity - pot_odds > 0.2 and round_state.max_raise >= round_state.min_raise:
            raise_amt = max(round_state.min_raise, call_amount * 2)
            raise_amt = min(raise_amt, round_state.max_raise)
            if raise_amt > call_amount:
                return PokerAction.RAISE, raise_amt

        return PokerAction.CALL, 0

    # -------------------------------------------------------------------------

    # noinspection PyUnusedLocal
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # nothing to clean up between rounds for this simple bot
        pass

    # noinspection PyUnusedLocal
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[Any, float],
        active_players_hands: Dict[Any, List[str]],
    ):
        # we don’t need end-game information yet
        pass