# player.py
import random
import itertools
from collections import Counter
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_TO_INT: Dict[str, int] = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}
INT_TO_RANK = {v: k for k, v in RANK_TO_INT.items()}


# --------------------  Helper functions for hand evaluation  -------------------- #
def _card_rank(card: str) -> int:
    return RANK_TO_INT[card[0]]


def _card_suit(card: str) -> str:
    return card[1]


def _is_straight(ranks: List[int]) -> Tuple[bool, int]:
    """Return (is_straight, highest_card_of_straight)."""
    ranks = sorted(set(ranks), reverse=True)
    # Add wheel straight possibility
    if 14 in ranks:
        ranks.append(1)
    for i in range(len(ranks) - 4):
        high = ranks[i]
        window = ranks[i:i + 5]
        if window == list(range(high, high - 5, -1)):
            return True, high if high != 1 else 5  # Wheel straight high card = 5
    return False, 0


def _evaluate_5(cards5: List[str]) -> Tuple[int, List[int]]:
    """Return (category, tie_breaker list) for a 5-card hand.
    Higher category is better. 8 = straight flush … 0 = high card.
    """
    ranks = [_card_rank(c) for c in cards5]
    suits = [_card_suit(c) for c in cards5]
    rank_counter = Counter(ranks)
    counts = sorted(rank_counter.values(), reverse=True)
    ordered_ranks = sorted(ranks, reverse=True)

    is_flush = len(set(suits)) == 1
    is_straight, high_in_straight = _is_straight(ranks)

    # Straight flush
    if is_flush and is_straight:
        return 8, [high_in_straight]
    # Four of a kind
    if counts[0] == 4:
        four_rank = rank_counter.most_common(1)[0][0]
        kicker = max(r for r in ranks if r != four_rank)
        return 7, [four_rank, kicker]
    # Full house
    if counts[0] == 3 and counts[1] == 2:
        trips = rank_counter.most_common(1)[0][0]
        pair = [r for r, c in rank_counter.items() if c == 2][0]
        return 6, [trips, pair]
    # Flush
    if is_flush:
        return 5, ordered_ranks
    # Straight
    if is_straight:
        return 4, [high_in_straight]
    # Three of a kind
    if counts[0] == 3:
        trips = rank_counter.most_common(1)[0][0]
        kickers = sorted([r for r in ranks if r != trips], reverse=True)
        return 3, [trips] + kickers
    # Two pair
    if counts[0] == 2 and counts[1] == 2:
        pairs = sorted([r for r, c in rank_counter.items() if c == 2], reverse=True)
        kicker = [r for r, c in rank_counter.items() if c == 1][0]
        return 2, pairs + [kicker]
    # One pair
    if counts[0] == 2:
        pair_rank = rank_counter.most_common(1)[0][0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
        return 1, [pair_rank] + kickers
    # High card
    return 0, ordered_ranks


def evaluate_best_hand(seven_cards: List[str]) -> Tuple[int, List[int]]:
    """Evaluate best 5-card hand from 7 cards."""
    best_cat = -1
    best_tiebreaker: List[int] = []
    for combo in itertools.combinations(seven_cards, 5):
        cat, tb = _evaluate_5(list(combo))
        if cat > best_cat or (cat == best_cat and tb > best_tiebreaker):
            best_cat, best_tiebreaker = cat, tb
    return best_cat, best_tiebreaker


def has_flush_draw(cards: List[str]) -> bool:
    suits = [_card_suit(c) for c in cards]
    return any(cnt >= 4 for cnt in Counter(suits).values())


def has_open_ended_straight_draw(cards: List[str]) -> bool:
    ranks = [_card_rank(c) for c in cards]
    ranks = set(ranks)
    if 14 in ranks:
        ranks.add(1)
    for start in range(2, 11):
        seq = {start, start + 1, start + 2, start + 3}
        if len(seq & ranks) == 4:
            return True
    return False


# --------------------  Pre-flop hand categorisation  -------------------- #
def _preflop_category(hole: List[str]) -> str:
    if len(hole) != 2:
        return "trash"
    r1, r2 = sorted([_card_rank(c) for c in hole], reverse=True)
    suited = _card_suit(hole[0]) == _card_suit(hole[1])
    pair = r1 == r2

    # Very strong
    if pair and r1 >= 10:
        return "very_strong"
    if r1 == 14 and r2 >= 13:  # AK
        return "very_strong"
    if suited and r1 == 14 and r2 >= 12:  # AKs, AQs
        return "very_strong"

    # Strong
    if pair and 7 <= r1 <= 9:
        return "strong"
    if suited and ((r1 == 14 and r2 >= 9) or (r1 == 13 and r2 >= 11)):
        return "strong"
    if not suited and (r1 == 14 and r2 >= 11):
        return "strong"

    # Playable
    if pair and 4 <= r1 <= 6:
        return "playable"
    if suited and r1 >= 11 and r2 >= 9:
        return "playable"
    if suited and r1 == 14 and r2 >= 6:
        return "playable"

    return "trash"


# --------------------  Bot implementation  -------------------- #
class SimplePlayer(Bot):
    """
    A relatively tight-aggressive Texas Hold'em bot.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.hole_cards: List[str] = []
        self.random = random.Random()

    # ---------------------------------------------------------------------- #
    #  Interface methods required by the framework.                          #
    # ---------------------------------------------------------------------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount * 2
        self.small_blind_amount = blind_amount
        # We receive our initial hole cards at game start in heads-up games.
        # In multi-round games hole cards are refreshed via `on_round_start`.
        self.hole_cards = player_hands or []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of every hand. Fetch new hole cards if provided."""
        # Many frameworks attach `player_hands` (dict) on the round_state – try to read it.
        if hasattr(round_state, "player_hands"):
            ph = getattr(round_state, "player_hands")
            if isinstance(ph, dict):
                # IDs might be either int or str; try both
                self.hole_cards = ph.get(self.id) or ph.get(str(self.id), [])
            elif isinstance(ph, list):
                # Some frameworks send list directly if only two players
                self.hole_cards = ph
        # Fallback: keep previous (best we can do)

    # ---------------------------------------------------------------------- #
    #  Decision logic                                                        #
    # ---------------------------------------------------------------------- #
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        # Determine amount to call and pot size
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = max(round_state.pot, 1)  # avoid divide by zero

        # SMALL helper to build safe actions
        def _safe_raise(amount: int) -> Tuple[PokerAction, int]:
            amount = max(amount, round_state.min_raise)
            amount = min(amount, round_state.max_raise)
            if amount < round_state.min_raise:
                # Cannot legally raise, default to call if possible
                return (PokerAction.CALL, 0) if to_call <= remaining_chips else (PokerAction.FOLD, 0)
            return PokerAction.RAISE, amount

        # Pre-flop strategy
        if round_state.round.lower() == "preflop":
            cat = _preflop_category(self.hole_cards)
            if cat == "very_strong":
                # 3-bet or open raise
                if to_call == 0:
                    return _safe_raise(self.big_blind_amount * 3)
                if to_call <= self.big_blind_amount * 2:
                    return _safe_raise(to_call * 2)
                # Facing huge shove
                return (PokerAction.CALL, 0) if to_call < remaining_chips * 0.3 else (PokerAction.FOLD, 0)

            if cat == "strong":
                if to_call == 0:
                    # Open raise
                    return _safe_raise(self.big_blind_amount * 2)
                if to_call <= self.big_blind_amount:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

            if cat == "playable":
                # Limp if cheap, otherwise fold
                return (PokerAction.CALL, 0) if to_call <= self.big_blind_amount else (PokerAction.FOLD, 0)

            # Trash hand
            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

        # ------------------------------------------------------------------ #
        # Post-flop strategy                                                 #
        # ------------------------------------------------------------------ #
        community = round_state.community_cards
        if not self.hole_cards or len(self.hole_cards) != 2:
            # Safety – if for some reason we do not have our cards, play tight
            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

        seven = self.hole_cards + community
        category, _ = evaluate_best_hand(seven)

        # Category mapping: 8=straight flush, …, 0=high card
        strong_made = category >= 3          # Trips or better
        medium_made = category == 2          # Two pair
        weak_pair = category == 1            # One pair
        draw = has_flush_draw(seven) or has_open_ended_straight_draw(seven)

        # Pot odds
        pot_odds = to_call / (pot + to_call)

        # Decision making
        if strong_made:
            # Value bet / raise
            if to_call == 0:
                return _safe_raise(int(pot * 0.75))
            # Willing to play big pot
            if to_call < remaining_chips * 0.5:
                return _safe_raise(to_call * 2)
            return (PokerAction.ALL_IN, 0)

        if medium_made:
            # Control pot size
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            if pot_odds <= 0.25:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        if weak_pair or draw:
            # Speculative – call small bets
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            if pot_odds <= 0.15:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # No hand – occasional bluff (very small frequency)
        if to_call == 0 and self.random.random() < 0.05:
            return _safe_raise(int(pot * 0.6))
        # Otherwise fold/check
        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

    # ---------------------------------------------------------------------- #
    #  Listener stubs (not used for strategy, but must be present)           #
    # ---------------------------------------------------------------------- #
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass