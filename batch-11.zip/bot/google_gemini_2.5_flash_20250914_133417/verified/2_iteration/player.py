import random
from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.num_players_at_start = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.num_players_at_start = len(all_players)
        # player_hands are the hole cards for the first hand of the game
        # For subsequent hands, hole cards are provided in on_round_start
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the new round, if provided (server might not send them here but on_start for first hand)
        # The hole cards for the current hand are usually given in the get_action call for pre-flop, or inferred from on_start
        # If the round_state contains player-specific info, we can update hole cards
        # For now, we assume hole cards are passed in get_action for the first action.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Fix for AttributeError: 'RoundStateClient' object has no attribute 'big_blind_player_id'
        # These attributes are passed in on_start and should be stored as instance variables.
        # However, the `player_hands` from `on_start` is for the *first* hand.
        # For subsequent hands, `player_hands` for *this specific hand* needs to be retrieved.
        # Since the framework doesn't explicitly provide `player_hands` in `get_action`
        # for intermediate hands, we must assume our `self.hole_cards` are updated
        # by the server or that `on_start`'s `player_hands` is the actual hole cards for this specific round.
        # The prompt says `player_hands` in `on_start` are for the first game.
        # Let's assume that `get_action` will be called with specific hole cards in a real scenario (or this is bug in provided client classes)
        # For now, let's make a dummy `self.hole_cards` if it's empty, anticipating it should be populated correctly by the system.
        if not self.hole_cards:
            # This is a fallback and assumes the server *should* provide actual hole cards.
            # In a real game, this would be a critical issue.
            # For iteration, let's use a placeholder if not set, but a real game engine should populate this.
            # The prompt "player_hands: List[str]" in on_start indicates initial cards.
            # Let's assume the game state 'player_hands' is what we need. However, RoundStateClient doesn't have it.
            # The only place player_hands is passed is on_start, FOR THE FIRST ROUND.
            # The bot template is missing a way to receive hole cards for subsequent rounds.
            # I will assume that the internal state of the bot maintains its hole cards through the game client.
            # If `self.hole_cards` isn't updated by the competition server for each round, the bot cannot play.
            # For the purpose of this exercise, I will use `self.hole_cards` as if it is always correctly set
            # for the *current* hand. If `self.hole_cards` is empty, it implies an issue with how the game state is passed.
            # Given the error, it's safer to assume I was expected to use the `on_start` arguments.
            # For repeated rounds (after the first one), the assumption is `self.hole_cards`
            # would be updated by the game system before `get_action` or `on_round_start` for the current hand.
            # Since the only place for player_hands is on_start, for successive hands that means this bot relies on
            # the server populating `self.hole_cards` in between rounds or that `hand_id` could be used to retrieve them.
            # This is an ambiguity in the template. I will proceed by assuming `self.hole_cards` correctly holds the current hand.
            # If this is the issue, I would need a different signature for `on_round_start` or `get_action`.
            pass # Keep self.hole_cards as whatever it was set to by on_start or previous round.

        # Card strength evaluation (Simplified)
        # This is a very basic evaluation and needs improvement for more complex strategy.
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        num_active_players = sum(1 for p_id in self.all_players if str(p_id) in round_state.player_bets and round_state.player_bets[str(p_id)] != -1) # -1 might indicate folded
        # A more accurate count of active players would be `len(round_state.current_player)` at the current moment
        # but this is also tricky as `current_player` only lists players whose turn it currently is or those who haven't folded.
        # Let's assume `num_active_players` is `len(set(round_state.player_bets.keys()) - set(folded_players))`.
        # For simplicity, let's consider anyone who hasn't folded as active.
        active_players_in_hand = [p_id for p_id in round_state.player_bets if p_id in [str(x) for x in self.all_players] and round_state.player_bets[p_id] != round_state.current_bet] # Simplified, assuming player_bets contains actual current bets. `player_bets[p_id] == -1` could mean folded.
        # Better: active_players (excluding current player) is len(round_state.current_player) after current player's turn if they don't fold.
        # For decision making, let's use a simple heuristic based on player_bets.
        # Anyone still in the current betting round.
        
        # A player is "active" if they haven't folded and still have chips, and are involved in current betting.
        # Let's try to infer active players from round_state.player_bets
        # If a player has bet 0 and it's not their turn or they haven't acted, they might be in.
        # If a player has folded, their bet is likely reset or removed from `player_bets` or marked in `player_actions`.
        # RoundStateClient.current_player only contains list of players whose turn it is or have yet to act.
        
        # Let's make an assumption: players in `round_state.player_bets` who have *not* folded (from `player_actions`)
        # are active. This is an approximation.
        
        active_players = 0
        for p_id in self.all_players:
            p_id_str = str(p_id)
            if p_id_str in round_state.player_actions:
                if round_state.player_actions[p_id_str] != 'Fold':
                    active_players += 1
            else:
                # If a player hasn't acted yet, they are implicitly active.
                active_players += 1
        
        if self.id is not None and str(self.id) in round_state.player_actions and round_state.player_actions[str(self.id)] == 'Fold':
            # This bot has already folded in this round, should not get action call
            # But just in case, return FOLD. This implies incorrect state management by the server.
            return PokerAction.FOLD, 0
            
        # Determine the amount to call
        bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Ensure bet_to_call doesn't exceed our chips
        bet_to_call = min(bet_to_call, remaining_chips)

        # Basic strategy based on hand strength and round
        # Adjusting strategy based on number of players
        num_vaguely_active_players = len([p for p in round_state.player_bets if round_state.player_bets[p] >= 0])
        if num_vaguely_active_players == 0: # This means we are the only active player left.
            return PokerAction.CHECK, 0 # This condition should ideally not happen if we are asked to act.

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            if bet_to_call > 0: # Someone has raised
                if hand_strength >= 2: # Strong pair or higher
                    # Aggressive play: raise
                    # Min raise is 2x current bet, but here min_raise is the minimum *additional* amount for a raise.
                    # so total bet would be round_state.current_bet + round_state.min_raise
                    raise_amount = round_state.current_bet + max(self.blind_amount * 2, round_state.min_raise)
                    # Cap raise to remaining chips
                    raise_amount = min(raise_amount, remaining_chips)
                    # Make sure the raise is valid
                    if remaining_chips > bet_to_call and raise_amount > round_state.current_bet + round_state.min_raise - 1: # ensure raise is significant
                        return PokerAction.RAISE, int(raise_amount)
                    else: # Can't raise enough or not worth it
                        if hand_strength >= 1: # decent hand
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                elif hand_strength == 1: # Marginal hand (e.g., small pair, high card suited, connectors)
                    if bet_to_call <= self.blind_amount * 1.5: # Small bet to call relative to blinds
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Weak hand
                    return PokerAction.FOLD, 0
            else: # No raise, we can check or raise
                if hand_strength >= 2: # Strong pair or higher
                    # Raise for value
                    raise_amount = max(self.blind_amount * 2, round_state.min_raise)
                    raise_amount = min(round_state.current_bet + raise_amount, remaining_chips)
                    return PokerAction.RAISE, int(raise_amount)
                elif hand_strength == 1:
                    # Check or raise small if cheap
                    if random.random() < 0.2: # Sometimes raise with marginal
                        raise_amount = max(self.blind_amount, round_state.min_raise)
                        raise_amount = min(round_state.current_bet + raise_amount, remaining_chips)
                        return PokerAction.RAISE, int(raise_amount)
                    else:
                        return PokerAction.CHECK, 0
                else: # Weak hand
                    return PokerAction.CHECK, 0 # Safest bet if no cost

        # Post-flop strategy (Flop, Turn, River)
        required_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # All-in condition check
        if required_to_call >= remaining_chips: # If required to call is more than or equal to our chips
            if hand_strength >= 3: # Strong hand (e.g., two pair or better)
                return PokerAction.ALL_IN, 0
            elif hand_strength >= 2 and random.random() < 0.5: # Decent hand, sometimes go all-in
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        # General post-flop strategy
        if bet_to_call > 0: # There's a bet to call
            if hand_strength >= 3: # Strong hand (e.g., Two Pair, Trips, better)
                # Raise for value
                raise_amount = round_state.current_bet + max(round_state.min_raise, round_state.pot // 2)
                raise_amount = min(raise_amount, remaining_chips)
                if raise_amount > required_to_call and remaining_chips > required_to_call: # Only raise if we can meaningfully raise
                    return PokerAction.RAISE, int(raise_amount)
                else:
                    return PokerAction.CALL, 0
            elif hand_strength == 2: # Medium hand (e.g., One pair, strong draws)
                # Call or small raise if pot is large
                if bet_to_call <= round_state.pot / (num_vaguely_active_players + 0.001) or random.random() < 0.2: # Pot odds or small bluff
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength == 1 and bet_to_call < round_state.pot / 5: # Weak marginal hand, only call small bets
                return PokerAction.CALL, 0
            else: # Weak hand, fold
                return PokerAction.FOLD, 0
        else: # No bet, we can check or bet
            if hand_strength >= 3: # Strong hand
                # Bet for value
                bet_amount = max(round_state.min_raise, round_state.pot // 2)
                bet_amount = min(round_state.current_bet + bet_amount, remaining_chips)
                return PokerAction.RAISE, int(bet_amount)
            elif hand_strength == 2: # Medium hand
                # Check, or small bet
                if random.random() < 0.3: # Sometimes bet for value/bluff
                    bet_amount = max(round_state.min_raise, round_state.pot // 3)
                    bet_amount = min(round_state.current_bet + bet_amount, remaining_chips)
                    return PokerAction.RAISE, int(bet_amount)
                else:
                    return PokerAction.CHECK, 0
            else: # Weak hand
                return PokerAction.CHECK, 0 # Check and hope for a free card or showdown

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round (they will be populated by on_start for the first game, or implicitly by get_action)
        self.hole_cards = []
        # In a real system, hole cards would be passed explicitly for the new round.
        # This is a critical assumption that the game framework will update this.

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """
        A very simple hand strength evaluator.
        Returns an integer representing basic hand strength:
        0: High Card
        1: One Pair / Weak Draw (e.g., gutshot, weak flush draw)
        2: Two Pair / Strong Draw (e.g., open-ended straight draw, strong flush draw)
        3: Three of a Kind / Straight / Flush
        4: Full House / Four of a Kind / Straight Flush / Royal Flush
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2: # Not enough cards to evaluate
            return 0 
        
        # Card values and suits
        values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        # Example card: 'Ah' (Ace of hearts). We need to parse this.
        
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) == 2:
                rank_char = card_str[0]
                suit_char = card_str[1]
            elif len(card_str) == 3 and card_str[0:2] == '10': # Handle '10h'
                rank_char = 'T'
                suit_char = card_str[2]
            else:
                continue # Unparseable card
            
            parsed_cards.append((values.get(rank_char, 0), suit_char))
            
        if not parsed_cards:
            return 0

        # Count ranks and suits
        rank_counts: Dict[int, int] = {}
        suit_counts: Dict[str, int] = {}
        for rank, suit in parsed_cards:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1

        # Check for flushes
        is_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straights
        sorted_ranks = sorted(list(set([r for r, s in parsed_cards])), reverse=True)
        is_straight = False
        if len(sorted_ranks) >= 5:
            # Check for standard straights
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i] - sorted_ranks[i+1] == 1 and \
                   sorted_ranks[i+1] - sorted_ranks[i+2] == 1 and \
                   sorted_ranks[i+2] - sorted_ranks[i+3] == 1 and \
                   sorted_ranks[i+3] - sorted_ranks[i+4] == 1:
                    is_straight = True
                    break
            # Check for A-5 straight (low straight)
            if not is_straight and 14 in sorted_ranks and 5 in sorted_ranks and 4 in sorted_ranks and 3 in sorted_ranks and 2 in sorted_ranks:
                is_straight = True

        # Check for pairs, trips, quads
        pairs = 0
        trips = 0
        quads = 0
        for rank, count in rank_counts.items():
            if count == 2:
                pairs += 1
            elif count == 3:
                trips += 1
            elif count == 4:
                quads += 1

        # Determine hand strength score
        if is_straight and is_flush:
            return 4 # Straight Flush / Royal Flush (highest)
        if quads >= 1:
            return 4 # Four of a Kind
        if trips >= 1 and pairs >= 1 or trips >= 2: # Full House (e.g., TTTKK or 999 TTT)
            return 4
        if is_flush:
            return 3 # Flush
        if is_straight:
            return 3 # Straight
        if trips >= 1:
            return 3 # Three of a Kind
        if pairs >= 2:
            return 2 # Two Pair
        if pairs == 1:
            # Check if it's a strong pair (Jacks or better) or if it's just a weak pair
            strong_pair = False
            for rank, count in rank_counts.items():
                if count == 2 and rank >= values['J']: # Jacks or better
                    strong_pair = True
                    break
            if strong_pair:
                return 2 # Strong pair
            else:
                return 1 # Weak pair

        # If only high card, consider hole card strength
        if len(hole_cards) == 2:
            hole_rank_values = sorted([values.get(c[0] if len(c) == 2 else 'T', 0) for c in hole_cards], reverse=True)
            if hole_rank_values[0] >= values['A'] and hole_rank_values[1] >= values['K']: # AK suited/off
                return 1.5 # Between high card and pair, good starting hand
            elif hole_rank_values[0] >= values['Q'] and hole_rank_values[1] >= values['J']: # QJ, KQ, etc.
                return 1 # Better high card

        return 0 # High card only or very weak hand