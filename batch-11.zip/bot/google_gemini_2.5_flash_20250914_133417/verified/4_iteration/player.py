import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.initial_stack = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_map = {} # Map player_id to index if needed
        self.hand_strength_preflop = {}
        self._initialize_hand_strength_preflop()

    def _initialize_hand_strength_preflop(self):
        # Using a simplified Sklansky-Chubukov ranking.
        # This is a very basic pre-flop hand strength approximation.
        # Ranks from 1 (strongest) to N (weakest).
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        rank_values = {r: i for i, r in enumerate(ranks)}

        def get_hand_rank(card1, card2, suited):
            r1 = rank_values[card1[0]]
            r2 = rank_values[card2[0]]
            
            if r1 < r2:
                r1, r2 = r2, r1 # Ensure r1 is always the higher rank

            if suited:
                # Suited connectors/one-gappers high cards are strong
                if r1 == rank_values['A'] and r2 == rank_values['K']: return 1 # AKs
                if r1 == rank_values['A'] and r2 == rank_values['Q']: return 2 # AQs
                if r1 == rank_values['A'] and r2 == rank_values['J']: return 3 # AJs
                if r1 == rank_values['K'] and r2 == rank_values['Q']: return 4 # KQs
                if r1 >= rank_values['J'] and r2 >= rank_values['T']: return 5 # JJ+ TT+
                if r1 - r2 <= 1 and r1 >= rank_values['8']: return 6 # Suited connectors 89s+
                if r1 == rank_values['A']: return 7 # All other suited Aces
                return 8

            else:
                # Pairs
                if r1 == r2:
                    if r1 >= rank_values['Q']: return 1 # AA, KK, QQ
                    if r1 >= rank_values['8']: return 2 # JJ, TT, 99, 88
                    return 3 # Smaller pairs

                # Offsuit
                if r1 == rank_values['A'] and r2 == rank_values['K']: return 4 # AKo
                if r1 == rank_values['A'] and r2 == rank_values['Q']: return 5 # AQo
                if r1 == rank_values['A'] and r2 == rank_values['J']: return 6 # AJo
                return 7
            
            return 9 # weaker hands

        all_possible_hands = []
        for i in range(len(ranks)):
            for j in range(i, len(ranks)):
                r1 = ranks[i]
                r2 = ranks[j]
                
                # Paired
                if i == j:
                    hand_str = f"{r1}{r2}"
                    # Just need rank values to create a dummy card for hand_rank calculation
                    dummy_card1 = f"{r1}s"
                    dummy_card2 = f"{r2}h"
                    self.hand_strength_preflop[hand_str] = get_hand_rank(dummy_card1, dummy_card2, False) # Suited doesn't apply to pairs
                
                # Unpaired
                else: 
                    # Suited
                    hand_str_s = f"{r1}{r2}s" if rank_values[r1] > rank_values[r2] else f"{r2}{r1}s"
                    dummy_card1_s = f"{r1}s"
                    dummy_card2_s = f"{r2}s"
                    self.hand_strength_preflop[hand_str_s] = get_hand_rank(dummy_card1_s, dummy_card2_s, True)

                    # Offsuit
                    hand_str_o = f"{r1}{r2}o" if rank_values[r1] > rank_values[r2] else f"{r2}{r1}o"
                    dummy_card1_o = f"{r1}s"
                    dummy_card2_o = f"{r2}h"
                    self.hand_strength_preflop[hand_str_o] = get_hand_rank(dummy_card1_o, dummy_card2_o, False)


    def _get_hand_string(self, hand: List[str]) -> str:
        if not hand or len(hand) != 2:
            return "???"
        
        card1_rank = hand[0][0]
        card1_suit = hand[0][1]
        card2_rank = hand[1][0]
        card2_suit = hand[1][1]

        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        if rank_values[card1_rank] < rank_values[card2_rank]:
            card1_rank, card2_rank = card2_rank, card1_rank

        if card1_rank == card2_rank:
            return f"{card1_rank}{card2_rank}"
        elif card1_suit == card2_suit:
            return f"{card1_rank}{card2_rank}s"
        else:
            return f"{card1_rank}{card2_rank}o"


    def _evaluate_hand_strength(self, hole_cards: List[str], board_cards: List[str]) -> float:
        """
        Evaluates the strength of a hand given hole cards and community cards.
        Returns a score from 0.0 to 1.0, where 1.0 is the strongest.
        This is a very simple placeholder. A real bot would use Monte Carlo simulations
        or pre-calculated equities.
        """
        all_cards = hole_cards + board_cards
        if len(all_cards) < 5:
            # Pre-flop, or not enough cards to form a 5-card hand
            if not hole_cards:
                return 0.0

            hand_str = self._get_hand_string(hole_cards)
            rank = self.hand_strength_preflop.get(hand_str, 9) # Default to weakest if not found
            # Normalize to 0-1, lower rank is stronger
            return 1.0 - (rank / 9.0) * 0.5 # Scale down pre-flop to be less aggressive

        # Simple hand evaluation (very basic, actual implementation needs robust poker hand evaluator)
        # This part requires a full poker hand evaluator to be accurate.
        # For now, let's just make a very rough estimation based on pairs in hand.
        
        ranks = [self._get_card_rank_value(card) for card in all_cards]
        
        pair_count = 0
        for r in set(ranks):
            if ranks.count(r) >= 2:
                pair_count += 1

        if pair_count >= 2: # Two pair or better
            return 0.8
        elif pair_count == 1: # One pair
            return 0.5
        elif self._has_straight_draw(hole_cards, board_cards):
            return 0.4
        elif self._has_flush_draw(hole_cards, board_cards):
            return 0.4
        else: # High card
            # Adjust based on the highest card rank
            max_rank = max(ranks) / 14.0 # Max rank A is 14
            return 0.1 + max_rank * 0.2 # Range from 0.1 to 0.38

    def _get_card_rank_value(self, card_str: str) -> int:
        rank_char = card_str[0]
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(rank_char, 0)
    
    def _get_card_suit(self, card_str: str) -> str:
        return card_str[1]
        
    def _has_flush_draw(self, hole_cards: List[str], board_cards: List[str]) -> bool:
        all_cards = hole_cards + board_cards
        suit_counts = {}
        for card in all_cards:
            suit = self._get_card_suit(card)
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        return any(count >= 4 for count in suit_counts.values())

    def _has_straight_draw(self, hole_cards: List[str], board_cards: List[str]) -> bool:
        all_ranks = sorted(list(set([self._get_card_rank_value(card) for card in hole_cards + board_cards])))
        
        # Add Ace as 1 for A-2-3-4-5 straight possibility
        if 14 in all_ranks:
            all_ranks.insert(0, 1)

        for i in range(len(all_ranks) - 3):
            if all_ranks[i+3] - all_ranks[i] <= 4: # Checking for open-ended or gutshot draws
                return True
        return False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_stack = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.id)] if str(self.id) in round_state.player_hands else []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Calculate effective stack for all-in considerations
        effective_stack = remaining_chips - current_bet_to_call if current_bet_to_call < remaining_chips else 0
        max_raise_amount = round_state.max_raise
        min_raise_amount = round_state.min_raise

        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            if hand_strength >= 0.7:  # Premium hands (AA, KK, QQ, AKs)
                if current_bet_to_call == 0: # Can check
                    return (PokerAction.RAISE, min(max_raise_amount, 3 * self.blind_amount + min_raise_amount)) # 3x big blind + min raise, or all-in
                elif current_bet_to_call < remaining_chips * 0.2: # Don't commit too much pre-flop
                    return (PokerAction.RAISE, min(max_raise_amount, current_bet_to_call * 2 + min_raise_amount)) # Re-raise
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength >= 0.5: # Strong hands (JJ, TT, 99, AQs, KQs)
                if current_bet_to_call == 0:
                    return (PokerAction.RAISE, min(max_raise_amount, 2 * self.blind_amount + min_raise_amount)) # 2x big blind + min raise
                elif current_bet_to_call < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength >= 0.3: # Medium hands (small pairs, suitable connectors)
                if current_bet_to_call == 0:
                    return (PokerAction.CALL, 0) # Limp or Check
                elif current_bet_to_call < remaining_chips * 0.05 and self.id == self.big_blind_player_id: # Call if big blind and cheap
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else: # Weak hands
                if current_bet_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength >= 0.8: # Very strong hand (e.g., Two pair+)
                if current_bet_to_call == 0:
                    return (PokerAction.RAISE, max(min_raise_amount, int(round_state.pot * 0.75)))
                elif current_bet_to_call < remaining_chips * 0.3: # Call smaller bets
                    return (PokerAction.RAISE, max(min_raise_amount, current_bet_to_call * 2 + min_raise_amount)) # Aggressively raise
                else: # Opponent bet too much, consider all-in
                    return (PokerAction.ALL_IN, 0)
            elif hand_strength >= 0.6: # Strong hand (e.g., Top pair)
                if current_bet_to_call == 0:
                    return (PokerAction.RAISE, max(min_raise_amount, int(round_state.pot * 0.5))) # Bet half pot
                elif current_bet_to_call < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength >= 0.4: # Medium strength (e.g., Draw or weak pair)
                if current_bet_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif current_bet_to_call < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else: # Weak hand
                if current_bet_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Default action if no condition met (should ideally not happen with comprehensive logic)
        return (PokerAction.FOLD, 0)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass