from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.player_id = None
        self.hand_strength_preflop = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands will only contain the bot's own hand, but as a list of strings
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update our perceived hole cards if provided (though it typically comes in on_start for the first round)
        # This method is more for setting up per-round state if needed, not for initial hand.
        pass

    def _get_card_rank_value(self, card_rank: str) -> int:
        if card_rank == 'A':
            return 14
        elif card_rank == 'K':
            return 13
        elif card_rank == 'Q':
            return 12
        elif card_rank == 'J':
            return 11
        elif card_rank == 'T':
            return 10
        else:
            return int(card_rank)

    def _evaluate_preflop_hand_strength(self, hole_cards: List[str]) -> float:
        if not hole_cards or len(hole_cards) != 2:
            return 0.0

        card1_rank = hole_cards[0][0]
        card1_suit = hole_cards[0][1]
        card2_rank = hole_cards[1][0]
        card2_suit = hole_cards[1][1]

        rank1_val = self._get_card_rank_value(card1_rank)
        rank2_val = self._get_card_rank_value(card2_rank)

        # Ensure rank1_val >= rank2_val for consistent evaluation
        if rank1_val < rank2_val:
            rank1_val, rank2_val = rank2_val, rank1_val

        # Base strength for pairs
        if rank1_val == rank2_val:
            return 0.5 + (rank1_val / 14.0) * 0.4 # Strong pairs get higher strength

        strength = 0.0

        # Suited bonus
        suited = (card1_suit == card2_suit)
        if suited:
            strength += 0.05

        # Connectedness bonus
        if rank1_val - rank2_val == 1: # Connected
            strength += 0.04
        elif rank1_val - rank2_val == 2: # One-gapper
            strength += 0.02
        
        # High card bonus
        strength += (rank1_val / 14.0) * 0.2 + (rank2_val / 14.0) * 0.1

        # Adjust for unsuited and unconnected if values are low
        if not suited and rank1_val - rank2_val > 2 and rank1_val < 10:
            strength -= 0.1

        # Cap strength between 0 and 1
        return max(0.0, min(1.0, strength))

    def _get_hand_rank(self, cards: List[str]) -> Tuple[int, List[int]]:
        # This is a simplified hand ranking for quick preflop/early postflop evaluation.
        # A full poker hand evaluator would be very complex and slow.
        # For competitive play, a more robust and fast hand evaluator is usually pre-computed or optimized.

        ranks = [self._get_card_rank_value(c[0]) for c in cards]
        suits = [c[1] for c in cards]
        ranks.sort(reverse=True)

        is_flush = (len(set(suits)) == 1 and len(cards) >= 5)
        
        # Check straights
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        straight_high_card = 0
        if len(unique_ranks) >= 5:
            # Check for A-5 straight (wheel)
            if all(r in unique_ranks for r in [14, 5, 4, 3, 2]):
                straight_high_card = 5
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    straight_high_card = max(straight_high_card, unique_ranks[i])
        
        # Count rank occurrences
        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        
        # Check for poker hand types in decreasing order of strength
        # Four of a kind
        for r, count in rank_counts.items():
            if count == 4:
                return (8, [r]) # Hand rank 8, kicker not handled here for simplicity

        # Full House
        three_of_a_kind_rank = 0
        pair_rank = 0
        for r, count in rank_counts.items():
            if count == 3:
                three_of_a_kind_rank = r
            elif count == 2:
                pair_rank = max(pair_rank, r)
        if three_of_a_kind_rank and pair_rank:
            return (7, [three_of_a_kind_rank, pair_rank])

        # Flush
        if is_flush:
            return (6, ranks[:5]) # Assuming top 5 highest cards for flush

        # Straight
        if straight_high_card:
            return (5, [straight_high_card])
        
        # Three of a kind
        if three_of_a_kind_rank:
            return (4, [three_of_a_kind_rank])
        
        # Two Pair
        pairs = []
        for r, count in rank_counts.items():
            if count == 2:
                pairs.append(r)
        if len(pairs) >= 2:
            pairs.sort(reverse=True)
            return (3, pairs[:2] + [r for r in ranks if r not in pairs][:1]) # two highest pairs + one kicker

        # One Pair
        if pair_rank:
            return (2, [pair_rank] + [r for r in ranks if r != pair_rank][:3]) # one pair + three kickers
        
        # High Card
        return (1, ranks[:5]) # Five highest cards for high card

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        community_cards = round_state.community_cards
        
        my_current_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet_in_round
        
        # Opponent's perceived aggression for this round
        opponent_actions = [action for player_id, action in round_state.player_actions.items() if str(player_id) != str(self.id)]
        is_opponent_aggressive = "Raise" in opponent_actions or "All_in" in opponent_actions
        
        total_cards = self.hole_cards + community_cards
        
        # Pre-flop strategy
        if round_state.round == PokerRound.PREFLOP.name:
            self.hand_strength_preflop = self._evaluate_preflop_hand_strength(self.hole_cards)
            
            if self.hand_strength_preflop >= 0.75: # Premium hands (AA, KK, QQ, AKs)
                # Aggressive play: Raise or Re-raise
                if call_amount > 0 and call_amount > remaining_chips * 0.3: # Don't commit too much if opponent already went big
                    return (PokerAction.CALL, 0) # Call big bets for very strong hands
                else:
                    raise_amount = min(max_raise, max(min_raise, current_bet * 2)) # Raise 2-3x current bet
                    if raise_amount > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)

            elif self.hand_strength_preflop >= 0.5: # Strong hands (JJ, TT, AQ, KQs, suited connectors)
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= self.blind_amount * 3: # Call small bets
                    return (PokerAction.CALL, 0)
                else: # Don't call big bets, consider a small raise if no one has raised much
                    if not is_opponent_aggressive and remaining_chips > min_raise * 2:
                        raise_amount = min(max_raise, max(min_raise, current_bet + self.blind_amount * 2))
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.FOLD, 0)

            elif self.hand_strength_preflop >= 0.3: # Medium hands (small pairs, some suited gappers)
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= self.blind_amount * 2: # Call for cheap draws or if in a blind position
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else: # Weak hands
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= self.blind_amount / 2: # Call small blind for very cheap
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Post-flop strategy (Flop, Turn, River)
        current_hand_rank, _ = self._get_hand_rank(total_cards)
        
        if current_hand_rank >= 5: # Strong hand (Straight or better)
            # Bet or raise aggressively
            if call_amount > 0:
                if call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                raise_amount = min(max_raise, max(min_raise, current_bet * 2))
                if raise_amount == 0 and remaining_chips > self.blind_amount: # If min_raise is 0 (first to act)
                    return (PokerAction.RAISE, self.blind_amount * 2) # Bet 2x BB
                return (PokerAction.RAISE, raise_amount if raise_amount > 0 else (remaining_chips if remaining_chips > self.blind_amount else self.blind_amount))
            elif current_bet == 0:
                raise_amount = min(max_raise, self.blind_amount * 2 if self.blind_amount * 2 > 0 else remaining_chips // 2)
                if raise_amount == 0 and remaining_chips > 0: # Handle cases where blind might be 0, or min_raise is too small
                    raise_amount = remaining_chips // 2 if remaining_chips > 0 else 1
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CALL, 0) # Should not happen if current_bet > 0 and no call_amount. Means we were first to act for current bet
        
        elif current_hand_rank >= 2: # Medium hand (One pair or two pair)
            if call_amount > 0:
                if call_amount >= remaining_chips * 0.5 and is_opponent_aggressive: # Don't over commit
                    return (PokerAction.FOLD, 0)
                if call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            elif current_bet == 0:
                # Value bet if we think we are ahead
                # If hand strength is high and there are few community cards, bet more
                if current_hand_rank == 3: # Two pair, good hand
                    raise_amount = min(max_raise, self.blind_amount * 1.5 if self.blind_amount * 1.5 > 0 else remaining_chips // 3)
                    return (PokerAction.RAISE, raise_amount if raise_amount > 0 else (remaining_chips if remaining_chips > self.blind_amount else self.blind_amount))
                elif current_hand_rank == 2: # One pair, be cautious
                    raise_amount = min(max_raise, self.blind_amount if self.blind_amount > 0 else remaining_chips // 4)
                    return (PokerAction.RAISE, raise_amount if raise_amount > 0 else (remaining_chips if remaining_chips > self.blind_amount else self.blind_amount))
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CALL, 0) # This state means we were first to act, opponent raised, and we are reacting from here

        else: # Weak hand (High card)
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount: # Call minimal bets if cheap
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Fallback to a safe action
        if call_amount > 0:
            if call_amount >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, 0)
        return (PokerAction.CHECK, 0)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass