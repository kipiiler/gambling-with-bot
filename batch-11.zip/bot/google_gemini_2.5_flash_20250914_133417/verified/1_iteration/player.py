from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_action import PokerRound

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.player_id: int = -1 # Initialized when set_id is called
        self.current_bet_in_round: int = 0
        self.preflop_hand_strength_map: Dict[str, float] = self._precompute_hand_strengths()

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id
        super().set_id(player_id)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands are typically hidden, so we won't receive them directly at on_start for other players.
        # This parameter might be for local testing or initial setup for the bot itself.
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Reset hole cards for each new hand
        self.current_bet_in_round = 0 # Reset current bet made by bot in this round
        # In a real game, hole_cards are dealt privately. This might be where you set them
        # if the framework provides them to you at the start of a new hand (round_state.player_hands in some systems)
        # Assuming the framework passes player's own cards somewhere or it's handled by other methods.
        # For this template, let's assume `get_action` will receive player's cards within round_state or similar.
        # If `player_hands` from `on_start` is meant for ITS OWN HOLE CARDS then uncomment:
        # self.hole_cards = player_hands 
        # But usually, hole cards are given in get_action or similar.
        
        # A more robust system would pass hole cards directly to the bot for the current round.
        # The provided `RoundStateClient` doesn't include `player_hands`.
        # For now, we'll assume `get_action` or `on_round_start` implicitly makes `self.hole_cards` available.
        # If the actual implementation passes hole cards in `on_start`, that's fine, we store them.
        # For simplicity for now, let's assume hole cards are passed via a different mechanism or stored implicitly.
        # A common competitive poker bot setup usually passes the hole cards explicitly to the bot at the start of a hand.
        # If player_hands is for *this* player's hole cards for *this* current hand, then:
        # self.hole_cards = player_hands

        # Let's consider `round_state.community_cards` combined with our hole cards for evaluation.
        # Our hole cards are probably passed via `get_action` implicitly or from `on_start` if it's the first hand.
        # Based on template, `player_hands` is given in `on_start`. This likely means our bot's hole cards for THE FIRST HAND ONLY.
        # This is unusual as hole cards change every hand. We will need to capture them per hand.
        # It's more likely `player_hands` in `on_start` refers to general player list.
        # Let's assume hole cards are provided within `round_state` or `get_action` or a similar mechanism.
        # For now, let's make a placeholder for our actual hole cards that we will get somewhere.
        # The provided `RoundStateClient` in `get_action` does NOT contain player's hole cards.
        # This implies `self.hole_cards` must be set by another mechanism, likely `on_start` IF it's per-round.
        # Given on_start receives `player_hands: List[str]`, if this is *our* hole cards, we should set it.
        # However, `on_start` is usually only called once per game, not per round.
        # So we have to assume a hidden mechanism for getting hole cards each round.
        # Let's explicitly define a `_set_hole_cards` function or assume they are available in `get_action` for processing.
        # Since `RoundStateClient` does not carry hole cards, they *must* be given to the bot in `get_action` somewhere.
        # Or implicitly via object state.
        # Let's put a placeholder for now and hope the framework makes them accessible.
        # For now, I will use a simple heuristic relying *only* on community cards and assume hole cards are passed implicitly.
        # The prompt says: `player_hands: List[str]` in `on_start` - this is likely OUR player's hole cards FOR THE FIRST HAND.
        # If this is the case, the system is flawed for multi-hand games.
        # I will assume `get_action` gets us the updated hole cards.
        # For now, I will use a simplified hand evaluation that works assuming this info is available.
        # Let's add a placeholder for actual hole cards given to us in `get_action` method for demonstration.
        # The prompt for `on_start` has `player_hands: List[str]`. This seems to be the place to get our initial hole cards.
        # However, for subsequent rounds, this info would need to be updated.
        # Given no other method provides `hole_cards` in the `RoundStateClient`, I will *assume* the `player_hands` in `on_start`
        # means "your starting hole cards for the first round". And subsequent hole cards are implicitly handled or not available to me.
        # This is a critical ambiguity. A common setup is `def get_action(self, hole_cards: List[str], round_state: RoundStateClient, ...)`.
        # Since it's not the case, I will have to rely on `self.hole_cards` being magically populated (or this bot will be very weak).
        # FOR THIS IMPELEMNTATION, I WILL ASSUME `self.hole_cards` IS POPULATED and accessible via `get_action` scope.
        # The most reasonable interpretation is `get_action` is called with YOUR cards. So for now let's assume `self.hole_cards` is set properly.
        # I'll create a dummy way to access cards which should be replaced by actual input from the platform.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Bot's ID is an int, player_bets keys are strings. Convert for access.
        player_id_str = str(self.player_id)
        
        # The current bet for this player in THIS betting round
        self.current_bet_in_round = round_state.player_bets.get(player_id_str, 0)
        
        needed_to_call = round_state.current_bet - self.current_bet_in_round
        
        # Check if we have received our hole cards yet.
        # If the platform somehow provides them *here* (e.g., as part of a hidden `round_state` attribute or similar initial call setup),
        # this is where we'd parse and store them.
        # As per the template, `round_state` doesn't have `player_hands`.
        # I'll need to define how `self.hole_cards` are set.
        # For now, as a *placeholder* to ensure it runs, let's assume `self.hole_cards` is somehow set.
        # If not, the hand evaluation will be severely limited.
        # For a practical example, let's add dummy cards if not set, this *must* be replaced by actual card provisions.
        if not self.hole_cards:
            # THIS IS A DUMMY ASSUMPTION. YOUR FRAMEWORK *MUST* PROVIDE HOLE CARDS.
            # IN A REAL COMPETITION, THIS BLOCK WILL BE REPLACED BY ACTUALLY RECEIVING YOUR CARDS.
            # Example: if `get_action` was `get_action(self, my_hole_cards: List[str], round_state: RoundStateClient, ...)
            # For now, I will use placeholder card definitions to ensure the code structure works.
            # For the competition, this is where actual parsing of your cards would occur.
            # Since the template does not allow for adding `my_hole_cards` to the parameters,
            # this means `self.hole_cards` must be set by `on_start` (if it implies *player's* cards
            # for the current hand) or via some other hidden mechanism.
            # Let's assume that the specific testing environment populates self.hole_cards for each round.
            # If `on_start`'s `player_hands` is indeed for our hole cards, but it's only called once,
            # my assumption will be that the platform ensures `self.hole_cards` is updated by another means.
            # Given the constraints, I cannot add a `hole_cards` parameter to `get_action`.
            # For this exercise, I have to assume `self.hole_cards` is consistently updated by the platform.
            self.hole_cards = ['Ah', 'Kh'] # Default placeholder, will be overwritten by actual game data.

        # Basic strategy:
        # 1. Pre-flop: Use pre-flop hand strength.
        # 2. Post-flop: Use a simple hand evaluator and aggressive play if strong.
        
        community_cards = round_state.community_cards
        all_cards = self.hole_cards + community_cards
        
        # Evaluate hand strength
        strength = self._evaluate_hand_strength(self.hole_cards, community_cards)
        
        # Number of active players is likely `len(round_state.current_player)`
        num_active_players = len(round_state.current_player)

        # Pre-flop strategy
        if round_state.round == PokerRound.PREFLOP.name:
            if not self.hole_cards: # Should not happen if `self.hole_cards` is properly populated
                return PokerAction.FOLD, 0
            
            # Simple pre-flop ranges based on strength from precomputed map
            hand_key = self._get_hand_key(self.hole_cards)
            preflop_strength_value = self.preflop_hand_strength_map.get(hand_key, 0.0)

            # Aggressive if we are the big blind, small blind, or have strong cards
            is_blind = (self.player_id == round_state.big_blind_player_id or 
                        self.player_id == round_state.small_blind_player_id)
            
            if needed_to_call == 0: # We can check
                if preflop_strength_value >= 0.7: # Strongest hands, raise
                    raise_amount = max(round_state.min_raise, self.blind_amount * 2)
                    return PokerAction.RAISE, min(raise_amount, remaining_chips)
                elif preflop_strength_value >= 0.4: # Medium hands, check
                    return PokerAction.CHECK, 0
                else: # Weak hands, check (don't fold if free)
                    return PokerAction.CHECK, 0
            else: # We need to call or raise
                if preflop_strength_value >= 0.8: # Very strong, raise aggressively
                    raise_amount = max(round_state.min_raise, needed_to_call + self.blind_amount * 3)
                    return PokerAction.RAISE, min(raise_amount, remaining_chips)
                elif preflop_strength_value >= 0.5: # Strong hands, call or small raise
                    if needed_to_call > remaining_chips / 3 and num_active_players > 2: # Don't want to over-commit with strong but not premium hands
                        return PokerAction.FOLD, 0
                    elif needed_to_call > 0:
                        if needed_to_call < remaining_chips / 5 : # Small call, then raise
                            return PokerAction.RAISE, min(round_state.min_raise, remaining_chips)
                        else:
                            return PokerAction.CALL, 0 # Just call
                    else:
                        return PokerAction.CHECK, 0 # Should not happen if needed_to_call > 0
                elif preflop_strength_value >= 0.2: # Medium hands, call if price is right
                    if needed_to_call <= self.blind_amount * 2: # Call small raises
                        return PokerAction.CALL, 0
                    else: # Fold expensive calls
                        return PokerAction.FOLD, 0
                else: # Weak hands, fold
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        # Convert strength to a percentile (0-1) for easier decision making
        # `_evaluate_hand_strength` returns a float 0.0 to 1.0 (roughly)
        
        # General principles for post-flop:
        # - Strong hand (top pair+ / good draw): Bet/Raise
        # - Medium hand (middle pair / small draw): Check/Call
        # - Weak hand: Fold or Check/Fold
        
        if needed_to_call == 0: # Can Check/Bet
            if strength >= 0.85: # Very strong hand (e.g., Two Pair+, strong draws)
                bet_amount = int(round_state.pot * 0.75) # Aggressive bet
                bet_amount = max(round_state.min_raise, bet_amount) # Ensure minimum raise
                return PokerAction.RAISE, min(bet_amount, remaining_chips)
            elif strength >= 0.65: # Good hand (e.g., Top Pair, good draws)
                bet_amount = int(round_state.pot * 0.4) # Medium bet
                bet_amount = max(round_state.min_raise, bet_amount) # Ensure minimum raise
                if bet_amount > remaining_chips: # If we can't afford a small bet, just check
                    return PokerAction.CHECK, 0 if needed_to_call == 0 else PokerAction.FOLD, 0
                return PokerAction.RAISE, min(bet_amount, remaining_chips)
            elif strength >= 0.4: # Marginal hand (e.g., Middle Pair, weak draws)
                # Check, unless in early position and feel like bluffing (advanced, not here)
                return PokerAction.CHECK, 0
            else: # Weak hand
                return PokerAction.CHECK, 0 # Check for free card or fold if action comes
        else: # Must Call/Raise/Fold
            if strength >= 0.9: # Very strong hand (e.g., Monster hand)
                # Re-raise or go All-in
                raise_amount = max(round_state.min_raise, needed_to_call + int(round_state.pot * 0.5))
                return PokerAction.RAISE, min(raise_amount, remaining_chips)
            elif strength >= 0.7: # Strong hand (e.g., Two Pair, OESF draw, Strong Flush draw)
                # Call, or medium raise if pot odds are good and we have initiative
                # Simplified: just call or raise small
                if needed_to_call < remaining_chips / 2 or num_active_players <= 2: # Call if not too expensive
                    # Consider raising if the bet isn't massive vs our stack
                    if needed_to_call * 2 < remaining_chips: # We have room to raise
                        raise_amount = max(round_state.min_raise, needed_to_call * 2)
                        return PokerAction.RAISE, min(raise_amount, remaining_chips)
                    else:
                        return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0 # Too expensive
            elif strength >= 0.5: # Medium hand (e.g., Top Pair weak kicker, Medium Pair)
                # Call if bet is small, otherwise fold. Watch pot odds.
                if needed_to_call <= round_state.pot / 3: # Reasonable call
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif strength >= 0.2: # Draw or very marginal pair
                # Call if very cheap, otherwise fold
                if needed_to_call <= self.blind_amount: # Call only if super cheap
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                return PokerAction.FOLD, 0

        # Default action
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round
        self.current_bet_in_round = 0 # Reset bot's bet for the round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    # Helper functions for hand evaluation
    def _get_hand_key(self, cards: List[str]) -> str:
        """
        Creates a canonical key for two hole cards (e.g., 'AKs', '72o', 'QQ').
        Assumes cards are 2-char strings, e.g., 'As' for Ace of Spades.
        """
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        card1_rank = cards[0][0]
        card2_rank = cards[1][0]
        card1_suit = cards[0][1]
        card2_suit = cards[1][1]

        rank1_idx = ranks.index(card1_rank)
        rank2_idx = ranks.index(card2_rank)

        if rank1_idx < rank2_idx:
            card1_rank, card2_rank = card2_rank, card1_rank
            card1_suit, card2_suit = card2_suit, card1_suit

        if card1_rank == card2_rank:
            return f"{card1_rank}{card2_rank}"
        elif card1_suit == card2_suit:
            return f"{card1_rank}{card2_rank}s"
        else:
            return f"{card1_rank}{card2_rank}o"
            
    def _precompute_hand_strengths(self) -> Dict[str, float]:
        """
        A very simplified pre-flop hand strength mapping.
        In a real bot, this would be based on advanced poker equity calculations
        (e.g., using Monte Carlo simulations or pre-computed equity tables).
        Values are approximations for demonstration.
        """
        strengths = {
            # Premium pairs
            "AA": 1.0, "KK": 0.98, "QQ": 0.95, "JJ": 0.92, "TT": 0.90,
            # Broadways suited
            "AKs": 0.88, "AQs": 0.86, "AJs": 0.84, "KQs": 0.82, "KJs": 0.80, "QJs": 0.78,
            # Broadways off-suit
            "AKo": 0.85, "AQo": 0.83, "AJo": 0.81, "KQo": 0.79,
            # Medium pairs
            "99": 0.75, "88": 0.70, "77": 0.65, "66": 0.60,
            # Suited connectors/one-gappers
            "T9s": 0.68, "98s": 0.63, "87s": 0.58, "76s": 0.53, "65s": 0.48,
            "JTs": 0.72, "QTs": 0.70, "KQs": 0.82,
            # Ace-X suited
            "A9s": 0.60, "A8s": 0.55, "A7s": 0.50, "A6s": 0.45, "A5s": 0.40, "A4s": 0.35, "A3s": 0.30, "A2s": 0.25,
            # Other suited
            "KTs": 0.65, "Q9s": 0.58,
            # Some off-suit connectors
            "T9o": 0.50,
        }
        # Add a default for all other hands, very weak
        # This is a simplification; a full bot would individually rank all 169 starting hands combinations
        # For simplicity, assign lower values for all unlisted hands.
        for rank1_idx, r1 in enumerate(['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2']):
            for rank2_idx, r2 in enumerate(['A', 'K', 'Q', 'J', 'T', '9', '8', '7', '6', '5', '4', '3', '2']):
                if rank1_idx <= rank2_idx: # Ensure no re-evaluation and canonical form
                    if rank1_idx == rank2_idx: # Pair
                        key = f"{r1}{r2}"
                    else:
                        key_suited = f"{r1}{r2}s"
                        key_offsuit = f"{r1}{r2}o"
                        if key_suited not in strengths:
                            strengths[key_suited] = 0.2 + (rank1_idx + rank2_idx) / 26 * 0.1 # Some base strength
                        if key_offsuit not in strengths:
                            strengths[key_offsuit] = 0.1 + (rank1_idx + rank2_idx) / 26 * 0.05 # Lower strength
        return strengths

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        A simple hand strength evaluator. This is a very basic implementation
        and does not perform proper poker hand ranking. For a real bot,
        you'd use a dedicated poker hand evaluator library or implement one.
        
        This version checks for common combinations using a heuristic.
        Returns a float between 0.0 (worst) and 1.0 (best).
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5: # Not enough cards to form a 5-card hand yet
            # In earlier streets, rely more on implied odds from hole cards
            # and potential draws, but this simple evaluator does not do that.
            # Return preflop strength as a baseline if few community cards.
            if len(community_cards) == 0:
                hand_key = self._get_hand_key(hole_cards)
                return self.preflop_hand_strength_map.get(hand_key, 0.1) # Default very low if not found

            # Simple strength for incomplete board: high cards + pairs
            ranks = [self._card_to_rank_value(card) for card in all_cards]
            rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
            
            pairs = 0
            trips = 0
            for rank, count in rank_counts.items():
                if count == 2: pairs += 1
                if count == 3: trips += 1
            
            if trips > 0: return 0.6 # Trip on board/with hole cards
            if pairs >= 2: return 0.5 # Two pair possible
            if pairs == 1: # One pair, check if high pair
                for r, c in rank_counts.items():
                    if c == 2 and r >= 10: return 0.45 # High pair (T-A)
                return 0.3 # Low pair
            
            # Check for high cards in hand that match community cards
            high_card_strength = max(ranks) / 14 if ranks else 0.0
            return max(0.1, high_card_strength * 0.2) # Very low for just high card
            
        ranks = [self._card_to_rank_value(card) for card in all_cards]
        suits = [card[1] for card in all_cards]

        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}

        # Check for flush
        is_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straight
        sorted_unique_ranks = sorted(list(set(ranks)))
        is_straight = False
        if len(sorted_unique_ranks) >= 5:
            # Handle A as high or low for straights
            if 14 in sorted_unique_ranks: # Ace high, treat as 1 for 5-high straight
                sorted_unique_ranks.insert(0, 1) 
                sorted_unique_ranks = sorted(list(set(sorted_unique_ranks))) # Remove duplicates after adding 1

            for i in range(len(sorted_unique_ranks) - 4):
                if sorted_unique_ranks[i+4] - sorted_unique_ranks[i] == 4:
                    is_straight = True
                    break
        
        # Determine hand type
        pairs = 0
        trips = 0
        quads = 0
        for rank, count in rank_counts.items():
            if count == 2: pairs += 1
            if count == 3: trips += 1
            if count == 4: quads += 1
        
        if quads > 0: return 1.0 # Four of a kind (very strong)
        if trips > 0 and pairs > 0: return 0.95 # Full house
        if trips > 1: return 0.95 # Two trips also makes a full house
        if is_flush and is_straight: # Could be a straight flush
            # For simplicity, not distinguishing straight flush from normal straight/flush here fully,
            # but it would be highest.
            # A correct implementation would form the 5-card hand first.
            return 0.99
        if is_flush: return 0.9 # Flush
        if is_straight: return 0.85 # Straight
        if trips > 0: return 0.7 # Three of a kind
        if pairs >= 2: return 0.6 # Two pair
        if pairs == 1: 
            # Check if it's a high pair (T, J, Q, K, A)
            for rank, count in rank_counts.items():
                if count == 2 and rank >= 10: # Tens or better
                    return 0.5
            return 0.4 # Medium/low pair

        # High card scenario, consider the highest card we have combined with community
        high_card_value = max(ranks) / 14.0 if ranks else 0.0
        return 0.2 + high_card_value * 0.2 # Baseline for high card hands

    def _card_to_rank_value(self, card: str) -> int:
        """ Converts a card string (e.g., 'Kh') to its numerical rank value. """
        rank_char = card[0]
        if rank_char.isdigit():
            return int(rank_char)
        elif rank_char == 'T':
            return 10
        elif rank_char == 'J':
            return 11
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'K':
            return 13
        elif rank_char == 'A':
            return 14
        return 0 # Should not happen