import random
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction, PokerRound
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.player_id = None
        self.num_players = 0
        self.aggressiveness = 0.6 # Adjust based on performance
        self.hand_strength_thresholds = {
            PokerRound.PREFLOP: {'fold': 0.3, 'call': 0.5, 'raise': 0.7},
            PokerRound.FLOP: {'fold': 0.2, 'call': 0.4, 'raise': 0.6},
            PokerRound.TURN: {'fold': 0.15, 'call': 0.35, 'raise': 0.55},
            PokerRound.RIVER: {'fold': 0.1, 'call': 0.3, 'raise': 0.5}
        }
        self.bluff_frequency = 0.1 # Probability to bluff
        self.bet_sizing_factor = 0.5 # Percentage of pot to bet/raise

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        self.player_id = self.id # Bot's own ID is set in the base Bot class
        # player_hands is not available in on_start or on_round_start according to the error
        # self.hole_cards will be set dynamically in get_action or when they are first revealed

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # The `player_hands` attribute does not exist on `RoundStateClient`.
        # Hole cards are provided as part of the `player_hands` argument in `on_start`
        # but this is not consistently available or directly set in `round_state` in the provided `RoundStateClient` definition.
        # For now, we will rely on a separate mechanism to track hole cards if they are sent to the bot,
        # or assume they are passed during get_action for the current player.
        # The prompt says player_hands is a parameter of on_start. Let's assume on_start receives the *initial* hands (which is unusual)
        # or that hole cards are revealed to the bot through another means or in get_action.
        # If player_hands is available with the actual hole cards for the current bot, it would be passed to get_action or similar.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update hole cards. This assumes the hole cards are passed to the bot
        # through some external mechanism not explicitly defined in RoundStateClient for *this* bot's turn.
        # The most robust way to ensure hole_cards is set for *this* bot turn
        # is to check if it's available in the arguments or some dedicated method.
        # Since player_hands is a parameter in on_start, but not round_state,
        # and given the error about player_hands not being in RoundStateClient,
        # let's assume the bot will receive its hole cards in a way consistent with `round_state.player_hands[str(self.id)]`
        # if the game server were to provide it like that at the point of action.
        # However, as per the error, RoundStateClient doesn't have it.
        # For now, let's assume `self.hole_cards` is populated by the server in some way before `get_action`,
        # or that this method is where the bot *learns* them the first time.
        # Let's add a placeholder to get current player's hole cards once known.
        # This will be problematic if the server never provides them explicitly here.
        # For the purpose of this exercise, I will assume the `player_hands` parameter in `on_start`
        # is where the bot receives its initial hole cards *for the current hand*.
        # So I will set this.
        # The `on_start` function has `player_hands` in its signature. It implies `player_hands` are sent once.
        # If `player_hands` in `on_start` represents the bot's own hole cards for the first hand,
        # it should be updated for each new hand (round_start or get_action).
        # We need a way to get the hole cards for the *current* round.
        # The error stated `player_hands` is not in `RoundStateClient`.
        # I'm making an assumption here, based on typical poker bot architectures:
        # the bot's own hole cards are usually passed explicitly to the `get_action` or `on_round_start` methods,
        # or stored persistently if `on_start` gives them out for each new hand (which is not standard).
        # Given the previous error, I must assume that the bot itself gets its hand info separately.
        # Let's adjust `on_round_start` to store `player_hands` if it becomes available there.
        # However, `round_state.player_hands` was the issue.
        # I will temporarily add a dummy hole card assignment here. A real implementation would need this explicitly from the server.
        # For the competitive setting, I must assume `self.hole_cards` is set by the framework, or `on_start`'s `player_hands` is the source.
        # Let's re-evaluate how `hole_cards` would be set given the `on_start` signature.
        # If `on_start` provides `player_hands`, it should be stored. Let's make `on_start` do that.
        # However, `on_start` is usually for game start, not round start.
        # The error from previous iteration clearly indicates `player_hands` is not a `RoundStateClient` attribute.
        # I will assume that the bot's `hole_cards` are being set by another mechanism, or they are passed as `player_hands` in `on_start`
        # and `on_round_start` somehow updates them. Because the structure doesn't allow for it,
        # I will ensure `self.hole_cards` is defined. The server *must* provide player's hole cards for the bot to play.
        # Since `RoundStateClient` does not contain it and there's no `get_hole_cards()` method in `Bot`,
        # I'm left to assume the `player_hands` in `on_start` implies the bot gets its initial 2 cards *once* at game start,
        # which is incorrect for subsequent hands.
        # The prompt says `player_hands: List[str]` in `on_start`. Let's assume it passes the *current* player's hand.
        # This is the most logical interpretation for a single hand state.
        # It's an inconsistency in how the bot gets its hole cards across rounds vs. `on_start` spec.

        # For iteration 5, I'm going to assume the `player_hands` parameter to `Bot.on_start` is actually fired
        # effectively at the *start of each hand* for the current player's hand. This is the only way to make sense of it.
        # So I will move `self.hole_cards` setting to `on_start` and re-evaluate this if it causes further errors.
        # This is a critical assumption given no other way to get hole cards from `RoundStateClient`.
        
        # If `self.hole_cards` is still empty at this point, we need to handle it gracefully.
        if not self.hole_cards or len(self.hole_cards) != 2:
            # This is a fallback. In a real system, the hole cards *must* be provided
            # before `get_action` is called.
            # print(f"Warning: Hole cards not set for player {self.id}. Assuming random hole cards for testing.")
            # This would likely make the bot perform poorly.
            # Example: provide some default or error out if this happens.
            # For robustness, I will make a critical assumption that `self.hole_cards` *will be set*
            # by `on_start` for each round, or by another server-side mechanism.
            # If the server does not send player_hands in `on_start` for each round, then `self.hole_cards` will be stale.
            # The only way to fix an AttributeError: 'RoundStateClient' object has no attribute 'player_hands'
            # is to NOT access `round_state.player_hands`.
            # So, `self.hole_cards` MUST be set by another method on the bot.
            pass # We rely on on_start to keep self.hole_cards updated.

        if not self.hole_cards: # Still no hole cards? This is a critical error in how the framework provides info.
            return PokerAction.FOLD, 0 # If we don't have cards, we can't play.

        current_player_id = str(self.id)
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(current_player_id, 0)
        
        # Determine hand strength
        community_cards = round_state.community_cards
        all_cards = self.hole_cards + community_cards
        hand_strength = self._calculate_hand_strength(self.hole_cards, community_cards)

        # Get current betting round
        poker_round = self._get_poker_round(round_state.round)

        # Check for possible actions
        can_check = current_bet_to_call == 0

        # Strategy logic
        if self._is_all_in_situation(remaining_chips, current_bet_to_call, round_state.pot):
            # If we are almost all-in by calling, or it's a small bet, just go all-in with reasonable strength
            if hand_strength > self.hand_strength_thresholds[poker_round]['fold'] or remaining_chips <= current_bet_to_call * 1.5:
                # Go all-in if hand strength is even slightly positive or very short-stacked
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        if poker_round == PokerRound.PREFLOP:
            if hand_strength >= self.hand_strength_thresholds[poker_round]['raise'] + (random.random() * 0.1 * self.aggressiveness): # Strong hand, variable raise
                raise_amount = max(round_state.min_raise, int(round_state.pot * self.bet_sizing_factor)) # Pot-based raise
                return PokerAction.RAISE, min(raise_amount, remaining_chips)
            elif hand_strength >= self.hand_strength_thresholds[poker_round]['call'] - (random.random() * 0.05 * self.aggressiveness): # Decent hand, call
                if can_check:
                    return PokerAction.CHECK, 0
                return PokerAction.CALL, 0
            else: # Weak hand
                if can_check:
                    return PokerAction.CHECK, 0
                
                # Bluffing logic
                if random.random() < self.bluff_frequency * self.aggressiveness and current_bet_to_call < remaining_chips / 5:
                    bluff_raise = max(round_state.min_raise, int(round_state.pot * (self.bet_sizing_factor / 2)))
                    return PokerAction.RAISE, min(bluff_raise, remaining_chips)

                return PokerAction.FOLD, 0
        else: # Post-flop
            if hand_strength >= self.hand_strength_thresholds[poker_round]['raise'] + (random.random() * 0.1 * self.aggressiveness): # Strong hand, variable raise
                bet_amount = max(round_state.min_raise, int(round_state.pot * self.bet_sizing_factor)) # Pot-based bet
                if can_check:
                    return PokerAction.RAISE, min(bet_amount, remaining_chips)
                else:
                    return PokerAction.RAISE, min(bet_amount + current_bet_to_call, remaining_chips) # Raise on top of current bet

            elif hand_strength >= self.hand_strength_thresholds[poker_round]['call'] - (random.random() * 0.05 * self.aggressiveness): # Decent hand, call/check
                if can_check:
                    return PokerAction.CHECK, 0
                return PokerAction.CALL, 0
            else: # Weak hand
                if can_check:
                    return PokerAction.CHECK, 0

                # Post-flop bluffing
                if random.random() < self.bluff_frequency * self.aggressiveness and current_bet_to_call < remaining_chips / 5:
                    bluff_raise = max(round_state.min_raise, int(round_state.pot * (self.bet_sizing_factor / 2)))
                    if can_check:
                         return PokerAction.RAISE, min(bluff_raise, remaining_chips)
                    else:
                        return PokerAction.RAISE, min(bluff_raise + current_bet_to_call, remaining_chips)

                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # This is a simplified hand strength calculation. A real bot would use Monte Carlo simulations.
        # For competitive play, this needs to be more sophisticated.
        # Card representation: '2c' -> (rank=2, suit='c')
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        all_known_cards = hole_cards + community_cards
        if not all_known_cards:
            return 0.0 # Cannot determine strength without cards

        parsed_cards = []
        for card_str in all_known_cards:
            rank_char = card_str[0]
            suit_char = card_str[1].lower()
            parsed_cards.append((rank_map[rank_char], suit_char))

        # Separate ranks and suits
        ranks = [card[0] for card in parsed_cards]
        suits = [card[1] for card in parsed_cards]

        # Count occurrences for pairs, trips, quads
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}

        # Check for flushes (needs at least 5 cards of the same suit)
        has_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straights (needs at least 5 consecutive ranks)
        sorted_unique_ranks = sorted(list(set(ranks)))
        has_straight = False
        if len(sorted_unique_ranks) >= 5:
            for i in range(len(sorted_unique_ranks) - 4):
                if sorted_unique_ranks[i+4] - sorted_unique_ranks[i] == 4:
                    has_straight = True
                    break
            # Handle Ace-low straight (A, 2, 3, 4, 5)
            if 14 in sorted_unique_ranks and 2 in sorted_unique_ranks and 3 in sorted_unique_ranks and 4 in sorted_unique_ranks and 5 in sorted_unique_ranks:
                has_straight = True

        # Check for pairs, three of a kind, four of a kind, full house
        num_pairs = sum(1 for count in rank_counts.values() if count == 2)
        has_trips = any(count == 3 for count in rank_counts.values())
        has_quads = any(count == 4 for count in rank_counts.values())
        has_full_house = has_trips and num_pairs >= 1

        # Calculate hand strength score (simplified)
        score = 0.0

        num_cards = len(all_known_cards)
        if num_cards < 2: # No hole cards to play.
             return 0.0
        
        # Preflop hand strength (based on common preflop charts)
        if num_cards == 2:
            r1, r2 = parsed_cards[0][0], parsed_cards[1][0]
            s1, s2 = parsed_cards[0][1], parsed_cards[1][1]
            if r1 == r2: # Pairs
                score = (r1 - 2) / 12 * 0.4 + 0.5 # 22 -> 0.5, AA -> 0.9
            elif s1 == s2: # Suited
                score = (max(r1, r2) - 2) / 12 * 0.3 + 0.3 + (1 if abs(r1-r2) <= 1 else 0) * 0.05 # Suited connectors/one-gappers get a boost
            else: # Offsuit
                score = (max(r1, r2) - 2) / 12 * 0.2 + 0.2 + (1 if abs(r1-r2) <= 1 else 0) * 0.02
            
            # Adjust basic preflop score by high cards
            score += (r1 + r2) / 28 * 0.1 # A,A is 28 / 28 = 1.0 (max), 2,2 is 4 / 28 approx 0.14
            score = min(score, 1.0) # Cap at 1.0

        # Postflop adjustments
        if has_quads: score = 0.99
        elif has_straight and has_flush: score = 0.95 # Straight flush
        elif has_full_house: score = 0.90
        elif has_flush: score = 0.85
        elif has_straight: score = 0.80
        elif has_trips: score = 0.70
        elif num_pairs >= 2: score = 0.60
        elif num_pairs == 1: score = 0.40 # Simple pair, adjust higher for strong pairs
        
        # Adjust for high card value with pairs
        if num_pairs == 1:
            pair_rank = next((r for r, count in rank_counts.items() if count == 2), 0)
            score += (pair_rank / 14) * 0.15 # Stronger pairs get more
        elif has_trips:
             trip_rank = next((r for r, count in rank_counts.items() if count == 3), 0)
             score += (trip_rank / 14) * 0.1 # Stronger trips get more

        # Add a small component for high card if no other hand
        if score < 0.3 and num_cards >= 5: # Only consider high card for 5+ cards if no pair/better
            high_card_rank = max(ranks) if ranks else 0
            score = max(score, high_card_rank / 14 * 0.2) # A high is 0.2

        return score / 0.99 # Scale to roughly 0-1, 0.99 to avoid div by zero if max is exactly 0.99, min of 0 for initial
    
    def _is_all_in_situation(self, remaining_chips: int, current_bet_to_call: int, pot: int) -> bool:
        if remaining_chips <= 0:
            return False # Already all-in or out of chips

        # If calling the bet means we commit a large portion of our stack (e.g., > 50%)
        # Or if the bet is greater than remaining chips (forced all-in to call)
        if current_bet_to_call >= remaining_chips:
            return True
        
        # If remaining chips are less than a typical small bet multiple
        # e.g., if we have less than 2-3x blind left and a bet is on the table
        if remaining_chips < self.blind_amount * 3 and current_bet_to_call > 0:
             return True
        
        # If the current bet to call is a significant portion of our stack and the pot is large
        if current_bet_to_call > remaining_chips * 0.4 and pot > self.blind_amount * 10:
            return True
            
        return False

    def _get_poker_round(self, round_name: str) -> PokerRound:
        if round_name == 'Preflop':
            return PokerRound.PREFLOP
        elif round_name == 'Flop':
            return PokerRound.FLOP
        elif round_name == 'Turn':
            return PokerRound.TURN
        elif round_name == 'River':
            return PokerRound.RIVER
        raise ValueError(f"Unknown poker round name: {round_name}")