from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.starting_chips = 0
        self.game_count = 0
        self.position = None  # 'small_blind', 'big_blind', or 'other'
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.starting_chips = starting_chips
        self.game_count += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'small_blind'
        elif self.id == big_blind_player_id:
            self.position = 'big_blind'
        else:
            self.position = 'other'
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        pass
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1."""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        # Parse hole cards
        card1_rank = self.get_card_rank(hole_cards[0][0])
        card2_rank = self.get_card_rank(hole_cards[1][0])
        suited = hole_cards[0][1] == hole_cards[1][1]
        
        # Pre-flop hand strength
        if not community_cards:
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 12:  # QQ+
                    return 0.95
                elif card1_rank >= 10:  # TT-JJ
                    return 0.85
                elif card1_rank >= 8:  # 88-99
                    return 0.75
                else:  # 22-77
                    return 0.65
            
            # High cards
            high_rank = max(card1_rank, card2_rank)
            low_rank = min(card1_rank, card2_rank)
            
            # AK, AQ
            if high_rank == 14 and low_rank >= 12:
                return 0.85 if suited else 0.80
            # AJ, KQ
            elif (high_rank == 14 and low_rank == 11) or (high_rank == 13 and low_rank == 12):
                return 0.75 if suited else 0.70
            # Ax suited
            elif high_rank == 14 and suited:
                return 0.65
            # KJ, QJ, JT suited
            elif high_rank >= 11 and low_rank >= 10 and suited:
                return 0.60
            # Two high cards
            elif high_rank >= 11 and low_rank >= 10:
                return 0.55
            # One high card
            elif high_rank >= 12:
                return 0.45
            else:
                return 0.35
        else:
            # Post-flop: simplified evaluation based on community cards
            all_cards = hole_cards + community_cards
            
            # Check for pairs, trips, etc.
            rank_counts = {}
            for card in all_cards:
                rank = self.get_card_rank(card[0])
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_count = max(rank_counts.values())
            
            # Adjust strength based on board texture
            if max_count >= 4:  # Four of a kind
                return 0.99
            elif max_count == 3:  # Three of a kind
                # Check if we have the trips
                for card in hole_cards:
                    if rank_counts[self.get_card_rank(card[0])] == 3:
                        return 0.85
                return 0.40  # Board has trips, we don't
            elif max_count == 2:  # At least a pair
                # Count pairs
                pairs = sum(1 for count in rank_counts.values() if count == 2)
                if pairs >= 2:  # Two pair or better
                    # Check if we have pocket pair
                    if self.get_card_rank(hole_cards[0][0]) == self.get_card_rank(hole_cards[1][0]):
                        return 0.75
                    return 0.65
                else:  # One pair
                    # Check if we have the pair
                    for card in hole_cards:
                        if rank_counts[self.get_card_rank(card[0])] == 2:
                            return 0.55
                    return 0.30  # Board pair
            
            # High card only
            high_card_value = max(self.get_card_rank(hole_cards[0][0]), 
                                self.get_card_rank(hole_cards[1][0]))
            return 0.25 + (high_card_value / 28.0)
    
    def get_card_rank(self, rank_char: str) -> int:
        """Convert card rank character to numeric value."""
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            try:
                return int(rank_char)
            except:
                return 2
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds."""
        if call_amount <= 0:
            return float('inf')
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current situation
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Determine betting round
        is_preflop = len(round_state.community_cards) == 0
        is_flop = len(round_state.community_cards) == 3
        is_turn = len(round_state.community_cards) == 4
        is_river = len(round_state.community_cards) == 5
        
        # Decision making
        if call_amount == 0:  # Can check
            if hand_strength > 0.75:  # Strong hand, bet/raise
                # Calculate proper raise amount
                if current_bet == 0:  # No one has bet yet
                    raise_amount = max(int(pot * 0.6), 20)
                else:  # Someone has bet, we raise
                    min_raise = current_bet * 2 - my_current_bet
                    raise_amount = max(min_raise, int(pot * 0.6))
                
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif hand_strength > 0.55:  # Medium hand, sometimes bet
                if is_preflop or (pot < 50):
                    return (PokerAction.CHECK, 0)
                else:
                    # Small bet
                    bet_amount = max(int(pot * 0.3), 20)
                    if bet_amount <= remaining_chips:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
            else:  # Weak hand, check
                return (PokerAction.CHECK, 0)
        else:  # Need to call, raise, or fold
            # Calculate if we should call based on pot odds and hand strength
            if hand_strength > 0.85:  # Very strong hand, raise/all-in
                min_raise = current_bet * 2 - my_current_bet
                raise_amount = max(min_raise, int(pot * 0.8))
                
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif hand_strength > pot_odds + 0.1:  # Good odds to call
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    # Can't afford to call, fold
                    return (PokerAction.FOLD, 0)
            elif hand_strength > 0.5 and pot_odds < 0.3:  # Decent hand and good pot odds
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Weak hand or bad pot odds
                # Bluff occasionally in position
                if self.position != 'big_blind' and pot > 100 and hand_strength > 0.3:
                    # 10% bluff chance
                    if remaining_chips > call_amount * 3:
                        # Occasional bluff raise
                        if pot % 10 == 0:  # Simple randomness based on pot size
                            min_raise = current_bet * 2 - my_current_bet
                            bluff_amount = max(min_raise, int(pot * 0.5))
                            if bluff_amount <= remaining_chips:
                                return (PokerAction.RAISE, bluff_amount)
                
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, 
                     active_players_hands: dict):
        """Called at the end of the game."""
        pass