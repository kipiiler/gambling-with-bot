from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.hand_strength_cache = {}
        self.opponent_aggression = {}
        self.hands_played = 0
        self.position_aware = True
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players
        self.hands_played = 0
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_aggression[str(player_id)] = {'raises': 0, 'calls': 0, 'folds': 0, 'checks': 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.hands_played += 1
        self.hand_strength_cache = {}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All-in' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
                elif 'Check' in action:
                    self.opponent_aggression[player_id]['checks'] += 1
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)
        
        # Adjust strategy based on stack size
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        
        # Position adjustment
        position_bonus = 0
        if self.position_aware:
            num_players = len(round_state.current_player)
            my_position = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
            position_bonus = (my_position / (num_players + 0.001)) * 0.1
        
        adjusted_strength = hand_strength + position_bonus
        
        # Get opponent aggression factor
        avg_aggression = self.get_average_opponent_aggression()
        
        # Decision making
        if to_call == 0:
            # No bet to call, we can check or bet
            if adjusted_strength > 0.7 or (adjusted_strength > 0.5 and random.random() < 0.3):
                # Strong hand or bluff
                bet_size = self.calculate_bet_size(pot, remaining_chips, adjusted_strength)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            if remaining_chips <= to_call:
                # Would be all-in to call
                if adjusted_strength > 0.5 or pot_odds < 0.25:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Calculate implied odds
            implied_odds = self.calculate_implied_odds(pot_odds, stack_to_pot_ratio)
            
            if adjusted_strength > 0.8:
                # Very strong hand
                if remaining_chips > round_state.min_raise:
                    bet_size = self.calculate_bet_size(pot, remaining_chips, adjusted_strength)
                    if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CALL, 0)
            elif adjusted_strength > 0.6:
                # Good hand
                if pot_odds < adjusted_strength - 0.1:
                    if random.random() < 0.3 and remaining_chips > round_state.min_raise:
                        bet_size = round_state.min_raise
                        if bet_size <= remaining_chips:
                            return (PokerAction.RAISE, bet_size)
                    return (PokerAction.CALL, 0)
                elif pot_odds < adjusted_strength:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif adjusted_strength > 0.4:
                # Marginal hand
                if pot_odds < adjusted_strength - 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand
                if pot_odds < 0.15 and avg_aggression < 0.3:
                    # Good pot odds and passive opponents
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        cache_key = (tuple(self.hole_cards), tuple(round_state.community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        if round_state.round == 'Preflop':
            strength = self.evaluate_preflop_strength()
        else:
            strength = self.evaluate_postflop_strength(round_state.community_cards)
        
        self.hand_strength_cache[cache_key] = strength
        return strength

    def evaluate_preflop_strength(self) -> float:
        """Evaluate preflop hand strength"""
        if len(self.hole_cards) != 2:
            return 0.3
        
        card1_rank = self.get_card_rank(self.hole_cards[0])
        card2_rank = self.get_card_rank(self.hole_cards[1])
        suited = self.hole_cards[0][-1] == self.hole_cards[1][-1]
        
        # Pocket pairs
        if card1_rank == card2_rank:
            if card1_rank >= 12:  # AA, KK, QQ
                return 0.95
            elif card1_rank >= 10:  # JJ, TT
                return 0.85
            elif card1_rank >= 7:  # 99, 88, 77
                return 0.75
            else:
                return 0.65
        
        # High cards
        high_rank = max(card1_rank, card2_rank)
        low_rank = min(card1_rank, card2_rank)
        gap = high_rank - low_rank
        
        if high_rank == 14:  # Ace high
            if low_rank >= 11 and suited:  # AK, AQ, AJ suited
                return 0.85
            elif low_rank >= 11:  # AK, AQ, AJ offsuit
                return 0.75
            elif low_rank >= 8:  # AT, A9, A8
                return 0.65 if suited else 0.55
            else:
                return 0.5 if suited else 0.4
        elif high_rank >= 11:  # King, Queen, Jack high
            if gap <= 2 and suited:
                return 0.7
            elif gap <= 2:
                return 0.6
            else:
                return 0.5 if suited else 0.4
        else:
            if gap <= 1 and suited:
                return 0.55
            elif gap <= 1:
                return 0.45
            else:
                return 0.35

    def evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        all_cards = self.hole_cards + community_cards
        
        # Check for made hands
        if self.has_flush(all_cards):
            return 0.9
        if self.has_straight(all_cards):
            return 0.85
        if self.has_three_of_kind(all_cards):
            return 0.8
        if self.has_two_pair(all_cards):
            return 0.75
        if self.has_pair(all_cards):
            pair_rank = self.get_pair_rank(all_cards)
            if pair_rank >= 12:  # High pair
                return 0.7
            elif pair_rank >= 9:  # Medium pair
                return 0.6
            else:  # Low pair
                return 0.5
        
        # High card only
        high_card = max([self.get_card_rank(card) for card in self.hole_cards])
        if high_card == 14:  # Ace high
            return 0.4
        elif high_card >= 11:  # King, Queen, Jack high
            return 0.35
        else:
            return 0.25

    def calculate_bet_size(self, pot: int, remaining_chips: int, hand_strength: float) -> int:
        """Calculate appropriate bet size"""
        if hand_strength > 0.9:
            # Very strong hand, bet big
            bet = int(pot * 0.75)
        elif hand_strength > 0.7:
            # Strong hand
            bet = int(pot * 0.6)
        elif hand_strength > 0.5:
            # Decent hand or bluff
            bet = int(pot * 0.4)
        else:
            # Weak hand, small bet
            bet = int(pot * 0.3)
        
        # Ensure bet is within limits
        bet = min(bet, remaining_chips)
        return bet

    def calculate_implied_odds(self, pot_odds: float, stack_to_pot_ratio: float) -> float:
        """Calculate implied odds based on remaining stacks"""
        if stack_to_pot_ratio > 5:
            return pot_odds * 0.8
        elif stack_to_pot_ratio > 2:
            return pot_odds * 0.9
        else:
            return pot_odds

    def get_average_opponent_aggression(self) -> float:
        """Calculate average opponent aggression"""
        total_aggression = 0
        count = 0
        
        for player_id, stats in self.opponent_aggression.items():
            total_actions = stats['raises'] + stats['calls'] + stats['folds'] + stats['checks'] + 0.001
            aggression = (stats['raises'] * 2 + stats['calls']) / total_actions
            total_aggression += aggression
            count += 1
        
        if count == 0:
            return 0.3
        
        return total_aggression / count

    def get_card_rank(self, card: str) -> int:
        """Get numeric rank of a card"""
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)

    def get_card_suit(self, card: str) -> str:
        """Get suit of a card"""
        return card[-1]

    def has_flush(self, cards: List[str]) -> bool:
        """Check if cards contain a flush"""
        suits = {}
        for card in cards:
            suit = self.get_card_suit(card)
            suits[suit] = suits.get(suit, 0) + 1
            if suits[suit] >= 5:
                return True
        return False

    def has_straight(self, cards: List[str]) -> bool:
        """Check if cards contain a straight"""
        ranks = sorted(set([self.get_card_rank(card) for card in cards]))
        
        # Check for ace-low straight
        if 14 in ranks:
            ranks.append(1)
        
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        return False

    def has_three_of_kind(self, cards: List[str]) -> bool:
        """Check if cards contain three of a kind"""
        ranks = {}
        for card in cards:
            rank = self.get_card_rank(card)
            ranks[rank] = ranks.get(rank, 0) + 1
            if ranks[rank] >= 3:
                return True
        return False

    def has_two_pair(self, cards: List[str]) -> bool:
        """Check if cards contain two pair"""
        ranks = {}
        for card in cards:
            rank = self.get_card_rank(card)
            ranks[rank] = ranks.get(rank, 0) + 1
        
        pairs = sum(1 for count in ranks.values() if count >= 2)
        return pairs >= 2

    def has_pair(self, cards: List[str]) -> bool:
        """Check if cards contain a pair"""
        ranks = {}
        for card in cards:
            rank = self.get_card_rank(card)
            ranks[rank] = ranks.get(rank, 0) + 1
            if ranks[rank] >= 2:
                return True
        return False

    def get_pair_rank(self, cards: List[str]) -> int:
        """Get the rank of the highest pair"""
        ranks = {}
        for card in cards:
            rank = self.get_card_rank(card)
            ranks[rank] = ranks.get(rank, 0) + 1
        
        for rank in sorted(ranks.keys(), reverse=True):
            if ranks[rank] >= 2:
                return rank
        return 0