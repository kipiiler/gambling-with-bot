from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_count = 0
        self.opponent_stats = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get basic info
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_bet)
        
        # Calculate pot odds
        pot_odds = to_call / (pot + to_call + 0.001) if to_call > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Position and aggression factor
        is_preflop = round_state.round == 'Preflop'
        num_players = len(round_state.current_player)
        
        # Track opponent actions for future use
        self._update_opponent_stats(round_state)
        
        # Decision making based on hand strength and pot odds
        if is_preflop:
            return self._preflop_strategy(hand_strength, to_call, remaining_chips, pot, current_bet, my_bet)
        else:
            return self._postflop_strategy(hand_strength, to_call, remaining_chips, pot, pot_odds, current_bet, my_bet, round_state)
            
    def _preflop_strategy(self, hand_strength, to_call, remaining_chips, pot, current_bet, my_bet):
        """Aggressive preflop strategy"""
        
        # Premium hands - always raise/reraise
        if hand_strength >= 0.85:
            if current_bet == 0:
                return (PokerAction.RAISE, min(pot * 3, remaining_chips))
            elif to_call < remaining_chips * 0.3:
                raise_amount = min(current_bet * 3, remaining_chips)
                if raise_amount > current_bet:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.ALL_IN, 0)
            
        # Strong hands - raise or call
        elif hand_strength >= 0.65:
            if current_bet == 0:
                return (PokerAction.RAISE, min(pot * 2, remaining_chips))
            elif to_call < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.25 and hand_strength >= 0.75:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Decent hands - sometimes raise, mostly call small bets
        elif hand_strength >= 0.45:
            if current_bet == 0:
                if hand_strength >= 0.55:
                    return (PokerAction.RAISE, min(pot * 1.5, remaining_chips))
                else:
                    return (PokerAction.CHECK, 0)
            elif to_call < remaining_chips * 0.08:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands - check or fold
        else:
            if current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount and to_call < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def _postflop_strategy(self, hand_strength, to_call, remaining_chips, pot, pot_odds, current_bet, my_bet, round_state):
        """More aggressive postflop strategy"""
        
        # Count aggressive actions this round
        aggressive_actions = sum(1 for action in round_state.player_actions.values() 
                                if action in ['Raise', 'All-in'])
        
        # Very strong hands - bet/raise aggressively
        if hand_strength >= 0.8:
            if current_bet == 0:
                return (PokerAction.RAISE, min(int(pot * 0.75), remaining_chips))
            elif to_call < remaining_chips * 0.5:
                raise_amount = min(current_bet * 2.5, remaining_chips)
                if raise_amount > current_bet:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.ALL_IN, 0)
            
        # Good hands - value bet or call
        elif hand_strength >= 0.6:
            if current_bet == 0:
                return (PokerAction.RAISE, min(int(pot * 0.6), remaining_chips))
            elif pot_odds < hand_strength - 0.1:
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Drawing hands or marginal hands
        elif hand_strength >= 0.4:
            if current_bet == 0:
                # Semi-bluff sometimes
                if hand_strength >= 0.5 and aggressive_actions == 0:
                    return (PokerAction.RAISE, min(int(pot * 0.5), remaining_chips))
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength:
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.1 and pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands - check or fold
        else:
            if current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif to_call < remaining_chips * 0.05 and pot_odds < 0.15:
                # Call very small bets
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        
        if not self.hand or len(self.hand) < 2:
            return 0.3
            
        card1, card2 = self.hand[0], self.hand[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                elif rank1 >= 6:  # 66-77
                    return 0.65
                else:  # 22-55
                    return 0.55
                    
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            gap = high_rank - low_rank
            
            if high_rank == 14:  # Ace high
                if low_rank >= 12:  # AQ+
                    return 0.85 if suited else 0.80
                elif low_rank >= 10:  # AT-AJ
                    return 0.70 if suited else 0.65
                elif low_rank >= 8:
                    return 0.60 if suited else 0.55
                else:
                    return 0.50 if suited else 0.45
                    
            elif high_rank == 13:  # King high
                if low_rank >= 11:  # KQ, KJ
                    return 0.75 if suited else 0.70
                elif low_rank >= 9:
                    return 0.60 if suited else 0.55
                else:
                    return 0.45 if suited else 0.40
                    
            elif high_rank >= 11:  # Queen/Jack high
                if gap <= 2:
                    return 0.65 if suited else 0.60
                elif gap <= 3:
                    return 0.55 if suited else 0.50
                else:
                    return 0.45 if suited else 0.40
                    
            # Suited connectors
            elif suited and gap == 1:
                return 0.55 if high_rank >= 8 else 0.45
                
            # Other hands
            else:
                base_strength = 0.3 + (high_rank / 30)
                if suited:
                    base_strength += 0.05
                if gap <= 2:
                    base_strength += 0.05
                return min(base_strength, 0.5)
                
        else:
            # Postflop - simplified evaluation
            community = round_state.community_cards
            all_cards = self.hand + community
            
            # Check for pairs, sets, etc.
            ranks = [self._card_rank(card) for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            max_count = max(rank_counts.values())
            
            # Check for flush
            suits = [card[-1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            has_flush = max(suit_counts.values()) >= 5
            
            # Check for straight
            unique_ranks = sorted(set(ranks))
            has_straight = False
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    has_straight = True
                    break
                    
            # Evaluate hand strength
            if has_flush and has_straight:
                return 0.95
            elif max_count >= 4:
                return 0.93
            elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
                return 0.90  # Full house
            elif has_flush:
                return 0.85
            elif has_straight:
                return 0.80
            elif max_count == 3:
                return 0.75
            elif len([c for c in rank_counts.values() if c == 2]) >= 2:
                return 0.65  # Two pair
            elif max_count == 2:
                # One pair - strength depends on rank
                pair_rank = max([rank for rank, count in rank_counts.items() if count == 2])
                return 0.45 + (pair_rank / 28)
            else:
                # High card
                high_card = max(ranks)
                return 0.25 + (high_card / 28)
                
    def _card_rank(self, card: str) -> int:
        """Convert card rank to numeric value"""
        if len(card) < 2:
            return 2
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
                
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Track opponent playing tendencies"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if player_id not in self.opponent_stats:
                    self.opponent_stats[player_id] = {
                        'aggressive': 0,
                        'passive': 0,
                        'total': 0
                    }
                stats = self.opponent_stats[player_id]
                stats['total'] += 1
                if action in ['Raise', 'All-in']:
                    stats['aggressive'] += 1
                elif action in ['Call', 'Check']:
                    stats['passive'] += 1
                    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.hand = []