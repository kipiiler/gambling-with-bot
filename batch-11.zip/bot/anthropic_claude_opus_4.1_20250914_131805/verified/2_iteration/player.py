from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.position = None  # 'early', 'middle', 'late', 'blinds'
        self.is_preflop = True
        self.aggression_factor = 1.0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.blind_amount = blind_amount
        
        # Determine position
        if self.id == big_blind_player_id or self.id == small_blind_player_id:
            self.position = 'blinds'
        else:
            player_index = all_players.index(self.id) if self.id in all_players else 0
            if player_index < len(all_players) // 3:
                self.position = 'early'
            elif player_index < 2 * len(all_players) // 3:
                self.position = 'middle'
            else:
                self.position = 'late'
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.is_preflop = (round_state.round == 'Preflop')
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.3
            
        # Extract card values and suits
        def card_value(card):
            if not card or len(card) < 2:
                return 2
            rank = card[0]
            if rank == 'A': return 14
            elif rank == 'K': return 13
            elif rank == 'Q': return 12
            elif rank == 'J': return 11
            elif rank == 'T': return 10
            else: 
                try:
                    return int(rank)
                except:
                    return 2
        
        def card_suit(card):
            if not card or len(card) < 2:
                return 'x'
            return card[1]
        
        card1_val = card_value(hole_cards[0])
        card2_val = card_value(hole_cards[1])
        suited = card_suit(hole_cards[0]) == card_suit(hole_cards[1])
        
        # Pre-flop hand strength evaluation
        if not community_cards:
            # Pocket pairs
            if card1_val == card2_val:
                if card1_val >= 12:  # QQ+
                    return 0.90
                elif card1_val >= 10:  # TT-JJ
                    return 0.75
                elif card1_val >= 7:  # 77-99
                    return 0.65
                else:  # 22-66
                    return 0.55
            
            # High cards
            max_val = max(card1_val, card2_val)
            min_val = min(card1_val, card2_val)
            gap = max_val - min_val
            
            # AK, AQ
            if max_val == 14 and min_val >= 12:
                return 0.80 if suited else 0.75
            # AJ, AT, KQ
            elif (max_val == 14 and min_val >= 10) or (max_val == 13 and min_val == 12):
                return 0.70 if suited else 0.65
            # KJ, QJ, JT suited
            elif max_val >= 11 and gap <= 2:
                return 0.60 if suited else 0.50
            # Suited connectors
            elif suited and gap == 1:
                return 0.55
            # High card
            elif max_val >= 10:
                return 0.45
            else:
                return 0.30
        
        # Post-flop: simplified evaluation
        all_cards = hole_cards + community_cards
        all_values = [card_value(c) for c in all_cards]
        value_counts = {}
        for v in all_values:
            value_counts[v] = value_counts.get(v, 0) + 1
        
        max_count = max(value_counts.values()) if value_counts else 1
        
        # Check for pairs, trips, etc.
        if max_count >= 4:
            return 0.95  # Four of a kind
        elif max_count == 3:
            if len([v for v in value_counts.values() if v >= 2]) >= 2:
                return 0.90  # Full house
            else:
                return 0.75  # Three of a kind
        elif max_count == 2:
            pairs = [v for v in value_counts.values() if v == 2]
            if len(pairs) >= 2:
                return 0.65  # Two pair
            else:
                # One pair - evaluate based on pair value
                pair_value = [k for k, v in value_counts.items() if v == 2][0]
                if pair_value >= 12:
                    return 0.60
                elif pair_value >= 9:
                    return 0.50
                else:
                    return 0.40
        else:
            # High card
            if max(all_values) >= 13:
                return 0.35
            else:
                return 0.25
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get basic information
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(
            self.hole_cards, 
            round_state.community_cards
        )
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Adjust strategy based on position
        position_modifier = 1.0
        if self.position == 'late':
            position_modifier = 1.2
        elif self.position == 'early':
            position_modifier = 0.8
        
        # Adjust hand strength based on position
        adjusted_strength = hand_strength * position_modifier
        
        # Decision making
        if call_amount == 0:
            # No bet to call - we can check or bet
            if adjusted_strength > 0.7:
                # Strong hand - bet/raise
                bet_size = int(pot * 0.75)
                if bet_size < round_state.min_raise:
                    bet_size = round_state.min_raise
                if bet_size > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                elif bet_size > 0:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif adjusted_strength > 0.5:
                # Medium hand - sometimes bet
                if pot > 0 and adjusted_strength > 0.6:
                    bet_size = int(pot * 0.5)
                    if bet_size < round_state.min_raise:
                        bet_size = round_state.min_raise
                    if bet_size > remaining_chips:
                        return (PokerAction.CHECK, 0)
                    elif bet_size > 0:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            if call_amount >= remaining_chips:
                # Would be all-in to call
                if adjusted_strength > 0.65:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Calculate if we should call based on pot odds and hand strength
            if adjusted_strength > pot_odds + 0.2:
                # Very strong relative to pot odds - raise
                if adjusted_strength > 0.75:
                    raise_amount = int(current_bet * 2.5)
                    if raise_amount < round_state.min_raise:
                        raise_amount = round_state.min_raise
                    if raise_amount > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    elif raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                # Good odds - call
                return (PokerAction.CALL, 0)
            elif adjusted_strength > pot_odds:
                # Marginal - call if pot odds are good
                return (PokerAction.CALL, 0)
            else:
                # Fold weak hands
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Adjust aggression based on results
        if player_score > 0:
            self.aggression_factor = min(1.5, self.aggression_factor * 1.1)
        elif player_score < 0:
            self.aggression_factor = max(0.7, self.aggression_factor * 0.95)