from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.game_history = []
        self.opponent_aggression = {}
        self.current_game_num = 0
        self.position = None  # 'SB' or 'BB'
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand_cards = player_hands
        self.current_game_num += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'SB'
        elif self.id == big_blind_player_id:
            self.position = 'BB'
        else:
            self.position = None
            
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current state info
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Track opponent actions
        self._update_opponent_stats(round_state)
        
        # Decision logic based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(hand_strength, to_call, pot, pot_odds, 
                                         min_raise, max_raise, remaining_chips, current_bet)
        else:
            return self._postflop_strategy(hand_strength, to_call, pot, pot_odds,
                                          min_raise, max_raise, remaining_chips, 
                                          round_state, current_bet)
    
    def _preflop_strategy(self, hand_strength, to_call, pot, pot_odds, 
                          min_raise, max_raise, remaining_chips, current_bet):
        """Preflop strategy"""
        
        # If we can check (no bet to call), check with weak hands
        if to_call == 0:
            if hand_strength >= 0.7:
                # Strong hand - raise
                raise_amount = min(int(pot * 0.75), max_raise)
                if raise_amount >= min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if hand_strength >= 0.75:
            # Very strong hand - raise if possible
            raise_amount = min(int(pot * 1.0), max_raise)
            if raise_amount >= min_raise and raise_amount > current_bet:
                return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        elif hand_strength >= 0.5:
            # Decent hand - call if pot odds are good
            if pot_odds <= 0.3 or to_call <= pot * 0.2:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            # Weak hand - fold unless very cheap
            if to_call <= pot * 0.1:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, hand_strength, to_call, pot, pot_odds,
                           min_raise, max_raise, remaining_chips, round_state, current_bet):
        """Postflop strategy"""
        
        # If we can check
        if to_call == 0:
            if hand_strength >= 0.6:
                # Good hand - bet for value
                bet_amount = min(int(pot * 0.5), max_raise)
                if bet_amount >= min_raise:
                    return (PokerAction.RAISE, bet_amount)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if hand_strength >= 0.7:
            # Strong hand - raise for value if possible
            raise_amount = min(int(pot * 0.75), max_raise)
            if raise_amount >= min_raise and raise_amount > current_bet:
                return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        elif hand_strength >= 0.4:
            # Medium hand - call if reasonable
            if pot_odds <= 0.25 or to_call <= pot * 0.3:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            # Weak hand - fold
            return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hand_cards:
            return 0.3
        
        card1, card2 = self.hand_cards[0], self.hand_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Preflop hand strength
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            strength = 0.5 + (rank1 / 14) * 0.4
        else:
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            strength = 0.2 + (high_rank / 14) * 0.3 + (low_rank / 14) * 0.1
            
            # Suited bonus
            if suited:
                strength += 0.05
            
            # Connectivity bonus
            if abs(rank1 - rank2) == 1:
                strength += 0.05
            elif abs(rank1 - rank2) == 2:
                strength += 0.03
        
        # Adjust for community cards if postflop
        if round_state.community_cards:
            comm_ranks = [self._card_rank(c) for c in round_state.community_cards]
            
            # Check for pairs with board
            for rank in [rank1, rank2]:
                if rank in comm_ranks:
                    strength += 0.2
            
            # Check for high cards
            if rank1 >= 12 or rank2 >= 12:
                strength += 0.1
        
        return min(1.0, strength)
    
    def _card_rank(self, card: str) -> int:
        """Convert card to numerical rank"""
        if not card or len(card) < 1:
            return 0
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            try:
                return int(rank_char)
            except:
                return 0
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Record game result
        self.game_history.append({
            'game_num': self.current_game_num,
            'score': player_score,
            'position': self.position,
            'hands': active_players_hands
        })