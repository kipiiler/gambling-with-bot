from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hand = []
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.current_round = None
        self.player_position = None
        self.hand_strength_estimate = 0.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        current_id = str(self.id)
        if current_id in round_state.player_actions:
            last_action = round_state.player_actions[current_id]
        else:
            last_action = None

    def _parse_card(self, card: str):
        """ Convert card string to value and suit """
        if len(card) == 2:
            value = card[0]
            suit = card[1]
        elif len(card) == 3:
            value = card[:2]
            suit = card[2]
        else:
            return None, None
        values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return values.get(value, None), suit

    def _hand_rank_preflop(self, hole_cards: List[str]) -> float:
        """ Estimate preflop hand strength """
        ranks = []
        suits = []
        for card in hole_cards:
            r, s = self._parse_card(card)
            if r is not None:
                ranks.append(r)
                suits.append(s)
        if len(ranks) != 2:
            return 0.1
        rank1, rank2 = sorted(ranks, reverse=True)
        suited = 1 if suits[0] == suits[1] else 0
        pair = 1 if rank1 == rank2 else 0
        gap = rank1 - rank2
        base_score = 0
        if pair:
            base_score = 10 + (rank1 / 14) * 50
        else:
            if suited:
                base_score = 2 + (rank1 / 14) * 10
            else:
                base_score = (rank1 / 14) * 8
            if gap <= 1:
                base_score += 5
            elif gap == 2:
                base_score += 2
            elif gap == 3:
                base_score += 1
            if rank1 <= 12 and rank2 >= 10:
                base_score += 4
        if rank1 == 14:
            base_score += 5
        if rank2 == 14:
            base_score += 3
        return min(base_score / 100.0, 1.0)

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Simple hand evaluator returning strength between 0 and 1 """
        if not community_cards:
            return self._hand_rank_preflop(hole_cards)
        all_cards = hole_cards + community_cards
        values = []
        suits = []
        for card in all_cards:
            r, s = self._parse_card(card)
            if r is not None:
                values.append(r)
                suits.append(s)
        value_counts = {}
        suit_counts = {}
        for v in values:
            value_counts[v] = value_counts.get(v, 0) + 1
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        sorted_values = sorted(values, reverse=True)
        pairs = [v for v, c in value_counts.items() if c == 2]
        trips = [v for v, c in value_counts.items() if c == 3]
        quads = [v for v, c in value_counts.items() if c == 4]
        flush_suit = [s for s, c in suit_counts.items() if c >= 5]
        is_flush = len(flush_suit) > 0
        unique_values = sorted(set(values), reverse=True)
        is_straight = False
        if len(unique_values) >= 5:
            for i in range(len(unique_values) - 4):
                if unique_values[i] - unique_values[i+4] == 4:
                    is_straight = True
                    break
            if 14 in unique_values:
                wheel = [14, 5, 4, 3, 2]
                if all(v in unique_values for v in wheel[:5]):
                    is_straight = True
        hand_strength = 0.0
        if quads:
            hand_strength = 0.8 + (quads[0] / 14) * 0.1
        elif trips and len(pairs) >= 1:
            hand_strength = 0.7 + (trips[0] / 14) * 0.05 + (max(pairs) / 14) * 0.05
        elif is_flush:
            flush_vals = [v for i, v in enumerate(values) if suits[i] == flush_suit[0]]
            flush_vals = sorted(flush_vals, reverse=True)[:5]
            hand_strength = 0.6 + sum(flush_vals[:3]) / (14 * 3)
        elif is_straight:
            if 14 in unique_values and 5 in unique_values and 4 in unique_values and 3 in unique_values and 2 in unique_values:
                high = 5
            else:
                high = max([v for v in unique_values if all(v - offset in unique_values for offset in range(5))])
            hand_strength = 0.5 + high / 14 * 0.1
        elif trips:
            kickers = sorted([v for v in values if v != trips[0]], reverse=True)[:2]
            hand_strength = 0.4 + (trips[0] / 14) * 0.1 + sum(kickers) / (14 * 2) * 0.1
        elif len(pairs) >= 2:
            top_two = sorted(pairs, reverse=True)[:2]
            kicker = max([v for v in values if v not in pairs], default=0)
            hand_strength = 0.3 + (top_two[0] / 14) * 0.1 + (top_two[1] / 14) * 0.05 + kicker / 14 * 0.05
        elif len(pairs) == 1:
            kickers = sorted([v for v in values if v != pairs[0]], reverse=True)[:3]
            hand_strength = 0.2 + (pairs[0] / 14) * 0.15 + sum(kickers) / (14 * 3) * 0.15
        else:
            kickers = sorted_values[:5]
            hand_strength = 0.1 + sum(kickers) / (14 * 5)
        return min(hand_strength, 1.0)

    def _estimate_win_probability(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Estimate win probability based on hand strength and board """
        hand_strength = self._evaluate_hand(hole_cards, community_cards)
        if len(community_cards) == 0:
            return hand_strength
        num_players_factor = min(1.0, 0.8 + (1.0 / (len(self.all_players) + 1)) * 2)
        return hand_strength * num_players_factor

    def _get_position(self, round_state: RoundStateClient) -> str:
        """ Determine position: early, middle, late """
        active_players = round_state.current_player
        if self.id not in active_players:
            self.player_position = 'early'
            return 'early'
        current_ids = [p for p in self.all_players if p in active_players]
        my_index = current_ids.index(self.id)
        total = len(current_ids)
        if total <= 1:
            self.player_position = 'late'
            return 'late'
        if my_index < total * 0.3:
            pos = 'early'
        elif my_index < total * 0.7:
            pos = 'middle'
        else:
            pos = 'late'
        self.player_position = pos
        return pos

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_id = str(self.id)
            my_current_bet = round_state.player_bets.get(current_id, 0)
            call_amount = round_state.current_bet - my_current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot_size = round_state.pot
            community_cards = round_state.community_cards
            hand_strength = self._estimate_win_probability(self.my_hand, community_cards)
            position = self._get_position(round_state)
            in_blind_spot = (self.id == self.small_blind_player_id or self.id == self.big_blind_player_id)

            if call_amount <= 0:
                if hand_strength > 0.8 and random.random() < 0.3:
                    raise_amount = min(remaining_chips // 2, max_raise)
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                elif hand_strength > 0.6 or (in_blind_spot and hand_strength > 0.4):
                    return (PokerAction.CHECK, 0)
                else:
                    if random.random() < 0.1:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)

            if call_amount >= remaining_chips:
                if hand_strength > 0.7:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)

            if call_amount > 0:
                effective_odds = (call_amount) / (pot_size + call_amount + 1e-8)
                expected_value = hand_strength - effective_odds

                if expected_value > 0.3 and hand_strength > 0.6:
                    raise_amount = min(pot_size, max_raise)
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)

                if expected_value > 0.1 and hand_strength >= 0.5:
                    return (PokerAction.CALL, 0)

                if hand_strength < 0.3:
                    return (PokerAction.FOLD, 0)

                call_thresholds = {
                    'early': 0.1,
                    'middle': 0.05,
                    'late': -0.05
                }
                threshold = call_thresholds.get(position, 0.0)
                if expected_value > threshold:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

            return (PokerAction.FOLD, 0)

        except Exception as e:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass