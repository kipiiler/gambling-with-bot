from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hole_cards = []
        self.positional_advantage = 0
        self.hand_strength_estimate = 0.0
        self.aggression_factor = 1.0
        self.volatility_threshold = 0.3
        self.tight_aggressive_profile = True

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        if str(self.id) in player_hands:
            self.hole_cards = player_hands[str(self.id)]
        self.aggression_factor = 1.0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if str(self.id) in round_state.player_actions:
            last_action = round_state.player_actions[str(self.id)]
            if last_action == 'RAISE':
                self.aggression_factor *= 1.1
            elif last_action == 'FOLD':
                self.aggression_factor = max(0.5, self.aggression_factor * 0.95)
        self._update_hand_strength(round_state, remaining_chips)

    def _get_position_value(self, round_state: RoundStateClient) -> float:
        active_players = len(round_state.current_player)
        if active_players == 0:
            return 0.5
        try:
            current_index = round_state.current_player.index(self.id)
            total_positions = len(round_state.current_player)
            pos_value = current_index / max(1, total_positions - 1)
            return pos_value
        except ValueError:
            return 0.5

    def _evaluate_hole_cards(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.3

        card1, card2 = self.hole_cards[0], self.hole_cards[1]

        rank_vals = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1, s1 = card1[0], card1[1]
        r2, s2 = card2[0], card2[1]

        v1, v2 = rank_vals[r1], rank_vals[r2]

        score = 0.0

        if r1 == r2:
            score += 8.0
        elif abs(v1 - v2) <= 1:
            score += 2.0
            if s1 == s2:
                score += 1.0
        elif abs(v1 - v2) == 2:
            score += 1.0
            if s1 == s2:
                score += 1.0

        if s1 == s2:
            score += 1.0

        score += (max(v1, v2) - 2) * 0.25
        score += (min(v1, v2) - 2) * 0.1

        if v1 >= 11 or v2 >= 11:
            score += 1.0

        return min(10.0, score) / 10.0

    def _calculate_outs(self, hand: List[str], community: List[str]) -> int:
        if len(community) < 3:
            return 0
        
        all_cards = hand + community
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_count = {r: ranks.count(r) for r in set(ranks)}
        suit_count = {s: suits.count(s) for s in set(suits)}
        
        outs = 0
        for r, cnt in rank_count.items():
            if cnt == 2:
                outs += 2
            elif cnt == 1 and len(hand + community) < 6:
                outs += 3
        for s, cnt in suit_count.items():
            if cnt == 4:
                outs += 9
            elif cnt == 3 and len(community) <= 4:
                outs += 2
        return min(outs, 20)

    def _update_hand_strength(self, round_state: RoundStateClient, remaining_chips: int):
        community = round_state.community_cards
        hole = self.hole_cards

        if not hole or len(hole) != 2:
            self.hand_strength_estimate = 0.1
            return

        hole_rank = self._evaluate_hole_cards()

        if len(community) == 0:
            self.hand_strength_estimate = hole_rank
            return

        total_cards = hole + community
        outs = self._calculate_outs(hole, community)
        improvement_potential = outs / 44.0 if len(total_cards) < 7 else 0.0

        made_hand_score = self._assess_made_hand(total_cards)
        position_factor = 0.8 + 0.4 * self._get_position_value(round_state)
        chip_factor = min(1.0, remaining_chips / (self.starting_chips * 0.5)) if self.starting_chips > 0 else 1.0

        raw_estimate = (hole_rank * 0.4 + made_hand_score * 0.5 + improvement_potential * 0.3)
        adjusted_estimate = raw_estimate * position_factor * (1.0 + chip_factor * 0.5)
        self.hand_strength_estimate = min(0.95, max(0.05, adjusted_estimate))

    def _assess_made_hand(self, cards: List[str]) -> float:
        if len(cards) < 5:
            return 0.0

        ranks = [c[0] for c in cards]
        suits = [c[1] for c in cards]
        rank_count = {r: ranks.count(r) for r in set(ranks)}
        suit_count = {s: suits.count(s) for s in set(suits)}

        flush = max(suit_count.values()) >= 5
        pairs = sum(1 for v in rank_count.values() if v >= 2)
        trips = sum(1 for v in rank_count.values() if v >= 3)
        quads = sum(1 for v in rank_count.values() if v >= 4)

        is_straight = self._has_straight(ranks)

        if quads:
            return 0.9
        elif trips and pairs >= 2:
            return 0.8
        elif flush and is_straight:
            return 0.95
        elif flush:
            return 0.7
        elif is_straight:
            return 0.6
        elif trips:
            return 0.5
        elif pairs >= 2:
            return 0.4
        elif pairs == 1:
            return 0.25
        else:
            high_card = max([{'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}[r] for r in ranks])
            return 0.1 + (high_card - 2) * 0.01

    def _has_straight(self, ranks: List[str]) -> bool:
        rank_vals = sorted(set([{'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}[r] for r in ranks]))
        if 14 in rank_vals:
            rank_vals.insert(0, 1)
        count = 1
        for i in range(1, len(rank_vals)):
            if rank_vals[i] == rank_vals[i-1] + 1:
                count += 1
                if count >= 5:
                    return True
            else:
                count = 1
        return False

    def _should_bluff(self, round_state: RoundStateClient, hand_strength: float, remaining_chips: int) -> bool:
        if hand_strength > 0.5 or len(round_state.current_player) <= 2:
            return False
        position = self._get_position_value(round_state)
        if position < 0.3:
            return False
        opponents_fold_likelihood = 0.3 + (1 - hand_strength) * 0.4
        pot_odds = round_state.pot / max(1, remaining_chips)
        return random.random() < min(0.4, opponents_fold_likelihood * pot_odds)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hand_strength = self.hand_strength_estimate
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        position = self._get_position_value(round_state)
        call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)

        if remaining_chips <= 0:
            return (PokerAction.CHECK, 0) if current_bet == 0 else (PokerAction.FOLD, 0)

        if current_bet == 0:
            if hand_strength > 0.4 + self.volatility_threshold:
                raise_amount = min(pot // 3, max_raise)
                if raise_amount < min_raise:
                    return (PokerAction.ALL_IN, remaining_chips)
                return (PokerAction.RAISE, max(min_raise, raise_amount))
            elif hand_strength > 0.2:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)

        if call_amount >= remaining_chips:
            if hand_strength > 0.6:
                return (PokerAction.ALL_IN, remaining_chips)
            else:
                return (PokerAction.FOLD, 0)

        if hand_strength > 0.7:
            if pot > 0:
                ideal_raise = min(pot, max_raise)
                raise_amount = max(min_raise, ideal_raise)
                if random.random() < 0.3:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, call_amount)
            else:
                return (PokerAction.CALL, call_amount)

        elif hand_strength > 0.5:
            if call_amount <= pot * 0.3:
                return (PokerAction.CALL, call_amount)
            else:
                return (PokerAction.FOLD, 0)

        elif hand_strength > 0.3:
            if call_amount <= pot * 0.15:
                return (PokerAction.CALL, call_amount)
            elif self._should_bluff(round_state, hand_strength, remaining_chips) and min_raise <= remaining_chips:
                bluff_raise = min(pot // 2, max_raise)
                return (PokerAction.RAISE, max(min_raise, bluff_raise))
            else:
                return (PokerAction.FOLD, 0)

        else:
            if call_amount <= blind_amount * 2 and random.random() < 0.1:
                return (PokerAction.CALL, call_amount)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass