from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.big_blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.current_round = None
        self.remaining_chips = 0
        self.hole_cards = []
        self.is_first_action = True
        self.position = 0  # 0 is early, 1 is middle, 2 is late (button)
        self.total_players = 0
        self.game_phase = 0  # 0: pre-flop, 1: flop, 2: turn, 3: river

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.big_blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.total_players = len(all_players)
        # Extract hole cards for self
        if str(self.id) in player_hands:
            self.hole_cards = player_hands[str(self.id)]
        else:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.is_first_action = True
        # Determine position: late if on or after button
        active_players = round_state.current_player
        if self.id in active_players:
            pos_index = active_players.index(self.id)
            # Assume SB acts first pre-flop, then BB, etc., and button is last pre-flop
            self.position = 2 if pos_index >= len(active_players) - 1 else 1 if pos_index >= len(active_players) // 2 else 0
        # Update game phase
        if round_state.round == "Preflop":
            self.game_phase = 0
        elif round_state.round == "Flop":
            self.game_phase = 1
        elif round_state.round == "Turn":
            self.game_phase = 2
        elif round_state.round == "River":
            self.game_phase = 3

    def evaluate_hand_strength(self):
        """ Very basic hand strength estimation """
        if not self.hole_cards:
            return 0.1
        
        # Extract ranks and suits
        ranks = [card[0] for card in self.hole_cards]
        suits = [card[1] for card in self.hole_cards]
        
        # Count pairs
        if ranks[0] == ranks[1]:
            pair_rank = "23456789TJQKA".index(ranks[0]) + 2
            if pair_rank >= 10:
                return 0.8
            elif pair_rank >= 7:
                return 0.6
            else:
                return 0.4
        
        # High cards
        high_card_value = max("23456789TJQKA".index(r) for r in ranks) + 2
        suited = 1 if suits[0] == suits[1] else 0
        connected = abs("23456789TJQKA".index(ranks[0]) - "23456789TJQKA".index(ranks[1])) == 1
        
        score = 0.1
        if high_card_value >= 11:  # T or higher
            score += 0.2
        if high_card_value >= 13:  # A or K
            score += 0.1
        if suited:
            score += 0.1
        if connected:
            score += 0.1
        
        return score

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Update hole cards if available in player_hands
        if hasattr(round_state, 'player_hands') and str(self.id) in round_state.player_hands:
            self.hole_cards = round_state.player_hands[str(self.id)]

        # Estimate hand strength
        hand_strength = self.evaluate_hand_strength()
        
        # Pot odds calculation
        pot_odds = 0.0
        if pot > 0:
            pot_odds = call_amount / (pot + call_amount + 1e-9)
        
        # Determine action based on game phase and hand strength
        if self.game_phase == 0:  # Preflop
            return self.decide_preflop_action(call_amount, min_raise, max_raise, pot_odds, hand_strength)
        else:  # Post-flop
            return self.decide_postflop_action(call_amount, min_raise, max_raise, pot_odds, hand_strength, pot)

    def decide_preflop_action(self, call_amount, min_raise, max_raise, pot_odds, hand_strength):
        # Adjust behavior based on position
        in_big_blind = self.id == self.big_blind_player_id
        in_small_blind = self.id == self.small_blind_player_id
        is_late = self.position == 2
        is_early = self.position == 0

        # If no bet to call (e.g., first to act or SB/BB in certain cases)
        if call_amount <= self.big_blind_amount:
            if hand_strength >= 0.6 or (hand_strength >= 0.4 and is_late):
                # Raise with strong or decent hand in late position
                raise_amount = min(self.big_blind_amount * 3, max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif hand_strength >= 0.4:
                return (PokerAction.CALL, 0)
            else:
                if in_big_blind:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Facing a raise
            effective_odds = call_amount / (self.starting_chips + 1e-9)
            if hand_strength >= 0.8:
                # Strong hand -> call or reraise
                if call_amount <= self.big_blind_amount * 4:
                    if max_raise >= min_raise * 2 and random.random() < 0.7:
                        raise_amount = min(call_amount * 2, max_raise)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    if hand_strength >= 0.9 or effective_odds < 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength >= 0.6 and is_late and call_amount <= self.big_blind_amount * 3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def decide_postflop_action(self, call_amount, min_raise, max_raise, pot_odds, hand_strength, pot):
        expected_equity = hand_strength
        # Simple decision: if equity > pot odds, call or raise
        if expected_equity > pot_odds * 1.5:
            if expected_equity > 0.7:
                # Strong hand: raise or go all-in
                if pot > self.remaining_chips * 0.5:
                    return (PokerAction.ALL_IN, 0)
                else:
                    raise_amount = min(int(pot * 0.75), max_raise)
                    if raise_amount < min_raise:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.RAISE, raise_amount)
            elif expected_equity > 0.5 and random.random() < 0.5:
                # Medium hand: small raise or call
                raise_amount = min(int(pot * 0.5), max_raise)
                if raise_amount >= min_raise and random.random() < 0.3:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # Just call or check if we have odds
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Fold if odds are bad
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Bluff occasionally in late position
                if self.position == 2 and random.random() < 0.05 and pot > 0:
                    bluff_raise = min(int(pot * 0.7), max_raise)
                    if bluff_raise >= min_raise:
                        return (PokerAction.RAISE, bluff_raise)
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        # Reset per-round flags if needed
        self.is_first_action = True

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing to do
        pass