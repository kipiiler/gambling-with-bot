from typing import List, Tuple, Dict, Set
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hole_cards = []
        self.role = ""  # "small_blind", "big_blind", or "normal"
        self.positional_tendency = 1.0  # Aggression factor based on position
        self.equity_estimate = 0.5
        self.game_phase_weights = {
            'Preflop': 0.6,
            'Flop': 0.8,
            'Turn': 0.9,
            'River': 1.0
        }
        self.player_stats = {}  # Track opponent tendencies
        self.hand_strength_history = []  # Track strength estimates per hand
        self.total_games = 0
        self.total_profit = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.total_games = 0
        self.total_profit = 0
        self.player_stats = {pid: {'folds_to_cbet': 0, 'calls': 0, 'raises': 0, 'total_actions': 1e-8} for pid in
                             all_players}

        # Initialize hole cards for self
        for pid, cards in player_hands:
            if int(pid) == self.id:
                self.hole_cards = cards
                break

        # Determine role
        if self.id == self.small_blind_player_id:
            self.role = "small_blind"
        elif self.id == self.big_blind_player_id:
            self.role = "big_blind"
        else:
            self.role = "normal"

        # Position adjustment: later position = more aggressive
        my_index = self.all_players.index(self.id)
        total_players = len(self.all_players)
        # Later positions (higher index) get higher aggression
        self.positional_tendency = 0.7 + (my_index / total_players) * 0.6

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round stats
        self.equity_estimate = self._estimate_hand_equity(round_state, remaining_chips)
        self.hole_cards = self._get_own_hole_cards()

    def _get_own_hole_cards(self) -> List[str]:
        """Extract own hole cards from player_hands using self.id."""
        for pid, cards in self.player_hands:
            if int(pid) == self.id:
                return cards
        return []

    def _estimate_hand_strength_preflop(self) -> float:
        """
        Estimate hand strength preflop based on hole cards using Chen Formula.
        """
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.5

        def card_rank(card):
            r = card[0]
            if r == 'A': return 14
            if r == 'K': return 13
            if r == 'Q': return 12
            if r == 'J': return 11
            if r == 'T': return 10
            return int(r)

        def card_value(card):
            r = card[0]
            if r == 'A': return 10
            if r == 'K': return 8
            if r == 'Q': return 7
            if r == 'J': return 6
            if r == 'T': return 5
            return int(r) / 2.0

        c1, c2 = self.hole_cards
        r1, r2 = card_rank(c1), card_rank(c2)
        suits = c1[1], c2[1]
        high_card, low_card = max(r1, r2), min(r1, r2)

        score = 0.0

        # High card value
        score += card_value(c1 if r1 > r2 else c2)

        # Pair bonus
        if r1 == r2:
            score = max(3.0, score * 2.0)

        # Suited bonus
        if suits[0] == suits[1]:
            score += 2.0

        # Gap penalty
        gap = high_card - low_card
        if gap == 1:
            score -= 0
        elif gap == 2:
            score -= 1
        elif gap == 3:
            score -= 2
        elif gap > 3:
            score -= 4

        # Connected straight draw bonus for broadway connectors
        if gap == 1 and high_card > 11:
            score += 1

        # Scale to 0-1
        return min(1.0, max(0.1, score / 20.0))

    def _estimate_hand_strength_postflop(self, round_state: RoundStateClient) -> float:
        """
        Estimate hand equity using opponent modeling and board texture.
        Simple simulation with random sampling.
        """
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.5

        board = round_state.community_cards
        total_cards = self.hole_cards + board
        if len(total_cards) < 3:
            return self._estimate_hand_strength_preflop()

        # Count outs for draws
        ranks = [c[0] for c in total_cards]
        suits = [c[1] for c in total_cards]

        # Check for flush draw
        flush_suit = None
        for s in set(suits):
            if suits.count(s) == 4:
                flush_suit = s
        has_flush_draw = flush_suit is not None and any(c[1] == flush_suit for c in self.hole_cards)

        # Check for straight draw
        rank_vals = sorted(set([{'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(r, int(r)) for r in ranks]))
        straight_draw = False
        for i in range(len(rank_vals) - 1):
            if rank_vals[i + 1] - rank_vals[i] == 1:
                continue
            elif rank_vals[i + 1] - rank_vals[i] == 2:
                straight_draw = True
                break

        # Pair / Overcards
        hole_ranks = [c[0] for c in self.hole_cards]
        pair_or_better = any(ranks.count(hr) >= 2 for hr in hole_ranks)
        overcards = sum(1 for hr in hole_ranks if {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(hr, int(hr)) > max(
            [int(r) if r.isdigit() else {'T': 10, 'J': 11, 'Q': 12, 'K': 13}.get(r, 14) for r in ranks], default=2)
                         )

        # Assign strength
        strength = 0.3
        if pair_or_better:
            if ranks.count(hole_ranks[0]) == 4 or ranks.count(hole_ranks[1]) == 4:  # Quads
                strength = 0.99
            elif len([r for r in set(ranks) if ranks.count(r) >= 3]) > 0:  # Set or full house
                strength = 0.9
            elif len([r for r in set(ranks) if ranks.count(r) >= 2]) >= 2:  # Two pair
                strength = 0.8
            elif len([r for r in set(ranks) if ranks.count(r) >= 2]) == 1:  # One pair
                if any(hr in ranks for hr in hole_ranks):  # Pocket pair or top pair
                    strength = 0.6

        elif has_flush_draw and straight_draw:
            strength = 0.65
        elif has_flush_draw or straight_draw:
            strength = 0.5
        elif overcards == 2:
            strength = 0.45
        else:
            strength = 0.35

        # Improve with position and aggression
        strength *= (0.8 + 0.4 * self.positional_tendency)
        return max(0.1, min(0.95, strength))

    def _estimate_hand_equity(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        if round_state.round == 'Preflop':
            return self._estimate_hand_strength_preflop()
        else:
            return self._estimate_hand_strength_postflop(round_state)

    def _get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        if round_state.current_bet == 0:
            return 1.0  # Free check
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if call_amount <= 0:
            return 1.0
        if call_amount >= remaining_chips:
            return 0.1  # All-in risk
        return round_state.pot / (round_state.pot + call_amount)

    def _should_bluff(self, round_state: RoundStateClient) -> bool:
        # Simple bluff logic: occasionally bluff on river if board is scary
        if round_state.round != 'River' or len(round_state.community_cards) < 5:
            return False

        suits = [c[1] for c in round_state.community_cards]
        ranks = [c[0] for c in round_state.community_cards]
        flush_possible = any(suits.count(s) >= 3 for s in set(suits))
        straight_possible = self._has_straight_possible(ranks)
        is_scary_board = flush_possible or straight_possible

        # Bluff 20% of the time on scary board with weak hand
        if is_scary_board and self.equity_estimate < 0.3:
            return random.random() < 0.2
        return False

    def _has_straight_possible(self, ranks: List[str]) -> bool:
        values = sorted(set([{'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}.get(r, int(r)) for r in ranks if r.isdigit() or r in 'TJQKA']))
        for i in range(len(values) - 1):
            if values[i+1] - values[i] <= 1:
                continue
            elif values[i+1] - values[i] <= 4:  # Missing max 3 for open-ended
                return True
        return False

    def _is_check_raising(self, round_state: RoundStateClient) -> bool:
        # If opponent checks to us and we have strong hand, consider raising
        last_action = list(round_state.player_actions.values())[-1] if round_state.player_actions else None
        return last_action == 'Check' and self.equity_estimate > 0.7

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update hole cards if missing
            if not self.hole_cards:
                self.hole_cards = self._get_own_hole_cards()

            # Estimate current hand equity
            self.equity_estimate = self._estimate_hand_equity(round_state, remaining_chips)

            # Pot odds
            pot_odds = self._get_pot_odds(round_state, remaining_chips)
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            # Default to fold if no decision made
            action = PokerAction.FOLD
            amount = 0

            # Preflop strategy: tighter early, looser late
            if round_state.round == 'Preflop':
                if self.equity_estimate > 0.6:  # Premium hands
                    if call_amount == 0:
                        action = PokerAction.RAISE
                        amount = min(3 * self.blind_amount, max_raise)
                    elif call_amount <= self.blind_amount * 3:
                        if self.equity_estimate > 0.7 and random.random() < 0.7:
                            action = PokerAction.RAISE
                            amount = min(call_amount * 2 + min_raise, max_raise)
                        else:
                            action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD if self.equity_estimate < 0.7 else PokerAction.CALL
                elif self.equity_estimate > 0.35:  # Speculative hands
                    if call_amount <= self.blind_amount * 3:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

            else:
                # Postflop: more nuanced strategy
                if call_amount == 0:
                    if self.equity_estimate > 0.4:
                        # Small bet for value or continuation bet
                        action = PokerAction.RAISE
                        bet_size = min(int(round_state.pot * (0.5 + self.equity_estimate)), max_raise)
                        amount = max(min_raise, bet_size)
                    else:
                        # Check behind with weak hand
                        action = PokerAction.CHECK
                else:
                    # Facing a bet
                    effective_equity = self.equity_estimate + 0.1 * self.positional_tendency

                    if self._should_bluff(round_state):
                        action = PokerAction.RAISE
                        amount = min(int(round_state.pot * 0.7), max_raise)
                    elif effective_equity > pot_odds:
                        if effective_equity > 0.8 and random.random() < 0.6:
                            # Value raise strong hands
                            action = PokerAction.RAISE
                            amount = min(call_amount * 2 + min_raise, max_raise)
                        else:
                            action = PokerAction.CALL
                    elif effective_equity > 0.3 and random.random() < 0.3:
                        # Float sometimes with draw
                        action = PokerAction.CALL
                    elif self._is_check_raising(round_state):
                        action = PokerAction.RAISE
                        amount = min(int(round_state.pot * 0.7), max_raise)
                    else:
                        action = PokerAction.FOLD

            # All-in protection
            if action == PokerAction.RAISE and amount >= remaining_chips * 0.9:
                action = PokerAction.ALL_IN
                amount = remaining_chips
            elif action == PokerAction.CALL and call_amount >= remaining_chips * 0.9:
                action = PokerAction.ALL_IN
                amount = remaining_chips

            # Validate and clamp amount
            if action == PokerAction.RAISE:
                amount = max(min_raise, min(amount, max_raise))
            elif action == PokerAction.CALL:
                amount = call_amount
            elif action == PokerAction.ALL_IN:
                amount = remaining_chips

            return action, amount

        except Exception as e:
            # Safety fallback
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update player stats based on actions
        for pid, action in round_state.player_actions.items():
            pid_int = int(pid)
            if pid_int != self.id and pid_int in self.player_stats:
                self.player_stats[pid_int]['total_actions'] += 1
                if action == 'Raise':
                    self.player_stats[pid_int]['raises'] += 1
                elif action == 'Call':
                    self.player_stats[pid_int]['calls'] += 1
                elif action == 'Fold':
                    # Could track folds to cbet if needed
                    pass

        # Log hand strength and result for self-improvement
        if hasattr(self, 'equity_estimate'):
            self.hand_strength_history.append({
                'strength': self.equity_estimate,
                'chips': remaining_chips
            })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict,
                    active_players_hands: dict):
        self.total_games += 1
        self.total_profit += player_score
        # Can refine strategy here based on long-term performance
        # For now: just reset for next game
        self.hole_cards = []
        self.equity_estimate = 0.5
        self.hand_strength_history = []