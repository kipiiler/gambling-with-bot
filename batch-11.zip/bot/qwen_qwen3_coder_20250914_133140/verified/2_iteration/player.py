from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.is_big_blind = False
        self.is_small_blind = False
        self.round_count = 0
        self.my_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_id = str(self.id)
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count = round_state.round_num
        # Store our hole cards if this is pre-flop
        if round_state.round == 'Preflop':
            # Hole cards would be provided in player_hands in on_start, here we just track state
            pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """A simple hand strength evaluator"""
        # This is a placeholder; a real implementation might use a library like deuces or poker-eval
        # For now, we'll implement a very basic heuristic
        
        if not hole_cards:
            return 0.0
            
        # Convert to ranks and suits
        ranks = '23456789TJQKA'
        rank_values = {r: i for i, r in enumerate(ranks, start=2)}
        
        try:
            hole_ranks = [card[0] for card in hole_cards]
            hole_suits = [card[1] for card in hole_cards]
        except:
            return 0.0
            
        strength = 0.0
        
        # Pair strength
        if len(hole_cards) == 2:
            if hole_ranks[0] == hole_ranks[1]:
                rank_val = rank_values.get(hole_ranks[0], 2)
                strength += rank_val * 0.1  # Pair strength
        
            # High card value
            for r in hole_ranks:
                if r in rank_values:
                    strength += rank_values[r] * 0.01
                    
            # Suited bonus
            if len(hole_suits) == 2 and hole_suits[0] == hole_suits[1]:
                strength += 0.05
                
        # Community cards factor
        if community_cards:
            # Simple adjustment based on number of community cards
            strength += len(community_cards) * 0.02
            
        return min(strength, 1.0)  # Cap at 1.0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(self.my_id, 0)
            to_call = current_bet - my_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            
            # Calculate hand strength
            # In a real implementation, we'd get hole cards from on_start or game state
            # As we don't have access to hole cards in this method directly, we'll use a default value
            # This is a limitation of the template, so we'll make a simple decision engine
            
            # Basic strategy based on position and pot odds
            hand_strength = 0.5  # Default neutral strength
            
            # Preflop strategy
            if round_state.round == 'Preflop':
                # Play tighter in early position, looser as dealer
                if self.is_big_blind and to_call == 0:
                    hand_strength += 0.1  # Already posted big blind
                elif self.is_small_blind and to_call <= 5:
                    hand_strength += 0.05  # Already posted small blind
                    
            # Post-flop strategy
            else:
                # Adjust based on community cards and hand strength
                hand_strength = self._evaluate_hand_strength([], round_state.community_cards)
                
                # If we have a strong hand, be more aggressive
                if hand_strength > 0.7:
                    pass  # Will likely raise or call below
                elif hand_strength < 0.3 and to_call > 10:
                    # Weak hand and expensive to call, likely fold
                    if to_call > 0:
                        return (PokerAction.FOLD, 0)
            
            # Decision making
            # If check is possible
            if to_call == 0:
                if hand_strength > 0.6 or random.random() < 0.3:  # Sometimes bet with any hand
                    raise_amount = min(max_raise, max(min_raise, 20))  # Standard raise
                    if raise_amount > 0 and raise_amount <= max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # There is a bet to call
                if hand_strength > 0.7 or to_call <= 10:  # Call small bets or with strong hands
                    if to_call >= remaining_chips:  # We can't fully call, so go all-in if we want to call
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > 0.4 and to_call <= remaining_chips * 0.1:  # Call with medium hands on small bets
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # If there's any error, fold to avoid breaking the game
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-specific state if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, could log or analyze performance here
        pass