from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_history = []
        self.position = None
        self.hand_rank = 0
        self.aggression_factor = 0.4
        self.tightness_factor = 0.6
        self.current_round = None
        self.player_hands = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.position = 'BB' if self.id == big_blind_player_id else ('SB' if self.id == small_blind_player_id else 'BUTTON')

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.hand_history.append({
            'round_state': round_state,
            'remaining_chips': remaining_chips
        })

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # Simple hand strength evaluation (placeholder for more complex logic)
        card_ranks = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            card_ranks[str(i)] = i

        # High card value
        high_card = max([card_ranks[card[0]] for card in hole_cards])
        pair_bonus = 0
        if hole_cards[0][0] == hole_cards[1][0]:
            pair_bonus = 10 + card_ranks[hole_cards[0][0]]

        suited_bonus = 2 if hole_cards[0][1] == hole_cards[1][1] else 0

        # Connectors and gaps
        rank_diff = abs(card_ranks[hole_cards[0][0]] - card_ranks[hole_cards[1][0]])
        connector_bonus = 3 if rank_diff == 1 else (1 if rank_diff == 2 else 0)

        total_strength = high_card + pair_bonus + suited_bonus + connector_bonus
        normalized_strength = total_strength / 30.0
        return min(normalized_strength, 1.0)

    def calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        if call_amount <= 0:
            return 1.0
        return pot_size / (pot_size + call_amount)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_bet
            pot = round_state.pot
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            
            # Get our hole cards
            hole_cards = self.player_hands
            
            # Evaluate hand strength
            community_cards = round_state.community_cards
            hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
            
            # Calculate pot odds
            pot_odds = self.calculate_pot_odds(to_call, pot)
            
            # Preflop strategy
            if round_state.round == "Preflop":
                if hand_strength > 0.7 or (to_call <= 3 * round_state.big_blind and hand_strength > 0.5):
                    if to_call == 0:
                        # We can check - choose to raise
                        raise_amount = min(max_raise, max(min_raise, int(2.5 * round_state.big_blind)))
                        return (PokerAction.RAISE, raise_amount)
                    elif hand_strength > 0.8 or pot_odds > 0.33:
                        # Call or raise based on strength
                        if hand_strength > 0.85 and max_raise >= 3 * to_call:
                            raise_amount = min(max_raise, max(min_raise, int(3 * to_call)))
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Post-flop strategy
            else:
                # Calculate implied odds and other factors could be added here
                if hand_strength > 0.6:
                    if to_call == 0:
                        # We can check - choose to bet
                        bet_size = min(max_raise, max(min_raise, int(0.5 * pot)))
                        return (PokerAction.RAISE, bet_size)
                    elif pot_odds > 0.25 or hand_strength > 0.75:
                        if hand_strength > 0.8 and max_raise >= 2 * to_call:
                            raise_amount = min(max_raise, max(min_raise, int(2 * to_call)))
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds > 0.4 and hand_strength > 0.4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # If any error occurs, fold to avoid disqualification
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Record round results for potential future analysis
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, could do final analysis here
        pass