from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.position = 0
        self.total_players = 0
        self.is_small_blind = False
        self.is_big_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.total_players = len(all_players)
        self.position = all_players.index(self.id) if self.id in all_players else 0
        self.is_small_blind = (self.id == small_blind_player_id)
        self.is_big_blind = (self.id == big_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get current bet and player's current bet
        current_bet = round_state.current_bet
        player_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - player_current_bet
        
        # Calculate raise amounts
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Simple strategy based on round and hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, call_amount, min_raise, max_raise, hand_strength)
        else:
            return self._postflop_strategy(round_state, call_amount, min_raise, max_raise, hand_strength)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        # Very basic hand evaluation - in a real implementation this would be more sophisticated
        return random.random()  # Placeholder for actual hand evaluation

    def _preflop_strategy(self, round_state: RoundStateClient, call_amount: int, min_raise: int, max_raise: int, hand_strength: float) -> Tuple[PokerAction, int]:
        # Position-based preflop strategy
        if hand_strength > 0.8:  # Premium hands
            if call_amount == 0:
                # We can raise
                raise_amount = min(max(min_raise, int(max_raise * 0.5)), max_raise)
                if raise_amount > 0 and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # We need to call or go all-in
                if call_amount <= max_raise:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_strength > 0.5:  # Decent hands
            if call_amount <= max_raise * 0.3:
                return (PokerAction.CALL, 0)
            elif call_amount == 0 and min_raise <= max_raise:
                raise_amount = min(max(min_raise, int(max_raise * 0.3)), max_raise)
                if raise_amount > 0 and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0) if call_amount == 0 else (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hands
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= max_raise * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, call_amount: int, min_raise: int, max_raise: int, hand_strength: float) -> Tuple[PokerAction, int]:
        # Simpler postflop strategy
        if hand_strength > 0.7:  # Strong hand
            if call_amount == 0:
                # We can raise
                raise_amount = min(max(min_raise, int(max_raise * 0.4)), max_raise)
                if raise_amount > 0 and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if call_amount <= max_raise:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_strength > 0.4:  # Medium hand
            if call_amount <= max_raise * 0.25:
                return (PokerAction.CALL, 0)
            elif call_amount == 0 and min_raise <= max_raise:
                raise_amount = min(max(min_raise, int(max_raise * 0.2)), max_raise)
                if raise_amount > 0 and raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0) if call_amount == 0 else (PokerAction.FOLD, 0)
        else:  # Weak hand
            if call_amount == 0:
                # Check if we can bet
                if min_raise <= max_raise and max_raise > 0:
                    bet_amount = min(max(min_raise, int(max_raise * 0.15)), max_raise)
                    if bet_amount > 0 and bet_amount <= max_raise:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= max_raise * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass