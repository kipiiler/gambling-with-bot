from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.my_position = 0
        self.num_players = 0
        self.player_stats = {}
        self.aggression_factor = 0.0
        self.tight_loose_factor = 0.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        for player_id in all_players:
            self.player_stats[player_id] = {
                'vpip': 0,  # voluntary put money in pot
                'pfr': 0,   # pre-flop raise
                'hands': 0,
                'raises': 0,
                'calls': 0,
                'folds': 0
            }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Get our hand from the player_bets dictionary using our ID
        # In a real implementation, this would be provided directly
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Parse our hand (this is a simplification - in reality we'd get this from on_round_start)
        # For now, assuming we have some way to know our hand
        hand_strength = self.evaluate_hand_strength(round_state)
        pot_odds = self.calculate_pot_odds(round_state)
        position_factor = self.calculate_position_factor(round_state)
        
        # Basic strategy components
        aggressive_threshold = 0.6 + (position_factor * 0.1) - (self.tight_loose_factor * 0.05)
        passive_threshold = 0.4 + (position_factor * 0.05) - (self.tight_loose_factor * 0.03)
        
        # Adjust thresholds based on number of opponents
        active_players = len([p for p in round_state.current_player if p in round_state.player_bets])
        if active_players <= 2:
            # Heads-up play - more aggressive
            aggressive_threshold *= 0.9
            passive_threshold *= 0.85
        
        # Decision making
        if hand_strength >= aggressive_threshold:
            # Strong hand - raise or go all-in
            if remaining_chips <= round_state.min_raise:
                return (PokerAction.ALL_IN, 0)
            else:
                raise_amount = min(
                    max(round_state.min_raise, int(remaining_chips * 0.5 * hand_strength)),
                    round_state.max_raise
                )
                # Ensure we're raising enough
                current_call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                total_bet = current_call_amount + raise_amount
                if total_bet < round_state.min_raise:
                    raise_amount = round_state.min_raise - current_call_amount
                    
                if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
        elif hand_strength >= passive_threshold:
            # Medium strength hand - call or check
            if round_state.current_bet > round_state.player_bets.get(str(self.id), 0):
                # Need to call
                return (PokerAction.CALL, 0)
            else:
                # Can check
                return (PokerAction.CHECK, 0)
        else:
            # Weak hand - fold or check if possible
            if round_state.current_bet > round_state.player_bets.get(str(self.id), 0):
                # Need to call to stay in - fold weak hands
                return (PokerAction.FOLD, 0)
            else:
                # Can check - check with weak hands
                return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update player statistics based on actions in this round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset any game-specific tracking
        pass

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate the strength of our hand based on hole cards and community cards"""
        # This is a simplified hand strength evaluator
        # In a real implementation, this would use more sophisticated algorithms
        
        # For demonstration, using a basic approach:
        # Hand strength is based on potential, not just current made hands
        community_cards = round_state.community_cards
        num_community = len(community_cards)
        
        # Base strength values (simplified)
        if num_community == 0:  # Pre-flop
            # Assign strength based on starting hand ranking
            return self.evaluate_preflop_hand()
        else:  # Post-flop
            # Simplified post-flop evaluation
            return self.evaluate_postflop_hand(community_cards)

    def evaluate_preflop_hand(self) -> float:
        """Evaluate pre-flop hand strength (0.0 to 1.0)"""
        # Simplified pre-flop evaluator
        # In reality, this would consider card ranks, suits, and position
        return random.uniform(0.2, 0.8)  # Placeholder

    def evaluate_postflop_hand(self, community_cards: List[str]) -> float:
        """Evaluate post-flop hand strength (0.0 to 1.0)"""
        # Simplified post-flop evaluator
        num_community = len(community_cards)
        base_strength = 0.3 + (num_community * 0.1)  # More cards = higher potential
        return min(base_strength + random.uniform(-0.2, 0.3), 1.0)  # Add some randomness

    def calculate_pot_odds(self, round_state: RoundStateClient) -> float:
        """Calculate pot odds for calling a bet"""
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if call_amount <= 0:
            return 1.0  # No cost to call
        
        pot_odds = call_amount / (round_state.pot + call_amount)
        return min(pot_odds, 1.0)

    def calculate_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor (-1 to 1)"""
        # Simplified position calculation
        # In reality, this would consider actual table position
        return 0.0  # Neutral position assumed