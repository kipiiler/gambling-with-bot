from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_id = None
        self.position = 0  # 0 = dealer, 1 = small blind, 2 = big blind
        self.num_players = 0
        self.preflop_strategy = "tight"

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_id = self.id
        self.num_players = len(all_players)
        
        # Determine our position
        if self.my_id == big_blind_player_id:
            self.position = 2
        elif self.my_id == small_blind_player_id:
            self.position = 1
        else:
            self.position = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset for each new hand
        self.hole_cards = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get our current bet
        my_current_bet = round_state.player_bets.get(str(self.my_id), 0)
        to_call = round_state.current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Preflop logic
        if round_state.round == "Preflop":
            # Basic hand strength evaluation
            card1, card2 = self.hole_cards[0], self.hole_cards[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Pair
            if rank1 == rank2:
                if rank1 in ['A', 'K', 'Q', 'J']:
                    # Premium pairs - raise aggressively
                    if to_call == 0:
                        return (PokerAction.RAISE, min(round_state.pot * 3, max_raise))
                    else:
                        if to_call <= remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    # Small to medium pairs - play carefully
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # High cards
            high_cards = 0
            if rank1 in ['A', 'K', 'Q']:
                high_cards += 1
            if rank2 in ['A', 'K', 'Q']:
                high_cards += 1
                
            # Suited cards
            suited = suit1 == suit2
            
            # Premium hands (AK, AQ, AJ, KQ)
            premium_kq = (rank1 in ['A','K'] and rank2 in ['A','K']) or \
                         (rank1 in ['A','Q'] and rank2 in ['A','Q']) or \
                         (rank1 in ['A','J'] and rank2 in ['A','J']) or \
                         (rank1 in ['K','Q'] and rank2 in ['K','Q'])
            
            if premium_kq:
                if to_call == 0:
                    return (PokerAction.RAISE, min(round_state.pot * 3, max_raise))
                else:
                    if to_call <= remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Two high cards
            if high_cards == 2:
                if to_call == 0:
                    return (PokerAction.RAISE, min(round_state.pot * 2, max_raise))
                else:
                    if to_call <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # One high card with suited
            if high_cards >= 1 and suited:
                if to_call == 0:
                    return (PokerAction.RAISE, min(round_state.pot * 1.5, max_raise))
                else:
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Connectors (54s, 65s, 76s, etc.)
            connector = False
            ranks = '23456789TJQKA'
            try:
                idx1 = ranks.index(rank1)
                idx2 = ranks.index(rank2)
                if abs(idx1 - idx2) == 1 and suited:
                    connector = True
            except:
                pass
                
            if connector:
                if to_call == 0:
                    return (PokerAction.RAISE, min(round_state.pot * 1.5, max_raise))
                else:
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Default fold for weak hands
            if to_call > 0:
                return (PokerAction.FOLD, 0)
            else:
                # If we're in late position and can check, do so
                if self.position == 0:  # Dealer
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Post-flop logic
        else:
            # Simple strategy: If we have at least a pair, continue with caution
            # This is a very simplified approach - a real implementation would do hand analysis
            has_pair_or_better = random.random() > 0.5  # Placeholder for actual hand strength evaluation
            
            if has_pair_or_better:
                if to_call == 0:
                    # We can check - do so to keep pot manageable
                    return (PokerAction.CHECK, 0)
                else:
                    # We have a hand, decide whether to call or raise based on pot odds
                    pot_odds = to_call / (round_state.pot + to_call) if (round_state.pot + to_call) > 0 else 0
                    
                    if pot_odds < 0.3:  # Good pot odds
                        if random.random() < 0.7:  # 70% chance to call
                            return (PokerAction.CALL, 0)
                        else:
                            raise_amount = min(to_call + round_state.pot, max_raise)
                            if raise_amount > to_call:
                                return (PokerAction.RAISE, raise_amount)
                            else:
                                return (PokerAction.CALL, 0)
                    elif pot_odds < 0.5:  # Medium pot odds
                        if random.random() < 0.4:  # 40% chance to call
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:  # Poor pot odds
                        return (PokerAction.FOLD, 0)
            else:
                if to_call == 0:
                    # We can check - do so
                    return (PokerAction.CHECK, 0)
                else:
                    # We don't have a strong hand - fold unless it's a small bet
                    if to_call <= remaining_chips * 0.02:  # Very small bet relative to stack
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No specific action needed at end of round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No specific action needed at end of game
        pass