from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.position = None
        self.opponent_aggression = 0.5  # Track opponent aggression
        self.games_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.all_players = all_players
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = "SB"
        elif self.id == big_blind_player_id:
            self.position = "BB"
        else:
            self.position = "BTN"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hand, round_state.community_cards)
        
        # Get betting context
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        pot_size = round_state.pot
        
        # Calculate pot odds if we need to call
        pot_odds = call_amount / (pot_size + call_amount + 0.001) if call_amount > 0 else 0
        
        # Determine if opponent has been aggressive
        opponent_raised = round_state.current_bet > (self.blind_amount if round_state.round == "Preflop" else 0)
        
        # Adjust strategy based on game stage and hand strength
        if round_state.round == "Preflop":
            return self._preflop_strategy(hand_strength, round_state, call_amount, remaining_chips)
        else:
            return self._postflop_strategy(hand_strength, round_state, call_amount, pot_odds, remaining_chips)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.1
            
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers for easier comparison
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Base strength calculation
        is_pair = val1 == val2
        is_suited = suit1 == suit2
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        gap = abs(val1 - val2)
        
        # Preflop hand strength
        if not community_cards:
            if is_pair:
                if val1 >= 10:  # TT+
                    return 0.85 + (val1 - 10) * 0.03
                elif val1 >= 7:  # 77-99
                    return 0.65 + (val1 - 7) * 0.05
                else:  # 22-66
                    return 0.45 + (val1 - 2) * 0.04
            
            # High cards
            if high_card == 14:  # Ace
                if low_card >= 10:  # AK, AQ, AJ, AT
                    return 0.75 + (low_card - 10) * 0.05 + (0.05 if is_suited else 0)
                elif low_card >= 7:  # A9-A7
                    return 0.55 + (low_card - 7) * 0.03 + (0.05 if is_suited else 0)
                else:  # A6-A2
                    return 0.35 + (low_card - 2) * 0.02 + (0.1 if is_suited else 0)
            
            # King hands
            if high_card == 13:
                if low_card >= 10:  # KQ, KJ, KT
                    return 0.65 + (low_card - 10) * 0.05 + (0.05 if is_suited else 0)
                elif low_card >= 8:  # K9, K8
                    return 0.45 + (low_card - 8) * 0.05 + (0.05 if is_suited else 0)
                else:
                    return 0.25 + (0.1 if is_suited else 0)
            
            # Queen and Jack hands
            if high_card >= 11:
                if low_card >= 9:
                    return 0.55 + (0.05 if is_suited else 0)
                elif gap <= 2 and is_suited:
                    return 0.45
                else:
                    return 0.25
            
            # Suited connectors and gaps
            if is_suited:
                if gap <= 1 and high_card >= 8:  # 87s+
                    return 0.5
                elif gap <= 2 and high_card >= 9:  # T8s+
                    return 0.45
                else:
                    return 0.3
            
            # Connectors
            if gap <= 1 and high_card >= 9:
                return 0.4
            
            return 0.2  # Weak hands
        
        # Post-flop evaluation (simplified)
        all_cards = hole_cards + community_cards
        return self._evaluate_made_hand(all_cards)
    
    def _evaluate_made_hand(self, all_cards: List[str]) -> float:
        """Simplified post-flop hand evaluation"""
        if len(all_cards) < 5:
            return 0.3  # Default for incomplete hands
        
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for pairs, trips, quads
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4:  # Four of a kind
            return 0.95
        elif counts[0] == 3 and counts[1] == 2:  # Full house
            return 0.9
        elif max(suit_counts.values()) >= 5:  # Flush
            return 0.85
        elif counts[0] == 3:  # Three of a kind
            return 0.75
        elif counts[0] == 2 and counts[1] == 2:  # Two pair
            return 0.65
        elif counts[0] == 2:  # One pair
            return 0.55
        else:  # High card
            return 0.35

    def _preflop_strategy(self, hand_strength: float, round_state: RoundStateClient, call_amount: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        
        # Very strong hands - always raise/reraise
        if hand_strength >= 0.8:
            if call_amount == 0:  # No bet to us
                raise_amount = max(round_state.min_raise, self.blind_amount * 3)
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:  # Someone bet/raised
                if call_amount <= remaining_chips // 4:  # Less than 25% of stack
                    raise_amount = max(round_state.min_raise, call_amount * 3)
                    if my_bet + raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.65:
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, self.blind_amount * 2)
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 6:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.45:
            if call_amount == 0:
                if self.position == "BTN":  # Button can be more aggressive
                    raise_amount = max(round_state.min_raise, self.blind_amount * 2)
                    if raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount and hand_strength >= 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, hand_strength: float, round_state: RoundStateClient, call_amount: int, pot_odds: float, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Post-flop strategy"""
        
        # Very strong hands
        if hand_strength >= 0.85:
            if call_amount == 0:
                bet_amount = max(round_state.min_raise, round_state.pot // 2)
                if bet_amount <= remaining_chips:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                if call_amount <= remaining_chips // 3:
                    raise_amount = max(round_state.min_raise, call_amount * 2)
                    my_bet = round_state.player_bets.get(str(self.id), 0)
                    if my_bet + raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.7:
            if call_amount == 0:
                bet_amount = max(round_state.min_raise, round_state.pot // 3)
                if bet_amount <= remaining_chips:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds <= 0.3:  # Good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.5:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds <= 0.25:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands with potential
        elif hand_strength >= 0.3:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds <= 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Very weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.games_played += 1
        
        # Update opponent aggression based on results
        for player_id, score in all_scores.items():
            if player_id != str(self.id):
                if score > 0:
                    self.opponent_aggression = min(0.8, self.opponent_aggression + 0.05)
                else:
                    self.opponent_aggression = max(0.2, self.opponent_aggression - 0.02)