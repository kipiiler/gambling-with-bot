from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.all_players = []
        self.big_blind_amount = 0
        self.opponent_stats = {}  # Track opponent tendencies
        self.hand_history = []
        self.position_awareness = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.all_players = all_players
        self.big_blind_amount = blind_amount
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggressive_actions': 0,
                    'total_actions': 0,
                    'showdowns': 0,
                    'wins': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self.evaluate_hand_strength(round_state.community_cards)
            
            # Calculate pot odds and implied odds
            pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
            
            # Analyze opponents
            opponent_aggression = self.analyze_opponents(round_state)
            
            # Position analysis
            position_strength = self.analyze_position(round_state)
            
            # Determine strategy based on multiple factors
            action_score = self.calculate_action_score(
                hand_strength, pot_odds, opponent_aggression, 
                position_strength, round_state, remaining_chips
            )
            
            return self.select_action(action_score, round_state, remaining_chips)
            
        except Exception:
            # Fallback to safe action
            if round_state.current_bet > self.get_my_current_bet(round_state):
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0

    def evaluate_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        all_cards = self.hole_cards + community_cards
        
        # Parse cards
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) >= 2:
                rank = card_str[0]
                suit = card_str[1]
                parsed_cards.append((rank, suit))
        
        if len(parsed_cards) < 2:
            return 0.1
            
        # Pre-flop hand strength
        if len(community_cards) == 0:
            return self.evaluate_preflop_strength()
        
        # Post-flop evaluation
        hand_rank = self.get_hand_rank(parsed_cards)
        
        # Convert hand rank to strength (higher rank = stronger hand)
        strength_map = {
            9: 1.0,   # Royal flush
            8: 0.95,  # Straight flush
            7: 0.9,   # Four of a kind
            6: 0.85,  # Full house
            5: 0.8,   # Flush
            4: 0.7,   # Straight
            3: 0.6,   # Three of a kind
            2: 0.4,   # Two pair
            1: 0.2,   # One pair
            0: 0.1    # High card
        }
        
        return strength_map.get(hand_rank, 0.1)

    def evaluate_preflop_strength(self) -> float:
        """Evaluate pre-flop hand strength"""
        if len(self.hole_cards) < 2:
            return 0.1
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        if len(card1) < 2 or len(card2) < 2:
            return 0.1
            
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
            
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # AA, KK, QQ, JJ, TT
                return 0.9
            elif val1 >= 7:  # 99, 88, 77
                return 0.7
            else:  # 66, 55, 44, 33, 22
                return 0.5
        
        # Suited cards
        suited = (suit1 == suit2)
        high_val = max(val1, val2)
        low_val = min(val1, val2)
        
        # High suited connectors
        if suited and abs(val1 - val2) <= 1 and high_val >= 10:
            return 0.8
        
        # High cards
        if high_val >= 12:  # Ace or King high
            if low_val >= 10:
                return 0.8
            elif low_val >= 8:
                return 0.6
            else:
                return 0.4
        
        # Suited cards
        if suited:
            return 0.5
        
        # Connected cards
        if abs(val1 - val2) <= 2:
            return 0.4
        
        return 0.2

    def get_hand_rank(self, cards) -> int:
        """Get numerical hand rank (9=royal flush, 0=high card)"""
        if len(cards) < 5:
            if len(cards) == 2:
                # Check for pair
                if cards[0][0] == cards[1][0]:
                    return 1
                return 0
            return 0
        
        # Convert ranks to values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
        
        values = []
        suits = []
        for rank, suit in cards:
            values.append(rank_values.get(rank, 2))
            suits.append(suit)
        
        values.sort(reverse=True)
        
        # Count occurrences
        value_counts = {}
        for val in values:
            value_counts[val] = value_counts.get(val, 0) + 1
        
        counts = sorted(value_counts.values(), reverse=True)
        unique_values = sorted(value_counts.keys(), reverse=True)
        
        # Check for flush
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        is_straight = False
        if len(unique_values) >= 5:
            for i in range(len(unique_values) - 4):
                if unique_values[i] - unique_values[i+4] == 4:
                    is_straight = True
                    break
            # Check for A-2-3-4-5 straight
            if set([14, 5, 4, 3, 2]).issubset(set(unique_values)):
                is_straight = True
        
        # Determine hand rank
        if is_straight and is_flush:
            if unique_values[0] == 14 and unique_values[1] == 13:  # Royal flush
                return 9
            return 8  # Straight flush
        elif counts[0] == 4:
            return 7  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 6  # Full house
        elif is_flush:
            return 5  # Flush
        elif is_straight:
            return 4  # Straight
        elif counts[0] == 3:
            return 3  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 2  # Two pair
        elif counts[0] == 2:
            return 1  # One pair
        else:
            return 0  # High card

    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        my_bet = self.get_my_current_bet(round_state)
        call_amount = round_state.current_bet - my_bet
        
        if call_amount <= 0:
            return 1.0
        
        if call_amount >= remaining_chips:
            call_amount = remaining_chips
        
        total_pot = round_state.pot + call_amount
        
        if total_pot <= 0:
            return 0.0
            
        return call_amount / (total_pot + 0.001)

    def analyze_opponents(self, round_state: RoundStateClient) -> float:
        """Analyze opponent aggression level"""
        total_aggression = 0.0
        active_opponents = 0
        
        for player_id_str, action in round_state.player_actions.items():
            try:
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    stats = self.opponent_stats[player_id]
                    if stats['total_actions'] > 0:
                        aggression = stats['aggressive_actions'] / (stats['total_actions'] + 0.001)
                        total_aggression += aggression
                        active_opponents += 1
            except (ValueError, KeyError):
                continue
        
        if active_opponents == 0:
            return 0.3  # Default moderate aggression
        
        return total_aggression / active_opponents

    def analyze_position(self, round_state: RoundStateClient) -> float:
        """Analyze position strength"""
        if not round_state.current_player or self.id not in round_state.current_player:
            return 0.5
        
        # Simple position analysis - later position is generally better
        total_players = len(self.all_players)
        if total_players <= 1:
            return 0.5
        
        try:
            my_position = round_state.current_player.index(self.id)
            position_strength = my_position / (len(round_state.current_player) - 1 + 0.001)
            return min(max(position_strength, 0.0), 1.0)
        except (ValueError, ZeroDivisionError):
            return 0.5

    def calculate_action_score(self, hand_strength: float, pot_odds: float, 
                             opponent_aggression: float, position_strength: float,
                             round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate overall action score"""
        # Base score from hand strength
        score = hand_strength
        
        # Adjust for pot odds
        if pot_odds < 0.3:  # Good pot odds
            score += 0.2
        elif pot_odds > 0.6:  # Bad pot odds
            score -= 0.3
        
        # Adjust for opponent aggression
        if opponent_aggression > 0.6:  # Aggressive opponents
            score -= 0.1
        elif opponent_aggression < 0.3:  # Passive opponents
            score += 0.1
        
        # Adjust for position
        score += (position_strength - 0.5) * 0.2
        
        # Stack size considerations
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        if stack_ratio < 0.3:  # Short stack
            if hand_strength > 0.6:
                score += 0.3  # Push with good hands
            else:
                score -= 0.2  # Be more conservative
        elif stack_ratio > 2.0:  # Big stack
            score += 0.1  # Can afford to be more aggressive
        
        return max(min(score, 1.0), 0.0)

    def select_action(self, action_score: float, round_state: RoundStateClient, 
                     remaining_chips: int) -> Tuple[PokerAction, int]:
        """Select action based on score"""
        my_bet = self.get_my_current_bet(round_state)
        call_amount = round_state.current_bet - my_bet
        
        # Check if we can check
        can_check = (call_amount <= 0)
        
        # Very strong hand
        if action_score >= 0.8:
            if can_check:
                # Sometimes check to trap
                if random.random() < 0.3:
                    return PokerAction.CHECK, 0
            
            # Aggressive play
            if remaining_chips <= call_amount:
                return PokerAction.ALL_IN, 0
            
            if round_state.max_raise > 0:
                raise_amount = min(
                    max(round_state.min_raise, round_state.pot // 2),
                    round_state.max_raise
                )
                return PokerAction.RAISE, raise_amount
            elif call_amount > 0:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0
        
        # Strong hand
        elif action_score >= 0.6:
            if call_amount > remaining_chips * 0.3:
                # Large bet, be cautious
                if action_score >= 0.7:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            if round_state.max_raise > 0 and random.random() < 0.4:
                raise_amount = min(round_state.min_raise, round_state.max_raise)
                return PokerAction.RAISE, raise_amount
            elif call_amount > 0:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0
        
        # Moderate hand
        elif action_score >= 0.4:
            if call_amount > remaining_chips * 0.2:
                return PokerAction.FOLD, 0
            elif call_amount > 0:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0
        
        # Weak hand
        else:
            if call_amount > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0

    def get_my_current_bet(self, round_state: RoundStateClient) -> int:
        """Get my current bet in this round"""
        return round_state.player_bets.get(str(self.id), 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Update opponent statistics"""
        for player_id_str, action in round_state.player_actions.items():
            try:
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    stats = self.opponent_stats[player_id]
                    stats['total_actions'] += 1
                    
                    if action in ['RAISE', 'ALL_IN']:
                        stats['aggressive_actions'] += 1
            except (ValueError, KeyError):
                continue

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Update long-term statistics"""
        for player_id, score in all_scores.items():
            try:
                pid = int(player_id)
                if pid != self.id and pid in self.opponent_stats:
                    self.opponent_stats[pid]['hands_played'] += 1
                    if score > 0:
                        self.opponent_stats[pid]['wins'] += 1
            except (ValueError, KeyError):
                continue