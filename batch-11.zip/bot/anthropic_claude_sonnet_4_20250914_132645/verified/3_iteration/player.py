from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.position_advantage = {}
        self.opponent_stats = {}
        self.hand_history = []
        self.aggressive_factor = 1.2
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.my_cards = player_hands
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggression': 0.5,
                    'fold_frequency': 0.5,
                    'bluff_frequency': 0.1
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            position_factor = self._get_position_factor(round_state)
            
            # Calculate amount needed to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Safety checks for remaining chips
            if remaining_chips <= 0:
                return (PokerAction.FOLD, 0)
            
            # Pre-flop strategy
            if round_state.round == 'Preflop':
                return self._preflop_strategy(round_state, remaining_chips, hand_strength, call_amount)
            
            # Post-flop strategy
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, position_factor, call_amount)
            
        except Exception:
            # Safe fallback - fold if any error occurs
            return (PokerAction.FOLD, 0)

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, call_amount: int) -> Tuple[PokerAction, int]:
        # Strong hands - premium pairs and high cards
        if hand_strength >= 0.8:
            if call_amount == 0:
                raise_amount = min(round_state.pot // 2 + round_state.min_raise, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 4:
                raise_amount = min(call_amount * 3 + round_state.min_raise, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0) if call_amount <= remaining_chips else (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.5:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 8:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount:
                return (PokerAction.CALL, 0) if call_amount <= remaining_chips else (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, position_factor: float, call_amount: int) -> Tuple[PokerAction, int]:
        # Very strong hands
        if hand_strength >= 0.9:
            if call_amount == 0:
                raise_amount = min(round_state.pot // 2 + round_state.min_raise, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips:
                if remaining_chips <= call_amount * 3:
                    return (PokerAction.ALL_IN, 0)
                else:
                    raise_amount = min(call_amount * 2 + round_state.min_raise, remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Strong hands
        elif hand_strength >= 0.7:
            if call_amount == 0:
                if random.random() < 0.7:
                    raise_amount = min(round_state.pot // 3 + round_state.min_raise, remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands with pot odds consideration
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds > 0.3 and call_amount <= remaining_chips // 4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.my_cards:
            return 0.0
        
        try:
            # Basic hand evaluation
            if len(round_state.community_cards) == 0:
                return self._evaluate_preflop_strength()
            else:
                return self._evaluate_postflop_strength(round_state.community_cards)
        except:
            return 0.3  # Default medium strength

    def _evaluate_preflop_strength(self) -> float:
        if len(self.my_cards) < 2:
            return 0.0
        
        card1, card2 = self.my_cards[0], self.my_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert ranks to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # TT, JJ, QQ, KK, AA
                return 0.9
            elif val1 >= 7:  # 77, 88, 99
                return 0.7
            else:  # 22-66
                return 0.5
        
        # High cards
        high_val = max(val1, val2)
        low_val = min(val1, val2)
        
        # Suited connectors and high cards
        is_suited = (suit1 == suit2)
        is_connected = abs(val1 - val2) <= 1
        
        if high_val == 14:  # Ace high
            if low_val >= 10:  # AK, AQ, AJ, AT
                return 0.85 if is_suited else 0.75
            elif low_val >= 7:  # A9, A8, A7
                return 0.6 if is_suited else 0.4
            else:
                return 0.5 if is_suited else 0.3
        
        elif high_val >= 12:  # King or Queen high
            if low_val >= 10:  # KQ, KJ, QJ
                return 0.7 if is_suited else 0.6
            else:
                return 0.4 if is_suited else 0.3
        
        elif is_suited and is_connected and high_val >= 8:
            return 0.5
        
        return 0.2

    def _evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        try:
            all_cards = self.my_cards + community_cards
            if len(all_cards) < 5:
                return self._evaluate_preflop_strength() * 0.8
            
            # Simple post-flop evaluation
            ranks = [card[0] for card in all_cards]
            suits = [card[1] for card in all_cards]
            
            rank_counts = {}
            suit_counts = {}
            
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            # Check for pairs, trips, quads
            counts = sorted(rank_counts.values(), reverse=True)
            
            if counts[0] >= 4:  # Four of a kind
                return 0.95
            elif counts[0] == 3 and counts[1] >= 2:  # Full house
                return 0.9
            elif max(suit_counts.values()) >= 5:  # Flush
                return 0.85
            elif counts[0] == 3:  # Three of a kind
                return 0.75
            elif counts[0] == 2 and counts[1] == 2:  # Two pair
                return 0.6
            elif counts[0] == 2:  # One pair
                return 0.4
            else:
                return 0.2
                
        except:
            return 0.3

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        try:
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount <= 0:
                return 1.0
            
            total_pot = round_state.pot + call_amount
            return call_amount / (total_pot + 1e-6)  # Add small epsilon to avoid division by zero
        except:
            return 0.5

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        try:
            active_players = len(round_state.current_player)
            if active_players <= 2:
                return 1.2  # Heads up - position matters more
            else:
                return 1.0
        except:
            return 1.0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent statistics based on observed actions
        try:
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    self.opponent_stats[player_id]['hands_played'] += 1
                    
                    if action in ['RAISE', 'ALL_IN']:
                        self.opponent_stats[player_id]['aggression'] = min(1.0, 
                            self.opponent_stats[player_id]['aggression'] + 0.1)
                    elif action == 'FOLD':
                        self.opponent_stats[player_id]['fold_frequency'] = min(1.0,
                            self.opponent_stats[player_id]['fold_frequency'] + 0.05)
        except:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Learn from final results
        pass