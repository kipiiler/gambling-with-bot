from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.all_players = []
        self.opponent_stats = {}
        self.game_history = []
        self.position_advantage = False
        self.aggressive_factor = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggression': 0.0,
                    'fold_frequency': 0.0,
                    'last_actions': []
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Determine position advantage (acting later is generally better)
        if len(round_state.current_player) == 2:
            current_idx = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
            self.position_advantage = current_idx > 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Safety check - ensure we're in the current players
            if self.id not in round_state.current_player:
                return (PokerAction.FOLD, 0)
            
            # Get our hand
            my_hand = self.player_hands
            if not my_hand or len(my_hand) < 2:
                return (PokerAction.FOLD, 0)
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(my_hand, round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Update opponent tracking
            self._update_opponent_stats(round_state)
            
            # Get betting strategy
            action, amount = self._get_betting_strategy(
                hand_strength, pot_odds, round_state, remaining_chips
            )
            
            # Validate action
            return self._validate_action(action, amount, round_state, remaining_chips)
            
        except Exception:
            # Fallback to safe action
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif round_state.current_bet <= remaining_chips // 10:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
        
        try:
            # Parse hole cards
            card1_rank, card1_suit = self._parse_card(hole_cards[0])
            card2_rank, card2_suit = self._parse_card(hole_cards[1])
            
            if card1_rank is None or card2_rank is None:
                return 0.0
            
            # Base strength on hole cards
            strength = 0.0
            
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 10:  # JJ, QQ, KK, AA
                    strength = 0.85 + (card1_rank - 10) * 0.03
                elif card1_rank >= 7:  # 77-TT
                    strength = 0.65 + (card1_rank - 7) * 0.05
                else:  # 22-66
                    strength = 0.45 + (card1_rank - 2) * 0.04
            
            # Suited cards
            elif card1_suit == card2_suit:
                high_card = max(card1_rank, card2_rank)
                low_card = min(card1_rank, card2_rank)
                gap = high_card - low_card
                
                if high_card >= 12:  # A or K high
                    strength = 0.70 - gap * 0.05
                elif high_card >= 10:  # Q or J high
                    strength = 0.55 - gap * 0.04
                else:
                    strength = 0.40 - gap * 0.03
            
            # Offsuit cards
            else:
                high_card = max(card1_rank, card2_rank)
                low_card = min(card1_rank, card2_rank)
                gap = high_card - low_card
                
                if high_card >= 12 and low_card >= 10:  # AK, AQ, AJ, KQ, etc.
                    strength = 0.65 - gap * 0.05
                elif high_card >= 10:
                    strength = 0.45 - gap * 0.04
                else:
                    strength = 0.25 - gap * 0.02
            
            # Adjust based on community cards
            if community_cards:
                strength = self._adjust_for_community_cards(
                    hole_cards, community_cards, strength
                )
            
            return max(0.0, min(1.0, strength))
            
        except Exception:
            return 0.3  # Default modest strength

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string like 'Ah' into rank and suit"""
        if not card or len(card) != 2:
            return None, None
        
        rank_str, suit = card[0], card[1]
        
        if rank_str == 'A':
            rank = 14
        elif rank_str == 'K':
            rank = 13
        elif rank_str == 'Q':
            rank = 12
        elif rank_str == 'J':
            rank = 11
        elif rank_str == 'T':
            rank = 10
        elif rank_str.isdigit():
            rank = int(rank_str)
        else:
            return None, None
        
        return rank, suit

    def _adjust_for_community_cards(self, hole_cards: List[str], community_cards: List[str], base_strength: float) -> float:
        """Adjust hand strength based on community cards"""
        try:
            all_cards = hole_cards + community_cards
            ranks = []
            suits = []
            
            for card in all_cards:
                rank, suit = self._parse_card(card)
                if rank is not None:
                    ranks.append(rank)
                    suits.append(suit)
            
            if not ranks:
                return base_strength
            
            # Count pairs, trips, etc.
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            counts = sorted(rank_counts.values(), reverse=True)
            
            # Four of a kind
            if counts[0] >= 4:
                return 0.95
            
            # Full house
            if counts[0] >= 3 and len(counts) > 1 and counts[1] >= 2:
                return 0.90
            
            # Flush
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            if max(suit_counts.values()) >= 5:
                return 0.85
            
            # Straight
            unique_ranks = sorted(set(ranks))
            if self._has_straight(unique_ranks):
                return 0.80
            
            # Three of a kind
            if counts[0] >= 3:
                return 0.75
            
            # Two pair
            if counts[0] >= 2 and len(counts) > 1 and counts[1] >= 2:
                return 0.65
            
            # One pair
            if counts[0] >= 2:
                return max(base_strength, 0.50)
            
            return base_strength
            
        except Exception:
            return base_strength

    def _has_straight(self, ranks: List[int]) -> bool:
        """Check if ranks contain a straight"""
        if len(ranks) < 5:
            return False
        
        # Check for A-2-3-4-5 straight (wheel)
        if 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
            return True
        
        # Check for normal straights
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        return False

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            
            if call_amount == 0:
                return float('inf')  # No cost to continue
            
            if call_amount > remaining_chips:
                return 0.0  # Can't afford to call
            
            total_pot = round_state.pot + call_amount
            return total_pot / (call_amount + 1e-6)  # Add small epsilon to avoid division by zero
            
        except Exception:
            return 1.0

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        try:
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    stats = self.opponent_stats[player_id]
                    stats['last_actions'].append(action)
                    if len(stats['last_actions']) > 10:
                        stats['last_actions'].pop(0)
                    
                    # Update aggression
                    aggressive_actions = ['Raise', 'All-in']
                    if action in aggressive_actions:
                        stats['aggression'] = min(1.0, stats['aggression'] + 0.1)
                    elif action == 'Fold':
                        stats['fold_frequency'] = min(1.0, stats['fold_frequency'] + 0.1)
        except Exception:
            pass

    def _get_betting_strategy(self, hand_strength: float, pot_odds: float, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine betting strategy based on hand strength and situation"""
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            
            # Adaptive thresholds based on position and opponents
            fold_threshold = 0.25
            call_threshold = 0.45
            raise_threshold = 0.70
            
            # Adjust for position
            if self.position_advantage:
                fold_threshold -= 0.05
                call_threshold -= 0.05
                raise_threshold -= 0.05
            
            # Adjust for pot size relative to stack
            pot_to_stack_ratio = round_state.pot / (remaining_chips + 1e-6)
            if pot_to_stack_ratio > 0.3:  # Large pot
                call_threshold -= 0.05
                raise_threshold -= 0.05
            
            # Very strong hands - always aggressive
            if hand_strength >= 0.85:
                if call_amount == 0:
                    raise_amount = max(round_state.min_raise, round_state.pot // 2)
                    return (PokerAction.RAISE, min(raise_amount, round_state.max_raise))
                else:
                    if call_amount < remaining_chips // 3:
                        # Raise with very strong hands
                        raise_amount = call_amount + round_state.pot // 3
                        if raise_amount <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
            
            # Strong hands
            elif hand_strength >= raise_threshold:
                if call_amount == 0:
                    raise_amount = max(round_state.min_raise, round_state.pot // 3)
                    return (PokerAction.RAISE, min(raise_amount, round_state.max_raise))
                elif call_amount <= remaining_chips // 4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Medium hands
            elif hand_strength >= call_threshold:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= remaining_chips // 8 and pot_odds > 3.0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Weak hands
            elif hand_strength >= fold_threshold:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= self.blind_amount and pot_odds > 5.0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Very weak hands
            else:
                if call_amount == 0:
                    # Occasional bluff
                    if random.random() < 0.1 and round_state.round in ['Flop', 'Turn']:
                        raise_amount = max(round_state.min_raise, round_state.pot // 2)
                        return (PokerAction.RAISE, min(raise_amount, round_state.max_raise))
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception:
            # Safe fallback
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _validate_action(self, action: PokerAction, amount: int, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Validate and correct action if necessary"""
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            
            # Check action validity
            if action == PokerAction.CHECK:
                if round_state.current_bet > 0:
                    # Can't check when there's a bet, call instead if affordable
                    if call_amount <= remaining_chips // 10:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                return (PokerAction.CHECK, 0)
            
            elif action == PokerAction.CALL:
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            
            elif action == PokerAction.RAISE:
                if amount < round_state.min_raise:
                    amount = round_state.min_raise
                if amount > round_state.max_raise:
                    if remaining_chips > call_amount:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                return (PokerAction.RAISE, amount)
            
            elif action == PokerAction.ALL_IN:
                if remaining_chips <= call_amount:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.ALL_IN, 0)
            
            else:  # FOLD
                return (PokerAction.FOLD, 0)
                
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game results for learning
        self.game_history.append({
            'round': round_state.round,
            'final_pot': round_state.pot,
            'remaining_chips': remaining_chips
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Adjust strategy based on performance
        if player_score > 0:
            self.aggressive_factor = min(1.2, self.aggressive_factor + 0.02)
        else:
            self.aggressive_factor = max(0.8, self.aggressive_factor - 0.02)