from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

def card_to_value(card: str) -> int:
    rank = card[0]
    if rank == 'A': return 14
    if rank == 'K': return 13
    if rank == 'Q': return 12
    if rank == 'J': return 11
    if rank == 'T': return 10
    return int(rank)

def is_suited(card1: str, card2: str) -> bool:
    return card1[-1] == card2[-1]

def evaluate_hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    all_cards = hole_cards + community_cards
    values = sorted([card_to_value(c) for c in all_cards], reverse=True)
    suits = [c[-1] for c in all_cards]
    
    # Simple heuristic score
    score = 0
    value_counts = {}
    for v in values:
        value_counts[v] = value_counts.get(v, 0) + 1
    suit_counts = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1

    pairs = [v for v, c in value_counts.items() if c == 2]
    trips = [v for v, c in value_counts.items() if c == 3]
    quads = [v for v, c in value_counts.items() if c == 4]

    # Pair
    if pairs:
        score += 50 + max(pairs)
    # Two pair
    if len(pairs) >= 2:
        score += 100 + sum(sorted(pairs, reverse=True)[:2])
    # Trips
    if trips:
        score += 150 + max(trips)
    # Straight possibility
    unique_vals = sorted(set(values), reverse=True)
    straight = False
    for i in range(len(unique_vals) - 4):
        if unique_vals[i] - unique_vals[i+4] == 4:
            straight = True
            score += 200 + unique_vals[i]
            break
    # Flush possibility
    flush = max(suit_counts.values()) >= 5
    if flush:
        score += 250
    # Full house
    if trips and pairs:
        score += 300 + max(trips) * 2
    # Quads
    if quads:
        score += 400 + max(quads)

    # High card
    score += max(values) / 100.0
    if is_suited(hole_cards[0], hole_cards[1]):
        score += 2

    return score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.position = 0
        self.players = []
        self.hand_history = []
        self.aggression_factor = 0.7
        self.tightness = 0.4

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.players = all_players
        self.position = 0
        if self.id == big_blind_player_id:
            self.position = 2
        elif self.id == small_blind_player_id:
            self.position = 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round.lower() == 'preflop':
            self.hole_cards = [c for c in self.hole_cards if c]

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pot = round_state.pot
        current_bet = round_state.current_bet
        to_call = max(0, current_bet - round_state.player_bets.get(str(self.id), 0))
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        community = round_state.community_cards
        rnd = round_state.round.lower()

        if not self.hole_cards or len(self.hole_cards) < 2:
            return PokerAction.FOLD, 0

        strength = evaluate_hand_strength(self.hole_cards, community)

        if rnd == 'preflop':
            # Premium pairs
            values = sorted([card_to_value(c) for c in self.hole_cards], reverse=True)
            if values[0] == values[1] and values[0] >= 12:  # QQ+ pairs
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(remaining_chips * 0.08))
                else:
                    return PokerAction.RAISE, max(min_raise, to_call * 3)
            # AK suited
            if values[0] == 14 and values[1] == 13 and is_suited(self.hole_cards[0], self.hole_cards[1]):
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(remaining_chips * 0.06))
                else:
                    return PokerAction.CALL, 0
            # Mid pairs
            if values[0] == values[1] and values[0] >= 9:
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(remaining_chips * 0.04))
                elif to_call <= int(remaining_chips * 0.05):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Suited connectors
            if is_suited(self.hole_cards[0], self.hole_cards[1]) and values[0] - values[1] <= 2 and values[0] >= 11:
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(remaining_chips * 0.03))
                elif to_call <= int(remaining_chips * 0.03):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Default
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                if to_call <= int(remaining_chips * 0.02):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            # Post-flop
            if strength > 300:
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(pot * 0.7))
                else:
                    return PokerAction.RAISE, max(min_raise, to_call * 2)
            elif strength > 150:
                if to_call == 0:
                    return PokerAction.RAISE, max(min_raise, int(pot * 0.4))
                else:
                    if to_call <= int(pot * 0.5):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif strength > 50:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= int(pot * 0.25):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass