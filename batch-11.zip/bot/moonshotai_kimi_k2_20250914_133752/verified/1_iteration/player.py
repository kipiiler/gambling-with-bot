from typing import List, Tuple, Dict, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import math
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 100
        self.position = 0
        self.players_count = 0
        self.hand_strength_cache = {}
        self.opp_tendency = {}
        self.my_actions = []
        self.pot_odds_call_ratio = 0.3
        self.aggression_factor = 1.0
        self.tight_loose_ratio = 0.7
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.players_count = len(all_players)
        self.opp_tendency = {player_id: {'vpip': 0, 'pfr': 0, 'aggr': 0, 'hands': 0} for player_id in all_players}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength relative to possible hands"""
        if len(community_cards) == 0:
            return self._preflop_strength(hole_cards)
        return self._postflop_strength(hole_cards, community_cards)
    
    def _preflop_strength(self, hole_cards: List[str]) -> float:
        """Evaluate preflop hand strength 0-1"""
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                 '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        card1, card2 = hole_cards
        rank1 = ranks[card1[0]]
        rank2 = ranks[card2[0]]
        suit1 = card1[1]
        suit2 = card2[1]
        
        # High cards first
        strength = max(rank1, rank2) / 14.0
        
        # Pairs
        if rank1 == rank2:
            return 0.9 + (rank1 / 100.0)
        
        # Suited
        suited_bonus = 0.1 if suit1 == suit2 else 0
        connected_bonus = 0.05 * (1 - abs(rank1 - rank2) / 13.0)
        
        # Penalty for big gaps
        gap_penalty = 0.05 if abs(rank1 - rank2) > 4 else 0
        
        # Combine factors
        combined_strength = (max(rank1, rank2) + min(rank1, rank2) / 2.0) / 14.0
        strength = combined_strength + suited_bonus + connected_bonus - gap_penalty
        
        return max(0, min(1, strength))
    
    def _postflop_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple postflop evaluation - count outs and hand category"""
        # Basic implementation - count made hands and draws
        all_cards = hole_cards + community_cards
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Count pairs, trips, quads
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Made hand categories
        if max(rank_counts.values()) >= 4:
            return 0.95  # Quads
        elif max(rank_counts.values()) == 3:
            if len([v for v in rank_counts.values() if v >= 2]) >= 2:
                return 0.90  # Full house
            return 0.75  # Trips
        elif max(suit_counts.values()) >= 5:
            return 0.85  # Flush
        elif self._is_straight(all_cards):
            return 0.80  # Straight
        elif max(rank_counts.values()) == 2:
            pairs = len([v for v in rank_counts.values() if v >= 2])
            if pairs >= 2:
                return 0.65  # Two pair
            else:
                return 0.50  # One pair
        
        return 0.20  # High card or draws
    
    def _is_straight(self, cards: List[str]) -> bool:
        """Check if cards contain a straight"""
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                    '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = [rank_map[card[0]] for card in cards]
        ranks = list(set(ranks))  # Remove duplicates
        ranks.sort()
        
        if len(ranks) < 5:
            return False
            
        # Check for straight
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        # Check for wheel (A-2-3-4-5)
        if 14 in ranks and 2 in ranks and 3 in ranks and 4 in ranks and 5 in ranks:
            return True
            
        return False
    
    def _calculate_pot_odds(self, round_state: RoundStateClient) -> float:
        """Calculate pot odds to call"""
        if round_state.current_bet == 0:
            return float('inf')
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if round_state.pot <= 0 or call_amount <= 0:
            return 1.0
        return round_state.pot / max(1, call_amount)
    
    def _get_opponent_range(self, round_state: RoundStateClient) -> float:
        """Estimate opponent's hand strength based on actions"""
        # Simple model: more aggressive means stronger range
        opp_count = len([p for p in round_state.player_actions.keys() if p != str(self.id)])
        if opp_count == 0:
            return 0.5
            
        agg_actions = 0
        total_actions = 0
        
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                total_actions += 1
                if action in ['Raise', 'All-in']:
                    agg_actions += 1
                elif action in ['Check', 'Call']:
                    agg_actions += 0.5
                    
        # Estimate opponent strength based on aggression
        if total_actions == 0:
            return 0.5
            
        return max(0, min(1, agg_actions / total_actions))
    
    def _get_position_strength(self, round_state: RoundStateClient) -> float:
        """Get position advantage 0-1"""
        players_in_order = list(round_state.player_actions.keys())
        if len(players_in_order) <= 1:
            return 1.0
            
        position = next(i for i, pid in enumerate(players_in_order) if pid == str(self.id))
        return (len(players_in_order) - position) / len(players_in_order)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Main decision logic"""
        try:
            if not self.player_hands or remaining_chips <= 0:
                return PokerAction.FOLD, 0
                
            hole_cards = self.player_hands[-2:] if len(self.player_hands) >= 2 else []
            if not hole_cards:
                return PokerAction.FOLD, 0
                
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
            position_strength = self._get_position_strength(round_state)
            pot_odds = self._calculate_pot_odds(round_state)
            pot_size = round_state.pot
            
            # Current bet amount
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Basic thresholds
            tight_threshold = 0.7 * self.tight_loose_ratio
            loose_threshold = 0.4 * self.tight_loose_ratio
            bluff_threshold = 0.3
            
            # Adjust for round
            round_adjustment = {
                'Preflop': 0.8,
                'Flop': 1.0,
                'Turn': 1.2,
                'River': 1.5
            }
            
            strength_adjusted = hand_strength * round_adjustment.get(round_state.round, 1.0) * position_strength
            
            # Pot odds check for calling
            if pot_odds != float('inf') and pot_odds > 0:
                pot_odds_needed = 1.0 / (pot_odds + 1.0)
                if hand_strength > pot_odds_needed + 0.1:
                    if call_amount <= 0:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CALL, 0
            
            # Decision tree based on strength and position
            if strength_adjusted > tight_threshold:
                # Value betting
                bet_size = min(
                    int(pot_size * (0.75 + strength_adjusted * 0.5)),
                    remaining_chips
                )
                
                if bet_size > round_state.current_bet and bet_size >= round_state.min_raise:
                    if random.random() < 0.8:  # 80% value bet
                        actual_bet = max(bet_size, my_current_bet + round_state.min_raise)
                        return PokerAction.RAISE, min(actual_bet, remaining_chips)
                    else:
                        return PokerAction.CALL, 0
                elif call_amount <= 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, 0
                    
            elif strength_adjusted > loose_threshold:
                # Semi-bluffing and defending
                if round_state.round == 'River':
                    # Don't bluff on river with weak hands
                    if call_amount <= 0:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.FOLD, 0
                        
                # Small bluff
                if pot_size > 0 and random.random() < 0.3:
                    bluff_size = min(int(pot_size * 0.6), remaining_chips)
                    if bluff_size >= round_state.min_raise:
                        return PokerAction.RAISE, bluff_size
                
                if call_amount <= 0:
                    return PokerAction.CHECK, 0
                elif call_amount < round_state.pot * 0.1:  # Cheap call
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
            else:
                # Weak hands - fold most times
                if call_amount <= 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
                    
        except Exception as e:
            # Conservative fallback
            return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Post-round processing"""
        try:
            # Update opponent tendencies
            for player_id, action in round_state.player_actions.items():
                if player_id != str(self.id):
                    if player_id not in self.opp_tendency:
                        self.opp_tendency[player_id] = {'vpip': 0, 'pfr': 0, 'aggr': 0, 'hands': 0}
                    
                    self.opp_tendency[player_id]['hands'] += 1
                    
                    # Track VPIP (Voluntarily Put $ In Pot)
                    if action in ['Call', 'Raise', 'All-in']:
                        self.opp_tendency[player_id]['vpip'] += 1
                        
                    # Track PFR (Pre-flop raise)
                    if action == 'Raise' and round_state.round == 'Preflop':
                        self.opp_tendency[player_id]['pfr'] += 1
                        
                    # Track aggression ratio
                    if action in ['Raise', 'All-in']:
                        self.opp_tendency[player_id]['aggr'] += 2
                    elif action in ['Check', 'Call']:
                        self.opp_tendency[player_id]['aggr'] += 1
                        
        except:
            pass
            
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """End of game processing"""
        try:
            # Adaptive strategy based on performance
            if player_score > 0:
                self.tight_loose_ratio *= 1.05  # Stay a bit looser when winning
            else:
                self.tight_loose_ratio *= 0.98  # Tighten up when losing
                
            # Reset tracking for next game
            self.player_hands = []
            
        except:
            pass