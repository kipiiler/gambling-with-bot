from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.hole_cards = []
        self.position = 0
        self.players = []
        self.aggression_factor = 1.0
        self.tightness = 0.7
        self.stack_sizes = {}
        self.player_actions_history = {}
        self.round_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands
        self.players = all_players
        self.position = self.players.index(self.id) if self.id in self.players else 0
        self.aggression_factor = 1.0
        self.tightness = 0.7
        self.stack_sizes = {p: starting_chips for p in all_players}
        self.player_actions_history = {p: [] for p in all_players}
        self.round_count = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1
        
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        all_cards = hole_cards + community_cards
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suits = {'h': [], 'd': [], 'c': [], 's': []}
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            suits[suit].append(ranks[rank])
        
        rank_counts = {}
        for card in all_cards:
            rank = card[0]
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        flush_suit = None
        for suit, cards in suits.items():
            if len(cards) >= 5:
                flush_suit = suit
                break
        
        pairs = []
        trips = []
        quads = []
        for rank, count in rank_counts.items():
            if count == 2:
                pairs.append(ranks[rank])
            elif count == 3:
                trips.append(ranks[rank])
            elif count == 4:
                quads.append(ranks[rank])
        
        if quads:
            return 0.9
        if trips and pairs:
            return 0.85
        if flush_suit:
            return 0.8
        if len(trips) >= 1:
            return 0.7
        if len(pairs) >= 2:
            return 0.6
        if len(pairs) == 1:
            return 0.5
        
        high_card = max([ranks[card[0]] for card in hole_cards])
        return high_card / 14.0 * 0.4
        
    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position factor for betting decisions"""
        num_players = len(round_state.current_player)
        if num_players <= 2:
            return 1.0 if round_state.current_player.index(self.id) == 0 else 0.9
        else:
            position = round_state.current_player.index(self.id)
            return 1.2 - (position / num_players) * 0.4
            
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling decisions"""
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot = round_state.pot
        if to_call <= 0:
            return 1.0
        return pot / to_call if to_call > 0 else 1.0
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Main decision logic for poker actions"""
        if not self.hole_cards:
            return PokerAction.FOLD, 0
            
        hole_cards = self.hole_cards
        community_cards = round_state.community_cards
        
        hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        position_factor = self._get_position_factor(round_state)
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_size = round_state.pot
        
        adjusted_strength = hand_strength * position_factor
        
        if round_state.round == 'Preflop':
            if 'A' in [card[0] for card in hole_cards] or 'K' in [card[0] for card in hole_cards]:
                adjusted_strength *= 1.2
            elif hole_cards[0][0] == hole_cards[1][0]:
                adjusted_strength *= 1.1
                
        if adjusted_strength > 0.8:
            if remaining_chips > round_state.min_raise:
                raise_amount = min(int(pot_size * 0.75), remaining_chips, round_state.max_raise)
                if raise_amount >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.ALL_IN, 0
            else:
                return PokerAction.ALL_IN, 0
                
        elif adjusted_strength > 0.6:
            if to_call <= 0:
                return PokerAction.CHECK, 0
            elif pot_odds > 2.5 and to_call <= remaining_chips * 0.1:
                return PokerAction.CALL, 0
            elif remaining_chips > round_state.min_raise and random.random() < 0.3:
                raise_amount = min(int(pot_size * 0.5), remaining_chips, round_state.max_raise)
                return PokerAction.RAISE, max(raise_amount, round_state.min_raise)
            else:
                return PokerAction.CALL, 0
                
        elif adjusted_strength > 0.4:
            if to_call <= 0:
                return PokerAction.CHECK, 0
            elif pot_odds > 3.0 and to_call <= remaining_chips * 0.05:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
                
        else:
            if to_call <= 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass