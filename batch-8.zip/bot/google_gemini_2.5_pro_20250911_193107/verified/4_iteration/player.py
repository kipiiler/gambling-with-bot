import itertools
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for hand ranking, higher is better
HIGH_CARD = 1
ONE_PAIR = 2
TWO_PAIR = 3
THREE_OF_A_KIND = 4
STRAIGHT = 5
FLUSH = 6
FULL_HOUSE = 7
FOUR_OF_A_KIND = 8
STRAIGHT_FLUSH = 9
ROYAL_FLUSH = 10

# Card ranks mapping for easy conversion and comparison
RANK_MAP = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}


class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of hand strength evaluation,
    pot odds, and position to make decisions.
    It evaluates made hands and draws, and adjusts its strategy based on
    the number of active players and the betting action.
    """
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.hand_strength: float = 0.0
        self.all_player_ids: List[int] = []
        self.blind_amount: int = 10  # Default, will be updated

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called once at the start of a game (which can be many hands). """
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.all_player_ids = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each betting round (pre-flop, flop, etc.). """
        # Hand strength is recalculated at the start of each action
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Main decision-making function.
        Returns a tuple of (PokerAction, amount).
        """
        # 1. Evaluate current hand strength
        self.hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # 2. Get game context
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_cost = round_state.current_bet - my_bet
        can_check = call_cost == 0

        # Determine number of active players for strength adjustment
        num_active_players = 2  # Default to heads-up
        if round_state.side_pots and round_state.side_pots[0] and 'eligible_players' in round_state.side_pots[0]:
            num_active_players = len(round_state.side_pots[0]['eligible_players'])
        num_active_players = max(1, num_active_players)
        
        # Adjust strength based on opponents; more players means we need a stronger hand.
        adjusted_strength = self.hand_strength / (num_active_players ** 0.5)

        # 3. Decision Logic

        # 3a. Short-stack strategy: push or fold
        if remaining_chips < 15 * self.blind_amount:
            if adjusted_strength > 0.65:
                return PokerAction.ALL_IN, 0
            if can_check:
                return PokerAction.CHECK, 0
            # If facing a small bet with a decent hand, call
            if call_cost < 0.2 * remaining_chips and adjusted_strength > 0.4:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        
        # 3b. Regular stack strategy
        if can_check:
            # Opportunity to bet or check
            if adjusted_strength > 0.7:  # Strong hand: bet for value
                bet_amount = int(0.75 * round_state.pot)
            elif adjusted_strength > 0.4: # Decent hand or strong draw: bet for value/protection
                bet_amount = int(0.5 * round_state.pot)
            else: # Weak hand: check
                return PokerAction.CHECK, 0
            
            # Sanitize bet amount and make the bet
            bet_amount = max(bet_amount, self.blind_amount)
            bet_amount = min(bet_amount, remaining_chips)
            return PokerAction.RAISE, bet_amount

        else: # Facing a bet
            pot_odds = call_cost / (round_state.pot + call_cost + 1e-9)
            is_large_bet = call_cost > 0.75 * round_state.pot

            # Fold condition: weak hand vs. bet that we don't have the odds to call
            if adjusted_strength < pot_odds:
                # Exception: call with decent draws if the bet is not too large
                is_drawing_hand = self.hand_strength > 0.3 and round_state.round != 'River'
                if is_drawing_hand and not is_large_bet:
                    # priced in to call with a draw
                    return self._get_call_or_all_in(call_cost, remaining_chips)
                return PokerAction.FOLD, 0

            # Raise condition: very strong hand, raise for value
            if adjusted_strength > 0.8 and adjusted_strength > pot_odds + 0.2:
                # Raise to 2x-3x the current bet
                raise_total = int(2.5 * round_state.current_bet)
                
                min_legal_raise_total = round_state.current_bet + round_state.min_raise
                raise_total = max(raise_total, min_legal_raise_total)
                
                # Ensure raise is valid and we have enough chips
                if raise_total >= remaining_chips + my_bet:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_total

            # Call condition: default action if not folding or raising
            return self._get_call_or_all_in(call_cost, remaining_chips)

    def _get_call_or_all_in(self, call_cost: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Helper to decide between call and all-in if not enough chips. """
        is_all_in = call_cost >= remaining_chips
        return (PokerAction.ALL_IN, 0) if is_all_in else (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each hand. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the entire game simulation. """
        # Reset for next game if any
        self.hole_cards = []

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """ Parses a card string like 'As' into (rank, suit). """
        rank = card_str[:-1]
        suit = card_str[-1]
        return RANK_MAP[rank], suit

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Calculates a value from 0 (terrible) to 1.0 (nuts) for the current hand. """
        if not hole_cards:
            return 0.0

        # Pre-flop hand strength (based on Chen formula)
        if not community_cards:
            card1, card2 = self._parse_card(hole_cards[0]), self._parsecard(hole_cards[1])
            rank1, suit1 = card1
            rank2, suit2 = card2
            
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            
            # Score highest card
            if high_rank == 14: score = 10
            elif high_rank == 13: score = 8
            elif high_rank == 12: score = 7
            elif high-rank == 11: score = 6
            else: score = high_rank / 2.0

            # Pairs
            if rank1 == rank2:
                score *= 2
                if score < 5: score = 5
            
            # Suited
            if suit1 == suit2:
                score += 2
            
            # Gaps
            gap = high_rank - low_rank - 1
            if gap == 0: score += 1
            elif gap == 1: score -= 1
            elif gap == 2: score -= 2
            elif gap == 3: score -= 4
            elif gap > 3: score -= 5
            
            # Normalize to 0-1 range (max for AA is 20)
            return max(0, score) / 20.0

        # Post-flop hand strength (made hand + draw potential)
        all_cards_str = hole_cards + community_cards
        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        current_eval = self._evaluate_7_cards(all_cards)
        hand_rank = current_eval[0]
        
        # Base strength from current hand (non-linear for emphasis on strong hands)
        made_hand_strength = (hand_rank / 10.0) ** 2

        # Draw potential (on Flop and Turn)
        draw_strength = 0.0
        if len(community_cards) < 5:
            # Flush draw
            suits = [c[1] for c in all_cards]
            suit_counts = {s: suits.count(s) for s in set(suits)}
            if 4 in suit_counts.values():
                draw_strength = max(draw_strength, 0.35)  # Equity of hitting
            
            # Straight draw
            ranks = sorted(list(set(c[0] for c in all_cards)))
            if len(ranks) >= 4:
                # Open-ended
                for i in range(len(ranks) - 3):
                    if ranks[i+3] - ranks[i] == 3 and ranks[i+3] - ranks[i+1] != ranks[i+2] - ranks[i]:
                        draw_strength = max(draw_strength, 0.32) # OESD equity
                        break
                # Gutshot
                if draw_strength < 0.1:
                    for i in range(len(ranks) - 3):
                        if ranks[i+3] - ranks[i] == 4:
                            draw_strength = max(draw_strength, 0.16) # Gutshot equity
                            break
        
        return min(1.0, made_hand_strength + draw_strength)

    def _evaluate_7_cards(self, cards: List[Tuple[int, str]]) -> Tuple[int, tuple]:
        """ Finds the best 5-card hand from a list of 7 cards. """
        best_hand = (0, (0,))
        for hand_5 in itertools.combinations(cards, 5):
            current_hand = self._evaluate_5_cards(list(hand_5))
            if current_hand[0] > best_hand[0]:
                best_hand = current_hand
            elif current_hand[0] == best_hand[0] and current_hand[1] > best_hand[1]:
                best_hand = current_hand
        return best_hand

    def _evaluate_5_cards(self, hand: List[Tuple[int, str]]) -> Tuple[int, tuple]:
        """ Evaluates a 5-card hand and returns its rank and tie-breaking values. """
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1]for c in hand]
        
        is_flush = len(set(suits)) == 1
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        is_straight = len(unique_ranks) == 5 and (unique_ranks[0] - unique_ranks[4] == 4)
        is_ace_low_straight = unique_ranks == [14, 5, 4, 3, 2]
        
        if is_straight or is_ace_low_straight:
            straight_high = 5 if is_ace_low_straight else unique_ranks[0]
            if is_flush:
                return (ROYAL_FLUSH, (straight_high,)) if straight_high == 14 else (STRAIGHT_FLUSH, (straight_high,))
        
        rank_counts = {r: ranks.count(r) for r in unique_ranks}
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4:
            four_rank = next(r for r,c in rank_counts.items() if c == 4)
            kicker = next(r for r,c in rank_counts.items() if c == 1)
            return (FOUR_OF_A_KIND, (four_rank, kicker))

        if counts == [3, 2]:
            three_rank = next(r for r,c in rank_counts.items() if c == 3)
            pair_rank = next(r for r,c in rank_counts.items() if c == 2)
            return (FULL_HOUSE, (three_rank, pair_rank))

        if is_flush:
            return (FLUSH, tuple(ranks))

        if is_straight or is_ace_low_straight:
            straight_high = 5 if is_ace_low_straight else unique_ranks[0]
            return (STRAIGHT, (straight_high,))
        
        if counts[0] == 3:
            three_rank = next(r for r,c in rank_counts.items() if c == 3)
            kickers = sorted([r for r,c in rank_counts.items() if c == 1], reverse=True)
            return (THREE_OF_A_KIND, tuple([three_rank] + kickers))

        if counts[:2] == [2, 2]:
            pairs = sorted([r for r,c in rank_counts.items() if c == 2], reverse=True)
            kicker = next(r for r,c in rank_counts.items() if c == 1)
            return (TWO_PAIR, tuple(pairs + [kicker]))

        if counts[0] == 2:
            pair_rank = next(r for r,c in rank_counts.items() if c == 2)
            kickers = sorted([r for r,c in rank_counts.items() if c == 1], reverse=True)
            return (ONE_PAIR, tuple([pair_rank] + kickers))

        return (HIGH_CARD, tuple(ranks))