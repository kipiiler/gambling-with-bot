import collections
import itertools
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Constants for Card and Hand Evaluation ---
_RANKS_STR = '23456789TJQKA'
_RANK_MAP = {rank: i for i, rank in enumerate(_RANKS_STR, 2)}

class SimplePlayer(Bot):
    """
    A poker bot that implements a tight-aggressive (TAG) strategy.
    - Pre-flop: Uses a hand tier system to make decisions based on card strength and position.
    - Post-flop: Evaluates hand strength, draws, and pot odds to decide whether to bet for value,
      semi-bluff, call, or fold.
    - Risk Management: Plays conservatively, avoids unnecessary risks, and aims for long-term profit.
    """
    def __init__(self):
        super().__init__()
        self.hand = []
        self.i_raised_preflop = False
        self.player_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the game."""
        self.player_count = len(all_players)
        self.hand = self._parse_hand(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of a new betting round."""
        # Reset per-hand state
        if round_state.round == 'Preflop':
            self.i_raised_preflop = False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of a betting round."""
        pass # Can be used for opponent modeling in future versions

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass

    # --- Main Action Logic ---
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the core of the bot. It decides what action to take.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet

        # If the cost to call is more than our remaining chips, it's an all-in decision.
        if to_call >= remaining_chips:
            return self._handle_forced_all_in(round_state, remaining_chips)

        if round_state.round == 'Preflop':
            action, amount = self._get_preflop_action(round_state, remaining_chips, to_call)
        else:
            action, amount = self._get_postflop_action(round_state, remaining_chips, to_call)

        # Before returning, validate the action to prevent errors.
        return self._validate_action(action, amount, to_call, remaining_chips, round_state)


    # --- Pre-flop Strategy ---
    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        hand_tier = self._get_preflop_tier(self.hand)
        active_players = self._count_active_players(round_state)
        position = self._get_position(round_state, active_players)
        
        # In pre-flop, BB is min_raise.
        big_blind_amount = round_state.min_raise
        stack_to_bb = remaining_chips / (big_blind_amount + 1e-9)

        # Push/Fold strategy if short-stacked
        if stack_to_bb < 15:
            if hand_tier <= 3 or (hand_tier == 4 and position != 'early'):
                return PokerAction.ALL_IN, 0
            else:
                return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

        is_raised = to_call > big_blind_amount

        # Decision based on hand tier, position, and if there has been a raise
        if is_raised: # Someone has raised
            if hand_tier <= 2: # Premium hands (AA, KK, QQ, AK, AQs)
                # 3-bet
                self.i_raised_preflop = True
                raise_amount = to_call + round_state.pot
                return PokerAction.RAISE, int(raise_amount)
            elif hand_tier <= 4:
                # Call if the raise is not too expensive
                if to_call < remaining_chips * 0.15:
                    return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else: # No raise yet
            raise_amount = big_blind_amount * 3
            if position == 'early':
                if hand_tier <= 3:
                    self.i_raised_preflop = True
                    return PokerAction.RAISE, int(raise_amount)
            elif position == 'mid':
                if hand_tier <= 4: 
                    self.i_raised_preflop = True
                    return PokerAction.RAISE, int(raise_amount)
                elif hand_tier == 5: return PokerAction.CALL, 0
            elif position == 'late':
                if hand_tier <= 5: 
                    self.i_raised_preflop = True
                    return PokerAction.RAISE, int(raise_amount)
        
        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)


    # --- Post-flop Strategy ---
    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        pot = round_state.pot
        hand_eval = self._evaluate_hand(self.hand, round_state.community_cards)
        hand_rank_id = hand_eval[0]
        
        outs, is_flush_draw, is_straight_draw = self._calculate_draws(self.hand, round_state.community_cards)
        
        pot_odds = to_call / (pot + to_call + 1e-9)
        win_prob_draw = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100.0

        # 1. Monster Hand (Set or better)
        if hand_rank_id >= 4: # Trips/Set or better
            bet_size = pot * 0.75
            if to_call > 0:
                bet_size = to_call + pot * 0.9
            return PokerAction.RAISE, int(bet_size)

        # 2. Strong Made Hand (Two Pair, Top Pair Good Kicker)
        if hand_rank_id == 3: # Two pair
            bet_size = pot * 0.6
            if to_call > 0:
                if to_call < pot * 0.5: return PokerAction.RAISE, int(to_call * 2.5)
                return PokerAction.CALL, 0
            return PokerAction.RAISE, int(bet_size)

        if hand_rank_id == 2: # One Pair
            board_ranks = [_RANK_MAP[c[0]] for c in round_state.community_cards]
            pair_rank = hand_eval[1]
            if pair_rank >= max(board_ranks or [0]):
                bet_size = pot * 0.5
                if to_call > 0:
                    if to_call < remaining_chips * 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                return PokerAction.RAISE, int(bet_size)
        
        # 3. Strong Draw (Flush or Open-ended Straight)
        if outs >= 8:
            if to_call > 0:
                if win_prob_draw > pot_odds:
                    return PokerAction.CALL, 0
            else: # Semi-bluff
                return PokerAction.RAISE, int(pot * 0.5)

        # 4. C-Bet logic
        if self.i_raised_preflop and to_call == 0 and round_state.round == 'Flop':
            # C-bet with a wide range, including draws and air
            if hand_rank_id > 0 or outs > 0: # C-bet with any piece or draw
                 return PokerAction.RAISE, int(pot * 0.4)

        # 5. Weak Hand / Air
        if to_call > 0:
            return PokerAction.FOLD, 0
        else:
            return PokerAction.CHECK, 0

    # --- Helper methods ---

    def _validate_action(self, action: PokerAction, amount: int, to_call: int, remaining_chips: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        """Ensures the chosen action is valid, preventing automatic folds."""
        if action == PokerAction.RAISE:
            if remaining_chips <= to_call:
                return PokerAction.CALL, 0
            
            # The amount for RAISE is the amount to raise BY
            raise_amount = amount
            
            # Ensure raise is valid
            min_raise, max_raise = round_state.min_raise, remaining_chips - to_call
            
            # Clamp raise amount
            final_raise_amount = max(min_raise, raise_amount)
            final_raise_amount = min(max_raise, final_raise_amount)

            if to_call + final_raise_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            
            if final_raise_amount < min_raise :
                 if to_call > 0: return PokerAction.CALL, 0
                 else: return PokerAction.CHECK, 0

            return PokerAction.RAISE, int(final_raise_amount)

        if action == PokerAction.CALL:
            if to_call == 0: return PokerAction.CHECK, 0
            if to_call >= remaining_chips: return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        if action == PokerAction.CHECK:
            return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)
        
        if action == PokerAction.ALL_IN:
            if remaining_chips <= to_call: return PokerAction.CALL, 0
            return PokerAction.ALL_IN, 0
            
        return PokerAction.FOLD, 0

    def _handle_forced_all_in(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Decide whether to call or fold when facing a bet that is all-in for us."""
        pot_odds = remaining_chips / (round_state.pot + remaining_chips + 1e-9)
        if round_state.round == 'Preflop':
            tier = self._get_preflop_tier(self.hand)
            if tier <= 4: return PokerAction.CALL, 0
        else:
            hand_eval = self._evaluate_hand(self.hand, round_state.community_cards)
            outs, _, _ = self._calculate_draws(self.hand, round_state.community_cards)
            
            # Estimate win prob vs one opponent
            win_prob = 0.0
            if hand_eval[0] >= 2: # At least a pair
                win_prob = 0.5
            elif outs > 0:
                win_prob = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100.0
            
            if win_prob > pot_odds:
                return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    @staticmethod
    def _parse_card(card_str: str) -> Tuple[int, str]:
        """'Ah' -> (14, 'h')"""
        rank = _RANK_MAP[card_str[0]]
        suit = card_str[1]
        return rank, suit

    def _parse_hand(self, player_hands: List[str]) -> List[Tuple[int, str]]:
        """['Ah', 'Kd'] -> [(14, 'h'), (13, 'd')]"""
        return [self._parse_card(c) for c in player_hands]

    @staticmethod
    def _get_preflop_tier(hand: List[Tuple[int, str]]) -> int:
        """Categorizes starting hands into tiers for easier decision making."""
        r1, s1 = hand[0]
        r2, s2 = hand[1]
        
        is_suited = s1 == s2
        is_pair = r1 == r2
        if r1 < r2: r1, r2 = r2, r1

        if is_pair:
            if r1 >= 12: return 1  # QQ+
            if r1 >= 10: return 2  # TT, JJ
            if r1 >= 7: return 3   # 77-99
            return 4               # 22-66

        if is_suited:
            if r1 >= 13: return 2   # AKs, AQs, KQs
            if r1 == 14: return 3   # Axs
            if (r1 - r2 == 1 and r2 >= 5) or r1-r2 == 2: return 4 # Suited connectors/gappers
            return 5
        
        if r1 >= 13 and r2 >= 12: return 3 # AKo, AQo, KQo
        if (r1 == 14 and r2 == 11) or (r1 == 13 and r2 == 11): return 4
        if r1 - r2 == 1 and r2 >= 9: return 5
        
        return 6

    @staticmethod
    def _get_position(round_state: RoundStateClient, active_players: int) -> str:
        """A simple heuristic for position."""
        acted_this_round = len(round_state.player_actions)
        to_act = active_players - acted_this_round
        
        if to_act <= max(1, active_players * 0.25): return 'late'
        if to_act <= active_players * 0.6: return 'mid'
        return 'early'
    
    @staticmethod
    def _count_active_players(round_state: RoundStateClient) -> int:
        """Counts players who have not folded in the hand."""
        # A simple proxy: total players minus those who folded.
        # This assumes player_actions contains all folds for the hand.
        total_players = len(round_state.player_bets)
        folded_players = sum(1 for action in round_state.player_actions.values() if action == 'Fold')
        return total_players - folded_players

    @staticmethod
    def _evaluate_hand(hole_cards: List[Tuple[int, str]], community_cards: List[str]) -> tuple:
        """
        Evaluates the best 5-card hand from 7 cards.
        Hand Rank IDs: 9=Royal, 8=SF, 7=Quads, 6=FH, 5=Flush, 4=Straight, 3=Trips, 2=TwoPair, 1=Pair, 0=HighCard
        """
        parsed_community = [SimplePlayer._parse_card(c) for c in community_cards]
        all_cards = hole_cards + parsed_community

        best_rank = (-1,)
        for combo in itertools.combinations(all_cards, 5):
            ranks = sorted([c[0] for c in combo], reverse=True)
            suits = [c[1] for c in combo]
            
            is_flush = len(set(suits)) == 1
            is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4))
            is_wheel = (ranks == [14, 5, 4, 3, 2])
            if is_wheel: is_straight = True

            rank_counts = collections.Counter(ranks)
            count_vals = sorted(rank_counts.values(), reverse=True)
            sorted_by_count = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)

            current_rank = (0,)
            if is_straight and is_flush:
                if ranks[0] == 14: current_rank = (9, 14)
                else: current_rank = (8, ranks[0])
            elif count_vals[0] == 4:
                current_rank = (7, sorted_by_count[0], sorted_by_count[1])
            elif count_vals == [3, 2]:
                current_rank = (6, sorted_by_count[0], sorted_by_count[1])
            elif is_flush:
                current_rank = (5, *ranks)
            elif is_straight:
                current_rank = (4, 5) if is_wheel else (4, ranks[0])
            elif count_vals[0] == 3:
                current_rank = (3, sorted_by_count[0], *sorted_by_count[1:])
            elif count_vals == [2, 2, 1]:
                current_rank = (2, sorted_by_count[0], sorted_by_count[1], sorted_by_count[2])
            elif count_vals[0] == 2:
                current_rank = (1, sorted_by_count[0], *sorted_by_count[1:])
            else:
                current_rank = (0, *ranks)
            
            best_rank = max(best_rank, current_rank)
        return best_rank

    @staticmethod
    def _calculate_draws(hole_cards: List, community_cards: List[str]) -> Tuple[int, bool, bool]:
        """Calculates outs for straight and flush draws."""
        parsed_community = [SimplePlayer._parse_card(c) for c in community_cards]
        all_cards = hole_cards + parsed_community
        
        suits = collections.Counter(c[1] for c in all_cards)
        is_flush_draw = any(count == 4 for count in suits.values())
        flush_draw_outs = 9 if is_flush_draw else 0
        
        all_ranks = {c[0] for c in all_cards}
        straight_draw_outs = 0
        for r_start in range(1, 11):
            needed = set(range(r_start, r_start + 5))
            have = all_ranks.intersection(needed)
            if len(have) == 4:
                missing_rank = list(needed - have)[0]
                if (missing_rank > r_start and missing_rank < r_start + 4): # Gutshot
                    straight_draw_outs += 4
                else: # Open-ended
                    straight_draw_outs += 8
        # Ace-low straight
        needed = {14, 2, 3, 4, 5}
        have = all_ranks.intersection(needed)
        if len(have) == 4:
            straight_draw_outs += 4
            
        is_straight_draw = straight_draw_outs > 0
        
        # Correct for overlapping outs (e.g. flush draw + straight draw)
        if is_flush_draw and is_straight_draw:
            suited_ranks = { c[0] for c in all_cards if c[1] == suits.most_common(1)[0][0] }
            overlap_outs = 0
            for r_start in range(1, 11):
                needed = set(range(r_start, r_start + 5))
                if len(all_ranks.intersection(needed)) == 4:
                    missing_rank = list(needed-all_ranks)[0]
                    if missing_rank in suited_ranks:
                         overlap_outs += 1
            total_outs = flush_draw_outs + straight_draw_outs - overlap_outs
        else:
            total_outs = flush_draw_outs + straight_draw_outs

        return total_outs, is_flush_draw, is_straight_draw