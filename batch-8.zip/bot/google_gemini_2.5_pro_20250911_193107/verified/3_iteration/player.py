import math
from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations

# These imports are from the game engine's provided type definitions
# and the abstract Bot class.
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Hand Evaluation Utilities ---
# These functions are self-contained and do not require external libraries.

_RANK_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
_HAND_STRENGTH = {
    "HIGH_CARD": 0, "ONE_PAIR": 1, "TWO_PAIR": 2, "THREE_OF_A_KIND": 3,
    "STRAIGHT": 4, "FLUSH": 5, "FULL_HOUSE": 6, "FOUR_OF_A_KIND": 7,
    "STRAIGHT_FLUSH": 8, "ROYAL_FLUSH": 9
}

def _evaluate_5_card_hand(hand: List[str]) -> Tuple[int, List[int]]:
    """Evaluates a 5-card hand and returns its strength and tie-breaker ranks."""
    if not hand or len(hand) != 5:
        return (0, [])

    ranks = sorted([_RANK_map[c[:-1]] for c in hand], reverse=True)
    suits = [c[-1] for c in hand]
    
    is_flush = len(set(suits)) == 1
    
    unique_ranks = sorted(list(set(ranks)), reverse=True)
    is_straight = False
    is_wheel = False
    if len(unique_ranks) >= 5:
        if unique_ranks[0] - unique_ranks[4] == 4:
            is_straight = True
        elif unique_ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            is_wheel = True

    if is_straight and is_flush:
        if is_wheel:
            return (_HAND_STRENGTH["STRAIGHT_FLUSH"], [5])
        if ranks[0] == 14:
            return (_HAND_STRENGTH["ROYAL_FLUSH"], [])
        return (_HAND_STRENGTH["STRAIGHT_FLUSH"], [ranks[0]])
    
    rank_counts = Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    
    if counts[0] == 4:
        quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (_HAND_STRENGTH["FOUR_OF_A_KIND"], [quad_rank, kicker])
    
    if counts == [3, 2]:
        trio_rank = [r for r, c in rank_counts.items() if c == 3][0]
        pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
        return (_HAND_STRENGTH["FULL_HOUSE"], [trio_rank, pair_rank])

    if is_flush:
        return (_HAND_STRENGTH["FLUSH"], ranks[:5])
        
    if is_straight:
        if is_wheel:
            return (_HAND_STRENGTH["STRAIGHT"], [5])
        return (_HAND_STRENGTH["STRAIGHT"], [ranks[0]])

    if counts[0] == 3:
        trio_rank = [r for r, c in rank_counts.items() if c == 3][0]
        kickers = sorted([r for r in ranks if r != trio_rank], reverse=True)
        return (_HAND_STRENGTH["THREE_OF_A_KIND"], [trio_rank] + kickers[:2])

    if counts == [2, 2, 1]:
        pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
        kicker = [r for r, c in rank_counts.items() if c == 1][0]
        return (_HAND_STRENGTH["TWO_PAIR"], pair_ranks + [kicker])
        
    if counts[0] == 2:
        pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
        return (_HAND_STRENGTH["ONE_PAIR"], [pair_rank] + kickers[:3])
        
    return (_HAND_STRENGTH["HIGH_CARD"], ranks[:5])

def _get_best_hand(all_cards: List[str]) -> Tuple[int, List[int]]:
    """Given a list of cards (e.g., 7), finds the best 5-card hand."""
    if len(all_cards) < 5:
        return _evaluate_5_card_hand(all_cards)
        
    best_hand_rank = (-1, [])
    for hand_combo in combinations(all_cards, 5):
        current_rank = _evaluate_5_card_hand(list(hand_combo))
        if current_rank[0] > best_hand_rank[0]:
            best_hand_rank = current_rank
        elif current_rank[0] == best_hand_rank[0]:
            for i in range(len(current_rank[1])):
                if i >= len(best_hand_rank[1]) or current_rank[1][i] > best_hand_rank[1][i]:
                    best_hand_rank = current_rank
                    break
                elif current_rank[1][i] < best_hand_rank[1][i]:
                    break
    return best_hand_rank

def _chen_formula(hole_cards: List[str]) -> float:
    """Calculates pre-flop hand strength using a simplified Chen formula."""
    card1, card2 = hole_cards[0], hole_cards[1]
    rank1, suit1 = card1[:-1], card1[-1]
    rank2, suit2 = card2[:-1], card2[-1]
    
    val1, val2 = _RANK_map[rank1], _RANK_map[rank2]
    
    high_rank_val = max(val1, val2)
    score = {14: 10, 13: 8, 12: 7, 11: 6}.get(high_rank_val, high_rank_val / 2.0)

    if val1 == val2:
        score = max(score * 2, 5)

    if suit1 == suit2:
        score += 2

    gap = abs(val1 - val2) - 1
    if gap >= 0 and val1 != val2:
        if gap == 0: score += 1
        else: score -= min(gap, 2)
        if gap >= 3: score -= 2
        
    return math.ceil(score)

def _calculate_outs(hole_cards: List[str], community_cards: List[str]) -> int:
    """Calculates the number of outs for common draws."""
    my_cards = hole_cards + community_cards
    
    suits = [c[-1] for c in my_cards]
    suit_counts = Counter(suits)
    is_flush_draw = 4 in suit_counts.values()
    
    ranks = sorted(list(set([_RANK_map[c[:-1]] for c in my_cards])))
    is_straight_draw = False
    
    if len(ranks) >= 4:
        for i in range(len(ranks) - 3):
            if ranks[i+3] - ranks[i] == 3 and ranks[i] > 1 and ranks[i+3] < 14:
                is_straight_draw = True
                break
        if {14, 2, 3, 4}.issubset(ranks):
            is_straight_draw = True

    if is_flush_draw and is_straight_draw: return 15
    if is_flush_draw: return 9
    if is_straight_draw: return 8
    
    return 0

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.all_players: List[int] = []
        self.big_blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of the simulation."""
        self.hole_cards = player_hands
        self.all_players = all_players
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of a new hand."""
        # The prompt is ambiguous about how new cards are dealt post-first hand.
        # This implementation assumes the game engine somehow updates self.hole_cards.
        # It's a critical assumption for the bot to function beyond the first hand.
        if round_state.min_raise > self.big_blind_amount * 2:
             self.big_blind_amount = round_state.min_raise / 2 if round_state.min_raise > 0 else self.big_blind_amount

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Decides the poker action for the current turn."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        if round_state.round == 'Preflop':
            chen_score = _chen_formula(self.hole_cards)
            
            if chen_score >= 8: # Strong to premium hands
                raise_amount = int(self.big_blind_amount * 3)
                if round_state.current_bet > self.big_blind_amount * 2:
                    raise_amount = int(round_state.current_bet * 2.5)

                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, round_state.max_raise)
                
                if raise_amount > 0 and raise_amount <= remaining_chips:
                    return PokerAction.RAISE, raise_amount
                
            elif chen_score >= 5: # Playable hands
                # Call if the bet isn't excessive, otherwise fold
                if amount_to_call <= self.big_blind_amount * 4:
                     if amount_to_call == 0:
                         return PokerAction.CHECK, 0
                     if amount_to_call < remaining_chips:
                         return PokerAction.CALL, 0
            
            # Default for weak hands or if facing large bets
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
        
        else: # Post-flop (Flop, Turn, River)
            all_cards = self.hole_cards + round_state.community_cards
            hand_strength, _ = _get_best_hand(all_cards)
            pot_size = round_state.pot

            # Tier 1: Strong made hands (Two Pair or better)
            if hand_strength >= _HAND_STRENGTH["TWO_PAIR"]:
                bet_amount = int(pot_size * 0.7)
                raise_amount = max(bet_amount, round_state.min_raise)
                raise_amount = min(raise_amount, remaining_chips)
                
                if raise_amount > 0 and raise_amount >= round_state.min_raise:
                    return PokerAction.RAISE, raise_amount
                if amount_to_call < remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.ALL_IN, 0

            # Tier 2: Decent made hand (One Pair)
            elif hand_strength == _HAND_STRENGTH["ONE_PAIR"]:
                if can_check:
                    return PokerAction.CHECK, 0
                # Call small bets, fold to large aggression
                if amount_to_call <= pot_size / 3:
                    if amount_to_call < remaining_chips:
                        return PokerAction.CALL, 0
                    return PokerAction.ALL_IN, 0 # Calling is all-in
                return PokerAction.FOLD, 0

            # Tier 3: Drawing hands or complete air
            else:
                outs = _calculate_outs(self.hole_cards, round_state.community_cards)
                if outs > 0: # We have a draw
                    if can_check:
                        return PokerAction.CHECK, 0
                    
                    pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9)
                    equity = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100
                    
                    if equity > pot_odds and amount_to_call < remaining_chips:
                        return PokerAction.CALL, 0
                    
                # No hand, no promising draw -> check or fold
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # Failsafe action
        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of a hand."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass