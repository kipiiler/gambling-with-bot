import itertools
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that uses hand strength evaluation and pot odds to make decisions.
    It has a distinct pre-flop strategy based on hand categories and a post-flop
    strategy that evaluates the best possible 5-card hand, including potential draws.
    """
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        # Pre-computed hand rankings for pre-flop strategy based on general starting hand charts.
        self.hand_rankings = {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs'],
            2: ['TT', 'AQs', 'AJs', 'KQs', 'AKo'],
            3: ['99', 'JTs', 'QJs', 'KJs', 'ATs', 'AQo'],
            4: ['88', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'AJo', 'KQo'],
            5: ['77', '66', '55', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 'Q9s', 'T8s', '97s', '87s', '76s', '65s', 'KJo', 'QJo', 'JTo'],
            6: ['44', '33', '22', 'K9s', 'K8s', 'K7s', 'K6s', 'K5s', 'K4s', 'K3s', 'K2s', 'Q8s', '86s', '75s', '54s', 'ATo', 'KTo', 'QTo'],
            7: ['J9o', 'T9o', '98o'],
            8: ['any other hand']
        }

    # ===============================================
    # Bot API Methods (called by the game engine)
    # ===============================================

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once at the start of a new hand.
        We assume this method is called for each new hand, not just once per simulation.
        """
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each betting round (pre-flop, flop, turn, river). """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Main decision-making function. Returns an action and an amount (if raising). """
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        can_check = call_amount == 0

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, call_amount, can_check)

        # Post-flop strategy
        else:
            return self._get_postflop_action(round_state, remaining_chips, call_amount, can_check)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of a hand. """
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called once at the end of the simulation. """
        pass

    # ===============================================
    # Strategy Helper Methods
    # ===============================================

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, can_check: bool) -> Tuple[PokerAction, int]:
        hand_category = self._get_preflop_hand_category(self.hole_cards)
        
        # Category 1-2: Premium hands. Always play, preferably by raising.
        if hand_category <= 2:
            raise_amount = 3 * round_state.min_raise if call_amount <= round_state.min_raise else 3 * round_state.current_bet
            raise_amount = int(max(raise_amount, round_state.min_raise))

            if raise_amount < remaining_chips * 0.35:
                # Ensure raise is valid and capped at max
                safe_raise = min(raise_amount, round_state.max_raise)
                if safe_raise >= round_state.min_raise:
                    return PokerAction.RAISE, safe_raise
                return PokerAction.CALL, 0
            elif call_amount < remaining_chips * 0.35:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, 0
        
        # Category 3-5: Strong and speculative hands. Playable, but cautiously.
        elif hand_category <= 5:
            # Call if the price is right (e.g., less than 5% of stack to see a flop).
            if call_amount <= remaining_chips * 0.05:
                return PokerAction.CHECK if can_check else PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        # Category 6-8: Weak hands. Fold unless checking is free.
        else:
            if can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
    
    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, can_check: bool) -> Tuple[PokerAction, int]:
        hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)
        pot_odds = call_amount / (round_state.pot + call_amount + 1e-6)

        if hand_strength >= pot_odds:
            # Very strong hands (value betting)
            if hand_strength > 0.8:
                bet_amount = int(0.75 * round_state.pot)
                if call_amount > 0: bet_amount = int(call_amount + 0.75 * (round_state.pot + call_amount))
                
                safe_raise = min(bet_amount, round_state.max_raise)
                if safe_raise >= round_state.min_raise:
                    return PokerAction.RAISE, safe_raise
                return PokerAction.ALL_IN, 0

            # Good hands (pot control / value)
            elif hand_strength > 0.5:
                if can_check:
                    bet_amount = int(0.5 * round_state.pot)
                    safe_raise = min(bet_amount, round_state.max_raise)
                    if safe_raise >= round_state.min_raise:
                        return PokerAction.RAISE, safe_raise
                return PokerAction.CALL, 0
            
            # Marginal hands / draws (play cheaply)
            else:
                return PokerAction.CHECK if can_check else PokerAction.CALL, 0
        
        else:
            return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

    # ===============================================
    # Hand Evaluation and Parsing
    # ===============================================

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """ Parses a card string like 'As' into a tuple (rank, suit), e.g., (14, 's'). """
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank_str = card[:-1]
        suit = card[-1]
        rank = rank_map.get(rank_str) or int(rank_str)
        return (rank, suit)

    def _get_preflop_hand_category(self, hole_cards: List[str]) -> int:
        """ Returns an integer category (1-8) for a pre-flop hand. """
        card1, card2 = self._parse_card(hole_cards[0]), self._parse_card(hole_cards[1])
        rank1, rank2 = sorted([card1[0], card2[0]], reverse=True)
        is_suited = 's' if card1[1] == card2[1] else 'o'
        
        rank_str_map = {14: 'A', 13: 'K', 12: 'Q', 11: 'J', 10: 'T'}
        r1_str = rank_str_map.get(rank1) or str(rank1)
        r2_str = rank_str_map.get(rank2) or str(rank2)

        hand_str = f"{r1_str}{r2_str}" if rank1 == rank2 else f"{r1_str}{r2_str}{is_suited}"

        for rank, hands in self.hand_rankings.items():
            if hand_str in hands:
                return rank
        return 8

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        hand_rank, tiebreaker = self._evaluate_hand(hole_cards, community_cards)
        
        base_strength = hand_rank / 9.0
        kicker_bonus = (tiebreaker[0] / 15.0) / 9.0 if tiebreaker else 0
        strength = base_strength + kicker_bonus

        if len(community_cards) in [3, 4]:
            draw_strength = self._calculate_draw_strength(hole_cards, community_cards, hand_rank)
            strength = max(strength, draw_strength)
        
        return min(strength, 1.0)
    
    def _calculate_draw_strength(self, hole_cards: List[str], community_cards: List[str], current_hand_rank: int) -> float:
        all_cards = hole_cards + community_cards
        num_cards_to_come = 2 if len(community_cards) == 3 else 1
        
        # Flush draw
        suits = [self._parse_card(c)[1] for c in all_cards]
        suit_counts = {s: suits.count(s) for s in set(suits)}
        if 4 in suit_counts.values() and current_hand_rank < 5:
            outs = 9 # 13 cards of suit - 4 on board = 9 outs
            prob_hitting = 1 - ((47 - outs) / 47) if num_cards_to_come == 1 else 1 - (((47 - outs) / 47) * ((46 - outs) / 46))
            return prob_hitting

        # Straight draw
        ranks = sorted(list(set(self._parse_card(c)[0] for c in all_cards)))
        for i in range(len(ranks) - 3):
            is_oesd = ranks[i+3] - ranks[i] == 3
            # Check for wheel draw case (A,2,3,4)
            if not is_oesd and set(ranks[i:i+4]) == {2,3,4,5}:
                 is_oesd = True # A is an out
            
            if is_oesd and current_hand_rank < 4:
                outs = 8
                prob_hitting = 1 - ((47 - outs) / 47) if num_cards_to_come == 1 else 1 - (((47 - outs) / 47) * ((46 - outs) / 46))
                return prob_hitting
        return 0.0

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        """
        Evaluates the best 5-card hand from 7 cards.
        Returns (hand_rank_int, tiebreaker_ranks_list).
        Ranks: 9=Royal, 8=SF, 7=Quads, 6=FH, 5=Flush, 4=Straight, 3=Trips, 2=2Pair, 1=Pair, 0=High
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5: return 0, []

        best_rank = -1
        best_tiebreaker = []

        for hand_tuple in itertools.combinations(all_cards, 5):
            current_rank, current_tiebreaker = self._evaluate_five_card_hand(hand_tuple)
            
            if current_rank > best_rank:
                best_rank, best_tiebreaker = current_rank, current_tiebreaker
            elif current_rank == best_rank and current_tiebreaker and best_tiebreaker:
                for i in range(len(current_tiebreaker)):
                    if current_tiebreaker[i] > best_tiebreaker[i]:
                        best_tiebreaker = current_tiebreaker
                        break
                    if current_tiebreaker[i] < best_tiebreaker[i]:
                        break
        return best_rank, best_tiebreaker

    def _evaluate_five_card_hand(self, hand: Tuple[str, ...]) -> Tuple[int, List[int]]:
        """ Helper to score a single 5-card combination. """
        parsed = sorted([self._parse_card(c) for c in hand], key=lambda x: x[0], reverse=True)
        ranks = [c[0] for c in parsed]
        suits = [c[1] for c in parsed]

        is_flush = len(set(suits)) == 1
        unique_ranks_desc = sorted(list(set(ranks)), reverse=True)
        is_straight = len(unique_ranks_desc) == 5 and (unique_ranks_desc[0] - unique_ranks_desc[4] == 4)
        is_ace_low_straight = unique_ranks_desc == [14, 5, 4, 3, 2]
        
        tiebreaker_ranks = ranks
        if is_ace_low_straight:
            is_straight = True
            tiebreaker_ranks = [5, 4, 3, 2, 1]

        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        counts = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            return (9, tiebreaker_ranks) if ranks[0] == 14 and not is_ace_low_straight else (8, tiebreaker_ranks)
        if counts[0] == 4:
            quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r in ranks if r != quad_rank]
            return 7, [quad_rank] * 4 + kicker
        if counts == [3, 2]:
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return 6, [three_rank] * 3 + [pair_rank] * 2
        if is_flush:
            return 5, ranks
        if is_straight:
            return 4, tiebreaker_ranks
        if counts[0] == 3:
            three_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)
            return 3, [three_rank] * 3 + kickers
        if counts == [2, 2, 1]:
            pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1]
            return 2, [pair_ranks[0]] * 2 + [pair_ranks[1]] * 2 + kicker
        if counts[0] == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return 1, [pair_rank] * 2 + kickers
        return 0, ranks