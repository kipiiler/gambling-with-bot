from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.current_player_hand if hasattr(round_state, 'current_player_hand') else self.hole_cards
        # If the round_state doesn't explicitly provide it at the start, rely on the on_start value
        # This can be improved if the server provides updated hole cards on round start for multi-round play

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        
        # Calculate hand strength
        strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic strategy based on hand strength and round
        if round_state.round == 'Preflop':
            if strength >= 0.8:  # Very strong starting hand (e.g., AA, KK, QQ, AKs)
                if remaining_chips > round_state.min_raise:
                    return PokerAction.RAISE, min(remaining_chips, round_state.current_bet * 3) # Aggressive pre-flop raise
                else:
                    return PokerAction.ALL_IN, 0
            elif strength >= 0.6:  # Strong starting hand (e.g., JJ, TT, AQ, 99)
                if amount_to_call == 0:  # If no bet, check or make a small raise
                    if remaining_chips > round_state.min_raise * 2 :
                        return PokerAction.RAISE, min(remaining_chips, round_state.current_bet * 2 if round_state.current_bet > 0 else self.blind_amount * 3)
                    else:
                        return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 5 : # Call smaller bets
                    return PokerAction.CALL, 0
                else: # Fold to larger bets
                    return PokerAction.FOLD, 0
            elif strength >= 0.4:  # Medium starting hand (e.g., 88, KQs, QJs)
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 10: # Call smaller bets, less willing to raise aggressively
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:  # Weak starting hand
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        else:  # Post-flop rounds (Flop, Turn, River)
            if strength >= 0.9:  # Very strong hand (e.g., Royal Flush, Straight Flush, Four of a Kind, Full House)
                if remaining_chips > round_state.min_raise:
                    return PokerAction.RAISE, min(remaining_chips, round_state.pot) # Bet the pot
                else:
                    return PokerAction.ALL_IN, 0
            elif strength >= 0.7:  # Strong hand (e.g., Flush, Straight, Three of a Kind)
                if amount_to_call == 0:
                    if remaining_chips > round_state.min_raise:
                        return PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, self.blind_amount * 2)) # Value bet
                    else:
                        return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 4:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0 # Fold to large bets if not premium hand
            elif strength >= 0.5:  # Medium hand (e.g., Two Pair, Top Pair)
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= remaining_chips / 8:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:  # Weak hand or drawing hand
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Consider folding or bluffing based on context (e.g., number of players)
                    # For a simple bot, just fold weak hands against bets
                    return PokerAction.FOLD, 0

        # Default action if no specific strategy matches (should ideally not be reached)
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif amount_to_call < remaining_chips:
            return PokerAction.CALL, 0
        else:
            return PokerAction.ALL_IN, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any per-round state if necessary
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Log final scores or perform post-game analysis
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # This is a simplified hand strength evaluation. For a real bot,
        # you'd use a more sophisticated mechanism (e.g., Monte Carlo simulations,
        # poker hand evaluators).

        # Card Ranks for numerical comparison
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0.0 # No cards to evaluate yet

        # Extract ranks and suits
        card_ranks = [ranks[card[:-1]] for card in all_cards]
        card_suits = [card[-1] for card in all_cards]
        
        # Sort ranks for easier evaluation
        card_ranks.sort(reverse=True)

        hand_strength = 0.0

        # Check for pairs, three of a kind, four of a kind
        rank_counts = {rank: card_ranks.count(rank) for rank in set(card_ranks)}
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)

        if quads:
            hand_strength = 1.0 # Highest possible without straight/royal flush considerations here
        elif trips and pairs: # Full House
            hand_strength = 0.9
        elif len(set(card_suits)) == 1 and len(all_cards) >= 5: # Assuming a flush is possible
            # This is a very rough check, doesn't ensure 5 suited cards from the best hand
            hand_strength = 0.8
        elif trips:
            hand_strength = 0.7
        elif pairs >= 2: # Two Pair
            hand_strength = 0.6
        elif pairs == 1: # One Pair
            # Consider strength of the pair (higher pair = stronger)
            for rank, count in rank_counts.items():
                if count == 2:
                    hand_strength = 0.3 + (rank / 14 * 0.2) # Scale based on card rank
                    break
        else: # High Card
            if card_ranks:
                hand_strength = card_ranks[0] / 14 * 0.1 # Very weak, scaled by highest card

        # Simple check for pre-flop strong hands
        if not community_cards and len(hole_cards) == 2:
            h1_rank = ranks[hole_cards[0][:-1]]
            h2_rank = ranks[hole_cards[1][:-1]]
            h1_suit = hole_cards[0][-1]
            h2_suit = hole_cards[1][-1]

            # Pocket pairs
            if h1_rank == h2_rank:
                if h1_rank >= 12: # AA, KK, QQ
                    hand_strength = max(hand_strength, 0.85)
                elif h1_rank >= 10: # JJ, TT
                    hand_strength = max(hand_strength, 0.75)
                else: # 22-99
                    hand_strength = max(hand_strength, 0.5 + (h1_rank / 14 * 0.2))

            # Suited connectors/broadways
            if h1_suit == h2_suit and (abs(h1_rank - h2_rank) <= 1 or (14 in [h1_rank, h2_rank] and 13 in [h1_rank, h2_rank])): # Suited A-K, K-Q, etc.
                if max(h1_rank, h2_rank) >= 12: # Suited broadways (AKs, AQs, KQs)
                    hand_strength = max(hand_strength, 0.7)
                elif max(h1_rank, h2_rank) >= 10:
                    hand_strength = max(hand_strength, 0.6) # Suited connectors like JTs, QJs
            
            # Offsuit broadways
            if (h1_rank >= 12 and h2_rank >= 10) or (h2_rank >= 12 and h1_rank >= 10): # AKo, AQo, KQo etc.
                 hand_strength = max(hand_strength, 0.6)
            
            # Any two high cards
            if max(h1_rank, h2_rank) >= 11 and min(h1_rank, h2_rank) >= 9:
                hand_strength = max(hand_strength, 0.5)

        # Ensure strength is within [0, 1]
        return min(1.0, max(0.0, hand_strength))