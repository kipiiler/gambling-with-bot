from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.player_id)] if str(self.player_id) in round_state.player_hands else []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Calculate hand strength (very basic for now)
            # Example: Pair strength, high cards
            # Higher strength means a higher willingness to bet
            hand_strength = self._calculate_preflop_strength(self.hole_cards)

            # If current_bet is 0, we can check or raise
            if current_bet_to_match == 0:
                if hand_strength >= 0.7:  # Strong hands, raise
                    return PokerAction.RAISE, min(remaining_chips, round_state.min_raise * 2) if round_state.min_raise * 2 <= remaining_chips else remaining_chips
                elif hand_strength >= 0.4:  # Medium hands, check/call
                    return PokerAction.CHECK, 0
                else:  # Weak hands, check/fold
                    return PokerAction.CHECK, 0
            else: # If there's a bet to call
                if current_bet_to_match >= remaining_chips: # All-in situation
                     return PokerAction.ALL_IN, 0
                
                # Adjust strategy based on pot odds and hand strength
                # For simplicity, if hand is strong, call or raise
                if hand_strength >= 0.6:
                    if current_bet_to_match <= self.blind_amount * 4 and round_state.min_raise <= remaining_chips: # Call small bets, raise larger with good hands
                        return PokerAction.CALL, 0
                    elif round_state.min_raise > remaining_chips:
                        return PokerAction.ALL_IN, 0 
                elif hand_strength >= 0.3 and current_bet_to_match <= self.blind_amount * 2: # Call small bets with medium hands
                    return PokerAction.CALL, 0
                else: # Fold weak hands or large bets
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            # Here, we need to evaluate hand strength considering community cards
            # This is a placeholder for a more sophisticated hand evaluation.
            # Convert cards to a format suitable for evaluation
            all_cards = self.hole_cards + round_state.community_cards
            
            # Simple heuristic: Check for pairs or draws
            hand_value = self._evaluate_hand_postflop(self.hole_cards, round_state.community_cards)

            if current_bet_to_match >= remaining_chips: # All-in situation
                return PokerAction.ALL_IN, 0

            if hand_value >= 0.8: # Very strong hand (e.g., two pair, trips, straight/flush draws often completed)
                if round_state.current_bet == 0: # If no bet, raise significantly
                    return PokerAction.RAISE, min(remaining_chips, round_state.min_raise * 3) if round_state.min_raise * 3 <= remaining_chips else remaining_chips
                else: # If there's a bet, re-raise or call
                    if round_state.current_bet + round_state.min_raise <= remaining_chips:
                        return PokerAction.RAISE, round_state.current_bet + round_state.min_raise if round_state.current_bet + round_state.min_raise <= remaining_chips else remaining_chips
                    else:
                        return PokerAction.ALL_IN, 0 # Go all-in if cannot raise a specified amount
            elif hand_value >= 0.5: # Medium strength hand (e.g., top pair, good draws)
                if round_state.current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    if current_bet_to_match <= remaining_chips and current_bet_to_match > 0:
                        return PokerAction.CALL, 0 if current_bet_to_match <= remaining_chips else PokerAction.ALL_IN, 0 # Call
                    else:
                        return PokerAction.CHECK, 0
            elif hand_value >= 0.2: # Weak hand with some potential (e.g., middle pair, weak draw)
                if round_state.current_bet == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match <= self.blind_amount: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Very weak hand
                if round_state.current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def _calculate_preflop_strength(self, hand: List[str]) -> float:
        if not hand or len(hand) != 2:
            return 0.0

        card_ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        rank1 = card_ranks.index(hand[0][0])
        rank2 = card_ranks.index(hand[1][0])
        suit1 = hand[0][1]
        suit2 = hand[1][1]

        strength = 0.0

        # Pair
        if rank1 == rank2:
            if rank1 >= card_ranks.index('A'): strength = 1.0  # AA
            elif rank1 >= card_ranks.index('K'): strength = 0.95 # KK
            elif rank1 >= card_ranks.index('Q'): strength = 0.90 # QQ
            elif rank1 >= card_ranks.index('J'): strength = 0.85 # JJ
            elif rank1 >= card_ranks.index('T'): strength = 0.80 # TT
            else: strength = 0.70 + (rank1 / 12) * 0.1 # 22-99
            
        # Suited connectors/Axs
        elif suit1 == suit2:
            if rank1 >= card_ranks.index('A') or rank2 >= card_ranks.index('A'): # Suited Ace
                strength = max(strength, 0.6 + (max(rank1,rank2) / 12) * 0.2)
            elif abs(rank1 - rank2) == 1 and max(rank1, rank2) >= card_ranks.index('T'): # Suited connectors (TJ+, QK, KJ)
                strength = max(strength, 0.5 + (max(rank1, rank2) / 12) * 0.2)
            elif abs(rank1 - rank2) <= 2: # Suited gappers
                strength = max(strength, 0.3 + (max(rank1, rank2) / 12) * 0.1)

        # High cards
        if rank1 >= card_ranks.index('T') or rank2 >= card_ranks.index('T'):
            strength = max(strength, 0.2 + (rank1 + rank2) / 24 * 0.3)
        
        return min(strength, 1.0) # Ensure strength is not > 1.0

    def _evaluate_hand_postflop(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 3: # Not enough cards to form a hand
            return 0.0

        card_ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        suits = ['s', 'h', 'd', 'c']

        # Extract ranks and suits
        ranks = [card_ranks.index(c[0]) for c in all_cards]
        suits_in_play = [c[1] for c in all_cards]

        # Count frequencies for pairs, trips, quads
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        suit_counts = {suit: suits_in_play.count(suit) for suit in set(suits_in_play)}

        strength = 0.0
        
        # Check for flushes
        for suit, count in suit_counts.items():
            if count >= 5:
                strength = max(strength, 0.9) # Flush

        # Check for straights
        sorted_ranks = sorted(list(set(ranks)))
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                strength = max(strength, 0.8) # Straight

        # Check for pairs, two pairs, three of a kind, four of a kind, full house
        pairs = 0
        trips = 0
        quads = 0
        for rank, count in rank_counts.items():
            if count == 2:
                pairs += 1
            elif count == 3:
                trips += 1
            elif count == 4:
                quads += 1
        
        if quads > 0:
            strength = max(strength, 1.0) # Four of a kind
        elif trips > 0 and pairs > 0:
            strength = max(strength, 0.95) # Full House
        elif trips > 0:
            strength = max(strength, 0.85) # Three of a kind
        elif pairs >= 2:
            strength = max(strength, 0.75) # Two Pairs
        elif pairs == 1:
            strength = max(strength, 0.6) # One Pair
        
        # Consider strong high cards if no made hand
        if strength == 0.0:
            highest_rank = max(ranks)
            if highest_rank >= card_ranks.index('A'):
                strength = max(strength, 0.15)
            elif highest_rank >= card_ranks.index('K'):
                strength = max(strength, 0.1)
                
        # Consider draws
        if strength < 0.8: # If not already a strong hand
            # Flush draw
            for suit, count in suit_counts.items():
                if count == 4:
                    strength = max(strength, 0.4) # Open-ended flush draw (4 cards)

            # Straight draw (open-ended - 4 cards in a row with gap at ends)
            consecutive_count = 0
            for i in range(len(sorted_ranks) - 1):
                if sorted_ranks[i+1] - sorted_ranks[i] == 1:
                    consecutive_count += 1
                else:
                    consecutive_count = 0
                if consecutive_count >= 3:
                    strength = max(strength, 0.35) # Open-ended straight draw
            
            # Gutshot straight draw (4 cards, gap in middle) - simple check
            if len(set(ranks)) >= 4 and strength < 0.35: # If not already open-ended or better
                temp_ranks = sorted(list(set(ranks)))
                # Check for one missing card for a straight
                for i in range(len(temp_ranks) - 3):
                    if temp_ranks[i+3] - temp_ranks[i] == 4: # e.g. 2,3,5,6 - miss 4
                        strength = max(strength, 0.25)
            
        return strength
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass