import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.blind_amount: int = 0
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.player_id: int = -1 # Store self.id after set_id is called
        self.starting_chips: int = 0

        # Card strength mapping for evaluation (simplified for basic strategy)
        self.card_ranks = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        self.rank_codes = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        self.suit_codes = ['h', 'd', 'c', 's']

    def set_id(self, player_id: int) -> None:
        """ Sets the player ID. """
        self.id = player_id
        self.player_id = player_id # Store it in internal variable for easier access

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # player_hands is a list of all hole cards for all players, not just yours.
        # The bot needs to determine its own hand based on its player_id and the order in all_players.
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Determine current player's index in all_players
        try:
            player_idx = self.all_players.index(self.player_id)
            # Each player gets 2 hole cards. So, for player_idx, cards are at 2*player_idx and 2*player_idx + 1
            if len(player_hands) > 2 * player_idx + 1:
                self.hole_cards = [player_hands[2 * player_idx], player_hands[2 * player_idx + 1]]
            else:
                self.hole_cards = [] # Should not happen in a valid game state, but for safety
        except ValueError:
            self.hole_cards = [] # Player ID not found in all_players, shouldn't happen
        except IndexError:
            self.hole_cards = [] # Not enough cards in player_hands, indicating an error in input or game state
        
        # print(f"Bot {self.player_id} on_start: hole_cards={self.hole_cards}, blind_amount={self.blind_amount}")

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Reset hole cards at the start of each round, they will be given in on_start of the game.
        # Re-fetch hole cards, if needed. This is tricky because player_hands seems to be only provided at game start.
        # The structure of `on_round_start` doesn't provide `player_hands`.
        # Assuming `on_start` provides `player_hands` for the ENTIRE game, this `hole_cards` assignment is problematic.
        # A more robust system would pass hole cards for the current round specifically.
        # For this iteration, we keep the previous on_start logic where hole_cards are set once.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        player_current_bet = round_state.player_bets.get(str(self.player_id), 0)
        amount_to_call = current_bet - player_current_bet
        
        # Ensure that remaining_chips is accurately representing stack after player_current_bet
        effective_remaining_chips = remaining_chips 

        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Avoid division by zero if all_players is empty
        num_active_players = len(round_state.current_player)
        
        # Implement a basic strategy based on hand strength and betting round
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Aggressive hands: AA, KK, QQ, AKs, AQs, TT+
            if hand_strength >= 0.8: # Strongest hands
                if amount_to_call == 0: # No bet yet or already matched
                    # Aggressively raise a good amount
                    raise_amount = min(max(min_raise * 2, self.blind_amount * 3), effective_remaining_chips)
                    if raise_amount > 0: # Ensure valid raise amount
                        return PokerAction.RAISE, raise_amount
                    elif effective_remaining_chips > 0 and current_bet == 0:
                        return PokerAction.CHECK, 0
                    elif amount_to_call > 0 and effective_remaining_chips >= amount_to_call:
                        return PokerAction.CALL, amount_to_call
                    else: # Can't raise, can't check, can't call, must fold or all-in
                        return PokerAction.ALL_IN, effective_remaining_chips if effective_remaining_chips > 0 else 0
                else: 
                    # Consider raising if opponent has already bet
                    if effective_remaining_chips >= amount_to_call + min_raise:
                        raise_amount = min(amount_to_call + min_raise * 2, effective_remaining_chips)
                        return PokerAction.RAISE, raise_amount
                    elif effective_remaining_chips >= amount_to_call: # Can only call
                        return PokerAction.CALL, amount_to_call
                    else: # Can't call, all-in or fold
                        return PokerAction.ALL_IN, effective_remaining_chips if effective_remaining_chips > 0 else 0


            elif hand_strength >= 0.5: # Medium strength hands (e.g., suited connectors, Broadway cards)
                if amount_to_call == 0: # Check if possible, or make a small bet
                    if random.random() < 0.6: # 60% chance to check/bet slowly
                        return PokerAction.CHECK, 0
                    else: # Or make a small bet to test
                        bet_size = min(max(self.blind_amount, min_raise), effective_remaining_chips)
                        if bet_size > 0:
                            return PokerAction.RAISE, bet_size
                        else:
                            return PokerAction.CHECK, 0
                else: 
                    if effective_remaining_chips >= amount_to_call:
                        # Call to see the flop, or small raise if feeling confident
                        if random.random() < 0.3 and effective_remaining_chips >= amount_to_call + min_raise:
                             raise_amount = min(amount_to_call + min_raise, effective_remaining_chips)
                             return PokerAction.RAISE, raise_amount
                        else:
                             return PokerAction.CALL, amount_to_call
                    else: # Can't call, all-in or fold
                        return PokerAction.ALL_IN, effective_remaining_chips if effective_remaining_chips > 0 else 0


            else: # Weak hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Fold if there's a bet, unless it's a small blind call
                    if amount_to_call <= self.blind_amount * 0.5 and effective_remaining_chips >= amount_to_call: # Small blind situation
                        return PokerAction.CALL, amount_to_call
                    else:
                        return PokerAction.FOLD, 0
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength >= 0.8: # Strong hand (e.g., Two Pair, Trips, Straights, Flushes)
                if amount_to_call == 0:
                    # Raise for value
                    raise_amount = min(max(min_raise * 2, round_state.pot // 2), effective_remaining_chips)
                    if raise_amount > 0:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CHECK, 0
                else: # Opponent has bet
                    # Re-raise or call, depending on stack size and pot equity
                    if effective_remaining_chips >= amount_to_call + min_raise:
                        re_raise_amount = min(amount_to_call + max(min_raise, round_state.pot // 3), effective_remaining_chips)
                        return PokerAction.RAISE, re_raise_amount
                    elif effective_remaining_chips >= amount_to_call:
                        return PokerAction.CALL, amount_to_call
                    else: # Can't call, all-in or fold
                        return PokerAction.ALL_IN, effective_remaining_chips if effective_remaining_chips > 0 else 0


            elif hand_strength >= 0.5: # Medium strength hand (e.g., One pair, strong draws)
                if amount_to_call == 0:
                    # Check or make a small bet
                    if random.random() < 0.7:
                        return PokerAction.CHECK, 0
                    else:
                        bet_size = min(max(self.blind_amount, min_raise), effective_remaining_chips)
                        if bet_size > 0:
                            return PokerAction.RAISE, bet_size
                        else:
                            return PokerAction.CHECK, 0
                else:
                    if effective_remaining_chips >= amount_to_call:
                        return PokerAction.CALL, amount_to_call
                    else: # Can't call
                        return PokerAction.ALL_IN, effective_remaining_chips if effective_remaining_chips > 0 else 0

            else: # Weak hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Check/fold
                    return PokerAction.FOLD, 0
        
        # Fallback to check/fold/call if no strong action is determined
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif effective_remaining_chips >= amount_to_call:
            return PokerAction.CALL, amount_to_call
        else: # Cannot afford to call, all-in if some chips left, otherwise fold
            if effective_remaining_chips > 0:
                return PokerAction.ALL_IN, effective_remaining_chips
            return PokerAction.FOLD, 0
    

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluates the strength of the current hand.
        Returns a float between 0.0 (weakest) and 1.0 (strongest).
        This is a very simplistic evaluation. A real bot would use Monte Carlo
        simulations or more advanced poker hand evaluators.
        """
        all_cards = hole_cards + community_cards

        # Simplify cards for evaluation
        ranks = [self.card_ranks[card[0]] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Count occurrences of each rank and suit
        rank_counts = {rank: ranks.count(rank) for rank in ranks}
        suit_counts = {suit: suits.count(suit) for suit in suits}

        # Check for pairs, trips, quads
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)

        # Check for flush
        has_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straight
        sorted_ranks_unique = sorted(list(set(ranks)))
        has_straight = False
        if len(sorted_ranks_unique) >= 5:
            for i in range(len(sorted_ranks_unique) - 4):
                if sorted_ranks_unique[i+4] - sorted_ranks_unique[i] == 4:
                    has_straight = True
                    break
            # Check for A-5 straight (Ace, 2, 3, 4, 5)
            if 14 in sorted_ranks_unique and 2 in sorted_ranks_unique and \
               3 in sorted_ranks_unique and 4 in sorted_ranks_unique and \
               5 in sorted_ranks_unique:
                has_straight = True

        # Assign strength based on hand type (simplified)
        if quads: return 1.0
        if trips and pairs >= 1: return 0.95 # Full House
        if has_flush: return 0.9
        if has_straight: return 0.85
        if trips: return 0.8
        if pairs >= 2: return 0.7 # Two Pair
        if pairs == 1: return 0.5
        
        # High card check for pre-flop or very weak hands
        if not community_cards and len(hole_cards) == 2:
            rank1 = self.card_ranks[hole_cards[0][0]]
            rank2 = self.card_ranks[hole_cards[1][0]]
            
            if rank1 >= 14 or rank2 >= 14: # At least one Ace
                if rank1 >= 13 or rank2 >= 13: # AK, AQ, AJ
                    return 0.7
                return 0.6 # Ace-X
            if rank1 >= 13 and rank2 >= 13: # KK, QQ, JJ, TT
                return 0.75
            if abs(rank1 - rank2) <= 1 and rank1 > 7 and rank2 > 7: # Suited connectors, good broadway
                if hole_cards[0][1] == hole_cards[1][1]: # Suited
                    return 0.6
                return 0.55
            
            return max(rank1, rank2) / 14.0 * 0.4 # General high card value
            

        return max(ranks) / 14.0 * 0.3 # Default for high card or unmade hands


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: Log results, adapt strategy.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: Analyze overall performance.
        pass