from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.my_player_id: int = -1
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.all_players: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        # player_hands will only contain the bot's own hole cards
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # Set my_player_id if available, otherwise it will be set by set_id
        if self.id is None:
            self.my_player_id = -1 # Placeholder, set_id will correct this

    def set_id(self, player_id: int) -> None:
        self.id = player_id
        self.my_player_id = player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the new round if they change, though typically they are set on_start
        # For simplicity, assume `self.hole_cards` is updated by the on_start method that passes `player_hands`.
        # If `on_start` is called only once at the beginning of the game, `self.hole_cards` would need to be updated here
        # based on some mechanism that passes the new hole cards.
        # As per the template, player_hands is passed to on_start. Assuming this means *my* hand for this game.
        # If multiple rounds mean new hands, this needs explicit update from the server.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_round_name = round_state.round
        community_cards = round_state.community_cards
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.my_player_id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_size = round_state.pot

        # Ensure hole cards are set. If not, this is an error or a case not handled by the setup.
        if not self.hole_cards or len(self.hole_cards) != 2:
            # Fallback to a safe action if hole cards are missing
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
            
        hand_strength = self._evaluate_hand_strength(self.hole_cards, community_cards)
        
        # Determine number of active players
        num_active_players = sum(1 for player_id, _ in round_state.player_bets.items() if round_state.player_actions.get(player_id) != 'Fold')

        # Simple strategy based on hand strength and round
        if current_round_name == "Preflop":
            return self._preflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, num_active_players)
        elif current_round_name == "Flop":
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, num_active_players, pot_size)
        elif current_round_name == "Turn":
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, num_active_players, pot_size)
        elif current_round_name == "River":
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, num_active_players, pot_size)
        
        # Default safe action (fold, or check if no bet)
        if current_bet_to_match > 0:
            return PokerAction.FOLD, 0
        else:
            return PokerAction.CHECK, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round, as a new round means new cards
        self.hole_cards = [] 


    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _preflop_strategy(self, hand_strength: float, current_bet_to_match: int, remaining_chips: int, min_raise: int, max_raise: int, num_active_players: int) -> Tuple[PokerAction, int]:
        # Hand strength is 0-1. Higher is better.
        
        # Aggressive premium hands
        if hand_strength >= 0.85: # AA, KK, QQ, AKs
            if current_bet_to_match == 0: # Can raise or check
                if remaining_chips >= min_raise:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 4) # Open raise 4BB
                else: # Not enough to raise, only check/call/all-in
                    return PokerAction.ALL_IN, 0
            else: # Already a bet
                if current_bet_to_match < remaining_chips * 0.15 or (current_bet_to_match > remaining_chips * 0.15 and hand_strength >= 0.95): # Call small bets, or if super strong
                    if remaining_chips >= current_bet_to_match + min_raise: # Re-raise if possible
                        return PokerAction.RAISE, min(remaining_chips, current_bet_to_match + self.blind_amount * 3) # Re-raise 3BB on top of bet
                    elif remaining_chips >= current_bet_to_match:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else: # Bet is too big for conservative call
                    return PokerAction.FOLD, 0
        
        # Strong hands
        elif hand_strength >= 0.7: # JJ, TT, AQs, KQs, 99
            if current_bet_to_match == 0: # Open raise or check
                if remaining_chips >= min_raise:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 3) # Open raise 3BB
                else:
                    return PokerAction.CHECK, 0 # Not enough to raise, just check
            else: # Call or fold based on bet size
                if current_bet_to_match < remaining_chips * 0.10: # Call small bets
                    if remaining_chips >= current_bet_to_match:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

        # Medium hands
        elif hand_strength >= 0.5: # Small pairs, suited connectors, stronger aces
            if current_bet_to_match == 0:
                if num_active_players <= 3 and remaining_chips >= min_raise: # Open limp or raise if few players
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 2) # Open raise 2BB
                else:
                    return PokerAction.CHECK, 0
            else: # Call only if bet is small and pot odds are good (implied by small bet percentage)
                if current_bet_to_match < remaining_chips * 0.05:
                    if remaining_chips >= current_bet_to_match :
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Weak hands
        else: # Most other hands, fold unless free play
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
    
    def _postflop_strategy(self, hand_strength: float, current_bet_to_match: int, remaining_chips: int, min_raise: int, max_raise: int, num_active_players: int, pot_size: int) -> Tuple[PokerAction, int]:
        # Hand strength is 0-1. Higher is better.
        
        # Value thresholds for post-flop
        strong_hand_threshold = 0.8
        medium_hand_threshold = 0.6
        draw_hand_threshold = 0.4
        
        # Calculate pot odds for calling
        pot_odds_ratio = (current_bet_to_match / (pot_size + current_bet_to_match + 1e-9)) if (pot_size + current_bet_to_match) > 0 else 0
        
        # Aggressive with strong hands (made hands, strong draws)
        if hand_strength >= strong_hand_threshold:
            if current_bet_to_match == 0: # Bet for value
                bet_amount = int(pot_size * 0.75) # Bet 75% pot
                return PokerAction.RAISE, min(max(min_raise, bet_amount), remaining_chips)
            else: # Raise or call with strong hand
                if remaining_chips >= current_bet_to_match + min_raise:
                    raise_amount = int(current_bet_to_match + pot_size * 0.5) # Re-raise 50% pot on top of call
                    return PokerAction.RAISE, min(max(current_bet_to_match + min_raise, raise_amount), remaining_chips)
                elif remaining_chips >= current_bet_to_match:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0

        # With medium hands (top pair, strong second pair, good draws)
        elif hand_strength >= medium_hand_threshold:
            if current_bet_to_match == 0: # Check or small bet
                if num_active_players > 2: # Bet for value if multiway
                    bet_amount = int(pot_size * 0.5) # Bet 50% pot
                    return PokerAction.RAISE, min(max(min_raise, bet_amount), remaining_chips)
                else: # Check if heads-up
                    return PokerAction.CHECK, 0
            else: # Call if pot odds are good and bet not too high
                if pot_odds_ratio <= 0.25 and current_bet_to_match < remaining_chips * 0.3: # Call up to 25% pot odds, or 30% of stack
                    if remaining_chips >= current_bet_to_match:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
        
        # With drawing hands (flush draw, straight draw)
        elif hand_strength >= draw_hand_threshold:
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0 # Check to see next card for free
            else:
                if pot_odds_ratio <= 0.20 and current_bet_to_match < remaining_chips * 0.15: # Call small bets for draw equity
                    if remaining_chips >= current_bet_to_match:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

        # Weak hands (no pair, weak draws)
        else:
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluates the strength of the best 5-card poker hand from 7 cards (2 hole + 5 community).
        Returns a float between 0 and 1, representing the hand strength.
        0: High card (2)
        0.1: Pair (2-2)
        0.2: Two Pair (2-2-3-3)
        0.3: Three of a kind (2-2-2)
        0.4: Straight (A-5, 10-A)
        0.5: Flush (5 cards same suit)
        0.6: Full House (3-2)
        0.7: Four of a kind (4)
        0.8: Straight Flush (A-5s)
        1.0: Royal Flush (10-As)
        """
        all_cards = hole_cards + community_cards
        
        if len(all_cards) < 2: # Not enough cards to form a hand
            return 0.0

        # Helper to convert card strings to (rank, suit) tuples
        def _parse_card(card_str: str) -> Tuple[int, str]:
            rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                        'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            rank = rank_map[card_str[:-1]]
            suit = card_str[-1]
            return rank, suit

        parsed_cards = [_parse_card(c) for c in all_cards]
        
        # Get all combinations of 5 cards from the available 7
        import itertools
        best_hand_strength = 0.0
        
        for hand_combo in itertools.combinations(parsed_cards, 5):
            ranks = sorted([c[0] for c in hand_combo], reverse=True)
            suits = [c[1] for c in hand_combo]

            # Check for flushes
            is_flush = len(set(suits)) == 1

            # Check for straights
            is_straight = False
            # Handle A-5 straight (Ace low)
            if set(ranks) == {14, 2, 3, 4, 5}:
                is_straight = True
            else:
                sorted_ranks_unique = sorted(list(set(ranks)))
                if len(sorted_ranks_unique) >= 5:
                    for i in range(len(sorted_ranks_unique) - 4):
                        if (sorted_ranks_unique[i+1] == sorted_ranks_unique[i] + 1 and
                            sorted_ranks_unique[i+2] == sorted_ranks_unique[i+1] + 1 and
                            sorted_ranks_unique[i+3] == sorted_ranks_unique[i+2] + 1 and
                            sorted_ranks_unique[i+4] == sorted_ranks_unique[i+3] + 1):
                            is_straight = True
                            break

            # Check for specific hand types
            rank_counts: Dict[int, int] = {}
            for r in ranks:
                rank_counts[r] = rank_counts.get(r, 0) + 1

            counts = sorted(rank_counts.values(), reverse=True)
            unique_ranks = sorted(rank_counts.keys(), reverse=True)

            hand_score = 0.0
            if is_straight and is_flush:
                if set(ranks) == {10, 11, 12, 13, 14}: # Royal Flush
                    hand_score = 1.0
                else: # Straight Flush
                    hand_score = 0.8 + (max(ranks) / 140.0) # Scale by highest card in straight
            elif 4 in counts: # Four of a Kind
                hand_score = 0.7 + (unique_ranks[0] / 140.0)
            elif 3 in counts and 2 in counts: # Full House
                # Find the rank that appears 3 times and the one that appears 2 times
                three_of_kind_rank = [r for r, count in rank_counts.items() if count == 3][0]
                pair_rank = [r for r, count in rank_counts.items() if count == 2][0]
                hand_score = 0.6 + (three_of_kind_rank / 140.0) + (pair_rank / 1400.0) # Prioritize 3 of a kind
            elif is_flush: # Flush
                hand_score = 0.5 + (max(ranks) / 140.0) # Scale by highest card
            elif is_straight: # Straight
                hand_score = 0.4 + (max(ranks) / 140.0) # Scale by highest card
            elif 3 in counts: # Three of a Kind
                hand_score = 0.3 + (unique_ranks[0] / 140.0)
            elif counts.count(2) == 2: # Two Pair
                # Sort unique ranks for two pair by descending order to consider higher pair first
                pairs = sorted([r for r, count in rank_counts.items() if count == 2], reverse=True)
                kicker = [r for r in unique_ranks if r not in pairs][0] if len(unique_ranks) == 3 else 0 # Find kicker if available
                hand_score = 0.2 + (pairs[0] / 140.0) + (pairs[1] / 1400.0) + (kicker / 14000.0) # Prioritize higher pair then lower pair then kicker
            elif 2 in counts: # One Pair
                pair_rank = [r for r, count in rank_counts.items() if count == 2][0]
                remaining_ranks = sorted([r for r in unique_ranks if r != pair_rank], reverse=True)[:3] # Top 3 kickers
                kicker_score = sum(remaining_ranks) / 14.0 / 3.0 / 10.0 # Small part for kickers
                hand_score = 0.1 + (pair_rank / 140.0) + kicker_score
            else: # High Card
                hand_score = (max(ranks) / 14.0) * 0.05 # Smaller scaling for high card

            best_hand_strength = max(best_hand_strength, hand_score)
            
        return best_hand_strength