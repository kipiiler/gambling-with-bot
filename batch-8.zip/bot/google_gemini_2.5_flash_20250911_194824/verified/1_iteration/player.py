import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.hole_cards = []
        self.my_starting_chips = 0
        self.blind_amount = 0

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands are the hole cards for all players, indexed by their ID.
        # We need to find our own cards.
        for i in range(len(all_players)):
            if all_players[i] == self.player_id:
                self.hole_cards = [player_hands[i*2], player_hands[i*2 + 1]]
                break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards from round_state if provided (though it's usually on on_start per game, not round)
        # Assuming hole cards are set once by on_start and persist for the game.
        # This method is more for resetting round-specific states if needed.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_round_name = round_state.round
        community_cards = round_state.community_cards
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Determine hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, community_cards)

        # Basic strategy based on hand strength and betting round
        if current_round_name == 'Preflop':
            return self._preflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, round_state)
        elif current_round_name == 'Flop':
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, round_state)
        elif current_round_name == 'Turn':
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, round_state)
        elif current_round_name == 'River':
            return self._postflop_strategy(hand_strength, current_bet_to_match, remaining_chips, min_raise, max_raise, round_state)
        
        # Default to fold if somehow none of the above
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # This method is called at the end of each hand.
        # You can use this to clear any hand-specific state or log results.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This method is called at the very end of the competition/simulation.
        # No specific action typically needed here for game strategy.
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluates the strength of the current hand (hole cards + community cards).
        Returns a float between 0.0 (weakest) and 1.0 (strongest).
        This is a very basic implementation. A more robust bot would use Monte Carlo simulations
        or pre-calculated hand equity tables.
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2: # Not enough cards to form a hand
            return 0.0

        # Card ranking for conversion
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Function to extract rank and suit
        def get_rank_suit(card):
            return ranks[card[0]], card[1]

        parsed_cards = [get_rank_suit(card) for card in all_cards]
        
        # Count rank occurrences for pairs, trips, quads
        rank_counts = {}
        for r, _ in parsed_cards:
            rank_counts[r] = rank_counts.get(r, 0) + 1

        # Check for pairs, two pairs, trips, quads
        has_pair = False
        has_two_pair = False
        has_trips = False
        has_quads = False
        
        pair_ranks = []
        for r, count in rank_counts.items():
            if count == 2:
                has_pair = True
                pair_ranks.append(r)
            elif count == 3:
                has_trips = True
            elif count == 4:
                has_quads = True

        if len(pair_ranks) >= 2:
            has_two_pair = True
        
        # Check for flushes
        suit_counts = {}
        for _, s in parsed_cards:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        has_flush = any(count >= 5 for count in suit_counts.values())

        # Check for straights
        sorted_ranks = sorted(list(set(r for r, _ in parsed_cards)))
        has_straight = False
        if len(sorted_ranks) >= 5:
            # Handle A-5 straight (A-2-3-4-5) - A can be low
            if 14 in sorted_ranks and 2 in sorted_ranks and 3 in sorted_ranks and 4 in sorted_ranks and 5 in sorted_ranks:
                has_straight = True
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    has_straight = True
                    break
        
        # Assign strength based on poker hand rankings
        if has_quads:
            return 1.0 # Very strong
        elif has_trips and has_pair: # Full House
            return 0.9
        elif has_flush:
            # Differentiate strong flushes from weak ones if possible
            if has_straight: # Straight Flush (or Royal Flush if ranks are T-A)
                return 1.0
            return 0.8
        elif has_straight:
            return 0.7
        elif has_trips:
            return 0.6
        elif has_two_pair:
            return 0.5
        elif has_pair:
            # Consider pair rank: Higher pair is stronger
            if any(r >= ranks['T'] for r in pair_ranks): # High pair (T-A)
                return 0.4
            else: # Low pair
                return 0.3
        else: # High Card
            return max(r for r, _ in parsed_cards) / 14.0 * 0.2 + 0.05 # Scale 0-14 to 0-0.2 for high card, base 0.05

    def _preflop_strategy(self, hand_strength: float, current_bet_to_match: int, remaining_chips: int, min_raise: int, max_raise: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        # Simple preflop strategy based on hand strength and position/blind
        is_big_blind = (self.player_id == round_state.big_blind_player_id)
        is_small_blind = (self.player_id == round_state.small_blind_player_id)
        
        # Check if we are facing a raise (current_bet_to_match > 0)
        facing_raise = current_bet_to_match > 0

        # Effective stack (for all-in considerations)
        effective_stack = remaining_chips

        # If it's preflop and no one has raised yet (or only blinds posted)
        if not facing_raise:
            # Open raising strategy
            if hand_strength >= 0.7:  # Strong hands (premium pairs, suited connectors, high Aces)
                raise_amount = max(min_raise, self.blind_amount * 3) # Example: 3x Big Blind
                if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips: # If cannot afford
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif hand_strength >= 0.4: # Medium hands
                # Check if we are the big blind and no one has raised
                if is_big_blind:
                    return PokerAction.CHECK, 0 # Check from big blind, option to see flop
                
                # Otherwise, consider a smaller raise or call blind
                raise_amount = max(min_raise, self.blind_amount * 2) # Example: 2x Big Blind
                if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            else: # Weak hands
                # If we are the big blind and no one has raised, we can check for free.
                if is_big_blind:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
        else: # Facing a raise
            # Response to a raise
            if current_bet_to_match >= remaining_chips: # All-in situation for call
                if hand_strength >= 0.6: # Call or push with strong hands
                    return PokerAction.ALL_IN, 0 
                return PokerAction.FOLD, 0
            
            # Normal raise situation
            if hand_strength >= 0.8: # Very strong hands, re-raise or call
                # Consider re-raising (3-bet)
                if remaining_chips > current_bet_to_match + min_raise:
                    raise_amount = max(min_raise * 2, current_bet_to_match * 2) # 2x the raise being faced
                    if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                else: # Cannot re-raise, but strong enough to call all-in if necessary
                     return PokerAction.CALL, 0
            elif hand_strength >= 0.5: # Medium hands, call or fold depending on raise size
                # Call if the bet is not too large relative to stack
                if current_bet_to_match <= effective_stack / 4: # Example: Call if bet is <= 25% of stack
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hands, usually fold if facing a raise
                return PokerAction.FOLD, 0
    
    def _postflop_strategy(self, hand_strength: float, current_bet_to_match: int, remaining_chips: int, min_raise: int, max_raise: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        
        # Consider pot odds, but for simplicity, primarily hand strength for now.
        
        # If no one has bet yet (current_bet_to_match == 0 means previous players checked or we are first to act)
        if current_bet_to_match == 0:
            if hand_strength >= 0.7:  # Strong hands (trips+, strong draws)
                # Bet for value, typically a percentage of pot
                bet_amount = int(round_state.pot * 0.75) # 75% pot bet
                bet_amount = max(bet_amount, min_raise) # Ensure minimum raise amount
                if bet_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            elif hand_strength >= 0.5: # Medium hands (pairs, strong draws)
                # Smaller bet for value or check to control pot
                bet_amount = int(round_state.pot * 0.5) # 50% pot bet
                bet_amount = max(bet_amount, min_raise)
                if bet_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            else: # Weak hands (high card, weak draws)
                return PokerAction.CHECK, 0 # Check to see next card for free or fold if bet
        else: # Facing a bet
            if current_bet_to_match >= remaining_chips: # All-in situation for call
                if hand_strength >= 0.65: # Call all-in with sufficiently strong hand
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0

            # Normal bet situation
            if hand_strength >= 0.8: # Very strong hands
                # Re-raise for value or call if re-raise amount is too large
                if remaining_chips > current_bet_to_match + min_raise:
                    raise_amount = max(min_raise * 2, int(round_state.pot * 0.75)) # Re-raise big
                    if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            elif hand_strength >= 0.55: # Medium-strong hands
                # Call the bet
                return PokerAction.CALL, 0
            elif hand_strength >= 0.3 and current_bet_to_match <= remaining_chips * 0.15: # Weak but might call small bets
                # If the bet is small relative to stack, sometimes call even with weaker hands (e.g., for draws)
                return PokerAction.CALL, 0
            else: # Weak hands facing a significant bet
                return PokerAction.FOLD, 0