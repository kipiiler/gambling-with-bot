from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = {}
        self.position_importance = {}
        self.rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}

    def _parse_card(self, card: str):
        """Parse a card string into rank and suit."""
        if len(card) < 2:
            return 0, ''
        rank_char = card[0:-1].upper()
        suit = card[-1].lower()
        rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        try:
            rank = rank_map.get(rank_char, int(rank_char))
        except ValueError:
            rank = 0
        return rank, suit

    def _hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate hand strength based on hole cards and community cards."""
        if not hole_cards:
            return 0.0

        hole_ranks = [self._parse_card(c)[0] for c in hole_cards]
        hole_suits = [self._parse_card(c)[1] for c in hole_cards]
        all_cards = hole_cards + community_cards
        all_ranks = [self._parse_card(c)[0] for c in all_cards]
        all_suits = [self._parse_card(c)[1] for c in all_cards]

        # Sort ranks in descending order
        all_ranks = sorted([r for r in all_ranks if r > 0], reverse=True)
        rank_count = {}
        for r in all_ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        counts = list(rank_count.values())

        # Flush check
        suit_count = {}
        for s in all_suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        has_flush = any(count >= 5 for count in suit_count.values())

        # Straight check
        unique_ranks = sorted(set(all_ranks), reverse=True)
        if 14 in unique_ranks:  # Ace high
            unique_ranks.append(1)  # Add Ace as 1 for low straight
        sorted_ranks = sorted(unique_ranks, reverse=True)
        straight_count = 1
        has_straight = False
        for i in range(1, len(sorted_ranks)):
            if sorted_ranks[i-1] == sorted_ranks[i] + 1:
                straight_count += 1
                if straight_count >= 5:
                    has_straight = True
                    break
            elif sorted_ranks[i-1] != sorted_ranks[i]:
                straight_count = 1

        # High card and pair strength
        max_rank = max(hole_ranks) if hole_ranks else 0
        pair_strength = 0
        if len(hole_ranks) == 2:
            if hole_ranks[0] == hole_ranks[1]:
                pair_strength = hole_ranks[0]
            elif hole_ranks[0] > 10 or hole_ranks[1] > 10:
                pair_strength = (hole_ranks[0] + hole_ranks[1]) / 2

        # Assign hand strength score
        score = 0.0
        if has_straight and has_flush:
            score = 0.9
        elif list(rank_count.values()).count(4) >= 1:
            score = 0.8
        elif 3 in counts and 2 in counts:
            score = 0.7
        elif has_flush:
            score = 0.6
        elif has_straight:
            score = 0.5
        elif 3 in counts:
            score = 0.4
        elif counts.count(2) >= 2:
            score = 0.3
        elif 2 in counts:
            score = 0.2
        else:
            score = max_rank / 14.0 * 0.15

        # Bonus for hole card pair or high cards
        if len(hole_ranks) == 2:
            if hole_ranks[0] == hole_ranks[1]:
                score += 0.1
            elif hole_ranks[0] >= 11 or hole_ranks[1] >= 11:
                score += 0.05

        # Cap score
        return min(score, 1.0)

    def _estimate_equity(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate equity using deterministic hand strength heuristic."""
        if len(community_cards) == 0:
            # Pre-flop: use pocket pair and high card logic
            r1, r2 = [self._parse_card(c)[0] for c in hole_cards]
            if r1 == r2:
                return 0.5 + (r1 - 2) * 0.025  # Higher pairs better
            elif {r1, r2} == {14, 13}:  # AK
                return 0.45
            elif r1 >= 11 or r2 >= 11:  # At least one face card
                return 0.3
            else:
                return 0.2
        else:
            # Post-flop: use hand strength
            return self._hand_strength(hole_cards, community_cards)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # Estimate positional value: later is better
        num_players = len(all_players)
        for i, pid in enumerate(all_players):
            # Position: 0 = early, 1 = middle, 2 = late
            if pid == self.id:
                pos = i
                self.position_importance[pid] = (num_players - pos) / num_players
                break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track any per-round initialization if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands.get(str(self.id), [])
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        player_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - player_bet

        # If folded or not in hand, return fold
        if not hole_cards:
            return PokerAction.FOLD, 0

        # Estimate equity
        equity = self._estimate_equity(hole_cards, community_cards)
        position_factor = self.position_importance.get(self.id, 0.5)
        aggression_factor = 1.0 + (position_factor - 0.5)  # More aggressive in late position

        # Preflop strategy
        if round_state.round == 'Preflop':
            r1, r2 = sorted([self._parse_card(c)[0] for c in hole_cards], reverse=True)
            suited = self._parse_card(hole_cards[0])[1] == self._parse_card(hole_cards[1])[1]
            pair = r1 == r2
            connected = abs(r1 - r2) == 1
            high_cards = r1 >= 11 and r2 >= 10

            # Adjust equity for starting hand
            if pair:
                equity = 0.3 + (r1 - 2) * 0.025
            elif suited and connected and r1 <= 12:
                equity = 0.25
            elif high_cards:
                equity = 0.35
            elif suited and r1 >= 10:
                equity = 0.2
            else:
                equity = 0.1

        # Post-flop: use estimated hand strength
        else:
            equity = self._hand_strength(hole_cards, community_cards)

        # Adjust for pot odds
        pot_odds = to_call / (pot + to_call) if (pot + to_call) > 0 else 0.0
        expected_value = equity - pot_odds

        # Default action
        action = PokerAction.FOLD
        amount = 0

        # If no bet, check or raise
        if to_call == 0:
            if equity > 0.3:
                raise_amount = min(int(aggression_factor * pot * 0.7), max_raise)
                if raise_amount >= min_raise and raise_amount <= max_raise:
                    action = PokerAction.RAISE
                    amount = raise_amount
                else:
                    action = PokerAction.CHECK
            else:
                action = PokerAction.CHECK
        else:
            # Need to call or fold or re-raise
            if equity > pot_odds + 0.1:
                if equity > 0.7 and expected_value > 0.2:
                    # Strong hand: raise or all-in
                    raise_amount = min(int(pot * aggression_factor), max_raise)
                    if raise_amount >= min_raise and raise_amount > to_call:
                        action = PokerAction.RAISE
                        amount = raise_amount
                    else:
                        action = PokerAction.CALL
                elif equity > 0.4:
                    # Good hand: call or small raise
                    if expected_value > 0.05:
                        raise_amount = min(int(pot * 0.5), max_raise)
                        if raise_amount >= min_raise and raise_amount > to_call:
                            action = PokerAction.RAISE
                            amount = raise_amount
                        else:
                            action = PokerAction.CALL
                    else:
                        action = PokerAction.CALL
                else:
                    # Marginal: just call if cheap
                    if to_call <= remaining_chips * 0.1:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
            else:
                # Fold if bad equity
                action = PokerAction.FOLD

        # Always ensure all-in is valid if needed
        if action == PokerAction.RAISE and amount > max_raise:
            amount = max_raise
        if remaining_chips <= to_call:
            action = PokerAction.ALL_IN
            amount = remaining_chips

        # Safety fallback: ensure valid action
        if action == PokerAction.RAISE:
            if amount < min_raise or amount > max_raise:
                if remaining_chips > current_bet:
                    amount = max(min_raise, current_bet + 1)
                    if amount > max_raise:
                        action = PokerAction.ALL_IN
                        amount = remaining_chips
                else:
                    action = PokerAction.ALL_IN
                    amount = remaining_chips

        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update any stats or tracking here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up or logging at end of game
        pass