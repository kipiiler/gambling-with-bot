from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 10
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.is_blind_position = False
        self.position_in_hand = 0
        self.hand_strength_estimate = 0.0
        self.tight_aggressive_factor = 0.7  # Base aggression level
        self.volatility_factor = 0.1  # Reduce bluffs in early phase
        self.previous_round_action = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.previous_round_action = None
        # Estimate positional advantage
        current_player_index = self.all_players.index(self.id) if self.id in self.all_players else 0
        # Assume dealers go last; assign position roughly
        late_positions = self.all_players[-2:]  # Cutoff and Button
        mid_positions = self.all_players[2:-2] if len(self.all_players) > 4 else []
        early_positions = self.all_players[:2]
        
        if self.id in late_positions:
            self.position_in_hand = 2  # Late position
        elif self.id in mid_positions:
            self.position_in_hand = 1  # Middle
        else:
            self.position_in_hand = 0  # Early

    def _parse_card(self, card: str):
        """Return (rank, suit); rank as int: 2-14 (Ace=14)"""
        if len(card) == 2:
            r, s = card[0], card[1]
        else:
            r, s = card[0:2], card[2]  # For '10h'
        rank_map = {'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map.get(r, int(r)) if r in rank_map or r.isdigit() else int(r)
        return rank, s

    def _hand_rank(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Simplified hand strength estimator using only top pair, overpair, draw potential."""
        all_cards = hole_cards + community_cards
        ranks = [self._parse_card(c)[0] for c in all_cards]
        suits = [self._parse_card(c)[1] for c in all_cards]
        rank_count = {r: ranks.count(r) for r in set(ranks)}
        suit_count = {s: suits.count(s) for s in set(suits)}

        hole_ranks = [self._parse_card(c)[0] for c in hole_cards]
        hole_suits = [self._parse_card(c)[1] for c in hole_cards]

        # Check pairs in hand
        pocket_pair = hole_ranks[0] == hole_ranks[1]
        top_pair = any(r == max(ranks) for r in hole_ranks) if community_cards else False
        overpair = pocket_pair and hole_ranks[0] > max(ranks[2:]) if community_cards and len(hole_ranks) == 2 else False

        # Flush draw if 4 cards of same suit including hole cards
        flush_draw = any(suit_count[s] == 4 and hole_suits.count(s) >= 1 for s in suit_count)
        open_ended_straight_draw = False
        if len(ranks) >= 4:
            sorted_ranks = sorted(set(ranks))
            for i in range(len(sorted_ranks) - 3):
                if sorted_ranks[i+3] - sorted_ranks[i] == 3:
                    open_ended_straight_draw = True
                    break

        # Strength score
        strength = 0
        if pocket_pair and hole_ranks[0] >= 10:
            strength += 30
        elif overpair:
            strength += 25
        elif top_pair and hole_ranks[0] >= 10:
            strength += 20
        elif top_pair:
            strength += 15
        elif flush_draw:
            strength += 12
        elif open_ended_straight_draw:
            strength += 10
        elif pocket_pair:
            strength += 8
        elif max(hole_ranks) >= 12:  # High card T+
            strength += 5
        elif flush_draw or open_ended_straight_draw:
            strength += 6

        return strength

    def _estimate_equity(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Rough equity estimation based on hand strength and board texture."""
        if len(community_cards) == 0:  # Preflop
            r1, r2 = [self._parse_card(c)[0] for c in hole_cards]
            gap = abs(r1 - r2)
            suited = self._parse_card(hole_cards[0])[1] == self._parse_card(hole_cards[1])[1]
            pair = r1 == r2

            score = 0
            high_cards = sum(1 for r in [r1, r2] if r >= 11)  # J, Q, K, A
            if pair:
                score = 50 + r1 * 2
            elif suited and gap <= 3:
                score = 30 + (r1 + r2) + 5
            elif high_cards == 2:
                score = 25 + (r1 + r2)
            elif high_cards == 1 and suited:
                score = 20 + max(r1, r2)
            else:
                score = 10 + (r1 + r2) / 2

            return max(0.1, min(0.9, score / 100))

        else:
            base_strength = self._hand_rank(hole_cards, community_cards)
            return max(0.05, min(0.95, base_strength / 100))

    def _should_fold_preflop(self, hole_cards: List[str], position: int, call_amount: int, pot: int) -> bool:
        """Decide if should fold based on preflop strength, position, and cost."""
        r1, r2 = sorted([self._parse_card(c)[0] for c in hole_cards], reverse=True)
        suited = self._parse_card(hole_cards[0])[1] == self._parse_card(hole_cards[1])[1]
        pair = r1 == r2
        effective_stack = 10000  # Assume full stack

        # Position adjustment
        pos_mult = 1.0
        if position == 0:  # Early
            pos_mult = 0.6
        elif position == 1:  # Mid
            pos_mult = 0.8

        # Define strong hands
        if pair or r1 == 14 or (r1 >= 13 and suited) or (r1 == 12 and r2 > 9 and suited):
            return False
        if (r1 == 14 and r2 >= 9) or (r1 >= 13 and r2 >= 10 and suited):
            return False
        if suited and r1 >= 11 and r1 - r2 <= 3:
            return call_amount / effective_stack <= 0.05 * pos_mult

        # Cost to enter
        cost_ratio = call_amount / (pot + 1e-9)
        if cost_ratio > 0.5:
            return True
        if r1 < 10 and r2 < 8:
            return True
        if not suited and r1 < 12 and r2 < 10:
            return True

        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.player_hands if hasattr(self, 'player_hands') else []
        if not hole_cards:
            return PokerAction.FOLD, 0

        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - player_bet

        # Preflop logic
        if round_state.round == 'Preflop':
            if to_call == 0:
                return PokerAction.CHECK if remaining_chips > 0 else PokerAction.FOLD, 0
            if self._should_fold_preflop(hole_cards, self.position_in_hand, to_call, pot):
                return PokerAction.FOLD, 0
            equity = self._estimate_equity(hole_cards, community_cards)
            pot_odds = to_call / (pot + to_call + 1e-9)
            if equity > pot_odds * 1.2:
                if equity > 0.6 and random.random() < 0.8 and remaining_chips >= min_raise:
                    raise_amount = min(remaining_chips, max(min_raise, int(pot * 0.7)))
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Postflop: Use hand strength
        equity = self._estimate_equity(hole_cards, community_cards)
        pot_odds = to_call / (pot + to_call + 1e-9) if to_call > 0 else 0

        strong_hand = equity >= 0.5
        medium_hand = 0.3 <= equity < 0.5
        drawing_hand = equity >= 0.15 and len(community_cards) < 5 and not strong_hand and not medium_hand

        if to_call == 0:
            if strong_hand and random.random() < 0.7 and remaining_chips >= min_raise:
                raise_amount = min(remaining_chips, max(min_raise, int(pot * 0.6)))
                return PokerAction.RAISE, raise_amount
            return PokerAction.CHECK, 0

        # Fold if equity too low vs pot odds
        if equity < pot_odds * 0.9:
            return PokerAction.FOLD, 0

        # Call or raise
        if strong_hand:
            if to_call / remaining_chips > 0.4:  # Going all-in is expensive
                if random.random() < 0.4:
                    return PokerAction.ALL_IN, remaining_chips
                else:
                    return PokerAction.CALL, 0
            else:
                if random.random() < 0.6 and remaining_chips >= min_raise and pot > 0:
                    raise_factor = random.uniform(1.5, 2.5)
                    raise_amount = min(remaining_chips, max(min_raise, int(to_call * raise_factor)))
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CALL, 0
        elif medium_hand or drawing_hand:
            if to_call / remaining_chips > 0.6:
                return PokerAction.FOLD, 0
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.previous_round_action = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass