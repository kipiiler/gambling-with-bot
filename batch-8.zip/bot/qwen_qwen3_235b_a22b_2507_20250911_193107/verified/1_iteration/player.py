from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import math

class HandStrength(Enum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.my_hand = []
        self.position = 0  # 0 = early, 1 = middle, 2 = late
        self.hand_ranking_table = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        if player_hands:
            self.my_hand = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update position: late if last 2, middle if middle, early if first half
        current_player_ids = round_state.current_player
        idx = current_player_ids.index(self.id) if self.id in current_player_ids else -1
        if idx >= len(current_player_ids) - 2:
            self.position = 2  # late position
        elif idx >= len(current_player_ids) // 2:
            self.position = 1  # middle
        else:
            self.position = 0  # early

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Extract current bet and my bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            pot_size = round_state.pot

            # Determine hand strength
            hand_strength_score, best_hand_type = self.evaluate_hand_strength(
                self.my_hand, round_state.community_cards
            )
            hand_strength = self.categorize_hand_strength(hand_strength_score)

            # Determine phase of the game
            is_preflop = round_state.round == "Preflop"
            is_flop = round_state.round == "Flop"
            is_turn = round_state.round == "Turn"
            is_river = round_state.round == "River"

            # Number of active players
            active_players = len(round_state.current_player)
            in_big_blind = self.id == self.big_blind_player_id
            in_small_blind = self.id == self.small_blind_player_id

            # Preflop logic
            if is_preflop:
                prefold_threshold = 0.3
                raise_prob = 0.0
                
                if hand_strength == "strong":
                    raise_prob = 0.9
                elif hand_strength == "medium" and self.position >= 1:
                    raise_prob = 0.6
                elif hand_strength == "weak" and self.position == 2 and in_small_blind and call_amount == self.blind_amount // 2:
                    # Limp in from SB if no raise
                    raise_prob = 0.3
                elif hand_strength == "very_strong":
                    raise_prob = 1.0
                else:
                    prefold_threshold = 0.7

                if random.random() < prefold_threshold:
                    return (PokerAction.FOLD, 0)

                if raise_prob > random.random():
                    min_raise = max(round_state.min_raise, 2 * self.blind_amount)
                    raise_amount = min(min_raise, remaining_chips)
                    if remaining_chips <= raise_amount or random.random() < 0.1:
                        return (PokerAction.ALL_IN, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)

                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, remaining_chips)
                else:
                    return (PokerAction.CALL, 0)

            # Post-flop logic
            else:
                equity = self.estimate_equity(hand_strength_score, active_players, round_state)
                pot_odds = call_amount / (pot_size + call_amount + 1e-9)  # Avoid division by zero

                # Aggression factor based on strength and position
                if hand_strength == "very_strong":
                    if random.random() < 0.7 or equity > 0.7:
                        raise_amount = min(int(pot_size * 0.75), remaining_chips)
                        if raise_amount < round_state.min_raise:
                            if call_amount >= remaining_chips:
                                return (PokerAction.ALL_IN, remaining_chips)
                            return (PokerAction.CALL, 0)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        if call_amount == 0:
                            return (PokerAction.CHECK, 0)
                        elif call_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, remaining_chips)
                        else:
                            return (PokerAction.CALL, 0)

                elif hand_strength == "strong":
                    if equity >= pot_odds or random.random() < 0.5:
                        bet_size = min(int(pot_size * 0.5), remaining_chips)
                        if bet_size < round_state.min_raise:
                            if call_amount == 0:
                                return (PokerAction.CHECK, 0)
                            elif call_amount >= remaining_chips:
                                return (PokerAction.ALL_IN, remaining_chips)
                            else:
                                return (PokerAction.CALL, 0)
                        return (PokerAction.RAISE, bet_size)
                    else:
                        if call_amount == 0:
                            return (PokerAction.CHECK, 0)
                        elif call_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, remaining_chips)
                        else:
                            return (PokerAction.CALL, 0)

                elif hand_strength == "medium":
                    if equity >= pot_odds and random.random() < 0.5:
                        if call_amount == 0:
                            return (PokerAction.CHECK, 0)
                        elif call_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, remaining_chips)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        if call_amount > 0:
                            if equity * 1.5 > pot_odds and remaining_chips > call_amount * 2:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.CHECK, 0)

                else:  # weak hand
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    elif equity > pot_odds * 1.5 and random.random() < 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)

        except Exception as e:
            # On any error, fold to avoid penalties
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset or track stats if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or learning (not needed for stateless bot)
        pass

    def parse_card(self, card: str):
        """Return rank and suit from card string."""
        if len(card) == 2:
            rank, suit = card[0], card[1]
        else:
            return None, None
        return rank, suit

    def hand_rank(self, cards):
        """Convert card rank to numeric value."""
        if not cards:
            return []
        return [self.hand_ranking_table[rank] for rank, _ in cards]

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]):
        """
        Evaluate the strength of the hand.
        Returns (score, hand_type)
        Score: 0-9 scaled by kickers, hand_type: string name
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self.evaluate_preflop_hand(hole_cards)

        ranks = []
        suits = []
        for card in all_cards:
            rank, suit = self.parse_card(card)
            if rank and suit:
                ranks.append(rank)
                suits.append(suit)

        # Count frequencies
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        # Convert to sorted numeric ranks
        numeric_ranks = sorted([self.hand_ranking_table[r] for r in ranks], reverse=True)

        # Sort by frequency and rank
        pairs = []
        trips = []
        quads = []
        for r, cnt in rank_count.items():
            nr = self.hand_ranking_table[r]
            if cnt == 2:
                pairs.append(nr)
            elif cnt == 3:
                trips.append(nr)
            elif cnt == 4:
                quads.append(nr)

        pairs.sort(reverse=True)
        trips.sort(reverse=True)
        quads.sort(reverse=True)

        # Check for flush
        flush_suit = None
        for s, cnt in suit_count.items():
            if cnt >= 5:
                flush_suit = s
                break

        # Get flush cards if exists
        flush_cards = []
        if flush_suit:
            for i, s in enumerate(suits):
                if s == flush_suit:
                    flush_cards.append(numeric_ranks[i])
            flush_cards.sort(reverse=True)

        # Check for straight
        unique_ranks = sorted(set(numeric_ranks), reverse=True)
        # Add low ACE (A-5 straight)
        if 14 in unique_ranks:
            unique_ranks.append(1)

        straight_high = None
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] == unique_ranks[i+1] + 1 == unique_ranks[i+2] + 2 == unique_ranks[i+3] + 3 == unique_ranks[i+4] + 4:
                straight_high = unique_ranks[i]
                break

        # Check for straight flush
        straight_flush_high = None
        if flush_suit:
            flush_ranks_in_suit = []
            suit_cards = all_cards.copy()
            for i, card in enumerate(all_cards):
                r, s = self.parse_card(card)
                if s == flush_suit:
                    flush_ranks_in_suit.append(self.hand_ranking_table[r])
            flush_ranks_in_suit = sorted(set(flush_ranks_in_suit), reverse=True)
            if 14 in flush_ranks_in_suit:
                flush_ranks_in_suit.append(1)
            flush_ranks_in_suit.sort(reverse=True)
            for i in range(len(flush_ranks_in_suit) - 4):
                if (flush_ranks_in_suit[i] == flush_ranks_in_suit[i+1] + 1 == flush_ranks_in_suit[i+2] + 2 == 
                    flush_ranks_in_suit[i+3] + 3 == flush_ranks_in_suit[i+4] + 4):
                    straight_flush_high = flush_ranks_in_suit[i]
                    break

        # Determine hand type
        if straight_flush_high:
            if straight_flush_high == 14:
                return (9.0, "ROYAL_FLUSH")
            else:
                return (8.0 + straight_flush_high / 100, "STRAIGHT_FLUSH")

        if quads:
            kicker = max([r for r in numeric_ranks if self.card_rank_from_value(r) not in [self.rank_from_value(q) for q in quads]], default=0)
            return (7.0 + quads[0]/100 + kicker/1000, "FOUR_OF_A_KIND")

        if len(trips) >= 1 and len(pairs) >= 1:
            return (6.0 + trips[0]/100 + pairs[0]/1000, "FULL_HOUSE")
        if len(trips) >= 2:
            return (6.0 + trips[0]/100 + trips[1]/1000, "FULL_HOUSE")

        if flush_suit:
            flush_score = 5.0
            for i, r in enumerate(flush_cards[:5]):
                flush_score += r / (100 * (10 ** i))
            return (flush_score, "FLUSH")

        if straight_high:
            return (4.0 + straight_high / 100, "STRAIGHT")

        if trips:
            kickers = sorted([r for r in numeric_ranks if self.card_rank_from_value(r) != self.rank_from_value(trips[0])], reverse=True)[:2]
            score = 3.0 + trips[0]/100
            for i, k in enumerate(kickers):
                score += k / (1000 * (10 ** i))
            return (score, "THREE_OF_A_KIND")

        if len(pairs) >= 2:
            score = 2.0 + pairs[0]/100 + pairs[1]/1000
            kickers = sorted([r for r in numeric_ranks if self.card_rank_from_value(r) not in [self.rank_from_value(p) for p in pairs]], reverse=True)[:1]
            if kickers:
                score += kickers[0] / 10000
            return (score, "TWO_PAIR")

        if len(pairs) == 1:
            kickers = sorted([r for r in numeric_ranks if self.card_rank_from_value(r) != self.rank_from_value(pairs[0])], reverse=True)[:3]
            score = 1.0 + pairs[0]/100
            for i, k in enumerate(kickers):
                score += k / (1000 * (10 ** i))
            return (score, "ONE_PAIR")

        # High card
        score = 0.0
        for i, r in enumerate(numeric_ranks[:5]):
            score += r / (100 * (10 ** i))
        return (score, "HIGH_CARD")

    def rank_from_value(self, value):
        for r, v in self.hand_ranking_table.items():
            if v == value:
                return r
        return '2'

    def card_rank_from_value(self, value):
        inv = {v: k for k, v in self.hand_ranking_table.items()}
        return inv.get(value, '2')

    def evaluate_preflop_hand(self, hole_cards):
        """Very basic preflop hand strength."""
        if len(hole_cards) != 2:
            return (0.0, "HIGH_CARD")

        r1, s1 = self.parse_card(hole_cards[0])
        r2, s2 = self.parse_card(hole_cards[1])
        v1, v2 = self.hand_ranking_table[r1], self.hand_ranking_table[r2]

        high_card = max(v1, v2)
        low_card = min(v1, v2)
        suited = 1 if s1 == s2 else 0
        paired = 1 if r1 == r2 else 0

        score = 0.0
        if paired:
            score = 0.5 + high_card / 100
        else:
            # Gap between cards
            gap = high_card - low_card
            connector_bonus = 0
            if gap == 1:
                connector_bonus = 0.1
            elif gap == 2:
                connector_bonus = 0.05
            elif gap == 3:
                connector_bonus = 0.02

            score = (low_card / 100) + connector_bonus + (suited * 0.1)

            # Bonus for high cards
            if low_card >= 11:
                score += 0.1

        return (score, "PREFLOP_HAND")

    def categorize_hand_strength(self, score):
        if score >= 7.0:
            return "very_strong"
        elif score >= 3.0:
            return "strong"
        elif score >= 1.5:
            return "medium"
        else:
            return "weak"

    def estimate_equity(self, hand_score, active_players, round_state):
        """Crude equity estimate based on hand score and board texture."""
        base_equity = 0.0
        phase_multiplier = 1.0

        if round_state.round == "Flop":
            phase_multiplier = 0.8
        elif round_state.round == "Turn":
            phase_multiplier = 0.9
        elif round_state.round == "River":
            phase_multiplier = 1.0

        if hand_score >= 8.0:
            base_equity = 0.95
        elif hand_score >= 7.0:
            base_equity = 0.85
        elif hand_score >= 6.0:
            base_equity = 0.75
        elif hand_score >= 5.0:
            base_equity = 0.65
        elif hand_score >= 4.0:
            base_equity = 0.55
        elif hand_score >= 2.0:
            base_equity = 0.4
        elif hand_score >= 1.0:
            base_equity = 0.25
        else:
            base_equity = 0.1

        # Adjust for number of opponents
        opponent_penalty = 1.0
        if active_players > 2:
            opponent_penalty = 1.0 - 0.15 * (active_players - 1)

        return base_equity * phase_multiplier * opponent_penalty