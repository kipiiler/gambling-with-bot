from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_position = None
        self.current_round = None
        self.hand_strength = 0.0
        self.is_raised = False
        self.pot_odds = 0.0
        self.stack_to_pot_ratio = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.is_raised = any(
            action != "Check" and action != "Ante" and action != "Small Blind" and action != "Big Blind"
            for action in round_state.player_actions.values()
        )
        if round_state.pot > 0:
            own_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - own_bet
            if call_amount > 0:
                self.pot_odds = call_amount / (round_state.pot + call_amount + 1e-9)
            else:
                self.pot_odds = 0.0
            self.stack_to_pot_ratio = remaining_chips / (round_state.pot + 1e-9)
        else:
            self.pot_odds = 0.0
            self.stack_to_pot_ratio = 1.0

        # Estimate hand strength based on round and cards
        self.hand_strength = self.estimate_hand_strength(
            self.hole_cards, round_state.community_cards
        )

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            own_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - own_bet
            in_pot = own_bet > 0

            # Determine position relative to dealer (assuming current_player is list of active player IDs)
            players = round_state.current_player
            dealer_index = players.index(self.id) if self.id in players else -1
            position = len(players) - dealer_index if dealer_index != -1 else 0
            is_late_position = position <= 2 and len(players) > 2

            # Pre-compute valid raise range
            min_raise = max(round_state.min_raise, call_amount + 1) if call_amount > 0 else round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            # Default values
            action = PokerAction.FOLD
            amount = 0

            if self.current_round == "Preflop":
                action, amount = self.preflop_strategy(
                    round_state, remaining_chips, call_amount, in_pot, is_late_position, min_raise, max_raise
                )
            else:
                community_cards = round_state.community_cards
                hand_strength = self.estimate_hand_strength(self.hole_cards, community_cards)
                action, amount = self.postflop_strategy(
                    round_state, remaining_chips, call_amount, in_pot,
                    hand_strength, is_late_position, min_raise, max_raise
                )
            
            # Validate action
            if action == PokerAction.RAISE:
                if amount < min_raise:
                    amount = min_raise
                elif amount > max_raise:
                    amount = max_raise
                if amount <= 0:
                    action = PokerAction.CALL if call_amount > 0 else PokerAction.CHECK
                elif amount >= remaining_chips:
                    action = PokerAction.ALL_IN
            elif action == PokerAction.CALL:
                if call_amount <= 0:
                    action = PokerAction.CHECK
                elif call_amount >= remaining_chips:
                    action = PokerAction.ALL_IN
            elif action == PokerAction.ALL_IN:
                amount = remaining_chips
            elif action == PokerAction.CHECK:
                if round_state.current_bet > own_bet:
                    if call_amount >= remaining_chips:
                        action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.CALL
            elif action == PokerAction.FOLD:
                pass  # valid

            return action, amount

        except Exception as e:
            # In case of any error, default to fold to prevent crash
            return PokerAction.FOLD, 0

    def preflop_strategy(self, round_state, remaining_chips, call_amount, in_pot, is_late_position, min_raise, max_raise):
        card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        value_map = {v: k for k, v in card_ranks.items()}
        suited = self.hole_cards[0][1] == self.hole_cards[1][1]
        rank1 = card_ranks[self.hole_cards[0][0]]
        rank2 = card_ranks[self.hole_cards[1][0]]
        high_card = max(rank1, rank2)
        low_card = min(rank1, rank2)
        pair = rank1 == rank2
        connector = abs(rank1 - rank2) == 1

        # Premium hands always raise or call
        if pair and rank1 >= 10:  # TT, JJ, QQ, KK, AA
            if call_amount == 0:
                return PokerAction.RAISE, min(3 * self.blind_amount, max_raise)
            elif call_amount <= 0.5 * remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, remaining_chips
        elif (high_card == 14 and low_card >= 10) or (high_card == 13 and low_card == 12):  # AK, AQ, AJ, KQ
            if call_amount == 0:
                return PokerAction.RAISE, min(3 * self.blind_amount, max_raise)
            else:
                return PokerAction.CALL, 0
        elif pair or (high_card >= 12 and suited) or (high_card == 11 and low_card >= 9 and suited) or connector and suited:
            if call_amount == 0:
                return PokerAction.RAISE, min(3 * self.blind_amount, max_raise)
            elif call_amount <= 2 * self.blind_amount:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif is_late_position and call_amount == 2 * self.blind_amount:  # Limper pickup in late position
            return PokerAction.CALL, 0
        else:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def postflop_strategy(self, round_state, remaining_chips, call_amount, in_pot, hand_strength, is_late_position, min_raise, max_raise):
        pot_odds_threshold = 0.3
        aggression_factor = 1.0

        if hand_strength > 0.9:  # Very strong hand
            if call_amount == 0:
                bet_size = min(int(0.5 * round_state.pot), max_raise)
                if bet_size < min_raise:
                    return PokerAction.CHECK, 0
                return PokerAction.RAISE, max(min_raise, bet_size)
            elif self.pot_odds <= pot_odds_threshold or call_amount < 0.2 * remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, remaining_chips
        elif hand_strength > 0.7:  # Strong hand
            if call_amount == 0:
                bet_size = min(int(0.6 * round_state.pot), max_raise)
                if bet_size < min_raise:
                    return PokerAction.CHECK, 0
                return PokerAction.RAISE, max(min_raise, bet_size)
            else:
                return PokerAction.CALL, 0
        elif hand_strength > 0.5:  # Medium strength (draws, middle pairs)
            if call_amount == 0:
                if random.random() < 0.7:  # Occasionally check to trap
                    bet_size = min(int(0.7 * round_state.pot), max_raise)
                    if bet_size < min_raise:
                        return PokerAction.CHECK, 0
                    return PokerAction.RAISE, max(min_raise, bet_size)
                else:
                    return PokerAction.CHECK, 0
            elif self.pot_odds <= hand_strength:  # Call if odds are good
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif hand_strength > 0.3:  # Weak draw or low pair
            if call_amount == 0:
                if random.random() < 0.3:  # Occasional bluff
                    bet_size = min(int(0.5 * round_state.pot), max_raise)
                    if bet_size < min_raise:
                        return PokerAction.CHECK, 0
                    return PokerAction.RAISE, max(min_raise, bet_size)
                else:
                    return PokerAction.CHECK, 0
            elif self.pot_odds <= hand_strength and call_amount < 0.2 * remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:  # Bluffing or folding
            if not in_pot and random.random() < 0.1 and call_amount < 0.1 * remaining_chips:
                bet_size = min(int(0.8 * round_state.pot), max_raise)
                if bet_size >= min_raise:
                    return PokerAction.RAISE, bet_size
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0

        combined_cards = hole_cards + community_cards
        ranks = [card[0] for card in combined_cards]
        suits = [card[1] for card in combined_cards]

        rank_counts = {r: ranks.count(r) for r in set(ranks)}
        suit_counts = {s: suits.count(s) for s in set(suits)}

        is_flush = max(suit_counts.values()) >= 5
        rank_vals = sorted([self.card_rank(r) for r in ranks], reverse=True)
        sorted_unique_ranks = sorted(set(rank_vals), reverse=True)
        is_straight = self.has_straight(rank_vals)

        # Check hand rankings
        if is_flush and is_straight:
            high = max(r for r in rank_vals if rank_vals.count(r) == 1)
            if high == 14:
                return 1.0  # Royal flush
            else:
                return 0.95  # Straight flush
        elif 4 in rank_counts.values():
            return 0.9  # Four of a kind
        elif 3 in rank_counts.values() and 2 in rank_counts.values():
            return 0.8  # Full house
        elif is_flush:
            return 0.7  # Flush
        elif is_straight:
            return 0.6  # Straight
        elif 3 in rank_counts.values():
            return 0.5  # Three of a kind
        elif list(rank_counts.values()).count(2) >= 2:
            return 0.4  # Two pair
        elif 2 in rank_counts.values():
            pair_rank = max([self.card_rank(r) for r, c in rank_counts.items() if c == 2])
            if pair_rank >= 11:
                return 0.35  # Top pair
            elif pair_rank >= 8:
                return 0.25  # Mid pair
            else:
                return 0.2  # Low pair
        else:
            high_card = max(self.card_rank(r) for r in ranks)
            if high_card == 14:
                return 0.15
            elif high_card == 13:
                return 0.1
            else:
                return 0.05

    def card_rank(self, rank_char: str) -> int:
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return ranks.get(rank_char, 2)

    def has_straight(self, ranks: List[int]) -> bool:
        unique_ranks = sorted(set(ranks), reverse=True)
        consecutive = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i-1] == unique_ranks[i] + 1:
                consecutive += 1
                if consecutive == 5:
                    return True
            else:
                consecutive = 1
        # Special case: A-5-4-3-2
        if set([14,2,3,4,5]).issubset(set(ranks)):
            return True
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used for tracking win/loss, but not required
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Can be used for logging or analytics after game ends
        pass