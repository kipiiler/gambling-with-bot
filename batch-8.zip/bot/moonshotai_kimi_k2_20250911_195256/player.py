from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import collections

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.position = 0
        self.blind_amount = 100
        self.hand_history = []
        self.player_stats = {}
        self.tightness = 0.7
        self.aggression = 0.6
        self.stack_size = 10000
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.position = self.all_players.index(self.id) if self.id in self.all_players else 0
        self.stack_size = starting_chips
        self.player_stats = {player_id: {'vpip': 0, 'hands': 0} for player_id in all_players}
        
    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate hand strength with available information"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._preflop_strength(hole_cards)
            
        return self._evaluate_five_cards(all_cards)
        
    def _preflop_strength(self, hole_cards: List[str]) -> float:
        """Calculate preflop hand strength"""
        ranks = [card[0] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        rank_values = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,
                      '9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}
        
        card_values = sorted([rank_values[r] for r in ranks], reverse=True)
        suited = suits[0] == suits[1]
        
        # Premium hands
        if card_values[0] == card_values[1]:
            if card_values[0] >= 8:
                return 0.9
        elif suited:
            if card_values[0] >= 10 and card_values[1] >= 8:
                return 0.85
            if card_values[0] - card_values[1] <= 3:
                return 0.75
        else:
            if card_values[0] >= 10 and card_values[1] >= 10:
                return 0.7
            if card_values[0] - card_values[1] == 1 and card_values[0] >= 12:
                return 0.65
                
        return 0.3
        
    def _evaluate_five_cards(self, cards: List[str]) -> float:
        """Simple 5-card evaluation"""
        rank_values = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,
                      '9':9,'T':10,'J':11,'Q':12,'K':13,'A':14}
        
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]
        
        # Count ranks and suits
        rank_counts = collections.Counter(ranks)
        suit_counts = collections.Counter(suits)
        
        # Check for flush
        flush = len(suit_counts) == 1
        
        # Check for straight
        values = sorted([rank_values[r] for r in ranks])
        unique_values = list(set(values))
        if len(unique_values) >= 5:
            if max(unique_values) - min(unique_values) == 4:
                straight = True
            elif set(unique_values[-5:]) == {14,2,3,4,5}:
                straight = True
            else:
                straight = False
        else:
            straight = False
            
        # Calculate hand value
        if flush and straight:
            return 0.98
        elif collections.Counter(rank_counts.values())[4] == 1:
            return 0.95
        elif collections.Counter(rank_counts.values())[3] == 1 and collections.Counter(rank_counts.values())[2] == 1:
            return 0.85
        elif flush:
            return 0.8
        elif straight:
            return 0.7
        elif collections.Counter(rank_counts.values())[3] == 1:
            return 0.6
        elif list(rank_counts.values()).count(2) == 2:
            return 0.5
        elif list(rank_counts.values()).count(2) == 1:
            return 0.4
        else:
            return max(values) / 14.0
            
    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        """Calculate pot odds for calling"""
        if call_amount <= 0:
            return 1.0
        pot_size = round_state.pot
        return call_amount / (pot_size + call_amount)
        
    def _position_adjustment(self, players_left: int) -> float:
        """Adjust strategy based on position"""
        if players_left <= 2:
            return 1.2 if self.position <= 2 else 0.8
        return 1.1 if self.position <= 3 else 0.9
        
    def _calculate_bet_size(self, round_state: RoundStateClient, strength: float, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Calculate appropriate bet sizing"""
        pot_size = round_state.pot
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        if strength > 0.8:
            bet_size = min(max(pot_size * 0.8, min_raise), max_raise)
        elif strength > 0.6:
            bet_size = min(max(pot_size * 0.6, min_raise), max_raise)
        elif strength > 0.4:
            bet_size = min(max(pot_size * 0.3, min_raise), max_raise)
        else:
            return PokerAction.CHECK, 0
            
        if bet_size > remaining_chips:
            return PokerAction.ALL_IN, 0
        if bet_size < min_raise:
            return PokerAction.CALL, 0
            
        return PokerAction.RAISE, bet_size
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player"""
        
        # Get hole cards
        if not hasattr(self, 'player_hands') or not self.player_hands:
            return PokerAction.FOLD, 0
            
        hole_cards = [h for h in self.player_hands if str(self.id) in h]
        if not hole_cards or len(hole_cards) != 2:
            return PokerAction.FOLD, 0
            
        hole_cards = hole_cards[0][str(self.id)] if isinstance(hole_cards[0], dict) else [h.split(':')[1] for h in self.player_hands if str(self.id) in h]
        
        # Calculate hand strength
        community_cards = round_state.community_cards
        hand_strength = self._calculate_hand_strength(hole_cards, community_cards)
        
        # Calculate pot odds
        current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - current_bet
        pot_odds = self._calculate_pot_odds(round_state, call_amount)
        
        # Position adjustment
        active_players = [p for p in round_state.current_player if str(p) not in [k for k, v in round_state.player_actions.items() if v == 'Fold']]
        position_factor = self._position_adjustment(len(active_players))
        
        # Adjust hand strength
        adjusted_strength = hand_strength * position_factor * (1 + random.uniform(-0.1, 0.1))
        
        # Decision making
        if round_state.round == 'Preflop':
            if hand_strength < 0.3 and call_amount > 0:
                if pot_odds <= 0.2:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CALL, 0
            elif hand_strength < 0.3 and call_amount == 0:
                return PokerAction.CHECK, 0
            elif hand_strength >= 0.6:
                if call_amount > 0:
                    return self._calculate_bet_size(round_state, adjusted_strength, remaining_chips)
                else:
                    return PokerAction.RAISE, min(round_state.pot * 0.3, remaining_chips)
            else:
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                elif call_amount <= round_state.pot * 0.1:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Postflop play
        if adjusted_strength > 0.7:
            if call_amount > 0:
                return self._calculate_bet_size(round_state, adjusted_strength, remaining_chips)
            else:
                return self._calculate_bet_size(round_state, adjusted_strength, remaining_chips)
        elif adjusted_strength > 0.5:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif pot_odds <= adjusted_strength:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if call_amount > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass