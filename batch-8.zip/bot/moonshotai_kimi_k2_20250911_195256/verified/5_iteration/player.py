from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_history = []
        self.player_stats = {}
        self.tightness = 0.7
        self.aggression = 0.3
        
    def card_value(self, card):
        rank = card[0]
        values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        return values[rank]
    
    def is_suited(self, cards):
        return cards[0][1] == cards[1][1]
    
    def is_connected(self, cards):
        v1 = self.card_value(cards[0])
        v2 = self.card_value(cards[1])
        return abs(v1 - v2) <= 1
    
    def is_pair(self, cards):
        return cards[0][0] == cards[1][0]
    
    def hand_strength(self, cards):
        if not cards or len(cards) < 2:
            return 0
            
        v1 = self.card_value(cards[0])
        v2 = self.card_value(cards[1])
        
        # Premium pairs
        if self.is_pair(cards):
            if max(v1, v2) >= 10:
                return 0.85
            elif max(v1, v2) >= 7:
                return 0.65
            else:
                return 0.45
        
        # Suited cards
        if self.is_suited(cards):
            if max(v1, v2) >= 12:
                return 0.75
            elif max(v1, v2) >= 10 and self.is_connected(cards):
                return 0.7
            elif self.is_connected(cards):
                return 0.55
            else:
                return 0.25
        
        # Off-suit cards
        if self.is_connected(cards) and max(v1, v2) >= 10:
            return 0.65
        elif max(v1, v2) >= 10:
            return 0.5
        elif max(v1, v2) >= 8:
            return 0.3
        else:
            return 0.1
    
    def position_adjustment(self, round_state, cards):
        # More aggressive from later position
        active_players = len(round_state.current_player)
        if active_players > 2:
            return 0.2
        return 0.0
    
    def stack_to_pot_ratio(self, remaining_chips, pot):
        if pot == 0:
            return float('inf')
        return remaining_chips / pot
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        player_hands = [hand for hand in player_hands if hand != '']
        # Store initial state
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not round_state or not round_state.community_cards:
            return PokerAction.FOLD, 0
            
        cards = [card for card in round_state.community_cards if card and card != '']
        base_strength = self.hand_strength(cards)
        
        # Position adjustment
        pos_adjust = self.position_adjustment(round_state, cards)
        adjust_strength = base_strength + pos_adjust
        
        # Stack adjustment
        spr = self.stack_to_pot_ratio(remaining_chips, round_state.pot)
        if spr < 3 and adjust_strength < 0.5:
            return PokerAction.FOLD, 0
        
        # Current bet situation
        current_bet = round_state.current_bet
        to_call = max(0, current_bet - (round_state.player_bets.get(str(self.id), 0)))
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            if adjust_strength >= 0.8:
                # Premium hand - raise
                amount = min(3 * round_state.current_bet, remaining_chips)
                if amount > to_call:
                    return PokerAction.RAISE, amount
            elif adjust_strength >= 0.6:
                # Good hand - call or raise
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call <= round_state.min_raise:
                    return PokerAction.CALL, 0
                else:
                    # Semi-bluff raise sometimes
                    if random.random() < 0.3:
                        amount = min(2 * round_state.min_raise, remaining_chips)
                        return PokerAction.RAISE, amount
                    return PokerAction.FOLD, 0
            else:
                # Weak hand
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
        
        # Post-flop strategy
        else:
            if adjust_strength >= 0.7:
                # Strong hand - bet/raise
                amount = min(round_state.pot * 0.75, remaining_chips)
                if current_bet == 0:
                    return PokerAction.RAISE, amount
                elif to_call <= amount // 2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.RAISE, amount
            elif adjust_strength >= 0.4:
                # Medium strength - conservative
                if to_call == 0:
                    return PokerAction.CHECK, 0
                elif to_call / round_state.pot < 0.25:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hand
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Default fallback
        if to_call == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass