from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.my_cards = []
        self.fold_pct = 0.7
        self.call_pct = 0.15
        self.raise_pct = 0.15
        self.position = 0
        self.num_players = 0
        self.player_reputation = {}
        self.hands_played = 0
        self.win_percentage = 0.0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.my_cards = player_hands
        self.num_players = len(all_players)
        for player_id in all_players:
            self.player_reputation[player_id] = {'hands_played': 0, 'aggression': 0.0, 'showdown_seen': 0}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.num_players == 2:
            return self.get_heads_up_action(round_state, remaining_chips)
        else:
            return self.get_multiway_action(round_state, remaining_chips)
    
    def get_heads_up_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        hand_strength = self.evaluate_hand_strength(round_state.community_cards, self.my_cards)
        
        if current_bet == 0:
            if hand_strength > 0.6 and remaining_chips > min_raise:
                raise_amount = min(max(min_raise, int(pot * 0.7)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif hand_strength > 0.4:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            to_call = current_bet - (round_state.player_bets.get(str(self.id), 0))
            pot_odds = to_call / (pot + to_call + 1e-6)
            
            if to_call >= remaining_chips:
                if hand_strength > 0.7:
                    return PokerAction.ALL_IN, 0
                elif hand_strength > 0.3 and pot_odds < 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            if hand_strength > 0.75:
                raise_amount = min(max(min_raise, int(pot * 1.2)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif hand_strength > max(0.4, pot_odds * 2):
                return PokerAction.CALL, 0
            else:
                if random.random() < 0.1 and hand_strength > 0.2:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
    
    def get_multiway_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        hand_strength = self.evaluate_hand_strength(round_state.community_cards, self.my_cards)
        
        if round_state.round == 'Preflop':
            return self.get_preflop_action(hand_strength, round_state, remaining_chips)
        
        active_players = len([a for a in round_state.player_actions.values() if a not in ['Fold', 'All-In']])
        
        if current_bet == 0:
            if hand_strength > 0.7:
                raise_amount = min(max(min_raise, int(pot * 0.75)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif hand_strength > 0.5:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            to_call = current_bet - (round_state.player_bets.get(str(self.id), 0))
            pot_odds = to_call / (pot + to_call + 1e-6)
            
            if to_call >= remaining_chips:
                if hand_strength > 0.8 or (hand_strength > 0.6 and pot_odds < 0.35):
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            
            effective_strength = hand_strength * (1 + 0.1 / (active_players + 1e-6))
            
            if effective_strength > 0.85:
                raise_amount = min(max(min_raise, int(pot * 1.1)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif effective_strength > max(0.6, pot_odds * 2.5):
                return PokerAction.CALL, 0
            elif effective_strength > max(0.4, pot_odds * 3):
                if random.random() < 0.3:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0
    
    def get_preflop_action(self, hand_strength, round_state, remaining_chips):
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        
        card1, card2 = self.my_cards
        
        rank1 = card1[:-1]
        rank2 = card2[:-1]
        suit1 = card1[-1]
        suit2 = card2[-1]
        
        is_pocket_pair = rank1 == rank2
        is_suited = suit1 == suit2
        
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank_val1 = ranks[rank1]
        rank_val2 = ranks[rank2]
        
        high_card = max(rank_val1, rank_val2)
        low_card = min(rank_val1, rank_val2)
        gap = high_card - low_card
        
        score = 0
        
        if is_pocket_pair:
            if high_card >= 8:
                score = 0.85
            elif high_card >= 5:
                score = 0.7
            else:
                score = 0.5
        elif is_suited:
            if high_card >= 12 and gap <= 1:
                score = 0.8
            elif high_card >= 10 and gap <= 2:
                score = 0.65
            elif high_card >= 10 and gap <= 3:
                score = 0.55
            else:
                score = 0.35
        else:
            if high_card >= 12 and low_card >= 10 and gap <= 1:
                score = 0.75
            elif high_card >= 11 and low_card >= 8 and gap <= 2:
                score = 0.6
            elif high_card >= 10 and low_card >= 8:
                score = 0.5
            else:
                score = 0.2
        
        if round_state.round_num < 50:
            score *= 0.9
            
        if current_bet == 0:
            if score > 0.65:
                raise_amount = min(max(min_raise, int(pot * 0.6)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif score > 0.45:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            to_call = current_bet - (round_state.player_bets.get(str(self.id), 0))
            
            if to_call >= remaining_chips:
                if score > 0.7:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            
            if score > 0.75:
                raise_amount = min(max(min_raise, int(pot * 1.2)), remaining_chips)
                return PokerAction.RAISE, raise_amount
            elif score > 0.6 and to_call <= remaining_chips / 8:
                return PokerAction.CALL, 0
            elif score > 0.5 and to_call <= remaining_chips / 15:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
    
    def evaluate_hand_strength(self, community_cards: List[str], hole_cards: List[str]) -> float:
        if len(community_cards) < 3:
            return 0.5
            
        try:
            all_cards = community_cards + hole_cards
            return self.estimate_strength(all_cards, hole_cards)
        except:
            return 0.0
    
    def estimate_strength(self, all_cards, hole_cards):
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suits = {'h': 0, 'd': 1, 'c': 2, 's': 3}
        
        cards = []
        for card in all_cards:
            rank = card[:-1]
            suit = card[-1]
            cards.append((ranks[rank], suits[suit]))
        
        rank_counts = {}
        suit_counts = {}
        for rank, suit in cards:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        is_flush = max(suit_counts.values()) >= 5
        is_straight = self.check_straight(sorted(rank_counts.keys()))
        
        hand_rank = self.get_hand_rank(rank_counts, is_flush, is_straight)
        
        hole_rank1 = ranks[hole_cards[0][:-1]]
        hole_rank2 = ranks[hole_cards[1][:-1]]
        hole_suit1 = suits[hole_cards[0][-1]]
        hole_suit2 = suits[hole_cards[1][-1]]
        
        has_pair = hole_rank1 == hole_rank2
        has_flush_potential = hole_suit1 == hole_suit2
        has_straight_potential = abs(hole_rank1 - hole_rank2) <= 4
        
        bonus = 0.0
        if has_pair: bonus += 0.15
        if has_flush_potential: bonus += 0.1
        if has_straight_potential: bonus += 0.05
        
        score = min(0.95, hand_rank + bonus)
        
        return max(0.0, min(1.0, score))
    
    def check_straight(self, ranks):
        if len(ranks) < 5:
            return False
        unique_ranks = list(set(ranks))
        unique_ranks = sorted(unique_ranks, reverse=True)
        count = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i] == unique_ranks[i-1] - 1:
                count += 1
                if count >= 5:
                    return True
            else:
                count = 1
        
        if set([14, 5, 4, 3, 2]).issubset(set(unique_ranks)):
            return True
            
        return False
    
    def get_hand_rank(self, rank_counts, is_flush, is_straight):
        counts = sorted(rank_counts.values(), reverse=True)
        ranks = sorted([(v, k) for k, v in rank_counts.items()], key=lambda x: (-x[0], -x[1]))
        
        if is_straight and is_flush:
            return 0.9
        
        if counts[0] == 4:
            return 0.85
        
        if counts[0] == 3 and len(counts) >= 2 and counts[1] == 2:
            return 0.8
        
        if is_flush:
            return 0.75
        
        if is_straight:
            return 0.7
        
        if counts[0] == 3:
            return 0.6
        
        if counts[0] == 2 and len(counts) >= 2 and counts[1] == 2:
            return 0.5
        
        if counts[0] == 2:
            return 0.4
        
        return 0.2
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass