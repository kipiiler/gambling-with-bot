from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.hand_strength_cache = {}
        self.position = 0
        self.num_players = 0
        self.aggression_factor = 0.7
        self.tightness = 0.65
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.num_players = len(all_players)
        if self.id in all_players:
            self.position = all_players.index(self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_strength_cache = {}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        if remaining_chips <= 0:
            return (PokerAction.CHECK, 0)
            
        # Calculate pot odds
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001)
        
        # Estimate hand strength
        hand_strength = self.estimate_hand_strength(round_state)
        
        # Get number of active players
        active_players = len([p for p in round_state.current_player if p != self.id])
        
        # Position-based adjustments
        position_multiplier = 1.0 + (self.position / (self.num_players + 0.001)) * 0.2
        
        # Adjust strategy based on stack size
        stack_ratio = remaining_chips / (self.starting_chips + 0.001)
        if stack_ratio < 0.2:  # Short stack - more aggressive
            self.aggression_factor = min(0.9, self.aggression_factor + 0.2)
            self.tightness = max(0.4, self.tightness - 0.2)
        elif stack_ratio > 1.5:  # Big stack - can afford to be looser
            self.aggression_factor = 0.6
            self.tightness = 0.7
            
        # Decision making
        if round_state.round == 'Preflop':
            return self.preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, call_amount)
        else:
            return self.postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, call_amount, active_players)

    def preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, call_amount: int) -> Tuple[PokerAction, int]:
        """Preflop strategy based on hand strength and position."""
        # Premium hands
        if hand_strength > 0.85:
            if round_state.current_bet > 0:
                raise_amount = min(remaining_chips, int(round_state.pot * 3))
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            else:
                raise_amount = min(remaining_chips, self.blind_amount * 3)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                    
        # Good hands
        elif hand_strength > 0.65:
            if call_amount <= remaining_chips * 0.15:
                if random.random() < self.aggression_factor and round_state.current_bet < remaining_chips * 0.2:
                    raise_amount = min(remaining_chips, int(round_state.pot * 2.5))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
                
        # Marginal hands
        elif hand_strength > 0.45:
            if call_amount <= self.blind_amount * 2 and call_amount <= remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
                
        # Weak hands
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.FOLD, 0)

    def postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, call_amount: int, active_players: int) -> Tuple[PokerAction, int]:
        """Postflop strategy with more sophisticated decision making."""
        # Adjust hand strength for number of opponents
        adjusted_strength = hand_strength ** (active_players + 1)
        
        # Very strong hands
        if adjusted_strength > 0.8:
            if round_state.current_bet > 0:
                if remaining_chips > round_state.pot * 2:
                    raise_amount = min(remaining_chips, int(round_state.pot * 0.75))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            else:
                # Value bet
                bet_amount = min(remaining_chips, int(round_state.pot * 0.6))
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
                
        # Good hands
        elif adjusted_strength > 0.6:
            if pot_odds < adjusted_strength:
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif round_state.current_bet == 0:
                if random.random() < 0.4:  # Occasionally bet for value
                    bet_amount = min(remaining_chips, int(round_state.pot * 0.5))
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
                
        # Drawing hands or marginal hands
        elif adjusted_strength > 0.35:
            if pot_odds < adjusted_strength and call_amount <= remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
                
        # Bluff occasionally
        if round_state.current_bet == 0 and random.random() < 0.15:
            bluff_amount = min(remaining_chips, int(round_state.pot * 0.4))
            if bluff_amount >= round_state.min_raise and bluff_amount <= remaining_chips * 0.3:
                return (PokerAction.RAISE, bluff_amount)
                
        # Default actions
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.FOLD, 0)

    def estimate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Estimate hand strength based on hole cards and community cards."""
        cache_key = (tuple(self.hole_cards), tuple(round_state.community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
            
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.2
            
        card1, card2 = self.hole_cards
        rank1, suit1 = self.parse_card(card1)
        rank2, suit2 = self.parse_card(card2)
        
        # Preflop hand strength
        if len(round_state.community_cards) == 0:
            strength = self.preflop_hand_strength(rank1, rank2, suit1 == suit2)
        else:
            # Postflop - evaluate actual hand
            all_cards = self.hole_cards + round_state.community_cards
            hand_rank = self.evaluate_hand(all_cards)
            strength = self.convert_hand_rank_to_strength(hand_rank, round_state.round)
            
        self.hand_strength_cache[cache_key] = strength
        return strength

    def preflop_hand_strength(self, rank1: int, rank2: int, suited: bool) -> float:
        """Calculate preflop hand strength."""
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        # Pocket pairs
        if rank1 == rank2:
            if high_rank >= 12:  # AA, KK, QQ
                return 0.95
            elif high_rank >= 10:  # JJ, TT
                return 0.80
            elif high_rank >= 8:  # 99, 88
                return 0.70
            elif high_rank >= 6:  # 77, 66
                return 0.60
            else:
                return 0.50
                
        # High cards
        if high_rank == 14:  # Ace high
            if low_rank >= 12:  # AK, AQ
                return 0.85 if suited else 0.80
            elif low_rank >= 10:  # AJ, AT
                return 0.70 if suited else 0.65
            else:
                return 0.55 if suited else 0.50
                
        if high_rank == 13:  # King high
            if low_rank >= 11:  # KQ, KJ
                return 0.70 if suited else 0.65
            elif low_rank >= 9:  # KT, K9
                return 0.55 if suited else 0.50
            else:
                return 0.45 if suited else 0.40
                
        # Connected cards
        if abs(rank1 - rank2) == 1:
            if high_rank >= 10:
                return 0.60 if suited else 0.55
            else:
                return 0.50 if suited else 0.45
                
        # Suited cards bonus
        if suited:
            return 0.45
            
        # Default weak hand
        return 0.35

    def evaluate_hand(self, cards: List[str]) -> Tuple[int, List[int]]:
        """Evaluate the best 5-card poker hand from available cards."""
        if len(cards) < 5:
            return (0, [])
            
        parsed_cards = [self.parse_card(card) for card in cards]
        best_hand = (0, [])
        
        # Generate all 5-card combinations
        from itertools import combinations
        for combo in combinations(parsed_cards, 5):
            hand_value = self.evaluate_5_cards(list(combo))
            if hand_value > best_hand:
                best_hand = hand_value
                
        return best_hand

    def evaluate_5_cards(self, cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        """Evaluate a specific 5-card hand."""
        ranks = sorted([card[0] for card in cards], reverse=True)
        suits = [card[1] for card in cards]
        
        # Check for flush
        is_flush = len(set(suits)) == 1
        
        # Check for straight
        is_straight = self.is_straight(ranks)
        
        # Count rank frequencies
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        counts = sorted(rank_counts.values(), reverse=True)
        unique_ranks = sorted(rank_counts.keys(), key=lambda x: (rank_counts[x], x), reverse=True)
        
        # Determine hand ranking
        if is_straight and is_flush:
            if ranks == [14, 13, 12, 11, 10]:
                return (9, ranks)  # Royal flush
            return (8, ranks)  # Straight flush
        elif counts == [4, 1]:
            return (7, unique_ranks)  # Four of a kind
        elif counts == [3, 2]:
            return (6, unique_ranks)  # Full house
        elif is_flush:
            return (5, ranks)  # Flush
        elif is_straight:
            return (4, ranks)  # Straight
        elif counts == [3, 1, 1]:
            return (3, unique_ranks)  # Three of a kind
        elif counts == [2, 2, 1]:
            return (2, unique_ranks)  # Two pair
        elif counts == [2, 1, 1, 1]:
            return (1, unique_ranks)  # One pair
        else:
            return (0, ranks)  # High card

    def is_straight(self, ranks: List[int]) -> bool:
        """Check if ranks form a straight."""
        if len(set(ranks)) != 5:
            return False
            
        # Check regular straight
        if ranks[0] - ranks[4] == 4:
            return True
            
        # Check A-2-3-4-5 straight
        if ranks == [14, 5, 4, 3, 2]:
            return True
            
        return False

    def convert_hand_rank_to_strength(self, hand_rank: Tuple[int, List[int]], round_name: str) -> float:
        """Convert hand ranking to strength value between 0 and 1."""
        rank_type = hand_rank[0]
        
        # Base strength by hand type
        base_strengths = {
            9: 1.0,    # Royal flush
            8: 0.98,   # Straight flush
            7: 0.96,   # Four of a kind
            6: 0.94,   # Full house
            5: 0.90,   # Flush
            4: 0.85,   # Straight
            3: 0.75,   # Three of a kind
            2: 0.65,   # Two pair
            1: 0.50,   # One pair
            0: 0.25    # High card
        }
        
        strength = base_strengths.get(rank_type, 0.2)
        
        # Adjust for high cards within hand type
        if len(hand_rank[1]) > 0:
            high_card_bonus = hand_rank[1][0] / 140.0  # Max 0.1 bonus
            strength += high_card_bonus
            
        return min(1.0, strength)

    def parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit."""
        if len(card) < 2:
            return (2, 's')
            
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        if rank_str in rank_map:
            rank = rank_map[rank_str]
        else:
            try:
                rank = int(rank_str)
            except:
                rank = 2
                
        return (rank, suit)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass