from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.game_count = 0
        self.current_round = None
        self.starting_chips = 10000
        self.blind_amount = 10
        self.folded_this_hand = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        self.folded_this_hand = False
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.folded_this_hand = False
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current game state
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
            
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Decision logic based on hand strength and pot odds
        if to_call == 0:
            # No bet to call - we can check or bet
            if hand_strength > 0.7:
                # Strong hand - bet/raise
                bet_size = min(int(pot * 0.75), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength > 0.5:
                # Medium hand - sometimes bet
                if self.game_count % 3 == 0:  # Mix it up
                    bet_size = min(int(pot * 0.5), remaining_chips)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            if hand_strength > 0.8:
                # Very strong hand - raise
                raise_size = min(int(current_bet * 2.5), remaining_chips)
                if raise_size > current_bet and raise_size >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_size)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif hand_strength > 0.6:
                # Good hand - call
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                elif hand_strength > 0.75 and to_call < remaining_chips * 1.5:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4 and pot_odds < 0.3:
                # Decent hand with good pot odds - call
                if to_call <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Weak hand - fold
                return (PokerAction.FOLD, 0)
                
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards."""
        
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Pre-flop evaluation
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 7:  # 77-99
                    return 0.75
                else:  # 22-66
                    return 0.65
                    
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            
            # Ace high
            if high_rank == 14:
                if low_rank >= 10:  # AK, AQ, AJ, AT
                    return 0.85 if suit1 == suit2 else 0.80
                elif low_rank >= 7:  # A9-A7
                    return 0.65 if suit1 == suit2 else 0.60
                else:
                    return 0.55 if suit1 == suit2 else 0.50
                    
            # King high
            if high_rank == 13:
                if low_rank >= 10:  # KQ, KJ, KT
                    return 0.75 if suit1 == suit2 else 0.70
                else:
                    return 0.55 if suit1 == suit2 else 0.50
                    
            # Connected cards
            if abs(rank1 - rank2) == 1:
                if high_rank >= 10:
                    return 0.65 if suit1 == suit2 else 0.60
                else:
                    return 0.55 if suit1 == suit2 else 0.50
                    
            # Suited cards bonus
            if suit1 == suit2:
                return 0.45
                
            # Default
            return 0.35
            
        else:
            # Post-flop: simplified evaluation
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for pairs, trips, etc.
            ranks = [self._parse_card(card)[0] for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            max_count = max(rank_counts.values())
            
            if max_count >= 4:  # Four of a kind
                return 0.98
            elif max_count == 3:  # Three of a kind
                if len([c for c in rank_counts.values() if c >= 2]) >= 2:
                    return 0.95  # Full house
                return 0.85
            elif max_count == 2:  # Pair
                pairs = [r for r, c in rank_counts.items() if c == 2]
                if len(pairs) >= 2:  # Two pair
                    return 0.75
                elif pairs[0] >= 12:  # High pair
                    return 0.70
                else:
                    return 0.60
                    
            # Check for flush potential
            suits = [self._parse_card(card)[1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            if max(suit_counts.values()) >= 5:
                return 0.90
                
            # High card
            if max(rank1, rank2) >= 12:
                return 0.45
            return 0.35
            
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit."""
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass