from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_count = 0
        self.position_is_sb = False
        self.position_is_bb = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        self.position_is_sb = (self.id == small_blind_player_id)
        self.position_is_bb = (self.id == big_blind_player_id)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0 to 1"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.3
            
        # Parse hole cards
        card1_rank = self.get_card_rank(hole_cards[0])
        card2_rank = self.get_card_rank(hole_cards[1])
        card1_suit = hole_cards[0][-1] if hole_cards[0] else ''
        card2_suit = hole_cards[1][-1] if hole_cards[1] else ''
        
        suited = (card1_suit == card2_suit)
        high_card = max(card1_rank, card2_rank)
        low_card = min(card1_rank, card2_rank)
        gap = high_card - low_card
        
        # Pre-flop hand strength
        strength = 0.0
        
        # Premium pairs
        if gap == 0:  # Pair
            if high_card >= 12:  # QQ+
                strength = 0.95
            elif high_card >= 10:  # TT-JJ
                strength = 0.85
            elif high_card >= 8:  # 88-99
                strength = 0.75
            elif high_card >= 6:  # 66-77
                strength = 0.65
            else:  # 22-55
                strength = 0.55
        # High cards
        elif high_card == 14:  # Ace high
            if low_card >= 11:  # AJ+
                strength = 0.80 if suited else 0.75
            elif low_card >= 9:  # A9-AT
                strength = 0.65 if suited else 0.60
            else:
                strength = 0.55 if suited else 0.50
        elif high_card == 13:  # King high
            if low_card >= 11:  # KJ+
                strength = 0.70 if suited else 0.65
            elif low_card >= 9:  # K9-KT
                strength = 0.55 if suited else 0.50
            else:
                strength = 0.45 if suited else 0.40
        elif high_card == 12:  # Queen high
            if low_card >= 10:  # QT+
                strength = 0.60 if suited else 0.55
            else:
                strength = 0.45 if suited else 0.40
        # Connectors
        elif gap == 1:  # Connected cards
            if high_card >= 10:
                strength = 0.55 if suited else 0.50
            else:
                strength = 0.45 if suited else 0.40
        # Gap hands
        elif gap == 2:
            if high_card >= 10:
                strength = 0.45 if suited else 0.40
            else:
                strength = 0.35 if suited else 0.30
        else:
            # Weak hands
            strength = 0.30 if suited else 0.25
            
        # Adjust for community cards if present
        if community_cards and len(community_cards) > 0:
            # Simple adjustments based on board texture
            num_community = len(community_cards)
            if num_community >= 3:
                # Check for pairs with board
                for card in hole_cards:
                    for comm_card in community_cards:
                        if self.get_card_rank(card) == self.get_card_rank(comm_card):
                            strength = min(1.0, strength + 0.3)
                            
                # Check for flush potential
                suits = {}
                for card in hole_cards + community_cards:
                    if card:
                        suit = card[-1]
                        suits[suit] = suits.get(suit, 0) + 1
                for suit, count in suits.items():
                    if count >= 4:
                        strength = min(1.0, strength + 0.2)
                    if count >= 5:
                        strength = min(1.0, strength + 0.4)
                        
        return strength
    
    def get_card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        if not card or len(card) < 1:
            return 2
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        return pot / (pot + call_amount + 0.001)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current situation
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(
            self.hole_cards, 
            round_state.community_cards
        )
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Determine betting round
        betting_round = round_state.round.lower()
        
        # Position-based adjustments
        is_preflop = (betting_round == 'preflop')
        in_position = self.position_is_sb and is_preflop
        
        # Adjust strategy based on position
        if in_position:
            hand_strength *= 1.1  # Slightly more aggressive in position
        
        # Decision logic
        if call_amount == 0:  # Can check
            if hand_strength > 0.7:
                # Strong hand - raise
                if max_raise > min_raise and min_raise > 0:
                    # Calculate raise size based on hand strength
                    if hand_strength > 0.9:
                        raise_amount = min(pot * 2, max_raise)
                    elif hand_strength > 0.8:
                        raise_amount = min(pot, max_raise)
                    else:
                        raise_amount = min(pot // 2, max_raise)
                    
                    # Ensure raise amount meets minimum requirements
                    if raise_amount >= min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength > 0.5:
                # Medium hand - sometimes raise as bluff
                if betting_round == 'river':
                    return (PokerAction.CHECK, 0)
                elif max_raise > min_raise and min_raise > 0:
                    # Occasional bluff
                    if self.game_count % 3 == 0:  # Bluff 1/3 of the time
                        raise_amount = min(pot // 2, max_raise)
                        if raise_amount >= min_raise:
                            return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:  # Need to call or fold
            # Calculate if call is profitable
            if hand_strength > pot_odds:
                # Profitable to call
                if hand_strength > 0.8 and max_raise > min_raise and min_raise > 0:
                    # Very strong hand - consider re-raising
                    raise_amount = min(pot + call_amount, max_raise)
                    if raise_amount >= min_raise and raise_amount > call_amount:
                        # Make sure our raise is valid
                        total_bet_after_raise = my_current_bet + raise_amount
                        if total_bet_after_raise > current_bet:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Not profitable to call
                if hand_strength > 0.4 and call_amount <= pot // 4:
                    # Small call with decent hand
                    if call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    # Fold weak hands
                    return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass