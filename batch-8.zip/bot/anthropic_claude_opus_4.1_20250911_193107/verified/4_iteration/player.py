from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_fold_rate = {}
        self.opponent_raise_count = {}
        self.opponent_call_count = {}
        self.last_aggressive_action = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        for player_id in all_players:
            if player_id not in self.opponent_fold_rate:
                self.opponent_fold_rate[player_id] = 0.5
                self.opponent_raise_count[player_id] = 0
                self.opponent_call_count[player_id] = 0
                self.last_aggressive_action[player_id] = 0
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Calculate hand strength with improved evaluation"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        card1, card2 = hole_cards[0], hole_cards[1]
        rank1, rank2 = self.get_card_rank(card1), self.get_card_rank(card2)
        suit1, suit2 = card1[-1], card2[-1]
        is_suited = (suit1 == suit2)
        is_pair = (rank1 == rank2)
        
        # Pre-flop strength
        if not community_cards:
            strength = 0.0
            
            # Pocket pairs
            if is_pair:
                strength = 0.35 + (rank1 / 14) * 0.5
                if rank1 >= 10:  # TT+
                    strength += 0.15
            else:
                high_card = max(rank1, rank2)
                low_card = min(rank1, rank2)
                gap = high_card - low_card
                
                # High cards
                strength = (high_card / 14) * 0.25 + (low_card / 14) * 0.15
                
                # Suited bonus
                if is_suited:
                    strength += 0.08
                
                # Connectivity bonus
                if gap == 1:
                    strength += 0.06
                elif gap == 2:
                    strength += 0.03
                
                # Premium hands
                if high_card == 14:  # Ace high
                    if low_card >= 10:  # AK, AQ, AJ, AT
                        strength += 0.2
                elif high_card == 13 and low_card >= 10:  # KQ, KJ, KT
                    strength += 0.1
                    
            return min(strength, 1.0)
        
        # Post-flop evaluation
        all_cards = hole_cards + community_cards
        strength = self.evaluate_made_hand(all_cards)
        
        # Adjust for board texture
        if len(community_cards) >= 3:
            board_danger = self.evaluate_board_danger(community_cards)
            strength *= (1.0 - board_danger * 0.3)
            
        return min(strength, 1.0)
    
    def evaluate_made_hand(self, cards: List[str]) -> float:
        """Evaluate the strength of made hands"""
        ranks = [self.get_card_rank(card) for card in cards]
        suits = [card[-1] for card in cards]
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for hands
        has_flush = any(count >= 5 for count in suit_counts.values())
        has_straight = self.check_straight(sorted(set(ranks)))
        
        max_same_rank = max(rank_counts.values()) if rank_counts else 0
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        
        if has_straight and has_flush:
            return 0.95  # Straight flush
        elif max_same_rank == 4:
            return 0.93  # Four of a kind
        elif max_same_rank == 3 and pairs >= 1:
            return 0.90  # Full house
        elif has_flush:
            return 0.85  # Flush
        elif has_straight:
            return 0.80  # Straight
        elif max_same_rank == 3:
            return 0.70  # Three of a kind
        elif pairs >= 2:
            return 0.60  # Two pair
        elif pairs == 1:
            high_pair_rank = max(rank for rank, count in rank_counts.items() if count == 2)
            return 0.35 + (high_pair_rank / 14) * 0.15  # One pair
        else:
            high_card = max(ranks)
            return 0.15 + (high_card / 14) * 0.15  # High card
    
    def check_straight(self, sorted_ranks: List[int]) -> bool:
        """Check if there's a straight in the ranks"""
        if len(sorted_ranks) < 5:
            return False
            
        # Check for regular straight
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                return True
                
        # Check for A-2-3-4-5 straight
        if 14 in sorted_ranks and set([2, 3, 4, 5]).issubset(set(sorted_ranks)):
            return True
            
        return False
    
    def evaluate_board_danger(self, community_cards: List[str]) -> float:
        """Evaluate how dangerous the board is"""
        if not community_cards:
            return 0.0
            
        danger = 0.0
        ranks = [self.get_card_rank(card) for card in community_cards]
        suits = [card[-1] for card in community_cards]
        
        # Check for flush possibilities
        for suit in set(suits):
            if suits.count(suit) >= 3:
                danger += 0.3
                
        # Check for straight possibilities
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 2):
            if sorted_ranks[i+2] - sorted_ranks[i] <= 4:
                danger += 0.2
                
        # Check for paired board
        if len(ranks) != len(set(ranks)):
            danger += 0.2
            
        return min(danger, 1.0)
    
    def get_card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        if not card or len(card) < 2:
            return 0
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def get_position_modifier(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage"""
        if not round_state.current_player:
            return 1.0
            
        my_position = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
        num_players = len(round_state.current_player)
        
        if num_players <= 1:
            return 1.0
            
        # Late position advantage
        position_ratio = my_position / (num_players - 1 + 0.001)
        return 0.85 + position_ratio * 0.3
    
    def update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics based on their actions"""
        for player_id, action in round_state.player_actions.items():
            if player_id == str(self.id):
                continue
                
            player_int_id = int(player_id)
            
            if action == 'Fold':
                self.opponent_fold_rate[player_int_id] = self.opponent_fold_rate.get(player_int_id, 0.5) * 0.9 + 0.1
            elif action == 'Raise' or action == 'All-in':
                self.opponent_raise_count[player_int_id] = self.opponent_raise_count.get(player_int_id, 0) + 1
                self.last_aggressive_action[player_int_id] = self.hand_count
            elif action == 'Call':
                self.opponent_call_count[player_int_id] = self.opponent_call_count.get(player_int_id, 0) + 1
                
    def should_bluff(self, round_state: RoundStateClient, remaining_chips: int) -> bool:
        """Determine if we should bluff"""
        if remaining_chips < self.starting_chips * 0.2:
            return False
            
        # Don't bluff into multiple opponents
        active_players = len([p for p, bet in round_state.player_bets.items() 
                            if p != str(self.id) and bet > 0])
        if active_players > 2:
            return False
            
        # Bluff more on scary boards
        if len(round_state.community_cards) >= 3:
            board_danger = self.evaluate_board_danger(round_state.community_cards)
            bluff_frequency = 0.15 + board_danger * 0.2
        else:
            bluff_frequency = 0.12
            
        # Adjust based on opponent tendencies
        for player_id in round_state.current_player:
            if player_id != self.id:
                fold_rate = self.opponent_fold_rate.get(player_id, 0.5)
                bluff_frequency *= (1 + fold_rate * 0.5)
                
        return random.random() < bluff_frequency
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Update opponent statistics
        self.update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self.get_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Apply position modifier
        position_modifier = self.get_position_modifier(round_state)
        adjusted_strength = hand_strength * position_modifier
        
        # Calculate pot odds
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_odds = self.calculate_pot_odds(round_state.pot, call_amount)
        
        # Stack to pot ratio
        spr = remaining_chips / (round_state.pot + 0.001)
        
        # Determine action based on hand strength and situation
        if call_amount <= 0:
            # No bet to call - we can check or bet
            if adjusted_strength > 0.75 or (adjusted_strength > 0.55 and self.should_bluff(round_state, remaining_chips)):
                # Strong hand or bluff - bet/raise
                if spr < 2 and adjusted_strength > 0.7:
                    # Low SPR with strong hand - go all in
                    return (PokerAction.ALL_IN, 0)
                else:
                    # Size bet based on pot and hand strength
                    bet_size = int(round_state.pot * (0.5 + adjusted_strength * 0.7))
                    bet_size = max(round_state.min_raise, min(bet_size, remaining_chips))
                    
                    if bet_size >= remaining_chips * 0.8:
                        return (PokerAction.ALL_IN, 0)
                    elif bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            implied_odds = pot_odds * 0.8  # Discount pot odds slightly
            
            # All-in decision
            if call_amount >= remaining_chips:
                if adjusted_strength > 0.65 or (adjusted_strength > pot_odds + 0.15):
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Regular decision
            if adjusted_strength > 0.8:
                # Very strong hand - raise or all-in
                if spr < 3:
                    return (PokerAction.ALL_IN, 0)
                else:
                    raise_amount = int(round_state.pot * (0.7 + adjusted_strength * 0.5))
                    raise_amount = max(round_state.min_raise, min(raise_amount, remaining_chips))
                    
                    if raise_amount >= remaining_chips * 0.7:
                        return (PokerAction.ALL_IN, 0)
                    elif raise_amount >= round_state.min_raise and raise_amount > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                        
            elif adjusted_strength > 0.6 or (adjusted_strength > pot_odds + 0.1):
                # Good hand or good pot odds - call or raise
                if adjusted_strength > 0.7 and spr > 3:
                    # Consider raising with strong hands
                    raise_amount = int(round_state.pot * 0.6)
                    if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips * 0.5:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
                
            elif adjusted_strength > pot_odds:
                # Marginal spot - call if pot odds are good
                return (PokerAction.CALL, 0)
                
            elif self.should_bluff(round_state, remaining_chips) and call_amount < remaining_chips * 0.2:
                # Occasional bluff raise
                raise_amount = int(round_state.pot * 0.8)
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips * 0.4:
                    return (PokerAction.RAISE, raise_amount)
                    
            # Default to fold if nothing else applies
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass