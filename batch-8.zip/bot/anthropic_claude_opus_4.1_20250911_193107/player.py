from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.game_count = 0
        self.fold_count = 0
        self.raise_count = 0
        self.call_count = 0
        self.starting_chips = 10000
        self.current_game_rounds = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.game_count += 1
        self.current_game_rounds = 0
        self.starting_chips = starting_chips
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_game_rounds += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current situation
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Calculate pot odds
        if amount_to_call > 0:
            pot_odds = amount_to_call / (pot_size + amount_to_call + 0.001)
        else:
            pot_odds = 0
            
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Position advantage (are we acting last?)
        num_active_players = len([p for p in round_state.current_player if p in round_state.player_bets])
        is_late_position = num_active_players <= 2
        
        # Decision making based on hand strength and pot odds
        if remaining_chips <= 0:
            return (PokerAction.FOLD, 0)
            
        # If we can check, consider it based on hand strength
        if amount_to_call == 0:
            if hand_strength >= 0.7:  # Strong hand, raise
                if remaining_chips > 0 and current_bet == 0:
                    # Make a proper raise amount
                    raise_amount = min(int(pot_size * 0.5), remaining_chips)
                    if raise_amount > 0:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif hand_strength >= 0.4:  # Medium hand, check
                return (PokerAction.CHECK, 0)
            else:  # Weak hand but free to check
                return (PokerAction.CHECK, 0)
        
        # Need to call or raise
        if hand_strength >= 0.8:  # Very strong hand
            # Calculate proper raise amount
            if min_raise > 0 and remaining_chips >= min_raise:
                raise_amount = min(int(pot_size * 0.75), max_raise)
                if raise_amount >= min_raise:
                    return (PokerAction.RAISE, raise_amount)
            # Can't raise properly, just call
            if amount_to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
                
        elif hand_strength >= 0.6:  # Good hand
            # Call if pot odds are favorable
            if pot_odds < 0.3 or (is_late_position and pot_odds < 0.4):
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.4:  # Medium hand
            # Only call small bets
            if pot_odds < 0.2:
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Weak hand
            # Only call very small bets or fold
            if pot_odds < 0.1 and amount_to_call < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1_rank, card1_suit = self._parse_card(self.hole_cards[0])
        card2_rank, card2_suit = self._parse_card(self.hole_cards[1])
        
        # Base strength from hole cards
        strength = 0.0
        
        # Pocket pairs
        if card1_rank == card2_rank:
            if card1_rank >= 12:  # QQ, KK, AA
                strength = 0.9
            elif card1_rank >= 10:  # TT, JJ
                strength = 0.8
            elif card1_rank >= 8:  # 88, 99
                strength = 0.7
            else:
                strength = 0.6
        else:
            # High cards
            high_card = max(card1_rank, card2_rank)
            low_card = min(card1_rank, card2_rank)
            
            if high_card == 14:  # Ace
                if low_card >= 10:  # AK, AQ, AJ, AT
                    strength = 0.75
                else:
                    strength = 0.55
            elif high_card >= 12:  # King or Queen
                if low_card >= 10:
                    strength = 0.65
                else:
                    strength = 0.45
            elif high_card >= 10:  # Jack or Ten
                if low_card >= 8:
                    strength = 0.5
                else:
                    strength = 0.4
            else:
                strength = 0.3
                
            # Suited bonus
            if card1_suit == card2_suit:
                strength += 0.05
                
            # Connected cards bonus
            if abs(card1_rank - card2_rank) == 1:
                strength += 0.05
        
        # Adjust based on community cards
        community = round_state.community_cards
        if len(community) >= 3:
            # Simple evaluation with community cards
            all_ranks = [card1_rank, card2_rank]
            for card in community:
                rank, _ = self._parse_card(card)
                all_ranks.append(rank)
                
            # Check for pairs, trips, etc.
            rank_counts = {}
            for rank in all_ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                
            max_count = max(rank_counts.values())
            if max_count >= 4:  # Four of a kind
                strength = 0.95
            elif max_count == 3:  # Three of a kind
                if 2 in rank_counts.values():  # Full house
                    strength = 0.9
                else:
                    strength = 0.75
            elif list(rank_counts.values()).count(2) >= 2:  # Two pair
                strength = 0.65
            elif max_count == 2:  # One pair
                pair_rank = [rank for rank, count in rank_counts.items() if count == 2][0]
                if pair_rank in [card1_rank, card2_rank]:  # We have the pair
                    strength = max(strength, 0.55)
                else:
                    strength = max(strength, 0.4)
                    
        # Adjust based on round
        if round_state.round == 'Preflop':
            strength *= 0.9  # Be more conservative preflop
        elif round_state.round == 'River':
            strength *= 1.1  # Be more aggressive on river
            
        return min(strength, 1.0)
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit"""
        if not card or len(card) < 2:
            return (2, 's')
            
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
            '7': 7, '8': 8, '9': 9, 'T': 10,
            'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass