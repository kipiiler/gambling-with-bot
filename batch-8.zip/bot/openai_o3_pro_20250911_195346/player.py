# player.py
from typing import List, Tuple, Dict, Any
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


# --------------------------------------------------------------------------- #
# --------------------------  Helper  Utilities  ---------------------------- #
# --------------------------------------------------------------------------- #
RANK_ORDER = "23456789TJQKA"
RANK_VALUE: Dict[str, int] = {r: i for i, r in enumerate(RANK_ORDER, start=2)}


def _card_rank(card: str) -> str:
    """Return rank character of a card, e.g. 'A' from 'As'."""
    return card[0] if card else "?"


def _card_suit(card: str) -> str:
    """Return suit character of a card, e.g. 's' from 'As'."""
    return card[1] if card else "?"


def chen_formula(card1: str, card2: str) -> float:
    """
    Very rough pre-flop hand strength estimator based on the
    well-known 'Chen formula'.  Returns a float score.
    """
    if not card1 or not card2:
        return 0.0
    r1, r2 = _card_rank(card1), _card_rank(card2)
    s1, s2 = _card_suit(card1), _card_suit(card2)

    def base_score(rank: str) -> float:
        mapping = {
            "A": 10, "K": 8, "Q": 7, "J": 6,
            "T": 5, "9": 4.5, "8": 4, "7": 3.5,
            "6": 3, "5": 2.5, "4": 2, "3": 1.5, "2": 1
        }
        return mapping[rank]

    high_rank, low_rank = (r1, r2) if RANK_VALUE[r1] >= RANK_VALUE[r2] else (r2, r1)
    score = base_score(high_rank)

    # Pair bonus (double, minimum 5)
    if r1 == r2:
        score = max(score * 2, 5)

    # Suited bonus
    if s1 == s2:
        score += 2

    # Gap penalties / connector bonus
    gap = abs(RANK_VALUE[r1] - RANK_VALUE[r2]) - 1  # gaps between ranks
    if gap == 0:        # connectors
        score += 1
    elif gap == 1:
        score += 0.5
    elif gap == 2:
        score -= 0.5
    elif gap == 3:
        score -= 1
    else:               # gap >= 4
        score -= 2

    # Small straight possibility (ACE–5, etc.)
    # simple bonus for wheel possibility
    wheel = {"A", "2", "3", "4", "5"}
    if {r1, r2}.issubset(wheel):
        score += 1

    return max(score, 0.0)  # never negative


def made_hand_strength(cards: List[str]) -> int:
    """
    Extremely simple post-flop hand strength:
    1 = high card,
    2 = pair,
    3 = two pair,
    4 = trips,
    5 = straight  (not fully detected here),
    6 = flush     (simplified),
    7 = full house,
    8 = four-of-kind,
    9 = straight flush / royal (not fully detected here).
    This implementation focuses on pairs/two-pair/trips/flush,
    enough for a basic strategy.
    """
    if len(cards) < 5:
        return 1

    ranks = [_card_rank(c) for c in cards]
    suits = [_card_suit(c) for c in cards]

    # Rank histogram
    counts: Dict[str, int] = {}
    for r in ranks:
        counts[r] = counts.get(r, 0) + 1
    freq = sorted(counts.values(), reverse=True)

    # Detect duplicates
    if freq[0] == 4:
        return 8
    if freq[0] == 3 and freq[1] >= 2:
        return 7
    if freq[0] == 3:
        return 4
    if freq[0] == 2 and freq[1] == 2:
        return 3
    if freq[0] == 2:
        return 2

    # Very naive flush detection
    for s in "shdc":
        if suits.count(s) >= 5:
            return 6

    # Straight detection – minimal (look for 5 unique sequential ranks)
    unique_ranks = sorted({RANK_VALUE[r] for r in ranks})
    for i in range(len(unique_ranks) - 4):
        if unique_ranks[i + 4] - unique_ranks[i] == 4:
            return 5
    # Wheel straight A-5
    wheel_values = {14, 5, 4, 3, 2}
    if wheel_values.issubset({RANK_VALUE[r] for r in ranks}):
        return 5

    return 1


# --------------------------------------------------------------------------- #
# ---------------------------     Poker  Bot     ---------------------------- #
# --------------------------------------------------------------------------- #
class SimplePlayer(Bot):
    """
    A very small, tight-aggressive bot based on simple heuristics.
    Implements all required callbacks from the competition template.
    """

    def __init__(self):
        super().__init__()
        # Statistics tracking (optional, may be extended later)
        self.hand_history: List[Dict[str, Any]] = []
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.starting_stack = 0
        random.seed()  # independent RNG per bot instance

    # ----------------------  Callback Implementations  ---------------------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_stack = starting_chips
        # We don't know seat position mapping here; merely store blind size
        self.small_blind_amount = blind_amount
        self.big_blind_amount = blind_amount * 2

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing special necessary each new hand for this simple bot
        pass

    # ----------------------------  Main Logic  ------------------------------ #
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision logic.  Uses:
        - very rough pre-flop Chen strength
        - ultra-simple post-flop made-hand ranking
        - bankroll / pot-odds checks
        Always ensures a legal move is returned.
        """
        try:
            my_id = str(self.id)
            to_call = max(round_state.current_bet - round_state.player_bets.get(my_id, 0), 0)
            can_check = to_call == 0

            # Safely fetch my private cards
            my_hole_cards = self._extract_hole_cards(round_state)
            community = round_state.community_cards

            phase = round_state.round.lower()  # 'preflop', 'flop', 'turn', 'river'

            # ---------------------------------------------------- #
            # -------------------  PRE-FLOP  ---------------------- #
            # ---------------------------------------------------- #
            if phase == "preflop":
                strength = chen_formula(my_hole_cards[0], my_hole_cards[1]) if len(my_hole_cards) == 2 else 0.0

                # Categorise
                if strength >= 10:          # premium
                    return self._play_strong(to_call, remaining_chips, round_state)
                elif strength >= 7.5:       # strong
                    return self._play_medium(to_call, remaining_chips, round_state)
                elif strength >= 5:         # mediocre
                    if can_check:
                        return PokerAction.CHECK, 0
                    else:
                        # Small call only if cheap
                        if to_call <= self.big_blind_amount:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                else:                       # trash
                    if can_check:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.FOLD, 0

            # ---------------------------------------------------- #
            # ------------------  POST-FLOP  ---------------------- #
            # ---------------------------------------------------- #
            all_cards = my_hole_cards + community
            made_rank = made_hand_strength(all_cards)

            # Convert to aggressive / passive behaviour
            if made_rank >= 7:  # full house +
                return PokerAction.ALL_IN, 0
            elif made_rank == 6 or made_rank == 5:  # flush / straight
                if can_check:
                    # Value bet
                    raise_amt = min(
                        round_state.max_raise,
                        max(round_state.min_raise, int(round_state.pot * 0.75))
                    )
                    if raise_amt > to_call:
                        return PokerAction.RAISE, raise_amt
                    return PokerAction.CHECK, 0
                else:
                    # Call or raise small
                    if to_call <= remaining_chips * 0.25:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif made_rank == 4 or made_rank == 3:  # trips / two-pair
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= round_state.pot * 0.3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif made_rank == 2:  # single pair
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= self.big_blind_amount * 2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:  # high card only
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        except Exception:  # Any unexpected error – fail safe: fold
            return PokerAction.FOLD, 0

    # -----------------------  End-of-Round / Game  -------------------------- #
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store small history for potential future learning
        self.hand_history.append(
            {
                "pot": round_state.pot,
                "community": round_state.community_cards,
                "player_bets": round_state.player_bets,
            }
        )
        # Keep history short to save memory
        if len(self.hand_history) > 500:
            self.hand_history.pop(0)

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # Optional: print summary for debugging (suppressed for competition)
        pass

    # ---------------------------  Helper methods  --------------------------- #
    def _play_strong(
        self, to_call: int, stack: int, rs: RoundStateClient
    ) -> Tuple[PokerAction, int]:
        """Strategy for very strong / premium starting hands."""
        if to_call == 0:
            # Open raise 4× BB or min-raise if limits tight
            raise_total = min(rs.max_raise, max(rs.min_raise, self.big_blind_amount * 4))
            return PokerAction.RAISE, raise_total
        else:
            # Re-raise / shove if short
            if to_call >= stack * 0.6:
                return PokerAction.ALL_IN, 0
            raise_total = min(rs.max_raise, max(rs.min_raise, rs.current_bet + to_call + self.big_blind_amount * 2))
            if raise_total <= stack:
                return PokerAction.RAISE, raise_total
            return PokerAction.CALL, 0

    def _play_medium(
        self, to_call: int, stack: int, rs: RoundStateClient
    ) -> Tuple[PokerAction, int]:
        """Strategy for decent but non-premium pre-flop hands."""
        if to_call == 0:
            # Small raise to build pot
            raise_total = min(rs.max_raise, max(rs.min_raise, self.big_blind_amount * 3))
            return PokerAction.RAISE, raise_total
        else:
            # Call small raises, fold to big ones
            if to_call <= self.big_blind_amount * 3:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _extract_hole_cards(self, rs: RoundStateClient) -> List[str]:
        """
        Attempt to obtain our private cards from RoundStateClient.
        Handles several possible attribute names defensively.
        """
        my_id_str = str(self.id)
        # 1. player_hands attribute (dict)
        if hasattr(rs, "player_hands") and isinstance(rs.player_hands, dict):
            if my_id_str in rs.player_hands:
                return rs.player_hands[my_id_str]

        # 2. hands attribute
        if hasattr(rs, "hands") and isinstance(rs.hands, dict):
            if my_id_str in rs.hands:
                return rs.hands[my_id_str]

        # 3. hole_cards attribute
        if hasattr(rs, "hole_cards"):
            hc = getattr(rs, "hole_cards")
            if isinstance(hc, dict) and my_id_str in hc:
                return hc[my_id_str]
            if isinstance(hc, list) and len(hc) == 2:
                # Sometimes hole cards are stored directly (heads-up scenario)
                return hc

        # Fallback: empty list – caller must handle gracefully
        return []