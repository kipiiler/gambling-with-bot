# player.py
import random
import math
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# OPTIONAL - try to use fast, pure-python hand evaluator (`treys`).
# Fallback to very simple heuristic if the package is missing.
try:
    from treys import Card, Evaluator, Deck  # type: ignore
    _TREYS_AVAILABLE = True
    _evaluator = Evaluator()
except Exception:  # pragma: no cover
    _TREYS_AVAILABLE = False


RANK_ORDER = "23456789TJQKA"
RANK_TO_INT = {r: i for i, r in enumerate(RANK_ORDER, 2)}


def _card_to_int(card: str) -> int:
    """Convert 'Ah'-style card to treys int."""
    return Card.new(card[0] + card[1].lower())


def _hand_to_key(card1: str, card2: str) -> str:
    """Return canonical 2-card hand key, e.g. 'AKs', 'T9o', '77'."""
    r1, s1 = card1[0], card1[1]
    r2, s2 = card2[0], card2[1]

    if RANK_TO_INT[r1] < RANK_TO_INT[r2]:
        r1, r2, s1, s2 = r2, r1, s2, s1  # ensure r1 >= r2

    if r1 == r2:
        return f"{r1}{r2}"
    suited = "s" if s1 == s2 else "o"
    return f"{r1}{r2}{suited}"


# Very small starting-hand strength table (value 1-10)
_PREFLOP_STRENGTH: Dict[str, int] = {
    # Premium pairs
    "AA": 10, "KK": 10, "QQ": 9, "JJ": 9, "TT": 8,
    # Mid pairs
    "99": 7, "88": 6, "77": 6, "66": 5, "55": 5, "44": 4, "33": 4, "22": 3,
    # Suited big aces / KQ
    "AKs": 10, "AQs": 9, "AJs": 8, "ATs": 7, "KQs": 8, "KJs": 7,
    # Off-suit big aces
    "AKo": 9, "AQo": 8, "AJo": 7, "KQo": 7,
    # Suited connectors
    "QJs": 7, "JTs": 7, "T9s": 6, "98s": 5, "87s": 5,
    # Suited one-gappers
    "KTs": 6, "QTs": 6, "J9s": 5, "T8s": 4, "97s": 4, "86s": 4,
    # Broadways off-suit
    "KJo": 6, "QJo": 5, "JTo": 5, "T9o": 4,
    # Suited A-x wheel
    "A9s": 6, "A8s": 5, "A7s": 5, "A6s": 4, "A5s": 4,
    # Etc. (all others default to 2)
}


def _get_starting_strength(card1: str, card2: str) -> int:
    key = _hand_to_key(card1, card2)
    return _PREFLOP_STRENGTH.get(key, 2)  # default very weak


class SimplePlayer(Bot):
    """
    Very small but robust Texas Hold'em bot.
    Focus: correctness & not spewing chips.
    Post-flop equity estimated via Monte-Carlo using `treys` when available.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.hole_cards: Tuple[str, str] | None = None
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        # Tracking
        self.round_counter = 0

    # -----------  LIFECYCLE CALLBACKS -----------------

    def on_start(self,
                 starting_chips: int,
                 player_hands: List[str],
                 blind_amount: int,
                 big_blind_player_id: int,
                 small_blind_player_id: int,
                 all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        # In many engines player_hands contains **our** 2 cards
        if player_hands and len(player_hands) == 2:
            self.hole_cards = (player_hands[0], player_hands[1])

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_counter += 1
        # Attempt to fetch our new hole cards if provided
        cards = None
        # Engine might store in round_state.player_hands -> dict
        if hasattr(round_state, "player_hands"):
            ph = getattr(round_state, "player_hands")
            if isinstance(ph, dict) and str(self.id) in ph:
                cards = ph[str(self.id)]
            elif isinstance(ph, (list, tuple)) and len(ph) == 2:
                cards = ph
        if cards:
            self.hole_cards = (cards[0], cards[1])

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = None  # new hand coming

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Simple logging – nothing fancy.
        pass

    # ----------------- MAIN DECISION ------------------

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Core decision engine.
        We intentionally restrict ourselves to CHECK / CALL / FOLD / ALL_IN
        (to avoid invalid raise amounts). ALL_IN used as an aggressive raise.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(round_state.current_bet - my_bet, 0)
        pot = max(round_state.pot, 1)  # avoid 0

        # If we somehow don't know our hole cards we take safest action.
        if not self.hole_cards:
            return self._safe_default_action(to_call)

        stage = round_state.round.lower()  # 'preflop', 'flop', etc.

        # ---- PREFLOP LOGIC ----
        if stage == "preflop":
            strength = _get_starting_strength(*self.hole_cards)

            if to_call == 0:
                # No raise facing us – decide to raise or check.
                if strength >= 8 and remaining_chips > 0:
                    return self._make_aggressive_move(round_state, remaining_chips)
                return PokerAction.CHECK, 0
            else:
                # Facing a bet
                if strength >= 8:
                    # Very strong – shove
                    return self._make_aggressive_move(round_state, remaining_chips)
                if strength >= 5 and to_call <= self.blind_amount * 4:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # ---- POSTFLOP LOGIC ----
        equity = self._estimate_equity(self.hole_cards, round_state.community_cards)
        # Breakeven call threshold
        need_equity = to_call / (pot + to_call + 1e-9)  # avoid zero div

        if to_call == 0:
            # Option to check
            if equity > 0.75 and remaining_chips > 0:
                return self._make_aggressive_move(round_state, remaining_chips)
            return PokerAction.CHECK, 0

        # Facing a bet
        if equity > 0.80:
            return self._make_aggressive_move(round_state, remaining_chips)
        if equity > need_equity + 0.05:  # small edge
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    # -------------  HELPER METHODS ---------------------

    def _safe_default_action(self, to_call: int) -> Tuple[PokerAction, int]:
        """No info – play ultra tight."""
        if to_call == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def _make_aggressive_move(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Choose ALL_IN if allowed; else CALL/CHECK."""
        if remaining_chips > 0:
            return PokerAction.ALL_IN, 0
        return PokerAction.CALL, 0

    # -------- EQUITY ESTIMATION (simple) --------------

    def _estimate_equity(self, hole_cards: Tuple[str, str], board_cards: List[str]) -> float:
        """
        Return win probability vs 1 random opponent using Monte-Carlo.
        Falls back to heuristic if `treys` unavailable.
        """
        if not _TREYS_AVAILABLE:
            # Quick heuristic: pair or better gets 0.65 else 0.30
            ranks = [c[0] for c in (*hole_cards, *board_cards)]
            has_pair = len(set(ranks)) < len(ranks)
            return 0.65 if has_pair else 0.30

        iterations = 120  # keep it light
        wins = ties = 0

        hole_ints = [_card_to_int(c) for c in hole_cards]
        board_ints = [_card_to_int(c) for c in board_cards]

        known_cards_set = set(hole_ints + board_ints)

        for _ in range(iterations):
            deck = Deck()
            # Remove known cards
            for card in known_cards_set:
                deck.cards.remove(card)

            opp_hole = deck.draw(2)
            remaining_board = deck.draw(5 - len(board_ints))
            full_board = board_ints + remaining_board

            my_score = _evaluator.evaluate(full_board, hole_ints)
            opp_score = _evaluator.evaluate(full_board, opp_hole)

            if my_score < opp_score:
                wins += 1
            elif my_score == opp_score:
                ties += 1
            # else loss

        total = iterations
        return (wins + ties * 0.5) / total if total > 0 else 0.5