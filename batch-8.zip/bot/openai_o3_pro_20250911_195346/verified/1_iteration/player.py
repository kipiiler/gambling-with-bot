# player.py
import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# -------- optional fast hand evaluator (pure python) -----------------
try:
    from treys import Card, Evaluator, Deck  # noqa
    _TREYS_AVAILABLE = True
    _evaluator = Evaluator()
except ImportError:  # graceful fallback, still legal – simply avoids post-flop simulation
    _TREYS_AVAILABLE = False
# ---------------------------------------------------------------------


class SimplePlayer(Bot):
    """
    A reasonably strong, fully–featured No-Limit Texas Hold’em bot that
    • plays a solid pre-flop style based on the Chen formula
    • performs Monte-Carlo simulations post-flop (when treys is available)
    • always returns legal actions (never throws)
    • respects time & memory limits
    """

    # ----- Chen formula high-card base values -----
    _CHEN_BASE: Dict[int, float] = {
        14: 10,   # Ace
        13: 8,    # King
        12: 7,    # Queen
        11: 6,    # Jack
        10: 5,
        9: 4.5,
        8: 4,
        7: 3.5,
        6: 3,
        5: 2.5,
        4: 2,
        3: 1.5,
        2: 1
    }

    def __init__(self):
        super().__init__()
        # will be filled at run-time
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.all_players: List[int] = []
        self.big_blind_player_id: int | None = None
        self.small_blind_player_id: int | None = None

        # per-hand storage
        self.hole_cards: List[str] = []  # our private two cards

    # ------------------------------------------------------------------
    #  Life-cycle hooks
    # ------------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands or []
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # obtain fresh hole cards if provided by server
        self.hole_cards = self._extract_hole_cards(round_state) or self.hole_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Core decision engine. Returns a tuple of (PokerAction, amount).
        Amount is ignored for FOLD / CHECK / CALL / ALL_IN.
        Always produces a legal action – crucial for staying alive.
        """

        # ------------------------------------------------------------------
        #  Basic derived variables
        # ------------------------------------------------------------------
        my_bet = self._my_bet(round_state)
        to_call = max(round_state.current_bet - my_bet, 0)
        can_check = to_call == 0
        can_call = to_call > 0 and remaining_chips >= to_call
        can_raise = remaining_chips > to_call and remaining_chips - to_call >= round_state.min_raise
        pot = max(round_state.pot, 1)  # avoid /0

        # ------------------------------------------------------------------
        #  PRE-FLOP PLAY
        # ------------------------------------------------------------------
        if round_state.round.lower() == "preflop":
            chen = self._chen_score(self.hole_cards)

            # if facing an all-in / huge bet, tighten up
            if to_call > pot * 0.75 and chen < 10:
                return (PokerAction.FOLD, 0)

            # aggressive play with strong holdings
            if chen >= 10:  # premium
                if can_raise:
                    return self._build_raise(round_state, remaining_chips, factor=4)
                if can_call:
                    return (PokerAction.CALL, 0)
                return (PokerAction.ALL_IN, 0)

            if chen >= 7:  # playable
                if can_call:
                    # small 3-bet if first in
                    if can_raise and can_check:
                        return self._build_raise(round_state, remaining_chips, factor=3)
                    return (PokerAction.CALL, 0)
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

            # speculative hands if pot odds permit
            limp_threshold = self.blind_amount * 2 + 1
            if can_check:
                return (PokerAction.CHECK, 0)
            if can_call and to_call <= limp_threshold:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # ------------------------------------------------------------------
        #  POST-FLOP PLAY
        # ------------------------------------------------------------------
        win_prob = self._estimate_strength(self.hole_cards, round_state.community_cards)

        # simple pot-sized betting heuristic
        if can_check:
            if win_prob > 0.6 and can_raise:
                return self._build_raise(round_state, remaining_chips, factor=0.75)
            return (PokerAction.CHECK, 0)

        # we face a bet
        # calling threshold adjusts with pot odds
        pot_odds = to_call / (pot + to_call + 1e-9)
        if win_prob > pot_odds + 0.15:  # have sufficient equity
            # occasionally apply pressure
            if win_prob > 0.75 and can_raise:
                return self._build_raise(round_state, remaining_chips, factor=1.2)
            return (PokerAction.CALL, 0) if can_call else (PokerAction.ALL_IN, 0)

        # bad spot – fold
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # clear hand information
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass  # nothing to persist between separate games

    # ==================================================================
    #  Helper functions
    # ==================================================================
    def _my_bet(self, round_state: RoundStateClient) -> int:
        return round_state.player_bets.get(str(self.id), 0) or round_state.player_bets.get(self.id, 0) or 0

    def _build_raise(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
        factor: float = 3.0
    ) -> Tuple[PokerAction, int]:
        """
        Constructs a valid RAISE amount.
        factor > 1 multiplies current bet or pot portion.
        """
        min_raise = round_state.min_raise
        to_call = max(round_state.current_bet - self._my_bet(round_state), 0)
        # size our raise relative to the pot
        target = int(round_state.pot * factor) + to_call
        amount = max(min_raise, target)
        amount = min(amount, remaining_chips - to_call)  # can't exceed stack
        # ensure legal
        if amount < min_raise or amount <= 0:
            # fall back safely
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            if remaining_chips <= to_call:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, 0)
        return (PokerAction.RAISE, amount)

    # ---------------- Chen formula ------------------------------------
    def _chen_score(self, cards: List[str]) -> float:
        if len(cards) != 2:
            return 0
        r1 = self._rank_value(cards[0][0])
        r2 = self._rank_value(cards[1][0])
        high, low = max(r1, r2), min(r1, r2)

        # base
        score = self._CHEN_BASE.get(high, 0)

        # pair
        if r1 == r2:
            score = max(5, score * 2)

        # suited
        if cards[0][1] == cards[1][1]:
            score += 2

        # gapped
        gap = abs(r1 - r2) - 1
        if gap == 0:
            score += 1
        elif gap == 1:
            score -= 1
        elif gap == 2:
            score -= 2
        elif gap >= 3:
            score -= 4

        # small straight bonus
        if gap <= 1 and high <= 11:
            score += 1

        return max(score, 0)

    @staticmethod
    def _rank_value(char: str) -> int:
        lookup = {'2': 2, '3': 3, '4': 4, '5': 5,
                  '6': 6, '7': 7, '8': 8, '9': 9,
                  'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return lookup.get(char.upper(), 0)

    # ---------------- Monte-Carlo hand strength -----------------------
    def _estimate_strength(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        iterations: int = 300
    ) -> float:
        """
        Estimates win probability vs ONE random opponent.
        Uses treys if available; otherwise returns neutral 0.5.
        """
        if not _TREYS_AVAILABLE or len(hole_cards) != 2:
            return 0.5  # fallback

        # convert to treys ints
        try:
            my_cards_int = [Card.new(c) for c in hole_cards]
            board_int = [Card.new(c) for c in community_cards]
        except Exception:
            return 0.5  # robust against malformed card strings

        wins = ties = 0
        deck = Deck()
        # remove known cards
        for c in my_cards_int + board_int:
            deck.cards.remove(c)

        for _ in range(iterations):
            # sample opponent hand & remaining community
            opp_cards = deck.draw(2)
            community_needed = 5 - len(board_int)
            future_board = deck.draw(community_needed)
            full_board = board_int + future_board

            my_rank = _evaluator.evaluate(full_board, my_cards_int)
            opp_rank = _evaluator.evaluate(full_board, opp_cards)

            if my_rank < opp_rank:
                wins += 1
            elif my_rank == opp_rank:
                ties += 1

            # put the drawn cards back for next iteration
            deck.cards.extend(opp_cards + future_board)
            random.shuffle(deck.cards)

        total = max(wins + ties, 1)
        return (wins + ties * 0.5) / total

    # ---------------- round_state helper ------------------------------
    def _extract_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """
        Tries several common field names to retrieve our private cards
        from the round_state object without assuming exact schema.
        """
        for attr in ('player_hands', 'hole_cards', 'private_cards'):
            if hasattr(round_state, attr):
                val = getattr(round_state, attr)
                # dict keyed by id
                if isinstance(val, dict):
                    return val.get(str(self.id), []) or val.get(self.id, [])
                # list of cards (already ours)
                if isinstance(val, list) and len(val) == 2:
                    return val
        return []