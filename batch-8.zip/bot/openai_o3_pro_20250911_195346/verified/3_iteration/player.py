# player.py
import random
import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i for i, r in enumerate(RANK_ORDER, 2)}


def _card_rank(card: str) -> str:
    return card[0]


def _card_suit(card: str) -> str:
    return card[1]


def evaluate_five(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Return (category, tie_breaker list) – larger is stronger.
    Category numbers:
        9  – royal flush
        8  – straight flush
        7  – four of a kind
        6  – full house
        5  – flush
        4  – straight
        3  – three of a kind
        2  – two pair
        1  – one pair
        0  – high card
    """
    ranks = sorted([RANK_VALUE[_card_rank(c)] for c in cards], reverse=True)
    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    counts = sorted(rank_counts.values(), reverse=True)
    counts_by_rank = sorted(
        ((cnt, r) for r, cnt in rank_counts.items()), reverse=True
    )
    is_flush = len({_card_suit(c) for c in cards}) == 1
    unique_ranks = sorted(set(ranks), reverse=True)
    is_straight = (
        len(unique_ranks) == 5
        and unique_ranks[0] - unique_ranks[-1] == 4
        or unique_ranks == [14, 5, 4, 3, 2]
    )
    if is_straight and is_flush and max(ranks) == 14:
        return (9, ranks)  # royal flush
    if is_straight and is_flush:
        return (8, ranks)
    if counts[0] == 4:
        four_rank = counts_by_rank[0][1]
        kicker = max(r for r in ranks if r != four_rank)
        return (7, [four_rank, kicker])
    if counts[0] == 3 and counts[1] == 2:
        triple = counts_by_rank[0][1]
        pair = counts_by_rank[1][1]
        return (6, [triple, pair])
    if is_flush:
        return (5, ranks)
    if is_straight:
        return (4, ranks)
    if counts[0] == 3:
        triple = counts_by_rank[0][1]
        kickers = sorted((r for r in ranks if r != triple), reverse=True)
        return (3, [triple] + kickers)
    if counts[0] == 2 and counts[1] == 2:
        pairs = [r for cnt, r in counts_by_rank if cnt == 2]
        pairs.sort(reverse=True)
        kicker = max(r for r in ranks if r not in pairs)
        return (2, pairs + [kicker])
    if counts[0] == 2:
        pair_rank = counts_by_rank[0][1]
        kickers = sorted((r for r in ranks if r != pair_rank), reverse=True)
        return (1, [pair_rank] + kickers)
    return (0, ranks)


def evaluate_seven(cards: List[str]) -> Tuple[int, List[int]]:
    """Pick best 5-card hand out of 7 and evaluate."""
    best = (-1, [])
    for combo in itertools.combinations(cards, 5):
        score = evaluate_five(list(combo))
        if score > best:
            best = score
    return best


def compare_seven(c1: List[str], c2: List[str]) -> int:
    """Return 1 if c1 wins, -1 if c2 wins, 0 tie."""
    s1 = evaluate_seven(c1)
    s2 = evaluate_seven(c2)
    if s1 > s2:
        return 1
    if s1 < s2:
        return -1
    return 0


class SimplePlayer(Bot):
    """
    A very small, self-contained bot that plays tight-aggressive pre-flop
    and uses simple win-probability estimation post-flop.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards: List[str] = []
        self.blind_amount = 0
        self.big_blind_id = None
        self.small_blind_id = None
        self.all_players: List[int] = []
        # statistics
        self.round_num = 0

    # ------------- Life-cycle hooks --------------- #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self.hole_cards = round_state.player_actions.get(str(self.id), self.hole_cards)

    # ------------- Core decision logic ------------ #

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:

        my_id_str = str(self.id)
        my_current_bet = round_state.player_bets.get(my_id_str, 0)
        call_amount = max(round_state.current_bet - my_current_bet, 0)
        can_check = call_amount == 0

        stage = round_state.round  # 'Preflop' / 'Flop' / 'Turn' / 'River'

        # Decide action for pre-flop
        if stage.lower() == "preflop":
            strength = self._preflop_strength(self.hole_cards)
            if strength >= 3:  # premium
                return self._raise_action(
                    round_state, remaining_chips, factor=4, call_amount=call_amount
                )
            if strength == 2:  # good
                if call_amount <= self.blind_amount * 3:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            if strength == 1:  # mediocre
                if can_check:
                    return PokerAction.CHECK, 0
                if call_amount <= self.blind_amount:  # cheap call
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            # trash
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # ----------- Post-flop strategy ------------- #
        win_prob = self._estimate_win_prob(
            self.hole_cards, round_state.community_cards, sims=150
        )

        pot = round_state.pot
        pot_odds = call_amount / (pot + call_amount + 1e-9)

        # If we are already all-in or cannot do anything
        if remaining_chips <= 0:
            return PokerAction.CHECK, 0

        # Strong advantage
        if win_prob > 0.8:
            # Value bet / shove
            if remaining_chips <= round_state.min_raise * 2:
                return PokerAction.ALL_IN, 0
            return self._raise_action(
                round_state, remaining_chips, factor=1.0, call_amount=call_amount
            )

        # Slight edge – call within odds
        if win_prob > pot_odds + 0.05:
            if can_check:
                return PokerAction.CHECK, 0
            if call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        # Otherwise fold / check
        if can_check:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # ------------- Helper functions --------------- #

    def _raise_action(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
        factor: float,
        call_amount: int,
    ) -> Tuple[PokerAction, int]:
        """
        Produce a legal raise action. factor indicates roughly
        how many pot-sized units to add beyond the call.
        """
        min_raise = round_state.min_raise
        pot = round_state.pot
        target = int(call_amount + min(max(int(pot * factor), min_raise), remaining_chips))
        target = max(min_raise, min(target, remaining_chips))
        # If we cannot legally raise the minimum, just go all-in / call
        if target < min_raise or target >= remaining_chips:
            if call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        return PokerAction.RAISE, target

    # ---------- Pre-flop hand classification ------- #

    def _preflop_strength(self, hand: List[str]) -> int:
        """
        Very rough pre-flop tiering.
        Returns:
            3 – premium
            2 – good
            1 – mediocre
            0 – weak
        """
        r1 = _card_rank(hand[0])
        r2 = _card_rank(hand[1])
        s1 = _card_suit(hand[0])
        s2 = _card_suit(hand[1])
        suited = s1 == s2
        # Pairs
        if r1 == r2:
            pair_rank_value = RANK_VALUE[r1]
            if pair_rank_value >= RANK_VALUE["T"]:
                return 3
            if pair_rank_value >= RANK_VALUE["7"]:
                return 2
            if pair_rank_value >= RANK_VALUE["4"]:
                return 1
            return 0
        # Non-pairs – make canonical ordering
        high = max(r1, r2, key=lambda x: RANK_VALUE[x])
        low = r1 if high == r2 else r2
        combo = high + low + ("s" if suited else "o")

        premium_set = {
            "AKs",
            "AQs",
            "AJs",
            "KQs",
            "AKo",
            "KK",
            "QQ",
            "JJ",
        }
        good_set = {
            "ATs",
            "KJs",
            "QJs",
            "AJo",
            "KQo",
        }
        mediocre_set = {
            "A9s",
            "KTs",
            "QTs",
            "JTs",
            "T9s",
            "98s",
            "ATo",
            "KJo",
            "QJo",
            "J9s",
        }
        if combo in premium_set:
            return 3
        if combo in good_set:
            return 2
        if combo in mediocre_set:
            return 1
        # High card Ace suited
        if high == "A" and suited:
            return 1
        return 0

    # ---------- Monte-Carlo win probability -------- #

    def _estimate_win_prob(
        self, hole: List[str], community: List[str], sims: int = 150
    ) -> float:
        deck = [r + s for r in RANK_ORDER for s in "cdhs"]
        for c in hole + community:
            if c in deck:
                deck.remove(c)
        wins = ties = 0
        for _ in range(sims):
            random.shuffle(deck)
            opp_hole = deck[:2]
            needed = 5 - len(community)
            board = community + deck[2 : 2 + needed]
            my_best = hole + board
            opp_best = opp_hole + board
            cmp = compare_seven(my_best, opp_best)
            if cmp > 0:
                wins += 1
            elif cmp == 0:
                ties += 1
        return (wins + ties * 0.5) / sims