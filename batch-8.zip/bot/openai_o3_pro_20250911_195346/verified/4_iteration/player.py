from typing import List, Tuple, Dict
from collections import Counter

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


# ------------ Helper functions ------------------------------------------------
_RANK_TO_VALUE: Dict[str, int] = {
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "T": 10,
    "J": 11,
    "Q": 12,
    "K": 13,
    "A": 14,
}


def _card_rank(card: str) -> str:
    """Returns rank character of a card, e.g. 'A' from 'Ah'. Safe-guarded."""
    return card[0] if len(card) >= 2 else ""


def _card_suit(card: str) -> str:
    """Returns suit character of a card, e.g. 'h' from 'Ah'. Safe-guarded."""
    return card[1] if len(card) >= 2 else ""


def _numeric_rank(card: str) -> int:
    """Returns numeric rank 2-14."""
    return _RANK_TO_VALUE.get(_card_rank(card), 0)


# ------------------------------------------------------------------------------
class SimplePlayer(Bot):
    """
    A robust, light-weight No-Limit Hold’em bot that focuses on playing
    reasonably solid pre-flop ranges and simple value betting post-flop.
    The implementation is intentionally conservative to avoid illegal moves
    and runtime errors while still profiting against weak opposition.
    """

    # ---------------------  PUBLIC API IMPLEMENTATION -------------------------
    def __init__(self):
        super().__init__()
        # State variables automatically reset between *games* (not rounds)
        self.starting_chips = 0
        self.big_blind_amount = 0
        self.total_players = 0
        # Variables that change every round
        self.hole_cards: List[str] = []
        self.round_num = 0

    # Game start ---------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.total_players = len(all_players)
        # player_hands may be empty at game start; store if available
        self.hole_cards = list(player_hands) if player_hands else []

    # Round start --------------------------------------------------------------
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Retrieve current hole cards if provided inside round_state
        # RoundState specification may or may not supply them; handle both cases
        cards = []
        # Try common keys used by servers
        for key in ("player_hands", "hole_cards", "hands"):
            if hasattr(round_state, key):
                hands_dict = getattr(round_state, key)
                if isinstance(hands_dict, dict):
                    cards = hands_dict.get(str(self.id), [])  # id’s are often str
                break
        self.hole_cards = list(cards) if cards else []

    # Main decision function ---------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Determine an action based on a simplified evaluation model.
        Always returns a valid action/amount pair.
        """
        # ----------------------------- Helpers ---------------------------------
        def legal_raise_amount(min_r: int, max_r: int, target: int) -> int:
            """Return a raise amount clamped to [min_r, max_r]."""
            target = max(target, min_r)
            target = min(target, max_r)
            # Ensure it actually constitutes a raise
            return target if target >= min_r else min_r

        # Current betting info
        our_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(round_state.current_bet - our_bet, 0)

        # Identify betting round
        street: str = round_state.round.upper()

        # -------------------------- PREFLOP LOGIC ------------------------------
        if street == "PREFLOP":
            strength = self._preflop_strength(self.hole_cards)

            # 1. Can we check?
            if to_call == 0:
                if strength >= 0.8 and round_state.min_raise <= remaining_chips:
                    raise_amt = legal_raise_amount(
                        round_state.min_raise,
                        round_state.max_raise,
                        self.big_blind_amount * 3,
                    )
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CHECK, 0

            # 2. There is a bet to call
            if strength >= 0.85:
                # Premium – 3-bet / shove depending on stack
                raise_target = to_call * 3
                if remaining_chips - to_call <= 0:
                    return PokerAction.ALL_IN, 0
                if raise_target >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                raise_amt = legal_raise_amount(
                    round_state.min_raise, round_state.max_raise, raise_target
                )
                return PokerAction.RAISE, raise_amt
            elif strength >= 0.6 and to_call <= remaining_chips * 0.05:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # ------------------------- POSTFLOP LOGIC ------------------------------
        community = list(round_state.community_cards)
        category = self._hand_category(self.hole_cards, community)

        # Map category to integer strength
        cat_strength = {
            "high_card": 0,
            "pair": 1,
            "two_pair": 2,
            "three_kind": 3,
            "straight": 4,
            "flush": 5,
            "full_house_plus": 6,
        }[category]

        if to_call == 0:
            if cat_strength >= 2 and round_state.min_raise <= remaining_chips:
                # Bet value
                pot_fraction = 0.75 if cat_strength >= 4 else 0.5
                raise_target = int(round_state.pot * pot_fraction)
                raise_amt = legal_raise_amount(
                    round_state.min_raise, round_state.max_raise, raise_target
                )
                return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0

        # There is a bet to call
        if cat_strength >= 4:
            # Strong made hands – raise or shove
            if remaining_chips - to_call <= 0:
                return PokerAction.ALL_IN, 0
            raise_target = int(round_state.pot * 0.9)
            if raise_target >= remaining_chips:
                return PokerAction.ALL_IN, 0
            raise_amt = legal_raise_amount(
                round_state.min_raise, round_state.max_raise, raise_target
            )
            return PokerAction.RAISE, raise_amt
        elif cat_strength >= 2:
            # Medium strength – call within reason
            if to_call <= remaining_chips * 0.25:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        elif cat_strength == 1:
            # Weak pair – small call
            if to_call <= remaining_chips * 0.05:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else:
            # No made hand
            return PokerAction.FOLD, 0

    # ---------------- END get_action -----------------------------------------

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No persistent per-round bookkeeping needed
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # Nothing to clean up between separate games at the moment
        pass

    # ---------------------- INTERNAL STRATEGY HELPERS -------------------------

    # -------- Pre-flop evaluation --------------------------------------------
    def _preflop_strength(self, hand: List[str]) -> float:
        """
        Approximate strength between 0 and 1 using a simplified Chen-like
        formula. Returns 0.5 if cards are unavailable.
        """
        if len(hand) != 2 or any(len(c) < 2 for c in hand):
            return 0.5  # Unknown, pick middle strength to stay conservative

        ranks = [_numeric_rank(c) for c in hand]
        suits = [_card_suit(c) for c in hand]
        ranks.sort(reverse=True)
        high, low = ranks

        # Base score from highest card
        score = high / 14.0

        # Pair bonus
        if high == low:
            score += 0.4 + (high - 6) / 20.0  # bigger bonus for high pairs

        # Suited bonus
        if suits[0] == suits[1]:
            score += 0.05

        # Connector bonus (gap)
        gap = abs(ranks[0] - ranks[1])
        if gap == 0:
            pass
        elif gap == 1:
            score += 0.08
        elif gap == 2:
            score += 0.04
        elif gap == 3:
            score -= 0.02
        else:
            score -= 0.05

        # Clamp to [0,1]
        return max(0.0, min(score, 1.0))

    # -------- Post-flop hand categorisation ----------------------------------
    def _hand_category(self, hole: List[str], board: List[str]) -> str:
        """
        Very rough hand strength classification.
        Returns one of: high_card, pair, two_pair, three_kind,
                        straight, flush, full_house_plus
        """
        cards = hole + board
        if len(cards) < 5:
            return "high_card"

        # Flush check
        suit_counts = Counter(_card_suit(c) for c in cards)
        has_flush = max(suit_counts.values()) >= 5

        # Rank counts
        rank_counts = Counter(_numeric_rank(c) for c in cards)
        counts = sorted(rank_counts.values(), reverse=True)
        if counts[0] >= 4:
            return "full_house_plus"  # four-of-a-kind
        if counts[0] == 3 and counts[1] >= 2:
            return "full_house_plus"  # full house

        # Straight check
        unique_ranks = sorted(set(rank_counts.keys()))
        # Handle wheel straight (A-5)
        if 14 in unique_ranks:
            unique_ranks.append(1)
        straight_found = False
        for i in range(len(unique_ranks) - 4):
            window = unique_ranks[i : i + 5]
            if window[-1] - window[0] == 4:
                straight_found = True
                break

        if has_flush and straight_found:
            return "full_house_plus"  # treat straight flush as top tier
        if has_flush:
            return "flush"
        if straight_found:
            return "straight"
        if counts[0] == 3:
            return "three_kind"
        if counts[0] == 2 and counts[1] == 2:
            return "two_pair"
        if counts[0] == 2:
            return "pair"
        return "high_card"