from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # assume big blind amount provided
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Round state tracking
        self.current_round_num: int = 0
        self.rng = random.Random(42)

        # Opponent modeling (lightweight)
        # Tracks simple aggregated stats over the game
        # Format: {player_id_str: {"raise": int, "call": int, "fold": int, "check": int, "all_in": int}}
        self.player_stats: Dict[str, Dict[str, int]] = {}

        # Bankroll and performance tracking
        self.last_remaining_chips: int = 0
        self.total_profit: int = 0

    def _init_player_stats(self):
        for pid in self.all_players:
            self.player_stats[str(pid)] = {"raise": 0, "call": 0, "fold": 0, "check": 0, "all_in": 0}

    def _seed_rng(self, salt: int = 0):
        # Seed RNG deterministically based on player id and round for reproducibility
        seed_val = (self.id or 0) * 1315423911 + (self.current_round_num or 0) * 2654435761 + salt
        self.rng.seed(seed_val)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize session info
        self.starting_chips = starting_chips
        self.blind_amount = max(1, int(blind_amount or 0))
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players or [])
        self._init_player_stats()
        self.last_remaining_chips = starting_chips
        self.total_profit = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track new round
        self.current_round_num = getattr(round_state, "round_num", self.current_round_num + 1)
        self._seed_rng(salt=self.current_round_num)
        # Make sure stats contain all players present in the mapping
        if round_state and round_state.player_actions:
            for pid in round_state.player_actions.keys():
                if pid not in self.player_stats:
                    self.player_stats[pid] = {"raise": 0, "call": 0, "fold": 0, "check": 0, "all_in": 0}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        # Safe defaults
        try:
            # Defensive guards
            if round_state is None:
                # No state - safest is to fold if something went wrong
                return (PokerAction.FOLD, 0)

            # Basic quantities
            my_id_str = str(self.id)
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(getattr(round_state, "current_bet", 0) or 0)
            to_call = max(0, current_bet - my_bet)
            pot = int(getattr(round_state, "pot", 0) or 0)
            min_raise = int(getattr(round_state, "min_raise", 0) or 0)
            max_raise = int(getattr(round_state, "max_raise", 0) or 0)
            street = str(getattr(round_state, "round", "Preflop") or "Preflop").lower()

            # Legal action guards
            can_check = (to_call <= 0)
            can_call = (to_call > 0 and remaining_chips > 0)
            can_raise = (min_raise > 0 and max_raise >= min_raise and remaining_chips > 0)
            can_all_in = (remaining_chips > 0)

            # Determine table size (active players in round_state.player_bets is a decent proxy)
            table_size = len((round_state.player_bets or {}).keys())

            # Pot odds heuristic thresholds by street
            # Slightly more tolerant on later streets
            if "pre" in street:
                call_threshold = 0.18
                raise_freq = 0.12
            elif "flop" in street:
                call_threshold = 0.22
                raise_freq = 0.16
            elif "turn" in street:
                call_threshold = 0.24
                raise_freq = 0.14
            else:
                call_threshold = 0.26
                raise_freq = 0.10

            # Adjust aggressiveness based on table_size (more conservative with more players)
            if table_size >= 5:
                call_threshold *= 0.9
                raise_freq *= 0.85
            elif table_size <= 3:
                call_threshold *= 1.1
                raise_freq *= 1.2

            # Adjust based on our current profit/loss to modulate risk
            bankroll_delta = (remaining_chips - self.starting_chips)
            if bankroll_delta < -200:  # losing => tighten up
                call_threshold *= 0.9
                raise_freq *= 0.85
            elif bankroll_delta > 200:  # winning => slightly looser
                call_threshold *= 1.05
                raise_freq *= 1.1

            # Compute pot odds
            denom = pot + to_call + 1e-9
            pot_odds = to_call / denom if denom > 0 else 0.0

            # If no one has bet yet
            if can_check:
                # Strategy:
                # - Mix in some opens/bets with small probability
                # - Size: conservative, at least min_raise when legal, else check
                bet_chance = raise_freq
                # Increase open frequency preflop slightly
                if "pre" in street:
                    bet_chance *= 1.5

                # Increase betting chance when we have position (rough proxy: if our id is far from blinds)
                # Can't accurately compute position; small nudge with randomness
                self._seed_rng(salt=self.current_round_num + 7)
                if self.rng.random() < bet_chance and can_raise:
                    # Choose a prudent raise size
                    # For betting into zero, raise amount equals our bet size increment
                    target = max(self.blind_amount * 3, pot // max(1, table_size) + self.blind_amount * 2)
                    desired = max(min_raise, int(target))
                    raise_amt = int(max(min_raise, min(desired, max_raise)))
                    return (PokerAction.RAISE, raise_amt)
                else:
                    return (PokerAction.CHECK, 0)

            # Facing a bet
            else:
                # If calling would put us all-in or near all-in, consider shoving over small to_call when short-stacked
                short_stack = remaining_chips <= 20 * max(1, self.blind_amount)

                # If to_call is more than our stack, we cannot call exactly; prefer ALL_IN
                if to_call >= remaining_chips and can_all_in:
                    return (PokerAction.ALL_IN, 0)

                # Decide call vs fold based on pot odds
                if to_call == 0:
                    # Shouldn't happen due to can_check branch; safeguard
                    return (PokerAction.CHECK, 0)

                if pot_odds <= call_threshold and can_call:
                    # Call with reasonable odds
                    # Occasionally turn calls into small raises to apply pressure
                    self._seed_rng(salt=self.current_round_num + 11)
                    if can_raise and self.rng.random() < (raise_freq * 0.6):
                        # Use minimum raise when raising over a bet to avoid invalid sizes and keep risk manageable
                        raise_amt = int(max(min_raise, min(min_raise, max_raise)))
                        # Ensure raise_amt does not exceed max
                        if raise_amt >= min_raise and raise_amt <= max_raise:
                            return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.CALL, 0)
                else:
                    # Consider an occasional bluff-raise in heads-up with small bets
                    small_bet = to_call <= max(2 * self.blind_amount, pot // 8)
                    heads_up = table_size <= 2
                    self._seed_rng(salt=self.current_round_num + 13)
                    if can_raise and small_bet and heads_up and self.rng.random() < (raise_freq * 0.5):
                        raise_amt = int(max(min_raise, min(min_raise, max_raise)))
                        if raise_amt >= min_raise and raise_amt <= max_raise:
                            return (PokerAction.RAISE, raise_amt)

                    # If we're short-stacked and the bet is small relative to pot, prefer call over fold
                    if short_stack and pot > 0 and (to_call / (pot + 1e-9)) < 0.2 and can_call:
                        return (PokerAction.CALL, 0)

                    # Default fold
                    return (PokerAction.FOLD, 0)
        except Exception:
            # Failsafe to avoid timeouts or crashes: pick the safest valid action
            try:
                # Try to check, else fold
                if round_state:
                    my_bet = int(round_state.player_bets.get(str(self.id), 0)) if round_state.player_bets else 0
                    to_call = max(0, int(round_state.current_bet or 0) - my_bet)
                    if to_call <= 0:
                        return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update simple stats from actions
        try:
            if round_state and round_state.player_actions:
                for pid, action in round_state.player_actions.items():
                    a = str(action or "").strip().lower()
                    if pid not in self.player_stats:
                        self.player_stats[pid] = {"raise": 0, "call": 0, "fold": 0, "check": 0, "all_in": 0}
                    if "raise" in a:
                        self.player_stats[pid]["raise"] += 1
                    elif "call" in a:
                        self.player_stats[pid]["call"] += 1
                    elif "fold" in a:
                        self.player_stats[pid]["fold"] += 1
                    elif "check" in a:
                        self.player_stats[pid]["check"] += 1
                    elif "all_in" in a or "all-in" in a or "allin" in a:
                        self.player_stats[pid]["all_in"] += 1

            # Track profit
            delta = (remaining_chips - self.last_remaining_chips)
            self.total_profit += delta
            self.last_remaining_chips = remaining_chips
        except Exception:
            # Do not let errors propagate
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final bookkeeping; nothing special to do
        # Reset or keep stats for potential future use
        pass