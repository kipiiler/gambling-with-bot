import random
from typing import List, Tuple, Dict, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def clamp(x: int, lo: int, hi: int) -> int:
    if lo > hi:
        return lo
    return max(lo, min(hi, x))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.big_blind_id: Optional[int] = None
        self.small_blind_id: Optional[int] = None
        self.blind_amount: int = 0
        self.all_players: List[int] = []
        # Round state
        self.current_hand: Optional[List[str]] = None  # ['Ah','Kd']
        self.round_num_seen: int = -1
        # RNG for mixed strategies
        self.rng = random.Random(1337)

        # Simple stats
        self.hands_played = 0
        self.hands_won = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Store game info
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []

        # Many engines will call this at the start of each hand with new hole cards.
        # If provided, store our current two cards. If not, keep as None to enable a conservative fallback.
        try:
            if player_hands and len(player_hands) >= 2:
                self.current_hand = [str(player_hands[0]), str(player_hands[1])]
            else:
                self.current_hand = None
        except Exception:
            self.current_hand = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # New betting round within a hand
        # Reset per-round details if a new hand number is detected
        try:
            if round_state.round_num != self.round_num_seen:
                self.round_num_seen = round_state.round_num
                # Often engines will pass new hole cards via on_start. Keep current_hand unless updated there.
                self.hands_played += 1
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Basic derived values
            my_id_str = str(self.id) if self.id is not None else None
            player_bets: Dict[str, int] = round_state.player_bets or {}
            my_bet = 0
            if my_id_str is not None and my_id_str in player_bets:
                my_bet = int(player_bets.get(my_id_str, 0))
            # Fallback: if id unknown, try to deduce a default
            else:
                # If we can't identify our bet, default to 0 (safe)
                my_bet = 0

            current_bet = int(round_state.current_bet or 0)
            min_raise = int(round_state.min_raise if round_state.min_raise is not None else 0)
            max_raise = int(round_state.max_raise if round_state.max_raise is not None else remaining_chips)

            # Safety bound corrections
            if min_raise < 0:
                min_raise = 0
            if max_raise < 0:
                max_raise = 0

            pot = int(round_state.pot or 0)
            to_call = max(0, current_bet - my_bet)

            stage = (round_state.round or "").lower()  # 'preflop','flop','turn','river'

            # Number of active players (rough approximation)
            active_players = len(round_state.current_player) if round_state.current_player else max(2, len(self.all_players) or 2)

            # Compute hand strength estimate
            equity = self._estimate_equity(stage, self.current_hand, round_state.community_cards or [], active_players)

            # Pot odds
            denom = float(pot + to_call) + 1e-9
            pot_odds = float(to_call) / denom

            # If we can check
            if to_call == 0:
                # No bet to call: consider betting/raising for value or checking
                # Choose a bet size target (use min_raise as a safe baseline)
                desire_aggressive = False
                bet_size_hint = 0

                # Stage-based aggressiveness
                if stage == "preflop":
                    # Open-raise with strong range
                    if equity >= 0.72:
                        desire_aggressive = True
                        bet_size_hint = max(min_raise, int(self._safe_fraction(pot, 0.5)))
                    elif equity >= 0.62 and self.rng.random() < 0.4:
                        desire_aggressive = True
                        bet_size_hint = max(min_raise, int(self._safe_fraction(pot, 0.4)))
                    else:
                        desire_aggressive = False
                else:
                    # Postflop: value bet or semi-bluff
                    if equity >= 0.72:
                        desire_aggressive = True
                        bet_size_hint = max(min_raise, int(self._safe_fraction(pot, 0.66)))
                    elif equity >= 0.58 and self.rng.random() < 0.35:
                        desire_aggressive = True
                        bet_size_hint = max(min_raise, int(self._safe_fraction(pot, 0.5)))
                    else:
                        desire_aggressive = False

                if desire_aggressive:
                    # Compose a valid raise-to (bet) amount
                    # In many engines, a bet is represented as a raise to amount >= current_bet + min_raise
                    target = current_bet + max(min_raise, bet_size_hint)
                    raise_to = clamp(target, current_bet + max(1, min_raise), max_raise)
                    # Ensure it's a valid increase
                    if raise_to > current_bet and raise_to <= max_raise:
                        return (PokerAction.RAISE, int(raise_to))
                    # If cannot raise legally, just check
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)

            # There is a bet to call
            # Very strong hands can raise or shove; medium hands can call with proper pot odds; weak hands mostly fold
            # Aggression thresholds
            strong_margin = 0.25  # equity advantage over pot odds to start raising
            call_margin = 0.02    # minimal edge over pot odds to justify calling

            # If extremely strong hand, consider raise or all-in
            if equity - pot_odds >= strong_margin:
                # Decide raise size
                # Use a value-oriented raise on later streets, smaller preflop
                if stage == "preflop":
                    desired = current_bet + max(min_raise, int(max(to_call * 3, self._safe_fraction(pot, 0.5))))
                else:
                    desired = current_bet + max(min_raise, int(self._safe_fraction(pot, 0.75)))

                raise_to = clamp(desired, current_bet + max(1, min_raise), max_raise)

                # If we can make a legal raise
                if raise_to > current_bet and raise_to <= max_raise and raise_to - my_bet <= remaining_chips:
                    return (PokerAction.RAISE, int(raise_to))
                # Otherwise, if raise not possible, consider ALL_IN if beneficial
                if remaining_chips > 0 and max_raise > current_bet and (equity > 0.8 or self.rng.random() < 0.3):
                    return (PokerAction.ALL_IN, 0)
                # Else fallback to call
                return (PokerAction.CALL, 0)

            # Moderate strength or draws, decide to call or fold
            if equity > pot_odds + call_margin:
                return (PokerAction.CALL, 0)

            # Occasional bluff raise if to_call is small and board texture permits
            if to_call <= max(1, min_raise) and self.rng.random() < 0.05:
                desired = current_bet + max(min_raise, int(self._safe_fraction(pot, 0.5)))
                raise_to = clamp(desired, current_bet + max(1, min_raise), max_raise)
                if raise_to > current_bet and raise_to <= max_raise and raise_to - my_bet <= remaining_chips:
                    return (PokerAction.RAISE, int(raise_to))

            # Otherwise fold
            return (PokerAction.FOLD, 0)

        except Exception:
            # Fail-safe: never crash; prefer CHECK if allowed, else FOLD to avoid invalid actions
            try:
                # Attempt a safe check if possible
                if round_state is not None:
                    my_id_str = str(self.id) if self.id is not None else None
                    player_bets: Dict[str, int] = round_state.player_bets or {}
                    my_bet = 0
                    if my_id_str is not None and my_id_str in player_bets:
                        my_bet = int(player_bets.get(my_id_str, 0))
                    current_bet = int(round_state.current_bet or 0)
                    to_call = max(0, current_bet - my_bet)
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        try:
            # Simple bookkeeping, reset hand
            self.current_hand = None
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No special teardown required
        pass

    # ----------------- Helper methods -----------------

    def _safe_fraction(self, pot: int, frac: float) -> int:
        """Compute integer fraction of pot safely."""
        try:
            return int(max(1, pot * frac))
        except Exception:
            return 1

    def _rank_value(self, r: str) -> int:
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(r.upper(), 0)

    def _preflop_strength(self, hand: Optional[List[str]]) -> float:
        if not hand or len(hand) < 2:
            return 0.5
        try:
            r1, s1 = hand[0][0], hand[0][1].lower()
            r2, s2 = hand[1][0], hand[1][1].lower()
            v1 = self._rank_value(r1)
            v2 = self._rank_value(r2)
            suited = (s1 == s2)
            high = max(v1, v2)
            low = min(v1, v2)
            pair = (v1 == v2)
            gap = max(0, abs(v1 - v2) - 1)

            if pair:
                # Scale pairs from 22 to AA
                base = 0.52
                inc = (high - 2) / 12.0  # from 0 to 1
                strength = base + 0.42 * inc  # 22=0.52, AA~0.94
                return max(0.5, min(1.0, strength))

            # Non-pairs
            strength = 0.15 + 0.35 * (high / 14.0) + 0.15 * (low / 14.0)
            if suited:
                strength += 0.05
            if gap == 0:
                strength += 0.05
            elif gap == 1:
                strength += 0.02
            elif gap >= 4:
                strength -= 0.08

            # Broadway and Ax adjustments
            if high >= 13 and low >= 10:
                strength += 0.10  # two broadways
            if (r1 == 'A' or r2 == 'A'):
                if max(v1, v2) >= 13:
                    strength += 0.08
                else:
                    strength += 0.02
                if suited:
                    strength += 0.03

            return max(0.0, min(1.0, strength))
        except Exception:
            return 0.5

    def _estimate_equity(self, stage: str, hand: Optional[List[str]], board: List[str], active_players: int) -> float:
        # Preflop: use simple heuristic
        if stage == "preflop" or len(board) == 0:
            eq = self._preflop_strength(hand)
            # Slightly tighten multi-way pots
            if active_players >= 3:
                eq *= (0.95 ** (active_players - 2))
            return max(0.0, min(1.0, eq))

        # Postflop: evaluate made hands and draws
        try:
            eq = self._postflop_equity_heuristic(hand, board)
            if active_players >= 3:
                eq *= (0.93 ** (active_players - 2))
            return max(0.0, min(1.0, eq))
        except Exception:
            # Fallback if anything goes wrong
            base = self._preflop_strength(hand)
            return max(0.0, min(1.0, base * 0.9))

    def _postflop_equity_heuristic(self, hand: Optional[List[str]], board: List[str]) -> float:
        # If no hand info, play passively
        if not hand or len(hand) < 2:
            # Estimate average equity with 2+ players: be conservative
            return 0.40

        ranks_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                     '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        def card_tuple(c: str):
            return (ranks_map.get(c[0], 0), c[1].lower())

        h1, h2 = card_tuple(hand[0]), card_tuple(hand[1])
        combo = [h1, h2] + [card_tuple(c) for c in board]
        board_only = [card_tuple(c) for c in board]

        # Counts
        rank_counts: Dict[int, int] = {}
        suit_counts: Dict[str, int] = {}
        board_rank_counts: Dict[int, int] = {}
        board_suit_counts: Dict[str, int] = {}

        for (r, s) in combo:
            rank_counts[r] = rank_counts.get(r, 0) + 1
            suit_counts[s] = suit_counts.get(s, 0) + 1
        for (r, s) in board_only:
            board_rank_counts[r] = board_rank_counts.get(r, 0) + 1
            board_suit_counts[s] = board_suit_counts.get(s, 0) + 1

        my_ranks = {h1[0], h2[0]}
        my_suits = {h1[1], h2[1]}

        # Helpers
        def has_flush() -> Tuple[bool, bool]:
            # returns (flush_made, uses_hole)
            for s, cnt in suit_counts.items():
                if cnt >= 5:
                    uses = (s in my_suits)
                    return True, uses
            return False, False

        def has_straight() -> Tuple[bool, bool]:
            # returns (straight_made, uses_hole)
            ranks = set([r for r, _ in combo])
            # Ace-low
            if 14 in ranks:
                ranks.add(1)
            seq = sorted(ranks)
            longest = 1
            current = 1
            uses = False
            seq_use = False

            def in_seq_contains_mine(vals: List[int]) -> bool:
                for v in vals:
                    if v in my_ranks or (v == 1 and 14 in my_ranks):
                        return True
                return False

            for i in range(1, len(seq)):
                if seq[i] == seq[i - 1] + 1:
                    current += 1
                else:
                    if current >= 5:
                        # Determine if our cards contribute to any 5-long window
                        # Build windows and check
                        for j in range(i - current, i - 4):
                            if in_seq_contains_mine(seq[j:j + 5]):
                                seq_use = True
                        longest = max(longest, current)
                    current = 1
            if current >= 5:
                for j in range(len(seq) - current, len(seq) - 4):
                    if in_seq_contains_mine(seq[j:j + 5]):
                        seq_use = True
                longest = max(longest, current)
            return (longest >= 5), seq_use

        def made_multiples_strength() -> Tuple[float, bool]:
            # Evaluate quads/full house/trips/two pair/one pair/overpair etc.
            # Return (score, strong_made_flag)
            # Determine board top rank
            board_ranks = [r for r, _ in board_only]
            top_board = max(board_ranks) if board_ranks else 0

            # Quads
            quad_rank = None
            for r, cnt in rank_counts.items():
                if cnt == 4:
                    quad_rank = r
                    break
            if quad_rank is not None:
                uses = (quad_rank in my_ranks)
                return (0.99 if uses else 0.90, True)

            # Full house
            trips = [r for r, cnt in rank_counts.items() if cnt == 3]
            pairs = [r for r, cnt in rank_counts.items() if cnt == 2]
            if len(trips) >= 2 or (len(trips) >= 1 and len(pairs) >= 1):
                uses = any(r in my_ranks for r in trips + pairs)
                return (0.95 if uses else 0.85, True)

            # Flush / Straight handled separately

            # Trips
            if len(trips) >= 1:
                t = trips[0]
                # Determine if it's a set (pocket pair hitting board) or trips on board
                board_trip = (board_rank_counts.get(t, 0) == 3)
                uses = (t in my_ranks and not board_trip)
                if uses:
                    return (0.80, True)  # set
                else:
                    return (0.70, True)  # trips on board

            # Two pair
            total_pairs = len(pairs)
            if total_pairs >= 2:
                # Check if our hole cards contribute
                uses = any(p in my_ranks for p in pairs)
                return (0.72 if uses else 0.60, True)

            # One pair or overpair
            # Check if we pair the board
            pair_with_board = any((board_rank_counts.get(r, 0) >= 1) for r in my_ranks)
            pocket_pair = (h1[0] == h2[0])

            if pocket_pair:
                # Overpair if pocket pair > top board card
                if h1[0] > top_board:
                    return (0.70, True)  # overpair
                else:
                    return (0.62, False)

            if pair_with_board:
                # Top/middle/bottom pair
                highest_board = top_board
                if (h1[0] == highest_board) or (h2[0] == highest_board):
                    # top pair
                    kicker = max(h1[0], h2[0]) if (h1[0] == highest_board or h2[0] == highest_board) else max(h1[0], h2[0])
                    # Roughly grade kicker
                    if kicker >= 12:
                        return (0.60, False)
                    else:
                        return (0.55, False)
                # Middle or bottom
                return (0.48, False)

            # Ace high / nothing
            if h1[0] == 14 or h2[0] == 14:
                return (0.36, False)
            return (0.32, False)

        def draw_equity_bonus() -> Tuple[float, int]:
            # Returns (approx_equity_from_draws, outs)
            # Use simple rule of 4 (flop) and 2 (turn)
            stage_len = len(board)
            # Flush draw
            fd_outs = 0
            for s, cnt in suit_counts.items():
                if cnt == 4 and s in my_suits:
                    fd_outs = max(fd_outs, 9)
            # Straight draw
            sd_outs = 0
            ranks = set([r for r, _ in combo])
            if 14 in ranks:
                ranks.add(1)
            seq = sorted(ranks)

            def is_oesd() -> bool:
                # Check windows of length 4
                for i in range(len(seq) - 3):
                    if seq[i + 3] - seq[i] == 3:
                        # Contains 4 consecutive ranks
                        # Ensure at least one of our ranks is relevant
                        window = set(seq[i:i + 4])
                        if (my_ranks & window):
                            return True
                return False

            def is_gutshot() -> bool:
                # A gutshot exists if in any 5-length range there are 4 ranks
                all_r = set(seq)
                # Build candidate windows from 1 to 14
                universe = list(range(1, 15))
                for i in range(0, len(universe) - 4):
                    window = set(universe[i:i + 5])
                    cnt = len(window & all_r)
                    if cnt == 4 and (len((my_ranks & window)) > 0):
                        return True
                return False

            if is_oesd():
                sd_outs = max(sd_outs, 8)
            elif is_gutshot():
                sd_outs = max(sd_outs, 4)

            outs = fd_outs + sd_outs
            if outs <= 0:
                return (0.0, 0)

            if stage_len == 3:
                # Flop -> two cards to come, Rule of 4
                eq = min(1.0, outs * 0.04 + 0.0)
            elif stage_len == 4:
                # Turn -> one card to come, Rule of 2
                eq = min(1.0, outs * 0.02 + 0.0)
            else:
                eq = min(1.0, outs * 0.02)

            return (eq, outs)

        # Made hands
        flush_made, flush_uses = has_flush()
        straight_made, straight_uses = has_straight()
        multiples_score, strong_made = made_multiples_strength()

        made_score = multiples_score
        # Adjust for flush/straight if stronger than multiples_score
        if flush_made:
            made_score = max(made_score, 0.90 if flush_uses else 0.75)
        if straight_made:
            made_score = max(made_score, 0.88 if straight_uses else 0.70)

        # If we have a strong made hand, weight heavily
        if made_score >= 0.70:
            return made_score

        # Otherwise, consider draws
        draw_eq, outs = draw_equity_bonus()
        # Blend base made score (like one pair or worse) with drawing equity
        base = made_score
        # If no made pair at all, base might be ~0.32 - 0.36
        # Blend with draws: weighted average
        combined = max(base, base * 0.6 + draw_eq * 0.6)
        return max(0.0, min(1.0, combined))