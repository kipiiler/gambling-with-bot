from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Simple, robust No-Limit Texas Hold'em bot using heuristic strategies.
# Focus: Valid actions, tight-aggressive preflop, value/semi-bluff on later streets,
# and pot-odds-based decisions with error-safe bounds.

RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
              '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/seat info
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Round state tracking
        self.hole_cards: List[str] = []  # Current hole cards
        self.last_round_num: int = -1

        # Stats
        self.total_hands: int = 0
        self.total_profit: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize on game start (or hand start if environment calls each hand)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players else []
        # Update hole cards if provided
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.hole_cards = player_hands[:2]
        else:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-specific as needed
        # Attempt to keep hole cards if environment provides them via on_start only.
        if round_state.round_num != self.last_round_num:
            self.last_round_num = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive guards
        try:
            my_bet = self._get_my_bet(round_state.player_bets)
            # Call amount needed to continue
            call_amount = max(0, int(round_state.current_bet) - int(my_bet))
            can_check = (call_amount == 0)
            pot = max(0, int(round_state.pot))
            min_raise = max(0, int(round_state.min_raise))
            max_raise = max(0, int(round_state.max_raise))
            # Count active players (fallback safe)
            active_players = round_state.current_player if isinstance(round_state.current_player, list) else []
            num_active = max(1, len(active_players))

            board = list(round_state.community_cards) if round_state.community_cards else []

            # If hole cards unknown (robust fallback), play super tight: fold to bets, check otherwise.
            if not self._valid_hole_cards(self.hole_cards):
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    # Avoid leaks without knowledge
                    if call_amount <= max(1, self.blind_amount):  # tiny call tolerance
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

            stage = (round_state.round or "").strip().lower()

            # Compute hand strength and draw info
            hs, info = self._hand_strength(self.hole_cards, board)

            # Preflop strategy (Chen score based)
            if stage in ("preflop", "pre-flop", "prefop", "pre flop"):
                chen = info.get("chen_score", 0.0)
                # Heads-up widen ranges
                heads_up = (num_active <= 2)
                strong_thr = 9.5 if not heads_up else 7.5
                medium_thr = 7.5 if not heads_up else 6.0
                marginal_thr = 6.0 if not heads_up else 4.5

                if can_check:
                    # Open or overlimp decisions
                    if chen >= strong_thr:
                        # Raise for value
                        amt = self._choose_raise_amount(round_state, pot, desired_frac=0.75)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                        return PokerAction.CHECK, 0
                    elif chen >= medium_thr:
                        # Small raise or check
                        amt = self._choose_raise_amount(round_state, pot, desired_frac=0.5)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Facing a bet
                    pot_odds = self._pot_odds(call_amount, pot)
                    if chen >= strong_thr + 1.0:
                        # Strong range: prefer raise over call
                        # If raise is not available, call.
                        if min_raise > 0 and max_raise >= min_raise:
                            # Size up raise with at least 3x call if possible
                            desired = max(min_raise, min(max_raise, max(call_amount * 2, int(pot * 0.75))))
                            if desired >= min_raise:
                                return PokerAction.RAISE, desired
                        # Otherwise call if safe
                        if call_amount <= remaining_chips:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    elif chen >= medium_thr:
                        # Medium range: call if pot-odds favorable
                        if hs > pot_odds + 0.05 and call_amount <= remaining_chips:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    elif chen >= marginal_thr and call_amount <= max(1, self.blind_amount):
                        # Defend cheaply
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

            # Postflop strategy (Flop, Turn, River)
            made = info.get("made", "highcard")
            flush_draw = info.get("flush_draw", False)
            oesd = info.get("oesd", False)
            gutshot = info.get("gutshot", False)
            very_strong = made in ("straight", "flush", "fullhouse", "quads", "straightflush")
            strong_made = very_strong or made in ("trips", "twopair", "overpair", "toppair")

            # Aggression tuning
            if can_check:
                # Bet for value or as semi-bluff when we have equity
                if hs >= 0.80 or very_strong:
                    amt = self._choose_raise_amount(round_state, pot, desired_frac=0.66)
                    if amt is not None:
                        return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                elif hs >= 0.60 or (flush_draw or oesd):
                    # Semi-bluff or value protection
                    amt = self._choose_raise_amount(round_state, pot, desired_frac=0.5)
                    if amt is not None:
                        return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # Facing bet: pot odds decision
                pot_odds = self._pot_odds(call_amount, pot)
                if hs >= 0.90 and remaining_chips <= max(self.blind_amount * 150, pot * 2):
                    # Jam with monsters in small SPR spots
                    if remaining_chips > 0:
                        return PokerAction.ALL_IN, 0
                if hs >= 0.80 or very_strong:
                    # Raise for value
                    if min_raise > 0 and max_raise >= min_raise:
                        desired = max(min_raise, min(max_raise, max(call_amount * 2, int(pot * 0.75))))
                        return PokerAction.RAISE, desired
                    else:
                        if call_amount <= remaining_chips:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                # Drawing odds
                if flush_draw or oesd:
                    # Approx draw equity ~ 32% (FD), ~31% (OESD) on flop, lower on turn.
                    # Call if pot odds reasonable
                    equity_est = 0.32 if flush_draw else 0.31
                    # On turn reduce slightly
                    if stage == "turn":
                        equity_est -= 0.08
                    if equity_est > pot_odds - 0.02 and call_amount <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        # Semi-bluff raise sometimes if cheap
                        if min_raise > 0 and max_raise >= min_raise and call_amount < max(self.blind_amount * 10, pot * 0.33):
                            desired = max(min_raise, min(max_raise, int(pot * 0.5)))
                            return PokerAction.RAISE, desired
                        return PokerAction.FOLD, 0

                # Made but marginal: call if odds good
                if strong_made:
                    if hs > pot_odds + 0.05 and call_amount <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        # Occasionally protect vs small bets
                        if call_amount <= max(self.blind_amount * 2, pot * 0.15) and min_raise > 0 and max_raise >= min_raise:
                            desired = max(min_raise, min(max_raise, int(pot * 0.5)))
                            return PokerAction.RAISE, desired
                        return PokerAction.FOLD, 0

                # Weak made hand or air: fold to significant pressure
                if hs > pot_odds + 0.15 and call_amount <= max(remaining_chips, self.blind_amount * 2):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        except Exception:
            # Fail-safe: never crash, always return valid conservative action
            # If we can check, do so; otherwise fold to avoid invalid state.
            try:
                my_bet = self._get_my_bet(getattr(round_state, "player_bets", {}))
                call_amount = max(0, int(getattr(round_state, "current_bet", 0)) - int(my_bet))
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Small tolerance call if tiny
                    if call_amount <= max(1, self.blind_amount):
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track bankroll change if possible
        self.total_hands += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No-op: environment handles scoring
        pass

    # --------------- Helper methods ---------------

    def _get_my_bet(self, player_bets: Dict[str, int]) -> int:
        """Safely get this bot's current committed bet from round_state."""
        if not player_bets:
            return 0
        # Keys may be strings of IDs
        key_str = str(self.id) if self.id is not None else None
        if key_str and key_str in player_bets:
            try:
                return int(player_bets[key_str])
            except Exception:
                return 0
        # Try int key fallback
        if self.id in player_bets:
            try:
                return int(player_bets[self.id])
            except Exception:
                return 0
        # Fallback: 0
        return 0

    def _valid_hole_cards(self, cards: List[str]) -> bool:
        return isinstance(cards, list) and len(cards) >= 2 and self._is_valid_card(cards[0]) and self._is_valid_card(cards[1])

    def _is_valid_card(self, c: str) -> bool:
        if not isinstance(c, str) or len(c) < 2:
            return False
        r, s = self._split_card(c)
        return r in RANK_ORDER and s in ('h', 'd', 'c', 's')

    def _split_card(self, c: str) -> Tuple[str, str]:
        c = c.strip()
        if len(c) == 3 and c[0:2] == '10':
            return 'T', c[2].lower()
        return c[0].upper(), c[1].lower()

    def _rank(self, c: str) -> int:
        r, _ = self._split_card(c)
        return RANK_ORDER.get(r, 0)

    def _suit(self, c: str) -> str:
        _, s = self._split_card(c)
        return s

    def _chen_score(self, hole: List[str]) -> float:
        # Chen formula approximation
        if not self._valid_hole_cards(hole):
            return 0.0
        r1 = self._rank(hole[0])
        r2 = self._rank(hole[1])
        s1 = self._suit(hole[0])
        s2 = self._suit(hole[1])
        hi = max(r1, r2)
        lo = min(r1, r2)

        # Base for highest card
        base_map = {14: 10, 13: 8, 12: 7, 11: 6, 10: 5, 9: 4.5, 8: 4, 7: 3.5, 6: 3, 5: 2.5, 4: 2, 3: 1.5, 2: 1}
        score = base_map.get(hi, 0)

        # Pair
        if r1 == r2:
            score = max(score * 2, 5)

        # Suited
        if s1 == s2:
            score += 2

        # Gaps
        gap = hi - lo - 1
        if gap <= 0:
            gap_pen = 0
        elif gap == 1:
            gap_pen = 1
        elif gap == 2:
            gap_pen = 2
        elif gap == 3:
            gap_pen = 4
        else:
            gap_pen = 5
        score -= gap_pen

        # Small card no gap bonus
        if r1 != r2 and (s1 == s2 or gap <= 1) and hi < 12:
            score += 1

        return max(0.0, score)

    def _hand_strength(self, hole: List[str], board: List[str]) -> Tuple[float, Dict[str, Any]]:
        # Returns (strength in [0,1], info dict)
        info: Dict[str, Any] = {}
        if not self._valid_hole_cards(hole):
            return 0.2, info

        if not board or len(board) < 3:
            # Preflop only
            chen = self._chen_score(hole)
            info["chen_score"] = chen
            # Normalize: Chen up to ~20
            hs = min(1.0, chen / 20.0)
            info["made"] = "preflop"
            return hs, info

        # Postflop eval heuristics
        cards = hole + board
        ranks = [self._rank(c) for c in cards]
        suits = [self._suit(c) for c in cards]
        board_ranks = [self._rank(c) for c in board]
        board_suits = [self._suit(c) for c in board]
        hole_ranks = [self._rank(c) for c in hole]
        hole_suits = [self._suit(c) for c in hole]

        # Count ranks
        from collections import Counter
        rank_count = Counter(ranks)
        board_rank_count = Counter(board_ranks)

        # Flush made/draw
        suit_count = Counter(suits)
        board_suit_count = Counter(board_suits)
        flush_suit = None
        for s, cnt in suit_count.items():
            if cnt >= 5:
                flush_suit = s
                break
        made_flush = flush_suit is not None
        flush_draw = False
        flush_draw_suit = None
        for s, cnt in suit_count.items():
            if cnt == 4 and s in hole_suits:
                flush_draw = True
                flush_draw_suit = s
                break
        # Consider board 4-flush that includes at least one of our cards for draw
        if not flush_draw:
            for s, cnt in board_suit_count.items():
                if cnt == 4 and s in hole_suits:
                    flush_draw = True
                    flush_draw_suit = s
                    break

        # Straight made/draw
        unique_ranks = sorted(set(ranks))
        has_straight = self._has_straight(unique_ranks)
        oesd, gutshot = self._straight_draw(unique_ranks)

        # Pairs/trips/quads and top pair determination
        max_dup = max(rank_count.values()) if rank_count else 1
        pocket_pair = (hole_ranks[0] == hole_ranks[1])
        highest_board = max(board_ranks) if board_ranks else 0
        made = "highcard"

        if made_flush and has_straight:
            made = "straightflush"
        elif max_dup == 4:
            made = "quads"
        elif self._has_full_house(rank_count, board_rank_count):
            made = "fullhouse"
        elif made_flush:
            made = "flush"
        elif has_straight:
            made = "straight"
        elif max_dup == 3:
            made = "trips"
        else:
            # Pairs logic
            pair_ranks = [r for r, cnt in rank_count.items() if cnt == 2]
            board_pair_ranks = [r for r, cnt in board_rank_count.items() if cnt == 2]
            if len(pair_ranks) >= 2 or (len(pair_ranks) == 1 and len(board_pair_ranks) == 1 and pair_ranks[0] != board_pair_ranks[0]):
                made = "twopair"
            elif len(pair_ranks) == 1:
                pr = pair_ranks[0]
                if pocket_pair and pr == hole_ranks[0] and pr > highest_board:
                    made = "overpair"
                else:
                    # Pair with board
                    if pr in hole_ranks and pr in board_ranks:
                        if pr == highest_board:
                            made = "toppair"
                        else:
                            # Second/third pair is marginal
                            second = sorted(set(board_ranks))[-2] if len(set(board_ranks)) >= 2 else 0
                            if pr >= second:
                                made = "secondpair"
                            else:
                                made = "pair"
                    elif pocket_pair and pr == hole_ranks[0]:
                        made = "underpair"
                    else:
                        made = "pair"
            else:
                made = "highcard"

        info["made"] = made
        info["flush_draw"] = flush_draw and not made_flush
        info["oesd"] = oesd and not has_straight
        info["gutshot"] = gutshot and not has_straight

        # Base strengths for made hands
        strength_map = {
            "straightflush": 0.98,
            "quads": 0.95,
            "fullhouse": 0.92,
            "flush": 0.88,
            "straight": 0.85,
            "trips": 0.80,
            "twopair": 0.75,
            "overpair": 0.73,
            "toppair": 0.66,
            "secondpair": 0.55,
            "pair": 0.50,
            "underpair": 0.45,
            "highcard": 0.30,
        }
        hs = strength_map.get(made, 0.30)

        # Draw adjustments
        if info["flush_draw"]:
            hs += 0.15
            # Slight boost for nut draws
            if 'a' in ''.join(self._split_card(c)[0].lower() for c in hole if self._suit(c) == flush_draw_suit):
                hs += 0.03
        if info["oesd"]:
            hs += 0.12
        elif info["gutshot"]:
            hs += 0.06

        # Cap
        hs = max(0.0, min(0.99, hs))
        return hs, info

    def _has_straight(self, unique_ranks: List[int]) -> bool:
        if not unique_ranks:
            return False
        # Treat Ace low
        ranks = set(unique_ranks)
        if 14 in ranks:
            ranks.add(1)
        seq = sorted(ranks)
        count = 0
        last = None
        for r in seq:
            if last is None or r == last + 1:
                count += 1
            elif r != last:
                count = 1
            last = r
            if count >= 5:
                return True
        return False

    def _straight_draw(self, unique_ranks: List[int]) -> Tuple[bool, bool]:
        # Determine OESD (need one of two ends) or gutshot (inside) approx
        if not unique_ranks:
            return False, False
        ranks = set(unique_ranks)
        if 14 in ranks:
            ranks.add(1)
        oesd = False
        gut = False
        # Check all windows of 5
        for low in range(1, 11):  # 1..10 corresponds to A..T as low
            window = {low, low + 1, low + 2, low + 3, low + 4}
            present = len(window & ranks)
            if present == 4:
                # Missing rank
                missing = list(window - ranks)[0]
                # If missing is an end, it's OESD; else gutshot
                if missing in (low, low + 4):
                    oesd = True
                else:
                    gut = True
        return oesd, gut

    def _has_full_house(self, rank_count: Dict[int, int], board_rank_count: Dict[int, int]) -> bool:
        trips = [r for r, c in rank_count.items() if c >= 3]
        pairs = [r for r, c in rank_count.items() if c >= 2 and r not in trips]
        if trips and (pairs or len(trips) >= 2):
            return True
        # Also consider board making it (board FH still counts as our hand)
        b_trips = [r for r, c in board_rank_count.items() if c >= 3]
        b_pairs = [r for r, c in board_rank_count.items() if c >= 2 and r not in b_trips]
        if b_trips and (b_pairs or len(b_trips) >= 2):
            return True
        return False

    def _pot_odds(self, call_amount: int, pot: int) -> float:
        denom = float(pot + call_amount) if (pot + call_amount) > 0 else 1.0
        return max(0.0, min(1.0, float(call_amount) / denom))

    def _choose_raise_amount(self, round_state: RoundStateClient, pot: int, desired_frac: float = 0.5) -> Optional[int]:
        # Determine a valid raise amount within [min_raise, max_raise]
        try:
            min_raise = max(0, int(round_state.min_raise))
            max_raise = max(0, int(round_state.max_raise))
            if min_raise <= 0 or max_raise < min_raise:
                return None
            # Pot-proportional desired raise (as raise increment, not total bet)
            desired = int(max(min_raise, min(max_raise, max(int(pot * desired_frac), min_raise))))
            # Safety clamp
            if desired < min_raise:
                desired = min_raise
            if desired > max_raise:
                desired = max_raise
            if desired < min_raise:
                return None
            return desired
        except Exception:
            return None