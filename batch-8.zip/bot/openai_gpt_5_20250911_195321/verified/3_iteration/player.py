import random
from typing import List, Tuple, Dict, Any, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def clamp(x: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, x))


def rank_char_to_int(r: str) -> int:
    if r.isdigit():
        return int(r)
    mapping = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    return mapping.get(r.upper(), 0)


def get_rank(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    return rank_char_to_int(card[0])


def get_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()


def card_is_valid(card: str) -> bool:
    return isinstance(card, str) and len(card) == 2 and get_rank(card) > 0 and get_suit(card) in ['c', 'd', 'h', 's']


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game-level state
        self.starting_chips: int = 0
        self.small_blind: int = 0
        self.big_blind: int = 0
        self.player_ids: List[int] = []
        self.opponent_ids: List[int] = []
        self.is_big_blind: bool = False
        self.is_small_blind: bool = False

        # Hand-level state
        self.hole_cards: List[str] = []  # e.g., ['Ah','Kd']
        self.hand_preflop_strength: float = 0.0
        self.round_num_seen: Optional[int] = None
        self.street_seen: str = ''
        self.has_cbet_this_street: bool = False

        # Opponent stats (very simple)
        self.villain_stats: Dict[str, Dict[str, int]] = {}  # keyed by player_id str
        # fields: 'faced_bet', 'folded_vs_bet', 'raised', 'acted'

        # Randomizer
        self.rng = random.Random()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.starting_chips = starting_chips
            self.small_blind = int(blind_amount)
            self.big_blind = max(2 * self.small_blind, self.small_blind * 2)  # ensure integer
            self.player_ids = list(all_players) if all_players else self.player_ids
            self.opponent_ids = [pid for pid in self.player_ids if pid != self.id]

            # blinds for this hand
            self.is_big_blind = (self.id == big_blind_player_id)
            self.is_small_blind = (self.id == small_blind_player_id)

            # Set hole cards if provided
            self.hole_cards = [c for c in player_hands if card_is_valid(c)] if player_hands else []
            if len(self.hole_cards) > 2:
                self.hole_cards = self.hole_cards[:2]
            self.hand_preflop_strength = self._estimate_preflop_strength(self.hole_cards)

            # Reset per-hand flags
            self.round_num_seen = None
            self.street_seen = ''
            self.has_cbet_this_street = False
        except Exception:
            # Ensure no exception bubbles up; in case of malformed input, reset safe defaults
            self.hole_cards = []
            self.hand_preflop_strength = 0.0
            self.is_big_blind = False
            self.is_small_blind = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        try:
            # Track street changes for per-street logic
            if self.round_num_seen is None or self.round_num_seen != round_state.round_num:
                self.round_num_seen = round_state.round_num
                self.street_seen = round_state.round
                self.has_cbet_this_street = False
            else:
                # If street changed within same hand
                if self.street_seen != round_state.round:
                    self.street_seen = round_state.round
                    self.has_cbet_this_street = False
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_id_str = str(self.id)
            # Current bet and my contribution
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(round_state.current_bet)
            amount_to_call = max(current_bet - my_bet, 0)
            min_raise = int(round_state.min_raise) if round_state.min_raise is not None else 0
            max_raise = int(round_state.max_raise) if round_state.max_raise is not None else 0
            can_check = (amount_to_call <= 0)
            can_raise = (max_raise > 0 and min_raise <= max_raise)
            pot = int(round_state.pot)
            community = list(round_state.community_cards or [])
            street = (round_state.round or 'Preflop')

            # Defensive: if no chips or no actions available, check/fold logic
            if remaining_chips <= 0:
                return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

            num_active = len(round_state.current_player) if round_state.current_player else max(2, len(self.player_ids) or 2)
            heads_up = (num_active <= 2)

            # If we weren't provided hole cards, try to proceed with info-lite strategy
            have_cards = len(self.hole_cards) == 2 and all(card_is_valid(c) for c in self.hole_cards)

            # Update simple opponent model (optional, very lightweight)
            self._update_villain_model(round_state)

            # Decide based on street
            if street.lower() == 'preflop':
                action, amount = self._decide_preflop(amount_to_call, min_raise, max_raise, can_check, can_raise, pot, heads_up)
                if action is not None:
                    return action, amount

            else:
                # Postflop decisions
                action, amount = self._decide_postflop(community, amount_to_call, min_raise, max_raise, can_check, can_raise, pot, heads_up, have_cards)
                if action is not None:
                    return action, amount

            # Fallback safety
            if can_check:
                return PokerAction.CHECK, 0
            else:
                # If we have to act and cannot check, fold if the call is big, else call small bets
                if amount_to_call <= max(self.big_blind, 2 * self.small_blind):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        except Exception:
            # Never crash; fail-safe conservative
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track opponent reactions for future hands
        try:
            self._update_villain_model(round_state)
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: could adjust strategy parameters based on performance
        pass

    # ---------- Strategy Helpers ----------

    def _decide_preflop(self, amount_to_call: int, min_raise: int, max_raise: int, can_check: bool, can_raise: bool,
                        pot: int, heads_up: bool) -> Tuple[Optional[PokerAction], int]:
        # Use hole cards if available; otherwise, use a safe mixed strategy
        strength = self.hand_preflop_strength if self.hole_cards else 0.35  # assume average if unknown

        # Define simple thresholds (tighter when multiway)
        tighten = 0.05 if not heads_up else 0.0
        premium_thr = 0.80 - tighten
        good_thr = 0.65 - tighten
        playable_thr = 0.50 - tighten

        # Aggression frequencies
        open_freq = 0.55 if heads_up else 0.35
        call_freq_small = 0.35 if heads_up else 0.20
        three_bet_freq = 0.12 if heads_up else 0.08

        # Determine if we face a bet/raise or just blinds/limps
        if amount_to_call == 0:
            # Can check or bet/raise
            if can_raise:
                # Decide to raise as open or iso from BB vs limp
                want_raise = False
                if strength >= premium_thr:
                    want_raise = True
                elif strength >= good_thr and self.rng.random() < 0.8:
                    want_raise = True
                elif strength >= playable_thr and self.rng.random() < open_freq:
                    want_raise = True

                if want_raise:
                    # Preflop open size ~ 2.5-3 bb
                    target_to = int(self.big_blind * (2.5 if heads_up else 3.0))
                    raise_to = clamp(max(min_raise, target_to), min_raise, max_raise)
                    if raise_to > 0 and raise_to >= min_raise:
                        self.has_cbet_this_street = True
                        return PokerAction.RAISE, int(raise_to)

            # Otherwise check
            return PokerAction.CHECK, 0
        else:
            # Facing a bet/raise
            # If the amount to call is small relative to pot, call more often with playable hands
            pot_plus_call = pot + amount_to_call
            pot_plus_call = pot_plus_call if pot_plus_call > 0 else 1
            pot_odds = amount_to_call / (pot_plus_call + 1e-9)

            if strength >= premium_thr:
                # Prefer 3-bet with some frequency if allowed
                if can_raise and self.rng.random() < max(three_bet_freq, 0.25):
                    # 3-bet size: ~2.5x current_bet if possible
                    target_to = int(max(min_raise, (amount_to_call + max(self.big_blind, amount_to_call)) * 2.5))
                    raise_to = clamp(target_to, min_raise, max_raise)
                    if raise_to > 0 and raise_to >= min_raise:
                        return PokerAction.RAISE, int(raise_to)
                # Otherwise call
                return PokerAction.CALL, 0

            if strength >= good_thr:
                # Mix call and occasional 3-bet
                if can_raise and self.rng.random() < three_bet_freq:
                    target_to = int(max(min_raise, (amount_to_call + max(self.big_blind, amount_to_call)) * 2.25))
                    raise_to = clamp(target_to, min_raise, max_raise)
                    if raise_to > 0 and raise_to >= min_raise:
                        return PokerAction.RAISE, int(raise_to)
                # Call if pot odds are decent
                if pot_odds <= 0.40 or self.rng.random() < 0.6:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            if strength >= playable_thr:
                # Call small bets more often; fold to large ones
                if amount_to_call <= self.big_blind * 2 and self.rng.random() < call_freq_small:
                    return PokerAction.CALL, 0
                # If pot odds are very favorable, call
                if pot_odds <= 0.25 and self.rng.random() < 0.5:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Weak hand: mostly fold unless very cheap
            if amount_to_call <= self.small_blind and self.rng.random() < 0.15:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _decide_postflop(self, community: List[str], amount_to_call: int, min_raise: int, max_raise: int, can_check: bool,
                         can_raise: bool, pot: int, heads_up: bool, have_cards: bool) -> Tuple[Optional[PokerAction], int]:
        # Very lightweight hand category eval if we have our cards; otherwise use info-lite heuristics.
        category = 'unknown'
        if have_cards:
            category = self._postflop_category(self.hole_cards, community)

        # Base bet sizes
        bet_half_pot = int(max(self.small_blind, pot * 0.50))
        bet_two_thirds = int(max(self.small_blind, pot * 0.66))
        bet_large = int(max(self.small_blind, pot * 0.80))

        # Heads up, we can be slightly more aggressive
        cbet_freq = 0.60 if heads_up else 0.45
        turn_cbet_freq = 0.50 if heads_up else 0.35
        river_cbet_freq = 0.40 if heads_up else 0.25

        # Choose default fraction based on street name via pot size
        street_lower = self.street_seen.lower() if self.street_seen else ''
        if 'flop' in street_lower:
            default_bet = bet_two_thirds
            cbet_threshold = cbet_freq
        elif 'turn' in street_lower:
            default_bet = bet_half_pot
            cbet_threshold = turn_cbet_freq
        else:
            default_bet = bet_half_pot
            cbet_threshold = river_cbet_freq

        # Convert bet amount to raise_to (total bet for the street):
        def raise_to_from_bet(desired_bet: int, current_bet: int, my_contribution: int) -> int:
            # desired_bet: how much we want to put in this street in total if no prior bet (i.e., bet size)
            # If there is an existing current_bet > 0, a raise_to should be current_bet + raise_size
            # But we lack raise_size -> use desired_bet as raise_size when raising over an existing bet
            if current_bet <= 0:
                # First bet this street: raise_to equals desired_bet
                target = desired_bet
            else:
                target = current_bet + desired_bet
            return clamp(max(min_raise, int(target)), min_raise, max_raise)

        # If we have a strong or very strong made hand -> bet or raise for value
        if category in ('nut', 'strong'):
            if amount_to_call > 0:
                if can_raise:
                    # Value raise
                    target = raise_to_from_bet(bet_two_thirds if category == 'strong' else bet_large, amount_to_call + (pot - amount_to_call), 0)
                    return PokerAction.RAISE, int(target)
                else:
                    return PokerAction.CALL, 0
            else:
                if can_raise:
                    target = raise_to_from_bet(default_bet, 0, 0)
                    if target >= min_raise:
                        self.has_cbet_this_street = True
                        return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0

        # Medium strength -> pot control and call reasonable bets
        if category == 'medium':
            if amount_to_call == 0:
                # Sometimes protection bet, otherwise check back
                if can_raise and self.rng.random() < (0.35 if heads_up else 0.25):
                    target = raise_to_from_bet(int(pot * 0.40), 0, 0)
                    if target >= min_raise:
                        self.has_cbet_this_street = True
                        return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
            else:
                # Call small to medium bets, fold to big bets
                pot_plus_call = pot + amount_to_call
                pot_plus_call = pot_plus_call if pot_plus_call > 0 else 1
                bet_fraction = amount_to_call / (pot_plus_call + 1e-9)
                if bet_fraction <= 0.30:
                    return PokerAction.CALL, 0
                elif bet_fraction <= 0.55 and self.rng.random() < 0.5:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Draw -> semi-bluff sometimes, call small bets
        if category == 'draw':
            if amount_to_call == 0:
                if can_raise and self.rng.random() < (0.55 if heads_up else 0.45):
                    target = raise_to_from_bet(int(pot * 0.50), 0, 0)
                    if target >= min_raise:
                        self.has_cbet_this_street = True
                        return PokerAction.RAISE, int(target)
                return PokerAction.CHECK, 0
            else:
                # Call if bet is small/medium, occasionally semi-bluff raise
                pot_plus_call = pot + amount_to_call
                pot_plus_call = pot_plus_call if pot_plus_call > 0 else 1
                bet_fraction = amount_to_call / (pot_plus_call + 1e-9)
                if bet_fraction <= 0.35:
                    return PokerAction.CALL, 0
                elif can_raise and bet_fraction <= 0.55 and self.rng.random() < 0.25:
                    target = raise_to_from_bet(int(pot * 0.60), amount_to_call, 0)
                    if target >= min_raise:
                        return PokerAction.RAISE, int(target)
                else:
                    return PokerAction.FOLD, 0

        # Unknown or weak -> c-bet frequencies when checked to, otherwise fold to aggression
        if amount_to_call == 0:
            # Consider a bluff c-bet
            if can_raise and not self.has_cbet_this_street and self.rng.random() < cbet_threshold:
                target = raise_to_from_bet(default_bet, 0, 0)
                if target >= min_raise:
                    self.has_cbet_this_street = True
                    return PokerAction.RAISE, int(target)
            return PokerAction.CHECK, 0
        else:
            # Facing a bet: mostly fold weak hands, occasionally call tiny bets heads-up
            pot_plus_call = pot + amount_to_call
            pot_plus_call = pot_plus_call if pot_plus_call > 0 else 1
            bet_fraction = amount_to_call / (pot_plus_call + 1e-9)
            if bet_fraction <= 0.20 and heads_up and self.rng.random() < 0.35:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def _estimate_preflop_strength(self, cards: List[str]) -> float:
        # Returns a rough strength value in [0,1]
        if not cards or len(cards) < 2 or not all(card_is_valid(c) for c in cards):
            return 0.35  # unknown or invalid -> average-ish

        r1, r2 = get_rank(cards[0]), get_rank(cards[1])
        s1, s2 = get_suit(cards[0]), get_suit(cards[1])
        high = max(r1, r2)
        low = min(r1, r2)
        pair = (r1 == r2)
        suited = (s1 == s2)
        gap = abs(r1 - r2)
        strength = 0.0

        if pair:
            # Pairs: scale from 22 to AA
            strength = 0.55 + (high - 2) / 12.0 * 0.40  # 22->0.55, AA->0.95
        else:
            # High card bonus (broadways)
            strength += (high - 9) / 5.0 * 0.25 if high >= 10 else 0.0  # T or higher
            # Suited bonus
            if suited:
                strength += 0.06
            # Connectivity bonus
            if gap == 1:
                strength += 0.05
            elif gap == 2:
                strength += 0.03
            elif gap == 3:
                strength += 0.015
            # Ace-x suited wheel bonus
            if high == 14 and suited and low <= 5:
                strength += 0.03
            # Penalty for very weak offsuit ragged
            if high <= 9 and gap >= 4 and not suited:
                strength -= 0.05

        # Clamp to [0,1]
        strength = max(0.0, min(1.0, strength))
        return strength

    def _postflop_category(self, hole: List[str], board: List[str]) -> str:
        # Very lightweight made hand categorization: 'nut', 'strong', 'medium', 'draw', 'weak'
        # This is heuristic and not a full evaluator.
        cards = [c for c in hole if card_is_valid(c)] + [c for c in board if card_is_valid(c)]
        if len(cards) < len(hole):
            return 'weak'

        # Rank and suit counts
        rank_counts: Dict[int, int] = {}
        suit_counts: Dict[str, int] = {}
        for c in cards:
            r = get_rank(c)
            s = get_suit(c)
            rank_counts[r] = rank_counts.get(r, 0) + 1
            suit_counts[s] = suit_counts.get(s, 0) + 1

        board_ranks = [get_rank(c) for c in board if card_is_valid(c)]
        top_board = max(board_ranks) if board_ranks else 0
        hole_ranks = [get_rank(c) for c in hole]
        hole_suits = [get_suit(c) for c in hole]

        # Detect flush and flush draw
        flush_suit = None
        for s, cnt in suit_counts.items():
            if cnt >= 5:
                flush_suit = s
                break
        has_flush = False
        if flush_suit:
            # ensure we participate in the flush (at least one hole of that suit)
            if flush_suit in hole_suits:
                has_flush = True

        # Flush draw (4 to a flush) using our hole cards
        have_flush_draw = False
        for s in ['c', 'd', 'h', 's']:
            if (hole_suits.count(s) >= 1) and (sum(1 for c in board if get_suit(c) == s) + hole_suits.count(s) >= 4):
                have_flush_draw = True
                break

        # Detect straight presence (simplified)
        ranks_unique = sorted(set(rank_counts.keys()))
        # Handle Ace-low straight possibility by adding rank 1 if Ace present
        if 14 in ranks_unique:
            ranks_unique = sorted(set(ranks_unique + [1]))

        def has_straight(ranks: List[int]) -> bool:
            if len(ranks) < 5:
                return False
            streak = 1
            for i in range(1, len(ranks)):
                if ranks[i] == ranks[i - 1] + 1:
                    streak += 1
                    if streak >= 5:
                        return True
                elif ranks[i] != ranks[i - 1]:
                    streak = 1
            return False

        have_straight = has_straight(ranks_unique)

        # Straight draw (open-ended or gutshot simplified)
        def has_straight_draw(ranks: List[int]) -> bool:
            if len(ranks) < 4:
                return False
            # Check for sequences with one gap over windows of size 5
            for start in range(min(ranks), max(ranks) - 3):
                window = {start, start + 1, start + 2, start + 3, start + 4}
                count_hit = len(window.intersection(set(ranks)))
                if count_hit >= 4:
                    return True
            return False

        have_straight_draw = has_straight_draw(ranks_unique)

        # Made hand categories
        # Count our pairings
        pair_with_board = False
        top_pair = False
        overpair = False
        two_pair_or_better = False
        trips_or_better = False

        # Combine counts
        # Determine if we have pair using one of our hole cards
        for hr in hole_ranks:
            if rank_counts.get(hr, 0) >= 2:
                pair_with_board = True
                # Trips if we have pocket pair and there's same on board or board has pair and we match one
                if rank_counts.get(hr, 0) >= 3:
                    trips_or_better = True

        # Check pocket pair and overpair
        if hole_ranks[0] == hole_ranks[1]:
            # pocket pair
            if hole_ranks[0] > top_board:
                overpair = True
            if rank_counts.get(hole_ranks[0], 0) >= 3:
                trips_or_better = True

        # Two pair detection: if both hole ranks appear at least once in combined (including board), or one of them pairs with board and board pairs with the other
        distinct_hole = hole_ranks[0] != hole_ranks[1]
        if distinct_hole and rank_counts.get(hole_ranks[0], 0) >= 2 and rank_counts.get(hole_ranks[1], 0) >= 2:
            two_pair_or_better = True
        # Board pairs plus our matching card
        board_rank_counts: Dict[int, int] = {}
        for br in board_ranks:
            board_rank_counts[br] = board_rank_counts.get(br, 0) + 1
        board_has_pair = any(v >= 2 for v in board_rank_counts.values())
        if board_has_pair and pair_with_board:
            # trips possible or two pair with board
            if trips_or_better:
                pass
            else:
                two_pair_or_better = True

        # Top pair
        if top_board in hole_ranks and top_board > 0 and rank_counts.get(top_board, 0) >= 2:
            top_pair = True

        # Decide category
        if have_straight or has_flush or trips_or_better or two_pair_or_better:
            return 'nut'  # treat strong made hands as 'nut' for betting logic
        if overpair or top_pair:
            return 'strong'
        if pair_with_board:
            return 'medium'
        if have_flush_draw or have_straight_draw:
            return 'draw'
        return 'weak'

    def _update_villain_model(self, round_state: RoundStateClient):
        # Very simple tracker: how often others fold to a street, raise, etc. Based on last known actions.
        if not round_state or not round_state.player_actions:
            return
        for pid_str, action in round_state.player_actions.items():
            if pid_str == str(self.id):
                continue
            stats = self.villain_stats.setdefault(pid_str, {'faced_bet': 0, 'folded_vs_bet': 0, 'raised': 0, 'acted': 0})
            stats['acted'] += 1
            a = (action or '').lower()
            if 'raise' in a:
                stats['raised'] += 1
            # Heuristic: if action is Fold and there was likely a bet, count as folded_vs_bet
            if 'fold' in a:
                stats['folded_vs_bet'] += 1
            # faced_bet count rough approximation using whether current_bet>0; not precise but lightweight
            if round_state.current_bet and round_state.current_bet > 0:
                stats['faced_bet'] += 1