from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session level
        self.starting_chips: int = 0
        self.initial_blind_amount: int = 0  # As provided by server (likely big blind at start)
        self.small_blind_player_id: Optional[int] = None
        self.big_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.is_heads_up: bool = False

        # Hand/round level
        self.round_num: int = 0
        self.street: str = ""
        self.my_bet_start: int = 0
        self.bb_amount_current: int = 0
        self.sb_amount_current: int = 0

        # Aggression tracking
        self.was_preflop_raiser: bool = False

        # Randomization for mixed strategies
        self.rng = random.Random(1337)

        # Hole cards handling (best-effort; environment-dependent)
        self.last_known_hole_cards: Optional[List[str]] = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize session parameters
        self.starting_chips = starting_chips
        self.initial_blind_amount = blind_amount if blind_amount is not None else 0
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.is_heads_up = len(self.all_players) == 2

        # Try to capture hole cards if provided (environment-specific)
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            # Expecting something like ['As', 'Kd']
            self.last_known_hole_cards = player_hands[:2]
        else:
            self.last_known_hole_cards = None

        # Reset per-hand trackers
        self.was_preflop_raiser = False
        self.my_bet_start = 0
        self.bb_amount_current = self.initial_blind_amount
        self.sb_amount_current = max(1, self.initial_blind_amount // 2)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Called at the start of each hand or street; do per-hand resets on preflop
        self.round_num = getattr(round_state, "round_num", 0)
        self.street = getattr(round_state, "round", "")
        self.was_preflop_raiser = False

        # Best-effort hole cards update if environment provides them somewhere
        # Attempt to read from a non-standard attribute if present
        try:
            possible_cards = getattr(round_state, "player_hands", None)
            if isinstance(possible_cards, list) and len(possible_cards) >= 2:
                self.last_known_hole_cards = possible_cards[:2]
        except Exception:
            pass

        # At the start of preflop, attempt to infer current blinds from posted bets
        if self.street.lower() in ("preflop", "pre-flop", "pre_flop"):
            my_id_str = str(self.id) if self.id is not None else ""
            self.my_bet_start = 0
            if isinstance(round_state.player_bets, dict):
                try:
                    # Save our initial posted blind (or zero)
                    self.my_bet_start = int(round_state.player_bets.get(my_id_str, 0))
                except Exception:
                    self.my_bet_start = 0
            # Infer blinds (robust to raises not yet made at round start)
            self._infer_current_blinds(round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player.
        Always ensure actions are valid as per constraints.
        """
        # Defensive defaults
        try:
            my_id_str = str(self.id) if self.id is not None else ""
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if isinstance(round_state.player_bets, dict) else 0
            current_bet = int(round_state.current_bet) if round_state.current_bet is not None else 0
            min_raise = int(round_state.min_raise) if round_state.min_raise is not None else 0
            max_raise = int(round_state.max_raise) if round_state.max_raise is not None else remaining_chips
            pot = int(round_state.pot) if round_state.pot is not None else 0
            community = list(round_state.community_cards) if isinstance(round_state.community_cards, list) else []
        except Exception:
            # If anything goes wrong reading state, fold safely
            return PokerAction.FOLD, 0

        amount_to_call = max(0, current_bet - my_bet)
        can_check = amount_to_call == 0
        street_name = (self.street or getattr(round_state, "round", "") or "").lower()

        # Ensure basic bounds
        if remaining_chips <= 0:
            # No chips left; cannot act differently (engine may handle as all-in). Check/fold safe.
            return PokerAction.CHECK if can_check else PokerAction.FOLD, 0

        # Compute pot odds fraction (safe)
        denom = float(pot + amount_to_call) + 1e-9
        pot_odds = float(amount_to_call) / denom

        # Attempt to retrieve hole cards (environment dependent)
        hole = self._get_hole_cards_safe(round_state)

        # Decision making
        if street_name in ("preflop", "pre-flop", "pre_flop"):
            # Preflop strategy
            if hole:
                # Use preflop hand strength heuristics
                strength = self._preflop_strength(hole)
                # Opening or checking option
                if can_check:
                    # If we can check, sometimes open-raise with strong hands, otherwise check
                    if strength >= 0.75:
                        # Raise for value
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            self.was_preflop_raiser = True
                            return PokerAction.RAISE, amt
                        return PokerAction.CHECK, 0
                    elif strength >= 0.65 and self.is_heads_up and self.rng.random() < 0.25:
                        # Occasional steal HU
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            self.was_preflop_raiser = True
                            return PokerAction.RAISE, amt
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Facing a bet/raise
                    # Conservative: fold weak, call medium with good pot odds, 3-bet with very strong
                    if strength >= 0.88:
                        # 3-bet if possible, otherwise call
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            self.was_preflop_raiser = True
                            return PokerAction.RAISE, amt
                        else:
                            # If raise isn't possible, calling is fine
                            if amount_to_call <= remaining_chips:
                                return PokerAction.CALL, 0
                            else:
                                return PokerAction.ALL_IN, 0
                    elif strength >= 0.65:
                        # Call if price not too steep
                        # Avoid calling very large raises with medium strength
                        bb = max(1, self.bb_amount_current)
                        if amount_to_call <= min(remaining_chips, 5 * bb):
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    else:
                        # Mostly fold weak hands to aggression
                        # But allow very cheap completes HU when small blind (defend sometimes)
                        bb = max(1, self.bb_amount_current)
                        if self.is_heads_up and amount_to_call <= bb // 2 and self.rng.random() < 0.15:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
            else:
                # No hole card info available; play very conservative
                if can_check:
                    # Occasionally steal in HU to avoid being overly passive
                    if self.is_heads_up and self.rng.random() < 0.10:
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            self.was_preflop_raiser = True
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    # Facing a bet without cards info: fold unless it's extremely cheap and HU
                    bb = max(1, self.bb_amount_current)
                    if self.is_heads_up and amount_to_call <= bb // 2 and self.rng.random() < 0.10:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

        else:
            # Postflop strategy
            if hole:
                strength = self._postflop_strength(hole, community)
                # If we can check, occasionally stab with weak/medium on early postflop if preflop aggressor or opponent shows weakness
                if can_check:
                    # If we were the preflop raiser, make a small c-bet sometimes; stronger with stronger hands
                    stab_freq = 0.25
                    if self.was_preflop_raiser:
                        # Increase frequency if we have some strength
                        if strength >= 0.75:
                            stab_freq = 0.9
                        elif strength >= 0.6:
                            stab_freq = 0.6
                        else:
                            stab_freq = 0.35
                    # Heads-up, increase stab freq slightly
                    if self.is_heads_up:
                        stab_freq = min(1.0, stab_freq + 0.1)

                    if self.rng.random() < stab_freq:
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    # Facing a bet: decide call/fold/raise based on strength and price
                    # Use pot fraction as a sizing guide
                    call_ok = False
                    raise_ok = False

                    # Strong made hands -> continue aggressively
                    if strength >= 0.85:
                        call_ok = True
                        raise_ok = True
                    elif strength >= 0.7:
                        # Good made hand or strong draw -> call most reasonable bets
                        # Call if bet <= 75% pot
                        if pot_odds <= 0.43:  # approx for 75% pot bet
                            call_ok = True
                    elif strength >= 0.55:
                        # Medium strength or draws -> call cheap bets (<= 1/3 pot)
                        if pot_odds <= 0.25:
                            call_ok = True
                    else:
                        # Weak -> only call very tiny bets occasionally
                        if pot_odds <= 0.05 and self.rng.random() < 0.3:
                            call_ok = True

                    # Execute decision
                    if raise_ok:
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                        # If cannot raise, call if possible
                        if amount_to_call <= remaining_chips:
                            return PokerAction.CALL, 0
                        return PokerAction.ALL_IN, 0

                    if call_ok:
                        if amount_to_call <= remaining_chips:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                # No hole cards available; play simple and safe: check when possible, fold to pressure unless tiny bet
                if can_check:
                    # Occasional stab HU to avoid being a sitting duck
                    if self.is_heads_up and self.rng.random() < 0.15:
                        amt = self._choose_raise_amount(round_state, target=None, default_scale=1.0)
                        if amt is not None:
                            return PokerAction.RAISE, amt
                    return PokerAction.CHECK, 0
                else:
                    # Call only tiny bets
                    tiny_bet = pot * 0.03
                    if amount_to_call <= max(1, int(tiny_bet)):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand trackers as needed
        self.was_preflop_raiser = False
        self.my_bet_start = 0
        # Attempt to clear hole cards (they change each hand)
        self.last_known_hole_cards = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing persistent to maintain across games beyond defaults
        pass

    # ----------------- Helper methods below -----------------

    def _infer_current_blinds(self, round_state: RoundStateClient):
        # Infer current SB and BB based on player_bets at preflop start (best effort)
        try:
            bets = []
            for v in (round_state.player_bets or {}).values():
                try:
                    iv = int(v)
                    if iv > 0:
                        bets.append(iv)
                except Exception:
                    continue
            if bets:
                mx = max(bets)
                mn_pos = min(b for b in bets if b > 0) if any(b > 0 for b in bets) else 0
                # If there's only one positive (e.g., just big blind posted), set sb as half but at least 1
                if len(bets) == 1:
                    self.bb_amount_current = mx
                    self.sb_amount_current = max(1, mx // 2)
                else:
                    self.bb_amount_current = mx
                    # In some structures, raises may already have occurred; attempt to detect typical SB size
                    # Use smallest positive as SB if it looks like half of BB, otherwise half heuristic
                    if mn_pos < mx:
                        self.sb_amount_current = mn_pos
                    else:
                        self.sb_amount_current = max(1, mx // 2)
            else:
                # Fallback to initial known blinds if no bets
                self.bb_amount_current = max(self.initial_blind_amount, 1)
                self.sb_amount_current = max(1, self.initial_blind_amount // 2)
        except Exception:
            # Keep previous values if inference fails
            if self.bb_amount_current <= 0:
                self.bb_amount_current = max(self.initial_blind_amount, 1)
            if self.sb_amount_current <= 0:
                self.sb_amount_current = max(1, self.initial_blind_amount // 2)

    def _choose_raise_amount(self, round_state: RoundStateClient, target: Optional[int], default_scale: float = 1.0) -> Optional[int]:
        """
        Return a valid raise amount within [min_raise, max_raise].
        If target is None, pick min_raise scaled mildly; otherwise clamp target.
        """
        try:
            min_r = int(round_state.min_raise) if round_state.min_raise is not None else 0
            max_r = int(round_state.max_raise) if round_state.max_raise is not None else 0
        except Exception:
            return None

        if max_r <= 0 or min_r <= 0:
            return None

        if target is None:
            # Default to min raise; occasionally size up if possible
            amt = int(min_r * max(1.0, min(3.0, default_scale)))
        else:
            amt = int(target)

        if amt < min_r:
            amt = min_r
        if amt > max_r:
            # If we cannot make a valid raise, return None
            return None
        return amt

    def _get_hole_cards_safe(self, round_state: RoundStateClient) -> Optional[List[str]]:
        """
        Best-effort retrieval of hole cards from known possible sources.
        If not available, return None and strategy will fallback to card-agnostic play.
        """
        # Try round_state attribute if it exists
        try:
            ph = getattr(round_state, "player_hands", None)
            if isinstance(ph, list) and len(ph) >= 2:
                return ph[:2]
        except Exception:
            pass
        # If we stored from on_start or elsewhere
        if isinstance(self.last_known_hole_cards, list) and len(self.last_known_hole_cards) >= 2:
            return self.last_known_hole_cards[:2]
        return None

    # --------------- Card and strength evaluation helpers ---------------

    @staticmethod
    def _card_rank_value(card: str) -> int:
        if not card or len(card) < 1:
            return 0
        r = card[0]
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5,
                   '6': 6, '7': 7, '8': 8, '9': 9,
                   'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(r.upper(), 0)

    @staticmethod
    def _card_rank_char(card: str) -> str:
        if not card or len(card) < 1:
            return '?'
        return card[0].upper()

    @staticmethod
    def _card_suit(card: str) -> str:
        if not card or len(card) < 2:
            return '?'
        return card[1].lower()

    def _hand_key(self, hole: List[str]) -> str:
        """
        Returns a canonical key like 'AKs', 'AQo', 'TT'.
        """
        if not hole or len(hole) < 2:
            return "??"
        a, b = hole[0], hole[1]
        ra, rb = self._card_rank_char(a), self._card_rank_char(b)
        va, vb = self._card_rank_value(a), self._card_rank_value(b)
        sa, sb = self._card_suit(a), self._card_suit(b)
        suited = 's' if sa == sb else 'o'
        if ra == rb:
            return f"{ra}{rb}"
        # Order high first
        if va < vb:
            ra, rb = rb, ra
            sa, sb = sb, sa
        # suited recalculated though suits swapped not needed
        suited = 's' if sa == sb else 'o'
        return f"{ra}{rb}{suited}"

    def _preflop_strength(self, hole: List[str]) -> float:
        """
        Simple preflop hand strength heuristic from 0 to 1.
        """
        key = self._hand_key(hole)
        # Pairs
        premium_pairs = {"AA", "KK", "QQ", "JJ"}
        strong_pairs = {"TT", "99", "88"}
        medium_pairs = {"77", "66", "55"}
        small_pairs = {"44", "33", "22"}

        premiums = {"AKs", "AQs", "AKo"}
        strongs = {"AJs", "ATs", "KQs", "KJs", "QJs", "AQo", "KQo", "KTs", "QTs", "JTs", "AJo"}
        mediums = {"A9s", "A8s", "A7s", "A5s", "KJo", "QJo", "T9s", "98s", "87s", "76s", "65s", "54s"}

        # Normalize key if it's a pair (strip suited char)
        if len(key) == 3 and key[0] == key[1]:
            key_pair = key[0:2]
        else:
            key_pair = key

        if key_pair in premium_pairs or key in premiums:
            return 0.95
        if key_pair in strong_pairs or key in strongs:
            return 0.78
        if key_pair in medium_pairs or key in mediums:
            return 0.62
        if key_pair in small_pairs:
            return 0.55

        # High card variations boost
        ranks = [self._card_rank_value(c) for c in hole if isinstance(c, str)]
        hi = max(ranks) if ranks else 0
        lo = min(ranks) if ranks else 0
        suited = 1.0 if (len(hole) >= 2 and self._card_suit(hole[0]) == self._card_suit(hole[1])) else 0.0
        connectors = 1.0 if abs(hi - lo) <= 1 else 0.0

        base = 0.35
        base += 0.05 * suited
        base += 0.04 * connectors
        if hi >= 13:
            base += 0.05
        if lo >= 10:
            base += 0.03
        return max(0.30, min(0.70, base))

    def _postflop_strength(self, hole: List[str], board: List[str]) -> float:
        """
        Crude postflop strength heuristic based on made hands and simple draws.
        Returns value in [0, 1].
        """
        cards = (hole or []) + (board or [])
        if len(cards) < 5:
            # Not enough info; default to mild value
            return 0.5

        # Rank counts
        rank_counts: Dict[int, int] = {}
        for c in cards:
            rv = self._card_rank_value(c)
            if rv <= 0:
                continue
            rank_counts[rv] = rank_counts.get(rv, 0) + 1

        # Suit counts
        suit_counts: Dict[str, int] = {}
        for c in cards:
            s = self._card_suit(c)
            if s == '?':
                continue
            suit_counts[s] = suit_counts.get(s, 0) + 1

        max_same_rank = max(rank_counts.values()) if rank_counts else 1
        max_same_suit = max(suit_counts.values()) if suit_counts else 1

        board_ranks = [self._card_rank_value(c) for c in board]
        hole_ranks = [self._card_rank_value(c) for c in hole]
        top_board = max(board_ranks) if board_ranks else 0

        # Determine made hand rough category
        made_val = 0.0
        # Quads / Full House / Trips detection via counts
        if max_same_rank >= 4:
            made_val = 0.98
        elif max_same_rank == 3:
            # Trips somewhere - stronger if trips include hole rank
            if any(rank_counts.get(r, 0) >= 3 for r in hole_ranks):
                made_val = 0.9
            else:
                made_val = 0.8
        else:
            # Pairs / two pairs
            # Overpair: pocket pair greater than top board
            if len(hole_ranks) == 2 and hole_ranks[0] == hole_ranks[1] and hole_ranks[0] > top_board:
                made_val = 0.82
            else:
                # Count how many hole ranks pair with board
                matches = 0
                matched_ranks = set()
                for r in hole_ranks:
                    if r in board_ranks and r not in matched_ranks:
                        matches += 1
                        matched_ranks.add(r)
                if matches >= 2:
                    made_val = 0.8  # two pair using both hole cards
                elif matches == 1:
                    # Check if it's top pair
                    if any(r == top_board for r in hole_ranks):
                        made_val = 0.72
                    else:
                        made_val = 0.6
                else:
                    made_val = 0.45  # high card only

        # Flush draw detection (especially on flop/turn)
        draw_val = 0.0
        board_len = len(board)
        # Count suits on board
        board_suit_counts: Dict[str, int] = {}
        for c in board:
            s = self._card_suit(c)
            board_suit_counts[s] = board_suit_counts.get(s, 0) + 1
        hole_suits = [self._card_suit(c) for c in hole]
        # Flush made if 5 of one suit overall
        if max_same_suit >= 5:
            made_val = max(made_val, 0.9)

        # Flush draws (4 to a flush) heuristics
        if board_len in (3, 4):  # Flop or Turn
            for s, bc in board_suit_counts.items():
                hc = sum(1 for hs in hole_suits if hs == s)
                total = bc + hc
                if total == 4 and hc >= 1:
                    draw_val = max(draw_val, 0.15)  # decent flush draw bump

        # Simple straight draw heuristic: check for 4-rank windows among unique ranks
        unique_ranks = sorted(set([self._card_rank_value(c) for c in cards if self._card_rank_value(c) > 0]))
        # Treat A as both high and low for wheel
        if 14 in unique_ranks:
            unique_ranks = sorted(set(unique_ranks + [1]))
        # Check consecutive sequences
        max_run = 1
        curr_run = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i] == unique_ranks[i - 1] + 1:
                curr_run += 1
                max_run = max(max_run, curr_run)
            else:
                curr_run = 1
        if max_run >= 5:
            made_val = max(made_val, 0.88)
        elif max_run == 4 and board_len in (3, 4):
            draw_val = max(draw_val, 0.10)

        # Overcards minor value (both hole cards over highest board rank)
        if hole_ranks and top_board > 0:
            if min(hole_ranks) > top_board:
                draw_val = max(draw_val, 0.05)

        # Clamp and combine
        strength = max(made_val, min(0.85, made_val + draw_val))
        strength = max(0.0, min(1.0, strength))
        return strength