import itertools
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.player_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.player_id = str(self.id)  # Store as string for consistent dict lookup

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = round_state.player_bets.get(self.player_id, 0)
        call_amount = round_state.current_bet - our_bet
        
        if round_state.round == 'Preflop':
            strength = self.pre_flop_strength(self.hole_cards)
            if strength >= 25:
                raise_amount = round_state.min_raise
                if raise_amount > remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif strength >= 15:
                if call_amount <= remaining_chips:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        else:
            hand_rank, _ = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            if hand_rank >= 4:
                if call_amount > 0:
                    total_bet_needed = call_amount + round_state.min_raise
                    if total_bet_needed > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, round_state.min_raise
                else:
                    if round_state.min_raise > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, round_state.min_raise
            elif hand_rank >= 2:
                if call_amount > 0:
                    if call_amount <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                if call_amount > 0:
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def pre_flop_strength(self, hole_cards: List[str]) -> float:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                    '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = [rank_map[card[0]] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        r1, r2 = ranks
        if r1 == r2:
            return r1 * 2
        high, low = max(r1, r2), min(r1, r2)
        gap = high - low
        suited = suits[0] == suits[1]
        strength = high + low / 14.0
        if gap <= 1:
            strength += 2
        elif gap == 2:
            strength += 1
        elif gap == 3:
            strength += 0.5
        if suited:
            strength += 1
        return strength

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, str]:
        cards = hole_cards + community_cards
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                    '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        card_ranks = []
        suits = []
        for card in cards:
            card_ranks.append(rank_map[card[0]])
            suits.append(card[1])
        
        best_rank = -1
        best_desc = ""
        
        for combo in itertools.combinations(range(len(cards)), 5):
            five_ranks = [card_ranks[i] for i in combo]
            five_suits = [suits[i] for i in combo]
            rank_val, desc = self._evaluate_five_cards(five_ranks, five_suits)
            if rank_val > best_rank:
                best_rank = rank_val
                best_desc = desc
                
        return best_rank, best_desc

    def _evaluate_five_cards(self, ranks: List[int], suits: List[str]) -> Tuple[int, str]:
        sorted_ranks = sorted(ranks)
        rank_counts = {}
        for r in sorted_ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        flush = any(count >= 5 for count in suit_counts.values())
        straight = False
        unique_ranks = list(set(sorted_ranks))
        if len(unique_ranks) >= 5:
            consecutive = 1
            for i in range(1, len(unique_ranks)):
                if unique_ranks[i] == unique_ranks[i-1] + 1:
                    consecutive += 1
                else:
                    consecutive = 1
                if consecutive >= 5:
                    straight = True
                    break
            if not straight and set(unique_ranks) >= {14, 2, 3, 4, 5}:
                straight = True
                sorted_ranks = [1, 2, 3, 4, 5]
        
        if flush and straight:
            if sorted_ranks[-1] == 14 and sorted_ranks[-5] == 10:
                return 9, "Royal Flush"
            return 8, f"Straight Flush {sorted_ranks[-1]}"
        
        quad_rank = None
        triple_rank = None
        pair_ranks = []
        for rank, count in rank_counts.items():
            if count == 4:
                quad_rank = rank
            elif count == 3:
                triple_rank = rank
            elif count == 2:
                pair_ranks.append(rank)
        
        if quad_rank is not None:
            return 7, f"Four of a Kind {quad_rank}"
        
        if triple_rank is not None and len(pair_ranks) >= 1:
            return 6, f"Full House {triple_rank} full of {pair_ranks[0]}"
        
        if flush:
            return 5, "Flush"
        
        if straight:
            return 4, f"Straight {sorted_ranks[-1]}"
        
        if triple_rank is not None:
            return 3, f"Three of a Kind {triple_rank}"
        
        if len(pair_ranks) >= 2:
            return 2, f"Two Pair {pair_ranks[-1]} and {pair_ranks[-2]}"
        
        if len(pair_ranks) == 1:
            return 1, f"Pair of {pair_ranks[0]}"
        
        return 0, f"High Card {sorted_ranks[-1]}"