from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.our_id = None
        self.hand_strength = 0
        self.current_round = None
        self.player_bets = {}
        self.player_actions = {}
        self.community_cards = []
        self.pot = 0
        self.current_bet = 0
        self.min_raise = 0
        self.max_raise = 0
        self.remaining_chips = 0
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.all_players = all_players
        if self.id is not None:
            try:
                idx = all_players.index(self.id)
                hand_str = player_hands[idx]
                self.hole_cards = [hand_str[0:2], hand_str[2:4]]
            except (ValueError, IndexError):
                self.hole_cards = None
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.remaining_chips = remaining_chips
        self.player_bets = round_state.player_bets
        self.player_actions = round_state.player_actions
        self.current_round = round_state.round

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.hole_cards is None:
            return PokerAction.FOLD, 0

        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.remaining_chips = remaining_chips
        self.player_bets = round_state.player_bets
        self.player_actions = round_state.player_actions
        self.current_round = round_state.round

        if self.current_round == 'Preflop':
            return self.handle_preflop()
        else:
            return self.handle_postflop()

    def handle_preflop(self) -> Tuple[PokerAction, int]:
        if self.current_bet == 0:
            if self.is_strong_preflop():
                raise_amount = min(3 * self.min_raise, self.max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            call_amount = self.current_bet - self.player_bets.get(str(self.id), 0)
            if call_amount > self.remaining_chips:
                return PokerAction.FOLD, 0

            if self.is_strong_preflop():
                raise_amount = min(self.min_raise, self.max_raise)
                return PokerAction.RAISE, raise_amount
            elif self.is_medium_preflop():
                if call_amount < self.remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0

    def handle_postflop(self) -> Tuple[PokerAction, int]:
        hand_value = self.evaluate_hand()
        if self.current_bet == 0:
            if hand_value >= 5000000:  # Straight or better
                raise_amount = min(self.min_raise, self.max_raise)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            call_amount = self.current_bet - self.player_bets.get(str(self.id), 0)
            if call_amount > self.remaining_chips:
                return PokerAction.FOLD, 0

            if hand_value >= 8000000:  # Four of a kind or better
                raise_amount = min(self.min_raise, self.max_raise)
                return PokerAction.RAISE, raise_amount
            elif hand_value >= 6000000:  # Flush or better
                return PokerAction.CALL, 0
            elif hand_value >= 4000000:  # Three of a kind or better
                if call_amount < self.remaining_chips * 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif hand_value >= 3000000:  # Two pair
                if call_amount < self.remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0

    def is_strong_preflop(self) -> bool:
        ranks = self.get_ranks(self.hole_cards)
        suited = self.hole_cards[0][1] == self.hole_cards[1][1]
        
        if ranks[0] == ranks[1]:  # Pair
            return ranks[0] >= 10  # TT+
        elif max(ranks) == 14 and min(ranks) == 13:  # AK
            return True
        elif max(ranks) == 14 and min(ranks) == 12:  # AQ
            return True
        elif max(ranks) == 13 and min(ranks) == 12:  # KQ
            return suited
        return False

    def is_medium_preflop(self) -> bool:
        ranks = self.get_ranks(self.hole_cards)
        suited = self.hole_cards[0][1] == self.hole_cards[1][1]
        
        if ranks[0] == ranks[1]:  # Pair
            return 7 <= ranks[0] <= 9  # 77-99
        elif max(ranks) == 14 and min(ranks) == 11:  # AJ
            return suited
        elif max(ranks) == 14 and min(ranks) == 10:  # AT
            return suited
        elif max(ranks) == 13 and min(ranks) == 11:  # KJ
            return suited
        elif max(ranks) == 12 and min(ranks) == 11:  # QJ
            return suited
        elif max(ranks) == 11 and min(ranks) == 10:  # JT
            return suited
        return False

    def get_ranks(self, cards: List[str]) -> List[int]:
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = []
        for card in cards:
            rank_char = card[0]
            if rank_char in rank_map:
                ranks.append(rank_map[rank_char])
            else:
                ranks.append(int(rank_char))
        return sorted(ranks, reverse=True)

    def evaluate_hand(self) -> int:
        if not self.community_cards:
            return 0
        
        all_cards = self.hole_cards + self.community_cards
        if len(all_cards) < 5:
            return 0
        
        return self.evaluate_best_hand(all_cards)

    def evaluate_best_hand(self, cards: List[str]) -> int:
        from itertools import combinations
        best_score = 0
        for combo in combinations(cards, 5):
            score = self.evaluate_five_card(combo)
            if score > best_score:
                best_score = score
        return best_score

    def evaluate_five_card(self, hand: List[str]) -> int:
        ranks = []
        suits = []
        for card in hand:
            rank_char = card[0]
            suit_char = card[1]
            rank = 0
            if rank_char == 'T':
                rank = 10
            elif rank_char == 'J':
                rank = 11
            elif rank_char == 'Q':
                rank = 12
            elif rank_char == 'K':
                rank = 13
            elif rank_char == 'A':
                rank = 14
            else:
                rank = int(rank_char)
            ranks.append(rank)
            suits.append(suit_char)
        
        ranks_sorted = sorted(ranks, reverse=True)
        is_flush = len(set(suits)) == 1
        
        straight_high = self.check_straight(ranks_sorted)
        is_straight = straight_high is not None
        
        if is_straight and is_flush:
            if straight_high == 14:
                return 10000000  # Royal flush
            return 9000000 + straight_high * 10000
        
        from collections import Counter
        count = Counter(ranks_sorted)
        counts = sorted(count.items(), key=lambda x: (-x[1], -x[0]))
        
        if counts[0][1] == 4:
            return 8000000 + counts[0][0] * 10000 + counts[1][0] * 100
        if counts[0][1] == 3 and counts[1][1] == 2:
            return 7000000 + counts[0][0] * 10000 + counts[1][0] * 100
        if is_flush:
            return 6000000 + sum(ranks_sorted[:5])  # Simplified kicker
        if is_straight:
            return 5000000 + straight_high * 10000
        if counts[0][1] == 3:
            return 4000000 + counts[0][0] * 10000 + counts[1][0] * 100 + counts[2][0]
        if counts[0][1] == 2 and counts[1][1] == 2:
            return 3000000 + max(counts[0][0], counts[1][0]) * 10000 + min(counts[0][0], counts[1][0]) * 100 + counts[2][0]
        if counts[0][1] == 2:
            return 2000000 + counts[0][0] * 10000 + counts[1][0] * 100 + counts[2][0]
        return 1000000 + sum(ranks_sorted[:5])  # High card

    def check_straight(self, ranks: List[int]) -> int:
        seen = set(ranks)
        for r in range(14, 5, -1):
            straight = {r - i for i in range(5)}
            if straight.issubset(seen):
                return r
        # Check Ace-low straight
        if {14, 2, 3, 4, 5}.issubset(seen):
            return 5
        return None

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.community_cards = []
        self.player_bets = {}
        self.player_actions = {}
        self.pot = 0
        self.current_bet = 0
        self.min_raise = 0
        self.max_raise = 0

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass