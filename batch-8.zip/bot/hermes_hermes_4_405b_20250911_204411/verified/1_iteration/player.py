from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.premium_pairs = ['AA','KK','QQ','JJ','TT','99','88']
        self.premium_suited = ['AKs','AQs','AJs','ATs','KQs','KJs','KTs','QJs','QTs','JTs','T9s','98s','87s']
        self.premium_unsuited = ['AK','AQ','AJ','AT','KQ']
        self.premium_hands_list = self.premium_pairs + self.premium_suited + self.premium_unsuited
        self.very_strong_hands = ['AA','KK','QQ','JJ','AKs','AK']
        self.hole_cards = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.num_players = len(all_players)
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, round_state.current_bet - my_bet)
        
        if round_state.round == 'Preflop':
            hand_str = self.get_hand_string(self.hole_cards)
            if self.id == self.big_blind_player_id and amount_to_call == 0:
                if hand_str in self.premium_hands_list:
                    return (PokerAction.RAISE, round_state.min_raise)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if hand_str in self.premium_hands_list:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        if amount_to_call < remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        else:
                            if hand_str in self.very_strong_hands:
                                return (PokerAction.RAISE, round_state.min_raise)
                            else:
                                return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            community = round_state.community_cards
            hand_rank = self.get_hand_strength(community)
            if round_state.round == 'Flop':
                if hand_rank[0] >= 2:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        if amount_to_call < remaining_chips * 0.2:
                            return (PokerAction.CALL, 0)
                        else:
                            if hand_rank[0] >= 3:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.FOLD, 0)
                elif hand_rank[0] == 1:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif round_state.round == 'Turn':
                if hand_rank[0] >= 3:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_rank[0] == 2:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                if hand_rank[0] >= 3:
                    if amount_to_call == 0:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_rank[0] == 2:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_hand_string(self, hole_cards):
        ranks = []
        suits = []
        for card in hole_cards:
            card = card.upper()
            rank_char = card[0]
            suit_char = card[1]
            if rank_char == 'T':
                rank = 'T'
            elif rank_char == 'J':
                rank = 'J'
            elif rank_char == 'Q':
                rank = 'Q'
            elif rank_char == 'K':
                rank = 'K'
            elif rank_char == 'A':
                rank = 'A'
            else:
                rank = str(int(rank_char))
            ranks.append(rank)
            suits.append(suit_char)
        
        rank_value = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        temp = []
        for idx, rank in enumerate(ranks):
            val = rank_value[rank]
            temp.append((val, rank, idx))
        temp.sort(key=lambda x: x[0], reverse=True)
        
        if temp[0][0] == temp[1][0]:
            hand_str = ranks[0] + ranks[1]
        else:
            hand_str = temp[0][1] + temp[1][1]
        
        if suits[0] == suits[1]:
            hand_str += 's'
        
        return hand_str

    def get_hand_strength(self, community):
        all_cards = self.hole_cards + community
        best_rank = None
        for combo in itertools.combinations(all_cards, 5):
            rank = self.evaluate_five(combo)
            if best_rank is None or rank > best_rank:
                best_rank = rank
        return best_rank

    def evaluate_five(self, cards):
        ranks = []
        suits = []
        for card in cards:
            card = card.upper()
            rank_char = card[0]
            suit_char = card[1]
            if rank_char == 'T':
                rank = 10
            elif rank_char == 'J':
                rank = 11
            elif rank_char == 'Q':
                rank = 12
            elif rank_char == 'K':
                rank = 13
            elif rank_char == 'A':
                rank = 14
            else:
                rank = int(rank_char)
            ranks.append(rank)
            suits.append(suit_char)
        
        ranks_sorted = sorted(ranks)
        suit_count = Counter(suits)
        flush = any(count >= 5 for count in suit_count.values())
        
        unique_ranks = sorted(set(ranks_sorted))
        straight = False
        high_card = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    straight = True
                    high_card = unique_ranks[i+4]
                    break
            if not straight and set(unique_ranks) >= {2, 3, 4, 5, 14}:
                straight = True
                high_card = 5
        
        count = Counter(ranks_sorted)
        counts = sorted(count.values(), reverse=True)
        rank_count = sorted([(r, c) for r, c in count.items()], key=lambda x: (x[1], x[0]), reverse=True)
        
        if straight and flush:
            if high_card == 14:
                return (9, [])
            else:
                return (8, [high_card])
        
        if counts[0] == 4:
            quad_rank = rank_count[0][0]
            kicker = next(r for r, c in rank_count if c != 4)
            return (7, [quad_rank, kicker])
        
        if counts[0] == 3 and counts[1] == 2:
            three_rank = rank_count[0][0]
            two_rank = rank_count[1][0]
            return (6, [three_rank, two_rank])
        
        if flush:
            flush_suit = max(suit_count, key=suit_count.get)
            flush_ranks = sorted([r for r, s in zip(ranks, suits) if s == flush_suit], reverse=True)[:5]
            return (5, flush_ranks)
        
        if straight:
            return (4, [high_card])
        
        if counts[0] == 3:
            trip_rank = rank_count[0][0]
            kickers = [r for r, c in rank_count if c != 3][:2]
            return (3, [trip_rank] + kickers)
        
        if counts[0] == 2 and counts[1] == 2:
            pairs = sorted([r for r, c in rank_count if c == 2], reverse=True)[:2]
            kicker = next(r for r, c in rank_count if c != 2)
            return (2, [pairs[0], pairs[1], kicker])
        
        if counts[0] == 2:
            pair_rank = rank_count[0][0]
            kickers = [r for r, c in rank_count if c != 2][:3]
            return (1, [pair_rank] + kickers)
        
        kickers = [r for r, c in rank_count][:5]
        return (0, kickers)