from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.big_blind = 0
        self.rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suit_map = {'h': 0, 's': 1, 'd': 2, 'c': 3}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot

        if round_state.round == 'Preflop':
            strength = self._get_preflop_strength()
        else:
            strength = self._get_postflop_strength(round_state.community_cards)

        if to_call == 0:
            if strength in ['strong', 'medium']:
                raise_amount = max(round_state.min_raise, 3 * self.big_blind)
                if raise_amount >= remaining_chips:
                    if remaining_chips > 0:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.CHECK, 0
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CHECK, 0
        else:
            if remaining_chips < to_call:
                return PokerAction.FOLD, 0

            min_raise_additional = to_call + round_state.min_raise
            can_raise = remaining_chips >= min_raise_additional

            if strength == 'strong':
                if not can_raise:
                    return PokerAction.CALL, 0
                desired_raise_by = max(round_state.min_raise, pot // 2)
                desired_additional = to_call + desired_raise_by
                additional = min(desired_additional, remaining_chips)
                if additional == remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, additional
            elif strength == 'medium':
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _get_preflop_strength(self) -> str:
        if len(self.hole_cards) != 2:
            return 'weak'
        card1, card2 = self.hole_cards
        r1 = self.rank_map[card1[0]]
        r2 = self.rank_map[card2[0]]
        suited = card1[1] == card2[1]
        if r1 < r2:
            r1, r2 = r2, r1
        pair = r1 == r2
        if pair and r1 >= 12 or (r1 == 14 and r2 >= 12 and suited):
            return 'strong'
        elif pair and r1 >= 7 or (r1 == 14 and r2 >= 10 and suited) or (r1 == 13 and r2 >= 11 and suited):
            return 'medium'
        else:
            return 'weak'

    def _get_postflop_strength(self, community: List[str]) -> str:
        all_cards = self.hole_cards + community
        score = self._get_hand_strength(all_cards)
        rank_type = score // 1000000
        if rank_type >= 4:
            return 'strong'
        elif rank_type >= 1:
            return 'medium'
        else:
            return 'weak'

    def _get_hand_strength(self, cards: List[str]) -> int:
        if len(cards) < 5:
            ranks = sorted([self.rank_map[c[0]] for c in cards], reverse=True)
            count = Counter(ranks)
            max_c = max(count.values())
            if max_c >= 3:
                return 3000000 + max(ranks) * 10000
            elif max_c == 2:
                pair_r = max(r for r, c in count.items() if c == 2)
                kicker = max(r for r in ranks if r != pair_r) if len(ranks) > 1 else 0
                return 1000000 + pair_r * 10000 + kicker * 100
            else:
                return ranks[0] * 10000 + (ranks[1] if len(ranks) > 1 else 0) * 100
        max_score = 0
        for combo in itertools.combinations(cards, 5):
            score = self._evaluate_score(list(combo))
            if score > max_score:
                max_score = score
        return max_score

    def _evaluate_score(self, five_cards: List[str]) -> int:
        ranks = sorted([self.rank_map[c[0]] for c in five_cards], reverse=True)
        suits = [self.suit_map[c[1]] for c in five_cards]
        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] - ranks[i + 1] == 1 for i in range(4))
        if ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]
        count = Counter(ranks)
        count_values = sorted(count.values(), reverse=True)
        if is_flush and is_straight:
            return 8000000 + ranks[0] * 10000
        if count_values[0] == 4:
            quad = next(r for r, c in count.items() if c == 4)
            kicker = next(r for r, c in count.items() if c == 1)
            return 7000000 + quad * 10000 + kicker * 100
        if count_values[0] == 3 and count_values[1] == 2:
            trips = next(r for r, c in count.items() if c == 3)
            pair = next(r for r, c in count.items() if c == 2)
            return 6000000 + trips * 10000 + pair * 100
        if is_flush:
            return 5000000 + ranks[0] * 100000 + ranks[1] * 10000 + ranks[2] * 1000 + ranks[3] * 100 + ranks[4]
        if is_straight:
            return 4000000 + ranks[0] * 10000
        if count_values[0] == 3:
            trips = next(r for r, c in count.items() if c == 3)
            kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
            return 3000000 + trips * 10000 + kickers[0] * 1000 + kickers[1] * 100
        if count_values[0] == 2 and count_values[1] == 2:
            pairs = sorted([r for r, c in count.items() if c == 2], reverse=True)
            kicker = next(r for r, c in count.items() if c == 1)
            return 2000000 + pairs[0] * 10000 + pairs[1] * 1000 + kicker * 100
        if count_values[0] == 2:
            pair = next(r for r, c in count.items() if c == 2)
            kickers = sorted([r for r, c in count.items() if c == 1], reverse=True)
            return 1000000 + pair * 10000 + kickers[0] * 1000 + kickers[1] * 100 + kickers[2]
        return ranks[0] * 100000 + ranks[1] * 10000 + ranks[2] * 1000 + ranks[3] * 100 + ranks[4]

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass