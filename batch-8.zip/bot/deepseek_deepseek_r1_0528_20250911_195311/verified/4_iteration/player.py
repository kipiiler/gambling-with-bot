from typing import List, Tuple, Dict, Set
import itertools
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.big_blind = 0
        self.all_players = []
        self.active_players = set()
        self.hand = []
        self.position = None
        self.hand_strength_groups = {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs', 'AKo'],
            2: ['TT', '99', '88', 'AQs', 'AQo', 'AJs', 'KQs'],
            3: ['77', '66', 'ATs', 'AJo', 'KJs', 'QJs', 'JTs'],
            4: ['55', '44', '33', '22', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 
                'KTs', 'QTs', 'J9s', 'T9s', '98s']
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.all_players = all_players
        self.active_players = set(all_players)
        self.hand = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.active_players = set(self.all_players)
        self.position = 'button' if self.id == round_state.current_player[0] else 'blind'

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        player_id_str = str(self.id)
        our_current_bet = round_state.player_bets.get(player_id_str, 0)
        amount_to_call = round_state.current_bet - our_current_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        num_active = len(self.active_players)
        
        # Update active players
        for pid, action in round_state.player_actions.items():
            if action == 'Fold' and int(pid) in self.active_players:
                self.active_players.remove(int(pid))
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            hand_str = self._hand_to_string(self.hand)
            hand_group = self._get_hand_group(hand_str)
            
            # Heads-up strategy
            if num_active == 2:
                if self.position == 'button':
                    if hand_group <= 4 and amount_to_call == 0:
                        raise_amount = min(max(min_raise, 3 * self.big_blind), max_raise)
                        if raise_amount >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, raise_amount
                    elif hand_group <= 4 and amount_to_call > 0:
                        if amount_to_call <= 3 * self.big_blind:
                            return PokerAction.CALL, 0
                        elif hand_group == 1:
                            raise_amount = min(max(min_raise, 3 * amount_to_call), max_raise)
                            if raise_amount >= remaining_chips:
                                return PokerAction.ALL_IN, 0
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.FOLD, 0
                    else:
                        return PokerAction.FOLD, 0
                else:  # Big blind position
                    if hand_group <= 4 and amount_to_call == 0:
                        return PokerAction.CHECK, 0
                    elif hand_group <= 4 and amount_to_call <= 3 * self.big_blind:
                        return PokerAction.CALL, 0
                    elif hand_group == 1:
                        raise_amount = min(max(min_raise, 3 * amount_to_call), max_raise)
                        if raise_amount >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.FOLD, 0
            
            # Multi-way pot strategy
            else:
                if hand_group <= 2 and amount_to_call == 0:
                    raise_amount = min(max(min_raise, 3 * self.big_blind), max_raise)
                    if raise_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif hand_group <= 2 and amount_to_call <= 2 * self.big_blind:
                    return PokerAction.CALL, 0
                elif hand_group == 1:
                    raise_amount = min(max(min_raise, 3 * amount_to_call), max_raise)
                    if raise_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop strategy
        win_prob = self._calculate_win_probability(self.hand, round_state.community_cards, num_simulations=200)
        pot = round_state.pot
        pot_odds = amount_to_call / (pot + amount_to_call + 1e-8)  # Avoid division by zero
        
        if amount_to_call == 0:  # Can check
            if win_prob > 0.6:  # Strong hand - value bet
                bet_amount = min(max(min_raise, pot // 2), max_raise)
                if bet_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount
            else:  # Weak hand - check
                return PokerAction.CHECK, 0
        else:  # Facing a bet
            if win_prob > pot_odds and win_prob > 0.5:  # Positive EV
                if win_prob > 0.7:  # Very strong hand - raise for value
                    raise_amount = min(max(min_raise, pot // 2), max_raise)
                    if raise_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                else:  # Call
                    return PokerAction.CALL, 0
            elif win_prob > pot_odds:  # Marginally positive EV
                return PokerAction.CALL, 0
            else:  # Negative EV - fold
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _hand_to_string(self, hand: List[str]) -> str:
        ranks = []
        for card in hand:
            rank = card[:-1]
            if rank == '10':
                rank = 'T'
            ranks.append(rank)
        ranks.sort()
        suited = 's' if hand[0][-1] == hand[1][-1] else 'o'
        return f"{ranks[0]}{ranks[1]}{suited}"

    def _get_hand_group(self, hand_str: str) -> int:
        for group, hands in self.hand_strength_groups.items():
            if hand_str in hands:
                return group
        return 5  # Weakest group

    def _calculate_win_probability(self, hole_cards: List[str], community_cards: List[str], num_simulations: int = 200) -> float:
        wins = 0
        ties = 0
        losses = 0
        
        # Create deck
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        suits = ['h', 'd', 'c', 's']
        deck = [f"{r}{s}" for r in ranks for s in suits]
        
        # Remove known cards
        for card in hole_cards + community_cards:
            if card in deck:
                deck.remove(card)
                
        # Determine cards to deal
        cards_to_deal = 5 - len(community_cards)
        
        for _ in range(num_simulations):
            # Shuffle deck
            random.shuffle(deck)
            
            # Deal opponent cards and remaining community cards
            opp_hole = deck[:2]
            new_comm = community_cards + deck[2:2+cards_to_deal]
            
            # Evaluate hands
            our_hand = self._evaluate_hand(hole_cards + new_comm)
            opp_hand = self._evaluate_hand(opp_hole + new_comm)
            
            # Compare hands
            comparison = self._compare_hands(our_hand, opp_hand)
            if comparison > 0:
                wins += 1
            elif comparison == 0:
                ties += 1
            else:
                losses += 1
                
        return (wins + ties/2) / num_simulations

    def _evaluate_hand(self, cards: List[str]) -> Tuple[int, ...]:
        best_rank = None
        for combo in itertools.combinations(cards, 5):
            rank = self._get_hand_rank(list(combo))
            if best_rank is None or self._compare_ranks(rank, best_rank) > 0:
                best_rank = rank
        return best_rank

    def _get_hand_rank(self, hand: List[str]) -> Tuple[int, ...]:
        ranks = []
        suits = []
        for card in hand:
            rank_str = card[:-1]
            suit = card[-1]
            if rank_str == 'A': rank = 14
            elif rank_str == 'K': rank = 13
            elif rank_str == 'Q': rank = 12
            elif rank_str == 'J': rank = 11
            elif rank_str == '10': rank = 10
            else: rank = int(rank_str)
            ranks.append(rank)
            suits.append(suit)
        
        ranks.sort(reverse=True)
        suit_count = len(set(suits))
        
        # Check straight
        straight = False
        if len(set(ranks)) == 5 and ranks[0] - ranks[4] == 4:
            straight = True
        elif set(ranks) == {14, 5, 4, 3, 2}:
            straight = True
            ranks = [5, 4, 3, 2, 1]
        
        # Check flush
        flush = suit_count == 1
        
        # Straight flush
        if straight and flush:
            return (9, ranks[0])
        
        # Count rank occurrences
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        sorted_counts = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)
        
        # Four of a kind
        if sorted_counts[0][1] == 4:
            return (8, sorted_counts[0][0], sorted_counts[1][0])
        
        # Full house
        if sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
            return (7, sorted_counts[0][0], sorted_counts[1][0])
        
        # Flush
        if flush:
            return (6, *ranks)
        
        # Straight
        if straight:
            return (5, ranks[0])
        
        # Three of a kind
        if sorted_counts[0][1] == 3:
            kickers = [x[0] for x in sorted_counts[1:]]
            return (4, sorted_counts[0][0], *kickers[:2])
        
        # Two pair
        if sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
            pairs = [x[0] for x in sorted_counts[:2]]
            kicker = sorted_counts[2][0]
            return (3, max(pairs), min(pairs), kicker)
        
        # One pair
        if sorted_counts[0][1] == 2:
            pair_rank = sorted_counts[0][0]
            kickers = [x[0] for x in sorted_counts[1:]]
            return (2, pair_rank, *kickers[:3])
        
        # High card
        return (1, *ranks[:5])
    
    def _compare_ranks(self, rank1: Tuple[int, ...], rank2: Tuple[int, ...]) -> int:
        for i in range(len(rank1)):
            if rank1[i] > rank2[i]:
                return 1
            elif rank1[i] < rank2[i]:
                return -1
        return 0
    
    def _compare_hands(self, hand1: Tuple[int, ...], hand2: Tuple[int, ...]) -> int:
        return self._compare_ranks(hand1, hand2)