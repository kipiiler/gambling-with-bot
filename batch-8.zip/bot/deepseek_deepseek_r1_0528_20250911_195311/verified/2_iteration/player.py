from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.position = 0
        self.hand_strength = 0
        self.aggression_factor = 1.0
        self.previous_actions = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.position = all_players.index(self.id)
        self.previous_actions = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.previous_actions = []

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.0
            
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 
                    'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        ranks = [rank_map[c[0]] for c in hole_cards]
        suits = [c[1] for c in hole_cards]
        
        # Premium pocket pairs
        if ranks[0] == ranks[1]:
            if ranks[0] >= 12:  # AA, KK, QQ
                return 0.9
            elif ranks[0] >= 10:  # JJ, TT
                return 0.7
            else:
                return 0.4
        
        # Premium suited connectors
        if suits[0] == suits[1]:
            if abs(ranks[0] - ranks[1]) == 1:  # Suited connectors
                if max(ranks) >= 12:  # AKs, KQs
                    return 0.85
                elif max(ranks) >= 10:  # QJs, JTs
                    return 0.65
            elif abs(ranks[0] - ranks[1]) == 0:  # Same card (shouldn't happen)
                return 0.8
            elif ranks[0] >= 13 or ranks[1] >= 13:  # Ace high suited
                return 0.7
        
        # High card strength
        high_card = max(ranks)
        if high_card >= 14:  # Ace
            return 0.6
        if high_card >= 12:  # King
            return 0.5
        
        return 0.0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_odds = current_bet / (current_bet + round_state.pot + 1e-6) if current_bet > 0 else 0
        position_factor = 1.0 - (self.position / max(len(self.all_players), 1))
        
        # Record previous actions
        self.previous_actions.append((round_state.round, current_bet))
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Premium hands
            if self.hand_strength >= 0.8:
                if current_bet == 0:
                    # Open with raise
                    raise_amount = min(max(3 * self.blind_amount, min_raise), max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    # 3-bet or call
                    if current_bet <= 5 * self.blind_amount:
                        return (PokerAction.RAISE, min(max(3 * current_bet, min_raise), max_raise))
                    else:
                        return (PokerAction.CALL, 0)
            
            # Medium hands in late position
            elif self.hand_strength >= 0.5 and position_factor > 0.6:
                if current_bet == 0:
                    # Open with raise
                    raise_amount = min(max(2 * self.blind_amount, min_raise), max_raise)
                    return (PokerAction.RAISE, raise_amount)
                elif current_bet <= 3 * self.blind_amount:
                    return (PokerAction.CALL, 0)
            
            # Big blind special
            elif self.id == self.big_blind_player_id and current_bet == self.blind_amount:
                if self.hand_strength >= 0.3:
                    return (PokerAction.CHECK, 0)
            
            # Fold weak hands
            return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            # Strong hands - bet aggressively
            if self.hand_strength >= 0.7:
                if current_bet == 0:
                    # Value bet
                    bet_size = min(max(int(0.6 * round_state.pot), min_raise), max_raise)
                    return (PokerAction.RAISE, bet_size)
                else:
                    if pot_odds < 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.RAISE, min(max(2 * current_bet, min_raise), max_raise))
            
            # Medium hands - control the pot
            elif self.hand_strength >= 0.4:
                if current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    if pot_odds < 0.25:
                        return (PokerAction.CALL, 0)
            
            # Weak hands - fold to aggression
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # Update aggression factor based on previous actions
        aggressive_actions = sum(1 for _, bet in self.previous_actions if bet > 0)
        total_actions = max(len(self.previous_actions), 1)
        self.aggression_factor = 0.7 * self.aggression_factor + 0.3 * (aggressive_actions / total_actions)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict) -> None:
        # Reset for next game
        self.aggression_factor = 1.0
        self.previous_actions = []