import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.position = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Get our hole cards
        try:
            player_index = all_players.index(self.id)
            self.hand = player_hands[player_index]
        except (ValueError, IndexError):
            self.hand = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_hand_group(self, hand):
        if not hand or len(hand) < 2:
            return 5
            
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        card1, card2 = hand
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        r1 = rank_map.get(rank1, 2)
        r2 = rank_map.get(rank2, 2)
        suited = suit1 == suit2
        paired = rank1 == rank2
        gap = abs(r1 - r2)
        
        # Group 1: Premium hands (AA, KK, QQ, AKs)
        if paired and r1 >= 12:  # QQ+
            return 1
        if not paired and (r1 == 14 or r2 == 14) and (r1 >= 13 or r2 >= 13) and suited:
            return 1
            
        # Group 2: Strong hands (JJ, TT, AQs, AKo, AJs, KQs)
        if paired and r1 >= 10:  # TT-JJ
            return 2
        if not paired and ((r1 == 14 and r2 >= 12 and suited) or  # AQs
                          (r1 == 14 and r2 >= 13 and not suited) or  # AKo
                          (max(r1, r2) >= 12 and min(r1, r2) >= 11 and suited)):  # KQs
            return 2
            
        # Group 3: Playable hands (99, 88, AQo, ATs, KJs, QJs, JTs)
        if paired and r1 >= 8:  # 88-99
            return 3
        if not paired and ((r1 == 14 and r2 >= 10) or  # AQo+
                          (r1 == 14 and r2 >= 10 and suited) or  # ATs+
                          (max(r1, r2) >= 11 and min(r1, r2) >= 10 and suited) or  # JTs, QJs
                          (max(r1, r2) >= 13 and min(r1, r2) >= 10 and suited)):  # KJs
            return 3
            
        # Group 4: Marginal hands (77, 66, A9s-A2s, KQo, KTs, QTs, J9s, T9s, 98s)
        if paired and r1 >= 6:  # 66-77
            return 4
        if not paired and ((r1 == 14 and r2 >= 2) or  # Any Ace
                          (max(r1, r2) >= 12 and min(r1, r2) >= 9) or  # KQo, QTo
                          (max(r1, r2) >= 10 and min(r1, r2) >= 8 and suited and gap <= 3)):  # Suited connectors
            return 4
            
        # Group 5: Weak hands
        return 5

    def evaluate_hand_strength(self, hole_cards, community_cards):
        if not hole_cards or len(hole_cards) < 2:
            return 0.1
            
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, 
                   '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        all_cards = hole_cards + community_cards
        ranks = [rank_map[card[0]] for card in all_cards if card[0] in rank_map]
        suits = [card[1] for card in all_cards]

        # Check for flush
        flush_suit = None
        for suit in ['h','d','c','s']:
            if suits.count(suit) >= 5:
                flush_suit = suit
                break

        # Check for straight
        sorted_ranks = sorted(set(ranks), reverse=True)
        straight = False
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks)-4):
                if sorted_ranks[i] - sorted_ranks[i+4] == 4:
                    straight = True
                    break

        # Count pairs
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r,0)+1
        pairs = []
        trips = []
        quads = []
        for r, count in rank_count.items():
            if count == 2:
                pairs.append(r)
            elif count == 3:
                trips.append(r)
            elif count == 4:
                quads.append(r)

        # Assign score
        if flush_suit and straight:
            return 0.99
        elif quads:
            return 0.95
        elif trips and pairs:
            return 0.9
        elif flush_suit:
            return 0.8
        elif straight:
            return 0.7
        elif trips:
            return 0.6
        elif len(pairs) >= 2:
            return 0.5
        elif len(pairs) == 1:
            max_community = max(ranks[len(hole_cards):]) if len(community_cards) > 0 else 0
            pair_rank = pairs[0]
            if pair_rank >= max_community:
                return 0.4
            else:
                return 0.3
        else:
            max_community = max(ranks[len(hole_cards):]) if len(community_cards) > 0 else 0
            my_max = max(ranks[:len(hole_cards)])
            if my_max > max_community:
                return 0.2
            return 0.1

    def preflop_strategy(self, round_state, remaining_chips):
        if not self.hand or len(self.hand) < 2:
            return (PokerAction.FOLD, 0)
            
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        group = self.get_hand_group(self.hand)
        
        # Button position (small blind)
        if self.id == self.small_blind_player_id:
            if to_call == self.blind_amount:  # First to act
                if group in [1, 2]:
                    raise_amt = min(3 * self.blind_amount, round_state.max_raise)
                    if raise_amt >= round_state.min_raise and raise_amt <= remaining_chips:
                        return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.ALL_IN, 0)
                elif group in [3, 4]:
                    if to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    if random.random() < 0.3:  # Bluff with weak hands
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
            else:  # Facing a raise
                if group in [1, 2]:
                    if to_call <= 3 * self.blind_amount:
                        raise_amt = min(3 * to_call, round_state.max_raise)
                        if raise_amt >= round_state.min_raise and raise_amt <= remaining_chips:
                            return (PokerAction.RAISE, raise_amt)
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                elif group == 3:
                    if to_call <= 2 * self.blind_amount:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Big blind position
        else:
            if to_call == 0:  # No raise
                if group in [1, 2]:
                    raise_amt = min(3 * self.blind_amount, round_state.max_raise)
                    if raise_amt >= round_state.min_raise and raise_amt <= remaining_chips:
                        return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:  # Facing a raise
                if group in [1, 2]:
                    if to_call <= 3 * self.blind_amount:
                        raise_amt = min(3 * to_call, round_state.max_raise)
                        if raise_amt >= round_state.min_raise and raise_amt <= remaining_chips:
                            return (PokerAction.RAISE, raise_amt)
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
                elif group in [3, 4]:
                    if to_call <= 2 * self.blind_amount:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def postflop_strategy(self, round_state, remaining_chips):
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hand, round_state.community_cards)
        
        # Facing a bet
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.0001)
            if hand_strength > 0.6:  # Strong hand
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.4 and pot_odds < 0.3:  # Pot odds favorable
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.3 and random.random() < 0.2:  # Bluff catch
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # First to act
        else:
            if hand_strength > 0.7:  # Very strong
                bet_size = max(min(pot // 2, round_state.max_raise), round_state.min_raise)
                if bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.ALL_IN, 0)
            elif hand_strength > 0.5:  # Medium strength
                return (PokerAction.CHECK, 0)
            else:  # Weak hand
                if random.random() < 0.2:  # Bluff
                    bet_size = max(min(pot // 2, round_state.max_raise), round_state.min_raise)
                    if bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CHECK, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get current bet amount
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = round_state.current_bet - my_bet
            
            # All-in if can't cover the call
            if to_call >= remaining_chips and to_call > 0:
                return (PokerAction.ALL_IN, 0)
                
            # Pre-flop strategy
            if round_state.round == 'Preflop':
                return self.preflop_strategy(round_state, remaining_chips)
                
            # Post-flop strategy
            else:
                return self.postflop_strategy(round_state, remaining_chips)
                
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass