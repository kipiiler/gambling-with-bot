from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.hand_history = []
        self.opponent_tendencies = {}
        self.big_blind_amount = 0
        self.position = None  # 'BB', 'SB', 'BTN', etc.
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount * 2
        
        # Determine position
        if self.id == big_blind_player_id:
            self.position = 'BB'
        elif self.id == small_blind_player_id:
            self.position = 'SB'
        else:
            self.position = 'BTN'

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for new round
        self.hole_cards = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get hole cards from player hands if available
            if not self.hole_cards and hasattr(round_state, 'player_hands') and str(self.id) in round_state.player_hands:
                self.hole_cards = round_state.player_hands[str(self.id)]
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds and bet sizing
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Determine action based on hand strength, position, and game state
            return self._decide_action(round_state, remaining_chips, hand_strength, pot_odds)
            
        except Exception as e:
            # Safety fallback - fold on any error
            return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.1
        
        card1, card2 = self.hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Base strength calculation
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(val1, val2, suit1 == suit2)
        else:
            return self._postflop_hand_strength(round_state, val1, val2, suit1, suit2)

    def _preflop_hand_strength(self, val1: int, val2: int, suited: bool) -> float:
        """Calculate preflop hand strength"""
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Premium hands
        if (val1 == val2 and val1 >= 10) or (high_card == 14 and low_card >= 10):
            return 0.95
        
        # Strong hands
        if (val1 == val2 and val1 >= 7) or (high_card == 14 and low_card >= 8):
            return 0.8
        
        # Good hands
        if val1 == val2 or (high_card >= 12 and low_card >= 9):
            return 0.7
        
        # Decent hands
        if (high_card >= 11 and low_card >= 7) or (suited and high_card >= 10):
            return 0.6
        
        # Marginal hands
        if high_card >= 10 or (suited and high_card >= 8):
            return 0.4
        
        # Weak hands
        if high_card >= 8:
            return 0.3
        
        return 0.15

    def _postflop_hand_strength(self, round_state: RoundStateClient, val1: int, val2: int, suit1: str, suit2: str) -> float:
        """Calculate postflop hand strength based on board"""
        if not round_state.community_cards:
            return 0.5
        
        # Simple heuristic based on pairs and high cards
        community_ranks = [self._card_rank(card) for card in round_state.community_cards]
        hole_ranks = [val1, val2]
        all_ranks = community_ranks + hole_ranks
        
        # Check for pairs, two pairs, etc.
        rank_counts = {}
        for rank in all_ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        pairs = sum(1 for count in rank_counts.values() if count >= 2)
        
        # Strong made hands
        if max(rank_counts.values()) >= 3:  # Three of a kind or better
            return 0.9
        elif pairs >= 2:  # Two pair
            return 0.75
        elif pairs >= 1:  # One pair
            if max(hole_ranks) in [rank for rank, count in rank_counts.items() if count >= 2]:
                return 0.65  # Our pair
            else:
                return 0.45  # Board pair
        
        # High card
        if max(hole_ranks) >= 12:  # Face card
            return 0.4
        
        return 0.25

    def _card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(card[0], 2)

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return float('inf')
        
        pot_after_call = round_state.pot + call_amount
        return pot_after_call / (call_amount + 0.001)

    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Make action decision based on hand strength and game state"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Check if we can check
        can_check = call_amount == 0
        
        # Stack to pot ratio
        spr = remaining_chips / max(round_state.pot, 1)
        
        # Aggressive play with strong hands
        if hand_strength >= 0.85:
            if can_check:
                # Bet for value with strong hands
                bet_size = min(int(round_state.pot * 0.75), round_state.max_raise)
                if bet_size > 0:
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Always call/raise with premium hands
                if call_amount < remaining_chips * 0.3:
                    raise_size = min(call_amount * 2 + round_state.current_bet, round_state.max_raise)
                    if raise_size > round_state.current_bet:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
        
        # Medium-strong hands
        elif hand_strength >= 0.65:
            if can_check:
                # Sometimes bet, sometimes check
                if round_state.pot > self.big_blind_amount * 2:
                    return (PokerAction.CHECK, 0)
                bet_size = min(int(round_state.pot * 0.5), round_state.max_raise)
                if bet_size > 0:
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Call reasonable bets
                if call_amount <= remaining_chips * 0.15:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Decent hands
        elif hand_strength >= 0.45:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                # Call small bets only
                if call_amount <= self.big_blind_amount * 2:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                # Fold weak hands to any bet
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track hand for analysis
        self.hand_history.append({
            'hole_cards': self.hole_cards.copy() if self.hole_cards else [],
            'community_cards': round_state.community_cards.copy(),
            'final_pot': round_state.pot
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_history = []
        self.hole_cards = []