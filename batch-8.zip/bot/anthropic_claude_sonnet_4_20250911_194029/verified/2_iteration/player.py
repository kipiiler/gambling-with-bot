from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.starting_chips = 0
        self.games_played = 0
        self.total_score = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Calculate pot odds and betting context
        pot_size = round_state.pot
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Ensure we don't bet more than we have
        call_amount = min(call_amount, remaining_chips)
        
        # Conservative strategy based on hand strength
        if hand_strength >= 0.8:  # Very strong hand
            if call_amount == 0:  # No bet to call
                # Make a strong bet
                raise_amount = min(pot_size // 2, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Call or raise
                if call_amount <= pot_size // 4:  # Good pot odds
                    if remaining_chips > call_amount * 3:  # Have room to raise
                        raise_amount = min(call_amount * 2, remaining_chips - call_amount)
                        if raise_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, raise_amount + call_amount)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
                    
        elif hand_strength >= 0.6:  # Good hand
            if call_amount == 0:  # No bet to call
                # Small bet or check
                if pot_size > 0:
                    raise_amount = min(pot_size // 4, remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:
                # Call if reasonable
                if call_amount <= pot_size // 3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        elif hand_strength >= 0.4:  # Marginal hand
            if call_amount == 0:  # No bet to call
                return (PokerAction.CHECK, 0)
            else:
                # Only call small bets
                if call_amount <= self.blind_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        else:  # Weak hand
            if call_amount == 0:  # No bet to call
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength on a scale of 0-1."""
        if not hole_cards or len(hole_cards) != 2:
            return 0.2
            
        # Parse hole cards
        card1_rank, card1_suit = self._parse_card(hole_cards[0])
        card2_rank, card2_suit = self._parse_card(hole_cards[1])
        
        # Base strength from hole cards
        strength = 0.0
        
        # Pair bonus
        if card1_rank == card2_rank:
            if card1_rank >= 10:  # High pair (TT+)
                strength += 0.7
            elif card1_rank >= 7:  # Medium pair (77-99)
                strength += 0.5
            else:  # Low pair
                strength += 0.3
        else:
            # High cards bonus
            high_card = max(card1_rank, card2_rank)
            low_card = min(card1_rank, card2_rank)
            
            if high_card == 14:  # Ace
                strength += 0.4
            elif high_card >= 11:  # Face card
                strength += 0.3
            elif high_card >= 9:  # 9 or T
                strength += 0.2
                
            # Connected cards
            if abs(card1_rank - card2_rank) <= 4:
                strength += 0.1
                
            # Suited cards
            if card1_suit == card2_suit:
                strength += 0.15
        
        # Community card improvements
        if community_cards:
            all_cards = hole_cards + community_cards
            if len(all_cards) >= 5:
                # Check for improved hand strength with community cards
                strength += self._evaluate_made_hand(all_cards)
        
        return min(1.0, strength)
    
    def _evaluate_made_hand(self, all_cards: List[str]) -> float:
        """Evaluate strength bonus from made hands."""
        if len(all_cards) < 5:
            return 0.0
            
        ranks = []
        suits = []
        
        for card in all_cards:
            rank, suit = self._parse_card(card)
            ranks.append(rank)
            suits.append(suit)
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for various hands
        counts = sorted(rank_counts.values(), reverse=True)
        
        # Four of a kind
        if 4 in counts:
            return 0.4
        
        # Full house
        if 3 in counts and 2 in counts:
            return 0.35
        
        # Flush
        if max(suit_counts.values()) >= 5:
            return 0.3
        
        # Straight
        if self._has_straight(ranks):
            return 0.25
        
        # Three of a kind
        if 3 in counts:
            return 0.2
        
        # Two pair
        if counts.count(2) >= 2:
            return 0.15
        
        # One pair
        if 2 in counts:
            return 0.1
        
        return 0.0
    
    def _has_straight(self, ranks: List[int]) -> bool:
        """Check if ranks contain a straight."""
        unique_ranks = sorted(set(ranks))
        
        # Check for wheel (A-2-3-4-5)
        if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
        
        # Check for regular straights
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        
        return False
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank and suit."""
        if len(card) != 2:
            return (2, 's')  # Default fallback
        
        rank_char = card[0]
        suit = card[1]
        
        # Convert rank to number
        if rank_char == 'A':
            rank = 14
        elif rank_char == 'K':
            rank = 13
        elif rank_char == 'Q':
            rank = 12
        elif rank_char == 'J':
            rank = 11
        elif rank_char == 'T':
            rank = 10
        else:
            try:
                rank = int(rank_char)
            except ValueError:
                rank = 2  # Default fallback
        
        return (rank, suit)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.games_played += 1
        self.total_score += player_score