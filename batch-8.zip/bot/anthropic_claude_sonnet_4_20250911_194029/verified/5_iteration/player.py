from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.opponent_history = {}  # Track opponent aggression
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get our hole cards from the beginning if we don't have them
        if not self.hole_cards and hasattr(self, '_current_hole_cards'):
            self.hole_cards = self._current_hole_cards
            
        # Calculate amount needed to call
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Position analysis
        is_big_blind = self.id == self.big_blind_player_id
        is_small_blind = self.id == self.small_blind_player_id
        
        # Hand strength evaluation
        hand_strength = self._evaluate_hand_strength(round_state)
        pot_odds = self._calculate_pot_odds(round_state, call_amount, remaining_chips)
        
        # Update opponent tracking
        self._update_opponent_history(round_state)
        
        # Stack management
        stack_ratio = remaining_chips / max(self.starting_chips, 1)
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, call_amount, is_big_blind, is_small_blind, stack_ratio)
        
        # Post-flop strategy
        return self._postflop_strategy(round_state, remaining_chips, call_amount, hand_strength, pot_odds, stack_ratio)
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, is_big_blind: bool, is_small_blind: bool, stack_ratio: float) -> Tuple[PokerAction, int]:
        # Emergency fold if we can't call
        if call_amount >= remaining_chips * 0.8:
            return (PokerAction.FOLD, 0)
            
        # Default tight range - only play strong hands
        if call_amount == 0:
            # We can check
            return (PokerAction.CHECK, 0)
        
        # Big blind defense - call small raises
        if is_big_blind and call_amount <= self.blind_amount * 2:
            return (PokerAction.CALL, 0)
            
        # Small blind - fold most hands unless very strong
        if is_small_blind and call_amount > self.blind_amount:
            return (PokerAction.FOLD, 0)
            
        # Standard play - call reasonable bets
        if call_amount <= self.blind_amount * 3:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, hand_strength: float, pot_odds: float, stack_ratio: float) -> Tuple[PokerAction, int]:
        # Very strong hands - be aggressive
        if hand_strength >= 0.85:
            if call_amount == 0:
                # Bet for value
                bet_size = min(int(round_state.pot * 0.7), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Raise strong hands
                if call_amount < remaining_chips * 0.3:
                    raise_size = call_amount + min(int(round_state.pot * 0.5), remaining_chips - call_amount)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
        
        # Strong hands
        elif hand_strength >= 0.6:
            if call_amount == 0:
                # Check or small bet
                if round_state.pot > self.blind_amount * 4:
                    return (PokerAction.CHECK, 0)
                bet_size = min(int(round_state.pot * 0.4), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                # Call reasonable bets
                if call_amount <= round_state.pot * 0.6 and call_amount < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
        
        # Medium hands
        elif hand_strength >= 0.3:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= round_state.pot * 0.3 and pot_odds > 3.0:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on community cards"""
        if not round_state.community_cards:
            return 0.5  # Unknown strength pre-flop
            
        # Simple heuristic based on community cards
        community = round_state.community_cards
        
        # Look for pairs, straights, flushes in community
        ranks = [self._card_rank(card) for card in community]
        suits = [card[1] for card in community]
        
        # Check for flush draw
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Check for straight draw
        ranks.sort()
        straight_potential = 0
        for i in range(len(ranks) - 1):
            if ranks[i+1] - ranks[i] <= 2:
                straight_potential += 1
        
        # Check for pairs in community
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        
        # Base strength calculation
        strength = 0.4
        
        # Adjust based on board texture
        if max_rank_count >= 2:  # Pair on board
            strength += 0.1
        if max_suit_count >= 3:  # Flush draw possible
            strength += 0.1
        if straight_potential >= 2:  # Straight draw possible
            strength += 0.1
        
        # River is more reliable
        if round_state.round == 'River':
            strength += 0.1
        elif round_state.round == 'Turn':
            strength += 0.05
            
        return min(strength, 0.9)
    
    def _card_rank(self, card: str) -> int:
        """Convert card rank to number"""
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int, remaining_chips: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return float('inf')
        total_pot = round_state.pot + call_amount
        return total_pot / max(call_amount, 1)
    
    def _update_opponent_history(self, round_state: RoundStateClient):
        """Track opponent betting patterns"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if player_id not in self.opponent_history:
                    self.opponent_history[player_id] = {'aggressive': 0, 'passive': 0}
                
                if action in ['Raise', 'All-in']:
                    self.opponent_history[player_id]['aggressive'] += 1
                elif action in ['Call', 'Check']:
                    self.opponent_history[player_id]['passive'] += 1
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hole_cards = []
        self.opponent_history = {}