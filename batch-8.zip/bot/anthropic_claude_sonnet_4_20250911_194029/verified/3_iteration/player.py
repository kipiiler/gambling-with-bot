from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.current_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.position = 0
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.current_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hands_played = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        if round_state.round == "Preflop":
            self.hands_played += 1
            
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.current_chips = remaining_chips
        
        # Get our current bet in this round
        our_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - our_bet
        
        # Calculate position (heads-up: button vs big blind)
        is_button = len(round_state.current_player) == 2 and self.id != self.big_blind_player
        
        if round_state.round == "Preflop":
            return self._preflop_action(round_state, call_amount, is_button)
        else:
            return self._postflop_action(round_state, call_amount, is_button)
    
    def _preflop_action(self, round_state: RoundStateClient, call_amount: int, is_button: bool) -> Tuple[PokerAction, int]:
        hand_strength = self._evaluate_preflop_hand()
        pot_size = round_state.pot
        
        # No bet to us
        if call_amount == 0:
            if hand_strength >= 0.8:  # Premium hands
                bet_size = max(round_state.min_raise, pot_size)
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            elif hand_strength >= 0.6:  # Good hands
                bet_size = max(round_state.min_raise, pot_size // 2)
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            elif hand_strength >= 0.4:  # Decent hands
                if is_button:  # More aggressive on button
                    bet_size = max(round_state.min_raise, pot_size // 3)
                    return (PokerAction.RAISE, min(bet_size, self.current_chips))
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # There's a bet to us
        pot_odds = call_amount / (pot_size + call_amount + 0.01)
        
        if hand_strength >= 0.85:  # Premium hands - always raise
            raise_size = max(round_state.min_raise, pot_size)
            if raise_size <= self.current_chips:
                return (PokerAction.RAISE, raise_size)
            else:
                return (PokerAction.ALL_IN, 0)
                
        elif hand_strength >= 0.7:  # Strong hands
            if pot_odds < 0.3:  # Good pot odds
                raise_size = max(round_state.min_raise, pot_size // 2)
                if raise_size <= self.current_chips:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
                
        elif hand_strength >= 0.5:  # Decent hands
            if pot_odds < 0.25:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.3 and is_button and pot_odds < 0.2:
            # Bluff with position and good pot odds
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def _postflop_action(self, round_state: RoundStateClient, call_amount: int, is_button: bool) -> Tuple[PokerAction, int]:
        hand_strength = self._evaluate_postflop_hand(round_state.community_cards)
        board_texture = self._analyze_board_texture(round_state.community_cards)
        pot_size = round_state.pot
        
        # No bet to us
        if call_amount == 0:
            if hand_strength >= 0.8:  # Very strong hands
                bet_size = max(round_state.min_raise, int(pot_size * 0.8))
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            elif hand_strength >= 0.65:  # Good hands
                bet_size = max(round_state.min_raise, int(pot_size * 0.6))
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            elif hand_strength >= 0.5:  # Medium hands
                bet_size = max(round_state.min_raise, int(pot_size * 0.4))
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            elif hand_strength >= 0.3 and board_texture['is_bluff_favorable'] and is_button:
                # Bluff on favorable boards with position
                bet_size = max(round_state.min_raise, int(pot_size * 0.5))
                return (PokerAction.RAISE, min(bet_size, self.current_chips))
            else:
                return (PokerAction.CHECK, 0)
        
        # There's a bet to us
        pot_odds = call_amount / (pot_size + call_amount + 0.01)
        
        if hand_strength >= 0.85:  # Nuts or near nuts
            if call_amount < self.current_chips // 2:
                raise_size = max(round_state.min_raise, pot_size)
                return (PokerAction.RAISE, min(raise_size, self.current_chips))
            else:
                return (PokerAction.ALL_IN, 0)
                
        elif hand_strength >= 0.7:  # Strong hands
            if pot_odds < 0.4:
                raise_size = max(round_state.min_raise, int(pot_size * 0.6))
                if raise_size <= self.current_chips:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
                
        elif hand_strength >= 0.5:  # Medium hands
            if pot_odds < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        elif hand_strength >= 0.25:  # Weak hands with some potential
            if pot_odds < 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.FOLD, 0)
    
    def _evaluate_preflop_hand(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.3
            
        card1, card2 = self.hole_cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values[rank1], rank_values[rank2]
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        is_suited = suit1 == suit2
        is_pair = val1 == val2
        
        # Premium pairs
        if is_pair:
            if high_card >= 13:  # AA, KK
                return 0.95
            elif high_card >= 11:  # QQ, JJ
                return 0.85
            elif high_card >= 9:  # TT, 99
                return 0.75
            elif high_card >= 7:  # 88, 77
                return 0.65
            else:  # 66 and below
                return 0.55
        
        # High card combinations
        if high_card == 14:  # Ace
            if low_card >= 12:  # AK, AQ
                return 0.9 if is_suited else 0.8
            elif low_card >= 10:  # AJ, AT
                return 0.75 if is_suited else 0.65
            elif low_card >= 8:  # A9, A8
                return 0.6 if is_suited else 0.45
            elif low_card >= 5:  # A7-A5
                return 0.55 if is_suited else 0.35
            else:  # A4-A2
                return 0.5 if is_suited else 0.25
                
        elif high_card == 13:  # King
            if low_card >= 11:  # KQ, KJ
                return 0.75 if is_suited else 0.6
            elif low_card >= 9:  # KT, K9
                return 0.6 if is_suited else 0.45
            else:
                return 0.45 if is_suited else 0.3
                
        elif high_card == 12:  # Queen
            if low_card >= 10:  # QJ, QT
                return 0.65 if is_suited else 0.5
            elif low_card >= 8:  # Q9, Q8
                return 0.5 if is_suited else 0.35
            else:
                return 0.35 if is_suited else 0.2
                
        elif high_card >= 10:  # Jack, Ten
            if abs(val1 - val2) <= 2:  # Connected
                return 0.55 if is_suited else 0.4
            else:
                return 0.4 if is_suited else 0.25
        
        # Small suited connectors and gaps
        if is_suited:
            if abs(val1 - val2) <= 1:  # Suited connectors
                return 0.45
            elif abs(val1 - val2) <= 3:  # Suited gaps
                return 0.35
        
        # Connected cards
        if abs(val1 - val2) <= 1 and high_card >= 8:
            return 0.4
            
        return 0.2  # Trash hands
    
    def _evaluate_postflop_hand(self, community_cards: List[str]) -> float:
        if len(self.hole_cards) != 2:
            return 0.3
            
        all_cards = self.hole_cards + community_cards
        hand_rank, high_cards = self._get_hand_rank(all_cards)
        
        # Convert hand rank to strength (higher rank = stronger hand)
        if hand_rank >= 8:  # Straight flush or better
            return 0.99
        elif hand_rank == 7:  # Four of a kind
            return 0.95
        elif hand_rank == 6:  # Full house
            return 0.9
        elif hand_rank == 5:  # Flush
            return 0.8
        elif hand_rank == 4:  # Straight
            return 0.75
        elif hand_rank == 3:  # Three of a kind
            return 0.7
        elif hand_rank == 2:  # Two pair
            return 0.6
        elif hand_rank == 1:  # One pair
            # Evaluate pair strength
            pair_rank = high_cards[0]
            if pair_rank >= 13:  # Top pair or better
                return 0.55
            elif pair_rank >= 10:
                return 0.45
            else:
                return 0.35
        else:  # High card
            high_card = high_cards[0]
            if high_card >= 13:
                return 0.25
            elif high_card >= 10:
                return 0.15
            else:
                return 0.05
    
    def _get_hand_rank(self, cards: List[str]) -> Tuple[int, List[int]]:
        if len(cards) < 5:
            return 0, [14]  # Default return for incomplete hands
            
        # Parse all cards
        parsed_cards = [self._parse_card(card) for card in cards]
        ranks = [self._rank_to_value(rank) for rank, suit in parsed_cards]
        suits = [suit for rank, suit in parsed_cards]
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Sort ranks by count, then by rank value
        sorted_ranks = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        
        # Check for flush
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = self._check_straight(unique_ranks)
        
        # Determine hand ranking
        counts = [count for rank, count in sorted_ranks]
        high_cards = [rank for rank, count in sorted_ranks]
        
        if is_straight and is_flush:
            return 8, [max(unique_ranks)]  # Straight flush
        elif counts[0] == 4:
            return 7, high_cards  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 6, high_cards  # Full house
        elif is_flush:
            return 5, sorted(unique_ranks, reverse=True)[:5]  # Flush
        elif is_straight:
            return 4, [max(unique_ranks)]  # Straight
        elif counts[0] == 3:
            return 3, high_cards  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 2, high_cards  # Two pair
        elif counts[0] == 2:
            return 1, high_cards  # One pair
        else:
            return 0, sorted(unique_ranks, reverse=True)[:5]  # High card
    
    def _check_straight(self, unique_ranks: List[int]) -> bool:
        if len(unique_ranks) < 5:
            return False
            
        # Check for A-2-3-4-5 straight (wheel)
        if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
            
        # Check for regular straights
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i + 4] == 4:
                return True
        return False
    
    def _analyze_board_texture(self, community_cards: List[str]) -> dict:
        if len(community_cards) < 3:
            return {'is_bluff_favorable': False, 'is_wet': False, 'is_paired': False}
            
        parsed_cards = [self._parse_card(card) for card in community_cards]
        ranks = [self._rank_to_value(rank) for rank, suit in parsed_cards]
        suits = [suit for rank, suit in parsed_cards]
        
        # Check for pairs on board
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        is_paired = any(count >= 2 for count in rank_counts.values())
        
        # Check for flush draws
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        has_flush_draw = any(count >= 3 for count in suit_counts.values())
        
        # Check for straight draws
        sorted_ranks = sorted(set(ranks), reverse=True)
        has_straight_draw = self._has_straight_draw(sorted_ranks)
        
        is_wet = has_flush_draw or has_straight_draw
        is_bluff_favorable = not is_wet and not is_paired and len(community_cards) >= 4
        
        return {
            'is_bluff_favorable': is_bluff_favorable,
            'is_wet': is_wet,
            'is_paired': is_paired
        }
    
    def _has_straight_draw(self, sorted_ranks: List[int]) -> bool:
        if len(sorted_ranks) < 3:
            return False
            
        # Check for potential straights
        for i in range(len(sorted_ranks) - 2):
            if sorted_ranks[i] - sorted_ranks[i + 2] <= 4:
                return True
        return False
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        return card[0], card[1]
    
    def _rank_to_value(self, rank: str) -> int:
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(rank, 2)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        if round_state.round == "Preflop":
            # Extract hole cards from player hands if available
            for player_id, cards in getattr(round_state, 'player_hands', {}).items():
                if int(player_id) == self.id:
                    self.hole_cards = cards
                    break
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass