from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.position_type = None  # 'BB', 'SB', or 'OTHER'
        self.num_players = 0
        self.hand_history = []
        self.opponent_stats = {}
        self.current_hand_actions = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        
        # Determine position
        if self.id == big_blind_player_id:
            self.position_type = 'BB'
        elif self.id == small_blind_player_id:
            self.position_type = 'SB'
        else:
            self.position_type = 'OTHER'
            
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[str(player_id)] = {
                    'hands_played': 0,
                    'vpip': 0,  # Voluntarily put money in pot
                    'aggression': 0,
                    'fold_to_raise': 0,
                    'total_actions': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []
        self.current_hand_actions = {}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent tracking
        self._update_opponent_stats(round_state)
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds and implied odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Determine position strength
        position_strength = self._get_position_strength(round_state)
        
        # Get opponent tendencies
        opponent_factor = self._analyze_opponents(round_state)
        
        # Combine all factors for decision
        action_score = (hand_strength * 0.4 + 
                       pot_odds * 0.3 + 
                       position_strength * 0.2 + 
                       opponent_factor * 0.1)
        
        return self._decide_action(round_state, remaining_chips, action_score, hand_strength)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate current hand strength on scale 0-1"""
        if not self.hole_cards:
            return 0.5
            
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength()
        else:
            return self._postflop_hand_strength(round_state.community_cards)

    def _preflop_hand_strength(self) -> float:
        """Evaluate preflop hand strength"""
        if len(self.hole_cards) < 2:
            return 0.5
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 7), rank_values.get(rank2, 7)
        high_card, low_card = max(val1, val2), min(val1, val2)
        
        # Premium hands
        if (high_card >= 13 and low_card >= 13) or (high_card == 14 and low_card >= 11):
            return 0.95
        
        # Strong pairs
        if val1 == val2:
            if val1 >= 10:
                return 0.9
            elif val1 >= 7:
                return 0.75
            else:
                return 0.6
                
        # Suited connectors and high cards
        is_suited = suit1 == suit2
        is_connected = abs(val1 - val2) <= 1
        
        if is_suited and high_card >= 12:
            return 0.8
        elif is_suited and is_connected:
            return 0.7
        elif high_card >= 13:
            return 0.65
        elif is_suited and high_card >= 10:
            return 0.6
        elif high_card >= 10 and low_card >= 8:
            return 0.55
        else:
            return 0.3

    def _postflop_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if not self.hole_cards or not community_cards:
            return 0.5
            
        all_cards = self.hole_cards + community_cards
        hand_rank = self._get_hand_rank(all_cards)
        
        # Convert hand rank to strength (higher rank = stronger hand)
        strength_map = {
            0: 0.15,  # High card
            1: 0.35,  # One pair
            2: 0.55,  # Two pair
            3: 0.75,  # Three of a kind
            4: 0.85,  # Straight
            5: 0.87,  # Flush
            6: 0.92,  # Full house
            7: 0.97,  # Four of a kind
            8: 0.99,  # Straight flush
            9: 1.0    # Royal flush
        }
        
        return strength_map.get(hand_rank, 0.5)

    def _get_hand_rank(self, cards: List[str]) -> int:
        """Get poker hand ranking (0=high card, 9=royal flush)"""
        if len(cards) < 5:
            return 0
            
        # Convert cards to values and suits
        values = []
        suits = []
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in cards:
            if len(card) >= 2:
                values.append(rank_values.get(card[0], 2))
                suits.append(card[1])
        
        # Count occurrences
        value_counts = {}
        suit_counts = {}
        
        for val in values:
            value_counts[val] = value_counts.get(val, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        unique_values = sorted(set(values))
        is_straight = False
        for i in range(len(unique_values) - 4):
            if unique_values[i+4] - unique_values[i] == 4:
                is_straight = True
                break
        
        # Special case: A-2-3-4-5 straight
        if set([14, 2, 3, 4, 5]).issubset(set(values)):
            is_straight = True
            
        # Get count patterns
        counts = sorted(value_counts.values(), reverse=True)
        
        # Determine hand rank
        if is_straight and is_flush:
            if set([10, 11, 12, 13, 14]).issubset(set(values)):
                return 9  # Royal flush
            return 8  # Straight flush
        elif counts[0] == 4:
            return 7  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 6  # Full house
        elif is_flush:
            return 5  # Flush
        elif is_straight:
            return 4  # Straight
        elif counts[0] == 3:
            return 3  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 2  # Two pair
        elif counts[0] == 2:
            return 1  # One pair
        else:
            return 0  # High card

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds factor"""
        if round_state.current_bet == 0:
            return 0.7  # No cost to continue
            
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 0.7
        if call_amount >= remaining_chips:
            return 0.3  # All-in situation
            
        pot_size = round_state.pot + call_amount
        if pot_size <= 0:
            return 0.5
            
        pot_odds = call_amount / (pot_size + 0.01)  # Add small delta to avoid division by zero
        
        # Convert to factor (lower pot odds = better)
        if pot_odds < 0.2:
            return 0.9
        elif pot_odds < 0.4:
            return 0.7
        elif pot_odds < 0.6:
            return 0.5
        else:
            return 0.3

    def _get_position_strength(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage"""
        num_active = len([p for p in round_state.current_player if p != self.id])
        
        if num_active <= 1:
            return 0.8  # Heads up or last to act
        elif self.position_type == 'BB':
            return 0.6  # Big blind has some positional advantage preflop
        elif self.position_type == 'SB':
            return 0.4  # Small blind is worst position
        else:
            return 0.7  # Button or middle position

    def _analyze_opponents(self, round_state: RoundStateClient) -> float:
        """Analyze opponent behavior for this hand"""
        aggression_seen = 0
        total_opponents = 0
        
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                total_opponents += 1
                if action in ['Raise', 'All-in']:
                    aggression_seen += 1
                    
        if total_opponents == 0:
            return 0.5
            
        aggression_ratio = aggression_seen / (total_opponents + 0.01)
        
        # Adjust strategy based on opponent aggression
        if aggression_ratio > 0.5:
            return 0.3  # Play tighter against aggressive opponents
        elif aggression_ratio > 0.2:
            return 0.5  # Normal adjustment
        else:
            return 0.7  # Can be more aggressive against passive opponents

    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, action_score: float, hand_strength: float) -> Tuple[PokerAction, int]:
        """Make final action decision"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Handle edge cases
        if call_amount >= remaining_chips:
            if action_score > 0.7:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # If no bet to call
        if round_state.current_bet == 0:
            if action_score > 0.8:
                # Strong hand - bet for value
                bet_size = min(int(round_state.pot * 0.7), round_state.max_raise)
                bet_size = max(bet_size, round_state.min_raise)
                return (PokerAction.RAISE, bet_size)
            elif action_score > 0.6:
                # Decent hand - small bet or check
                bet_size = min(int(round_state.pot * 0.4), round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if action_score > 0.85:
            # Very strong - raise
            raise_size = min(int(round_state.pot * 1.0), round_state.max_raise)
            raise_size = max(raise_size, round_state.min_raise)
            return (PokerAction.RAISE, raise_size)
        elif action_score > 0.6:
            # Good enough to call
            return (PokerAction.CALL, 0)
        elif action_score > 0.4 and call_amount < remaining_chips * 0.1:
            # Marginal but cheap - call
            return (PokerAction.CALL, 0)
        else:
            # Fold weak hands
            return (PokerAction.FOLD, 0)

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                stats['total_actions'] += 1
                
                if action in ['Call', 'Raise', 'All-in']:
                    stats['vpip'] += 1
                if action in ['Raise', 'All-in']:
                    stats['aggression'] += 1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store hand history for learning
        self.hand_history.append({
            'hole_cards': self.hole_cards.copy(),
            'community_cards': round_state.community_cards.copy(),
            'final_pot': round_state.pot,
            'result': remaining_chips
        })
        
        # Keep only recent history to manage memory
        if len(self.hand_history) > 50:
            self.hand_history = self.hand_history[-50:]

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_history = []
        self.opponent_stats = {}