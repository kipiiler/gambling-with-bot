from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import logging

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.position = 0
        self.is_small_blind = False
        self.is_big_blind = False
        self.all_players = []
        self.starting_chips = 10000

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand_cards = player_hands
        self.all_players = all_players
        self.is_small_blind = (self.id == small_blind_player_id)
        self.is_big_blind = (self.id == big_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any round-specific variables if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
        
        # Position-based strategy
        is_preflop = round_state.round == 'Preflop'
        players_remaining = len(round_state.current_player)
        
        # Aggressive strategy with strong hands
        if hand_strength > 0.7:
            if round_state.current_bet == 0:
                # No bet yet, raise
                raise_amount = min(remaining_chips, max(round_state.min_raise, int(0.75 * round_state.pot)))
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # There's a bet, decide whether to call or raise
                if hand_strength > 0.85 or pot_odds < 0.3:
                    # Strong hand or good odds, raise
                    total_pot = round_state.pot + call_amount
                    raise_amount = min(remaining_chips, max(round_state.min_raise, int(0.5 * total_pot)))
                    # Ensure we're actually raising, not just calling
                    current_total_bet = round_state.player_bets.get(str(self.id), 0) + call_amount
                    if raise_amount + current_total_bet > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        # Just call if we can't make a valid raise
                        return (PokerAction.CALL, 0)
                else:
                    # Good but not great hand, call if odds are reasonable
                    if pot_odds < 0.4:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        # Medium strength hands
        elif hand_strength > 0.4:
            if is_preflop and players_remaining <= 2:
                # Heads-up with decent cards, be more aggressive
                if round_state.current_bet == 0:
                    return (PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, 20)))
                elif call_amount <= 50:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= 30 or pot_odds < 0.25:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if is_preflop and round_state.current_bet == 0:
                # In late position with weak cards, still try to steal blinds sometimes
                if players_remaining <= 3:
                    return (PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, 15)))
                else:
                    return (PokerAction.FOLD, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= 10 and pot_odds < 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up or record information if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final game analysis if needed
        pass

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate the strength of our hand (0.0 to 1.0)"""
        if not self.hand_cards:
            return 0.0
            
        # Basic hand ranking without community cards (preflop)
        if round_state.round == 'Preflop':
            card1, card2 = self.hand_cards[0], self.hand_cards[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Pair
            if rank1 == rank2:
                if rank1 in ['A', 'K', 'Q', 'J']:
                    return 0.9
                elif rank1 in ['10', '9', '8']:
                    return 0.75
                else:
                    return 0.6
            
            # High cards
            high_card_value = 0
            if rank1 in ['A', 'K', 'Q', 'J'] or rank2 in ['A', 'K', 'Q', 'J']:
                high_card_value = 0.5
                
            # Suited cards bonus
            suited_bonus = 0.1 if suit1 == suit2 else 0
            
            # Connected cards bonus
            connected_bonus = 0
            ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
            try:
                idx1 = ranks.index(rank1)
                idx2 = ranks.index(rank2)
                if abs(idx1 - idx2) == 1:
                    connected_bonus = 0.1
            except ValueError:
                pass
                
            return min(0.9, max(0.1, high_card_value + suited_bonus + connected_bonus))
            
        # Postflop evaluation would go here
        # For now, return a moderate value
        return 0.5