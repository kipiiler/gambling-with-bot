from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.round_state = None
        self.remaining_chips = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate the strength of the hand (simplified)"""
        # Combine hole cards with community cards
        all_cards = hole_cards + community_cards
        
        # Simple hand ranking based on pairs and high cards
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Count occurrences of each rank
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        # Check for pairs, three of a kind, etc.
        pairs = 0
        triplets = 0
        quads = 0
        for count in rank_counts.values():
            if count == 2:
                pairs += 1
            elif count == 3:
                triplets += 1
            elif count == 4:
                quads += 1
                
        # Evaluate hand strength based on combinations
        hand_strength = 0
        if quads > 0:
            hand_strength = 8
        elif triplets > 0 and pairs > 0:
            hand_strength = 7
        elif triplets > 0:
            hand_strength = 4
        elif pairs >= 2:
            hand_strength = 3
        elif pairs == 1:
            hand_strength = 2
            
        # Add high card value
        high_card_value = 0
        for card in hole_cards:
            rank = card[0]
            value = rank_values.get(rank, 0)
            if value > high_card_value:
                high_card_value = value
                
        # Normalize hand strength to between 0 and 1
        return (hand_strength * 14 + high_card_value) / (8 * 14 + 14)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(self.my_hand, round_state.community_cards)
        
        # Positional play - determine if we're in early/mid/late position
        # Approximate position based on number of active players
        active_players = len(round_state.current_player)
        if active_players <= 3:
            # Late position - play more aggressively
            aggression_factor = 1.2
        elif active_players <= 6:
            # Mid position - moderate play
            aggression_factor = 1.0
        else:
            # Early position - tighter play
            aggression_factor = 0.8
            
        # Adjust bet sizing based on hand strength and position
        if round_state.current_bet == 0:
            # We can check or bet
            if hand_strength > 0.7:
                # Strong hand - make a substantial bet
                bet_amount = min(int(remaining_chips * 0.5 * aggression_factor), round_state.max_raise)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength > 0.4:
                # Medium hand - small bet or check
                bet_amount = min(int(remaining_chips * 0.2 * aggression_factor), round_state.max_raise)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # There is a current bet - need to call, raise, or fold
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            
            # Pot odds calculation
            pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
            
            # Compare hand strength to pot odds
            if hand_strength > pot_odds * 1.5:  # Include a margin of safety
                if hand_strength > 0.7:
                    # Strong hand - raise
                    raise_amount = min(int((round_state.pot + call_amount) * 1.5), round_state.max_raise)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    # Good enough hand - call
                    return (PokerAction.CALL, 0)
            else:
                # Not enough equity - fold
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass