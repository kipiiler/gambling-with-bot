from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hand = []
        self.player_ids = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.blind_amount = 0
        self.hand_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.player_ids = all_players
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Extract our hand from player_hands which should be available in round_state or passed context
        # In this case we'll just initialize it as empty since we don't have access to player_hands here
        self.my_hand = []

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """A simple heuristic-based hand strength evaluator"""
        # Combine hand and community cards
        all_cards = hand + community_cards
        
        # Count suits and ranks
        suit_counts = {}
        rank_counts = {}
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in all_cards:
            if len(card) != 2:
                continue
            rank = card[0]
            suit = card[1]
            
            if suit in suit_counts:
                suit_counts[suit] += 1
            else:
                suit_counts[suit] = 1
                
            if rank in rank_counts:
                rank_counts[rank] += 1
            else:
                rank_counts[rank] = 1
        
        # Basic hand ranking approximation
        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        num_pairs = sum(1 for count in rank_counts.values() if count == 2)
        
        # Check for flush potential
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Calculate basic strength based on pairs and high cards
        strength = 0.0
        
        if max_rank_count == 4:
            strength = 0.95  # Four of a kind
        elif max_rank_count == 3 and num_pairs >= 1:
            strength = 0.9  # Full house
        elif max_suit_count >= 5:
            strength = 0.85  # Flush
        elif max_rank_count == 3:
            strength = 0.8  # Three of a kind
        elif num_pairs >= 2:
            strength = 0.7  # Two pair
        elif max_rank_count == 2:
            strength = 0.6  # One pair
        else:
            # High card - use highest card value
            high_card_value = max([rank_values.get(card[0], 0) for card in all_cards] + [0])
            strength = 0.1 + (high_card_value / 14.0) * 0.4  # Scale between 0.1 and 0.5
            
        # Add straight potential bonus (simplified)
        ranks = sorted(set([rank_values.get(card[0], 0) for card in all_cards]))
        if len(ranks) >= 4:
            consecutive = 0
            max_consecutive = 0
            for i in range(1, len(ranks)):
                if ranks[i] - ranks[i-1] == 1:
                    consecutive += 1
                    max_consecutive = max(max_consecutive, consecutive)
                else:
                    consecutive = 0
            if max_consecutive >= 4:  # Four consecutive cards
                strength = min(strength + 0.15, 0.8)  # Boost but cap at reasonable level
                
        # Cap at 1.0
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get current bet amount needed to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Determine if we can check
            can_check = (round_state.current_bet <= my_current_bet)
            
            # Estimate hand strength
            estimated_strength = 0.5  # Default middle strength
            
            # Since we don't have direct access to our cards in this interface,
            # we'll implement position-based and pot-odds aware strategy
            
            # Position awareness (simplified)
            is_in_position = False  # Assume out of position unless we're last to act
            if round_state.current_player and len(round_state.current_player) > 0:
                is_in_position = (str(self.id) == str(round_state.current_player[-1]))
                
            # Number of players still in hand
            active_players = len([p for p in round_state.player_bets.keys() if round_state.player_bets[p] >= 0])
            
            # Preflop strategy adjustments
            if round_state.round == "Preflop":
                # Play tighter preflop - only really strong hands
                # Since we can't see our actual cards, we'll use position and stack size
                if active_players <= 2:  # Heads-up
                    estimated_strength = 0.65
                else:
                    estimated_strength = 0.4
                
                # Adjustment based on position
                if is_in_position:
                    estimated_strength += 0.05
            else:
                # Postflop - assume average strength
                estimated_strength = 0.5 + (0.1 * (active_players <= 2))  # Higher when fewer opponents
                
                # Community cards factor
                if len(round_state.community_cards) > 0:
                    # Placeholder since we can't actually evaluate without our hole cards
                    estimated_strength = 0.5
                    
            # Risk management based on stack size
            stack_ratio = remaining_chips / max(self.starting_chips, 1)  # Avoid division by zero
            
            # Aggression factors
            raise_multiplier = 2.5
            if round_state.round == "Preflop":
                raise_multiplier = 3.0 if estimated_strength > 0.6 else 2.0
            elif round_state.round == "River":
                raise_multiplier = 2.0 if estimated_strength > 0.5 else 1.5
                
            # Decision logic
            if estimated_strength < 0.3:
                # Weak hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif estimated_strength < 0.5:
                # Medium hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                elif call_amount <= remaining_chips * 0.4 and estimated_strength > 0.4:
                    # Consider raising with medium-strength hands when in position
                    raise_amount = min(int(call_amount * raise_multiplier), remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
            elif estimated_strength < 0.7:
                # Strong hand
                if call_amount == 0:
                    # We can make a continuation bet
                    bet_size = min(max(int(remaining_chips * 0.3), round_state.min_raise), remaining_chips)
                    if bet_size <= round_state.max_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # There's already a bet
                    if call_amount <= remaining_chips * 0.4:
                        return (PokerAction.CALL, 0)
                    else:
                        raise_amount = min(int(call_amount * raise_multiplier), remaining_chips)
                        if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                            
            else:
                # Very strong hand
                if call_amount == 0:
                    # Value bet
                    bet_size = min(max(int(remaining_chips * 0.5), round_state.min_raise), remaining_chips)
                    if bet_size <= round_state.max_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Raise for value
                    raise_amount = min(int(call_amount * raise_multiplier), remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                        
            # Fallback to safe action
            if can_check:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        except Exception as e:
            # In case of any error, fold to be safe
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could track statistics here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could do post-game analysis here
        pass