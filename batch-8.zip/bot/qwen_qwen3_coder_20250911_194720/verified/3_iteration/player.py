from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.player_id = None
        self.opponent_id = None
        self.is_big_blind = False
        self.is_small_blind = False
        self.current_round = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        if self.id is not None:
            hand_index = all_players.index(self.id)
            self.my_hand = player_hands[hand_index] if hand_index < len(player_hands) else []
        else:
            self.my_hand = []
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.opponent_id = [p for p in all_players if p != self.id][0] if len(all_players) == 2 else None
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards:
            return 0.0
            
        # High card values
        card_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
            '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        # Extract ranks and suits
        ranks = [card[0] for card in hole_cards + community_cards]
        suits = [card[1] for card in hole_cards + community_cards]
        
        # Count rank frequencies
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        # Basic hand ranking evaluation
        max_rank = max([card_values[r] for r in ranks])
        unique_ranks = len(set(ranks))
        unique_suits = len(set(suits))
        
        # Simple scoring based on pairs, high cards, and suitedness
        score = 0
        pair_bonus = 0
        for count in rank_counts.values():
            if count == 2:
                pair_bonus += 1
            elif count == 3:
                pair_bonus += 3
            elif count == 4:
                pair_bonus += 6
                
        # Add pair bonuses
        score += pair_bonus * 10
        
        # High card value
        score += max_rank / 10.0
        
        # Flush potential bonus
        if unique_suits == 1 or (len(community_cards) <= 3 and unique_suits <= 2):
            score += 2
            
        # Straight potential bonus
        sorted_ranks = sorted([card_values[r] for r in set(ranks)])
        if len(sorted_ranks) >= 4:
            gaps = 0
            for i in range(len(sorted_ranks)-1):
                if sorted_ranks[i+1] - sorted_ranks[i] > 1:
                    gaps += sorted_ranks[i+1] - sorted_ranks[i] - 1
            if gaps <= 1:  # Close to straight
                score += 3
                
        # Normalize to 0-1 range (approximate)
        return min(score / 20.0, 1.0)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get our current bet and the amount needed to call
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_current_bet
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.my_hand, round_state.community_cards)
        
        # Positional and round-based adjustments
        is_preflop = round_state.round == "Preflop"
        is_flop_or_later = not is_preflop
        is_heads_up = len(round_state.current_player) == 2
        
        # Calculate pot odds if we need to call
        pot_odds = 0
        if to_call > 0 and round_state.pot > 0:
            pot_odds = to_call / (to_call + round_state.pot)
        
        # Adjust hand strength based on position and game state
        adjusted_strength = hand_strength
        
        # In heads-up, play more aggressively
        if is_heads_up:
            adjusted_strength += 0.1
            
        # Preflop strategy
        if is_preflop:
            # Premium hands: AA, KK, QQ, JJ, AK
            high_cards = sorted([self.my_hand[0][0], self.my_hand[1][0]], key=lambda x: '23456789TJQKA'.index(x), reverse=True)
            is_pair = self.my_hand[0][0] == self.my_hand[1][0]
            is_high_pair = is_pair and self.my_hand[0][0] in 'TJQKA'
            is_ak = (self.my_hand[0][0] == 'A' and self.my_hand[1][0] == 'K') or \
                    (self.my_hand[0][0] == 'K' and self.my_hand[1][0] == 'A')
            
            # Raise with premium hands
            if is_high_pair or is_ak:
                if to_call == 0:
                    raise_amount = min(round_state.min_raise * 3, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    if hand_strength > 0.7:
                        return (PokerAction.RAISE, min(round_state.min_raise * 2, remaining_chips))
                    elif to_call <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            # Medium strength hands
            elif hand_strength > 0.4:
                if to_call == 0:
                    return (PokerAction.RAISE, min(round_state.min_raise, remaining_chips))
                elif pot_odds < hand_strength:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            # Weak hands
            else:
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= 10:  # Always call small bets
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        # Postflop strategy
        else:
            # Strong hand postflop
            if hand_strength > 0.7:
                if to_call == 0:
                    raise_amount = min(max(round_state.pot // 3, round_state.min_raise), remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    if to_call <= remaining_chips * 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            # Medium strength postflop
            elif hand_strength > 0.4:
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < hand_strength or to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            # Weak hand postflop
            else:
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= 10:  # Always call very small bets
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Default fallback - should not reach here but just in case
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        elif to_call <= remaining_chips * 0.1:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)
            
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing to do here for now
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing to do here for now
        pass