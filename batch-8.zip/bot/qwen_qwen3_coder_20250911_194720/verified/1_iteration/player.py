from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.my_position = 0
        self.num_players = 0
        self.all_players_ids = []
        self.player_hand_strength = 0.0
        self.is_blind_steal_opportunity = False
        self.aggression_factor = 1.0
        self.tightness_factor = 1.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.all_players_ids = all_players[:]
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_hand = [card for card in player_hands if str(self.id) in card][0].split(' ')[1:]
        self.my_position = self.all_players_ids.index(self.id)
        
    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        # Very basic hand strength evaluator based on high card and pairs
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                       '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        ranks = [card[0] for card in hand + community_cards]
        suits = [card[1] for card in hand + community_cards]
        
        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        suit_counts = {suit: suits.count(suit) for suit in set(suits)}
        
        # Check for flush draw or made flush
        flush_possible = max(suit_counts.values()) >= 4
        
        # Check for straight draw or made straight
        unique_ranks = sorted(set([rank_values[r] for r in ranks]), reverse=True)
        straight_possible = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight_possible = True
                break
        
        # Count pairs, trips, quads
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)
        
        # Basic scoring system
        score = 0.0
        if quads:
            score = 0.95
        elif trips and pairs:
            score = 0.90
        elif flush_possible:
            score = 0.85
        elif straight_possible:
            score = 0.80
        elif trips:
            score = 0.75
        elif pairs >= 2:
            score = 0.70
        elif pairs == 1:
            pair_rank = [k for k, v in rank_counts.items() if v == 2][0]
            score = 0.5 + (rank_values[pair_rank] / 30.0)
        else:
            high_card_val = max([rank_values[r] for r in ranks])
            score = high_card_val / 20.0
            
        return min(score, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Pre-flop logic
        if round_state.round == 'Preflop':
            hand_ranks = [self.my_hand[0][0], self.my_hand[1][0]]
            hand_suits = [self.my_hand[0][1], self.my_hand[1][1]]
            
            is_pair = hand_ranks[0] == hand_ranks[1]
            is_suited = hand_suits[0] == hand_suits[1]
            high_cards = [r in ['A', 'K', 'Q', 'J'] for r in hand_ranks]
            num_high = sum(high_cards)
            
            # Very tight pre-flop strategy early position
            if self.my_position <= self.num_players // 3:
                if is_pair and hand_ranks[0] in ['A', 'K']:
                    if to_call <= remaining_chips * 0.1:
                        return (PokerAction.RAISE, min(current_bet * 3, max_raise))
                    elif to_call <= remaining_chips * 0.2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif num_high == 2 and is_suited:
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.RAISE, min(current_bet * 2, max_raise))
                    elif to_call <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif num_high >= 1:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    elif to_call <= remaining_chips * 0.03:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Middle position slightly looser
            elif self.my_position <= 2 * self.num_players // 3:
                if is_pair or num_high >= 1:
                    if to_call <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            # Late position can steal blinds
            else:
                if to_call == 0:
                    return (PokerAction.RAISE, min(max(2 * current_bet, min_raise), max_raise))
                elif to_call <= remaining_chips * 0.15:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Post-flop logic
        else:
            hand_strength = self.evaluate_hand_strength(self.my_hand, round_state.community_cards)
            
            # If we have a very strong hand, bet/raise aggressively
            if hand_strength > 0.8:
                if to_call == 0:
                    return (PokerAction.RAISE, min(int(0.7 * round_state.pot), max_raise))
                else:
                    return (PokerAction.RAISE, min(current_bet + int(0.7 * round_state.pot), max_raise))
            
            # If we have a decent hand, call reasonable bets
            elif hand_strength > 0.6:
                if to_call <= remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # If we have a weak hand but there's no bet, check
            elif to_call == 0:
                return (PokerAction.CHECK, 0)
            
            # Otherwise fold
            else:
                return (PokerAction.FOLD, 0)
                
        # Default fallback
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        elif to_call <= remaining_chips * 0.1:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass