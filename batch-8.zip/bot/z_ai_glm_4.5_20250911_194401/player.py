from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

def hand_strength(cards):
    if len(cards) < 5:
        return (0, tuple(sorted([int(c[0]) if c[0].isdigit() else 10 if c[0]=='T' else 11 if c[0]=='J' else 12 if c[0]=='Q' else 13 if c[0]=='K' else 14 for c in cards], reverse=True)[:5]))
    rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
    suits = [c[1] for c in cards]
    ranks = sorted([rank_map[c[0]] for c in cards], reverse=True)
    flush = any(suits.count(s) >= 5 for s in suits)
    straight = False
    unique_ranks = sorted(list(set(ranks)), reverse=True)
    if len(unique_ranks) >= 5:
        for i in range(len(unique_ranks)-4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight = True
                break
        if not straight and 14 in unique_ranks:
            low_ranks = [1 if r==14 else r for r in unique_ranks]
            low_ranks.sort(reverse=True)
            for i in range(len(low_ranks)-4):
                if low_ranks[i] - low_ranks[i+4] == 4:
                    straight = True
                    break
    freq = {}
    for r in ranks:
        freq[r] = freq.get(r,0)+1
    freq_items = sorted(freq.items(), key=lambda x: (x[1],x[0]), reverse=True)
    counts = [x[1] for x in freq_items]
    if straight and flush:
        return (8, tuple(sorted(unique_ranks, reverse=True)[:5]))
    elif flush:
        flush_ranks = sorted([r for r, s in zip(ranks, suits) if suits.count(s)>=5], reverse=True)[:5]
        return (5, tuple(flush_ranks))
    elif straight:
        return (4, tuple(sorted(unique_ranks, reverse=True)[:5]))
    elif counts[0] == 4:
        return (7, (freq_items[0][0], freq_items[1][0]))
    elif counts[0] == 3 and counts[1] == 2:
        return (6, (freq_items[0][0], freq_items[1][0]))
    elif counts[0] == 3:
        return (3, (freq_items[0][0], freq_items[1][0], freq_items[2][0]))
    elif counts[0] == 2 and counts[1] == 2:
        return (2, (freq_items[0][0], freq_items[1][0], freq_items[2][0]))
    elif counts[0] == 2:
        return (1, (freq_items[0][0], freq_items[1][0], freq_items[2][0], freq_items[3][0]))
    else:
        return (0, tuple(sorted(ranks, reverse=True)[:5]))

def pre_flop_hand_value(hole_cards):
    if len(hole_cards) != 2:
        return 0
    rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
    r1 = rank_map[hole_cards[0][0]]
    r2 = rank_map[hole_cards[1][0]]
    suited = (hole_cards[0][1] == hole_cards[1][1])
    if r1 == r2:
        return 80 + r1
    else:
        high = max(r1, r2)
        low = min(r1, r2)
        value = (high + low/2.0) * 3
        if suited:
            value += 4
        return int(value)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.opp_agg = 0.5

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if not self.hole_cards or remaining_chips <= 0:
                return (PokerAction.FOLD, 0)
            
            my_id_str = str(self.id)
            player_bets = round_state.player_bets
            my_current_bet = player_bets.get(my_id_str, 0) if player_bets else 0
            call_amount = round_state.current_bet - my_current_bet
            pot = round_state.pot
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            community_cards = round_state.community_cards

            if not community_cards:
                pf_value = pre_flop_hand_value(self.hole_cards)
                if call_amount == 0:
                    if pf_value >= 80:
                        raise_amt = min(max_raise, max(min_raise, 3 * self.blind_amount))
                        return (PokerAction.RAISE, raise_amt)
                    elif pf_value >= 65:
                        raise_amt = min(max_raise, max(min_raise, 2.5 * self.blind_amount))
                        return (PokerAction.RAISE, raise_amt)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if pf_value >= 80:
                        if call_amount <= 3 * self.blind_amount:
                            if remaining_chips > call_amount + min_raise:
                                raise_amt = min(max_raise, max(min_raise, pot + call_amount))
                                return (PokerAction.RAISE, raise_amt)
                            else:
                                if call_amount <= remaining_chips:
                                    return (PokerAction.CALL, 0)
                                else:
                                    return (PokerAction.ALL_IN, 0)
                        else:
                            if call_amount <= remaining_chips:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.ALL_IN, 0)
                    elif pf_value >= 65:
                        if call_amount <= 3 * self.blind_amount:
                            if call_amount <= remaining_chips:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                all_cards = self.hole_cards + community_cards
                hand_rank, _ = hand_strength(all_cards)
                n_players = len(round_state.current_player)
                
                if n_players >= 3:
                    agg_thres = 7
                    strong_thres = 4
                    moderate_thres = 3
                else:
                    agg_thres = 6
                    strong_thres = 3
                    moderate_thres = 2
                
                if call_amount == 0:
                    if hand_rank >= agg_thres:
                        bet_size = min(max_raise, max(min_raise, (3 * pot) // 4))
                        return (PokerAction.RAISE, bet_size)
                    elif hand_rank >= moderate_thres:
                        bet_size = min(max_raise, max(min_raise, pot // 2))
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if hand_rank >= agg_thres:
                        if call_amount <= pot // 2:
                            if remaining_chips > call_amount + min_raise:
                                raise_amt = min(max_raise, max(min_raise, pot))
                                return (PokerAction.RAISE, raise_amt)
                            else:
                                if call_amount <= remaining_chips:
                                    return (PokerAction.CALL, 0)
                                else:
                                    return (PokerAction.ALL_IN, 0)
                        else:
                            if call_amount <= remaining_chips:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.ALL_IN, 0)
                    elif hand_rank >= strong_thres:
                        if call_amount <= pot // 3:
                            if call_amount <= remaining_chips:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass