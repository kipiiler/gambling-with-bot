from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import math

# PokerRound Enum is already provided in the environment, but we include it for completeness if needed.
class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

# Helper for card evaluation
class HandEvaluator:
    """
    A simplified hand evaluator to estimate hand strength.
    Maps poker hands to a numeric score for comparison.
    Higher score is better.
    This is a basic lookup and does not cover all combinations perfectly but is efficient.
    For stronger bots, one might use a full exhaustive evaluator or lookup tables.
    """
    RANKS = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
    RANKS_REVERSED = {v: k for k, v in RANKS.items()}

    @staticmethod
    def _get_rank(card: str) -> int:
        return HandEvaluator.RANKS[card[0]]

    @staticmethod
    def _get_suit(card: str) -> str:
        return card[1]

    @staticmethod
    def _is_flush(cards: List[str]) -> bool:
        suits = [HandEvaluator._get_suit(c) for c in cards]
        return any(suits.count(s) >= 5 for s in set(suits))

    @staticmethod
    def _to_sorted_ranks(cards: List[str]) -> List[int]:
        return sorted([HandEvaluator._get_rank(c) for c in cards], reverse=True)

    @staticmethod
    def _rank_groups(ranks: List[int]) -> List[Tuple[int, int]]:
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        return sorted(rank_count.items(), key=lambda item: (item[1], item[0]), reverse=True)

    @staticmethod
    def _is_straight(sorted_ranks: List[int]) -> Tuple[bool, Optional[int]]:
        unique_ranks = sorted(list(set(sorted_ranks)), reverse=True)
        if len(unique_ranks) < 5:
            return False, None

        for i in range(len(unique_ranks) - 4):
            is_straight = all(unique_ranks[j] - 1 == unique_ranks[j+1] for j in range(i, i+4))
            if is_straight:
                return True, unique_ranks[i]

        # Check for wheel straight (A, 2, 3, 4, 5)
        if set(unique_ranks[-5:]) == {14, 5, 4, 3, 2}:
            return True, 5

        return False, None

    @staticmethod
    def evaluate_hand(hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.0

        ranks = HandEvaluator._to_sorted_ranks(all_cards)
        groups = HandEvaluator._rank_groups(ranks)
        is_flush = HandEvaluator._is_flush(all_cards)
        is_straight, straight_high = HandEvaluator._is_straight(ranks)

        # Hand strength score calculation
        # Score is in a format: <hand_rank><hand_value1><hand_value2>...
        # Hand rank: 8=Straight Flush, 7=Four of a kind, 6=Full house, 5=Flush, 4=Straight, 3=Three of a kind, 2=Two pair, 1=One pair, 0=High card

        score = 0.0
        hand_rank = 0

        if is_straight and is_flush:
            hand_rank = 8
            score = hand_rank * 100000000 + straight_high
        elif groups[0][1] == 4:
            hand_rank = 7
            score = hand_rank * 100000000 + groups[0][0] * 10000 + groups[1][0]
        elif groups[0][1] == 3 and groups[1][1] >= 2:
            hand_rank = 6
            score = hand_rank * 100000000 + groups[0][0] * 10000 + groups[1][0]
        elif is_flush:
            hand_rank = 5
            # Flush score is based on the top 5 cards of that suit
            suit_counts = {}
            for card in all_cards:
                suit = HandEvaluator._get_suit(card)
                if suit not in suit_counts:
                    suit_counts[suit] = []
                suit_counts[suit].append(HandEvaluator._get_rank(card))

            for suit, cards_in_suit in suit_counts.items():
                if len(cards_in_suit) >= 5:
                    cards_in_suit.sort(reverse=True)
                    score = hand_rank * 100000000
                    for i in range(5):
                        score += cards_in_suit[i] * (20 ** (4 - i))
                    break
        elif is_straight:
            hand_rank = 4
            score = hand_rank * 100000000 + straight_high
        elif groups[0][1] == 3:
            hand_rank = 3
            score = hand_rank * 100000000 + groups[0][0] * 10000 + groups[1][0] * 100 + groups[2][0]
        elif groups[0][1] == 2 and groups[1][1] == 2:
            hand_rank = 2
            score = hand_rank * 100000000 + groups[0][0] * 1000000 + groups[1][0] * 10000 + groups[2][0]
        elif groups[0][1] == 2:
            hand_rank = 1
            score = hand_rank * 100000000 + groups[0][0] * 1000000
            for i in range(1, 4):
                if i < len(groups): score += groups[i][0] * (100 ** (3-i))
        else: # High card
            hand_rank = 0
            score = hand_rank * 100000000
            for i in range(5):
                if i < len(ranks):
                    score += ranks[i] * (20 ** (4 - i))
        
        return float(score)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.my_hole_cards: List[str] = []
        self.blind_amount: int = 0
        self.opponent_model: Dict[int, Dict] = {}  # Basic opponent model
        self.evaluator = HandEvaluator()
        self.log = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called when the game starts. """
        self.starting_chips = starting_chips
        self.my_hole_cards = player_hands
        self.blind_amount = blind_amount
        self.log.append(f"Game started. Blinds: {small_blind_player_id}/{big_blind_player_id}, Amount: {blind_amount}")
        for pid in all_players:
            if pid != self.id:
                self.opponent_model[pid] = {"aggression": 0.5, "vpip": 0.5, "hands_played": 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each round. """
        self.log.append(f"Round {round_state.round_num} started. Chips: {remaining_chips}")
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        # --- Defensive Programming ---
        if self.id not in round_state.current_player:
            self.log.append("ERROR: get_action called when not current player. Folding.")
            return PokerAction.FOLD, 0
        
        # --- 1. Gather Information ---
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_size = round_state.pot + call_amount # Pot size if I call
        effective_stack = remaining_chips
        
        is_preflop = round_state.round == 'Preflop'
        is_heads_up = len(round_state.current_player) == 2
        
        # --- 2. Evaluate Hand Strength ---
        hand_score = self.evaluator.evaluate_hand(self.my_hole_cards, round_state.community_cards)
        
        # Normalize hand score to a 0-1 range for simpler logic
        # Max score is a Royal Flush (e.g., 8.14... * 10^8). Min is High Card (e.g., 0.14...*10^8)
        # We use a simple heuristic-based normalization
        if is_preflop:
            hand_strength = self._get_preflop_hand_strength(self.my_hole_cards)
        else:
            # Normalize post-flop score. Max possible score is around 8.14e8
            # We'll scale it to a [0, 1] range. A score of 1e8 is a very strong hand.
            hand_strength = min(hand_score / (9e8), 1.0)

        # --- 3. Determine Action Based on Strategy ---
        action_type: PokerAction = PokerAction.FOLD
        bet_amount: int = 0

        # --- Pre-Flop Strategy ---
        if is_preflop:
            # Adjust for position (simplified: UTG is tight, Button is loose)
            # In 6-max, positions are UTG, MP, CO, BTN, SB, BB. We don't have position info, so we use aggressiveness as proxy.
            position_factor = 0.5 # Default
            if self.blind_amount > 0 and remaining_chips > 20 * self.blind_amount: # Deep stack, play more hands
                position_factor = 0.6

            adjusted_strength = hand_strength * (0.8 + 0.4 * position_factor)

            if call_amount == 0: # We can check
                if len(round_state.current_player) > 2 and adjusted_strength < 0.4: # Multi-way, weak hand
                    action_type = PokerAction.CHECK
                elif adjusted_strength > 0.7 or (adjusted_strength > 0.5 and is_heads_up):
                    # Raise strong hands for value
                    action_type = PokerAction.RAISE
                    # Pot-sized raise as default
                    bet_amount = min(pot_size, effective_stack)
                    bet_amount = max(round_state.min_raise, bet_amount)
                else:
                    # Limp with medium hands
                    action_type = PokerAction.CHECK
            else: # We have to call or raise
                pot_odds = call_amount / (pot_size + 1e-9) # Avoid div by zero
                if adjusted_strength > 0.65:
                    # Raise with strong hands
                    action_type = PokerAction.RAISE
                    # Raise 2.5x pot for aggression
                    bet_amount = min(2.5 * pot_size, effective_stack)
                    bet_amount = max(round_state.min_raise, bet_amount)
                elif adjusted_strength > 0.4 and pot_odds < 0.25:
                    # Call with decent hands if odds are good
                    action_type = PokerAction.CALL
                elif adjusted_strength > 0.6 and call_amount < 0.1 * effective_stack:
                    # Re-raise with very strong hands against small bets
                    action_type = PokerAction.RAISE
                    bet_amount = min(3 * call_amount + pot_size, effective_stack)
                    bet_amount = max(round_state.min_raise, bet_amount)
                else:
                    action_type = PokerAction.FOLD
        
        # --- Post-Flop Strategy (Flop, Turn, River) ---
        else:
            pot_odds = call_amount / (pot_size + 1e-9)

            # --- Determine Betting Action (when no one has bet or we can check) ---
            if call_amount == 0:
                if hand_strength > 0.85 and random.random() > 0.3:
                    # Bet for value with monster hands, sometimes slow play
                    action_type = PokerAction.RAISE
                    bet_amount = min(0.75 * pot_size, effective_stack)
                elif hand_strength > 0.6 and (is_heads_up or random.random() > 0.5):
                    # Semi-bluff or value bet with strong hands
                    action_type = PokerAction.RAISE
                    bet_amount = min(0.5 * pot_size, effective_stack)
                elif hand_strength < 0.3:
                    # Pure bluff with very weak hands, infrequently
                    if random.random() < 0.1 and is_heads_up:
                        action_type = PokerAction.RAISE
                        bet_amount = min(0.6 * pot_size, effective_stack)
                    else:
                        action_type = PokerAction.CHECK
                else:
                    # Check with medium strength or drawing hands
                    action_type = PokerAction.CHECK
            
            # --- Determine Reaction to a Bet (when call_amount > 0) ---
            else:
                if hand_strength > 0.8: # Monster
                    if call_amount < 0.3 * effective_stack:
                        action_type = PokerAction.RAISE
                        bet_amount = min(pot_size + call_amount, effective_stack)
                    else:
                        action_type = PokerAction.ALL_IN
                elif hand_strength > 0.65: # Strong hand
                    if call_amount < 0.2 * effective_stack: # Bet is small
                        action_type = PokerAction.RAISE
                        bet_amount = min(1.5 * pot_size, effective_stack)
                    elif pot_odds < hand_strength * 0.5: # Good pot odds or big hand
                        action_type = PokerAction.CALL
                    else:
                        if random.random() < 0.2: # Occasional bluff raise
                            action_type = PokerAction.RAISE
                            bet_amount = min(pot_size * 1.8, effective_stack)
                        else:
                            action_type = PokerAction.FOLD
                elif hand_strength > 0.4: # Medium hand
                    if pot_odds < 0.2:
                        action_type = PokerAction.CALL
                    elif random.random() < 0.15 and call_amount < 0.1 * effective_stack and is_heads_up:
                        # Bluff raise as a semi-bluff
                        action_type = PokerAction.RAISE
                        bet_amount = min(pot_size * 1.5, effective_stack)
                    else:
                        action_type = PokerAction.FOLD
                elif hand_strength > 0.25 and pot_odds < 0.1: # Weak draw
                    action_type = PokerAction.CALL
                else: # Very weak
                    action_type = PokerAction.FOLD
        
        # --- Final Action Validation and Sanitization ---
        # Convert CHECK to CALL if it's not allowed (shouldn't happen with our logic but is a safeguard)
        if action_type == PokerAction.CHECK and call_amount > 0:
            self.log.append("Logic Error: Trying to check when call_amount > 0. Defaulting to FOLD.")
            return PokerAction.FOLD, 0

        # Ensure RAISE amount is within bounds
        if action_type == PokerAction.RAISE:
            # The total bet we put in must be my_current_bet + bet_amount
            # This must be > current_bet (which is the bet to call)
            # The min_raise is the minimum additional amount we need to raise to.
            # e.g., bet to call is 50, min_raise is 100. So we must bet at least 100 total. Our raise size is 100 - current_bet (50) = 50.
            
            # The amount we provide with RAISE is the TOTAL NEW BET, not the amount to raise by.
            # So if current bet is 50, and min_raise is 100, we must bet at least 100. Our bet_amount param must be 100.
            
            # Let's re-evaluate: the raise action is (PokerAction.RAISE, total_bet_amount)
            # total_bet_amount must be >= current_bet + min_raise
            # and <= current_bet + max_raise (which is our stack)
            
            # Our bet_amount is the *size of the new total bet* we are making.
            # The amount we are raising by is: (our_new_total_bet) - (current_bet_total_to_call)
            # So, our_new_total_bet = my_current_bet + amount_we_put_into_pot_this_round
            
            # The server expects for RAISE: (RAISE, NEW_TOTAL_BET)
            min_total_bet = round_state.current_bet + round_state.min_raise
            max_total_bet = my_current_bet + effective_stack # Bet everything we have
            
            if bet_amount < min_total_bet:
                bet_amount = min_total_bet
            if bet_amount > max_total_bet:
                bet_amount = max_total_bet
            
            # If we can't even make the min raise, then we might have to call or all-in
            if min_total_bet > my_current_bet + effective_stack:
                # This means we don't have enough for the min raise, so we can only call or go all-in
                if call_amount <= effective_stack:
                    action_type = PokerAction.CALL
                    bet_amount = 0 # Amount is ignored for call
                else:
                    action_type = PokerAction.ALL_IN
                    bet_amount = 0 # Amount is ignored for all-in
            elif bet_amount >= my_current_bet + effective_stack * 0.95 : # If raise is > 95% of stack, just all-in
                 action_type = PokerAction.ALL_IN
                 bet_amount = 0

        # Final safety net: ensure we don't bet more than we have.
        # This is mostly for CALL, but good practice.
        elif action_type == PokerAction.CALL:
            if call_amount > effective_stack:
                action_type = PokerAction.ALL_IN
                bet_amount = 0
        
        self.log.append(f"Action: {action_type.name}, Amount: {bet_amount}. Strength: {hand_strength:.2f}, Pot: {pot_size}, Call: {call_amount}")
        return action_type, bet_amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        if str(self.id) in round_state.player_actions:
            self.log.append(f"Round ended. My action: {round_state.player_actions[str(self.id)]}. Chips: {remaining_chips}")
        else:
            self.log.append(f"Round ended. I folded or was not involved. Chips: {remaining_chips}")
        # Clear hole cards for next round
        self.my_hole_cards = [] 

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        self.log.append(f"Game ended. My score: {player_score}. Scores: {all_scores}")
        # In a real competition, we'd save this log or update a persistent model.
        # For this submission, we just keep it in memory, which is fine for 1000 hands.
        pass

    # --- Helper Methods ---

    def _get_preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """Returns a simplified strength score for hole cards (0.0 to 1.0)."""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0

        c1, c2 = hole_cards
        r1, s1 = c1[0], c1[1]
        r2, s2 = c2[0], c2[1]

        # Sort by rank
        if HandEvaluator.RANKS[r1] < HandEvaluator.RANKS[r2]:
            r1, r2 = r2, r1
        
        is_pair = (r1 == r2)
        is_suited = (s1 == s2)
        is_connected = abs(HandEvaluator.RANKS[r1] - HandEvaluator.RANKS[r2]) == 1
        is_one_gapper = abs(HandEvaluator.RANKS[r1] - HandEvaluator.RANKS[r2]) == 2
        
        rank_high = HandEvaluator.RANKS[r1]
        rank_low = HandEvaluator.RANKS[r2]

        score = 0.0
        # Pairs are strong
        if is_pair:
            score = 0.5 + (rank_high / 14.0) * 0.4 # AA = 0.9, 22 = 0.51
        # High cards (AK, AQ)
        elif rank_high >= 12: # Ace or King
            score = 0.4 + (rank_high / 14.0) * 0.3 
            if rank_low >= 10: # Broadways
                score += 0.1
            if is_suited:
                score += 0.1
        # Suited connectors/gappers
        elif is_suited and (is_connected or is_one_gapper):
            score = 0.3 + (rank_high / 14.0) * 0.2
        # Other hands
        else:
            score = (rank_high / 14.0) * 0.25 + (rank_low / 14.0) * 0.15
            if is_suited:
                score += 0.05
        
        return min(max(score, 0.0), 1.0)