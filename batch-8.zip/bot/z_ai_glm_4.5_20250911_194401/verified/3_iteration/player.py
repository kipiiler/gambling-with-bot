from typing import List, Tuple, Dict, Any
import random
import collections
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Card ordering for comparison
CARD_RANKS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
CARD_SUITS = {'h': 0, 'd': 1, 'c': 2, 's': 3}

# Precomputed hand strength lookup table (simplified, in a real bot this would be more comprehensive)
# For now, using a simplified calculation based on hole cards and community cards
def evaluate_hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    """Evaluate hand strength as a float between 0.0 and 1.0."""
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        # Not enough cards to evaluate, return base strength of hole cards
        if len(hole_cards) == 2:
            rank1, rank2 = CARD_RANKS[hole_cards[0][0]], CARD_RANKS[hole_cards[1][0]]
            suit1, suit2 = hole_cards[0][1], hole_cards[1][1]
            
            # Pair
            if rank1 == rank2:
                return 0.7 + (rank1 / 14) * 0.3
            
            # Suited
            if suit1 == suit2:
                return 0.4 + (max(rank1, rank2) / 14) * 0.2
            
            # High card
            return 0.3 + (max(rank1, rank2) / 14) * 0.1
        return 0.5
    
    # Simplified hand evaluation - count high cards, pairs, etc.
    ranks = [CARD_RANKS[c[0]] for c in all_cards]
    suits = [c[1] for c in all_cards]
    rank_counts = collections.Counter(ranks)
    suit_counts = collections.Counter(suits)
    
    # Check for flush
    is_flush = max(suit_counts.values()) >= 5
    
    # Check for straight
    unique_ranks = sorted(set(ranks))
    is_straight = False
    if len(unique_ranks) >= 5:
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                is_straight = True
        # Check for A-2-3-4-5 straight
        if set(ranks) >= {14, 2, 3, 4, 5}:
            is_straight = True
    
    # Get hand rank
    counts = sorted(rank_counts.values(), reverse=True)
    
    # Evaluate hand strength
    if is_straight and is_flush:
        return 0.95 + (max(ranks) / 14) * 0.05  # Straight flush
    elif counts[0] == 4:
        return 0.9 + (max(r for r, c in rank_counts.items() if c == 4) / 14) * 0.05  # Four of a kind
    elif counts[0] == 3 and counts[1] >= 2:
        return 0.85 + (max(r for r, c in rank_counts.items() if c == 3) / 14) * 0.05  # Full house
    elif is_flush:
        return 0.8 + (max(ranks) / 14) * 0.05  # Flush
    elif is_straight:
        return 0.75 + (max(ranks) / 14) * 0.05  # Straight
    elif counts[0] == 3:
        return 0.7 + (max(r for r, c in rank_counts.items() if c == 3) / 14) * 0.05  # Three of a kind
    elif counts[0] == 2 and counts[1] == 2:
        return 0.65 + (max(r for r, c in rank_counts.items() if c == 2) / 14) * 0.05  # Two pair
    elif counts[0] == 2:
        return 0.6 + (max(r for r, c in rank_counts.items() if c == 2) / 14) * 0.05  # One pair
    else:
        return 0.5 + (max(ranks) / 14) * 0.1  # High card

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.hole_cards = []
        self.aggression_factor = 1.0
        self.vpip = 0.0  # Voluntarily Put money In Pot
        self.pfr = 0.0   # Pre-Flop Raise
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = evaluate_hand_strength(self.hole_cards, round_state.community_cards)
            
            # Adjust hand strength based on position and game state
            position_factor = 1.0
            if round_state.round == 'Preflop':
                # Early position is more conservative, late position more aggressive
                if self.id == self.small_blind_player_id or self.id == self.big_blind_player_id:
                    position_factor = 0.9
                else:
                    position_factor = 1.1
            
            adjusted_strength = hand_strength * position_factor
            
            # Pot odds calculation
            pot_odds = 0.0
            if round_state.current_bet > 0:
                to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                pot_odds = to_call / (round_state.pot + to_call + 1e-9)  # Avoid division by zero
            
            # Basic strategy based on hand strength and pot odds
            current_bet_for_me = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - current_bet_for_me
            
            # No one has bet yet
            if round_state.current_bet == 0:
                if adjusted_strength > 0.7:  # Strong hand
                    # Raise between 2.5x and 4x the big blind
                    raise_amount = min(max(round_state.min_raise, int(self.blind_amount * 2.5)), remaining_chips * 3 // 4)
                    return PokerAction.RAISE, raise_amount
                elif adjusted_strength > 0.5:  # Medium hand
                    # Check or small raise
                    if random.random() < 0.5:
                        return PokerAction.CHECK, 0
                    else:
                        raise_amount = min(max(round_state.min_raise, int(self.blind_amount * 2)), remaining_chips // 2)
                        return PokerAction.RAISE, raise_amount
                else:  # Weak hand
                    if random.random() < 0.8:  # Usually check with weak hand if no bet
                        return PokerAction.CHECK, 0
                    else:  # occasional bluff
                        raise_amount = min(max(round_state.min_raise, int(self.blind_amount * 2.5)), remaining_chips // 2)
                        return PokerAction.RAISE, raise_amount
            else:
                # Someone has bet, need to decide whether to call, raise, or fold
                if adjusted_strength > 0.8:  # Very strong hand
                    # Consider raising or going all-in
                    if random.random() < 0.7:
                        # Make a significant raise, but not all-in
                        raise_amount = min(max(round_state.min_raise, round_state.pot + amount_to_call), remaining_chips * 3 // 4)
                        return PokerAction.RAISE, raise_amount
                    else:
                        # Go all in with our strongest hands
                        return PokerAction.ALL_IN, 0
                elif adjusted_strength > pot_odds + 0.1:  # Good hand relative to pot odds
                    if amount_to_call <= remaining_chips // 4 and random.random() < 0.5:
                        # Re-raise occasionally
                        raise_amount = min(max(round_state.min_raise, round_state.pot // 2), remaining_chips * 3 // 4)
                        return PokerAction.RAISE, raise_amount
                    else:
                        # Just call
                        return PokerAction.CALL, 0
                elif adjusted_strength > pot_odds:  # Marginally good hand
                    # Just call
                    return PokerAction.CALL, 0
                else:  # Weak hand
                    # Usually fold
                    if random.random() < 0.9:  # 90% fold rate with weak hands
                        return PokerAction.FOLD, 0
                    else:  # occasional bluff
                        if remaining_chips > round_state.pot * 2:
                            return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.FOLD, 0
        except Exception as e:
            # If any error occurs, default to folding to avoid crashing
            return PokerAction.FOLD, 0
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update statistics based on the outcome
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Analyze the game results for future improvement
        pass