from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 50
        self.position = 0
        self.hand = []
        self.opponent_actions = []
        self.aggression_factor = 0
        self.round_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hand = []
        self.opponent_actions = []
        self.aggression_factor = 0
        self.round_count = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Map round names to indices
        round_map = {
            'Preflop': 0,
            'Flop': 1,
            'Turn': 2,
            'River': 3,
            'PREFLOP': 0,
            'FLOP': 1,
            'TURN': 2,
            'RIVER': 3
        }
        
        self.current_round = round_map.get(round_state.round, 0)
        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        
        # Update opponent actions
        if hasattr(round_state, 'player_actions') and round_state.player_actions:
            for player_id, action in round_state.player_actions.items():
                if str(player_id) != str(self.id):
                    self.opponent_actions.append(action)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract basic information
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Simple preflop strategy
        if self.current_round == 0:  # Preflop
            return self.preflop_strategy(round_state, remaining_chips)
        
        # Postflop strategy
        else:
            return self.postflop_strategy(round_state, remaining_chips)

    def preflop_strategy(self, round_state, remaining_chips):
        # Simple preflop hand evaluation based on card strength
        if not hasattr(self, 'hand') or not self.hand:
            if round_state.current_bet > 0:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Determine if we should play based on card quality
        if len(self.hand) >= 2 and self.is_strong_preflop_hand(self.hand):
            if round_state.current_bet == 0:
                # Make a bet if no one has bet
                bet_size = min(200, remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Call or raise based on position and aggression
                if round_state.current_bet < round_state.pot * 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Fold weak hands
            if round_state.current_bet > 0:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def postflop_strategy(self, round_state, remaining_chips):
        # Check if we have a made hand or decent draw
        hand_strength = self.evaluate_hand_strength(round_state.community_cards)
        
        if hand_strength > 0.7:  # Strong hand
            if round_state.current_bet == 0:
                bet_size = min(int(round_state.pot * 0.75), remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Consider raising for value
                if round_state.current_bet < round_state.pot * 0.6:
                    raise_amount = min(int(round_state.current_bet * 2.5), remaining_chips, round_state.max_raise)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
        
        elif hand_strength > 0.3:  # Marginal hand
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                if round_state.current_bet < round_state.pot * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        else:  # Weak hand
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def is_strong_preflop_hand(self, cards):
        """Simple preflop hand strength evaluation"""
        if not cards or len(cards) < 2:
            return False
        
        # High pairs, suited connectors, high cards
        card_values = [c[0] for c in cards]
        card_suits = [c[1] for c in cards]
        
        value_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        v1 = value_map.get(card_values[0][0], 0)
        v2 = value_map.get(card_values[1][0], 0)
        
        # Pocket pairs
        if card_values[0][0] == card_values[1][0]:
            return True
        
        # Suited cards with high value
        if card_suits[0] == card_suits[1] and max(v1, v2) >= 10:
            return True
            
        # High card combinations
        if v1 + v2 >= 20:
            return True
            
        return False

    def evaluate_hand_strength(self, community_cards):
        """Simple hand strength evaluation based on made hands"""
        if not community_cards:
            return 0.0
            
        # Just return a basic strength based on number of connected cards
        # This is a simplified evaluation - in real implementation would use proper hand ranking
        num_community = len(community_cards)
        
        if num_community >= 3:
            # Check for pairs, flushes, straights
            cards = community_cards.copy()
            # Simplified - return moderate strength postflop
            return 0.4 + (0.1 * num_community)
        
        return 0.0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass