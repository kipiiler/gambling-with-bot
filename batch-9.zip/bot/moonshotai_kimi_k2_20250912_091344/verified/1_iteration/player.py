from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import math
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hand = []
        self.position = 0
        self.num_players = 0
        self.opponent_tendencies = {}
        self.stack_history = {}
        self.pot_odds_threshold = 0.25
        self.aggression_factor = 1.0
        self.stage = 0  # 0=preflop, 1=flop, 2=turn, 3=river
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.my_hand = player_hands[self.id] if self.id < len(player_hands) else ""
        self.blind = blind_amount
        
        # Initialize tracking
        for player in all_players:
            if player != self.id:
                self.opponent_tendencies[player] = {
                    'vpip': 0, 'pfr': 0, 'aggression': 0, 'hands_played': 0
                }
                self.stack_history[player] = starting_chips
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stage = ['Preflop', 'Flop', 'Turn', 'River'].index(round_state.round)
        self.current_round_pot = round_state.pot
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.my_hand == "" or len(self.my_hand) < 4:
            return PokerAction.FOLD, 0
            
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength()
        
        # Pot odds calculation
        current_bet = round_state.current_bet
        pot = round_state.pot
        call_amount = max(0, current_bet - round_state.player_bets.get(str(self.id), 0))
        
        if call_amount > 0:
            pot_odds = call_amount / (pot + call_amount)
        else:
            pot_odds = 0
        
        # Position and player count factors
        num_active = len(round_state.current_player)
        position_factor = 1.0 if self.id in round_state.current_player[-2:] else 0.8
        
        # Preflop strategy
        if self.stage == 0:
            return self.preflop_strategy(hand_strength, call_amount, pot, round_state)
        
        # Postflop strategy
        else:
            return self.postflop_strategy(hand_strength, call_amount, pot, pot_odds, round_state)
    
    def preflop_strategy(self, hand_strength, call_amount, pot, round_state):
        # Simplified preflop rankings
        card1, card2 = self.my_hand.split()
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert ranks
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                      '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1, r2 = rank_values[rank1], rank_values[rank2]
        suited = suit1 == suit2
        high_card = max(r1, r2)
        pair = r1 == r2
        
        # Tight-aggressive starting hand selection
        if pair and r1 >= 7:
            return self.raise_action(round_state, 3 * self.blind)
        elif suited and high_card >= 10:
            if call_amount <= self.blind * 2:
                return PokerAction.CALL, 0
            else:
                return self.raise_action(round_state, 2 * self.blind)
        elif high_card >= 11:
            if call_amount <= self.blind:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            return PokerAction.FOLD, 0
    
    def postflop_strategy(self, hand_strength, call_amount, pot, pot_odds, round_state):
        # Basic postflop logic
        if hand_strength > 80:  # Strong hand
            if call_amount == 0:
                return self.bet_action(round_state, max(self.blind, pot // 3))
            else:
                return self.raise_action(round_state, max(pot // 2, call_amount * 2))
        elif hand_strength > 60:  # Medium strength
            if pot_odds < 0.3:
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif hand_strength > 40:  # Weak but playable
            if pot_odds < 0.15 and call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        else:  # Very weak
            return PokerAction.FOLD, 0
    
    def evaluate_hand_strength(self) -> int:
        # Simplified hand strength (0-100)
        if self.stage == 0:
            # Preflop evaluation
            return self.preflop_strength()
        else:
            # Postflop evaluation based on visible cards
            return self.postflop_strength()
    
    def preflop_strength(self) -> int:
        if not self.my_hand:
            return 0
            
        cards = self.my_hand.split()
        rank1, suit1 = cards[0][0], cards[0][1]
        rank2, suit2 = cards[1][0], cards[1][1]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                      '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1, r2 = rank_values[rank1], rank_values[rank2]
        suited = 1 if suit1 == suit2 else 0
        
        # Rough strength calculation
        strength = max(r1, r2) * 5
        if r1 == r2:
            strength += 50
        elif abs(r1 - r2) <= 1 and suited:
            strength += 20
        elif abs(r1 - r2) <= 2:
            strength += 10
            
        return min(100, strength)
    
    def postflop_strength(self) -> int:
        # Extremely simplified postflop - always play tight
        return random.randint(20, 40) + self.random_float_between_0_and_1()
    
    def raise_action(self, round_state: RoundStateClient, amount: int) -> Tuple[PokerAction, int]:
        max_raise = min(amount, round_state.max_raise)
        min_raise = round_state.min_raise
        
        if max_raise < min_raise:
            if max_raise == round_state.max_raise:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
            
        return PokerAction.RAISE, max(min_raise, amount)
    
    def bet_action(self, round_state: RoundStateClient, amount: int) -> Tuple[PokerAction, int]:
        max_bet = min(amount, round_state.max_raise)
        min_bet = round_state.min_raise
        
        if max_bet < min_bet:
            if max_bet == round_state.max_raise:
                return PokerAction.ALL_IN, 0
            return PokerAction.CHECK, 0
            
        return PokerAction.RAISE, max(min_bet, amount)
    
    def random_float_between_0_and_1(self) -> float:
        # Deterministic pseudo-random for reproducibility
        return (hash(str(self.id) + str(self.stage)) % 1000) / 1000
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass