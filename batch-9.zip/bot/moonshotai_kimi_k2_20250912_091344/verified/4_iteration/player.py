from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.player_hands = []
        self.all_players = []
        self.hand_counter = 0
        self.vpip = 0
        self.pfr = 0
        self.aggression_factor = [0, 0]  # [bets/raises, calls]
        self.position = 0
        self.stack_size = 10000
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.hand_counter = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_size = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not round_state.player_hands or str(self.id) not in round_state.player_hands:
            return (PokerAction.FOLD, 0)
        
        my_hand = round_state.player_hands[str(self.id)]
        hole_cards = my_hand.split()
        
        # Basic hand strength
        hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
        
        # Position calculation
        total_players = len([p for p in round_state.current_player])
        position = self._get_position(round_state)
        
        # Pot odds
        pot_odds = round_state.current_bet / (round_state.pot + round_state.current_bet + 1e-9)
        
        # Stack size consideration
        stack_to_pot = remaining_chips / (round_state.pot + 1e-9)
        
        # Pre-flop play
        if round_state.round == "Preflop":
            return self._preflop_strategy(hole_cards, position, round_state, remaining_chips, pot_odds, hand_strength)
        
        # Post-flop play
        return self._postflop_strategy(hole_cards, round_state.community_cards, hand_strength, position, round_state, remaining_chips, pot_odds)
    
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        ranks = []
        suits = []
        
        # Add hole cards
        for card in hole_cards:
            ranks.append(values[card[0]])
            suits.append(card[1])
        
        # Add community cards
        for card in community_cards:
            ranks.append(values[card[0]])
            suits.append(card[1])
        
        if not ranks:
            return 0.0
        
        # Basic hand evaluation
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        # Flush potential
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Determine hand strength
        max_rank = max(rank_counts.keys()) if rank_counts else 0
        flush_potential = max(suit_counts.values()) >= 5
        
        # Basic hand strength calculation
        strength = 0.0
        
        # High card bonus
        strength += max_rank / 14.0
        
        # Pair bonus
        pairs = [r for r, c in rank_counts.items() if c == 2]
        if pairs:
            strength += 0.5 + sorted(pairs, reverse=True)[0] / 14.0
        
        # Two pair bonus
        if len(pairs) >= 2:
            strength += 0.3
            
        # Three of a kind
        trips = [r for r, c in rank_counts.items() if c == 3]
        if trips:
            strength += 1.0
            
        # Four of a kind
        four = [r for r, c in rank_counts.items() if c == 4]
        if four:
            strength += 3.0
            
        # Straight potential
        sorted_ranks = sorted(set(ranks))
        if len(sorted_ranks) >= 5:
            straight = False
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    straight = True
                    break
            if straight:
                strength += 1.5
            
        # Flush
        if flush_potential and community_cards:
            strength += 1.0
            
        return min(strength, 5.0)
    
    def _get_position(self, round_state: RoundStateClient) -> int:
        """Determine position at table"""
        if len(round_state.current_player) <= 2:
            return 1 if str(self.id) == list(round_state.player_bets.keys())[-1] else 0
        else:
            return len(round_state.current_player) - list(round_state.current_player).index(self.id)
    
    def _preflop_strategy(self, hole_cards: List[str], position: int, round_state: RoundStateClient, remaining_chips: int, pot_odds: float, hand_strength: float) -> Tuple[PokerAction, int]:
        """Pre-flop decision making"""
        # Premium hands
        premium_hands = ['AA', 'KK', 'QQ', 'JJ', 'AK', 'AQ']
        hole_str = ''.join([c[0] for c in hole_cards])
        
        hand_rank = hole_str[0] + hole_str[2]
        is_suited = hole_cards[0][1] == hole_cards[1][1]
        
        # Convert to standard notation
        if len(set(hand_rank)) == 1:
            hand_notation = hand_rank[0] + hand_rank[0]
        elif hole_str[0] > hole_str[2]:
            hand_notation = hand_rank[0] + hand_rank[1]
            if is_suited:
                hand_notation += 's'
            else:
                hand_notation += 'o'
        else:
            hand_notation = hand_rank[1] + hand_rank[0]
            if is_suited:
                hand_notation += 's'
            else:
                hand_notation += 'o'
        
        # Default fold
        action = PokerAction.CALL
        
        # Premium hands - raise
        if any(truncated in hand_notation for truncated in premium_hands):
            if position <= 2:  # Early position
                raise_amount = min(round_state.current_bet * 3, round_state.max_raise)
            else:
                raise_amount = min(round_state.current_bet * 2.5, round_state.max_raise)
            return (PokerAction.RAISE, int(raise_amount))
        
        # Quality hands - call/raise
        if self._is_quality_hand(hole_cards):
            if pot_odds < 0.3 and round_state.current_bet > 0:
                return (PokerAction.CALL, 0)
            elif position > len(round_state.current_player) // 2:
                return (PokerAction.RAISE, min(round_state.min_raise * 2, round_state.max_raise))
        
        # Defensive play based on stack size
        if remaining_chips < round_state.current_bet * 3 and hand_strength > 0.3:
            return (PokerAction.CALL, 0)
        
        # Default fold if not good hand and facing bet
        if round_state.current_bet > 0 and hand_strength < 0.2:
            return (PokerAction.FOLD, 0)
        
        return (PokerAction.CALL, 0)
    
    def _is_quality_hand(self, hole_cards: List[str]) -> bool:
        """Determine if hole cards constitute a quality hand"""
        values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        ranks = [values[card[0]] for card in hole_cards]
        suited = hole_cards[0][1] == hole_cards[1][1]
        
        high_card = max(ranks)
        low_card = min(ranks)
        
        # Pocket pairs
        if high_card == low_card:
            return high_card >= 7
        
        # Suited connectors
        if suited and (high_card - low_card <= 4 and high_card >= 9):
            return True
            
        # Broadway cards
        if high_card >= 11:
            return True
            
        return False
    
    def _postflop_strategy(self, hole_cards: List[str], community_cards: List[str], hand_strength: float, position: int, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Post-flop decision making"""
        # Big hand - go for value
        if hand_strength >= 1.5:
            if round_state.current_bet > 0:
                return (PokerAction.RAISE, min(max(round_state.current_bet * 1.5, round_state.min_raise), round_state.max_raise))
            else:
                return (PokerAction.RAISE, min(round_state.pot * 0.75, round_state.max_raise))
        
        # Decent hand - pot control
        if hand_strength >= 0.7:
            if pot_odds < 0.25:
                return (PokerAction.CALL, 0)
            elif round_state.current_bet == 0:
                return (PokerAction.RAISE, min(round_state.pot * 0.5, round_state.max_raise))
        
        # Drawing hand
        if hand_strength >= 0.3 and len(community_cards) < 5:
            if pot_odds < 0.2:
                return (PokerAction.CALL, 0)
        
        # Bluffing spots
        if round_state.current_bet == 0 and position <= 2 and len(community_cards) > 0:
            return (PokerAction.RAISE, min(round_state.pot * 0.4, round_state.max_raise))
        
        # Facing aggression with weak hand
        if round_state.current_bet > remaining_chips * 0.3 and hand_strength < 0.4:
            return (PokerAction.FOLD, 0)
        
        # Default action
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        elif pot_odds < 0.15 and hand_strength > 0.2:
            return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_counter += 1
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass