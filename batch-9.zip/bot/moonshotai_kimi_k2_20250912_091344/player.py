from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.players_count = 0
        self.my_stack = 10000
        self.blind_amount = 0
        self.aggression_factor = 0
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_stack = starting_chips
        self.blind_amount = blind_amount
        self.players_count = len(all_players)
        if self.id in all_players:
            self.position = all_players.index(self.id)
        self.hole_cards = []
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_stack = remaining_chips
        if hasattr(round_state, 'player_cards'):
            self.hole_cards = round_state.player_cards.get(str(self.id), [])
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.my_stack = remaining_chips
        
        if not self.hole_cards or len(self.hole_cards) < 2:
            return PokerAction.FOLD, 0
            
        pot_odds = round_state.current_bet / (round_state.pot + round_state.current_bet + 1e-6)
        equity = self._calculate_equity()
        
        if round_state.current_bet == 0:
            if equity > 0.7:
                return PokerAction.RAISE, int(round_state.max_raise * 0.8)
            elif equity > 0.5:
                return PokerAction.RAISE, int(round_state.min_raise * 1.5)
            else:
                return PokerAction.CHECK, 0
        else:
            if equity > 0.8 or (equity > pot_odds + 0.3):
                if round_state.max_raise > round_state.current_bet * 3:
                    return PokerAction.RAISE, min(round_state.max_raise, round_state.current_bet * 4)
                else:
                    return PokerAction.ALL_IN, 0
            elif equity > pot_odds + 0.1:
                return PokerAction.CALL, 0
            elif equity > 0.15:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
                
    def _calculate_equity(self) -> float:
        if len(self.hole_cards) != 2:
            return 0.0
            
        card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                     '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        h1, h2 = self.hole_cards
        r1, r2 = card_ranks[h1[0]], card_ranks[h2[0]]
        s1, s2 = h1[1], h2[1]
        
        if r1 == r2:
            # Pair
            return 0.85 if r1 > 10 else 0.75
        elif s1 == s2:
            # Suited
            if max(r1, r2) >= 11 and abs(r1 - r2) <= 5:
                return 0.6
            elif max(r1, r2) >= 9 and abs(r1 - r2) <= 4:
                return 0.5
            else:
                return 0.3
        else:
            # Unsuited
            if abs(r1 - r2) == 1 and max(r1, r2) >= 11:
                return 0.55
            elif max(r1, r2) >= 12:
                return 0.45
            elif max(r1, r2) >= 10:
                return 0.35
            else:
                return 0.2
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_stack = remaining_chips
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass