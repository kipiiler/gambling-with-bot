import random
from typing import List, Tuple, Dict, Any, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.blind_amount: int = 0  # initial big blind (may increase later)
        self.current_blind_estimate: int = 0  # tracked/updated estimate based on action streets
        self.players: List[int] = []
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None

        # Round state tracking
        self.round_num: int = 0
        self.last_round_seen: int = -1

        # Opponent modeling (very light)
        self.opp_last_aggressive: Dict[str, int] = {}  # count of raises by player id (string)
        self.opp_last_passive: Dict[str, int] = {}     # count of checks/calls by player id (string)

        # Hole cards tracking (best-effort: in case framework passes them)
        self.my_hole_cards: List[str] = []

        # Randomization seed for consistency
        random.seed()

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ):
        # Initialize match info
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.current_blind_estimate = max(1, blind_amount)
        self.players = list(all_players) if all_players else []
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id

        # Best-effort: Some engines may provide our hole cards here. Store if 2-length.
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            # If multiple players' hands were provided (unlikely), keep the first 2 as ours.
            self.my_hole_cards = player_hands[:2]
        else:
            self.my_hole_cards = []

        # Reset opponent models
        self.opp_last_aggressive.clear()
        self.opp_last_passive.clear()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track round number for per-round resets
        self.round_num = getattr(round_state, "round_num", self.round_num)
        if self.round_num != self.last_round_seen:
            self.last_round_seen = self.round_num
            # Best-effort to update blind estimate at the start of preflop
            if hasattr(round_state, "round") and isinstance(round_state.round, str):
                if round_state.round.lower() in ("preflop", "pre-flop", "pre_flop"):
                    # On fresh preflop, current_bet should be at least big blind; update estimate conservatively
                    cb = getattr(round_state, "current_bet", 0) or 0
                    self.current_blind_estimate = max(self.current_blind_estimate, int(cb) if cb > 0 else self.current_blind_estimate)

        # Try to fetch current hole cards if the engine provides them in round_state (not guaranteed)
        self._fetch_my_hole_cards_from_state(round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player.
        This strategy is a safe, mixed-frequency baseline designed to be valid and robust.
        """
        try:
            # Defensive guards
            eps = 1e-9
            my_id_str = str(self.id) if self.id is not None else None

            # Read basic round info
            stage_name = getattr(round_state, "round", "Preflop")
            stage_lower = stage_name.lower() if isinstance(stage_name, str) else "preflop"
            pot = int(getattr(round_state, "pot", 0) or 0)
            current_bet = int(getattr(round_state, "current_bet", 0) or 0)
            min_raise = int(getattr(round_state, "min_raise", 0) or 0)
            max_raise = int(getattr(round_state, "max_raise", 0) or 0)

            # My current bet this street
            player_bets = getattr(round_state, "player_bets", {}) or {}
            my_bet = int(player_bets.get(my_id_str, 0) or 0) if my_id_str is not None else 0

            # Amount to call
            amount_to_call = max(0, current_bet - my_bet)

            # Update blind estimate opportunistically at start of preflop
            if stage_lower in ("preflop", "pre-flop", "pre_flop"):
                # If current_bet is small and positive, it's likely the big blind
                if current_bet > 0:
                    self.current_blind_estimate = max(self.current_blind_estimate, current_bet)

            # Track opponent action frequencies
            self._update_opponent_stats(round_state)

            # Action availability
            can_check = (amount_to_call == 0)
            can_call = (amount_to_call > 0 and remaining_chips > 0)
            # Raise is available only if we can raise above minimum and have chips
            can_raise = (
                (min_raise is not None)
                and (max_raise is not None)
                and (min_raise > 0)
                and (max_raise >= min_raise)
                and (remaining_chips > amount_to_call)
                and (max_raise > 0)
            )
            # If we cannot cover the call, call may not be valid; prefer ALL_IN or FOLD in that case
            can_afford_call = (remaining_chips >= amount_to_call)

            # Determine action by street
            # Without guaranteed access to hole cards, we use mixed strategies that balance aggression and caution.
            if stage_lower in ("preflop", "pre-flop", "pre_flop"):
                action, value = self._decide_preflop_action(
                    amount_to_call=amount_to_call,
                    pot=pot,
                    min_raise=min_raise,
                    max_raise=max_raise,
                    can_check=can_check,
                    can_call=can_call and can_afford_call,
                    can_raise=can_raise,
                    remaining_chips=remaining_chips
                )
                if action is not None:
                    return action, value

            else:
                # Postflop (Flop/Turn/River)
                action, value = self._decide_postflop_action(
                    amount_to_call=amount_to_call,
                    pot=pot,
                    min_raise=min_raise,
                    max_raise=max_raise,
                    can_check=can_check,
                    can_call=can_call and can_afford_call,
                    can_raise=can_raise,
                    remaining_chips=remaining_chips
                )
                if action is not None:
                    return action, value

            # Fallback safety: if we reached here, choose a valid safe action
            if can_check:
                return PokerAction.CHECK, 0
            elif can_call and can_afford_call:
                return PokerAction.CALL, 0
            else:
                # If we can't call and can't check, either shove as last resort if short or fold
                if remaining_chips <= max(2 * self.current_blind_estimate, amount_to_call):
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0

        except Exception:
            # On any unexpected error, choose the safest valid action to avoid auto-fold penalties
            # Attempt to check; otherwise fold
            try:
                # Try using minimal info from round_state
                current_bet = int(getattr(round_state, "current_bet", 0) or 0)
                player_bets = getattr(round_state, "player_bets", {}) or {}
                my_bet = int(player_bets.get(str(self.id), 0) or 0) if self.id is not None else 0
                amount_to_call = max(0, current_bet - my_bet)
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # If we have to act facing a bet and something failed, fold to be safe
                    return PokerAction.FOLD, 0
            except Exception:
                # Absolute last resort
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear round-specific info if needed
        self.my_hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset models for a fresh game next time
        self.opp_last_aggressive.clear()
        self.opp_last_passive.clear()
        self.my_hole_cards = []

    # -----------------------
    # Helper methods
    # -----------------------

    def _fetch_my_hole_cards_from_state(self, round_state: RoundStateClient):
        """
        Best-effort attempt to extract hole cards if the engine provides them in the round_state.
        This is optional and robust to absence of such fields.
        """
        try:
            # Some engines might insert a dict of player_id -> [card1, card2]
            cand = getattr(round_state, "player_hands", None)
            if isinstance(cand, dict) and self.id is not None:
                h = cand.get(str(self.id))
                if isinstance(h, list) and len(h) >= 2:
                    self.my_hole_cards = h[:2]
                    return
            # Some engines might provide directly as a list
            if isinstance(cand, list) and len(cand) >= 2:
                self.my_hole_cards = cand[:2]
                return
        except Exception:
            pass  # Safe to ignore

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """
        Update opponent models based on player_actions dictionary.
        We categorize 'Raise' and 'All-in' as aggressive, 'Call'/'Check' as passive.
        """
        try:
            actions = getattr(round_state, "player_actions", {}) or {}
            for pid_str, act in actions.items():
                act_l = str(act).lower()
                if 'raise' in act_l or 'all' in act_l:
                    self.opp_last_aggressive[pid_str] = self.opp_last_aggressive.get(pid_str, 0) + 1
                elif 'call' in act_l or 'check' in act_l:
                    self.opp_last_passive[pid_str] = self.opp_last_passive.get(pid_str, 0) + 1
                elif 'fold' in act_l:
                    # We can treat fold as passive outcome
                    self.opp_last_passive[pid_str] = self.opp_last_passive.get(pid_str, 0) + 1
        except Exception:
            pass  # Robust to unexpected formats

    def _clamp_raise(self, desired_raise_by: int, min_raise: int, max_raise: int) -> Optional[int]:
        """
        Clamp a desired raise-by amount to [min_raise, max_raise]. Return None if not possible.
        """
        if min_raise is None or max_raise is None:
            return None
        if min_raise <= 0 or max_raise < min_raise:
            return None
        amt = max(min_raise, min(max_raise, desired_raise_by))
        if amt < min_raise or amt > max_raise:
            return None
        return int(amt)

    def _decide_preflop_action(
        self,
        amount_to_call: int,
        pot: int,
        min_raise: int,
        max_raise: int,
        can_check: bool,
        can_call: bool,
        can_raise: bool,
        remaining_chips: int
    ) -> Tuple[Optional[PokerAction], int]:
        """
        Mixed-frequency preflop policy using blind estimate. No hole cards assumption for robustness.
        """
        bb = max(1, self.current_blind_estimate or self.blind_amount or 1)
        # Heuristic sizing based on blind estimate
        open_raise_by = max(min_raise, 2 * bb) if min_raise > 0 else 2 * bb
        iso_raise_by = max(min_raise, 3 * bb) if min_raise > 0 else 3 * bb
        three_bet_by = max(min_raise, 4 * bb) if min_raise > 0 else 4 * bb

        # If we can check (likely BB vs SB limp or we are SB with no raise yet)
        if can_check:
            # Raise (isolation) some % to avoid being too passive
            if can_raise:
                freq = 0.35  # 35% of the time iso-raise
                if random.random() < freq:
                    raise_by = self._clamp_raise(iso_raise_by, min_raise, max_raise)
                    if raise_by is not None and raise_by <= remaining_chips:
                        return PokerAction.RAISE, raise_by
            # Otherwise check
            return PokerAction.CHECK, 0

        # Facing a raise/open
        # Size in BBs
        bet_in_bb = amount_to_call / (bb + 1e-9)

        # If the bet is small (<= 3bb): call often, 3-bet sometimes; otherwise fold
        if bet_in_bb <= 3.0:
            # If short-stacked relative to bet, sometimes shove (rare)
            if amount_to_call >= max(remaining_chips * 0.4, 10 * bb):
                # Big bet relative to stack: mostly fold, sometimes all-in
                if random.random() < 0.10:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            # Normal small open: mix call and 3-bet
            r = random.random()
            if r < 0.55 and can_call:
                return PokerAction.CALL, 0
            elif r < 0.70 and can_raise:
                raise_by = self._clamp_raise(three_bet_by, min_raise, max_raise)
                if raise_by is not None and (amount_to_call + raise_by) <= remaining_chips:
                    return PokerAction.RAISE, raise_by
                # If can't 3-bet due to limits, default to call if possible
                if can_call:
                    return PokerAction.CALL, 0
            # Otherwise fold to avoid over-defending
            if remaining_chips <= amount_to_call:
                # Can't afford, shove small frequency, else fold
                if random.random() < 0.15:
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0
            return PokerAction.FOLD, 0

        # Medium raises (3-6bb): tighten up
        if 3.0 < bet_in_bb <= 6.0:
            if amount_to_call >= remaining_chips:
                # Facing a large portion of stack: mostly fold, rare shove
                if random.random() < 0.08:
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0
            r = random.random()
            if r < 0.28 and can_call:
                return PokerAction.CALL, 0
            elif r < 0.35 and can_raise:
                raise_by = self._clamp_raise(three_bet_by, min_raise, max_raise)
                if raise_by is not None and (amount_to_call + raise_by) <= remaining_chips:
                    return PokerAction.RAISE, raise_by
            return PokerAction.FOLD, 0

        # Very large raises (>6bb): mostly fold, rarely shove if short
        if amount_to_call >= remaining_chips:
            # If we are effectively all-in to call, only continue rarely
            if random.random() < 0.07:
                return PokerAction.ALL_IN, 0
            return PokerAction.FOLD, 0

        # If we have deep stack but face a very large open, mostly fold
        if random.random() < 0.10 and can_call:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0

    def _decide_postflop_action(
        self,
        amount_to_call: int,
        pot: int,
        min_raise: int,
        max_raise: int,
        can_check: bool,
        can_call: bool,
        can_raise: bool,
        remaining_chips: int
    ) -> Tuple[Optional[PokerAction], int]:
        """
        Mixed-frequency postflop policy without hand evaluation:
        - If checked to us, bet some frequency, small-to-medium size
        - If facing a bet, call more vs small bets, fold vs large bets, occasionally bluff-raise
        """
        eps = 1e-9
        bb = max(1, self.current_blind_estimate or self.blind_amount or 1)

        # If no bet yet, consider betting for fold equity
        if can_check:
            if can_raise:
                # Bluff/semi-bluff frequency when checked to
                freq_bet = 0.40
                if random.random() < freq_bet:
                    # Aim around 50-75% pot if possible, but bounded by min/max raise
                    target = int(max(min_raise, min(max_raise, max(bb, int(0.6 * pot)))))
                    # Ensure valid raise-by amount
                    raise_by = self._clamp_raise(target, min_raise, max_raise)
                    if raise_by is not None and raise_by <= remaining_chips:
                        return PokerAction.RAISE, raise_by
            # Otherwise check back
            return PokerAction.CHECK, 0

        # Facing a bet
        call_cost = amount_to_call
        # Pot odds like measure
        pot_after_call = pot + call_cost
        pot_odds = call_cost / (pot_after_call + eps) if pot_after_call > 0 else 1.0

        # If the bet is tiny relative to pot, continue wider
        if pot_odds <= 0.20:
            r = random.random()
            if r < 0.65 and can_call and call_cost <= remaining_chips:
                return PokerAction.CALL, 0
            elif r < 0.75 and can_raise:
                # Small bluff-raise
                target = int(max(min_raise, min(max_raise, int(0.75 * max(call_cost, bb)))))
                raise_by = self._clamp_raise(target, min_raise, max_raise)
                if raise_by is not None and (call_cost + raise_by) <= remaining_chips:
                    return PokerAction.RAISE, raise_by
            # Otherwise fold if we can't call
            if remaining_chips <= call_cost:
                if random.random() < 0.20:
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0
            # Default to call if possible
            if can_call:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        # Medium bet sizes: mix calls and folds, occasional raise
        if 0.20 < pot_odds <= 0.40:
            r = random.random()
            if r < 0.40 and can_call and call_cost <= remaining_chips:
                return PokerAction.CALL, 0
            elif r < 0.48 and can_raise:
                # Semi-bluff raise sizing around 60% pot
                target = int(max(min_raise, min(max_raise, int(0.6 * pot))))
                raise_by = self._clamp_raise(target, min_raise, max_raise)
                if raise_by is not None and (call_cost + raise_by) <= remaining_chips:
                    return PokerAction.RAISE, raise_by
            # Otherwise fold (or shove rare if short)
            if call_cost >= remaining_chips:
                if random.random() < 0.10:
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0
            return PokerAction.FOLD, 0

        # Large bets: mostly fold, rarely continue
        if call_cost >= remaining_chips:
            # If calling would commit all-in, rarely continue
            if random.random() < 0.06:
                return PokerAction.ALL_IN, 0
            return PokerAction.FOLD, 0

        # If we are deep but villain bets big, mostly fold; occasionally float call
        if random.random() < 0.12 and can_call:
            return PokerAction.CALL, 0
        return PokerAction.FOLD, 0