from typing import List, Tuple, Dict, Any
from collections import Counter
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _rank_value(card_rank: str) -> int:
    order = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
             '7': 7, '8': 8, '9': 9, 'T': 10,
             'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    return order.get(card_rank, 0)


def _parse_card(card: str) -> Tuple[str, str]:
    if not card or len(card) < 2:
        return '', ''
    return card[0], card[1]


def _sorted_ranks_desc(r1: str, r2: str) -> Tuple[str, str]:
    return tuple(sorted([r1, r2], key=lambda r: _rank_value(r), reverse=True))


def _hand_code(h1: str, h2: str) -> Tuple[str, bool]:
    r1, s1 = _parse_card(h1)
    r2, s2 = _parse_card(h2)
    if not r1 or not r2:
        return ("", False)
    r_high, r_low = _sorted_ranks_desc(r1, r2)
    suited = (s1 == s2)
    return (r_high + r_low, suited)


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.players: List[int] = []
        self.hole_cards: List[str] = []  # e.g., ['Ah', 'Kd']
        self.rng = random.Random(1337)
        self.game_round_counter = 0
        self.last_betting_round_name = None
        self.was_last_aggressor = False
        self.stats = {
            'hands': 0,
            'raises': 0,
            'calls': 0,
            'folds': 0,
            'checks': 0,
            'allins': 0
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the start of the game or (in some environments) at the start of each hand.
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players[:] if all_players else []
        # In some environments, player_hands are provided at hand start
        if player_hands and len(player_hands) >= 2:
            self.hole_cards = player_hands[:2]
            self.stats['hands'] += 1
        # Reseed RNG slightly per hand for variability but stable behavior
        self.rng.seed((self.id or 0) * 1000003 + self.stats['hands'])

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track betting street transitions
        current_street = round_state.round
        if self.last_betting_round_name != current_street:
            # New betting street; reset aggressor flag unless we were PFR and continue barreling
            self.was_last_aggressor = False
            self.last_betting_round_name = current_street

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Safety guards
            if remaining_chips <= 0:
                return PokerAction.CHECK, 0

            # Get our current street info
            pot = max(0, round_state.pot or 0)
            current_bet = max(0, round_state.current_bet or 0)
            min_raise = max(0, round_state.min_raise or 0)
            max_raise = max(0, round_state.max_raise or 0)

            my_bet = 0
            pid_str = str(self.id) if self.id is not None else ""
            if pid_str and round_state.player_bets and pid_str in round_state.player_bets:
                my_bet = max(0, round_state.player_bets.get(pid_str, 0) or 0)
            to_call = max(0, current_bet - my_bet)

            # Determine if we can check
            can_check = (current_bet == 0)

            stage = (round_state.round or "").lower()  # 'Preflop', 'Flop', 'Turn', 'River'
            community = round_state.community_cards or []
            have_cards = self.hole_cards and len(self.hole_cards) >= 2 and all(len(c) >= 2 for c in self.hole_cards)

            # Helper for safe raise
            def clamp_raise(desired: int) -> int:
                # Ensure desired is within bounds and at least min_raise
                if max_raise <= 0:
                    return 0
                amt = desired
                if amt < min_raise:
                    amt = min_raise
                if amt > max_raise:
                    amt = max_raise
                if amt < min_raise:
                    # Cannot raise legally
                    return 0
                return amt

            # Pot odds
            pot_for_odds = pot
            # Ensure to_call non-negative
            call_amt = max(0, to_call)
            total_pot_if_call = pot_for_odds + call_amt
            pot_odds = call_amt / (max(total_pot_if_call, 1e-9))

            # Decide action by street
            if stage == 'preflop':
                action, amount = self._act_preflop(to_call, pot, min_raise, max_raise, pot_odds, clamp_raise)
                if action is not None:
                    return action, amount

            # Postflop decisions (flop/turn/river)
            if have_cards:
                ehs, draw_info = self._evaluate_postflop_strength(self.hole_cards, community)
            else:
                # If we don't know our cards, play very tight/passive
                ehs, draw_info = 0.05, {'flush_draw': False, 'oesd': False, 'gutshot': False, 'top_pair': False}

            # Decide postflop
            # Value thresholds
            strong_threshold = 0.80
            medium_threshold = 0.55
            weak_showdown = 0.35

            # If we can check
            if can_check:
                # Bet for value or semi-bluff
                bet_size = 0
                if ehs >= strong_threshold:
                    # Strong value: about 70% pot
                    bet_size = int(0.7 * max(0, pot))
                elif ehs >= medium_threshold:
                    # Medium value: 50% pot
                    bet_size = int(0.5 * max(0, pot))
                elif draw_info.get('flush_draw') or draw_info.get('oesd'):
                    # Semi-bluff: 40% pot sometimes
                    if self.rng.random() < 0.6:
                        bet_size = int(0.4 * max(0, pot))
                else:
                    # Occasionally bluff small on flop only
                    if (round_state.round or '').lower() == 'flop' and self.rng.random() < 0.1 and pot > 0:
                        bet_size = int(0.33 * pot)

                if bet_size > 0:
                    # Ensure betting via RAISE when current_bet == 0; size by blind if pot is small
                    desired = max(bet_size, int(2.0 * self.blind_amount))
                    raise_amt = clamp_raise(desired)
                    if raise_amt >= min_raise:
                        self.was_last_aggressor = True
                        self.stats['raises'] += 1
                        return PokerAction.RAISE, raise_amt

                # Default check
                self.stats['checks'] += 1
                return PokerAction.CHECK, 0

            # Facing a bet
            # Consider all-in threshold
            if ehs >= 0.92 and remaining_chips <= (pot + call_amt) * 1.5:
                # Jam strong hands when stacks are shallow relative to pot
                self.stats['allins'] += 1
                return PokerAction.ALL_IN, 0

            # Decide call/raise/fold
            # If very strong, raise for value
            if ehs >= strong_threshold:
                # Target raise ~ 2.5x of to_call or ~70% pot, whichever higher
                target = max(int(2.5 * max(1, to_call)), int(0.7 * pot))
                raise_amt = clamp_raise(target)
                if raise_amt >= min_raise:
                    self.was_last_aggressor = True
                    self.stats['raises'] += 1
                    return PokerAction.RAISE, raise_amt
                else:
                    # If can't raise, call
                    if call_amt <= remaining_chips:
                        self.stats['calls'] += 1
                        return PokerAction.CALL, 0
                    else:
                        self.stats['allins'] += 1
                        return PokerAction.ALL_IN, 0

            # With medium strength or good pot odds with draws, call
            has_draw = draw_info.get('flush_draw') or draw_info.get('oesd') or draw_info.get('gutshot')
            # Adjust willingness based on pot odds
            call_threshold = max(pot_odds * 1.10, 0.25)
            if ehs >= max(medium_threshold, call_threshold) or (has_draw and pot_odds <= 0.25):
                if call_amt <= remaining_chips:
                    self.stats['calls'] += 1
                    return PokerAction.CALL, 0
                else:
                    # If we can't fully call, decide whether to jam or fold based on ehs
                    if ehs >= 0.6:
                        self.stats['allins'] += 1
                        return PokerAction.ALL_IN, 0
                    else:
                        self.stats['folds'] += 1
                        return PokerAction.FOLD, 0

            # Weak: fold
            self.stats['folds'] += 1
            return PokerAction.FOLD, 0

        except Exception:
            # Fail-safe: never crash; default to safe action
            try:
                # If we can check, check; else fold
                if round_state and (round_state.current_bet or 0) == 0:
                    self.stats['checks'] += 1
                    return PokerAction.CHECK, 0
            except Exception:
                pass
            self.stats['folds'] += 1
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear per-hand state if a hand just ended (heuristic)
        # Some environments may call this at the end of a betting street; be conservative
        if (round_state.round or "").lower() == 'river':
            # Likely end of hand post-showdown
            self.hole_cards = []
            self.was_last_aggressor = False
            self.last_betting_round_name = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # We could log stats if needed; keep minimal to adhere to constraints
        pass

    # -------- Strategy helpers --------

    def _act_preflop(self, to_call: int, pot: int, min_raise: int, max_raise: int, pot_odds: float, clamp_raise_cb) -> Tuple[PokerAction, int] | Tuple[None, None]:
        # If no hole cards known, default to tight/passive preflop
        if not (self.hole_cards and len(self.hole_cards) >= 2):
            if to_call == 0:
                self.stats['checks'] += 1
                return PokerAction.CHECK, 0
            else:
                # Fold most; occasionally defend BB cheaply
                if to_call <= max(1, self.blind_amount) and self.rng.random() < 0.2:
                    self.stats['calls'] += 1
                    return PokerAction.CALL, 0
                self.stats['folds'] += 1
                return PokerAction.FOLD, 0

        premium, strong, medium, speculative = self._classify_preflop(self.hole_cards)

        # Determine if facing raise (beyond blinds)
        facing_raise = (to_call > 0 and (to_call > self.blind_amount or (self.blind_amount == 0 and to_call > 0)))
        can_check = (to_call == 0)

        # Aggression rules
        if not facing_raise:
            # Unopened pot or check option
            if can_check:
                # Big blind option; raise with decent hands, else check
                if premium or strong or medium:
                    # Open raise ~ 3x BB
                    desired = max(int(3.0 * max(1, self.blind_amount)), min_raise)
                    raise_amt = clamp_raise_cb(desired)
                    if raise_amt >= min_raise:
                        self.was_last_aggressor = True
                        self.stats['raises'] += 1
                        return PokerAction.RAISE, raise_amt
                # Otherwise check
                self.stats['checks'] += 1
                return PokerAction.CHECK, 0
            else:
                # Our first action preflop: open-raise or fold (avoid limping)
                if premium or strong:
                    desired = max(int(3.0 * max(1, self.blind_amount)), min_raise)
                    raise_amt = clamp_raise_cb(desired)
                    if raise_amt >= min_raise:
                        self.was_last_aggressor = True
                        self.stats['raises'] += 1
                        return PokerAction.RAISE, raise_amt
                    # If can't raise, call with strong holdings
                    if to_call <= 2 * max(1, self.blind_amount):
                        self.stats['calls'] += 1
                        return PokerAction.CALL, 0
                    self.stats['folds'] += 1
                    return PokerAction.FOLD, 0
                elif medium:
                    # Mix raise/call, avoid limping
                    if self.rng.random() < 0.6:
                        desired = max(int(2.5 * max(1, self.blind_amount)), min_raise)
                        raise_amt = clamp_raise_cb(desired)
                        if raise_amt >= min_raise:
                            self.was_last_aggressor = True
                            self.stats['raises'] += 1
                            return PokerAction.RAISE, raise_amt
                    # Otherwise fold to avoid weak limps unless cheap
                    if to_call <= max(1, self.blind_amount) and self.rng.random() < 0.4:
                        self.stats['calls'] += 1
                        return PokerAction.CALL, 0
                    self.stats['folds'] += 1
                    return PokerAction.FOLD, 0
                elif speculative:
                    # Mostly fold; occasionally open or call if cheap
                    if to_call <= max(1, self.blind_amount) and self.rng.random() < 0.35:
                        self.stats['calls'] += 1
                        return PokerAction.CALL, 0
                    if self.rng.random() < 0.15:
                        desired = max(int(2.2 * max(1, self.blind_amount)), min_raise)
                        raise_amt = clamp_raise_cb(desired)
                        if raise_amt >= min_raise:
                            self.was_last_aggressor = True
                            self.stats['raises'] += 1
                            return PokerAction.RAISE, raise_amt
                    self.stats['folds'] += 1
                    return PokerAction.FOLD, 0
                else:
                    # Weak: fold; defend BB sometimes
                    if to_call <= max(1, self.blind_amount) and self.rng.random() < 0.15:
                        self.stats['calls'] += 1
                        return PokerAction.CALL, 0
                    self.stats['folds'] += 1
                    return PokerAction.FOLD, 0
        else:
            # Facing raise
            if premium:
                # 3-bet
                desired = max(int(3.0 * max(1, self.blind_amount)), min_raise)
                raise_amt = clamp_raise_cb(desired)
                if raise_amt >= min_raise:
                    self.was_last_aggressor = True
                    self.stats['raises'] += 1
                    return PokerAction.RAISE, raise_amt
                # fallback call
                self.stats['calls'] += 1
                return PokerAction.CALL, 0
            elif strong:
                # Mix call and 3-bet
                if self.rng.random() < 0.5:
                    desired = max(int(2.5 * max(1, self.blind_amount)), min_raise)
                    raise_amt = clamp_raise_cb(desired)
                    if raise_amt >= min_raise:
                        self.was_last_aggressor = True
                        self.stats['raises'] += 1
                        return PokerAction.RAISE, raise_amt
                # call if price reasonable
                if pot_odds <= 0.35 or to_call <= 3 * max(1, self.blind_amount):
                    self.stats['calls'] += 1
                    return PokerAction.CALL, 0
                self.stats['folds'] += 1
                return PokerAction.FOLD, 0
            elif medium or speculative:
                # Mostly call if price good; else fold
                if pot_odds <= 0.25 or to_call <= 2 * max(1, self.blind_amount):
                    self.stats['calls'] += 1
                    return PokerAction.CALL, 0
                # Rare bluff 3-bet with blockers
                if medium and self.rng.random() < 0.15:
                    desired = max(int(2.2 * max(1, self.blind_amount)), min_raise)
                    raise_amt = clamp_raise_cb(desired)
                    if raise_amt >= min_raise:
                        self.was_last_aggressor = True
                        self.stats['raises'] += 1
                        return PokerAction.RAISE, raise_amt
                self.stats['folds'] += 1
                return PokerAction.FOLD, 0
            else:
                # Weak hands fold; defend rarely if cheap
                if to_call <= max(1, self.blind_amount) and self.rng.random() < 0.15:
                    self.stats['calls'] += 1
                    return PokerAction.CALL, 0
                self.stats['folds'] += 1
                return PokerAction.FOLD, 0

    def _classify_preflop(self, hole_cards: List[str]) -> Tuple[bool, bool, bool, bool]:
        # Return tuple (premium, strong, medium, speculative)
        r1, s1 = _parse_card(hole_cards[0])
        r2, s2 = _parse_card(hole_cards[1])
        if not r1 or not r2:
            return False, False, False, False
        code, suited = _hand_code(hole_cards[0], hole_cards[1])
        r_high, r_low = code[0], code[1]

        pair = (r1 == r2)
        ranks = ''.join(sorted([r1, r2], key=lambda r: _rank_value(r), reverse=True))

        # Groupings
        premium_pairs = {'A', 'K', 'Q', 'J'}
        strong_pairs = {'T', '9'}
        medium_pairs = {'8', '7'}
        spec_pairs = {'6', '5', '4', '3', '2'}

        # Premiums
        if pair and r1 in premium_pairs:
            return True, False, False, False
        if suited and set([r_high + r_low]) & set(['AK']):
            return True, False, False, False

        # Strong
        if pair and r1 in strong_pairs:
            return False, True, False, False
        if code in ('AK',) and not suited:
            return False, True, False, False
        if suited and code in ('AQ', 'AJ', 'KQ'):
            return False, True, False, False

        # Medium
        if pair and r1 in medium_pairs:
            return False, False, True, False
        if suited and code in ('AT', 'KJ', 'QJ', 'JT', 'T9'):
            return False, False, True, False
        if not suited and code in ('AQ',):
            return False, False, True, False

        # Speculative
        connectors = {'98', '87', '76', '65', '54'}
        one_gappers = {'97', '86', '75', '64', '53'}
        if pair and r1 in spec_pairs:
            return False, False, False, True
        if suited and (code in connectors or code in one_gappers or code in ('KTs', 'QTs', 'JTs')):
            return False, False, False, True
        if not suited and code in ('AT', 'KQ', 'KJ', 'QJ'):
            return False, False, False, True

        return False, False, False, False

    def _evaluate_postflop_strength(self, hole_cards: List[str], community: List[str]) -> Tuple[float, Dict[str, bool]]:
        # Returns (EHS approximation [0..1], draw info dict)
        cards = list(hole_cards) + list(community)
        ranks = [_parse_card(c)[0] for c in cards if c]
        suits = [_parse_card(c)[1] for c in cards if c]

        # Count ranks and suits
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)

        # Identify made hand category
        category = self._made_hand_category(cards)

        # Detect top pair and pair quality
        ehs = 0.05  # base high-card
        draw_info = {'flush_draw': False, 'oesd': False, 'gutshot': False, 'top_pair': False}

        # Draw detection
        # Flush draw (4 to a flush)
        max_suit = max(suit_counts.values()) if suit_counts else 0
        if max_suit == 4 and len(community) >= 3:
            draw_info['flush_draw'] = True

        # Straight draw detection
        ranks_vals = set()
        for r in ranks:
            v = _rank_value(r)
            if v == 14:
                ranks_vals.add(14)
                ranks_vals.add(1)  # Wheel A low
            else:
                ranks_vals.add(v)
        # OESD: any 4 in a row present
        oesd = False
        for start in range(1, 11):  # 1..10 represent A-low .. T start
            if all(((start + d) in ranks_vals) for d in range(0, 4)):
                oesd = True
                break
        draw_info['oesd'] = oesd
        # Gutshot: any 4 of 5 sequence present (but not OESD already)
        gutshot = False
        if not oesd:
            for start in range(1, 11):
                seq = set(start + d for d in range(0, 5))
                count = len(seq.intersection(ranks_vals))
                if count >= 4:
                    gutshot = True
                    break
        draw_info['gutshot'] = gutshot

        # Evaluate pair quality
        com_ranks = [_parse_card(c)[0] for c in community]
        com_rank_vals = [_rank_value(r) for r in com_ranks]
        max_board_rank = max(com_rank_vals) if com_rank_vals else 0
        hole_ranks = [_parse_card(c)[0] for c in hole_cards]
        hole_vals = [_rank_value(r) for r in hole_ranks]
        hole_set = set(hole_ranks)

        # Determine pair rank for single pair case
        pair_rank_val = 0
        if category == 0:
            for r, cnt in rank_counts.items():
                if cnt >= 2:
                    pair_rank_val = _rank_value(r)
                    break
            # Check if our hole contributes to the pair
            contributes = any(r in hole_set for r, cnt in rank_counts.items() if cnt >= 2)
            if contributes and pair_rank_val == max_board_rank:
                draw_info['top_pair'] = True

        # Map category to base EHS
        if category >= 6:  # quads or better
            ehs = 0.97
        elif category == 5:  # full house
            ehs = 0.92
        elif category == 4:  # flush
            ehs = 0.88
        elif category == 3:  # straight
            ehs = 0.84
        elif category == 2:  # trips
            ehs = 0.72
        elif category == 1:  # two pair
            ehs = 0.66
        elif category == 0:  # one pair
            # Top pair good kicker
            other_hole = max(hole_vals) if pair_rank_val in hole_vals else (sorted(hole_vals)[-1] if hole_vals else 0)
            if draw_info['top_pair'] and other_hole >= 12:  # Q or better kicker
                ehs = 0.60
            elif draw_info['top_pair']:
                ehs = 0.55
            else:
                # Underpair to board or middle/bottom pair
                if pair_rank_val > 0 and pair_rank_val < max_board_rank:
                    ehs = 0.40
                else:
                    ehs = 0.45
        else:
            ehs = 0.05

        # Incorporate draws
        if category < 3:  # if less than straight
            if draw_info['flush_draw']:
                ehs = max(ehs, 0.37)
            if draw_info['oesd']:
                ehs = max(ehs, 0.33)
            if draw_info['gutshot']:
                ehs = max(ehs, 0.18)

        # Cap within [0,1]
        ehs = max(0.0, min(1.0, ehs))
        return ehs, draw_info

    def _made_hand_category(self, cards: List[str]) -> int:
        # Return category code:
        # 6: Four of a kind or better proxy
        # 5: Full house
        # 4: Flush
        # 3: Straight
        # 2: Three of a kind
        # 1: Two pair
        # 0: One pair
        # -1: High card
        # This is a simplified evaluator that detects presence of categories without tie strength.
        if not cards:
            return -1

        ranks = [_parse_card(c)[0] for c in cards if c]
        suits = [_parse_card(c)[1] for c in cards if c]
        rank_counts = Counter(ranks)
        suit_counts = Counter(suits)

        counts = sorted(rank_counts.values(), reverse=True)
        is_four = counts[0] == 4 if counts else False
        is_three = counts[0] == 3 if counts else False
        pairs = sum(1 for v in rank_counts.values() if v >= 2)

        is_flush = max(suit_counts.values()) >= 5 if suit_counts else False

        # Straight detection
        vals = set()
        for r in ranks:
            v = _rank_value(r)
            if v == 14:
                vals.add(14)
                vals.add(1)
            else:
                vals.add(v)
        is_straight = False
        for start in range(1, 11):
            if all(((start + d) in vals) for d in range(0, 5)):
                is_straight = True
                break

        # Straight flush detection (approx)
        is_straight_flush = False
        if is_flush:
            # Check straight flush by filtering to each suit
            for s in set(suits):
                suited_vals = set()
                for c in cards:
                    r, cs = _parse_card(c)
                    if cs == s:
                        v = _rank_value(r)
                        if v == 14:
                            suited_vals.add(14)
                            suited_vals.add(1)
                        else:
                            suited_vals.add(v)
                for start in range(1, 11):
                    if all(((start + d) in suited_vals) for d in range(0, 5)):
                        is_straight_flush = True
                        break
                if is_straight_flush:
                    break

        if is_straight_flush:
            return 7  # stronger than quads
        if is_four:
            return 6
        if is_three and pairs >= 2 or (is_three and pairs >= 1 and len(rank_counts) <= 3):
            # Full house (trip + pair)
            # pairs count includes the trips counted as pair; ensure there's at least one additional pair
            # A simpler robust check:
            trip_ranks = [r for r, c in rank_counts.items() if c >= 3]
            pair_ranks = [r for r, c in rank_counts.items() if c >= 2 and r not in trip_ranks]
            if trip_ranks and pair_ranks:
                return 5
            # Edge case with multiple trips also is full house
            if len(trip_ranks) >= 2:
                return 5
        if is_flush:
            return 4
        if is_straight:
            return 3
        if is_three:
            return 2
        if pairs >= 2:
            return 1
        if pairs == 1:
            return 0
        return -1