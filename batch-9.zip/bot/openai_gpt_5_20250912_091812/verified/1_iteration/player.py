from typing import List, Tuple, Dict, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Utility constants and helpers for card parsing and hand evaluation
RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
              'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
RANKS = "23456789TJQKA"
SUITS = "cdhs"

def parse_card(card: str) -> Tuple[int, str]:
    # card like 'Ah', 'Ks', '3d'
    if not card or len(card) < 2:
        return (0, 'x')
    r = card[0].upper()
    s = card[1].lower()
    return (RANK_ORDER.get(r, 0), s)

def get_unique_sorted_ranks(cards: List[str]) -> List[int]:
    ranks = sorted({parse_card(c)[0] for c in cards if c}, reverse=True)
    return ranks

def count_suits(cards: List[str]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for c in cards:
        r, s = parse_card(c)
        if r == 0:
            continue
        counts[s] = counts.get(s, 0) + 1
    return counts

def count_ranks(cards: List[str]) -> Dict[int, int]:
    counts: Dict[int, int] = {}
    for c in cards:
        r, s = parse_card(c)
        if r == 0:
            continue
        counts[r] = counts.get(r, 0) + 1
    return counts

def has_straight(ranks: List[int]) -> bool:
    # ranks should be unique and sorted descending
    if not ranks:
        return False
    ranks_set = set(ranks)
    # Handle wheel straight: A-2-3-4-5 (14,5,4,3,2)
    if {14, 5, 4, 3, 2}.issubset(ranks_set):
        return True
    # Normal straights
    # Convert to ascending for easier iteration
    sorted_ranks = sorted(ranks_set)
    streak = 1
    for i in range(1, len(sorted_ranks)):
        if sorted_ranks[i] == sorted_ranks[i-1] + 1:
            streak += 1
            if streak >= 5:
                return True
        elif sorted_ranks[i] != sorted_ranks[i-1]:
            streak = 1
    return False

def has_straight_flush(cards: List[str]) -> bool:
    # Check straight flush by filtering cards by suit with count >=5
    suit_counts = count_suits(cards)
    for suit, cnt in suit_counts.items():
        if cnt >= 5:
            suited_ranks = [parse_card(c)[0] for c in cards if parse_card(c)[1] == suit]
            if not suited_ranks:
                continue
            # Unique ranks for that suit
            unique_suited = sorted(set(suited_ranks))
            # Handle wheel
            if set([14, 2, 3, 4, 5]).issubset(set(unique_suited)):
                return True
            # Check straight in suited ranks
            streak = 1
            for i in range(1, len(unique_suited)):
                if unique_suited[i] == unique_suited[i-1] + 1:
                    streak += 1
                    if streak >= 5:
                        return True
                elif unique_suited[i] != unique_suited[i-1]:
                    streak = 1
    return False

def evaluate_7card_category(cards: List[str]) -> int:
    """
    Returns a coarse category for the 7-card hand using poker category mapping:
    8: straight flush
    7: four of a kind
    6: full house
    5: flush
    4: straight
    3: three of a kind
    2: two pair
    1: one pair
    0: high card
    """
    if not cards or len([c for c in cards if c]) < 5:
        return 0
    # Straight flush
    if has_straight_flush(cards):
        return 8
    # Rank counts
    rcounts = count_ranks(cards)
    counts = sorted(rcounts.values(), reverse=True)
    if counts and counts[0] >= 4:
        return 7
    if len(counts) >= 2 and counts[0] == 3 and counts[1] >= 2:
        return 6
    # Flush
    suit_counts = count_suits(cards)
    if any(v >= 5 for v in suit_counts.values()):
        # Could be straight flush caught above
        return 5
    # Straight
    ranks = get_unique_sorted_ranks(cards)
    if has_straight(ranks):
        return 4
    if counts and counts[0] == 3:
        return 3
    if counts.count(2) >= 2:
        return 2
    if counts and counts[0] == 2:
        return 1
    return 0

def detect_draws(hole_cards: List[str], board: List[str]) -> Dict[str, bool]:
    """
    Detect common draws: flush draw (4 to a flush) and straight draws (OESD or gutshot).
    Returns dict with keys: 'flush_draw', 'oesd', 'gutshot'
    """
    draws = {'flush_draw': False, 'oesd': False, 'gutshot': False}
    all_cards = [c for c in hole_cards + board if c]
    if len(board) == 0:
        return draws
    # Flush draw: any suit count == 4 (overall)
    suits_count = count_suits(all_cards)
    if any(v == 4 for v in suits_count.values()):
        draws['flush_draw'] = True
    # Straight draws
    ranks = sorted(set(parse_card(c)[0] for c in all_cards if c))
    # Consider A as 1 as well to catch wheels
    if 14 in ranks:
        ranks = sorted(set(ranks + [1]))
    # Check sequences for 4-length (OESD) or inside gap (gutshot)
    ranks_set = set(ranks)
    # OESD: any 4 consecutive ranks present
    for low in range(1, 11):  # 1..10 inclusive (A-low to T)
        seq = {low, low+1, low+2, low+3}
        if seq.issubset(ranks_set):
            # Ensure we aren't already a straight (need 5)
            if not ({low, low+1, low+2, low+3, low+4}.issubset(ranks_set) or {low-1, low, low+1, low+2, low+3}.issubset(ranks_set)):
                draws['oesd'] = True
                break
    # Gutshot: 4 out of 5 in a straight with 1 gap
    if not draws['oesd']:
        for low in range(1, 11):
            seq5 = {low, low+1, low+2, low+3, low+4}
            # if exactly 4 of these in ranks_set -> gutshot
            if len(seq5.intersection(ranks_set)) == 4:
                draws['gutshot'] = True
                break
    return draws

def is_top_pair(hole_cards: List[str], board: List[str]) -> bool:
    if not board:
        return False
    board_ranks = [parse_card(c)[0] for c in board if c]
    max_board = max(board_ranks) if board_ranks else 0
    hole_ranks = [parse_card(c)[0] for c in hole_cards if c]
    # Check if we pair one of our hole cards with the board, and that rank == top board rank
    rcounts = count_ranks(hole_cards + board)
    for r in set(hole_ranks):
        # We have a pair if total count >=2 and includes at least one from hole (implicitly true)
        if rcounts.get(r, 0) >= 2 and r == max_board:
            return True
    return False

def pair_rank(hole_cards: List[str], board: List[str]) -> int:
    # Return the highest rank where we have at least a pair including our hole, else 0
    rcounts = count_ranks(hole_cards + board)
    hr = [parse_card(c)[0] for c in hole_cards if c]
    best = 0
    for r in set(hr):
        if rcounts.get(r, 0) >= 2 and r > best:
            best = r
    return best

def is_overpair(hole_cards: List[str], board: List[str]) -> bool:
    # Pocket pair higher than any board card
    if len(hole_cards) != 2:
        return False
    r1, s1 = parse_card(hole_cards[0])
    r2, s2 = parse_card(hole_cards[1])
    if r1 != r2 or r1 == 0:
        return False
    board_ranks = [parse_card(c)[0] for c in board if c]
    if not board_ranks:
        return False
    return r1 > max(board_ranks)

def suited(hole_cards: List[str]) -> bool:
    if len(hole_cards) != 2:
        return False
    return parse_card(hole_cards[0])[1] == parse_card(hole_cards[1])[1]

def connected(hole_cards: List[str]) -> bool:
    if len(hole_cards) != 2:
        return False
    r1 = parse_card(hole_cards[0])[0]
    r2 = parse_card(hole_cards[1])[0]
    if r1 == 0 or r2 == 0:
        return False
    return abs(r1 - r2) == 1 or (set([r1, r2]) == {14, 13})  # treat AK as connected

def pocket_pair(hole_cards: List[str]) -> int:
    if len(hole_cards) != 2:
        return 0
    r1 = parse_card(hole_cards[0])[0]
    r2 = parse_card(hole_cards[1])[0]
    if r1 == r2:
        return r1
    return 0

def preflop_strength_score(hole_cards: List[str]) -> float:
    """
    Rough preflop strength score in [0,1], using simple chart-like heuristics.
    """
    if len(hole_cards) != 2:
        return 0.0
    r1 = parse_card(hole_cards[0])[0]
    r2 = parse_card(hole_cards[1])[0]
    hi = max(r1, r2)
    lo = min(r1, r2)
    pp = pocket_pair(hole_cards)
    s = suited(hole_cards)
    conn = connected(hole_cards)

    # Premiums
    if pp >= 11:  # JJ+
        return 0.95
    if (hi == 14 and lo >= 12 and s):  # AKs, AQs, AJs
        return 0.9
    if (hi == 14 and lo >= 13):  # AKo, AKs counted above
        return 0.85
    if pp == 10:  # TT
        return 0.82
    # Strong
    if (hi >= 13 and lo >= 11 and s):  # KQs, KJs, QJs
        return 0.78
    if pp == 9:
        return 0.76
    if (hi == 14 and lo >= 10 and s):  # ATs+
        return 0.75
    if (hi == 13 and lo >= 12):  # KQ off
        return 0.7
    if pp == 8:
        return 0.68
    # Medium
    if (hi == 14 and lo >= 10):  # ATo+
        return 0.65
    if (conn and s and hi >= 11):  # JTs, QJs counted above
        return 0.62
    if pp == 7:
        return 0.6
    if (conn and s and hi >= 9):  # T9s, 98s
        return 0.58
    if s and hi >= 12 and lo >= 9:  # KTs, QTs
        return 0.56
    if pp == 6:
        return 0.55
    # Speculative
    if s and conn:
        return 0.5
    if pp == 5:
        return 0.48
    if hi >= 12 and lo >= 10:
        return 0.46
    # Weak
    if pp >= 2:
        return 0.42
    return 0.35

def approx_draw_equity(draws: Dict[str, bool], street: str) -> float:
    """
    Returns approximate equity for typical draws at given street.
    street: 'Flop' or 'Turn' or 'River'
    """
    # Base outs:
    outs = 0
    if draws.get('flush_draw', False):
        outs += 9
    if draws.get('oesd', False):
        outs += 8
    elif draws.get('gutshot', False):
        outs += 4
    # Cap outs to avoid over-count
    outs = min(outs, 15)
    if outs <= 0:
        return 0.0
    if street.lower() == 'flop':
        # Rule of 4 (two cards to come)
        return min(0.04 * outs, 0.95)
    elif street.lower() == 'turn':
        # Rule of 2 (one card to come)
        return min(0.02 * outs, 0.95)
    else:
        return 0.0

def clamp(v: int, lo: int, hi: int) -> int:
    if hi < lo:
        hi = lo
    return max(lo, min(hi, v))

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []  # our private two cards for the current hand
        self.round_num: int = 0
        self.stats: Dict[str, float] = {
            'hands_played': 0,
            'vpip': 0,  # voluntarily put money in pot
            'pfr': 0,   # preflop raise
            'aggression': 0
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Initial hand if provided
        if player_hands and isinstance(player_hands, list):
            self.hole_cards = player_hands[:2]
        else:
            self.hole_cards = []
        self.round_num = 0

    def _update_private_cards_from_state(self, round_state: RoundStateClient):
        """
        Try to extract private hole cards from round_state if available by different possible keys.
        Keeps previous self.hole_cards if nothing new is found.
        """
        # Try common attributes
        candidates = []
        # Some servers may send round_state.player_hands as dict {player_id: [cards]}
        ph = getattr(round_state, 'player_hands', None)
        if isinstance(ph, dict) and self.id is not None:
            my_cards = ph.get(str(self.id)) or ph.get(self.id)
            if isinstance(my_cards, list) and len(my_cards) >= 2:
                candidates = my_cards[:2]
        # Alternative keys
        if not candidates:
            hc = getattr(round_state, 'hole_cards', None)
            if isinstance(hc, dict) and self.id is not None:
                my_cards = hc.get(str(self.id)) or hc.get(self.id)
                if isinstance(my_cards, list) and len(my_cards) >= 2:
                    candidates = my_cards[:2]
            elif isinstance(hc, list) and len(hc) >= 2:
                candidates = hc[:2]
        if not candidates:
            # Some servers pass 'hand' as list
            hc2 = getattr(round_state, 'hand', None)
            if isinstance(hc2, list) and len(hc2) >= 2:
                candidates = hc2[:2]
        # Update if found
        if candidates and all(isinstance(c, str) for c in candidates):
            self.hole_cards = candidates[:2]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self._update_private_cards_from_state(round_state)
        # Reset or update per-hand indicators if needed
        # No heavy processing to keep under time/memory
        pass

    def _get_call_amount(self, round_state: RoundStateClient) -> int:
        my_bet = 0
        try:
            my_bet = int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            my_bet = 0
        call_amount = max(0, int(round_state.current_bet) - my_bet)
        return call_amount

    def _can_check(self, round_state: RoundStateClient) -> bool:
        # As per rules: You can't check if round's current bet is larger than 0
        try:
            return int(round_state.current_bet) <= 0
        except Exception:
            return False

    def _safe_raise_from_zero(self, round_state: RoundStateClient, target_amount: int) -> Tuple[PokerAction, int]:
        """
        Attempt a valid bet when current_bet == 0 using RAISE with a safe amount.
        """
        try:
            min_r = int(round_state.min_raise)
            max_r = int(round_state.max_raise)
        except Exception:
            min_r, max_r = 0, 0
        if max_r <= 0:
            # Can't raise; fallback to check
            return (PokerAction.CHECK, 0) if self._can_check(round_state) else (PokerAction.CALL, 0)
        amount = clamp(int(target_amount), max(1, min_r), max_r)
        # Ensure amount + my current bet > current_bet (which is 0 here)
        if amount <= 0:
            amount = max(1, min_r)
        return (PokerAction.RAISE, amount)

    def _bet_fraction_of_pot(self, round_state: RoundStateClient, fraction: float) -> Tuple[PokerAction, int]:
        """
        Place a bet when checking is allowed (i.e., current_bet == 0). Bet size = max(min_raise, fraction * pot)
        """
        pot = max(0, int(round_state.pot))
        target = int(pot * fraction)
        # Ensure at least min_raise
        try:
            min_r = int(round_state.min_raise)
            max_r = int(round_state.max_raise)
        except Exception:
            min_r, max_r = 0, 0
        # If min_raise unknown or 0, fall back to blind_amount if available
        base_min = min_r if min_r > 0 else (self.blind_amount if self.blind_amount > 0 else 1)
        target = max(base_min, target)
        return self._safe_raise_from_zero(round_state, target)

    def _preflop_decision(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amount = self._get_call_amount(round_state)
        can_check = self._can_check(round_state)
        # If we don't know our cards, play ultra-conservative: check/fold
        if not self.hole_cards or len(self.hole_cards) < 2:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0) if call_amount > 0 else (PokerAction.CHECK, 0)
        strength = preflop_strength_score(self.hole_cards)
        # Track VPIP/PFR (soft; won't throw)
        try:
            self.stats['hands_played'] += 1
        except Exception:
            pass

        # If no bet to us yet (we can check or bet)
        if call_amount == 0 and can_check:
            # Open with strong hands
            if strength >= 0.75:
                # Raise 3x min_raise or ~3bb
                try:
                    min_r = int(round_state.min_raise)
                except Exception:
                    min_r = max(1, self.blind_amount if self.blind_amount > 0 else 1)
                amount = max(min_r, 3 * min_r)
                action = self._safe_raise_from_zero(round_state, amount)
                # update pfr stat if we do raise
                if action[0] == PokerAction.RAISE:
                    try:
                        self.stats['pfr'] += 1
                        self.stats['vpip'] += 1
                    except Exception:
                        pass
                return action
            elif strength >= 0.6:
                # Mix in a smaller raise or check
                try:
                    min_r = int(round_state.min_raise)
                except Exception:
                    min_r = max(1, self.blind_amount if self.blind_amount > 0 else 1)
                amount = max(min_r, 2 * min_r)
                # 50-50 between raise and check for pot control
                if amount > 0 and (round_state.max_raise or 0) >= amount:
                    return self._safe_raise_from_zero(round_state, amount)
                return (PokerAction.CHECK, 0)
            else:
                # Weak: check
                return (PokerAction.CHECK, 0)

        # There is a bet to us
        if call_amount > 0:
            pot = max(0, int(round_state.pot))
            # If we are super short stacked and strong, shove
            if strength >= 0.9 and remaining_chips <= max(call_amount * 5, 4 * (self.blind_amount or call_amount or 1)):
                if remaining_chips > 0:
                    try:
                        self.stats['vpip'] += 1
                        self.stats['pfr'] += 1
                    except Exception:
                        pass
                    return (PokerAction.ALL_IN, 0)
            # With premium, prefer calling if raise semantics uncertain
            if strength >= 0.85:
                if remaining_chips >= call_amount:
                    try:
                        self.stats['vpip'] += 1
                    except Exception:
                        pass
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            # Strong: call most of the time if the call is not too big
            if strength >= 0.65:
                threshold = max(2 * (self.blind_amount or 1), int(0.15 * max(pot, 1)))
                if call_amount <= max(threshold, 1):
                    if remaining_chips >= call_amount:
                        try:
                            self.stats['vpip'] += 1
                        except Exception:
                            pass
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    # Too large; fold marginally strong hands
                    return (PokerAction.FOLD, 0)
            # Medium/weak: call only if very small (e.g., completing small blind)
            small_thresh = max(self.blind_amount, 1)
            if call_amount <= small_thresh:
                if remaining_chips >= call_amount:
                    try:
                        self.stats['vpip'] += 1
                    except Exception:
                        pass
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            return (PokerAction.FOLD, 0)

        # Fall back
        if can_check:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    def _postflop_decision(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        call_amount = self._get_call_amount(round_state)
        can_check = self._can_check(round_state)
        board = round_state.community_cards or []
        hole = self.hole_cards if self.hole_cards else []

        # If we don't know our cards, default to check/fold
        if not hole or len(hole) < 2:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        # Evaluate made hand category
        all_cards = hole + board
        category = evaluate_7card_category(all_cards)  # 0..8
        # Detect draws
        draws = detect_draws(hole, board)
        street = (round_state.round or "").lower()

        # Strength tiers
        very_strong = category >= 5 or category >= 4 and is_top_pair(hole, board) and is_overpair(hole, board)
        strong_made = category >= 3  # trips+ or straight/flush already captured
        medium_made = (category == 2) or (category == 1 and (is_top_pair(hole, board) or is_overpair(hole, board)))
        weak_made = (category == 1)

        pot = max(0, int(round_state.pot))
        # When we can check or bet
        if call_amount == 0 and can_check:
            if very_strong or category >= 6:
                # Strong value bet 70% pot
                return self._bet_fraction_of_pot(round_state, 0.7)
            if strong_made or category == 4 or category == 5:
                # Value bet 60% pot
                return self._bet_fraction_of_pot(round_state, 0.6)
            # Semi-bluff draws
            eq = approx_draw_equity(draws, street.capitalize())
            if eq >= 0.28:
                return self._bet_fraction_of_pot(round_state, 0.5)
            # Top pair decent kicker: small value/protection bet
            if medium_made:
                return self._bet_fraction_of_pot(round_state, 0.5)
            # Otherwise check
            return (PokerAction.CHECK, 0)

        # Facing a bet
        if call_amount > 0:
            # All-in with very strong hands for simplicity
            if category >= 6 or (category >= 5 and remaining_chips <= max(call_amount * 5, pot)):
                if remaining_chips > 0:
                    return (PokerAction.ALL_IN, 0)
                # If cannot all-in (0 chips), just call if possible (will be 0)
                return (PokerAction.CALL, 0)
            # With strong made hand, prefer to continue
            if strong_made or category == 4 or category == 5:
                # If stacks shallow, jam; else call to control pot (avoid ambiguous raise semantics)
                if remaining_chips <= max(call_amount * 4, int(0.75 * max(pot, 1))):
                    return (PokerAction.ALL_IN, 0)
                # Call if affordable
                if remaining_chips >= call_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            # With draws: compare equity vs pot odds
            eq = approx_draw_equity(draws, street.capitalize())
            # Pot odds: call_amount / (pot + call_amount)
            denom = pot + call_amount + 1e-9
            pot_odds = call_amount / denom if denom > 0 else 1.0
            if eq > pot_odds * 1.05:  # small buffer
                if remaining_chips >= call_amount:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            # With medium made hands (top pair/overpair), continue for reasonable price
            if medium_made:
                # Threshold: don't call huge bets
                if call_amount <= max(int(0.5 * max(pot, 1)), max(self.blind_amount, 1) * 6):
                    if remaining_chips >= call_amount:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            # Weak hands: fold to aggression
            return (PokerAction.FOLD, 0)

        # Fallback
        if can_check:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player.
        Always returns a valid action per the constraints.
        """
        try:
            # Refresh private cards if possible
            self._update_private_cards_from_state(round_state)

            round_name = (round_state.round or "").lower()
            # Preflop vs postflop
            if round_name == 'preflop':
                return self._preflop_decision(round_state, remaining_chips)
            else:
                return self._postflop_decision(round_state, remaining_chips)
        except Exception:
            # In case of any unexpected error, choose the safest valid action
            try:
                if self._can_check(round_state):
                    return (PokerAction.CHECK, 0)
                call_amount = self._get_call_amount(round_state)
                if call_amount > 0:
                    # Be conservative on error: fold
                    return (PokerAction.FOLD, 0)
                return (PokerAction.CHECK, 0)
            except Exception:
                # Absolute fallback
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Clear hand-specific data
        self.hole_cards = []
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent state needed for now
        pass