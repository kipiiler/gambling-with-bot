from typing import List, Tuple, Dict, Any, Optional
import math
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session level
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.rng = random.Random(1337)

        # Per hand/round
        self.my_hole_cards: List[str] = []
        self.last_round_num: int = -1
        self.hand_history: List[Dict[str, Any]] = []

        # Simple adaptive stats
        self.total_hands_played: int = 0
        self.aggression_factor: float = 1.0  # Adjust aggression slightly with success
        self.epsilon: float = 1e-9

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players or []
        # Try capture hole cards if provided (may not always be meaningful at game start)
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.my_hole_cards = player_hands[:2]
        else:
            self.my_hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand tracking
        self.my_hole_cards = self._extract_my_hole_cards(round_state) or self.my_hole_cards
        self.last_round_num = getattr(round_state, 'round_num', self.last_round_num)
        self.total_hands_played += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Ensure we have hole cards; if not, play ultra conservative to avoid spew
            my_cards = self._extract_my_hole_cards(round_state) or self.my_hole_cards
            if not my_cards or len(my_cards) < 2:
                return self._safe_default_action(round_state, remaining_chips)

            stage = (round_state.round or "").lower()
            community = list(getattr(round_state, 'community_cards', []) or [])
            pot = max(0, int(getattr(round_state, 'pot', 0) or 0))
            my_bet = self._get_my_bet(round_state)
            current_bet = max(0, int(getattr(round_state, 'current_bet', 0) or 0))
            min_raise = max(0, int(getattr(round_state, 'min_raise', 0) or 0))
            max_raise = max(0, int(getattr(round_state, 'max_raise', remaining_chips) or remaining_chips))
            players_in_hand = max(2, len(getattr(round_state, 'current_player', []) or self.all_players or [0, 1]))

            call_amount = max(0, current_bet - my_bet)
            can_check = call_amount <= 0
            can_call = (call_amount > 0) and (remaining_chips >= call_amount)
            can_raise = (remaining_chips > call_amount) and (max_raise >= min_raise and min_raise > 0)
            can_all_in = remaining_chips > 0

            # Equity/strength assessment
            if stage == "preflop":
                s = self._preflop_strength(my_cards, players_in_hand)
            else:
                s = self._postflop_strength(my_cards, community, players_in_hand)

            # Adjust aggression slightly with running factor
            s_adj = min(0.98, max(0.02, s * self.aggression_factor))

            # Decision making
            # If all-in needed to continue (short), decide by s threshold
            if call_amount >= remaining_chips:
                # If we're being put all-in
                if s_adj >= 0.58 or self._has_strong_draw(my_cards, community):
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Compute pot odds for calling decisions
            required_equity = call_amount / (pot + call_amount + self.epsilon)

            # Randomization to avoid being predictable
            rand = self.rng.random()

            if can_check:
                # No bet to us; decide whether to bet/raise or check
                if stage == "preflop":
                    # Open-raise with sufficiently strong hands
                    if s_adj >= 0.60 or (s_adj >= 0.52 and rand < 0.5):
                        desired_add = self._open_size_preflop(min_raise)
                        amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                        if amt >= min_raise:
                            return (PokerAction.RAISE, amt)
                        # Fallback if cannot raise
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    draw_strength = self._draw_strength(my_cards, community)
                    # Value bet with strong made hands
                    if s_adj >= 0.68:
                        desired_add = self._bet_size_pot_fraction(round_state, pot, call_amount, remaining_chips, frac=0.75)
                        amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                        if (amt >= min_raise) and can_raise:
                            return (PokerAction.RAISE, amt)
                        return (PokerAction.CHECK, 0)
                    # Semi-bluff when we have decent draws on flop/turn
                    if draw_strength >= 0.25 and stage in ("flop", "turn"):
                        desired_add = self._bet_size_pot_fraction(round_state, pot, call_amount, remaining_chips, frac=0.6)
                        amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                        if (amt >= min_raise) and can_raise:
                            return (PokerAction.RAISE, amt)
                        return (PokerAction.CHECK, 0)
                    # Thin value / protection with medium strength sometimes
                    if s_adj >= 0.58 and rand < 0.4:
                        desired_add = self._bet_size_pot_fraction(round_state, pot, call_amount, remaining_chips, frac=0.5)
                        amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                        if (amt >= min_raise) and can_raise:
                            return (PokerAction.RAISE, amt)
                    return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                if stage == "preflop":
                    if s_adj >= 0.80:
                        # 3-bet for value
                        if can_raise:
                            desired_add = max(min_raise, int(0.6 * (pot + call_amount)))
                            amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                            if amt >= min_raise:
                                return (PokerAction.RAISE, amt)
                            elif can_all_in:
                                return (PokerAction.ALL_IN, 0)
                        # If can't raise, call
                        if can_call:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    elif s_adj >= 0.62:
                        # Call reasonable sizes, otherwise fold
                        if required_equity <= s_adj - 0.02 and can_call:
                            # Avoid calling very large bets with middling hands
                            if call_amount <= max(self.blind_amount * 6, int(0.08 * remaining_chips)):
                                return (PokerAction.CALL, 0)
                        # Occasionally 3-bet bluff with blockers (Ax/Kx suited)
                        if can_raise and s_adj >= 0.66 and rand < 0.25:
                            desired_add = max(min_raise, int(0.5 * (pot + call_amount)))
                            amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                            if amt >= min_raise:
                                return (PokerAction.RAISE, amt)
                        return (PokerAction.FOLD, 0)
                    else:
                        # Speculative calls only if cheap
                        if can_call and call_amount <= max(self.blind_amount * 3, int(0.03 * remaining_chips)) and s_adj >= 0.50:
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)
                else:
                    # Postflop
                    draw_strength = self._draw_strength(my_cards, community)
                    # Strong made hands: raise or call depending on pot odds and size
                    if s_adj >= 0.75:
                        # With strong hands, prefer to raise for value unless bet is huge
                        if can_raise and (call_amount <= int(0.6 * (pot + call_amount))):
                            desired_add = self._bet_size_pot_fraction(round_state, pot, call_amount, remaining_chips, frac=0.8)
                            amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                            if amt >= min_raise:
                                return (PokerAction.RAISE, amt)
                        # Otherwise, call
                        if can_call:
                            return (PokerAction.CALL, 0)
                        # If we cannot call, shove
                        if can_all_in:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.FOLD, 0)
                    # Medium hands: call if pot odds are met
                    if s_adj >= required_equity + 0.02:
                        # Avoid calling very large bets with medium hands
                        if call_amount <= int(0.65 * (pot + call_amount)):
                            return (PokerAction.CALL, 0)
                    # Semi-bluff raise with good draws (especially flop/turn)
                    if draw_strength >= 0.28 and (stage in ("flop", "turn")) and can_raise and rand < 0.35:
                        desired_add = self._bet_size_pot_fraction(round_state, pot, call_amount, remaining_chips, frac=0.7)
                        amt = self._clip_raise_amount(desired_add, min_raise, max_raise)
                        if amt >= min_raise:
                            return (PokerAction.RAISE, amt)
                        # If can't raise, but call is ok on odds
                        implied_ok = (stage == "flop" and call_amount <= int(0.25 * (pot + call_amount))) or (stage == "turn" and call_amount <= int(0.2 * (pot + call_amount)))
                        if implied_ok and can_call:
                            return (PokerAction.CALL, 0)
                    # Draws: call if pot odds are met
                    if draw_strength > 0 and (s_adj >= required_equity - 0.01) and can_call:
                        return (PokerAction.CALL, 0)

                    return (PokerAction.FOLD, 0)

        except Exception:
            # Safety: never throw; be conservative
            return self._safe_default_action(round_state, remaining_chips)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optionally adjust aggression based on stack changes to adapt
        try:
            # Simple heuristic: if we gained chips this hand, increase aggression slightly; otherwise decrease slightly
            delta_from_start = remaining_chips - self.starting_chips
            if delta_from_start > 0:
                self.aggression_factor = min(1.15, self.aggression_factor * 1.01)
            elif delta_from_start < 0:
                self.aggression_factor = max(0.85, self.aggression_factor * 0.995)
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset/adjust or log if needed; ensure no exceptions.
        try:
            # Nudge aggression towards neutral for next game
            self.aggression_factor = 1.0
        except Exception:
            pass

    # ----------------- Helper Methods -----------------

    def _safe_default_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_bet = self._get_my_bet(round_state)
            call_amount = max(0, int(getattr(round_state, 'current_bet', 0) or 0) - my_bet)
            if call_amount <= 0:
                return (PokerAction.CHECK, 0)
            else:
                # Fold by default to avoid spew if we cannot assess
                return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.CHECK, 0)

    def _extract_my_hole_cards(self, round_state: RoundStateClient) -> Optional[List[str]]:
        # Try multiple possible locations/keys to find our hole cards robustly
        try:
            candidates = []
            # Common attribute name
            if hasattr(round_state, 'player_hands'):
                candidates.append(getattr(round_state, 'player_hands'))
            if hasattr(round_state, 'hands'):
                candidates.append(getattr(round_state, 'hands'))
            if hasattr(round_state, 'hole_cards'):
                candidates.append(getattr(round_state, 'hole_cards'))
            if hasattr(round_state, 'my_hole_cards'):
                candidates.append(getattr(round_state, 'my_hole_cards'))

            for cand in candidates:
                if not cand:
                    continue
                # If it's a dict mapping player_id->cards
                if isinstance(cand, dict):
                    # keys may be strings
                    key = str(self.id) if self.id is not None else None
                    if key and key in cand and isinstance(cand[key], list) and len(cand[key]) >= 2:
                        return cand[key][:2]
                    # Or keys may be int
                    keyi = self.id
                    if keyi is not None and keyi in cand and isinstance(cand[keyi], list) and len(cand[keyi]) >= 2:
                        return cand[keyi][:2]
                # If it's a list already containing our two cards
                if isinstance(cand, list) and len(cand) >= 2 and all(isinstance(x, str) for x in cand[:2]):
                    return cand[:2]
        except Exception:
            pass
        return None

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            bets = getattr(round_state, 'player_bets', {}) or {}
            key = str(self.id) if self.id is not None else None
            if key and key in bets:
                return int(bets[key] or 0)
            # Sometimes keyed by int
            if self.id is not None and self.id in bets:
                return int(bets[self.id] or 0)
        except Exception:
            pass
        return 0

    # Card utils
    def _rank_value(self, r: str) -> int:
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(r[0].upper(), 0)

    def _suit_value(self, c: str) -> str:
        return c[1].lower() if len(c) >= 2 else '?'

    def _is_suited(self, c1: str, c2: str) -> bool:
        return self._suit_value(c1) == self._suit_value(c2)

    def _is_pair(self, c1: str, c2: str) -> bool:
        return self._rank_value(c1) == self._rank_value(c2)

    def _preflop_strength(self, cards: List[str], players_in_hand: int) -> float:
        # Tiered preflop strength model; returns ~[0.3, 0.98]
        if len(cards) < 2:
            return 0.3
        c1, c2 = cards[0], cards[1]
        r1, r2 = self._rank_value(c1), self._rank_value(c2)
        s = self._is_suited(c1, c2)
        pair = r1 == r2
        high = max(r1, r2)
        low = min(r1, r2)

        # Identify hand categories
        premium_pairs = {14, 13, 12, 11, 10}  # AA-TT
        strong_pairs = {9, 8, 7}
        med_pairs = {6, 5}
        low_pairs = {4, 3, 2}

        # Suited high broadways/kickers
        def is_broadway(x): return x >= 10

        suited_connector = (s and abs(r1 - r2) == 1 and high >= 6)
        suited_one_gap = (s and abs(r1 - r2) == 2 and high >= 9)
        offsuit_connector = (not s and abs(r1 - r2) == 1 and high >= 10)

        # Strong offsuit combos
        strong_offsuit = ((high == 14 and low >= 11) or (high == 13 and low >= 12))  # AK, AQ, KQ
        strong_suited = ((high == 14 and low >= 10 and s) or (s and is_broadway(high) and is_broadway(low)))

        # Base strengths
        if pair and high in premium_pairs:
            base = 0.90 + 0.02 * (high - 10)  # TT->0.90, JJ->0.92, QQ->0.94, KK->0.96, AA->0.98
        elif pair and high in strong_pairs:
            base = 0.70 + 0.02 * (high - 7)   # 77->0.70, 88->0.72, 99->0.74
        elif pair and high in med_pairs:
            base = 0.60 + 0.02 * (high - 5)   # 55->0.60, 66->0.62
        elif pair and high in low_pairs:
            base = 0.52 + 0.02 * (high - 2)   # 22->0.52, 44->0.58
        elif strong_suited:
            base = 0.78
        elif strong_offsuit:
            base = 0.72
        elif suited_connector:
            base = 0.60
        elif suited_one_gap:
            base = 0.58
        elif offsuit_connector:
            base = 0.56
        elif s and high >= 12:
            base = 0.60
        elif high >= 12 and low >= 10:
            base = 0.58
        elif high >= 12:
            base = 0.54
        else:
            base = 0.48

        # Heads-up boost vs multiway reduction
        if players_in_hand <= 2:
            base += 0.05
        elif players_in_hand >= 5:
            base -= 0.05
        elif players_in_hand >= 3:
            base -= 0.02

        # Cap within
        return float(min(0.98, max(0.30, base)))

    def _postflop_strength(self, cards: List[str], board: List[str], players_in_hand: int) -> float:
        # Returns approximate equity-like score [0, 1)
        ranks = [self._rank_value(c) for c in (cards + board)]
        suits = [self._suit_value(c) for c in (cards + board)]
        rank_counts: Dict[int, int] = {}
        suit_counts: Dict[str, int] = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1

        max_of_a_kind = max(rank_counts.values()) if rank_counts else 1
        pairs = sum(1 for v in rank_counts.values() if v >= 2)
        trips_present = any(v >= 3 for v in rank_counts.values())
        quads_present = any(v >= 4 for v in rank_counts.values())
        pair_in_hand = self._is_pair(cards[0], cards[1])
        board_ranks = [self._rank_value(c) for c in board]
        board_high = max(board_ranks) if board_ranks else 0
        my_ranks = [self._rank_value(c) for c in cards]

        # Flush/straight detection
        flush_made = any(v >= 5 for v in suit_counts.values())
        flush_draw = not flush_made and any(v == 4 for v in suit_counts.values())

        straight_made, open_ended, gutshot = self._straight_info(cards, board)

        # Full house detection
        counts_sorted = sorted(rank_counts.values(), reverse=True)
        full_house = (len(counts_sorted) >= 2 and counts_sorted[0] >= 3 and counts_sorted[1] >= 2)

        # Pair category classification
        top_pair = False
        overpair = False
        two_pair = False

        # Determine if we have at least a pair using our cards
        have_pair = False
        if pair_in_hand:
            have_pair = True
            if board_high and max(my_ranks) > board_high:
                overpair = True
        else:
            # Pair with board
            if board_ranks:
                if my_ranks[0] in board_ranks or my_ranks[1] in board_ranks:
                    have_pair = True
                    # Top pair check: if the matched rank equals top board rank
                    if (my_ranks[0] in board_ranks and my_ranks[0] == board_high) or (my_ranks[1] in board_ranks and my_ranks[1] == board_high):
                        top_pair = True

        # Two pair detection (approx)
        if pairs >= 2:
            two_pair = True

        # Base strength from made hands
        s = 0.25  # high card baseline
        if quads_present:
            s = 0.97
        elif full_house:
            s = 0.90
        elif flush_made:
            s = 0.84
        elif straight_made:
            s = 0.80
        elif trips_present:
            s = 0.68
        elif two_pair:
            s = 0.64
        elif overpair:
            s = 0.66
        elif top_pair:
            s = 0.58
        elif have_pair:
            s = 0.45

        # Draw bonuses depend on stage
        stage_bonus = 0.0
        # Determine stage by number of community cards
        cc = len(board)
        if cc == 3:  # Flop
            if flush_draw and not flush_made:
                stage_bonus += 0.15
            if open_ended and not straight_made:
                stage_bonus += 0.14
            if gutshot and not straight_made:
                stage_bonus += 0.07
        elif cc == 4:  # Turn
            if flush_draw and not flush_made:
                stage_bonus += 0.08
            if open_ended and not straight_made:
                stage_bonus += 0.08
            if gutshot and not straight_made:
                stage_bonus += 0.04

        s += stage_bonus

        # Multi-way adjustment
        if players_in_hand > 2:
            factor = 0.95 ** (players_in_hand - 2)
            # Keep monsters strong
            if s < 0.85:
                s *= factor

        return float(min(0.98, max(0.05, s)))

    def _straight_info(self, cards: List[str], board: List[str]) -> Tuple[bool, bool, bool]:
        # Determine straight made, and draw types (open-ended/gutshot)
        ranks_all = [self._rank_value(c) for c in (cards + board)]
        ranks_set = set(ranks_all)
        # Consider wheel: Ace can be low
        if 14 in ranks_set:
            ranks_set.add(1)
        sorted_unique = sorted(ranks_set)
        straight_made = False

        # Check made straight
        for start in range(1, 11):  # 1..10 is A..10 window starts for 5-card straights
            window = set(range(start, start + 5))
            if window.issubset(ranks_set):
                straight_made = True
                break

        open_ended = False
        gutshot = False
        if not straight_made:
            for start in range(1, 11):
                window = list(range(start, start + 5))
                present = [v for v in window if v in ranks_set]
                missing = [v for v in window if v not in ranks_set]
                if len(present) == 4 and len(missing) == 1:
                    # If the missing is at one end -> open-ended, otherwise gutshot
                    if missing[0] == window[0] or missing[0] == window[-1]:
                        open_ended = True
                    else:
                        gutshot = True
        return straight_made, open_ended, gutshot

    def _has_strong_draw(self, cards: List[str], board: List[str]) -> bool:
        # Strong draw heuristics
        _, open_ended, gutshot = self._straight_info(cards, board)
        # Flush draw
        suits = [self._suit_value(c) for c in (cards + board)]
        suit_counts: Dict[str, int] = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_draw = any(v == 4 for v in suit_counts.values())
        # Consider open-ended or flush draw as strong
        return flush_draw or open_ended

    def _draw_strength(self, cards: List[str], board: List[str]) -> float:
        # Approximate draw value
        straight_made, open_ended, gutshot = self._straight_info(cards, board)
        suits = [self._suit_value(c) for c in (cards + board)]
        suit_counts: Dict[str, int] = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_made = any(v >= 5 for v in suit_counts.values())
        flush_draw = not flush_made and any(v == 4 for v in suit_counts.values())

        if flush_draw and open_ended:
            return 0.35
        if flush_draw:
            return 0.28
        if open_ended:
            return 0.24
        if gutshot:
            return 0.12
        return 0.0

    def _open_size_preflop(self, min_raise: int) -> int:
        # Typical open size ~2.5-3x; fallback to min_raise if blinds unknown
        if self.blind_amount and self.blind_amount > 0:
            return max(min_raise, 3 * self.blind_amount)
        return max(min_raise, 2 * (self.blind_amount or 1))

    def _bet_size_pot_fraction(self, round_state: RoundStateClient, pot: int, call_amount: int, remaining_chips: int, frac: float) -> int:
        # We specify raise amount as additional chips (assumption consistent with engine min_raise/max_raise)
        # Target additional amount near frac * (pot + call)
        base = int(frac * (pot + call_amount))
        # Ensure at least min_raise will be imposed by caller using _clip_raise_amount
        # Clip to remaining chips minus call (so we can still pay call if engine semantics differ)
        return max(0, min(base, max(0, remaining_chips - call_amount)))

    def _clip_raise_amount(self, desired_add: int, min_raise: int, max_raise: int) -> int:
        # Ensure raise amount within [min_raise, max_raise]
        if max_raise < min_raise:
            return -1
        return max(min_raise, min(max_raise, desired_add))