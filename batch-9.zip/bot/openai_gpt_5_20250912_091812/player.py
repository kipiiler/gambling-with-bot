from typing import List, Tuple, Dict, Any
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANKS = "23456789TJQKA"
RANK_TO_VAL = {r: i + 2 for i, r in enumerate(RANKS)}
VAL_TO_RANK = {v: r for r, v in RANK_TO_VAL.items()}


def card_rank(card: str) -> str:
    # card examples: 'Ah', 'Td'
    if not card or len(card) < 2:
        return '2'
    return card[0].upper()


def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return 'x'
    return card[1].lower()


def rank_value(rank_char: str) -> int:
    return RANK_TO_VAL.get(rank_char.upper(), 2)


def sorted_two_ranks(hole_cards: List[str]) -> Tuple[str, str]:
    r1 = card_rank(hole_cards[0])
    r2 = card_rank(hole_cards[1])
    v1 = rank_value(r1)
    v2 = rank_value(r2)
    if v1 >= v2:
        return r1, r2
    else:
        return r2, r1


def is_suited(hole_cards: List[str]) -> bool:
    return card_suit(hole_cards[0]) == card_suit(hole_cards[1])


def hand_code(hole_cards: List[str]) -> str:
    # Returns like 'AKs', 'AQo', 'TT'
    r1, r2 = sorted_two_ranks(hole_cards)
    if r1 == r2:
        return r1 + r2
    suited = 's' if is_suited(hole_cards) else 'o'
    return r1 + r2 + suited


def clamp(x: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, x))


def has_straight(all_cards: List[str]) -> bool:
    # Checks if any 5-card straight exists among the given cards
    # Simplified: use set of unique rank values, include Ace low as 1
    vals = set(rank_value(card_rank(c)) for c in all_cards if c)
    if 14 in vals:
        vals.add(1)
    seq = sorted(vals)
    if not seq:
        return False
    # Count consecutive runs
    longest = 1
    cur = 1
    for i in range(1, len(seq)):
        if seq[i] == seq[i - 1] + 1:
            cur += 1
            longest = max(longest, cur)
        elif seq[i] == seq[i - 1]:
            continue
        else:
            cur = 1
    return longest >= 5


def flush_count_by_suit(all_cards: List[str]) -> Dict[str, int]:
    d: Dict[str, int] = {}
    for c in all_cards:
        s = card_suit(c)
        d[s] = d.get(s, 0) + 1
    return d


def has_flush(all_cards: List[str]) -> bool:
    suits = flush_count_by_suit(all_cards)
    return any(cnt >= 5 for cnt in suits.values())


def has_flush_draw(hole_cards: List[str], community: List[str]) -> bool:
    # Flush draw: 4 of a suit among hole + board and we hold at least one of that suit
    if not hole_cards:
        return False
    all_cards = hole_cards + community
    suits = flush_count_by_suit(all_cards)
    for s, cnt in suits.items():
        if cnt == 4:
            # ensure we contribute to the draw (have at least one of that suit)
            if any(card_suit(c) == s for c in hole_cards):
                return True
    return False


def rank_histogram(cards: List[str]) -> Dict[int, int]:
    hist: Dict[int, int] = {}
    for c in cards:
        rv = rank_value(card_rank(c))
        hist[rv] = hist.get(rv, 0) + 1
    return hist


def evaluate_made_hand(hole_cards: List[str], community: List[str]) -> str:
    # Returns a coarse category string for postflop decision-making
    all_cards = hole_cards + community
    rh = rank_histogram(all_cards)
    counts = sorted(rh.values(), reverse=True)
    # Quads, Full house, Trips, Two pair, Pair, High card:
    if 4 in counts:
        return 'quads'
    if 3 in counts and 2 in counts:
        return 'full_house'
    if has_flush(all_cards):
        return 'flush'
    if has_straight(all_cards):
        return 'straight'
    if 3 in counts:
        return 'trips'
    if counts.count(2) >= 2:
        return 'two_pair'
    # For one pair, further refine: overpair, top pair, second pair, underpair
    if 2 in counts:
        # Determine board ranks
        board_vals = sorted((rank_value(card_rank(c)) for c in community), reverse=True)
        my_vals = [rank_value(card_rank(c)) for c in hole_cards]
        # If pocket pair (both same)
        if rank_value(card_rank(hole_cards[0])) == rank_value(card_rank(hole_cards[1])):
            # Overpair if both board cards (max) are lower than our pair rank
            pair_rank = rank_value(card_rank(hole_cards[0]))
            if not board_vals:
                return 'pair'
            if all(bv < pair_rank for bv in board_vals):
                return 'overpair'
            else:
                return 'pair'
        # Else pair made with board
        # Determine highest board rank
        top_board = max(board_vals) if board_vals else 0
        second_board = board_vals[1] if len(board_vals) > 1 else 0
        # What is our pair rank?
        all_ranks = [rank_value(card_rank(c)) for c in all_cards]
        for v in sorted(set(all_ranks), reverse=True):
            if all_ranks.count(v) == 2:
                pair_rank = v
                break
        else:
            return 'pair'
        if pair_rank >= top_board:
            return 'top_pair'
        elif second_board and pair_rank >= second_board:
            return 'second_pair'
        else:
            return 'pair'
    return 'high_card'


def preflop_category(hole_cards: List[str], players_at_table: int) -> str:
    # Categorize into 'premium', 'strong', 'medium', 'speculative', 'trash'
    code = hand_code(hole_cards)
    pair = code if len(code) == 2 else None

    premium_pairs = {'AA', 'KK', 'QQ', 'JJ'}
    strong_pairs = {'TT', '99', '88'}
    medium_pairs = {'77', '66', '55'}
    small_pairs = {'44', '33', '22'}

    premium_broadways = {'AKs', 'AKo', 'AQs'}
    strong_broadways = {'AQo', 'AJs', 'KQs', 'AJo', 'KQo'}
    medium_broadways = {'ATs', 'KJs', 'QJs', 'JTs', 'KQo'}
    speculative_suited = {'T9s', '98s', '87s', '76s', '65s', '54s', 'A5s', 'A4s', 'A3s', 'A2s', 'KTs', 'QTs', 'J9s', 'T8s', '97s', '86s', '75s', '64s', '53s', '43s'}

    if pair in premium_pairs or code in premium_broadways:
        cat = 'premium'
    elif (pair in strong_pairs) or (code in strong_broadways):
        cat = 'strong'
    elif (pair in medium_pairs) or (code in medium_broadways):
        cat = 'medium'
    elif (pair in small_pairs) or (code in speculative_suited):
        cat = 'speculative'
    else:
        # Some Axs and KQo/KJo can be medium/strong; rough bump
        r1, r2 = sorted_two_ranks(hole_cards)
        suited = is_suited(hole_cards)
        if r1 == 'A' and suited:
            cat = 'medium'
        elif r1 == 'K' and r2 in ('Q', 'J'):
            cat = 'medium'
        else:
            cat = 'trash'

    # Heads-up adjustment: widen by one category
    if players_at_table <= 2:
        if cat == 'strong':
            return 'premium'
        if cat == 'medium':
            return 'strong'
        if cat == 'speculative':
            return 'medium'
        if cat == 'trash':
            return 'speculative'
        return cat
    return cat


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0  # small blind
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.players_at_table = 2

        self.hole_cards: List[str] = []
        self.community_cards: List[str] = []

        self.preflop_raiser = False
        self.random = random.Random()

        self.hand_round = 'Preflop'  # 'Preflop', 'Flop', 'Turn', 'River'
        self.last_round_num = -1

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called at the start of a new hand (game run or hand depending on engine)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        self.players_at_table = max(2, len(self.all_players)) if self.all_players else 2

        # New hand
        self.hole_cards = player_hands[:] if player_hands else []
        self.community_cards = []
        self.preflop_raiser = False
        self.hand_round = 'Preflop'
        # seed randomness slightly differently each hand
        seed_val = (self.id or 0) ^ (starting_chips or 0) ^ (blind_amount or 0)
        self.random.seed(seed_val)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update community cards and current round street
        try:
            self.hand_round = round_state.round
            self.community_cards = round_state.community_cards[:] if round_state.community_cards else []
            self.last_round_num = round_state.round_num
        except Exception:
            # Defensive: ignore state update failures
            pass

    def _my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _to_call(self, round_state: RoundStateClient) -> int:
        try:
            tc = int(round_state.current_bet) - self._my_bet(round_state)
            return max(0, tc)
        except Exception:
            return 0

    def _can_check(self, round_state: RoundStateClient) -> bool:
        return self._to_call(round_state) <= 0

    def _can_raise(self, round_state: RoundStateClient) -> bool:
        try:
            return int(round_state.min_raise) > 0 and int(round_state.max_raise) >= int(round_state.min_raise)
        except Exception:
            return False

    def _valid_raise_by(self, round_state: RoundStateClient, desired: int) -> int:
        try:
            min_r = int(round_state.min_raise)
            max_r = int(round_state.max_raise)
            if max_r < min_r:
                return -1
            # Ensure within bounds
            return clamp(int(desired), min_r, max_r)
        except Exception:
            return -1

    def _pot(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.pot)
        except Exception:
            return 0

    def _bb(self) -> int:
        # In logs blind_amount corresponds to small blind; BB = 2*SB
        return max(2 * int(self.blind_amount or 1), 2)

    def _bet_fraction_of_pot_raise_by(self, round_state: RoundStateClient, frac: float, remaining_chips: int) -> int:
        # Compute a raise-by amount that roughly equals frac * pot
        # Ensure within [min_raise, max_raise]
        pot = max(self._pot(round_state), 0)
        # Add a small epsilon to avoid division-by-zero effects when used elsewhere
        desired = int(max(1, frac * pot))
        desired = max(desired, int(round_state.min_raise or 0))
        desired = min(desired, int(round_state.max_raise or remaining_chips or desired))
        if desired < int(round_state.min_raise or 0):
            return -1
        return desired

    def _preflop_decision(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._to_call(round_state)
        min_r = int(round_state.min_raise or 0)
        max_r = int(round_state.max_raise or remaining_chips or 0)
        pot = self._pot(round_state)
        bb = self._bb()
        category = preflop_category(self.hole_cards, self.players_at_table)

        # If we can check (BB facing no raise)
        if to_call == 0:
            # Iso-raise (protect) strong hands, otherwise check
            if category in ('premium', 'strong') and self._can_raise(round_state):
                open_size = max(3 * min_r, int(2.5 * bb))
                rb = self._valid_raise_by(round_state, open_size)
                if rb >= min_r:
                    self.preflop_raiser = True
                    return (PokerAction.RAISE, rb)
            # Occasional bluff raise with suited connectors heads-up
            if self.players_at_table <= 2 and category in ('speculative', 'medium') and self._can_raise(round_state):
                if self.random.random() < 0.25:
                    rb = self._valid_raise_by(round_state, max(2 * min_r, int(2.0 * bb)))
                    if rb >= min_r:
                        self.preflop_raiser = True
                        return (PokerAction.RAISE, rb)
            return (PokerAction.CHECK, 0)

        # There is a bet to call (could be blinds or a raise)
        # If it's just completing the SB (very small), call widely
        if to_call <= bb and category in ('premium', 'strong', 'medium', 'speculative'):
            # Sometimes raise (3-bet) with premium/strong
            if category in ('premium', 'strong') and self._can_raise(round_state):
                # 3-bet sizing: ~3x raise or 3*min_r
                desired = max(3 * to_call, 3 * min_r)
                rb = self._valid_raise_by(round_state, desired)
                if rb >= min_r and self.random.random() < 0.7:
                    self.preflop_raiser = True
                    return (PokerAction.RAISE, rb)
            return (PokerAction.CALL, 0)

        # Facing a raise (to_call > bb)
        if category == 'premium':
            # Mostly 3-bet; if shallow stack, all-in is fine
            if remaining_chips <= 10 * bb:
                return (PokerAction.ALL_IN, 0)
            if self._can_raise(round_state):
                desired = max(3 * to_call, 3 * min_r)
                rb = self._valid_raise_by(round_state, desired)
                if rb >= min_r:
                    self.preflop_raiser = True
                    return (PokerAction.RAISE, rb)
            return (PokerAction.CALL, 0)
        elif category == 'strong':
            # Mix between call and 3-bet
            if self._can_raise(round_state) and self.random.random() < 0.4:
                desired = max(3 * to_call, 3 * min_r)
                rb = self._valid_raise_by(round_state, desired)
                if rb >= min_r:
                    self.preflop_raiser = True
                    return (PokerAction.RAISE, rb)
            # Call if price reasonable
            # Pot odds rough: call if to_call <= 20% of pot
            if to_call <= max(bb, int(0.25 * (pot + 1))):
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        elif category == 'medium':
            # Prefer call if price is cheap
            if to_call <= max(2 * bb, int(0.2 * (pot + 1))):
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        elif category == 'speculative':
            # Set mine/suited connectors: call only if cheap
            if to_call <= max(bb, int(0.15 * (pot + 1))):
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            # Trash
            if to_call <= bb and self.players_at_table <= 2 and self.random.random() < 0.15:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def _postflop_decision(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._to_call(round_state)
        min_r = int(round_state.min_raise or 0)
        pot = max(self._pot(round_state), 0)
        stage = self.hand_round
        made = evaluate_made_hand(self.hole_cards, self.community_cards)
        fd = has_flush_draw(self.hole_cards, self.community_cards)

        # Strong made hands: bet/raise big
        strong_made = {'quads', 'full_house', 'flush', 'straight', 'trips', 'two_pair'}
        medium_made = {'overpair', 'top_pair'}
        weak_made = {'second_pair', 'pair'}

        can_check = self._can_check(round_state)
        can_raise = self._can_raise(round_state)

        # If facing a bet (to_call > 0)
        if to_call > 0:
            # Very strong: raise big
            if made in strong_made:
                if can_raise:
                    frac = 0.7 if stage in ('Turn', 'River') else 0.6
                    rb = self._bet_fraction_of_pot_raise_by(round_state, frac, remaining_chips)
                    if rb >= min_r:
                        return (PokerAction.RAISE, rb)
                # If cannot raise, call
                return (PokerAction.CALL, 0)

            # Medium strength: call reasonable bets; sometimes raise on flop
            if made in medium_made:
                # Call threshold: up to ~70% pot
                if to_call <= int(0.7 * (pot + 1)):
                    # Occasional protection raise on flop/turn
                    if stage in ('Flop', 'Turn') and can_raise and self.random.random() < 0.25:
                        rb = self._bet_fraction_of_pot_raise_by(round_state, 0.6, remaining_chips)
                        if rb >= min_r:
                            return (PokerAction.RAISE, rb)
                    return (PokerAction.CALL, 0)
                else:
                    # Too expensive; fold marginal top pair weak kickers sometimes
                    if stage == 'River':
                        return (PokerAction.FOLD, 0)
                    return (PokerAction.CALL, 0)

            # Draws: call with decent pot odds; semi-bluff raise sometimes
            if fd:
                # Flush draw approx equity ~18% from flop to river; ~9% on turn
                thr = 0.5 if stage == 'Flop' else 0.35
                if to_call <= int(thr * (pot + 1)):
                    if can_raise and self.random.random() < 0.25:
                        rb = self._bet_fraction_of_pot_raise_by(round_state, 0.5, remaining_chips)
                        if rb >= min_r:
                            return (PokerAction.RAISE, rb)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

            if made in weak_made:
                # Call small bets, fold to large ones
                if to_call <= int(0.33 * (pot + 1)):
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # High card / air: mostly fold; occasionally bluff raise small bets on flop
            if stage == 'Flop' and to_call <= int(0.2 * (pot + 1)) and can_raise and self.random.random() < 0.1:
                rb = self._bet_fraction_of_pot_raise_by(round_state, 0.5, remaining_chips)
                if rb >= min_r:
                    return (PokerAction.RAISE, rb)
            return (PokerAction.FOLD, 0)

        # No bet yet (we can check or bet)
        # As preflop raiser, consider c-bet on flop a lot; smaller frequency later
        if can_check:
            if made in strong_made:
                # Value bet
                frac = 0.75 if stage == 'River' else 0.6
                if self._can_raise(round_state):
                    rb = self._bet_fraction_of_pot_raise_by(round_state, frac, remaining_chips)
                    if rb >= min_r:
                        return (PokerAction.RAISE, rb)
                return (PokerAction.CHECK, 0)

            if made in medium_made:
                # Value/protection bet earlier streets
                if stage in ('Flop', 'Turn') and self._can_raise(round_state):
                    rb = self._bet_fraction_of_pot_raise_by(round_state, 0.5, remaining_chips)
                    if rb >= min_r:
                        return (PokerAction.RAISE, rb)
                return (PokerAction.CHECK, 0)

            # Draws: semi-bluff on flop/turn sometimes
            if fd and stage in ('Flop', 'Turn') and self._can_raise(round_state):
                if self.random.random() < 0.5:
                    rb = self._bet_fraction_of_pot_raise_by(round_state, 0.5, remaining_chips)
                    if rb >= min_r:
                        return (PokerAction.RAISE, rb)
                return (PokerAction.CHECK, 0)

            # C-bet bluff: as preflop raiser on flop with favorable boards
            if stage == 'Flop' and self.preflop_raiser and self._can_raise(round_state):
                # Avoid very connected/mono boards for bluffing
                suits = flush_count_by_suit(self.community_cards)
                mono = any(cnt >= 3 for cnt in suits.values())
                # Connectivity heuristic: presence of many consecutive ranks
                board_vals = sorted(rank_value(card_rank(c)) for c in self.community_cards)
                connected = False
                if len(board_vals) >= 3:
                    connected = (abs(board_vals[0] - board_vals[1]) <= 2 and abs(board_vals[1] - board_vals[2]) <= 2)
                if not mono and not connected:
                    if self.random.random() < 0.55:
                        rb = self._bet_fraction_of_pot_raise_by(round_state, 0.45, remaining_chips)
                        if rb >= min_r:
                            return (PokerAction.RAISE, rb)
            return (PokerAction.CHECK, 0)

        # Fallback
        return (PokerAction.CHECK, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Safety values
            to_call = self._to_call(round_state)
            pot = self._pot(round_state)
            min_r = int(round_state.min_raise or 0)
            max_r = int(round_state.max_raise or remaining_chips or 0)

            # Preflop vs Postflop logic
            if self.hand_round == 'Preflop':
                action, amount = self._preflop_decision(round_state, remaining_chips)
            else:
                action, amount = self._postflop_decision(round_state, remaining_chips)

            # Ensure action validity
            if action == PokerAction.CHECK:
                if to_call > 0:
                    # Cannot check; default to CALL if affordable, else FOLD
                    if to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                return (PokerAction.CHECK, 0)

            if action == PokerAction.CALL:
                if to_call <= 0:
                    # Nothing to call; convert to CHECK
                    return (PokerAction.CHECK, 0)
                return (PokerAction.CALL, 0)

            if action == PokerAction.RAISE:
                if not self._can_raise(round_state):
                    # Can't raise; fall back to CALL if needed else CHECK
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                # Validate raise amount
                if amount is None or amount <= 0:
                    amount = min_r
                amount = clamp(int(amount), min_r, max_r)
                # Mark preflop raiser
                if self.hand_round == 'Preflop':
                    self.preflop_raiser = True
                return (PokerAction.RAISE, amount)

            if action == PokerAction.ALL_IN:
                # Always valid; if to_call==0 and we choose ALL_IN by mistake, it still stands; but prefer CHECK if no pressure
                if to_call <= 0 and remaining_chips > 0:
                    # Avoid pointless all-in without incentive; check instead
                    return (PokerAction.CHECK, 0)
                return (PokerAction.ALL_IN, 0)

            if action == PokerAction.FOLD:
                if to_call <= 0:
                    # No need to fold; check instead
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)

            # Fallback safe
            return (PokerAction.CHECK if to_call <= 0 else PokerAction.FOLD, 0)

        except Exception:
            # Absolute fallback to avoid exceptions causing auto-fold penalties
            try:
                to_call = self._to_call(round_state)
            except Exception:
                to_call = 0
            return (PokerAction.CHECK if to_call <= 0 else PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-based flags if needed
        self.preflop_raiser = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent state needed across games beyond defaults
        pass