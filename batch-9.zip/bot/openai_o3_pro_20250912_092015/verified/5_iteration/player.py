from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# External, pure-python hand evaluator
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A very small, self-contained No-Limit Texas Hold’em poker bot.
    1. Uses a pre–flop starting-hand table to decide whether to raise, call or fold.
    2. From the flop onward it evaluates its hand with the Treys Evaluator and
       compares a crude equity estimate to the immediate pot-odds to decide.
    3. Always returns a syntactically valid action in the required format.
    """

    # ----------------------------------------------------------------------
    # Construction / helpers
    # ----------------------------------------------------------------------
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind_amount: int = 0
        self.hole_cards: Optional[List[str]] = None
        self.evaluator = Evaluator()
        # map treys class number to rough equity estimate
        self.class_equity = {
            1: 0.99,   # straight-flush / royal
            2: 0.92,   # four of a kind
            3: 0.88,   # full house
            4: 0.80,   # flush
            5: 0.75,   # straight
            6: 0.67,   # trips
            7: 0.56,   # two pair
            8: 0.42,   # one pair
            9: 0.25,   # high card
        }
        # Very small epsilon for safe divisions
        self.eps = 1e-9

    # ----------------------------------------------------------------------
    # Mandatory interface methods
    # ----------------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        # player_hands is assumed to be our two hole cards in string form
        if player_hands and len(player_hands) == 2:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        At the beginning of every hand we expect new hole cards to be supplied
        inside round_state.player_hands (dict) if the server follows that
        interface.  Fallback to previously stored cards if not present.
        """
        # Attempt to pull our current hole cards from the round_state
        cards = None
        if hasattr(round_state, "player_hands"):
            ph = round_state.player_hands
            if isinstance(ph, dict):
                cards = ph.get(str(self.id)) or ph.get(self.id)
        if cards and len(cards) == 2:
            self.hole_cards = cards  # refresh

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine – chooses a valid poker action.
        """
        # ---------- Safety checks ----------
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0  # should not happen, but stay safe
        if self.id is None:
            return PokerAction.FOLD, 0

        # ---------- Convenience variables ----------
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        pot_size = round_state.pot

        # Try to identify stage
        stage = round_state.round.lower()  # 'preflop', 'flop', etc.

        # ------------------------------------------------------------------
        # PRE-FLOP STRATEGY
        # ------------------------------------------------------------------
        if stage == "preflop":
            if not self.hole_cards or len(self.hole_cards) != 2:
                # Unknown cards -> very conservative
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return (
                    PokerAction.FOLD,
                    0,
                )

            hand_code = self._preflop_code(self.hole_cards[0], self.hole_cards[1])

            if hand_code in self._premium_hands():
                # Premium: 3-4× raise, or shove if stacks are short
                target = max(
                    min_raise, int(3 * self.big_blind_amount)
                )  # at least 3× blind
                raise_amt = min(max_raise, target)
                if raise_amt >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
                # fall back to call
                if call_amount <= remaining_chips:
                    return (
                        PokerAction.CALL,
                        0,
                    )

            elif hand_code in self._good_hands():
                # Decent – call small bet, otherwise fold/check
                threshold = 0.05 * remaining_chips  # 5 % of stack
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                if call_amount <= threshold:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            else:
                # Weak hand
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        # ------------------------------------------------------------------
        # POST-FLOP STRATEGY (flop, turn, river)
        # ------------------------------------------------------------------
        estimated_equity = self._estimate_equity(
            self.hole_cards, round_state.community_cards
        )
        pot_odds = call_amount / (pot_size + call_amount + self.eps)

        # 1. Very strong hand – build pot / shove
        if estimated_equity >= 0.85:
            # pot-building raise: between 50 % and 100 % pot
            target_raise = int(pot_size * 0.7)
            target_raise = max(target_raise, min_raise)
            target_raise = min(target_raise, max_raise)
            if target_raise >= remaining_chips or max_raise == remaining_chips:
                return PokerAction.ALL_IN, 0
            if target_raise >= min_raise:
                return PokerAction.RAISE, target_raise
            # else fall back to call

        # 2. Good call if equity beats pot odds
        if estimated_equity >= pot_odds:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            if call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        # 3. Fold otherwise
        if call_amount == 0:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No persistent learning currently – placeholder for future work
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # Nothing to clean up
        pass

    # ----------------------------------------------------------------------
    # Internal helper functions
    # ----------------------------------------------------------------------
    @staticmethod
    def _rank_value(card_str: str) -> str:
        return card_str[0]  # 'A', 'K', 'Q', …, '2'

    def _preflop_code(self, c1: str, c2: str) -> str:
        """
        Returns a canonical pre-flop hand code like ‘AKs’, ‘QJo’, ‘55’.
        """
        r1, r2 = self._rank_value(c1), self._rank_value(c2)
        suited = c1[1] == c2[1]
        # order ranks descending
        order = "AKQJT98765432"
        if order.index(r2) < order.index(r1):
            r1, r2 = r2, r1
        if r1 == r2:
            return r1 + r2  # e.g. 'AA'
        return r1 + r2 + ("s" if suited else "o")

    @staticmethod
    def _premium_hands() -> set:
        return {"AA", "KK", "QQ", "JJ", "AKs"}

    @staticmethod
    def _good_hands() -> set:
        return {
            "TT",
            "AQs",
            "AKo",
            "AJs",
            "KQs",
            "99",
            "JTs",
            "QJs",
            "KJs",
            "ATs",
            "AQo",
            "88",
        }

    # ------------------------------------------------------------------
    # Equity estimation (very cheap – no Monte-Carlo)
    # ------------------------------------------------------------------
    def _estimate_equity(self, hole_cards: Optional[List[str]], board: List[str]) -> float:
        """
        Convert Treys rank class into a hard-coded equity approximation.
        """
        if not hole_cards or len(hole_cards) != 2:
            return 0.25  # unknown -> weak

        try:
            hole = [Card.new(s) for s in hole_cards]
            community = [Card.new(s) for s in board]
            score = self.evaluator.evaluate(community, hole)
            class_rank = self.evaluator.get_rank_class(score)
            return self.class_equity.get(class_rank, 0.25)
        except Exception:
            # Fail-safe
            return 0.25