import random
import math
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# The treys library provides a fast, pure-python poker hand evaluator
# (MIT licence, < 100 kB).  Allowed as an external dependency.
from treys import Card, Evaluator, Deck


def _to_treys(card_str: str) -> int:
    """
    Convert 2-char card notation used by the server (e.g. 'Ah', 'Td')
    to the integer representation expected by treys.Card.
    """
    if not card_str or len(card_str) != 2:
        raise ValueError(f"Bad card string: {card_str}")
    rank, suit = card_str[0], card_str[1].lower()
    return Card.new(rank + suit)


def chen_formula(card1: str, card2: str) -> float:
    """
    Very small, light-weight approximation of preflop hand strength
    (Chen & Ankenman, 2006).  Returns score 0-12.
    """
    ranks = "23456789TJQKA"
    values = {
        "A": 10,
        "K": 8,
        "Q": 7,
        "J": 6,
        "T": 5,
        "9": 4.5,
        "8": 4,
        "7": 3.5,
        "6": 3,
        "5": 2.5,
        "4": 2,
        "3": 1.5,
        "2": 1
    }

    r1, r2 = card1[0], card2[0]
    s1, s2 = card1[1], card2[1]

    high = values[r1]
    low = values[r2]

    if high < low:  # keep r1 the high card
        high, low = low, high
        r1, r2 = r2, r1
        s1, s2 = s2, s1

    score = high

    # Pair bonus
    if r1 == r2:
        score *= 2
        if score < 5:
            score = 5
        if score > 10:
            score = 10
        return score

    # Suited
    if s1 == s2:
        score += 2

    # Gap
    gap = abs(ranks.index(r1) - ranks.index(r2)) - 1
    if gap == 0:
        score += 1
    elif gap == 1:
        score += 0
    elif gap == 2:
        score -= 1
    elif gap == 3:
        score -= 2
    else:
        score -= 4

    # Small gap & suited bonus for straight potential
    if (gap <= 1) and (s1 == s2) and (ranks.index(r1) < ranks.index("Q")):
        score += 1

    return max(score, 0)


class SimplePlayer(Bot):
    """
    A very small, pure-python poker bot that follows the competition template.
    Pre-flop: Chen formula aggression.
    Post-flop: Monte-Carlo win-probability vs one random opponent
               (100 simulations -> <10 ms).
    The whole class stays comfortably within the 30 s / 100 MB limits.
    """

    def __init__(self):
        super().__init__()
        self.evaluator = Evaluator()
        self.rng = random.Random()
        # State remembered across callbacks
        self.starting_chips = 0
        self.blind_amount = 0
        self.current_hand: List[str] = []  # our two hole cards
        self.round_idx = 0

    # -------------------  CALLBACKS REQUIRED BY THE TEMPLATE ---------------- #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_idx = round_state.round_num
        # Hole cards should be somewhere in the round_state. Try the most
        # common options; if not found, keep previous value (failsafe).
        try:
            if hasattr(round_state, "player_hands"):
                self.current_hand = round_state.player_hands.get(
                    str(self.id), round_state.player_hands.get(self.id, [])
                )
            elif hasattr(round_state, "hole_cards"):
                self.current_hand = round_state.hole_cards  # type: ignore
        except Exception:
            self.current_hand = []

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision function.  Always returns a valid action even if unexpected
        data are received (failsafe folds).
        """
        try:
            # ------------------------------------------------------------- #
            # Extract useful numbers
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = max(0, round_state.current_bet - my_bet)
            min_raise = round_state.min_raise
            pot_size = round_state.pot
            stage = (round_state.round or "").lower()  # "preflop", "flop", ...

            # We might not have received our cards for some reason – be cautious
            hole_cards = self.current_hand if len(self.current_hand) == 2 else []

            # ---------------  PREFLOP DECISION USING CHEN FORMULA  ---------- #
            if stage.startswith("pre"):
                if len(hole_cards) == 2:
                    chen = chen_formula(hole_cards[0], hole_cards[1])
                else:
                    chen = 0  # unknown cards -> very weak

                # Thresholds calibrated for heads-up micro-stakes
                if chen >= 8:  # strong -> raise / 3-bet
                    if remaining_chips > to_call + min_raise:
                        raise_amt = max(min_raise, to_call + min_raise)
                        raise_amt = min(raise_amt, remaining_chips)
                        return PokerAction.RAISE, raise_amt
                    else:
                        return PokerAction.ALL_IN, remaining_chips
                elif chen >= 5:  # mediocre -> call
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    if remaining_chips > to_call:
                        return PokerAction.CALL, 0
                    return PokerAction.ALL_IN, remaining_chips
                else:  # trash
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    return PokerAction.FOLD, 0

            # ---------------  POSTFLOP WIN-PROBABILITY SIMULATION ----------- #
            if len(hole_cards) != 2:
                # Without hole cards we can only check/fold
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            win_prob = self._estimate_win_probability(
                hole_cards, round_state.community_cards, simulations=100
            )

            # Adjust for multi-way pots: assume equal random ranges
            active_players = len(round_state.current_player)
            if active_players > 1:
                win_prob = win_prob ** (active_players - 1)

            # Pot-odds call threshold
            call_cost = to_call
            pot_after_call = pot_size + call_cost
            pot_odds = call_cost / (pot_after_call + 1e-9)

            if call_cost > 0 and win_prob < pot_odds - 0.05:
                # Clearly –ev call → fold
                return PokerAction.FOLD, 0

            # Aggression with strong equity
            if win_prob > 0.75 and remaining_chips > call_cost + min_raise:
                raise_amt = max(min_raise, int(pot_size * 0.75))
                raise_amt = min(raise_amt + call_cost, remaining_chips)
                return PokerAction.RAISE, raise_amt

            # Medium strength – call / check
            if call_cost == 0:
                return PokerAction.CHECK, 0
            if remaining_chips > call_cost:
                return PokerAction.CALL, 0
            return PokerAction.ALL_IN, remaining_chips

        except Exception:
            # Any unexpected issue -> safe fold to avoid penalties
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_hand = []  # clear between rounds

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict[str, List[str]],
    ):
        pass

    # ----------------------------- HELPERS --------------------------------- #

    def _estimate_win_probability(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        simulations: int = 100,
    ) -> float:
        """
        Monte-Carlo estimate of hand equity versus 1 random opponent.
        100 simulations << 1 ms with treys.
        """
        try:
            deck = Deck()
            known = [_to_treys(c) for c in hole_cards + community_cards]
            for card in known:
                deck.cards.remove(card)

            hero_hand = [_to_treys(c) for c in hole_cards]
            board_known = [_to_treys(c) for c in community_cards]
            wins = 0
            for _ in range(simulations):
                # Sample opponent hand
                opp = deck.draw(2)
                # Complete board
                remaining_board = deck.draw(5 - len(board_known))
                board = board_known + remaining_board
                hero_rank = self.evaluator.evaluate(board, hero_hand)
                opp_rank = self.evaluator.evaluate(board, opp)
                if hero_rank < opp_rank:
                    wins += 1
                elif hero_rank == opp_rank:
                    wins += 0.5
                # Return sampled cards
                deck.cards.extend(opp + remaining_board)
            return wins / simulations
        except Exception:
            # Failsafe: unknown -> very weak equity
            return 0.0