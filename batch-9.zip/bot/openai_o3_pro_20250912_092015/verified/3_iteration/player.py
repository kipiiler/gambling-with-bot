# player.py
from __future__ import annotations

import random
import math
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# We rely on the pure-python “treys” library for hand evaluation
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A reasonably strong, error-tolerant No-Limit Hold’em bot.
    Uses:
      • Lightweight pre-flop strength heuristics
      • Monte-Carlo simulations with treys for post-flop equity
      • Pot-odds comparison for betting decisions
    """

    # ---------- Helper constants ----------
    RANK_ORDER = "23456789TJQKA"
    PRE_FLOP_FOLD_THRESHOLD = 0.20
    PRE_FLOP_RAISE_THRESHOLD = 0.65
    POST_FLOP_FOLD_THRESHOLD = 0.15
    POST_FLOP_RAISE_THRESHOLD = 0.70
    MC_SIMULATIONS_POSTFLOP = 300        # keep small for time constraints
    MC_SIMULATIONS_PREFLOP = 200          # only used when < 4 players remain

    def __init__(self) -> None:
        super().__init__()
        self.evaluator = Evaluator()

        # will be refreshed every hand
        self.hole_cards: List[str] = []
        self.current_round: str = ""
        self.my_bet_this_round: int = 0
        self.starting_stack: int = 0

        # basic stats you can build on
        self.hands_played: int = 0
        self.hands_won: int = 0

    # ------------------------------------------------------------------ #
    #                    Framework life-cycle callbacks                  #
    # ------------------------------------------------------------------ #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ) -> None:
        """Called once at the beginning of the match."""
        self.starting_stack = starting_chips
        self._set_hole_cards(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        """Called at the beginning of each hand."""
        self.hands_played += 1
        self.current_round = "Preflop"
        self.my_bet_this_round = 0

        # Try to pull new hole cards from round_state if available
        hole_cards = self._extract_hole_cards_from_round_state(round_state)
        if hole_cards:
            self._set_hole_cards(hole_cards)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision function. Chooses an action & amount (if needed).
        Always returns a legal action; falls back to folding on error.
        """
        try:
            self.current_round = round_state.round
            our_bet = self._get_player_bet(round_state)
            to_call = max(round_state.current_bet - our_bet, 0)
            can_check = to_call == 0
            pot = round_state.pot
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            # Compute win probability
            players_still_in = max(len(round_state.current_player), 2)
            win_prob = self._estimate_win_probability(
                community_cards=round_state.community_cards,
                num_active_players=players_still_in,
            )

            # Pot-odds calculation
            pot_odds = to_call / (pot + to_call + 1e-9) if to_call > 0 else 0.0

            # Decide action
            if can_check:
                if win_prob >= self.POST_FLOP_RAISE_THRESHOLD and max_raise >= min_raise:
                    # value bet
                    raise_amount = self._choose_raise_amount(
                        pot, min_raise, max_raise, win_prob
                    )
                    self.my_bet_this_round += raise_amount
                    return PokerAction.RAISE, raise_amount
                return PokerAction.CHECK, 0

            # Facing a bet
            if win_prob < max(self.PRE_FLOP_FOLD_THRESHOLD, pot_odds):
                return PokerAction.FOLD, 0

            # We are willing to continue
            if win_prob - pot_odds > 0.25 and max_raise >= min_raise:
                raise_amount = self._choose_raise_amount(
                    pot, min_raise, max_raise, win_prob
                )
                # Prevent meaningless min min-raises
                if raise_amount >= min_raise:
                    self.my_bet_this_round += raise_amount
                    return PokerAction.RAISE, raise_amount

            # If calling would put us all-in, just ship it
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, remaining_chips

            return PokerAction.CALL, to_call

        except Exception:
            # Any unexpected error – just fold to stay alive
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        """Track whether we won the pot."""
        try:
            last_actions = round_state.player_actions
            if last_actions:
                winner_ids = [
                    pid for pid, act in last_actions.items() if act == "Win"
                ]
                if self.id in winner_ids:
                    self.hands_won += 1
        except Exception:
            pass  # do not crash

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[Any, float],
        active_players_hands: Dict[Any, Any],
    ) -> None:
        """Print basic stats for debugging."""
        try:
            win_rate = self.hands_won / max(self.hands_played, 1)
            print(
                f"[SimplePlayer] Game over. Hands played={self.hands_played}, "
                f"hands won={self.hands_won}, win-rate={win_rate:.2%}, "
                f"final delta={player_score - self.starting_stack}"
            )
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    #                            Helper methods                          #
    # ------------------------------------------------------------------ #
    def _set_hole_cards(self, cards: List[str]) -> None:
        if len(cards) >= 2:
            self.hole_cards = cards[:2]

    def _extract_hole_cards_from_round_state(
        self, round_state: RoundStateClient
    ) -> List[str]:
        # try several likely attribute names
        for attr in ("player_hands", "hole_cards", "hands"):
            if hasattr(round_state, attr):
                data = getattr(round_state, attr)
                if isinstance(data, dict) and self.id in data:
                    return data[self.id]
                if isinstance(data, dict) and str(self.id) in data:
                    return data[str(self.id)]
        return []

    def _get_player_bet(self, round_state: RoundStateClient) -> int:
        """Return chips we have already committed this betting round."""
        bets = round_state.player_bets
        return bets.get(self.id, bets.get(str(self.id), 0))

    # ------------ Win-probability estimation --------------------------
    def _estimate_win_probability(
        self, community_cards: List[str], num_active_players: int
    ) -> float:
        """
        Quick equity estimation.
        – Pre-flop: Use heuristic or light Monte-Carlo.
        – Post-flop:  Monte-Carlo simulation using treys.
        """
        if not community_cards:  # preflop
            return self._preflop_strength(num_active_players)

        # Post-flop Monte-Carlo
        known_cards = self.hole_cards + community_cards
        deck = Deck()
        for c in known_cards:
            deck.cards.remove(Card.new(c))

        wins = 0
        ties = 0
        simulations = self.MC_SIMULATIONS_POSTFLOP
        our_hand_cards = [Card.new(c) for c in self.hole_cards]
        board_cards = [Card.new(c) for c in community_cards]

        for _ in range(simulations):
            draw_count = 5 - len(board_cards)
            drawn_board = deck.draw(draw_count)
            full_board = board_cards + drawn_board

            # Opponent hands
            opp_hands = []
            for _ in range(num_active_players - 1):
                opp_hands.append([deck.draw(1)[0], deck.draw(1)[0]])

            our_rank = self.evaluator.evaluate(full_board, our_hand_cards)
            best_opp_rank = min(
                self.evaluator.evaluate(full_board, opp) for opp in opp_hands
            )

            if our_rank < best_opp_rank:
                wins += 1
            elif our_rank == best_opp_rank:
                ties += 1

            # Return cards to deck
            deck.cards.extend(drawn_board)
            for opp in opp_hands:
                deck.cards.extend(opp)

        return (wins + ties * 0.5) / max(simulations, 1)

    # ---------------- Pre-flop heuristics ------------------------------
    def _preflop_strength(self, num_players: int) -> float:
        """
        Simple deterministic strength estimator based on starting-hand
        categories, scaled to (0,1). Uses bonus for pairs, suitedness,
        connectivity, and high cards. If only heads-up, will additionally
        perform light Monte-Carlo for higher accuracy.
        """
        if len(self.hole_cards) < 2:
            return 0.0

        r1 = self.hole_cards[0][0]
        r2 = self.hole_cards[1][0]
        s1 = self.hole_cards[0][1]
        s2 = self.hole_cards[1][1]

        rank_idx1 = self.RANK_ORDER.index(r1)
        rank_idx2 = self.RANK_ORDER.index(r2)
        high = max(rank_idx1, rank_idx2)
        low = min(rank_idx1, rank_idx2)

        strength = 0.0

        # pair
        if r1 == r2:
            strength = 0.55 + 0.035 * high  # 55% to 1.0
        else:
            # high card contribution
            strength += (high + 2) * 0.03  # max about 0.45
            # suited
            if s1 == s2:
                strength += 0.05
            # connected
            if abs(rank_idx1 - rank_idx2) == 1:
                strength += 0.04
            elif abs(rank_idx1 - rank_idx2) == 2:
                strength += 0.02

        # Clamp
        strength = max(0.05, min(strength, 0.95))

        # heads-up adjustment – run small MC sim
        if num_players <= 2:
            strength = (
                0.4 * strength
                + 0.6
                * self._mc_equity_preflop(
                    self.hole_cards, num_players, sims=self.MC_SIMULATIONS_PREFLOP
                )
            )

        return strength

    def _mc_equity_preflop(
        self, hole_cards: List[str], num_players: int, sims: int = 200
    ) -> float:
        """Lightweight MC equity preflop vs random hands."""
        deck = Deck()
        for c in hole_cards:
            deck.cards.remove(Card.new(c))

        wins = 0
        ties = 0
        our_hand_cards = [Card.new(c) for c in hole_cards]
        for _ in range(sims):
            board = deck.draw(5)
            opp_hands = [
                [deck.draw(1)[0], deck.draw(1)[0]]
                for _ in range(num_players - 1)
            ]

            our_rank = self.evaluator.evaluate(board, our_hand_cards)
            best_opp_rank = min(
                self.evaluator.evaluate(board, opp) for opp in opp_hands
            )

            if our_rank < best_opp_rank:
                wins += 1
            elif our_rank == best_opp_rank:
                ties += 1

            deck.cards.extend(board)
            for opp in opp_hands:
                deck.cards.extend(opp)

        return (wins + 0.5 * ties) / max(sims, 1)

    # ---------------------- Betting helpers ---------------------------
    @staticmethod
    def _choose_raise_amount(
        pot: int, min_raise: int, max_raise: int, win_prob: float
    ) -> int:
        """
        Choose a raise amount proportional to pot and certainty.
        Ensures legality.
        """
        target = int(pot * (win_prob - 0.4))  # more confidence → bigger raise
        target = max(target, min_raise)
        target = min(target, max_raise)
        return target