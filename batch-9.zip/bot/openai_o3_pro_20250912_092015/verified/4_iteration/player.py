# player.py
from typing import List, Tuple, Dict
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# third-party pure-python evaluator (declared in requirements.txt)
from treys import Card, Evaluator


# ------------ Helper functions ------------------------------------------------
RANK_ORDER = "23456789TJQKA"


def _card_str_to_int(card: str) -> int:
    """Convert 'Ah' -> treys integer representation."""
    return Card.new(card)


def _hand_to_preflop_rep(card1: str, card2: str) -> str:
    """
    Return canonical pre-flop string such as 'AKs', 'QJo', 'TT'.
    The first letter is always the higher rank.
    """
    r1, s1 = card1[0], card1[1]
    r2, s2 = card2[0], card2[1]

    # order by rank strength
    if RANK_ORDER.index(r2) > RANK_ORDER.index(r1):
        r1, r2 = r2, r1
        s1, s2 = s2, s1

    suited = s1 == s2
    if r1 == r2:
        return r1 + r2  # e.g. 'TT'
    return f"{r1}{r2}{'s' if suited else 'o'}"


# very coarse pre-flop strength tiers
PREMIUM_HANDS = {
    "AA",
    "KK",
    "QQ",
    "JJ",
    "AKs",
}
STRONG_HANDS = {
    "TT",
    "AKo",
    "AQs",
    "AJs",
    "KQs",
}
MEDIUM_HANDS = {
    "99",
    "88",
    "77",
    "AQo",
    "KQo",
    "ATs",
    "KJs",
    "QJs",
    "JTs",
}


def _estimate_postflop_strength(
    hole_cards: List[str], board_cards: List[str], n_sim: int = 50
) -> float:
    """
    Very quick Monte-Carlo equity estimate versus one random opponent hand.
    Returns probability [0,1] of winning.
    """
    evaluator = Evaluator()
    deck_cards = set(
        [
            f"{r}{s}"
            for r in "23456789TJQKA"
            for s in "shdc"  # order used by treys
        ]
    )
    used = set(hole_cards + board_cards)
    remaining = list(deck_cards - used)
    hole_int = [_card_str_to_int(c) for c in hole_cards]
    board_int = [_card_str_to_int(c) for c in board_cards]

    wins = ties = 0
    for _ in range(n_sim):
        opp = random.sample(remaining, 2)
        rem_for_board = list(set(remaining) - set(opp))
        needed_board = 5 - len(board_cards)
        board_fill = random.sample(rem_for_board, needed_board)
        full_board = board_cards + board_fill
        opp_int = [_card_str_to_int(c) for c in opp]
        full_board_int = [_card_str_to_int(c) for c in full_board]

        score_me = evaluator.evaluate(full_board_int, hole_int)
        score_opp = evaluator.evaluate(full_board_int, opp_int)
        if score_me < score_opp:
            wins += 1
        elif score_me == score_opp:
            ties += 1
    trials = max(1, n_sim)
    return (wins + ties * 0.5) / trials


# ------------------------------------------------------------------------------
class SimplePlayer(Bot):
    """
    A very small, safe-to-run No-Limit Hold'em poker bot.
    Implements:
        • Simple tier-based pre-flop strategy
        • Rough post-flop equity estimate with treys
        • Strict action validation to avoid automatic folds
    """

    def __init__(self):
        super().__init__()
        self.starting_chips: int | None = None
        self.big_blind: int | None = None
        self.hole_cards: List[str] = []
        self.evaluator = Evaluator()
        # track simple stats
        self.total_hands_played = 0
        self.total_money_won = 0

    # -------------------- Callbacks required by the engine --------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        # We are guaranteed that player_hands is list of strings of our own cards
        # (competition spec). Keep them around.
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # New hand: update hole cards if provided in round_state (depends on server).
        # Fallback to previous value if not present.
        if hasattr(round_state, "player_hands"):
            self.hole_cards = round_state.player_hands
        self.total_hands_played += 1

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision logic. Must ALWAYS return a legal (action, amount) pair.
        """
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = max(0, round_state.current_bet - my_bet)

        # ------------ decide intended action ---------------------------------
        if round_state.round == "Preflop":
            action, amount = self._decide_preflop(round_state, to_call, remaining_chips)
        else:
            action, amount = self._decide_postflop(
                round_state, to_call, remaining_chips
            )

        # ------------ validate before returning ------------------------------
        validated_action, validated_amount = self._validate_action(
            action, amount, to_call, round_state, remaining_chips
        )
        return validated_action, validated_amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # track profit
        if self.starting_chips is not None:
            self.total_money_won += remaining_chips - self.starting_chips

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[str, float],
        active_players_hands: Dict,
    ):
        # final statistics print (will be captured by engine logs)
        print(
            f"[SimplePlayer] Game finished. Hands: {self.total_hands_played}, "
            f"Money Δ: {self.total_money_won}"
        )

    # ------------------------- Decision helpers ------------------------------
    def _decide_preflop(
        self,
        round_state: RoundStateClient,
        to_call: int,
        remaining_chips: int,
    ) -> Tuple[PokerAction, int]:
        """Very coarse hard-coded pre-flop strategy."""
        if len(self.hole_cards) < 2:
            # Fail-safe
            return (PokerAction.FOLD, 0)

        rep = _hand_to_preflop_rep(self.hole_cards[0], self.hole_cards[1])

        # choose aggression factors
        if rep in PREMIUM_HANDS:
            target_action = "aggressive"
        elif rep in STRONG_HANDS:
            target_action = "value"
        elif rep in MEDIUM_HANDS:
            target_action = "speculative"
        else:
            target_action = "trash"

        min_raise = round_state.min_raise
        pot_size = round_state.pot + to_call

        if target_action == "aggressive":
            # if someone has raised before us, 3-bet (raise) up to 3× pot or shove small stack
            desired = min_raise * 3 if to_call == 0 else to_call * 3 + min_raise
            raise_amt = max(min_raise, min(desired, round_state.max_raise))
            if raise_amt >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.RAISE, raise_amt)
        elif target_action == "value":
            if to_call == 0:
                raise_amt = max(min_raise, min(min_raise * 3, round_state.max_raise))
                return (PokerAction.RAISE, raise_amt)
            call_ratio = to_call / max(1, remaining_chips)
            if call_ratio < 0.25:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        elif target_action == "speculative":
            # limp or cheap call, otherwise fold
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            if to_call <= self.big_blind * 2 and to_call < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:  # trash
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

    def _decide_postflop(
        self,
        round_state: RoundStateClient,
        to_call: int,
        remaining_chips: int,
    ) -> Tuple[PokerAction, int]:
        """
        Very light equity driven logic: few Monte-Carlo samples to estimate win %
        then use thresholds to decide whether to bet/raise/call/fold.
        """
        board = round_state.community_cards
        equity = _estimate_postflop_strength(self.hole_cards, board, n_sim=40)

        pot_after_call = round_state.pot + to_call
        pot_odds = to_call / max(1, pot_after_call)

        # Decision thresholds
        if to_call == 0:
            # no bet to us. choose to bet (value) or check
            if equity > 0.75:
                bet_size = max(round_state.min_raise, int(pot_after_call * 0.75))
                bet_size = min(bet_size, round_state.max_raise)
                if bet_size >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, bet_size)
            # medium strength -> small bet or check
            if equity > 0.55 and round_state.min_raise <= remaining_chips * 0.25:
                bet_size = round_state.min_raise
                return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)

        # Facing a bet
        # decide to call, raise, or fold based on equity vs pot odds
        if equity > 0.80:
            # big hand: raise / shove
            raise_amt = max(round_state.min_raise, int(to_call * 3))
            raise_amt = min(raise_amt, round_state.max_raise)
            if raise_amt >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.RAISE, raise_amt)

        if equity > pot_odds + 0.1:
            # profitable call
            if to_call >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, 0)

        return (PokerAction.FOLD, 0)

    # ------------------------ Validation / Safety ----------------------------
    def _validate_action(
        self,
        action: PokerAction,
        amount: int,
        to_call: int,
        round_state: RoundStateClient,
        remaining_chips: int,
    ) -> Tuple[PokerAction, int]:
        """
        Ensure action is legal. If not, downgrade gracefully to a safe option.
        """
        if action == PokerAction.CHECK and to_call != 0:
            # cannot check, must at least call/fold
            action = PokerAction.CALL if to_call <= remaining_chips else PokerAction.FOLD

        if action == PokerAction.CALL:
            if to_call == 0:  # unnecessary call -> check instead
                return (PokerAction.CHECK, 0)
            if to_call > remaining_chips:
                return (PokerAction.ALL_IN, 0)

        if action == PokerAction.RAISE:
            # verify amount bounds
            if amount < round_state.min_raise:
                amount = round_state.min_raise
            if amount > round_state.max_raise:
                amount = round_state.max_raise
            if amount >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            # Avoid raising less than call amount (illegal)
            if amount <= to_call:
                # turn into call if legal
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            return (action, amount)

        # Ensure we are not specifying an amount when unnecessary
        if action in {PokerAction.CHECK, PokerAction.FOLD, PokerAction.CALL, PokerAction.ALL_IN}:
            return (action, 0)

        # Fallback
        return (PokerAction.FOLD, 0)