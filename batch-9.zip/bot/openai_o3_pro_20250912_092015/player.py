# player.py
# NOTE: expects that the framework provides the abstract base-class `Bot`
#       together with the `PokerAction` enum and the `RoundStateClient`
#       dataclass exactly as described in the problem statement.

from __future__ import annotations
import random
from collections import Counter
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_VALUE: Dict[str, int] = {r: i for i, r in enumerate(RANK_ORDER, start=2)}


def card_rank(card: str) -> int:
    """Return numerical rank value of a card string such as 'Ah'."""
    return RANK_VALUE[card[0]]


def card_suit(card: str) -> str:
    return card[1]


class SimplePlayer(Bot):
    """
    A very small, completely self-contained NLHE bot that tries to play
    decent, non-spewy poker while ALWAYS staying within the rules/limits.
    The focus is robustness: never crash, never time-out, never make an
    illegal move.  The strategic core is a simple pre-flop hand group
    table and a post-flop made-hand evaluator.
    """

    # ------------------------------------------------------------------ #
    #  Framework hooks                                                   #
    # ------------------------------------------------------------------ #
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0

        # will be filled every round
        self.hole_cards: List[str] = []
        self.round_num: int = 0

        # statistics we may want to use later
        self.total_hands_played: int = 0
        self.total_chips_won: int = 0

        # pre-computed pre-flop tiers (169 canonical starting hands)
        self._init_preflop_tiers()

    # noinspection PyUnusedLocal
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount

    # noinspection PyUnusedLocal
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Obtain our hole cards if they are provided by the server inside the
        round_state (exact structure may vary slightly – hence the safe
        look-ups).
        """
        self.round_num = round_state.round_num
        self.hole_cards = []

        if hasattr(round_state, "player_hands"):
            # server keys may be int or str – handle both
            pid_key = str(self.id)
            if pid_key in round_state.player_hands:
                self.hole_cards = round_state.player_hands[pid_key]
            elif self.id in round_state.player_hands:
                self.hole_cards = round_state.player_hands[self.id]

    # ------------------------------------------------------------------ #
    #  Main decision point                                               #
    # ------------------------------------------------------------------ #
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide on an action.  The method *must* always return a LEGAL move.
        Fallback strategy hierarchy:
            1. Try intended move if legal
            2. Else, downgrade (RAISE → CALL, CALL → CHECK/FOLD)
            3. Ensure never illegal – finally default to FOLD
        """

        # -------------------------------------------------------------- #
        #  Gather basic live info                                        #
        # -------------------------------------------------------------- #
        player_bets = round_state.player_bets or {}
        our_bet = player_bets.get(str(self.id), 0) or player_bets.get(self.id, 0) or 0
        to_call = max(round_state.current_bet - our_bet, 0)
        can_check = to_call == 0

        pot = max(round_state.pot, 1)  # avoid div-zero

        # -------------------------------------------------------------- #
        #  Choose target action depending on the street                  #
        # -------------------------------------------------------------- #
        if round_state.round == "Preflop":
            intended_action, amount = self._decide_preflop(
                to_call, round_state, remaining_chips
            )
        else:
            intended_action, amount = self._decide_postflop(
                to_call, round_state, remaining_chips, pot
            )

        # -------------------------------------------------------------- #
        #  Validate & downgrade if necessary                             #
        # -------------------------------------------------------------- #
        action, amount = self._ensure_legal_action(
            intended_action,
            amount,
            to_call,
            can_check,
            round_state,
            remaining_chips,
        )
        return action, amount

    # ------------------------------------------------------------------ #
    #  End-of-round / game hooks                                        #
    # ------------------------------------------------------------------ #
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.total_hands_played += 1
        self.total_chips_won = remaining_chips - self.starting_chips

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # currently unused

    # ================================================================== #
    #  ---  Internal helper methods below here  ---                      #
    # ================================================================== #

    # --------------------------- Pre-flop ----------------------------- #
    def _decide_preflop(
        self,
        to_call: int,
        rs: RoundStateClient,
        stack: int,
    ) -> Tuple[PokerAction, int]:
        """
        Very small pre-flop lookup strategy using the pre-computed tiers.
        """
        hand_key = self._canonical_hand_key(self.hole_cards)
        tier = self.preflop_tiers.get(hand_key, 5)

        # default fallback amounts
        min_raise = rs.min_raise
        max_raise = rs.max_raise

        # simple tiered action logic
        if tier == 1:
            # Premium – willing to 4-bet / shove
            if to_call == 0:
                raise_amt = self._cap_bet(int(4 * min_raise), min_raise, max_raise)
                return PokerAction.RAISE, raise_amt
            elif to_call < max(0.2 * stack, 10 * self.blind_amount):
                # reraise big or jam
                if max_raise <= stack * 0.5:
                    return PokerAction.ALL_IN, 0
                raise_amt = self._cap_bet(int(stack * 0.5), min_raise, max_raise)
                return PokerAction.RAISE, raise_amt
            else:
                return PokerAction.ALL_IN, 0

        elif tier == 2:
            # Very good – open or call small, else 3-bet small
            if to_call == 0:
                raise_amt = self._cap_bet(int(3 * min_raise), min_raise, max_raise)
                return PokerAction.RAISE, raise_amt
            elif to_call <= max(self.blind_amount * 3, stack * 0.1):
                if random.random() < 0.5:  # sometimes just call
                    return PokerAction.CALL, 0
                raise_amt = self._cap_bet(int(2.5 * to_call), min_raise, max_raise)
                return PokerAction.RAISE, raise_amt
            else:
                return PokerAction.FOLD, 0

        elif tier == 3:
            # Medium strength – open or over-limp, avoid big pots
            if to_call == 0:
                # open-limp 50% otherwise small raise
                if random.random() < 0.5:
                    return PokerAction.CHECK, 0
                raise_amt = self._cap_bet(int(2.5 * min_raise), min_raise, max_raise)
                return PokerAction.RAISE, raise_amt
            elif to_call <= max(self.blind_amount * 2, stack * 0.05):
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # weak: play only if free
            if to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    # --------------------------- Post-flop ---------------------------- #
    def _decide_postflop(
        self,
        to_call: int,
        rs: RoundStateClient,
        stack: int,
        pot: int,
    ) -> Tuple[PokerAction, int]:
        strength = self._evaluate_made_hand(rs.community_cards + self.hole_cards)

        min_raise = rs.min_raise
        max_raise = rs.max_raise
        can_check = to_call == 0

        # threshold-based action
        if strength >= 6:  # full house or better
            # try to get money in
            if to_call >= stack:  # someone is all-in
                return PokerAction.CALL, 0
            raise_amt = self._cap_bet(max_raise, min_raise, max_raise)
            return PokerAction.RAISE, raise_amt if raise_amt < stack else 0

        elif strength == 5 or strength == 4:  # flush or straight
            if to_call <= pot * 0.6:
                if to_call == 0:
                    raise_amt = self._cap_bet(int(pot * 0.75), min_raise, max_raise)
                    return PokerAction.RAISE, raise_amt
                else:
                    return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        elif strength == 3:  # trips
            if to_call <= pot * 0.4:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        elif strength == 2:  # two pair
            if to_call == 0:
                # small value bet
                raise_amt = self._cap_bet(int(pot * 0.45), min_raise, max_raise)
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
                return PokerAction.CHECK, 0
            elif to_call <= pot * 0.25:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        elif strength == 1:  # single pair
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= pot * 0.15:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        else:  # high card / air
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    # -------------------- Hand strength evaluation ------------------- #
    def _evaluate_made_hand(self, cards: List[str]) -> int:
        """
        VERY light-weight made-hand classification:
        0 - high-card, 1-pair, 2-two-pair, 3-trips, 4-straight,
        5 - flush, 6-full-house, 7-quads, 8-straight-flush
        """
        if len(cards) < 5:
            return 0

        ranks = [card_rank(c) for c in cards]
        suits = [card_suit(c) for c in cards]
        rank_counter = Counter(ranks)
        suit_counter = Counter(suits)

        is_flush = any(cnt >= 5 for cnt in suit_counter.values())
        is_straight = self._has_straight(set(ranks))

        most_common = rank_counter.most_common()

        if is_flush and is_straight:
            return 8
        if most_common[0][1] == 4:
            return 7  # quads
        if most_common[0][1] == 3 and most_common[1][1] >= 2:
            return 6  # full house
        if is_flush:
            return 5
        if is_straight:
            return 4
        if most_common[0][1] == 3:
            return 3  # trips
        if most_common[0][1] == 2 and most_common[1][1] == 2:
            return 2  # two pair
        if most_common[0][1] == 2:
            return 1  # one pair
        return 0  # high card

    @staticmethod
    def _has_straight(unique_ranks: set[int]) -> bool:
        """Wheel (A-5) supported."""
        ordered = sorted(unique_ranks)
        if 14 in ordered:  # if Ace present include low-Ace for wheel
            ordered = [1] + ordered
        # sliding window of consecutive ranks
        consecutive = 0
        last_rank = None
        for r in ordered:
            if last_rank is None or r == last_rank + 1:
                consecutive += 1
                if consecutive >= 5:
                    return True
            elif r != last_rank:
                consecutive = 1
            last_rank = r
        return False

    # -------------------- Utility / Validation ----------------------- #
    @staticmethod
    def _cap_bet(target: int, min_raise: int, max_raise: int) -> int:
        """Ensure target falls inside allowed raise range."""
        return max(min(target, max_raise), min_raise)

    def _ensure_legal_action(
        self,
        action: PokerAction,
        amount: int,
        to_call: int,
        can_check: bool,
        rs: RoundStateClient,
        stack: int,
    ) -> Tuple[PokerAction, int]:
        """Downgrade actions until they are unquestionably legal."""
        min_raise = rs.min_raise
        max_raise = rs.max_raise

        # Validate the intended action
        if action == PokerAction.RAISE:
            if amount < min_raise or amount > max_raise or amount > stack:
                # cannot raise – fall back
                action = PokerAction.CALL if to_call <= stack else PokerAction.FOLD
                amount = 0

        if action == PokerAction.CALL and to_call > stack:
            action = PokerAction.ALL_IN  # calling for rest
        if action == PokerAction.CALL and to_call == 0:
            action = PokerAction.CHECK
        if action == PokerAction.CHECK and not can_check:
            # not allowed to check
            action = PokerAction.CALL if to_call <= stack else PokerAction.FOLD
        if action == PokerAction.ALL_IN and stack <= 0:
            action = PokerAction.FOLD

        # Final safety guard
        if action == PokerAction.RAISE and (amount < min_raise or amount > max_raise):
            action = PokerAction.CALL if to_call <= stack else PokerAction.FOLD
            amount = 0
        if action in (PokerAction.CALL, PokerAction.ALL_IN) and stack <= 0:
            action = PokerAction.FOLD

        return action, amount

    # -------------------- Pre-flop tiers ----------------------------- #
    def _init_preflop_tiers(self):
        """
        A very small handcrafted tier list.
        Tier1: AA, KK, QQ, JJ, AKs
        Tier2: TT, AQs, AKo, KQs
        Tier3: 99-77, ATs-AJs, KJs, QJs, JTs, T9s, 87s
        """
        self.preflop_tiers: Dict[str, int] = {}
        # tier 1
        for pair in ["AA", "KK", "QQ", "JJ"]:
            self.preflop_tiers[pair] = 1
        self.preflop_tiers["AKs"] = 1

        # tier 2
        for h in ["TT", "AQs", "AKo", "KQs"]:
            self.preflop_tiers[h] = 2

        # tier 3
        for pair in ["99", "88", "77"]:
            self.preflop_tiers[pair] = 3
        for suited in ["ATs", "AJs", "KJs", "QJs", "JTs", "T9s", "87s"]:
            self.preflop_tiers[suited] = 3

    # -------------------- Hand key conversion ------------------------ #
    @staticmethod
    def _canonical_hand_key(hole_cards: List[str]) -> str:
        """
        Convert two hole cards into a canonical key like 'AKs', '77', 'QTo'.
        """
        if len(hole_cards) != 2:
            return ""
        r1, s1 = hole_cards[0][0], hole_cards[0][1]
        r2, s2 = hole_cards[1][0], hole_cards[1][1]

        if RANK_VALUE[r1] < RANK_VALUE[r2]:
            r1, r2 = r2, r1  # make r1 the higher rank

        if r1 == r2:
            return f"{r1}{r2}"  # pocket pair
        suited = "s" if s1 == s2 else "o"
        return f"{r1}{r2}{suited}"