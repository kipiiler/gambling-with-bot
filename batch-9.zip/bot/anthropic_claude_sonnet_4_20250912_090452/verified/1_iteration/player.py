from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.opponent_stats = {}
        self.round_history = []
        self.position_advantage = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[str(player_id)] = {
                    'vpip': 0.5,  # Voluntarily put money in pot
                    'pfr': 0.3,   # Pre-flop raise
                    'aggression': 0.5,
                    'hands_seen': 0,
                    'voluntary_actions': 0,
                    'raises': 0,
                    'calls': 0,
                    'folds': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._calculate_hand_strength(round_state)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Update opponent stats
            self._update_opponent_stats(round_state)
            
            # Calculate position advantage
            self._calculate_position(round_state)
            
            # Get number of active players
            active_players = len([p for p in round_state.current_player if p != self.id])
            
            # Calculate betting action
            action, amount = self._decide_action(round_state, remaining_chips, hand_strength, pot_odds, active_players)
            
            return action, amount
            
        except Exception as e:
            # Fallback to safe action
            if round_state.current_bet == 0:
                return PokerAction.CHECK, 0
            elif round_state.current_bet <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate hand strength based on hole cards and community cards"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        val1 = rank_values.get(rank1, int(rank1))
        val2 = rank_values.get(rank2, int(rank2))
        
        # Base strength from pocket cards
        if val1 == val2:  # Pocket pair
            if val1 >= 10:
                strength = 0.8 + (val1 - 10) * 0.05
            else:
                strength = 0.4 + (val1 - 2) * 0.05
        elif abs(val1 - val2) <= 1:  # Connected cards
            avg_val = (val1 + val2) / 2.0
            strength = 0.3 + (avg_val - 7) * 0.03
            if suit1 == suit2:  # Suited
                strength += 0.1
        elif max(val1, val2) >= 12:  # High card
            strength = 0.2 + (max(val1, val2) - 12) * 0.1
            if suit1 == suit2:
                strength += 0.05
        else:
            strength = 0.1 + (max(val1, val2) - 2) * 0.02
            
        # Adjust based on community cards
        if round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
            
        return min(max(strength, 0.0), 1.0)

    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        if not community_cards:
            return base_strength
            
        # Simple adjustment - look for pairs, flushes, straights
        all_cards = self.hole_cards + community_cards
        
        # Count ranks and suits
        ranks = {}
        suits = {}
        
        for card in all_cards:
            rank, suit = card[0], card[1]
            rank_val = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}.get(rank, int(rank))
            ranks[rank_val] = ranks.get(rank_val, 0) + 1
            suits[suit] = suits.get(suit, 0) + 1
            
        # Check for pairs, trips, quads
        max_rank_count = max(ranks.values()) if ranks else 1
        if max_rank_count == 4:
            return 0.95
        elif max_rank_count == 3:
            return 0.85
        elif max_rank_count == 2:
            pairs = sum(1 for count in ranks.values() if count == 2)
            if pairs >= 2:
                return 0.75
            else:
                return base_strength + 0.2
                
        # Check for flush potential
        max_suit_count = max(suits.values()) if suits else 1
        if max_suit_count >= 5:
            return 0.8
        elif max_suit_count >= 4:
            return base_strength + 0.15
            
        # Check for straight potential
        sorted_ranks = sorted(ranks.keys())
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                    return 0.75
                    
        return base_strength

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return 1.0
        if call_amount > remaining_chips:
            call_amount = remaining_chips
            
        total_pot = round_state.pot + call_amount
        if total_pot == 0:
            return 0.0
            
        return call_amount / (total_pot + 1e-6)

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics based on their actions"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                stats['hands_seen'] += 1
                
                if action in ['Call', 'Raise', 'All_in']:
                    stats['voluntary_actions'] += 1
                elif action == 'Raise':
                    stats['raises'] += 1
                elif action == 'Call':
                    stats['calls'] += 1
                elif action == 'Fold':
                    stats['folds'] += 1
                    
                # Update VPIP and PFR
                if stats['hands_seen'] > 0:
                    stats['vpip'] = stats['voluntary_actions'] / stats['hands_seen']
                    stats['pfr'] = stats['raises'] / stats['hands_seen']
                    if stats['calls'] + stats['raises'] > 0:
                        stats['aggression'] = stats['raises'] / (stats['calls'] + stats['raises'])

    def _calculate_position(self, round_state: RoundStateClient):
        """Calculate position advantage"""
        if len(round_state.current_player) <= 1:
            self.position_advantage = 0
            return
            
        my_position = -1
        for i, player_id in enumerate(round_state.current_player):
            if player_id == self.id:
                my_position = i
                break
                
        if my_position == -1:
            self.position_advantage = 0
        else:
            # Later position is better
            self.position_advantage = my_position / max(len(round_state.current_player) - 1, 1)

    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, active_players: int) -> Tuple[PokerAction, int]:
        """Decide on the action to take"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        # Adjust hand strength based on position and opponents
        adjusted_strength = hand_strength
        
        # Position adjustment
        adjusted_strength += self.position_advantage * 0.1
        
        # Player count adjustment - tighten up with more players
        if active_players > 3:
            adjusted_strength -= 0.1
        elif active_players == 1:  # Heads up
            adjusted_strength += 0.15
            
        # Opponent aggression adjustment
        avg_aggression = 0.5
        if self.opponent_stats:
            aggressions = [stats['aggression'] for stats in self.opponent_stats.values()]
            if aggressions:
                avg_aggression = sum(aggressions) / len(aggressions)
                
        if avg_aggression > 0.7:  # Very aggressive opponents
            adjusted_strength -= 0.1
        elif avg_aggression < 0.3:  # Passive opponents
            adjusted_strength += 0.1
            
        # Determine action based on adjusted strength
        if call_amount == 0:  # Can check
            if adjusted_strength > 0.6:
                # Strong hand - consider betting
                bet_size = min(round_state.pot // 2, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            elif adjusted_strength > 0.3:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
                
        else:  # Need to call or raise
            if call_amount > remaining_chips:
                # Must go all-in to call
                if adjusted_strength > 0.7:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
                    
            # Calculate call threshold based on pot odds and hand strength
            call_threshold = max(0.2, pot_odds * 1.5)
            
            if adjusted_strength > 0.8:  # Very strong hand
                if remaining_chips <= round_state.pot:  # Good spot to go all-in
                    return PokerAction.ALL_IN, 0
                else:
                    raise_size = min(round_state.pot, remaining_chips - call_amount)
                    if call_amount + raise_size >= round_state.min_raise:
                        return PokerAction.RAISE, call_amount + raise_size
                    else:
                        return PokerAction.CALL, 0
                        
            elif adjusted_strength > 0.6:  # Strong hand
                if call_amount <= round_state.pot // 4:  # Small bet
                    raise_size = min(round_state.pot // 2, remaining_chips - call_amount)
                    if call_amount + raise_size >= round_state.min_raise:
                        return PokerAction.RAISE, call_amount + raise_size
                    else:
                        return PokerAction.CALL, 0
                else:
                    return PokerAction.CALL, 0
                    
            elif adjusted_strength > call_threshold:  # Decent hand
                if call_amount <= remaining_chips // 10:  # Small price
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
            else:  # Weak hand
                if pot_odds < 0.2 and call_amount <= remaining_chips // 20:  # Very cheap call
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round"""
        self.round_history.append({
            'round_num': round_state.round_num,
            'final_chips': remaining_chips,
            'pot': round_state.pot
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        pass