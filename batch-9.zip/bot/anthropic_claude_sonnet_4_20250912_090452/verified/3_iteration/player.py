from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_history = []
        self.opponent_aggression = 0.5
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds and bet sizing
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_size = round_state.pot
        
        # Avoid division by zero
        pot_odds = call_amount / max(pot_size + call_amount, 1)
        
        # Position and opponent analysis
        position_factor = self._analyze_position(round_state)
        opponent_factor = self._analyze_opponent_behavior(round_state)
        
        # Dynamic strategy based on stack size
        stack_factor = remaining_chips / max(self.starting_chips, 1)
        
        # Adjust aggression based on game state
        base_aggression = 0.4 + (0.3 * position_factor) + (0.2 * stack_factor)
        
        # Decision logic
        if round_state.current_bet == 0:
            # No bet to us - we can check or bet
            if hand_strength >= 0.7:
                # Strong hand - bet for value
                bet_size = min(int(pot_size * 0.8), round_state.max_raise)
                bet_size = max(bet_size, round_state.min_raise)
                return (PokerAction.RAISE, bet_size)
            elif hand_strength >= 0.4 and base_aggression > 0.6:
                # Semi-bluff or position bet
                bet_size = min(int(pot_size * 0.5), round_state.max_raise)
                bet_size = max(bet_size, round_state.min_raise)
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to us
            if call_amount >= remaining_chips:
                # All-in situation
                if hand_strength >= 0.6:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Calculate effective pot odds threshold
            threshold = max(0.3, pot_odds * 1.2)
            
            if hand_strength >= 0.8:
                # Very strong hand - raise
                raise_size = min(call_amount + int(pot_size * 0.8), round_state.max_raise)
                raise_size = max(raise_size, round_state.min_raise)
                return (PokerAction.RAISE, raise_size)
            elif hand_strength >= threshold:
                # Good enough to call
                return (PokerAction.CALL, 0)
            elif hand_strength >= 0.25 and pot_odds < 0.2 and base_aggression > 0.7:
                # Bluff attempt
                bluff_size = min(int(pot_size * 1.2), round_state.max_raise)
                bluff_size = max(bluff_size, round_state.min_raise)
                return (PokerAction.RAISE, bluff_size)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        # Parse cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
            
        val1 = rank_values.get(rank1, 7)
        val2 = rank_values.get(rank2, 7)
        
        # Base hand strength
        if rank1 == rank2:  # Pocket pair
            if val1 >= 10:
                strength = 0.85  # High pair
            elif val1 >= 7:
                strength = 0.65  # Medium pair
            else:
                strength = 0.45  # Low pair
        elif suit1 == suit2:  # Suited
            if abs(val1 - val2) <= 4 and min(val1, val2) >= 7:
                strength = 0.7  # Suited connectors/high cards
            elif max(val1, val2) >= 12:
                strength = 0.6  # High suited cards
            else:
                strength = 0.4  # Low suited
        else:  # Offsuit
            if max(val1, val2) >= 12 and min(val1, val2) >= 10:
                strength = 0.65  # High cards
            elif max(val1, val2) >= 11:
                strength = 0.45  # One high card
            else:
                strength = 0.25  # Low cards
        
        # Adjust for board texture and round
        if round_state.community_cards:
            strength = self._adjust_for_board(strength, round_state.community_cards)
            
        return min(1.0, max(0.0, strength))
    
    def _adjust_for_board(self, base_strength: float, community_cards: List[str]) -> float:
        if not community_cards:
            return base_strength
            
        # Simple board texture analysis
        board_size = len(community_cards)
        
        # More conservative on dangerous boards
        if board_size >= 3:
            # Check for flush/straight possibilities
            suits = [card[1] for card in community_cards]
            ranks = [card[0] for card in community_cards]
            
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
                
            # Flush draw possible
            if max(suit_counts.values()) >= 2:
                base_strength *= 0.9
                
            # Straight possibilities (simplified)
            if board_size >= 3 and len(set(ranks)) >= 2:
                base_strength *= 0.95
                
        return base_strength
    
    def _analyze_position(self, round_state: RoundStateClient) -> float:
        # Simple position analysis - in heads up, position alternates
        num_players = len(round_state.current_player) if round_state.current_player else 2
        if num_players <= 2:
            return 0.6  # Heads up position is less critical
        return 0.5
    
    def _analyze_opponent_behavior(self, round_state: RoundStateClient) -> float:
        # Track opponent aggression over time
        aggressive_actions = 0
        total_actions = 0
        
        for action in round_state.player_actions.values():
            if action in ['Raise', 'All-in']:
                aggressive_actions += 1
            total_actions += 1
            
        if total_actions > 0:
            self.opponent_aggression = aggressive_actions / total_actions
            
        return self.opponent_aggression
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        # Track game history for learning
        self.game_history.append({
            'final_pot': round_state.pot,
            'remaining_chips': remaining_chips,
            'community_cards': round_state.community_cards.copy() if round_state.community_cards else []
        })
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hands_played = 0
        self.opponent_aggression = 0.5