from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.current_bet = 0
        self.opponent_actions = []
        self.game_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_bet = 0
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Get pot odds and betting context
            pot_size = round_state.pot
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            
            # Analyze opponent behavior
            aggression_level = self._analyze_opponent_aggression(round_state)
            
            # Decision logic based on hand strength and situation
            if hand_strength >= 0.8:  # Very strong hand
                return self._play_strong_hand(round_state, remaining_chips, call_amount, pot_size)
            elif hand_strength >= 0.6:  # Good hand
                return self._play_good_hand(round_state, remaining_chips, call_amount, pot_size, aggression_level)
            elif hand_strength >= 0.4:  # Marginal hand
                return self._play_marginal_hand(round_state, remaining_chips, call_amount, pot_size, aggression_level)
            else:  # Weak hand
                return self._play_weak_hand(round_state, remaining_chips, call_amount, pot_size)
                
        except Exception as e:
            # Fallback to safe action
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.1:  # Only call if it's less than 10% of stack
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        if not self.hole_cards:
            return 0.3
            
        # Card values for evaluation
        card_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Parse hole cards
        card1_rank = self.hole_cards[0][0]
        card1_suit = self.hole_cards[0][1]
        card2_rank = self.hole_cards[1][0]
        card2_suit = self.hole_cards[1][1]
        
        card1_val = card_values.get(card1_rank, 7)
        card2_val = card_values.get(card2_rank, 7)
        
        strength = 0.0
        
        # Pair evaluation
        if card1_rank == card2_rank:
            if card1_val >= 10:  # High pairs (TT+)
                strength = 0.9
            elif card1_val >= 7:  # Medium pairs (77-99)
                strength = 0.7
            else:  # Low pairs
                strength = 0.5
        else:
            # High cards
            high_card = max(card1_val, card2_val)
            low_card = min(card1_val, card2_val)
            
            if high_card == 14:  # Ace
                if low_card >= 10:  # AK, AQ, AJ, AT
                    strength = 0.85
                elif low_card >= 7:  # A7-A9
                    strength = 0.6
                else:  # A2-A6
                    strength = 0.45
            elif high_card >= 13:  # King
                if low_card >= 10:  # KQ, KJ, KT
                    strength = 0.75
                elif low_card >= 7:  # K7-K9
                    strength = 0.5
                else:
                    strength = 0.3
            elif high_card >= 11:  # Queen or Jack
                if low_card >= 9:  # QJ, QT, JT
                    strength = 0.65
                else:
                    strength = 0.35
            else:
                strength = 0.25
            
            # Suited bonus
            if card1_suit == card2_suit:
                strength += 0.1
                
            # Connected cards bonus
            if abs(card1_val - card2_val) == 1:
                strength += 0.05
        
        # Adjust based on community cards if available
        if round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
            
        return min(1.0, strength)

    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        # Simple adjustment - if we have many community cards, be more conservative
        if len(community_cards) >= 4:  # Turn or River
            return base_strength * 0.9  # Slightly more conservative
        elif len(community_cards) == 3:  # Flop
            return base_strength * 0.95
        return base_strength

    def _analyze_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Analyze opponent's aggression level"""
        aggressive_actions = 0
        total_actions = 0
        
        for player_id, action in round_state.player_actions.items():
            if int(player_id) != self.id:
                total_actions += 1
                if action in ['Raise', 'All-in']:
                    aggressive_actions += 2
                elif action == 'Bet':
                    aggressive_actions += 1
                    
        if total_actions == 0:
            return 0.5
        return min(1.0, aggressive_actions / (total_actions + 0.001))

    def _play_strong_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int) -> Tuple[PokerAction, int]:
        """Play strategy for strong hands"""
        if call_amount == 0:
            # No bet to call, make a value bet
            bet_size = max(round_state.min_raise, min(pot_size // 2, remaining_chips // 4))
            if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 2:
            # Good pot odds with strong hand
            if remaining_chips > call_amount * 3:
                # Raise for value
                raise_size = max(round_state.min_raise, min(call_amount * 2, remaining_chips // 3))
                if raise_size <= remaining_chips and raise_size >= round_state.min_raise:
                    total_bet = round_state.player_bets.get(str(self.id), 0) + raise_size
                    if total_bet <= remaining_chips:
                        return (PokerAction.RAISE, raise_size)
            return (PokerAction.CALL, 0)
        else:
            # Big bet, but strong hand
            return (PokerAction.CALL, 0) if call_amount <= remaining_chips else (PokerAction.FOLD, 0)

    def _play_good_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int, aggression: float) -> Tuple[PokerAction, int]:
        """Play strategy for good hands"""
        if call_amount == 0:
            if aggression < 0.5:  # Opponent not aggressive
                bet_size = max(round_state.min_raise, min(pot_size // 3, remaining_chips // 6))
                if bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 4:
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips // 2 and aggression < 0.7:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _play_marginal_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int, aggression: float) -> Tuple[PokerAction, int]:
        """Play strategy for marginal hands"""
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 10 and aggression < 0.5:
            return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips // 8 and pot_size > call_amount * 3:
            # Good pot odds
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def _play_weak_hand(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int, pot_size: int) -> Tuple[PokerAction, int]:
        """Play strategy for weak hands"""
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount <= remaining_chips // 20 and pot_size > call_amount * 5:
            # Very good pot odds
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Store game history for learning
        self.game_history.append({
            'final_chips': remaining_chips,
            'community_cards': round_state.community_cards,
            'pot': round_state.pot
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        # Could implement learning from game results here
        pass