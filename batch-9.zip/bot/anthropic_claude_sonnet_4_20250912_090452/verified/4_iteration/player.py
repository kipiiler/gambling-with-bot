from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.blind_amount = 0
        self.opponents = []
        self.position = ""
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.opponents = [p for p in all_players if p != self.id]
        
        # Determine position
        if self.id == big_blind_player_id:
            self.position = "big_blind"
        elif self.id == small_blind_player_id:
            self.position = "small_blind"
        else:
            self.position = "normal"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Get hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds if facing a bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            pot_odds = call_amount / (round_state.pot + call_amount + 0.01)  # Avoid division by zero
            
            # Aggressive strategy based on hand strength
            if hand_strength >= 0.8:  # Very strong hand
                if call_amount == 0:  # No bet to call
                    # Strong bet
                    raise_amount = max(round_state.min_raise, round_state.pot // 2)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    if raise_amount > 0:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:  # Facing a bet
                    if call_amount <= remaining_chips:
                        # Raise aggressively
                        raise_amount = max(round_state.min_raise, call_amount * 2)
                        raise_amount = min(raise_amount, round_state.max_raise)
                        if raise_amount > 0:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                        
            elif hand_strength >= 0.6:  # Good hand
                if call_amount == 0:  # No bet to call
                    # Moderate bet
                    raise_amount = max(round_state.min_raise, round_state.pot // 3)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    if raise_amount > 0 and raise_amount <= remaining_chips // 4:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:  # Facing a bet
                    if pot_odds < 0.3 and call_amount <= remaining_chips // 3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            elif hand_strength >= 0.4:  # Decent hand
                if call_amount == 0:  # No bet to call
                    return (PokerAction.CHECK, 0)
                else:  # Facing a bet
                    if pot_odds < 0.2 and call_amount <= remaining_chips // 6:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            else:  # Weak hand
                if call_amount == 0:  # No bet to call
                    # Occasional bluff
                    if round_state.round in ["Turn", "River"] and hash(str(self.hole_cards)) % 10 == 0:
                        raise_amount = max(round_state.min_raise, round_state.pot // 4)
                        raise_amount = min(raise_amount, round_state.max_raise)
                        if raise_amount > 0 and raise_amount <= remaining_chips // 8:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CHECK, 0)
                else:  # Facing a bet
                    return (PokerAction.FOLD, 0)
                    
        except Exception:
            # Fallback: conservative play
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 10:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        try:
            if not self.hole_cards or len(self.hole_cards) != 2:
                return 0.3
            
            card1, card2 = self.hole_cards
            rank1, suit1 = self._parse_card(card1)
            rank2, suit2 = self._parse_card(card2)
            
            # Rank values: 2=2, 3=3, ..., T=10, J=11, Q=12, K=13, A=14
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                          '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            
            val1 = rank_values.get(rank1, 7)
            val2 = rank_values.get(rank2, 7)
            
            # Base strength calculation
            high_card = max(val1, val2)
            low_card = min(val1, val2)
            
            # Pocket pairs
            if val1 == val2:
                if val1 >= 10:  # TT, JJ, QQ, KK, AA
                    base_strength = 0.8 + (val1 - 10) * 0.04
                elif val1 >= 7:  # 77, 88, 99
                    base_strength = 0.6 + (val1 - 7) * 0.067
                else:  # 22-66
                    base_strength = 0.4 + (val1 - 2) * 0.04
            else:
                # Non-pairs
                if high_card == 14:  # Ace high
                    if low_card >= 10:  # AK, AQ, AJ, AT
                        base_strength = 0.7 + (low_card - 10) * 0.05
                    elif low_card >= 7:  # A9, A8, A7
                        base_strength = 0.5 + (low_card - 7) * 0.067
                    else:  # A6 and below
                        base_strength = 0.4 + (low_card - 2) * 0.02
                elif high_card >= 13:  # King high
                    if low_card >= 10:  # KQ, KJ, KT
                        base_strength = 0.6 + (low_card - 10) * 0.033
                    else:
                        base_strength = 0.3 + (low_card - 2) * 0.025
                elif high_card >= 11:  # Queen/Jack high
                    if low_card >= 9:
                        base_strength = 0.5 + (low_card - 9) * 0.05
                    else:
                        base_strength = 0.25 + (low_card - 2) * 0.02
                else:  # Lower cards
                    base_strength = 0.1 + (high_card - 2) * 0.02
            
            # Suited bonus
            if suit1 == suit2:
                base_strength += 0.05
            
            # Connected cards bonus (straight potential)
            if abs(val1 - val2) == 1:
                base_strength += 0.03
            elif abs(val1 - val2) == 2:
                base_strength += 0.02
            
            # Post-flop adjustments
            if round_state.community_cards:
                community_strength = self._evaluate_with_community(round_state.community_cards)
                base_strength = (base_strength + community_strength) / 2
            
            return min(max(base_strength, 0.0), 1.0)
            
        except Exception:
            return 0.3
    
    def _parse_card(self, card: str) -> Tuple[str, str]:
        """Parse card string like 'Ah' into rank and suit"""
        if len(card) >= 2:
            return card[0], card[1]
        return '7', 'h'  # Default fallback
    
    def _evaluate_with_community(self, community_cards: List[str]) -> float:
        """Basic evaluation with community cards"""
        try:
            if not community_cards:
                return 0.5
            
            all_cards = self.hole_cards + community_cards
            ranks = []
            suits = []
            
            for card in all_cards:
                rank, suit = self._parse_card(card)
                ranks.append(rank)
                suits.append(suit)
            
            # Count ranks and suits
            rank_counts = {}
            suit_counts = {}
            
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            # Check for made hands
            max_rank_count = max(rank_counts.values()) if rank_counts else 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 1
            
            if max_rank_count >= 4:  # Four of a kind
                return 0.95
            elif max_rank_count == 3:  # Three of a kind or full house
                if len([c for c in rank_counts.values() if c >= 2]) >= 2:
                    return 0.9  # Full house
                else:
                    return 0.75  # Three of a kind
            elif max_suit_count >= 5:  # Flush
                return 0.8
            elif max_rank_count == 2:  # Pair or two pair
                pair_count = len([c for c in rank_counts.values() if c == 2])
                if pair_count >= 2:
                    return 0.65  # Two pair
                else:
                    return 0.5   # One pair
            else:
                return 0.3  # High card
                
        except Exception:
            return 0.4

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass