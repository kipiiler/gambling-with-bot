from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.num_players = 0
        self.opponent_tendencies = {}
        self.hand_history = []
        self.blind_amount = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.num_players = len(all_players)
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 0  # Small blind
        elif self.id == big_blind_player_id:
            self.position = 1  # Big blind
        else:
            # Calculate position relative to blinds
            my_index = all_players.index(self.id)
            bb_index = all_players.index(big_blind_player_id)
            self.position = (my_index - bb_index - 1) % len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds and position factor
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        position_factor = self._get_position_factor()
        
        # Determine aggression level based on hand strength and position
        aggression_threshold = self._get_aggression_threshold(hand_strength, position_factor, round_state)
        
        # Calculate call amount needed
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # If no bet to call, consider checking or betting
        if call_amount <= 0:
            if hand_strength >= 0.7:  # Strong hand - bet for value
                bet_size = self._calculate_bet_size(round_state, remaining_chips, hand_strength)
                if bet_size >= round_state.min_raise and bet_size <= round_state.max_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength >= 0.4 and position_factor > 0.5:  # Medium hand in good position - consider betting
                if self._should_bluff(round_state, hand_strength):
                    bet_size = min(round_state.pot // 2, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # If there's a bet to call
        if hand_strength >= aggression_threshold:
            if hand_strength >= 0.8:  # Very strong hand - raise
                raise_size = self._calculate_raise_size(round_state, remaining_chips, hand_strength)
                if raise_size >= round_state.min_raise and raise_size <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength >= 0.6:  # Good hand - call or raise
                if self._should_raise(round_state, hand_strength, pot_odds):
                    raise_size = self._calculate_raise_size(round_state, remaining_chips, hand_strength)
                    if raise_size >= round_state.min_raise and raise_size <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
            else:  # Marginal hand - call if pot odds are good
                if pot_odds > 2.0:  # Good pot odds
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Weak hand - fold unless great pot odds
            if pot_odds > 4.0 and call_amount < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.hole_cards:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert face cards to numbers
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 7), rank_values.get(rank2, 7)
        is_suited = suit1 == suit2
        is_pair = val1 == val2
        
        # Pre-flop evaluation
        if round_state.round == 'Preflop':
            # Premium pairs
            if is_pair and val1 >= 10:
                return 0.9 + (val1 - 10) * 0.02
            # Good pairs
            elif is_pair and val1 >= 7:
                return 0.7 + (val1 - 7) * 0.05
            # Small pairs
            elif is_pair:
                return 0.5 + (val1 - 2) * 0.03
            # High cards
            elif val1 >= 12 and val2 >= 12:  # AK, AQ, KQ
                return 0.8 + (0.02 if is_suited else 0.0)
            elif val1 >= 11 and val2 >= 11:  # AJ, KJ, QJ
                return 0.65 + (0.05 if is_suited else 0.0)
            elif max(val1, val2) == 14:  # Ace with medium card
                return 0.5 + min(val1, val2) * 0.02 + (0.05 if is_suited else 0.0)
            # Suited connectors
            elif is_suited and abs(val1 - val2) <= 2:
                return 0.45 + max(val1, val2) * 0.01
            # Connected cards
            elif abs(val1 - val2) <= 1:
                return 0.35 + max(val1, val2) * 0.01
            else:
                return 0.2 + max(val1, val2) * 0.01
        
        # Post-flop evaluation with community cards
        else:
            return self._evaluate_made_hand(round_state)
    
    def _evaluate_made_hand(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength with community cards"""
        if not round_state.community_cards or not self.hole_cards:
            return 0.3
            
        all_cards = self.hole_cards + round_state.community_cards
        hand_rank = self._get_hand_rank(all_cards)
        
        # Convert hand rank to strength (0.0 to 1.0)
        if hand_rank >= 8:  # Straight flush or better
            return 0.98
        elif hand_rank == 7:  # Four of a kind
            return 0.95
        elif hand_rank == 6:  # Full house
            return 0.9
        elif hand_rank == 5:  # Flush
            return 0.8
        elif hand_rank == 4:  # Straight
            return 0.75
        elif hand_rank == 3:  # Three of a kind
            return 0.65
        elif hand_rank == 2:  # Two pair
            return 0.5
        elif hand_rank == 1:  # One pair
            return 0.35
        else:  # High card
            return 0.2
    
    def _get_hand_rank(self, cards) -> int:
        """Get numerical rank of best 5-card hand (higher = better)"""
        if len(cards) < 5:
            return 0
            
        # Simple hand ranking - just check for basic patterns
        rank_counts = {}
        suit_counts = {}
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in cards:
            if len(card) >= 2:
                rank, suit = card[0], card[1]
                rank_val = rank_values.get(rank, 7)
                rank_counts[rank_val] = rank_counts.get(rank_val, 0) + 1
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        counts = sorted(rank_counts.values(), reverse=True)
        has_flush = max(suit_counts.values()) >= 5 if suit_counts else False
        
        # Check for straight (simplified)
        sorted_ranks = sorted(rank_counts.keys())
        has_straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                has_straight = True
                break
        
        # Hand rankings
        if has_flush and has_straight:
            return 8  # Straight flush
        elif counts[0] == 4:
            return 7  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 6  # Full house
        elif has_flush:
            return 5  # Flush
        elif has_straight:
            return 4  # Straight
        elif counts[0] == 3:
            return 3  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 2  # Two pair
        elif counts[0] == 2:
            return 1  # One pair
        else:
            return 0  # High card
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return float('inf')
        
        total_pot = round_state.pot + call_amount
        return total_pot / (call_amount + 0.001)  # Add small delta to avoid division by zero
    
    def _get_position_factor(self) -> float:
        """Get position advantage factor (0.0 to 1.0)"""
        if self.num_players <= 2:
            return 0.5
        
        # Later position is better
        return min(1.0, self.position / (self.num_players - 1 + 0.001))
    
    def _get_aggression_threshold(self, hand_strength: float, position_factor: float, round_state: RoundStateClient) -> float:
        """Calculate threshold for calling/raising based on situation"""
        base_threshold = 0.4
        
        # Adjust for position
        position_adjustment = (position_factor - 0.5) * 0.1
        
        # Adjust for betting round
        if round_state.round == 'Preflop':
            round_adjustment = 0.0
        elif round_state.round == 'Flop':
            round_adjustment = 0.05
        elif round_state.round == 'Turn':
            round_adjustment = 0.1
        else:  # River
            round_adjustment = 0.15
        
        return max(0.2, base_threshold - position_adjustment + round_adjustment)
    
    def _calculate_bet_size(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> int:
        """Calculate appropriate bet size"""
        pot_size = round_state.pot
        
        if hand_strength >= 0.8:  # Very strong hand
            bet_size = int(pot_size * 0.75)
        elif hand_strength >= 0.6:  # Good hand
            bet_size = int(pot_size * 0.5)
        else:  # Bluff or weak value bet
            bet_size = int(pot_size * 0.3)
        
        # Ensure bet is within valid range
        bet_size = max(bet_size, round_state.min_raise)
        bet_size = min(bet_size, round_state.max_raise)
        bet_size = min(bet_size, remaining_chips)
        
        return bet_size
    
    def _calculate_raise_size(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> int:
        """Calculate appropriate raise size"""
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        
        if hand_strength >= 0.8:  # Very strong hand
            raise_size = current_bet + int(pot_size * 0.8)
        elif hand_strength >= 0.6:  # Good hand
            raise_size = current_bet + int(pot_size * 0.5)
        else:  # Bluff raise
            raise_size = current_bet + int(pot_size * 0.3)
        
        # Ensure raise is within valid range
        raise_size = max(raise_size, round_state.min_raise)
        raise_size = min(raise_size, round_state.max_raise)
        raise_size = min(raise_size, remaining_chips)
        
        return raise_size
    
    def _should_bluff(self, round_state: RoundStateClient, hand_strength: float) -> bool:
        """Determine if we should bluff"""
        # Bluff occasionally with weak hands in good position
        if hand_strength < 0.3 and self._get_position_factor() > 0.6:
            return len(round_state.current_player) <= 2  # Only bluff heads-up or few players
        return False
    
    def _should_raise(self, round_state: RoundStateClient, hand_strength: float, pot_odds: float) -> bool:
        """Determine if we should raise instead of call"""
        # Raise with strong hands or good drawing hands with position
        if hand_strength >= 0.7:
            return True
        elif hand_strength >= 0.5 and self._get_position_factor() > 0.6:
            return True
        elif pot_odds > 3.0 and hand_strength >= 0.4:
            return True
        return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass