import random
from typing import List, Tuple, Dict, Any
import itertools
from collections import Counter
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards: List[str] = []
        self.players_in_hand: List[int] = []
        self.small_blind_amount: int = 0
        self.big_blind_amount: int = 0
        self.my_last_bet: int = 0
        self.starting_chips = 0
        self.player_id_str = ""

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands  # This seems to be the initial hole cards for the first round
        self.small_blind_amount = blind_amount
        self.big_blind_amount = blind_amount * 2
        self.players_in_hand = all_players  # All players at the table
        # self.id is inherited from Bot, which is set by the game runner.
        # However, the player IDs in round_state are strings, so we need to convert our ID to string for comparison
        self.player_id_str = str(self.id)
        self.my_last_bet = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[self.player_id_str] if self.player_id_str in round_state.player_hands else []
        self.players_in_hand = [int(p_id) for p_id in round_state.player_bets.keys()]
        self.my_last_bet = round_state.player_bets.get(self.player_id_str, 0)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        
        # Ensure our player_id is a string for consistent dictionary access
        player_id_str = str(self.id)
        
        # Handle cases where player_bets or player_hands might not contain our ID yet
        current_bet_in_round = round_state.player_bets.get(player_id_str, 0)
        
        # Ensure Hole cards are correctly updated for the current round
        self.hole_cards = round_state.player_hands[player_id_str] if player_id_str in round_state.player_hands else []

        # My current chips remaining
        my_chips = remaining_chips

        # Opponent's ID (assuming heads-up)
        # This will be more complex in multi-player, but for now assuming it's usually heads-up or small tables.
        other_players_ids = [p_id for p_id in round_state.current_player if str(p_id) != player_id_str]
        opponent_id = str(other_players_ids[0]) if other_players_ids else None
        
        # Calculate amount to call
        
        amount_to_call = max(0, round_state.current_bet - current_bet_in_round)
        
        # If opponent has gone all-in and we don't have enough chips to match, we can only go all-in or fold
        if opponent_id and round_state.player_bets.get(opponent_id, 0) >= my_chips + current_bet_in_round:
            if amount_to_call > my_chips:
                amount_to_call = my_chips

        
        # Pre-flop strategy (simplified for demonstration)
        if round_state.round == 'Preflop':
            hand_strength = self._evaluate_hand(self.hole_cards, [])
            
            # Aggressive play with strong hands
            if hand_strength >= 0.8:  # Very strong starting hands
                if amount_to_call == 0:  # No one bet yet, or we're big blind and it's checked around
                    return PokerAction.RAISE, min(my_chips, round_state.current_bet + self.big_blind_amount * 3)
                elif amount_to_call < my_chips / 4: # If it's a small raise
                    return PokerAction.RAISE, min(my_chips, round_state.current_bet + self.big_blind_amount * 2) 
                else: # Opponent made a significant raise, consider going All-in
                    return PokerAction.ALL_IN, 0
            # Moderate hands, call small bets or raise to test
            elif hand_strength >= 0.5: # Decent starting hands
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(my_chips, self.big_blind_amount * 2)
                elif amount_to_call <= self.big_blind_amount*2 or amount_to_call < my_chips / 10: # Call small raises
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            # Weak hands, fold unless we can check
            else:
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop strategy
        else:
            community_cards = round_state.community_cards
            all_cards = self.hole_cards + community_cards
            
            # Calculate hand strength based on community cards
            hand_strength = self._evaluate_hand(self.hole_cards, community_cards)
            
            # Aggressive play with strong hands (top 10-20% of hands)
            if hand_strength >= 0.8:
                if amount_to_call == 0:
                    # Value bet: bet a significant portion of the pot
                    bet_amount = min(my_chips, round_state.pot // 2 + round_state.current_bet)
                    # Ensure bet is at least min_raise if it's the first bet or responding to a check
                    if bet_amount < round_state.min_raise and round_state.min_raise <= my_chips:
                        return PokerAction.RAISE, round_state.min_raise
                    return PokerAction.RAISE, bet_amount
                else:
                    # Re-raise or go all-in
                    raise_amount = min(my_chips, round_state.current_bet + max(round_state.min_raise, round_state.pot))
                    if raise_amount > amount_to_call: # Only raise if we can make a valid raise
                        return PokerAction.RAISE, raise_amount
                    elif amount_to_call <= my_chips: # If we can't raise above opponent bet but can call
                        return PokerAction.CALL, 0
                    else: # Can't afford to call, must go all-in if confident or fold
                        return PokerAction.ALL_IN, 0 if my_chips > 0 else (PokerAction.FOLD, 0)
                        
            # Decent hands, call or make small bets
            elif hand_strength >= 0.5:
                if amount_to_call == 0:
                    # Small bet to extract value or check
                    return PokerAction.CHECK, 0
                else:
                    # Call if the bet is not too large compared to our chips
                    if amount_to_call < my_chips / 3 or amount_to_call <= round_state.pot / 3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            
            # Weak hands
            else:
                if amount_to_call == 0:
                    # Check if possible
                    return PokerAction.CHECK, 0
                else:
                    # Always fold if facing a bet with a weak hand
                    if amount_to_call <= my_chips:
                        return PokerAction.FOLD, 0
                    else:
                        return PokerAction.ALL_IN, 0 # We cannot afford to call so we go all in
                        
        
        # Fallback in case none of the above conditions met or special cases
        if amount_to_call == 0:
            return PokerAction.CHECK, 0
        elif amount_to_call < my_chips:  # Can call without going all-in
            return PokerAction.CALL, 0
        else:  # Cannot call without going all-in
            # If we've made it this far and are forced all-in and have a decent equity, or bluff
            # For now, just go all-in if we have any chips or fold
            if my_chips > 0:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_last_bet = 0  # Reset last bet for the new round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict,
                     active_players_hands: dict):
        pass

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Evaluates the strength of a poker hand based on hole cards and community cards.
        Returns a float between 0.0 (worst) and 1.0 (best).
        """
        all_possible_cards = self._get_rank_strength_map()
        
        # Convert cards to a standard format for evaluation
        def card_to_tuple(card_str: str) -> Tuple[str, str]:
            rank = card_str[:-1]
            suit = card_str[-1]
            return rank, suit

        # Convert to PokerHand format
        hand_obj = [card_to_tuple(c) for c in hole_cards]
        board_obj = [card_to_tuple(c) for c in community_cards]
        
        # Consider all 5-card combinations
        
        best_hand_rank = self._get_hand_rank_and_category(hand_obj, board_obj)
        
        
        # Need to simulate against random hands to get a true strength percentile
        # This is a simplified approach, a Monte Carlo simulation would be more accurate
        
        # For simplicity, let's just convert the hand rank directly to a 0-1 score
        # Hand ranks are typically 1 (high card) to 9 (straight flush)
        # We need a more granular ranking for a float output.
        # Let's map hand categories to approximate strength values.
        
        overall_hand_strength = self._get_overall_hand_strength(hole_cards, community_cards)
        
        return overall_hand_strength

    def _get_rank_strength_map(self) -> Dict[str, int]:
        ''' Ranks for cards for strength comparison'''
        # A, K, Q, J, T, 9, 8, 7, 6, 5, 4, 3, 2
        return {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10,
            'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
           
    def _evaluate_two_cards(self, cards: List[str]) -> float:
        """
        Evaluates the strength of a starting hand (two hole cards) based on common pre-flop heuristics.
        Returns a float between 0.0 and 1.0.
        """
        if not cards or len(cards) != 2:
            return 0.0

        rank_map = self._get_rank_strength_map()
        
        r1, s1 = cards[0][:-1], cards[0][-1]
        r2, s2 = cards[1][:-1], cards[1][-1]
        
        rank1 = rank_map[r1]
        rank2 = rank_map[r2]
        
        # Sort ranks to handle 'Ks Ad' same as 'Ad Ks'
        ranks = sorted([rank1, rank2], reverse=True)
        
        is_suited = (s1 == s2)
        is_pair = (rank1 == rank2)
        
        # Hand strength scoring (example, can be made more sophisticated)
        strength = 0.0
        
        # Pairs are strong
        if is_pair:
            if ranks[0] >= rank_map['A']: strength = 0.95
            elif ranks[0] >= rank_map['K']: strength = 0.90
            elif ranks[0] >= rank_map['Q']: strength = 0.85
            elif ranks[0] >= rank_map['J']: strength = 0.80
            elif ranks[0] >= rank_map['T']: strength = 0.75
            else: strength = 0.60 + (ranks[0] - 2) * 0.02 # Scale for smaller pairs

        # Suited connectors/high cards
        elif is_suited:
            if ranks[0] >= rank_map['A']: # Suited Ace-high
                if ranks[1] >= rank_map['T']: strength = 0.80
                else: strength = 0.65
            elif ranks[0] >= rank_map['K']: # Suited King-high
                if ranks[1] >= rank_map['J']: strength = 0.70
                else: strength = 0.55
            elif ranks[0] >= rank_map['Q']: # Suited Queen-high
                if ranks[1] >= rank_map['T']: strength = 0.60
                else: strength = 0.50
            elif ranks[0] - ranks[1] == 1: # Suited connectors
                if ranks[0] >= rank_map['J']: strength = 0.70
                else: strength = 0.55
            else: strength = 0.30

        # Unsuited high cards / connectors
        else:
            if ranks[0] >= rank_map['A'] and ranks[1] >= rank_map['Q']: strength = 0.75 # AQo, AKo
            elif ranks[0] >= rank_map['A'] and ranks[1] >= rank_map['J']: strength = 0.65
            elif ranks[0] >= rank_map['K'] and ranks[1] >= rank_map['Q']: strength = 0.60
            elif ranks[0] >= rank_map['A']: strength = 0.50 # Other unsuited A-high
            elif ranks[0] >= rank_map['K']: strength = 0.40 # Other unsuited K-high
            elif ranks[0] >= rank_map['Q']: strength = 0.30
            elif ranks[0] - ranks[1] == 1 and ranks[0] >= rank_map['J']: strength = 0.40
            else: strength = 0.10 # Junk

        return min(1.0, max(0.0, strength)) # Ensure bounding

    
    def _get_overall_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Simulates hand equity by comparing our hand against a range of random opponent hands.
        Returns the approximate equity (win probability).
        """
        if not hole_cards:
            return 0.0

        num_simulations = 50  # Number of random opponent hands to simulate
        num_wins = 0

        # All possible cards in a deck
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        suits = ['c', 'd', 'h', 's']
        # This creates a full deck of 52 cards (e.g., ['2c', '2d', ..., 'As'])
        full_deck = [rank + suit for rank in ranks for suit in suits]
        
        # Convert cards to a standard format for evaluation
        def card_to_tuple(card_str: str) -> Tuple[str, str]:
            rank = card_str[:-1]
            suit = card_str[-1]
            return rank, suit
        
        # Calculate our best hand given the community cards
        our_hand_rank, _ = self._get_hand_rank_and_category([card_to_tuple(c) for c in hole_cards], [card_to_tuple(c) for c in community_cards])

        # Remove our hole cards and community cards from the deck
        remaining_deck = [card for card in full_deck if card not in hole_cards and card not in community_cards]

        for _ in range(num_simulations):
            # Draw opponent's hole cards
            if len(remaining_deck) < 2: # Not enough cards to draw a hand
                break 
            
            opponent_hole_cards_str = random.sample(remaining_deck, 2)
            opponent_hole_cards_obj = [card_to_tuple(c) for c in opponent_hole_cards_str]
            
            # Remaining deck after dealing opponent cards
            sim_deck_after_opp = [card for card in remaining_deck if card not in opponent_hole_cards_str]

            # Draw remaining community cards if not all 5 are out yet
            sim_community_cards_to_draw = 5 - len(community_cards)
            
            if len(sim_deck_after_opp) < sim_community_cards_to_draw: # Not enough cards for board
                continue
            
            sim_community_cards_str = random.sample(sim_deck_after_opp, sim_community_cards_to_draw)
            
            sim_full_community_cards_obj = [card_to_tuple(c) for c in community_cards + sim_community_cards_str]

            # Evaluate opponent's hand
            opponent_hand_rank, _ = self._get_hand_rank_and_category(opponent_hole_cards_obj, sim_full_community_cards_obj)

            if our_hand_rank >= opponent_hand_rank:
                num_wins += 1
        
        # Add a small delta to avoid division by zero if num_simulations happens to be 0 (e.g., in testing edge cases)
        epsilon = 1e-6 
        return num_wins / (num_simulations + epsilon)


    def _get_hand_rank_and_category(self, hole_cards: List[Tuple[str, str]], community_cards: List[Tuple[str, str]]):
        """
        Evaluates the best 5-card poker hand from 7 cards (2 hole, 5 community).
        Returns a tuple: (hand_rank_value, hand_category_string)
        Hand ranks values are higher for better hands.
        """
        all_cards = hole_cards + community_cards
        
        if len(all_cards) < 5:
            # Not enough cards to form a 5-card hand yet
            # For pre-flop, we might just look at hole card strength, or return a neutral value
            return 0, "No Hand Yet" # Or a pre-flop specific evaluation
        
        # Map for card ranks
        rank_to_int = {str(i): i for i in range(2, 10)}
        rank_to_int.update({'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14})

        # Generate all 5-card combinations
        five_card_combinations = list(itertools.combinations(all_cards, 5))

        best_rank_value = -1
        best_category = "High Card"

        for combo in five_card_combinations:
            current_rank_value, current_category = self._evaluate_five_card_hand(combo)
            if current_rank_value > best_rank_value:
                best_rank_value = current_rank_value
                best_category = current_category
        
        return best_rank_value, best_category

    def _evaluate_five_card_hand(self, five_cards: Tuple[Tuple[str, str], ...]):
        """
        Evaluates a single 5-card hand.
        Returns a tuple: (rank_value, hand_category_string)
        """
        rank_to_int = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        int_ranks = sorted([rank_to_int[card[0]] for card in five_cards], reverse=True)
        suits = [card[1] for card in five_cards]

        is_flush = len(set(suits)) == 1
        is_straight = self._is_straight(int_ranks)
        
        ranks_count = Counter(int_ranks)
        num_pairs = 0
        num_trips = 0
        num_quads = 0
        
        for rank, count in ranks_count.items():
            if count == 2:
                num_pairs += 1
            elif count == 3:
                num_trips += 1
            elif count == 4:
                num_quads += 1

        # Hand ranking logic (higher value for better hands)
        if is_straight and is_flush:
            if int_ranks[0] == 14: # A, K, Q, J, T suited
                return 900 + int_ranks[0], "Royal Flush"
            return 800 + int_ranks[0], "Straight Flush"
        elif num_quads == 1:
            quad_rank = next(rank for rank, count in ranks_count.items() if count == 4)
            kicker = next(rank for rank in int_ranks if rank != quad_rank)
            return 700 + quad_rank * 10 + kicker, "Four of a Kind"
        elif num_trips == 1 and num_pairs == 1:
            trip_rank = next(rank for rank, count in ranks_count.items() if count == 3)
            pair_rank = next(rank for rank, count in ranks_count.items() if count == 2)
            return 600 + trip_rank * 10 + pair_rank, "Full House"
        elif is_flush:
            return 500 + int_ranks[0], "Flush"  # High card of flush determines tie-break
        elif is_straight:
            return 400 + int_ranks[0], "Straight" # High card of straight determines tie-break
        elif num_trips == 1:
            trip_rank = next(rank for rank, count in ranks_count.items() if count == 3)
            kickers = sorted([rank for rank in int_ranks if rank != trip_rank], reverse=True)
            return 300 + trip_rank * 100 + kickers[0] * 10 + kickers[1], "Three of a Kind"
        elif num_pairs == 2:
            pair_ranks = sorted([rank for rank, count in ranks_count.items() if count == 2], reverse=True)
            kicker = next(rank for rank in int_ranks if rank not in pair_ranks)
            return 200 + pair_ranks[0] * 100 + pair_ranks[1] * 10 + kicker, "Two Pair"
        elif num_pairs == 1:
            pair_rank = next(rank for rank, count in ranks_count.items() if count == 2)
            kickers = sorted([rank for rank in int_ranks if rank != pair_rank], reverse=True)
            return 100 + pair_rank * 1000 + kickers[0] * 100 + kickers[1] * 10 + kickers[2], "One Pair"
        else:
            return int_ranks[0] * 10000 + int_ranks[1] * 1000 + int_ranks[2] * 100 + int_ranks[3] * 10 + int_ranks[4], "High Card"

    def _is_straight(self, sorted_ranks: List[int]) -> bool:
        """
        Checks if the sorted list of 5 ranks forms a straight.
        Handles Ace-low straight (A, 5, 4, 3, 2).
        """
        unique_ranks = sorted(list(set(sorted_ranks)), reverse=True) # Ensure unique and sorted
        if len(unique_ranks) < 5:
            return False

        # Check for standard straight
        if all(unique_ranks[i] - 1 == unique_ranks[i+1] for i in range(len(unique_ranks) - 1)):
            return True
        
        # Check for Ace-low straight (A, 5, 4, 3, 2)
        # Unique ranks must be {14, 5, 4, 3, 2} in some order
        if set(unique_ranks) == {14, 5, 4, 3, 2}:
            return True
            
        return False