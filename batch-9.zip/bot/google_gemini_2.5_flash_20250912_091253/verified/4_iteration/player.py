from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.player_id = None
        self.last_action = None
        self.last_action_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        # The player_id is set by the framework, so we don't handle it here directly
        # but store relevant initial round details.
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands.get(str(self.id), []) if hasattr(round_state, 'player_hands') else self.hole_cards
        self.last_action = None # Reset last action for new round
        self.last_action_amount = 0 # Reset last action amount

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Determine hand strength (simple heuristic based on hole cards)
        # Higher score for pairs, suited connectors, high cards
        hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Pre-flop strategy
        if round_state.round == 'PREFLOP':
            if hand_strength >= 9: # Premium hands (AA, KK, QQ, AKs)
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 4)
                else:
                    return PokerAction.RAISE, min(remaining_chips, current_bet_to_match + max(round_state.min_raise, self.blind_amount * 3))
            elif hand_strength >= 7: # Strong hands (JJ, TT, AQ, KQs)
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, min(remaining_chips, self.blind_amount * 3)
                else:
                    return PokerAction.CALL, 0 # Call if already raised
            elif hand_strength >= 5: # Medium hands ( suited connectors, small pairs)
                if current_bet_to_match < self.blind_amount * 2: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hands
                if current_bet_to_match == 0: # Check if possible
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            # Re-evaluate hand strength with community cards
            hand_strength = self._calculate_hand_strength(self.hole_cards, round_state.community_cards)
            
            if hand_strength >= 10: # Very strong hand (e.g., Two Pair+, Strong Draw)
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, min(remaining_chips, round_state.pot // 2)
                else:
                    return PokerAction.RAISE, min(remaining_chips, current_bet_to_match + max(round_state.min_raise, round_state.pot // 4)) # Re-raise
            elif hand_strength >= 7: # Strong hand (e.g., One Pair, Medium Draw)
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, min(remaining_chips, round_state.pot // 3)
                else:
                    if current_bet_to_match <= remaining_chips / 4: # Call reasonable bets
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif hand_strength >= 4: # Medium hand (e.g., High Card, Gutshot)
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match <= self.blind_amount: # Call minimal bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Fallback to fold if no action decided (should not happen with comprehensive logic)
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Calculates a heuristic hand strength. Higher number means stronger hand.
        This is a very simplified heuristic and not a full hand evaluator.
        """
        if not hole_cards:
            return 0.0

        all_cards = hole_cards + community_cards
        
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        hole_ranks = sorted([ranks[card[0]] for card in hole_cards], reverse=True)
        hole_suits = [card[1] for card in hole_cards]

        strength = 0.0

        # Pre-flop strength
        if not community_cards:
            # Pairs
            if len(hole_ranks) == 2 and hole_ranks[0] == hole_ranks[1]:
                strength += 2 * (hole_ranks[0] / 14.0) * 10 # Stronger pairs get more
            
            # Suited
            if len(hole_suits) == 2 and hole_suits[0] == hole_suits[1]:
                strength += 1.5
            
            # Connectors (e.g., 89, TJ, QK)
            if len(hole_ranks) == 2 and abs(hole_ranks[0] - hole_ranks[1]) == 1:
                strength += 1.0
                if hole_ranks[0] >= 10: # Higher connectors are better
                    strength += 0.5

            # High cards
            strength += (hole_ranks[0] / 14.0) * 2 + (hole_ranks[1] / 14.0) * 1

        # Post-flop strength (simplified, just looking for basic combinations)
        else:
            card_ranks = [ranks[card[0]] for card in all_cards]
            rank_counts = {rank: card_ranks.count(rank) for rank in set(card_ranks)}
            
            # Check for pairs, three of a kind, four of a kind
            num_pairs = 0
            has_three_of_a_kind = False
            has_four_of_a_kind = False
            for rank, count in rank_counts.items():
                if count == 2:
                    num_pairs += 1
                    strength += (rank / 14.0) * 3 # Value for a pair
                elif count == 3:
                    has_three_of_a_kind = True
                    strength += (rank / 14.0) * 6 # Value for three of a kind
                elif count == 4:
                    has_four_of_a_kind = True
                    strength += (rank / 14.0) * 10
            
            if has_four_of_a_kind:
                strength += 100 # Very strong
            elif has_three_of_a_kind:
                strength += 50
            elif num_pairs >= 2:
                strength += 30 # Two pair
            elif num_pairs == 1:
                strength += 10 # One pair

            # Check for flushes (simple check)
            suits = [card[1] for card in all_cards]
            suit_counts = {suit: suits.count(suit) for suit in set(suits)}
            for suit, count in suit_counts.items():
                if count >= 5:
                    strength += 40 # Flush

            # Check for straights (simple check)
            unique_ranks = sorted(list(set(card_ranks)))
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    strength += 35 # Straight
                    break # Only count one straight

        return strength