from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_action import PokerRound

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = -1
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.player_id = self.id # Bot's own ID is set in the base Bot class

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.player_id)] if hasattr(round_state, 'player_hands') else []

    def _get_card_rank(self, card: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]

    def _get_hand_strength_preflop(self) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.0

        card1_rank = self._get_card_rank(self.hole_cards[0])
        card2_rank = self._get_card_rank(self.hole_cards[1])
        card1_suit = self.hole_cards[0][1]
        card2_suit = self.hole_cards[1][1]

        # Pair
        if card1_rank == card2_rank:
            if card1_rank >= 12:  # JJ, QQ, KK, AA
                return 0.9 + (card1_rank - 11) * 0.02
            elif card1_rank >= 7:  # 77-TT
                return 0.7 + (card1_rank - 6) * 0.02
            else:  # 22-66
                return 0.5 + card1_rank * 0.01

        # Suited connectors/gappers
        suited = (card1_suit == card2_suit)
        rank_diff = abs(card1_rank - card2_rank)
        min_rank = min(card1_rank, card2_rank)
        max_rank = max(card1_rank, card2_rank)

        if suited:
            if rank_diff == 1: # Suited connectors
                if min_rank >= 10: # TJ+ suited
                    return 0.85
                elif min_rank >= 7: # 78-9T suited
                    return 0.75
                else: # 23-67 suited
                    return 0.65
            elif rank_diff == 2 and min_rank >= 8: # Suited one-gappers 8T+
                return 0.6
            elif rank_diff == 0: # This case is handled by pairs
                pass 
            else: # Other suited cards
                if max_rank >= 12 and min_rank >= 8: # A,K,Q high suited with reasonable kicker
                    return 0.7
                elif max_rank >= 10 and min_rank >= 6:
                    return 0.55
                else:
                    return 0.4
        
        # Offsuited Broadway/high cards
        if max_rank >= 12 and min_rank >= 10: # AK, AQ, KQ offsuited
            return 0.65 + (max_rank + min_rank - 22) * 0.01
        elif max_rank >= 10 and min_rank >= 8: # AT, AJ, QT, JT offsuited
            return 0.5
        
        # Catch all for very weak hands
        return 0.3

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        
        # Calculate pre-flop strength
        hand_strength = self._get_hand_strength_preflop()

        # Simple strategy for pre-flop
        if round_state.round == PokerRound.PREFLOP.name:
            if hand_strength >= 0.8:  # Very strong hands (AA, KK, QQ, AKs)
                if current_bet_to_match == 0:
                    raise_amount = max(round_state.min_raise, self.blind_amount * 3)
                    if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > round_state.current_bet:
                        if remaining_chips >= raise_amount:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.ALL_IN, 0
                    else: # current_bet is higher than our calculated raise, just call (or all-in if can't afford raise)
                        if remaining_chips >= current_bet_to_match:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0

                else: # There's a bet to match
                    if remaining_chips <= current_bet_to_match:
                        return PokerAction.ALL_IN, 0
                    
                    if current_bet_to_match >= remaining_chips * 0.4: # Don't over commit too early against a big raise
                        if hand_strength >= 0.9: # Only super strong hands call big raises
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    
                    raise_amount = max(round_state.min_raise, current_bet_to_match * 2)
                    if remaining_chips >= raise_amount and raise_amount <= round_state.max_raise:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.CALL, 0

            elif hand_strength >= 0.6:  # Strong hands (JJ, TT, AQs, KJs)
                if current_bet_to_match == 0: # No bet, try to raise
                    raise_amount = max(round_state.min_raise, self.blind_amount * 2)
                    if raise_amount + round_state.player_bets.get(str(self.player_id), 0) > round_state.current_bet:
                        if remaining_chips >= raise_amount:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.ALL_IN, 0
                    else: # current_bet is higher than our calculated raise, just call
                        if remaining_chips >= current_bet_to_match:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0
                else:
                    if current_bet_to_match <= remaining_chips * 0.25: # Call small bets
                        return PokerAction.CALL, 0
                    elif current_bet_to_match >= remaining_chips * 0.35: # Fold to large bets
                        return PokerAction.FOLD, 0
                    else: # Medium bet, call if strength is high enough
                        if hand_strength >= 0.65:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
            
            elif hand_strength >= 0.45: # Medium strength hands (small pairs, some suited connectors)
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match <= remaining_chips * 0.1: # Call small bets
                    return PokerAction.CALL, 0
                else: # Fold to larger bets
                    return PokerAction.FOLD, 0
            
            else:  # Weak hands
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop strategy (simplified for now)
        # This is a very basic post-flop strategy and needs significant improvement for a competitive bot.
        # It's currently designed to be conservative unless it has good pre-flop strength.
        else: # Flop, Turn, River
             # If no community cards are dealt yet or only just started, wait for cards before evaluation
            
            # Placeholder: Simple evaluation for demonstration. A real bot needs full hand evaluation
            # For now, it will tend to check/call small bets, fold to large bets, and rarely raise unless very strong
            
            if current_bet_to_match == 0:
                # If no one has bet, check
                return PokerAction.CHECK, 0
            else:
                # If there's a bet, compare it to remaining chips
                if current_bet_to_match >= remaining_chips:
                    # If the bet is larger than or equal to our chips, go all-in or fold
                    # For now, prioritize folding if we are deep-stacked post-flop without a plan
                    if remaining_chips > self.blind_amount * 10 and hand_strength < 0.7: # If we are not super strong and have chips, fold
                        return PokerAction.FOLD, 0
                    else: # If we are short, or very strong, just shove
                        return PokerAction.ALL_IN, 0
                
                # If current bet is less than our chips, decide to call or fold
                # Again, this is very basic, a real bot needs to evaluate actual hand strength vs. board
                # For demonstration, call small to medium bets, and fold to large bets
                elif current_bet_to_match <= remaining_chips * 0.2: # Call bets up to 20% of remaining chips
                    return PokerAction.CALL, 0
                else: # Fold to larger bets
                    return PokerAction.FOLD, 0



    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # We don't need to do anything here for this basic bot.
        # A more advanced bot might update statistics or opponent models here.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # We don't need to do anything here for this basic bot.
        pass