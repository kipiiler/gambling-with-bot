from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands 
        self.blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the new round
        # The player_hands in on_start is for the entire game simulation initial hands, not per round.
        # on_round_start does not provide hole cards, so we need to rely on the get_action to get it.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # For simplicity, we'll assume hole cards are passed in round_state or accessible.
        # Since round_state doesn't directly provide hole cards, we need to track them.
        # This simple bot will treat `self.hole_cards` as the current hand for the round.
        
        # A very basic strategy:
        # Pre-flop:
        #   - If strong hand (e.g., AA, KK, QQ, AKs), raise.
        #   - If medium hand (e.g., JJ, AQ, KQs), call or small raise.
        #   - Otherwise, call small blinds or fold.
        # Post-flop:
        #   - If strong hand (pair, two pair, trips, better), bet or raise.
        #   - If drawing hand, call.
        #   - Otherwise, check or fold.
        
        my_player_id = str(self.id)
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(my_player_id, 0)
        
        # Basic pre-flop hand strength evaluation (can be greatly improved)
        # Assuming self.hole_cards contains the two card strings, e.g., ['Ah', 'Kd']
        if len(self.hole_cards) != 2:
            # Fallback if hole cards aren't properly set, should not happen if previous methods are correctly implemented
            return (PokerAction.FOLD, 0)

        card1_rank = self._get_card_rank(self.hole_cards[0])
        card2_rank = self._get_card_rank(self.hole_cards[1])
        card1_suit = self.hole_cards[0][-1]
        card2_suit = self.hole_cards[1][-1]

        is_suited = (card1_suit == card2_suit)
        is_pair = (card1_rank == card2_rank)

        # Convert ranks to comparable numeric values (e.g., 2=2, ..., T=10, J=11, Q=12, K=13, A=14)
        rank1_val = self._rank_to_value(card1_rank)
        rank2_val = self._rank_to_value(card2_rank)
        
        hand_strength = 0 # 0-100, higher is stronger

        # Simple pre-flop strategy
        if round_state.round == 'Preflop':
            if is_pair:
                if rank1_val >= self._rank_to_value('Q'): # AA, KK, QQ
                    hand_strength = 90
                elif rank1_val >= self._rank_to_value('J'): # JJ, TT
                    hand_strength = 75
                elif rank1_val >= self._rank_to_value('7'): # 77-99
                    hand_strength = 60
                else: # 22-66
                    hand_strength = 40
            elif (rank1_val >= self._rank_to_value('A') and rank2_val >= self._rank_to_value('T')) or \
                 (rank2_val >= self._rank_to_value('A') and rank1_val >= self._rank_to_value('T')): # AK, AQ, AJ, AT (suited or not)
                hand_strength = 85 if is_suited else 70
            elif (rank1_val >= self._rank_to_value('K') and rank2_val >= self._rank_to_value('J')) or \
                 (rank2_val >= self._rank_to_value('K') and rank1_val >= self._rank_to_value('J')): # KQ, KJ (suited or not)
                hand_strength = 65 if is_suited else 50
            elif is_suited and (rank1_val >= self._rank_to_value('Q') and rank2_val >= self._rank_to_value('J')) or \
                (rank2_val >= self._rank_to_value('Q') and rank1_val >= self._rank_to_value('J')): # QJs, QTs
                hand_strength = 55
            else: # Other hands
                hand_strength = 20
            
            # Action based on pre-flop hand strength
            if hand_strength >= 80: # Very strong hands
                raise_amount = max(round_state.min_raise, self.blind_amount * 3)
                if current_bet_to_match > 0 and current_bet_to_match >= remaining_chips:
                    return (PokerAction.ALL_IN, 0) # All-in if facing an all-in
                if raise_amount + current_bet_to_match >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, raise_amount)
            elif hand_strength >= 60: # Strong hands
                if current_bet_to_match > remaining_chips / 4: # Don't overcommit on strong hands pre-flop
                    return (PokerAction.FOLD, 0)
                if current_bet_to_match > 0 and current_bet_to_match >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                if current_bet_to_match > 0:
                    return (PokerAction.CALL, 0)
                else:
                    # Small raise or check if no bet
                    raise_amount = max(round_state.min_raise, int(self.blind_amount * 2.5))
                    if raise_amount + current_bet_to_match >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
            elif hand_strength >= 40: # Medium hands
                if current_bet_to_match > remaining_chips / 8: # Don't call big bets with medium hands
                    return (PokerAction.FOLD, 0)
                if current_bet_to_match > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else: # Weak hands
                if current_bet_to_match > 0:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CHECK, 0)
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            # Simple simulation of hand strength with community cards
            all_cards = self.hole_cards + round_state.community_cards
            
            # This is a very rudimentary hand evaluator, needs a proper implementation for a real bot
            # For iteration 2, we improve this slightly by checking for pairs and flush/straight draws
            
            ranks = [self._rank_to_value(self._get_card_rank(card)) for card in all_cards]
            suits = [card[-1] for card in all_cards]

            # Check for pairs
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_rank_count = 0
            for rank, count in rank_counts.items():
                if count > max_rank_count:
                    max_rank_count = count
            
            # Check for flush draw/flush
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            has_flush_draw = False
            has_flush = False
            for suit, count in suit_counts.items():
                if count >= 4 and len(round_state.community_cards) < 5: # Flush draw if 4 of a kind and not all community cards out
                    has_flush_draw = True
                if count >= 5: # Flush
                    has_flush = True

            # Check for straight draw/straight (very basic)
            sorted_ranks = sorted(list(set(ranks))) # Unique sorted ranks
            has_straight_draw = False
            has_straight = False
            if len(sorted_ranks) >= 4:
                for i in range(len(sorted_ranks) - 3):
                    if sorted_ranks[i+3] - sorted_ranks[i] <= 4:
                        has_straight_draw = True
            if len(sorted_ranks) >= 5:
                for i in range(len(sorted_ranks) - 4):
                    if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                        has_straight = True
            
            # Determine post-flop hand strength
            if max_rank_count >= 4: # Four of a kind
                hand_strength = 100
            elif max_rank_count >= 3 and len(rank_counts) <= len(all_cards) - 2: # Full house or Three of a kind (needs more accurate check for full house)
                # A more robust check for full house: needs a pair + three of a kind
                has_trips = False
                has_pair = False
                for r, c in rank_counts.items():
                    if c == 3:
                        has_trips = True
                    elif c == 2:
                        has_pair = True
                if has_trips and has_pair:
                    hand_strength = 95
                elif has_trips:
                    hand_strength = 80
                else: # Fallback for now
                     hand_strength = 50
            elif has_flush:
                hand_strength = 90
            elif has_straight:
                hand_strength = 85
            elif max_rank_count == 2:
                # Check for two pair
                pairs_count = sum(1 for c in rank_counts.values() if c == 2)
                if pairs_count >= 2:
                    hand_strength = 70
                else: # One pair
                    hand_strength = 60
            elif has_flush_draw or has_straight_draw:
                hand_strength = 45 # Decent draw
            else: # High card
                hand_strength = 30

            # Action based on post-flop hand strength
            if hand_strength >= 80: # Very strong hands (trips, flush, straight, full house, quads)
                if current_bet_to_match > 0 and current_bet_to_match >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                raise_amount = min(max(round_state.min_raise, int(round_state.pot * 0.75)), remaining_chips - current_bet_to_match)
                if raise_amount <= 0: # If cannot raise or raise amount is invalid, call or check
                    if current_bet_to_match > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                return (PokerAction.RAISE, raise_amount)
            elif hand_strength >= 60: # Strong hands (strong pair, two pair)
                if current_bet_to_match > remaining_chips / 3: # Don't call excessively large bets
                    return (PokerAction.FOLD, 0)
                
                if current_bet_to_match > 0 and current_bet_to_match >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                
                if current_bet_to_match > 0:
                    return (PokerAction.CALL, 0)
                else:
                    # Small bet or check
                    bet_amount = min(max(self.blind_amount, int(round_state.pot * 0.3)), remaining_chips - current_bet_to_match)
                    if bet_amount <= 0:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.RAISE, bet_amount) # Using RAISE for betting
            elif hand_strength >= 40: # Medium hands or good draws
                if current_bet_to_match > remaining_chips / 6: # Be cautious with medium strength
                    return (PokerAction.FOLD, 0)
                if current_bet_to_match > 0:
                    return (PokerAction.CALL, 0)
                else: 
                    return (PokerAction.CHECK, 0)
            else: # Weak hands
                if current_bet_to_match > 0:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CHECK, 0)
        
        # Default fallback to fold if nothing matches (shouldn't be reached if logic is complete)
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _get_card_rank(self, card: str) -> str:
        return card[:-1]

    def _rank_to_value(self, rank: str) -> int:
        if rank.isdigit():
            return int(rank)
        elif rank == 'T':
            return 10
        elif rank == 'J':
            return 11
        elif rank == 'Q':
            return 12
        elif rank == 'K':
            return 13
        elif rank == 'A':
            return 14
        return 0 # Should not happen