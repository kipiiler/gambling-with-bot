from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.player_id_map = {p_id: idx for idx, p_id in enumerate(all_players)} # Map player ID to simple index for internal use
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the current round if not already set by on_start for some reason
        # This part might be redundant if on_start correctly sets hole_cards at the beginning of a game
        # but useful if game server sends player_hands per round
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = int(self.id)
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(my_id), 0)
        
        # Determine player's position (small blind, big blind, or other)
        # This requires knowing blinds for the current hand, which isn't always directly in round_state
        # For now, let's assume heads-up and simple position logic or defer.
        
        # Basic hand strength evaluation based on hole cards
        # This is a very simple model and needs significant improvement
        hand_rank = self._evaluate_hole_cards(self.hole_cards)
        
        # Consider the number of active players
        active_players = sum(1 for player_id, bet in round_state.player_bets.items() if player_id in map(str, round_state.current_player))

        # Define thresholds for hand strength categories
        # These are arbitrary and need tuning
        BLUFF_THRESHOLD = 0.5  # For semi-bluffing or very weak hands
        WEAK_HAND_THRESHOLD = 0.65 # Top 65% of hands pre-flop
        MEDIUM_HAND_THRESHOLD = 0.8  # Top 80% of hands pre-flop
        STRONG_HAND_THRESHOLD = 0.9  # Top 90% of hands pre-flop

        # Special logic for pre-flop
        if round_state.round == 'Preflop':
            # Aggressive play with strong hands
            if hand_rank >= STRONG_HAND_THRESHOLD: # Top 10% of hands
                if current_bet_to_match > 0: # If there's a bet to call
                    # Raise dynamically based on current bet and stack
                    raise_amount = max(round_state.min_raise, current_bet_to_match * 2) 
                    if remaining_chips >= raise_amount + current_bet_to_match:
                        return PokerAction.RAISE, raise_amount
                    elif remaining_chips > current_bet_to_match and current_bet_to_match > 0:
                        return PokerAction.ALL_IN, 0 # Go all-in if cannot raise enough
                    else:
                        return PokerAction.CALL, 0 # If cannot raise or all-in, just call

                else: # No bet, can check or raise
                    if remaining_chips >= self.blind_amount * 3: # Raise 3x big blind
                         return PokerAction.RAISE, self.blind_amount * 3
                    else:
                        return PokerAction.ALL_IN, 0 # All-in if stack is low
            
            # Medium hands, less aggressive
            elif hand_rank >= MEDIUM_HAND_THRESHOLD: # Top 20% of hands
                if current_bet_to_match > remaining_chips / 3: # Don't call big bets with medium hands
                    return PokerAction.FOLD, 0
                elif current_bet_to_match > 0:
                    return PokerAction.CALL, 0
                else: # No bet, just check
                    return PokerAction.CHECK, 0

            # Weak hands, mostly fold
            else: # Weakest hands
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_match < self.blind_amount: # Call small blinds
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0


        # Post-flop strategy (Flop, Turn, River)
        # Combine hole cards with community cards for better evaluation
        all_cards = self.hole_cards + round_state.community_cards
        effective_hand_rank = self._evaluate_hand_strength(all_cards, len(round_state.community_cards))

        # Adjust strategy based on effective hand strength and number of community cards
        # As more community cards are revealed, hand strength becomes more certain
        if effective_hand_rank >= STRONG_HAND_THRESHOLD: # Strong hands (e.g., made hands, strong draws)
            if current_bet_to_match > 0:
                raise_amount = max(round_state.min_raise, current_bet_to_match * 2)
                if remaining_chips >= raise_amount + current_bet_to_match:
                    return PokerAction.RAISE, raise_amount
                elif remaining_chips > current_bet_to_match and current_bet_to_match > 0:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.CALL, 0
            else:
                if remaining_chips >= self.blind_amount * 2:
                    return PokerAction.RAISE, self.blind_amount * 2
                else:
                    return PokerAction.ALL_IN, 0

        elif effective_hand_rank >= WEAK_HAND_THRESHOLD: # Medium hands (e.g., top pair, good draws)
            if current_bet_to_match > remaining_chips / 2 and active_players > 1: # Be cautious with large bets in multi-way pots
                return PokerAction.FOLD, 0
            elif current_bet_to_match > 0:
                return PokerAction.CALL, 0
            else:
                return PokerAction.CHECK, 0

        else: # Weak hands (e.g., no pair, weak draw)
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0
            elif current_bet_to_match < remaining_chips / 10: # Call small bets to see next card
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Default action
        if current_bet_to_match >= remaining_chips:
            return PokerAction.ALL_IN, 0
        elif current_bet_to_match == 0:
            return PokerAction.CHECK, 0
        elif current_bet_to_match > 0:
            return PokerAction.FOLD, 0 # Default to fold if bet is too high or unhandled
        
        return PokerAction.FOLD, 0 # Fallback in case none above match (shouldn't happen with comprehensive logic)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _evaluate_hole_cards(self, cards: List[str]) -> float:
        """
        A very basic function to evaluate hole card strength.
        This needs to be considerably improved for a competitive bot.
        Returns a value between 0.0 (worst) and 1.0 (best).
        """
        if not cards or len(cards) != 2:
            return 0.0

        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        c1_rank = rank_map[cards[0][0]]
        c2_rank = rank_map[cards[1][0]]
        c1_suit = cards[0][1]
        c2_suit = cards[1][1]

        # Pair
        if c1_rank == c2_rank:
            # Stronger pairs are better
            return (c1_rank - 2) / 12 * 0.4 + 0.6  # 0.6 to 1.0 for pairs (22 is 0.6, AA is 1.0)
        
        # Suited
        suited = (c1_suit == c2_suit)
        
        # Connectedness
        connected = abs(c1_rank - c2_rank) == 1
        
        # High cards
        high_card_bonus = 0
        if c1_rank >= 10 or c2_rank >= 10: # Ten or better
            high_card_bonus = 0.1
        if c1_rank >= 12 and c2_rank >= 12: # Queen or better
            high_card_bonus = 0.2
        if c1_rank >= 13 and c2_rank >= 13: # King or better
            high_card_bonus = 0.3
        
        # Calculate a score based on these features
        score = 0.1 * (c1_rank + c2_rank) / 28  # Normalize rank sum (2+3=5 to 13+14=27)
        if suited:
            score += 0.1
        if connected:
            score += 0.05
        score += high_card_bonus

        return min(1.0, score) # Ensure score doesn't exceed 1.0

    def _evaluate_hand_strength(self, all_cards: List[str], num_community_cards: int) -> float:
        """
        Evaluates the strength of the 5-card poker hand formed by hole cards and community cards.
        This is a placeholder and ideally requires a robust poker hand evaluator.
        Returns a value between 0.0 (worst) and 1.0 (best).
        """
        if len(all_cards) < 2: # Need at least 2 hole cards
            return 0.0

        if num_community_cards < 3: # Not enough community cards to form full hand
            return self._evaluate_hole_cards(all_cards[:2]) # Use pre-flop evaluator as a proxy

        # For a full implementation, you'd need a poker hand evaluator here.
        # This placeholder will just return a boosted version of hole card rating for now.
        # This is a significant weakness of the current bot and needs a proper hand evaluation library.

        # Crude approximation: if there's a pair on the board or in hand + board, it's stronger
        ranks = [self._get_card_rank(card) for card in all_cards]
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1

        score = self._evaluate_hole_cards(self.hole_cards) # Start with hole card strength

        if 4 in rank_counts.values(): # Four of a kind
            score = 1.0
        elif 3 in rank_counts.values() and 2 in rank_counts.values(): # Full House
            score = 0.95
        elif 3 in rank_counts.values(): # Three of a kind
            score = 0.8
        elif sum(1 for count in rank_counts.values() if count == 2) >= 2: # Two Pair
            score = 0.7
        elif 2 in rank_counts.values(): # One Pair
            score = 0.65
        
        # Flush or Straight (very basic check)
        suits = [card[1] for card in all_cards]
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        if max(suit_counts.values()) >= 5: # Possible flush
            score = max(score, 0.9)


        sorted_ranks = sorted(list(set(ranks))) # Unique sorted ranks for straight check
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i+4] - sorted_ranks[i] == 4: # Possible straight
                    score = max(score, 0.85)

        return min(1.0, score) # Ensure score is not over 1.0

    def _get_card_rank(self, card: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]