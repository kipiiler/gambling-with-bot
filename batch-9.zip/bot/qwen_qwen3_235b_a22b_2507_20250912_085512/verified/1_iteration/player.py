from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.positional_importance = {}
        self.aggression_factor = 1.5
        self.tight_threshold = 0.3
        self.tight_early_threshold = 0.4
        self.voluntary_donation_per_hand = 0.0
        self.hand_strength_cache = {}
        self.total_hands_played = 0
        self.stack_size_importance = 1.2

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.total_hands_played = 0
        self.voluntary_donation_per_hand = 0.0
        self.hand_strength_cache.clear()

        # Estimate positions: later positions are better
        player_count = len(all_players)
        for i, pid in enumerate(all_players):
            # Position: 0 = early, ~0.5 = middle, ~1 = late
            pos_index = (i - all_players.index(self.id)) % player_count
            self.positional_importance[pid] = 1.0 - (pos_index / max(player_count - 1, 1))

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.total_hands_played += 1
        # Adjust tightness based on stage (early vs later in tournament)
        stage_factor = min(remaining_chips / self.starting_chips, 10.0)
        self.tight_threshold = max(self.tight_early_threshold * stage_factor, 0.2)

    def card_rank_value(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def suited(self, cards: List[str]) -> bool:
        return cards[0][1] == cards[1][1]

    def paired(self, cards: List[str]) -> bool:
        return cards[0][0] == cards[1][0]

    def hand_rank_strength(self, hole_cards: List[str]) -> float:
        """ Estimate pre-flop hand strength (0 to 1) """
        c1, c2 = hole_cards
        r1, r2 = self.card_rank_value(c1), self.card_rank_value(c2)
        high = max(r1, r2)
        low = min(r1, r2)
        gap = high - low

        score = 0.0
        # Pair bonus
        if self.paired(hole_cards):
            if high >= 13:  # AA, KK
                score = 0.85
            elif high >= 12:  # QQ, JJ
                score = 0.7
            elif high >= 10:  # TT, 99
                score = 0.6
            else:
                score = 0.4 + (high - 2) * 0.02  # 22-99
        else:
            # High card boost
            score += (high - 2) / 100  # base on high card
            score += (low - 2) / 200

            # Connectors and gaps
            if gap == 0:  # same rank, already covered
                pass
            elif gap == 1:  # connectors
                score += 0.05
            elif gap == 2:
                score += 0.03
            elif gap == 3:
                score += 0.02
            elif gap == 4:
                score += 0.01

            # Suited bonus
            if self.suited(hole_cards):
                score += 0.03

            # Broadway adjustment
            if low >= 10:
                score += 0.05

            # Reduce penalty for big gaps
            if gap > 4:
                score -= 0.02

            # Ax starting hands
            if high == 14 and low <= 5:
                score += 0.04
            elif high == 14 and low <= 9:
                score += 0.02

        # Normalize to ~0.1 to 0.9
        return min(max(score, 0.1), 0.9)

    def estimate_equity(self, hole_cards: List[str], community_cards: List[str], simulations: int = 50) -> float:
        """ Very rough Monte Carlo equity estimation with limited sim for speed """
        if len(community_cards) == 5:
            return self.evaluate_hand(hole_cards + community_cards)
        
        deck = self.generate_deck()
        for card in hole_cards + community_cards:
            if card in deck:
                deck.remove(card)

        wins = 0
        total = 0
        # Estimate against 1-3 opponents realistically
        num_opponents = max(1, min(3, len(self.all_players) - 1))

        for _ in range(simulations):
            random.shuffle(deck)
            num_needed = 5 - len(community_cards)
            if len(deck) < num_needed:
                break
            simulated_board = community_cards + deck[:num_needed]
            my_final_hand = self.rank_hand(hole_cards + simulated_board)

            all_opponent_hands = []
            for _ in range(num_opponents):
                if len(deck) < 2:
                    break
                opp_hand = deck[num_needed:num_needed+2]
                all_opponent_hands.append(self.rank_hand(opp_hand + simulated_board))
                num_needed += 2

            if not all_opponent_hands:
                break

            if my_final_hand > max(all_opponent_hands):
                wins += 1
            elif my_final_hand == max(all_opponent_hands):
                wins += 0.5
            total += 1

        return wins / total if total > 0 else 0.5

    def generate_deck(self) -> List[str]:
        suits = ['h', 'd', 's', 'c']
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        return [r + s for r in ranks for s in suits]

    def evaluate_hand(self, cards: List[str]) -> float:
        """ Evaluates a 5+ card hand and returns a comparable score """
        if tuple(cards) in self.hand_strength_cache:
            return self.hand_strength_cache[tuple(cards)]

        score = self.rank_hand(cards)
        self.hand_strength_cache[tuple(cards)] = score
        return score

    def rank_hand(self, cards: List[str]) -> int:
        """ Returns an integer score for a hand (higher is better) """
        from collections import Counter

        if len(cards) > 5:
            # Generate all 5-card combinations
            from itertools import combinations
            best = 0
            for combo in combinations(cards, 5):
                best = max(best, self.score_five_card(list(combo)))
            return best
        elif len(cards) == 5:
            return self.score_five_card(cards)
        else:
            return 0

    def score_five_card(self, cards: List[str]) -> int:
        """ Score a 5-card poker hand """
        if len(cards) != 5:
            return 0
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        values = [c[0] for c in cards]
        suits = [c[1] for c in cards]
        vmap = {r: i+2 for i, r in enumerate(ranks)}
        nums = sorted([vmap[v] for v in values], reverse=True)
        is_flush = len(set(suits)) == 1
        is_straight = (nums[0]-nums[4] == 4) and len(set(nums)) == 5
        # Special A-5 straight
        if not is_straight and set(values) == {'A','2','3','4','5'}:
            nums = [5,4,3,2,1]
            is_straight = True

        c = Counter(nums)
        freq = sorted(c.items(), key=lambda x: (x[1], x[0]), reverse=True)
        val = 0

        if is_straight and is_flush:
            return 80000000 + nums[0]
        if freq[0][1] == 4:
            quad, kicker = freq[0][0], freq[1][0]
            return 70000000 + quad * 100 + kicker
        if freq[0][1] == 3 and freq[1][1] == 2:
            trips, pair = freq[0][0], freq[1][0]
            return 60000000 + trips * 100 + pair
        if is_flush:
            return 50000000 + nums[0]*10000 + nums[1]*1000 + nums[2]*100 + nums[3]*10 + nums[4]
        if is_straight:
            return 40000000 + nums[0]
        if freq[0][1] == 3:
            trips = freq[0][0]
            kickers = [f[0] for f in freq[1:]]
            return 30000000 + trips*10000 + kickers[0]*100 + kickers[1]
        if freq[0][1] == 2 and freq[1][1] == 2:
            pair1, pair2 = freq[0][0], freq[1][0]
            kicker = freq[2][0]
            return 20000000 + max(pair1,pair2)*10000 + min(pair1,pair2)*100 + kicker
        if freq[0][1] == 2:
            pair = freq[0][0]
            kickers = [f[0] for f in freq[1:]]
            score = 10000000 + pair*10000
            for i, k in enumerate(kickers):
                score += k * (100 ** (2-i))
            return score
        # High card
        score = nums[0]*100000000 + nums[1]*1000000 + nums[2]*10000 + nums[3]*100 + nums[4]
        return score

    def pot_odds_ratio(self, call_amount: int, pot_size: int) -> float:
        if call_amount == 0:
            return float('inf')
        return pot_size / call_amount

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_round = round_state.round
            community_cards = round_state.community_cards
            pot_size = round_state.pot
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            player_bet = round_state.player_bets.get(str(self.id), 0)

            # Get hole cards (assume we get them in on_start or inferred)
            hole_cards = self.get_hole_cards(round_state, self.player_hands)

            if not hole_cards:
                return PokerAction.FOLD, 0

            call_amount = current_bet - player_bet
            effective_stack = min(remaining_chips, 100 * self.blind_amount)  # avoid overcommitment

            # Estimate hand strength
            hand_strength = 0.0
            if current_round == 'Preflop':
                hand_strength = self.hand_rank_strength(hole_cards)
            else:
                hand_strength = self.estimate_equity(hole_cards, community_cards, simulations=100)

            # Position factor
            my_pos = self.positional_importance.get(self.id, 0.5)
            position_multiplier = 0.8 + 0.4 * my_pos

            # Stack-aware aggression
            stack_depth = remaining_chips / (self.blind_amount * 2 + 1e-8)
            stack_factor = 1.0 if stack_depth > 10 else (0.7 if stack_depth > 5 else 0.4)

            # Adjust decision
            aggression = self.aggression_factor * position_multiplier * stack_factor
            adjusted_suitability = hand_strength * aggression

            # Determine playable
            is_playable = adjusted_suitability > self.tight_threshold

            # Consider recent VPIP (Voluntarily Put $ In Pot) to avoid detectable patterns
            # Simplified: limit raise frequency if too high recent aggression
            recent_action_bias = 1.0

            # Decision logic
            if call_amount == 0:
                if is_playable:
                    if current_round == 'Preflop' and not self.is_bb_sb_or_dealer(round_state):
                        # Raise pre-check
                        raise_amount = min(int(pot_size * 0.5), max_raise)
                        raise_amount = max(min_raise, raise_amount)
                        if raise_amount <= max_raise and raise_amount >= min_raise:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

            # Facing a bet
            pot_odds = self.pot_odds_ratio(call_amount, pot_size)
            min_equity_needed = 1 / (pot_odds + 1) if pot_odds != float('inf') else 0

            # All-in logic
            if remaining_chips <= self.blind_amount * 2 or hand_strength > 0.95:
                if hand_strength >= min_equity_needed * 0.9:
                    return PokerAction.ALL_IN, 0

            # Fold if unplayable and odds not good
            if not is_playable and hand_strength < min_equity_needed * 0.8:
                return PokerAction.FOLD, 0

            # Call if we have sufficient equity
            if hand_strength >= min_equity_needed * 0.9:
                return PokerAction.CALL, 0

            # Raise logic: only if strong hand and good position
            if is_playable and hand_strength > 0.6 and pot_odds > 2:
                raise_amount = 0
                if current_round == 'Preflop':
                    raise_amount = min(int(pot_size * 2), max_raise)
                else:
                    # Value bet or semi-bluff
                    bet_size = max(pot_size * 0.5, call_amount * 2)
                    raise_amount = min(int(bet_size), max_raise)
                raise_amount = max(min_raise, raise_amount)
                if raise_amount <= max_raise and raise_amount >= min_raise:
                    return PokerAction.RAISE, raise_amount

            # Default action
            if call_amount <= remaining_chips * 0.3 or hand_strength > 0.5:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        except Exception as e:
            # Any error leads to fold
            return PokerAction.FOLD, 0

    def is_bb_sb_or_dealer(self, round_state: RoundStateClient) -> bool:
        """ Estimate if we are in BB, SB or dealer position """
        current_players = round_state.current_player
        if len(current_players) <= 2:
            return self.id in [self.big_blind_player_id, self.small_blind_player_id]
        # Approximate dealer as not first to act
        return True  # conservative

    def get_hole_cards(self, round_state: RoundStateClient, player_hands: List[str]) -> List[str]:
        """Extract hole cards for this bot from available info"""
        if not player_hands:
            return []
        # Assume player_hands list contains 'cards' field and player order
        # This is a simplification -- in reality, mapping hands to player IDs
        # should be handled via proper id-based lookup
        try:
            # Attempt to use self.id to find hand
            # This is a placeholder; in real system, server should link hand to id
            # For now, assume player_hands are ordered by all_players from on_start
            if not hasattr(self, 'all_players') or not self.all_players:
                return []
            if self.id not in self.all_players:
                return []
            idx = self.all_players.index(self.id)
            if idx < len(player_hands):
                hand_str = player_hands[idx]
                # Parse hand string like "AhKs"
                return [hand_str[0:2], hand_str[2:4]]
            else:
                return []
        except:
            return []

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update stats if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up if needed
        self.hand_strength_cache.clear()