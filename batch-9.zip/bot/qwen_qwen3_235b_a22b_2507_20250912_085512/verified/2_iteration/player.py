from typing import List, Tuple, Dict, Set
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.starting_chips = 10000
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.hand_history = []
        self.current_hole_cards = []
        self.positional_advantage = False
        self.strong_hands = {'AA', 'KK', 'QQ', 'AKs', 'AKo', 'JJ', 'AQs', 'AQo'}
        self.medium_hands = {'TT', 'AJs', 'ATs', 'KQs', 'AJo', 'KQt', 'KTs', 'QJs'}
        self.tight_fold_threshold = 0.2  # fold weak hands this % of the time in early position
        self.aggression_factor = 1.2  # multiplier on raise size when aggressive
        self.opp_bet_patterns = {}  # track opponent tendencies
        self.volatility_factor = 0.1  # for randomizing actions slightly to avoid predictability
        self.equity_floor = 0.4  # minimum equity to call a big bet
        self.bluff_frequency = 0.15  # 15% chance to bluff with draw or weak hand
        self.tightness_stage = 0  # 0 = tight, 1 = loose-aggressive, adjusted based on stack

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2
        self.current_hole_cards = player_hands
        self.player_id = str(self.id)
        for pid in all_players:
            self.opp_bet_patterns[str(pid)] = {"aggressive": 0, "passive": 0, "total": 0}
        self.tightness_stage = 0 if starting_chips >= 8000 else 1  # go looser if short stacked

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_hole_cards = []  # will be updated via game mechanics (only visible if still in hand)
        # We can't access hole cards here; need to infer based on prior logic
        # Just reset any round-specific state if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract self player state
        player_id_str = str(self.id)
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_size = round_state.pot
        community_cards = round_state.community_cards
        player_bet = round_state.player_bets.get(player_id_str, 0)
        call_amount = current_bet - player_bet

        # Determine hand strength and round
        hole_cards = self._get_hole_cards_from_history()
        hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        is_preflop = round_state.round == 'Preflop'
        is_postflop = not is_preflop
        pot_odds = self._calculate_pot_odds(call_amount, pot_size)
        equity_vs_random = self._estimate_equity(hole_cards, community_cards)

        # Update opponent tendency tracking
        self._update_opponent_patterns(round_state)

        # Adjust strategy based on stack depth
        stack_depth_bb = remaining_chips / self.big_blind_amount if self.big_blind_amount > 0 else 100
        if stack_depth_bb < 10:
            self.tightness_stage = 1  # Jam or fold when short-stacked

        # Position: True if we act late (current player includes us and others after)
        active_player_ids = [str(pid) for pid in round_state.current_player]
        my_index = active_player_ids.index(player_id_str) if player_id_str in active_player_ids else -1
        total_players_active = len(active_player_ids)
        in_position = (my_index == total_players_active - 1) if my_index != -1 else False

        # Action Decision Logic
        if is_preflop:
            action, amount = self._preflop_strategy(hole_cards, call_amount, min_raise, max_raise, remaining_chips, in_position)
        else:
            # Post-flop decision using hand strength and board texture
            action, amount = self._postflop_strategy(
                hole_cards, community_cards, hand_strength, equity_vs_random,
                call_amount, min_raise, max_raise, pot_size, pot_odds,
                in_position, remaining_chips
            )

        # Ensure valid action and amount
        action, amount = self._validate_action(action, amount, call_amount, min_raise, max_raise, current_bet, player_bet, remaining_chips)

        return action, amount

    def _preflop_strategy(self, hole_cards, call_amount, min_raise, max_raise, remaining_chips, in_position):
        hand_key = self._get_hand_key(hole_cards)
        is_raised = call_amount > self.big_blind_amount

        # Identify hand tier
        if hand_key in self.strong_hands:
            if call_amount == 0:
                # Open raise
                raise_amount = min(3 * self.big_blind_amount, remaining_chips)
                return PokerAction.RAISE, raise_amount
            else:
                # Facing a raise, 3-bet or call
                if is_raised and remaining_chips > 1000:
                    three_bet = min(call_amount * 2, max_raise)
                    return PokerAction.RAISE, three_bet
                return PokerAction.CALL, 0

        elif hand_key in self.medium_hands:
            if call_amount == 0:
                open_raise = min(3 * self.big_blind_amount, remaining_chips)
                return PokerAction.RAISE, open_raise
            elif not is_raised:
                return PokerAction.CALL, 0
            else:
                # Facing raise, fold unless deep stacked
                if remaining_chips < 500:
                    return PokerAction.FOLD, 0
                return PokerAction.CALL, 0

        else:
            # Weak hand
            if call_amount == 0:
                # Limp in small ball style sometimes
                if random.random() < 0.3:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                # Fold to opens unless suited connectors or small pair and cheap to see
                if self._is_speculative_hand(hole_cards) and call_amount <= 2 * self.big_blind_amount:
                    if random.random() < 0.5:
                        return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        return PokerAction.FOLD, 0

    def _postflop_strategy(self, hole_cards, community_cards, hand_strength, equity, call_amount, min_raise, max_raise, pot_size, pot_odds, in_position, remaining_chips):
        hand_rank = self._get_hand_rank(hole_cards, community_cards)
        made_hand = hand_rank >= 3  # pair or better
        has_draw = self._has_strong_draw(hole_cards, community_cards)
        draw_equity = self._estimate_draw_equity(hole_cards, community_cards) if has_draw else 0.0
        effective_equity = max(equity, draw_equity)

        # Bluffing logic with randomness
        is_bluffing = False
        if not made_hand and random.random() < self.bluff_frequency and in_position and len(community_cards) >= 3:
            is_bluffing = True

        # Leading with equity or draw
        if call_amount == 0:
            if made_hand or has_draw or is_bluffing:
                # Bet for value or bluff
                bet_size = min(int(pot_size * (0.5 + random.uniform(-0.1, 0.2))), max_raise)
                bet_size = max(min_raise, bet_size) if bet_size > 0 else min_raise
                return PokerAction.RAISE, bet_size
            else:
                # Check weak hand
                return PokerAction.CHECK, 0

        # Facing a bet
        if effective_equity >= self.equity_floor or (has_draw and draw_equity >= pot_odds):
            if effective_equity > 0.7 and remaining_chips > 1000:
                # Raise for value
                raise_size = min(int(pot_size * 0.75), max_raise)
                return PokerAction.RAISE, raise_size
            else:
                # Call with draw or decent equity
                return PokerAction.CALL, 0
        else:
            # Fold if equity too low
            return PokerAction.FOLD, 0

        return PokerAction.FOLD, 0

    def _get_hand_rank(self, hole_cards: List[str], community_cards: List[str]) -> int:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._evaluate_hand_strength(hole_cards, community_cards)

        # Simplified hand strength ranking: High card = 1, One pair = 2, etc.
        ranks = '23456789TJQKA'
        suits = 'cdhs'
        rank_count = {r: 0 for r in ranks}
        suit_count = {s: 0 for s in suits}
        card_rank_vals = []

        for card in all_cards:
            r, s = card[0], card[1]
            rank_count[r] += 1
            suit_count[s] += 1
            card_rank_vals.append(ranks.index(r))

        sorted_ranks = sorted(card_rank_vals, reverse=True)
        rank_vals = list(rank_count.values())
        flush = max(suit_count.values()) >= 5
        straight = False

        distinct_ranks = sorted([ranks.index(r) for r in rank_count if rank_count[r] > 0], reverse=True)
        for i in range(len(distinct_ranks) - 4):
            if distinct_ranks[i] - distinct_ranks[i+4] == 4:
                straight = True
                break
        # Wheel straight
        if set('A2345') <= set(rank_count.keys()):
            straight = True

        # Check combinations
        if flush and straight:
            return 9  # Straight flush
        if 4 in rank_vals:
            return 8  # Four of a kind
        if 3 in rank_vals and 2 in rank_vals or rank_vals.count(3) >= 2:
            return 7  # Full house
        if flush:
            return 6  # Flush
        if straight:
            return 5  # Straight
        if 3 in rank_vals:
            return 4  # Three of a kind
        if rank_vals.count(2) >= 2:
            return 3  # Two pair
        if 2 in rank_vals:
            return 2  # One pair
        return 1  # High card

    def _has_strong_draw(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        if len(community_cards) < 3:
            return False
        all_cards = hole_cards + community_cards
        ranks = '23456789TJQKA'
        suits = 'cdhs'
        suit_count = {s: 0 for s in suits}
        for card in all_cards:
            suit_count[card[1]] += 1
        # Flush draw: 4 cards of same suit
        if max(suit_count.values()) == 4 and any(suit_count[c[1]] == 4 for c in hole_cards):
            return True
        # Straight draw: check connected cards
        hole_ranks = [c[0] for c in hole_cards]
        board_ranks = [c[0] for c in community_cards]
        all_ranks = hole_ranks + board_ranks
        rank_indices = sorted(set(ranks.index(r) for r in all_ranks))
        for i in range(len(rank_indices) - 2):
            if rank_indices[i+2] - rank_indices[i] <= 4:
                return True
        return False

    def _estimate_draw_equity(self, hole_cards: List[str], community_cards: List[str]) -> float:
        has_flush_draw = self._has_strong_draw(hole_cards, community_cards) and \
                         max([sum(1 for c in hole_cards + community_cards if c[1] == s) for s in 'cdhs']) == 4
        has_straight_draw = self._has_strong_draw(hole_cards, community_cards) and not has_flush_draw

        outs = 0
        if has_flush_draw:
            outs = 9  # 13 - 4 seen
        if has_straight_draw:
            outs = 8  # open-ended

        if outs == 0:
            return 0.0

        # Approximate equity: outs * 2 per street
        remaining_cards = 46 if len(community_cards) == 3 else 44
        return min(outs / remaining_cards, 0.4)

    def _is_speculative_hand(self, hole_cards: List[str]) -> bool:
        ranks = '23456789TJQKA'
        c1, c2 = hole_cards[0], hole_cards[1]
        r1, s1 = c1[0], c1[1]
        r2, s2 = c2[0], c2[1]
        rank_diff = abs(ranks.index(r1) - ranks.index(r2))
        is_suited = s1 == s2
        is_pair = r1 == r2
        is_connectors = rank_diff == 1
        is_small_gap = rank_diff == 2

        return (is_suited and (is_connectors or is_small_gap)) or is_pair

    def _get_hand_key(self, hole_cards: List[str]) -> str:
        if not hole_cards or len(hole_cards) < 2:
            return "XX"
        ranks = '23456789TJQKA'
        c1, c2 = hole_cards[0], hole_cards[1]
        r1, s1 = c1[0], c1[1]
        r2, s2 = c2[0], c2[1]
        rank1, rank2 = ranks.index(r1), ranks.index(r2)
        if rank1 < rank2:
            r1, r2 = r2, r1
            s1, s2 = s2, s1
        suited = 's' if s1 == s2 else 'o'
        if r1 == r2:
            return r1 + r2
        return r1 + r2 + suited

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if not hole_cards:
            return 0.1
        if len(community_cards) == 0:
            hand_key = self._get_hand_key(hole_cards)
            if hand_key in self.strong_hands:
                return 0.8
            elif hand_key in self.medium_hands:
                return 0.5
            elif self._is_speculative_hand(hole_cards):
                return 0.3
            else:
                return 0.1
        else:
            # Estimate equity via simplified rules
            return self._estimate_equity(hole_cards, community_cards)

    def _estimate_equity(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # Very basic equity estimation
        if len(community_cards) == 0:
            # Pre-flop based on known tables
            hand_key = self._get_hand_key(hole_cards)
            if hand_key in ['AA', 'KK']:
                return 0.82
            elif hand_key in ['QQ', 'JJ', 'AKs']:
                return 0.72
            elif hand_key in ['TT', 'AKo', 'AQs']:
                return 0.65
            elif self._is_speculative_hand(hole_cards):
                return 0.45
            else:
                return 0.3
        else:
            # Post-flop: use hand rank as proxy
            rank = self._get_hand_rank(hole_cards, community_cards)
            if rank >= 8:
                return 0.95
            elif rank >= 6:
                return 0.75
            elif rank >= 4:
                return 0.55
            elif rank >= 3:
                return 0.4
            elif self._has_strong_draw(hole_cards, community_cards):
                return 0.35
            else:
                return 0.2

    def _calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        if pot_size + call_amount == 0:
            return 0.0
        return call_amount / (pot_size + call_amount + 1e-8)  # avoid divide by zero

    def _update_opponent_patterns(self, round_state: RoundStateClient):
        player_id_str = str(self.id)
        for pid, action in round_state.player_actions.items():
            if pid == player_id_str:
                continue
            if pid not in self.opp_bet_patterns:
                self.opp_bet_patterns[pid] = {"aggressive": 0, "passive": 0, "total": 0}
            self.opp_bet_patterns[pid]["total"] += 1
            if action in ['RAISE', 'BET', 'ALL_IN']:
                self.opp_bet_patterns[pid]["aggressive"] += 1
            elif action in ['CHECK', 'CALL']:
                self.opp_bet_patterns[pid]["passive"] += 1

    def _get_hole_cards_from_history(self) -> List[str]:
        # Since we don't get hole cards directly in get_action, assume we maintain them via logic
        # In practice, this should be passed down through game flow
        # For now, simulate access — this is a limitation of the interface
        # We assume hole cards are retained from on_start or stored during play
        # As a fallback, if we don't have them, return empty
        return self.current_hole_cards if self.current_hole_cards else []

    def _validate_action(self, action: PokerAction, amount: int, call_amount: int, min_raise: int, max_raise: int, current_bet: int, player_bet: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Ensure amount is within bounds
        if action == PokerAction.RAISE:
            min_valid_raise = current_bet + min_raise
            total_raise_amount = player_bet + amount
            if total_raise_amount < min_valid_raise:
                amount = min_valid_raise - player_bet
            if amount <= 0:
                action = PokerAction.CALL
            elif amount >= remaining_chips:
                action = PokerAction.ALL_IN
                amount = remaining_chips
        elif action == PokerAction.CALL:
            amount = call_amount
            if amount == 0:
                action = PokerAction.CHECK
        elif action == PokerAction.ALL_IN:
            amount = remaining_chips
        elif action == PokerAction.FOLD or action == PokerAction.CHECK:
            amount = 0

        # Final bounds check
        if amount < 0:
            amount = 0
        if amount > remaining_chips:
            amount = remaining_chips
            action = PokerAction.ALL_IN

        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Record round outcome, update strategies
        self.hand_history.append({
            'round': round_state.round,
            'pot': round_state.pot,
            'community_cards': round_state.community_cards.copy(),
            'final_bet': round_state.player_bets.get(str(self.id), 0),
            'chips_left': remaining_chips
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or stats
        pass