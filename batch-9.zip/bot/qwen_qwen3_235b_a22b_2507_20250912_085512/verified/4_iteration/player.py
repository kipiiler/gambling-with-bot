from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re
from collections import defaultdict

# Helper functions for card evaluation
def parse_card(card: str) -> Tuple[int, str]:
    """Convert card string to (rank, suit). Rank: 2-14 (Ace=14), Suit: 'h','d','c','s'"""
    if len(card) == 2:
        r, s = card[0], card[1]
    else:
        r, s = card[0:2], card[2]  # For '10h' etc.
    rank_map = {'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    rank = rank_map.get(r) or (10 if r == 'T' else int(r))
    return (rank, s)

def hand_rank(cards: List[str]) -> Tuple[int, List[int]]:
    """Evaluate best 5-card hand from list of 2-7 cards and return hand strength tuple."""
    if len(cards) == 0:
        return (0, [])
    parsed_cards = [parse_card(c) for c in cards]
    ranks = sorted([r for r, s in parsed_cards], reverse=True)
    suits = [s for r, s in parsed_cards]
    rank_count = defaultdict(int)
    suit_count = defaultdict(list)
    for r, s in parsed_cards:
        rank_count[r] += 1
        suit_count[s].append(r)
    
    # Sort each suit's ranks descending
    for s in suit_count:
        suit_count[s].sort(reverse=True)
    
    # Check flushes
    flush_suit = None
    for s, rs in suit_count.items():
        if len(rs) >= 5:
            flush_suit = s
            flush_ranks = sorted(rs, reverse=True)[:5]
            break
    
    # Check straight
    unique_ranks = sorted(set(ranks), reverse=True)
    # Add A=1 for low straights
    if 14 in unique_ranks:
        unique_ranks.append(1)
        unique_ranks.sort(reverse=True)
    straight_high = None
    seq = 1
    for i in range(1, len(unique_ranks)):
        if unique_ranks[i-1] == unique_ranks[i] + 1:
            seq += 1
            if seq == 5:
                straight_high = unique_ranks[i-4]
                if straight_high == 1: straight_high = 14  # Convert A-5 straight
                break
        else:
            seq = 1

    # Four of a kind
    fours = [r for r, c in rank_count.items() if c == 4]
    if fours:
        kickers = sorted([r for r in ranks if r != fours[0]], reverse=True)[:1]
        return (7, [fours[0]] + kickers)

    # Full house
    triples = [r for r, c in rank_count.items() if c == 3]
    pairs = [r for r, c in rank_count.items() if c >= 2 and r not in triples]
    if triples and pairs:
        return (6, [triples[0], pairs[0]])
    if len(triples) >= 2:
        return (6, [triples[0], triples[1]])

    # Flush
    if flush_suit:
        return (5, flush_ranks)

    # Straight
    if straight_high:
        return (4, [straight_high])

    # Three of a kind
    if triples:
        kickers = sorted([r for r in ranks if r != triples[0]], reverse=True)[:2]
        return (3, [triples[0]] + kickers)

    # Two pair
    if len(pairs) >= 2:
        top_two = sorted(pairs, reverse=True)[:2]
        kicker = max([r for r in ranks if r not in top_two], default=0)
        return (2, top_two + [kicker])

    # One pair
    if pairs:
        kickers = sorted([r for r in ranks if r != pairs[0]], reverse=True)[:3]
        return (1, [pairs[0]] + kickers)

    # High card
    return (0, ranks[:5])

def hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    """Estimate hand strength as a value between 0 and 1."""
    all_cards = hole_cards + community_cards
    score, kickers = hand_rank(all_cards)
    
    # Start with base strength
    strength = score * 0.1  # 0.0 to 0.7 for high card to four of a kind
    if score == 0:
        # High card: use top 5 cards
        kicker_strength = sum(k for k in kickers) / (14 * 5)
        return 0.0 + kicker_strength * 0.1
    elif score == 1:
        # One pair: pair + kickers
        total = kickers[0] * 0.7 + sum(kickers[1:]) * 0.1
        return 0.1 + total / (14 * 2)
    elif score == 2:
        # Two pair
        total = sum(kickers[:2]) * 0.5 + kickers[2] * 0.2
        return 0.2 + total / (14 * 2.2)
    else:
        # Higher hands
        return strength + 0.05  # Base bonus

def preflop_hand_rank(card1: str, card2: str) -> float:
    """Evaluate preflop hand strength using Chen formula approximation."""
    r1, s1 = parse_card(card1)
    r2, s2 = parse_card(card2)
    
    # Highest card
    high = max(r1, r2)
    low = min(r1, r2)
    
    score = 0.0
    # High card points
    if high > 10:
        score += high - 10
    elif high == 10:
        score += 5
    else:
        score += high / 2.0
    
    # Pair bonus
    if r1 == r2:
        score *= 2
        if score < 5:
            score = 5
    
    # Suited bonus
    if s1 == s2:
        score += 2
    
    # Gap penalty
    gap = high - low - 1
    if gap == 1:
        score -= 1
    elif gap == 2:
        score -= 2
    elif gap == 3:
        score -= 4
    elif gap >= 4:
        score -= 5
    
    # Connected small cards
    if gap == 0 and low >= 11:  # Broadways connected
        score += 1
    
    # Scale to 0-10
    score = max(0, min(10, score))
    return score / 10.0  # Normalize to 0-1

def is_draw_possible(cards: List[str], hand_type: str) -> bool:
    """Check if there's a possible draw (flush or straight)."""
    if len(cards) < 4:
        return False
    parsed = [parse_card(c) for c in cards]
    ranks = [r for r, s in parsed]
    suits = [s for r, s in parsed]
    suit_count = defaultdict(int)
    rank_count = defaultdict(int)
    for s in suits:
        suit_count[s] += 1
    for r in ranks:
        rank_count[r] += 1
    
    if hand_type == "flush":
        return any(count >= 4 for count in suit_count.values())
    
    if hand_type == "straight":
        unique_ranks = sorted(set(ranks))
        if 14 in unique_ranks:
            unique_ranks.append(1)  # Ace low
        unique_ranks.sort()
        consecutive = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i] == unique_ranks[i-1] + 1:
                consecutive += 1
                if consecutive >= 4:
                    return True
            else:
                consecutive = 1
                if unique_ranks[i] - unique_ranks[i-1] > 4:
                    # Too far apart, can't form 4-straight
                    break
        return False
    
    return False

def pot_odds(pot: int, call_amount: int) -> float:
    """Calculate pot odds ratio. Return very small if division by zero."""
    return call_amount / (pot + call_amount + 1e-8)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 10
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.last_action = None
        self.position_history = []  # Track our position relative to dealer
        self.aggression_factor = 0.0
        self.total_decisions = 0
        self.voluntary_put_in_pot = 0
        self.hands_played = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Extract relevant info
            current_player = round_state.current_player[0] if round_state.current_player else None
            if current_player != self.id:
                return (PokerAction.FOLD, 0)  # Shouldn't happen
            
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            player_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, current_bet - player_bet)
            pot = round_state.pot
            community_cards = round_state.community_cards
            round_name = round_state.round.lower()

            # Get our hole cards
            hole_cards = self.player_hands.get(str(self.id), [])
            if not hole_cards:
                # Cannot play without hole cards
                return (PokerAction.FOLD, 0)

            # Default action and bet
            action = PokerAction.FOLD
            amount = 0

            # Evaluate hand strength
            if len(community_cards) == 0:
                # Preflop
                strength = preflop_hand_rank(hole_cards[0], hole_cards[1])
            else:
                # Postflop
                strength = hand_strength(hole_cards, community_cards)

            # Determine position: if we are one of the last to act
            active_players = list(round_state.player_bets.keys())
            our_index = active_players.index(str(self.id)) if str(self.id) in active_players else -1
            last_to_act = our_index == len(active_players) - 1 if our_index != -1 else False
            in_position = last_to_act

            # Pot odds
            call_odds = pot_odds(pot, call_amount)
            
            # Decision logic
            effective_strength = strength
            if in_position:
                effective_strength += 0.1  # Slight boost for position
            if len(community_cards) >= 3 and is_draw_possible(hole_cards + community_cards, "flush"):
                effective_strength += 0.15
            if len(community_cards) >= 3 and is_draw_possible(hole_cards + community_cards, "straight"):
                effective_strength += 0.1

            # Adjust for stack size (short stack play tighter)
            stack_pressure = (self.starting_chips - remaining_chips) / (self.starting_chips + 1e-8)
            if stack_pressure > 0.5 and remaining_chips < 20 * self.blind_amount:
                # Short stack mode
                if strength > 0.7:
                    if call_amount == 0:
                        action = PokerAction.RAISE
                        amount = min(remaining_chips // 4, min_raise * 2, remaining_chips)
                    else:
                        if effective_strength > 0.75:
                            action = PokerAction.RAISE
                            amount = min(remaining_chips // 3, max_raise)
                        else:
                            action = PokerAction.CALL
                elif call_amount == 0:
                    action = PokerAction.CHECK if current_bet == 0 else PokerAction.CALL
                else:
                    if effective_strength > call_odds:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
            else:
                # Normal play
                if call_amount == 0:
                    if effective_strength > 0.4:
                        action = PokerAction.RAISE
                        amount = min(remaining_chips // 5, max(min_raise * 3, 2 * self.blind_amount), max_raise)
                    else:
                        action = PokerAction.CHECK
                else:
                    # Facing a bet
                    if effective_strength > 0.7:
                        if remaining_chips > 3 * call_amount:
                            action = PokerAction.RAISE
                            raise_amount = min(call_amount * 2, remaining_chips // 3, max_raise)
                            amount = max(raise_amount, min_raise)
                        else:
                            action = PokerAction.CALL if effective_strength > 0.75 else PokerAction.ALL_IN
                    elif effective_strength > 0.5:
                        if effective_strength > call_odds:
                            action = PokerAction.CALL
                        else:
                            action = PokerAction.FOLD
                    elif effective_strength > 0.3 and random.random() < 0.3:
                        action = PokerAction.CALL
                    else:
                        if effective_strength > call_odds * 1.5:
                            action = PokerAction.CALL
                        else:
                            action = PokerAction.FOLD

            # Enforce valid actions
            if action == PokerAction.RAISE:
                amount = max(amount, min_raise)
                amount = min(amount, max_raise)
                if amount <= player_bet:
                    action = PokerAction.CALL
                else:
                    amount = min(amount, remaining_chips)
            elif action == PokerAction.CALL:
                amount = 0  # Server handles call amount
            elif action == PokerAction.ALL_IN:
                amount = 0  # Server knows to go all in
            elif action == PokerAction.CHECK:
                if current_bet > player_bet:
                    # Cannot check behind when bet is outstanding
                    if call_amount <= remaining_chips:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
            elif action == PokerAction.FOLD:
                amount = 0

            # Final check
            if action not in [PokerAction.FOLD, PokerAction.CHECK, PokerAction.CALL, PokerAction.RAISE, PokerAction.ALL_IN]:
                action = PokerAction.FOLD
                
            return (action, amount)
            
        except Exception as e:
            # Safety fallback
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update stats
        self.total_decisions += 1
        # Optional: learn from round outcome
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional cleanup
        self.player_hands.clear()
        self.position_history.clear()