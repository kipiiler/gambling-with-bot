from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = {}
        self.hole_cards = []
        self.equity_history = []
        self.position_status = ""

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_hands = {str(pid): [] for pid in all_players}
        if str(self.id) in self.player_hands:
            self.hole_cards = player_hands.copy() if player_hands else []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self._update_position_status(round_state)
        self.hole_cards = self.player_hands.get(str(self.id), []).copy()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = remaining_chips
        pot = round_state.pot
        community_cards = round_state.community_cards

        # Ensure hole_cards are initialized
        if not self.hole_cards:
            # If we don't have hole cards, fold
            return (PokerAction.FOLD, 0)

        # Extract current player bets
        player_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - player_bet

        # If no bet, we can check
        if to_call == 0:
            # Decide whether to check or raise
            if self._should_raise(round_state, remaining_chips, pot, community_cards):
                raise_amount = min(max(min_raise, pot // 3), max_raise)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CHECK, 0)

        # If we are required to call
        if to_call > 0:
            # If they are all-in or high pressure
            if to_call >= remaining_chips:
                equity = self._estimate_equity(self.hole_cards, community_cards)
                min_equity = self._get_min_call_equity(round_state, pot, to_call)
                if equity >= min_equity:
                    return (PokerAction.ALL_IN, remaining_chips)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Facing a raise, decide whether to fold, call, or re-raise
                equity = self._estimate_equity(self.hole_cards, community_cards)
                min_equity = self._get_min_call_equity(round_state, pot, to_call)
                pot_odds = to_call / (pot + to_call) if (pot + to_call) > 0 else 0

                if equity >= min_equity:
                    if equity > pot_odds + 0.2 and remaining_chips > 0:
                        # Re-raise if we have strong equity
                        raise_amount = min(to_call * 2, max_raise)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    if random.random() < 0.1 and self._is_speculative_hand(self.hole_cards):
                        # Occasional bluff call with speculative hands
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

        # Fallback
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used to track performance or adjust strategy
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up if needed
        pass

    def _update_position_status(self, round_state: RoundStateClient):
        if self.id is None:
            self.position_status = "unknown"
            return
        current_pos = round_state.current_player[0] if round_state.current_player else -1
        # Approximate position: late if we act near the end, early otherwise
        active_players = len(round_state.current_player)
        if active_players == 0:
            self.position_status = "early"
        else:
            # Estimate position based on player count and blind roles
            try:
                idx = self.all_players.index(self.id)
                total = len(self.all_players)
                if (idx - self.big_blind_player_id) % total <= 2:
                    self.position_status = "early"
                elif (idx - self.big_blind_player_id) % total <= 4:
                    self.position_status = "middle"
                else:
                    self.position_status = "late"
            except:
                self.position_status = "unknown"

    def _should_raise(self, round_state: RoundStateClient, remaining_chips: int, pot: int, community_cards: List[str]) -> bool:
        equity = self._estimate_equity(self.hole_cards, community_cards)
        stage_multiplier = self._get_stage_multiplier(round_state.round)
        position_multiplier = self._get_position_multiplier(self.position_status)
        min_equity_to_raise = 0.5 / (stage_multiplier * position_multiplier + 1e-9)
        return equity > min_equity_to_raise and random.random() < 0.8

    def _get_stage_multiplier(self, game_round: str) -> float:
        multipliers = {
            "Preflop": 0.3,
            "Flop": 0.6,
            "Turn": 0.8,
            "River": 1.0
        }
        return multipliers.get(game_round, 0.5)

    def _get_position_multiplier(self, pos: str) -> float:
        multipliers = {
            "early": 0.8,
            "middle": 1.0,
            "late": 1.3,
            "unknown": 1.0
        }
        return multipliers.get(pos, 1.0)

    def _get_min_call_equity(self, round_state: RoundStateClient, pot: int, to_call: int) -> float:
        pot_odds = to_call / (pot + to_call + 1e-9)
        stage_risk = self._get_stage_risk(round_state.round)
        return max(pot_odds * stage_risk, 0.1)

    def _get_stage_risk(self, game_round: str) -> float:
        risks = {
            "Preflop": 2.0,
            "Flop": 1.5,
            "Turn": 1.2,
            "River": 1.0
        }
        return risks.get(game_round, 1.0)

    def _estimate_equity(self, hole_cards: List[str], community_cards: List[str]) -> float:
        if len(hole_cards) < 2:
            return 0.0  # Return 0 if no valid hand

        if len(community_cards) == 0:
            return self._preflop_hand_strength(hole_cards)

        # Use simple rule-based on post-flop strength
        hand_rank = self._evaluate_hand(hole_cards, community_cards)
        # Normalize rank to equity (very approximate)
        max_rank = 9  # Royal flush
        min_rank = 0  # High card
        normalized_rank = (max_rank - hand_rank) / (max_rank - min_rank + 1e-9)
        return 0.3 + normalized_rank * 0.7  # Map to 0.3-1.0 range

    def _preflop_hand_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) < 2:
            return 0.0

        c1, c2 = hole_cards[0], hole_cards[1]

        rank1 = self._card_rank(c1[0])
        rank2 = self._card_rank(c2[0])
        suit1 = c1[1]
        suit2 = c2[1]

        is_suited = suit1 == suit2
        is_pair = rank1 == rank2
        gap = abs(rank1 - rank2)

        score = 0.0

        if is_pair:
            score += 5.0 + rank1 * 0.8
        if is_suited:
            score += 2.0
        if gap == 0:  # Pair
            pass  # Already handled
        elif gap == 1:  # Consecutive
            score += 3.0
        elif gap == 2:
            score += 2.0
        elif gap == 3:
            score += 1.0

        # Add some value for high cards
        score += max(rank1, rank2) * 0.5

        # Scale to [0, 1]
        score = min(score / 10.0, 1.0)
        return score

    def _card_rank(self, rank_char: str) -> int:
        ranks = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}
        return ranks.get(rank_char.upper(), 0)

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> int:
        # Return a hand rank: 9=royal flush, 8=straight flush, ..., 0=high card
        cards = hole_cards + community_cards
        if len(cards) < 5:
            return 0

        # Parse cards into (rank, suit)
        def parse_card(card: str):
            r = card[0].upper()
            s = card[1].lower()
            rank = {'2': 0, '3': 1, '4': 2, '5': 3, '6': 4, '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 'Q': 10, 'K': 11, 'A': 12}[r]
            return (rank, s)

        try:
            parsed = [parse_card(c) for c in cards]
        except:
            return 0

        suits = [s for _, s in parsed]
        ranks = [r for r, _ in parsed]

        # Sort ranks descending
        ranks = sorted(ranks, reverse=True)

        # Count frequencies
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1

        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        # Check flush
        flush_suit = None
        for s, cnt in suit_count.items():
            if cnt >= 5:
                flush_suit = s
                break

        # Check straight
        unique_ranks = sorted(set(ranks), reverse=True)
        # Add low ace if needed
        if 12 in unique_ranks:  # Ace
            unique_ranks.append(-1)  # Treat Ace as 0 for low straight

        straight_high = -1
        seq = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i-1] - unique_ranks[i] == 1:
                seq += 1
                if seq >= 5:
                    straight_high = unique_ranks[i-4]
                    break
            else:
                seq = 1

        # Reset: Ace as low straight
        if straight_high == -1 and 12 in unique_ranks and 0 in unique_ranks and 1 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks:
            straight_high = 3  # 5-high straight

        # Royal flush and straight flush
        if flush_suit:
            flush_cards = [r for (r, s) in parsed if s == flush_suit]
            flush_cards = sorted(set(flush_cards), reverse=True)
            if len(flush_cards) >= 5:
                # Check straight within flush
                seq = 1
                flush_straight_high = -1
                for i in range(1, len(flush_cards)):
                    if flush_cards[i-1] - flush_cards[i] == 1:
                        seq += 1
                        if seq >= 5:
                            flush_straight_high = flush_cards[i-4]
                            break
                    else:
                        seq = 1
                if flush_straight_high != -1:
                    if flush_straight_high == 12:  # Ace high
                        return 9  # Royal flush
                    else:
                        return 8  # Straight flush

        # Four of a kind
        if 4 in rank_count.values():
            return 7

        # Full house
        if 3 in rank_count.values() and 2 in rank_count.values():
            return 6

        # Flush
        if flush_suit and len([r for (r,s) in parsed if s == flush_suit]) >= 5:
            return 5

        # Straight
        if straight_high != -1:
            return 4

        # Three of a kind
        if 3 in rank_count.values():
            return 3

        # Two pair
        pairs = sum(1 for v in rank_count.values() if v == 2)
        if pairs >= 2:
            return 2

        # One pair
        if pairs == 1:
            return 1

        # High card
        return 0

    def _is_speculative_hand(self, hole_cards: List[str]) -> bool:
        if len(hole_cards) < 2:
            return False  # Safeguard against empty or single card
        c1, c2 = hole_cards[0], hole_cards[1]
        rank1 = self._card_rank(c1[0])
        rank2 = self._card_rank(c2[0])
        suit1 = c1[1]
        suit2 = c2[1]
        gap = abs(rank1 - rank2)
        is_suited = suit1 == suit2
        
        # Suited connectors or one-gappers, or small pairs
        if is_suited and gap <= 2:
            return True
        if gap == 0 and rank1 <= 7:  # Small pairs
            return True
        if gap == 1 and max(rank1, rank2) <= 9:  # Medium-low connectors
            return True
        return False