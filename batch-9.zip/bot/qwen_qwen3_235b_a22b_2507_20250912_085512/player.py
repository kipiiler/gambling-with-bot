from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re
import math

# Helper functions for hand evaluation
def parse_card(card: str):
    """Parse card string into value and suit"""
    if len(card) == 2:
        rank, suit = card[0], card[1]
    else:
        rank, suit = card[0:-1], card[-1]
    value_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    rank_val = value_map.get(rank.upper(), int(rank) if rank.isdigit() else 0)
    return rank_val, suit

def card_rank(card: str) -> int:
    """Return numerical rank of card"""
    r = card[0].upper()
    if r == 'A': return 14
    if r == 'K': return 13
    if r == 'Q': return 12
    if r == 'J': return 11
    if r == 'T': return 10
    return int(r)

def evaluate_hand(hole_cards: List[str], community_cards: List[str]) -> tuple:
    """Evaluate the best 5-card hand strength (returns a tuple for comparison)"""
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        return (0, 0, 0, 0, 0, 0, 0)  # Not enough cards yet

    # Parse all cards
    parsed = [parse_card(c) for c in all_cards]
    ranks = sorted([p[0] for p in parsed], reverse=True)
    suits = [p[1] for p in parsed]

    # Count ranks and suits
    rank_count = {}
    suit_count = {}
    for r, s in zip(ranks, suits):
        rank_count[r] = rank_count.get(r, 0) + 1
        suit_count[s] = suit_count.get(s, 0) + 1

    # Sort by count then rank
    sorted_ranks_by_count = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)
    values_by_freq = []
    for rk, cnt in sorted_ranks_by_count:
        values_by_freq.extend([rk] * cnt)

    # Check flush
    flush_suit = None
    for suit, count in suit_count.items():
        if count >= 5:
            flush_suit = suit
            break

    # Get flush cards if exists
    if flush_suit:
        flush_ranks = sorted([parse_card(c)[0] for c in all_cards if c[1] == flush_suit], reverse=True)
    else:
        flush_ranks = []

    # Check straight
    unique_ranks = sorted(set(ranks), reverse=True)
    # Add low ace for A-5 straight
    if 14 in unique_ranks:
        unique_ranks.append(1)

    straight_high = 0
    for i in range(len(unique_ranks) - 4):
        if unique_ranks[i] == unique_ranks[i+1] + 1 == unique_ranks[i+2] + 2 == unique_ranks[i+3] + 3 == unique_ranks[i+4] + 4:
            straight_high = unique_ranks[i]
            break

    # Check straight flush
    straight_flush_high = 0
    if flush_suit:
        flush_only_ranks = sorted([r for r in unique_ranks if parse_card_from_rank(r) + flush_suit in all_cards], reverse=True)
        for i in range(len(flush_only_ranks) - 4):
            if flush_only_ranks[i] == flush_only_ranks[i+1] + 1 == flush_only_ranks[i+2] + 2 == flush_only_ranks[i+3] + 3 == flush_only_ranks[i+4] + 4:
                straight_flush_high = flush_only_ranks[i]
                break

    # Royal flush
    if straight_flush_high == 14:
        return (9,)

    # Straight flush
    if straight_flush_high > 0:
        return (8, straight_flush_high)

    # Four of a kind
    if 4 in rank_count.values():
        quad_rank = None
        kicker = 0
        for r, cnt in rank_count.items():
            if cnt == 4:
                quad_rank = r
            elif cnt == 1:
                kicker = max(kicker, r)
        kicker = kicker if kicker > 0 else max(r for r in ranks if rank_count[r] != 4)
        return (7, quad_rank, kicker)

    # Full house
    if 3 in rank_count.values() and 2 in rank_count.values():
        trips = None
        pair = None
        for r, cnt in sorted_ranks_by_count:
            if cnt == 3 and trips is None:
                trips = r
            elif cnt == 2 and pair is None:
                pair = r
        return (6, trips, pair)
    if list(rank_count.values()).count(3) >= 2:  # Two trips, use higher trips + lower as pair
        trips_ranks = [r for r, cnt in rank_count.items() if cnt == 3]
        trips_ranks.sort(reverse=True)
        return (6, trips_ranks[0], trips_ranks[1])

    # Flush
    if flush_suit and len(flush_ranks) >= 5:
        return (5,) + tuple(flush_ranks[:5])

    # Straight
    if straight_high > 0:
        return (4, straight_high)

    # Three of a kind
    if 3 in rank_count.values():
        trips_rank = None
        kickers = []
        for r, cnt in rank_count.items():
            if cnt == 3:
                trips_rank = r
            elif cnt == 1:
                kickers.append(r)
        kickers.sort(reverse=True)
        return (3, trips_rank, kickers[0], kickers[1])

    # Two pair
    pairs = [r for r, cnt in rank_count.items() if cnt == 2]
    if len(pairs) >= 2:
        pairs.sort(reverse=True)
        kicker = max([r for r, cnt in rank_count.items() if cnt == 1] + [0])
        return (2, pairs[0], pairs[1], kicker)

    # One pair
    if 2 in rank_count.values():
        pair_rank = max([r for r, cnt in rank_count.items() if cnt == 2])
        kickers = sorted([r for r, cnt in rank_count.items() if cnt == 1], reverse=True)
        return (1, pair_rank, kickers[0], kickers[1], kickers[2])

    # High card
    return (0,) + tuple(sorted(ranks, reverse=True)[:5])

def parse_card_from_rank(rank: int) -> str:
    """Convert rank number back to card string"""
    if rank == 14: return 'A'
    if rank == 13: return 'K'
    if rank == 12: return 'Q'
    if rank == 11: return 'J'
    if rank == 10: return 'T'
    return str(rank)

def hand_strength(hole_cards: List[str], community_cards: List[str]) -> float:
    """Estimate hand strength as a number between 0 and 1"""
    if not community_cards:
        # Pre-flop: use pocket strength heuristic
        c1, c2 = hole_cards
        r1, r2 = card_rank(c1), card_rank(c2)
        suited = 1 if c1[1] == c2[1] else 0
        pair = 2 if r1 == r2 else 0
        high_cards = (max(r1, r2) - 2) / 12.0
        connected = 0.5 if abs(r1 - r2) == 1 else 0.25 if abs(r1 - r2) == 2 else 0.1 if abs(r1 - r2) == 3 else 0
        
        # Pocket Aces = 1.0, 23o = ~0.1
        strength = 0.3 + 0.3*pair + 0.2*high_cards + 0.15*suited + 0.15*connected
        return min(strength, 1.0)
    
    # Post-flop: evaluate hand
    category_scores = {
        0: 0.05,    # High card
        1: 0.15,    # One pair
        2: 0.30,    # Two pair
        3: 0.45,    # Three of a kind
        4: 0.60,    # Straight
        5: 0.70,    # Flush
        6: 0.85,    # Full house
        7: 0.90,    # Four of a kind
        8: 0.98,    # Straight flush
        9: 1.00     # Royal flush
    }
    
    hand_value = evaluate_hand(hole_cards, community_cards)
    category = hand_value[0]
    
    return category_scores.get(category, 0.0)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.my_hole_cards = []
        self.position = None  # early, middle, late
        self.hand_strength_estimate = 0.0
        self.aggression_factor = 1.2  # Tune bet sizing
        self.tightness = 0.8   # 1.0 = very tight, 0.1 = loose
        self.volatility_threshold = 0.1  # How much to deviate from EV
        self.last_action_round = {}  # Track actions per round for learning

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): [] for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.my_hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round variables
        self.hand_strength_estimate = hand_strength(self.my_hole_cards, round_state.community_cards)
        
        # Estimate position based on number of players and seat
        num_players = len(round_state.player_bets)
        if self.id is not None:
            current_players_sorted = sorted(round_state.player_bets.keys(), key=lambda x: int(x))
            my_index = current_players_sorted.index(str(self.id))
            if my_index < num_players * 0.3:
                self.position = 'early'
            elif my_index < num_players * 0.7:
                self.position = 'middle'
            else:
                self.position = 'late'

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Extract current state
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise or remaining_chips
            pot = round_state.pot
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = current_bet - my_current_bet

            # Safety fallback
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            # Always ensure valid state
            if min_raise <= 0:
                min_raise = 2 * current_bet if current_bet > 0 else self.blind_amount * 2

            # Update hand strength
            self.hand_strength_estimate = hand_strength(self.my_hole_cards, round_state.community_cards)

            # Calculate pot odds
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-8)

            # Bet sizing
            recommended_raise = max(min_raise, int(pot * 0.75))
            all_in_threshold = remaining_chips < self.blind_amount * 10

            # Pre-flop adjustments
            is_preflop = round_state.round == 'Preflop'
            if is_preflop:
                # Use tighter ranges based on position
                c1, c2 = self.my_hole_cards
                r1, r2 = card_rank(c1), card_rank(c2)
                suited = 1 if c1[1] == c2[1] else 0
                pair = r1 == r2
                high_card = max(r1, r2)
                gap = abs(r1 - r2)
                
                # Define playable hands by position
                playable = False
                if self.position == 'late':
                    playable = (pair or high_card >= 10 or suited or gap <= 2)
                elif self.position == 'middle':
                    playable = (pair or high_card >= 11 or (suited and high_card >= 9))
                else:  # early
                    playable = (pair and high_card >= 10) or high_card >= 13  # Only strong hands
                
                if not playable:
                    return PokerAction.FOLD, 0

                # Raise first in if no raises yet
                if current_bet <= self.blind_amount * 2:  # Assume only blinds in
                    raise_amount = min(max(self.blind_amount * 3, min_raise), int(pot * 3))
                    return PokerAction.RAISE, min(raise_amount, remaining_chips)
                
                # Facing raise: only continue with strong hands
                strength = self.hand_strength_estimate
                if strength < 0.4:
                    return PokerAction.FOLD, 0
                if strength < 0.6 and amount_to_call > remaining_chips * 0.1:
                    return PokerAction.FOLD, 0

            # Post-flop logic
            else:
                # Strong hand -> value bet or raise
                if self.hand_strength_estimate > 0.7:
                    if current_bet == 0:
                        bet_size = min(int(pot * 0.75), max_raise)
                        return PokerAction.RAISE, max(min_raise, bet_size) if bet_size >= min_raise else PokerAction.CHECK, 0
                    else:
                        if amount_to_call < remaining_chips * 0.3 or all_in_threshold:
                            return PokerAction.RAISE, min(recommended_raise * 2, max_raise)
                        else:
                            return PokerAction.CALL, 0

                # Medium strength -> call or bet for value
                elif self.hand_strength_estimate > 0.4:
                    if current_bet == 0:
                        bet_size = min(int(pot * 0.6), max_raise)
                        return PokerAction.RAISE, max(min_raise, bet_size)
                    else:
                        if pot_odds < 0.3 or amount_to_call <= remaining_chips * 0.1:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0

                # Weak hand
                else:
                    if current_bet == 0:
                        # Small bet as bluff sometimes
                        if random.random() < self.volatility_threshold:
                            bluff_size = min(int(pot * 0.5), max_raise)
                            if bluff_size >= min_raise:
                                return PokerAction.RAISE, bluff_size
                        return PokerAction.CHECK, 0
                    else:
                        if pot_odds > 0.4 and random.random() < 0.3:  # Small chance to call bluff catch
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0

            # Default fallback: if we haven't returned yet
            if current_bet == 0:
                return PokerAction.CHECK, 0
            elif amount_to_call == 0:
                return PokerAction.CHECK, 0
            elif amount_to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            elif amount_to_call > remaining_chips * 0.3 and self.hand_strength_estimate < 0.6:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CALL, 0

        except Exception as e:
            # On any error, default to safe fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could track opponent behavior here for future learning
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or stats
        pass