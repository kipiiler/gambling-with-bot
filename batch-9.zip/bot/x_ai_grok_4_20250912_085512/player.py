from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
from itertools import combinations

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.blind_amount = blind_amount  # Assuming this is the big blind amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def _parse_card(self, card: str) -> Tuple[int, int]:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suit_map = {'h': 0, 's': 1, 'd': 2, 'c': 3}
        return rank_map[card[0]], suit_map[card[1]]

    def _evaluate_five(self, five_cards: List[Tuple[int, int]]) -> int:
        ranks = sorted([r for r, s in five_cards], reverse=True)
        suits = [s for r, s in five_cards]
        is_flush = all(s == suits[0] for s in suits)
        is_straight = all(ranks[i] == ranks[0] - i for i in range(1, 5))
        if not is_straight and ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]
        if is_flush and is_straight:
            if ranks == [14, 13, 12, 11, 10]:
                return 9 * 10**10
            return 8 * 10**10 + ranks[0] * 10**8
        rank_count = Counter(ranks)
        counts = sorted(rank_count.values(), reverse=True)
        if counts[0] == 4:
            quad_rank = next(r for r, c in rank_count.items() if c == 4)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return 7 * 10**10 + quad_rank * 10**8 + kicker * 10**6
        if counts == [3, 2]:
            three_rank = next(r for r, c in rank_count.items() if c == 3)
            pair_rank = next(r for r, c in rank_count.items() if c == 2)
            return 6 * 10**10 + three_rank * 10**8 + pair_rank * 10**6
        if is_flush:
            score = 5 * 10**10
            for i, r in enumerate(ranks):
                score += r * 10**(8 - 2 * i)
            return score
        if is_straight:
            return 4 * 10**10 + ranks[0] * 10**8
        if counts[0] == 3:
            three_rank = next(r for r, c in rank_count.items() if c == 3)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 3 * 10**10 + three_rank * 10**8 + kickers[0] * 10**6 + kickers[1] * 10**4
        if counts == [2, 2, 1]:
            pairs = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return 2 * 10**10 + pairs[0] * 10**8 + pairs[1] * 10**6 + kicker * 10**4
        if counts[0] == 2:
            pair_rank = next(r for r, c in rank_count.items() if c == 2)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return 1 * 10**10 + pair_rank * 10**8 + kickers[0] * 10**6 + kickers[1] * 10**4 + kickers[2] * 10**2
        score = 0
        for i, r in enumerate(ranks):
            score += r * 10**(8 - 2 * i)
        return score

    def _get_hand_score(self, hole: List[str], community: List[str]) -> int:
        all_cards = [self._parse_card(c) for c in hole + community]
        max_score = 0
        for comb in combinations(all_cards, 5):
            score = self._evaluate_five(list(comb))
            if score > max_score:
                max_score = score
        return max_score

    def _preflop_strength(self) -> float:
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.0
        r1, s1 = self._parse_card(self.hole_cards[0])
        r2, s2 = self._parse_card(self.hole_cards[1])
        if r1 < r2:
            r1, r2 = r2, r1
            s1, s2 = s2, s1
        suited = s1 == s2
        if r1 == r2:
            return 0.85 + (r1 - 2) / 12 * 0.15
        diff = r1 - r2
        base = 0.3 if diff > 4 else 0.4
        if suited:
            base += 0.1
        if diff <= 1:
            base += 0.1
        return base + (r1 / 14) * 0.3 + (r2 / 14) * 0.1

    def _postflop_strength(self, community: List[str]) -> float:
        score = self._get_hand_score(self.hole_cards, community)
        category = score // 10**10
        if category >= 8:
            return 1.0
        elif category >= 5:
            return 0.9 + (score % 10**10) / (10**10 * 0.9)
        elif category == 4:
            return 0.8
        elif category == 3:
            return 0.7
        elif category == 2:
            return 0.6
        elif category == 1:
            return 0.5
        else:
            return 0.3 + (score % 10**10) / (10**10 * 0.3)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if remaining_chips <= 0:
            return PokerAction.CHECK, 0
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0
        can_call = to_call > 0 and to_call <= remaining_chips
        min_raise_add = round_state.min_raise
        max_raise_add = round_state.max_raise

        pot = round_state.pot
        pot_odds = to_call / (pot + to_call + 1e-6) if to_call > 0 else 0

        if round_state.round == 'Preflop':
            strength = self._preflop_strength()
        else:
            strength = self._postflop_strength(round_state.community_cards)

        if strength > 0.8:
            # Aggressive with strong hand
            if remaining_chips <= to_call:
                return PokerAction.ALL_IN, 0
            raise_add = max(min_raise_add, int(pot * 0.75))
            raise_add = min(raise_add, max_raise_add)
            if raise_add >= min_raise_add:
                return PokerAction.RAISE, raise_add
            elif can_call:
                return PokerAction.CALL, 0
            elif can_check:
                return PokerAction.CHECK, 0
            return PokerAction.ALL_IN, 0
        elif strength > 0.5:
            # Call if pot odds good
            if can_check:
                return PokerAction.CHECK, 0
            elif can_call and pot_odds < 0.3:
                return PokerAction.CALL, 0
            elif to_call > 0 and remaining_chips > to_call and pot_odds < 0.2:
                raise_add = max(min_raise_add, int(pot * 0.5))
                raise_add = min(raise_add, max_raise_add)
                if raise_add >= min_raise_add:
                    return PokerAction.RAISE, raise_add
            return PokerAction.FOLD, 0
        else:
            # Fold weak, occasional bluff on river
            if round_state.round == 'River' and can_check and strength > 0.2 and pot > self.blind_amount * 10:
                return PokerAction.ALL_IN, 0  # Bluff all-in sometimes
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass