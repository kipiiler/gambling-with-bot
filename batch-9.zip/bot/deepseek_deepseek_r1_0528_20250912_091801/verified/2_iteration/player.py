import random
import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.id = None
        self.hole_cards = []
        self.big_blind = 0
        self.num_players = 0
        self.starting_chips = 0
        self.ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suits = ['h', 'd', 'c', 's']
        self.full_deck = [r + s for r in self.ranks.keys() for s in self.suits]
    
    def set_id(self, player_id: int) -> None:
        self.id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.num_players = len(all_players)
        if self.id is not None:
            idx = all_players.index(self.id)
            hand_str = player_hands[idx]
            self.hole_cards = [hand_str[i:i+2] for i in range(0, len(hand_str), 2)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            player_bets = round_state.player_bets
            our_current_bet = player_bets.get(str(self.id), 0)
            amount_to_call = current_bet - our_current_bet
            pot = round_state.pot
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            community_cards = round_state.community_cards
            round_stage = round_state.round

            if amount_to_call >= remaining_chips:
                return (PokerAction.ALL_IN, 0)

            if round_stage == 'Preflop':
                hand_score = self._preflop_hand_strength(self.hole_cards)
                if amount_to_call == 0:
                    if hand_score > 0.5:
                        raise_target = 3 * self.big_blind
                        if raise_target < current_bet + min_raise:
                            raise_target = current_bet + min_raise
                        if raise_target >= our_current_bet + remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.RAISE, raise_target)
                    elif hand_score > 0.2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    pot_odds = amount_to_call / (pot + amount_to_call + 1e-8)
                    required_win_prob = 1 / (1 + pot_odds)
                    if hand_score > required_win_prob:
                        if hand_score > 0.8:
                            raise_target = current_bet + min_raise
                            if raise_target >= our_current_bet + remaining_chips:
                                return (PokerAction.ALL_IN, 0)
                            else:
                                return (PokerAction.RAISE, raise_target)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                win_prob = self._monte_carlo_win_prob(self.hole_cards, community_cards, round_stage, len(round_state.current_player) - 1)
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    pot_odds = amount_to_call / (pot + amount_to_call + 1e-8)
                    required_win_prob = 1 / (1 + pot_odds)
                    if win_prob > required_win_prob:
                        if win_prob > 0.8:
                            raise_target = current_bet + min_raise
                            if raise_target >= our_current_bet + remaining_chips:
                                return (PokerAction.ALL_IN, 0)
                            else:
                                return (PokerAction.RAISE, raise_target)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        except Exception as e:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

    def _preflop_hand_strength(self, hole_cards):
        card1, card2 = hole_cards
        rank1 = self.ranks[card1[0]]
        rank2 = self.ranks[card2[0]]
        high = max(rank1, rank2)
        low = min(rank1, rank2)
        suited = card1[1] == card2[1]
        if rank1 == rank2:
            base = high * 2
        else:
            base = high + low / 2
            if suited:
                base *= 1.1
        normalized = base / 28.0
        return normalized

    def _evaluate_hand_five(self, cards):
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        card_tuples = []
        for card in cards:
            rank_char = card[0]
            suit = card[1]
            rank_val = rank_values[rank_char]
            card_tuples.append((rank_val, suit))
        
        card_tuples.sort(key=lambda x: x[0], reverse=True)
        ranks = [r for r, _ in card_tuples]
        suits = [s for _, s in card_tuples]
        
        flush_suit = None
        suit_count = {}
        for suit in suits:
            suit_count[suit] = suit_count.get(suit, 0) + 1
            if suit_count[suit] >= 5:
                flush_suit = suit
        flush_cards = [r for r, s in card_tuples if s == flush_suit] if flush_suit else []
        flush_cards.sort(reverse=True)
        if flush_suit:
            flush_cards = flush_cards[:5]
        
        unique_ranks = sorted(set(ranks), reverse=True)
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    straight_high = unique_ranks[i]
                    break
            if 14 in unique_ranks:
                if 5 in unique_ranks and 4 in unique_ranks and 3 in unique_ranks and 2 in unique_ranks:
                    straight_high = 5
        
        if flush_suit and straight_high:
            if flush_cards:
                unique_flush_ranks = sorted(set(flush_cards), reverse=True)
                straight_high_flush = 0
                if len(unique_flush_ranks) >= 5:
                    for i in range(len(unique_flush_ranks) - 4):
                        if unique_flush_ranks[i] - unique_flush_ranks[i+4] == 4:
                            straight_high_flush = unique_flush_ranks[i]
                            break
                    if 14 in unique_flush_ranks:
                        if 5 in unique_flush_ranks and 4 in unique_flush_ranks and 3 in unique_flush_ranks and 2 in unique_flush_ranks:
                            straight_high_flush = 5
                if straight_high_flush:
                    return (8 << 20) + (straight_high_flush << 16)
        
        if flush_suit:
            score = 5 << 20
            for i in range(5):
                if i < len(flush_cards):
                    score += flush_cards[i] << (16 - 4 * i)
            return score
        
        if straight_high:
            return (4 << 20) + (straight_high << 16)
        
        rank_count = {}
        for rank in ranks:
            rank_count[rank] = rank_count.get(rank, 0) + 1
        items = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)
        
        if items[0][1] == 4:
            score = 7 << 20
            score += items[0][0] << 16
            kicker = max(r for r in ranks if r != items[0][0])
            score += kicker << 12
            return score
        
        if items[0][1] == 3 and len(items) > 1 and items[1][1] >= 2:
            score = 6 << 20
            score += items[0][0] << 16
            score += items[1][0] << 12
            return score
        
        if items[0][1] == 3:
            score = 3 << 20
            score += items[0][0] << 16
            kickers = [r for r in ranks if r != items[0][0]]
            kickers.sort(reverse=True)
            score += kickers[0] << 12
            score += kickers[1] << 8
            return score
        
        if items[0][1] == 2 and len(items) > 1 and items[1][1] == 2:
            score = 2 << 20
            score += items[0][0] << 16
            score += items[1][0] << 12
            kicker = max(r for r in ranks if r != items[0][0] and r != items[1][0])
            score += kicker << 8
            return score
        
        if items[0][1] == 2:
            score = 1 << 20
            score += items[0][0] << 16
            kickers = [r for r in ranks if r != items[0][0]]
            kickers.sort(reverse=True)
            score += kickers[0] << 12
            score += kickers[1] << 8
            score += kickers[2] << 4
            return score
        
        score = 0
        for i in range(5):
            if i < len(ranks):
                score += ranks[i] << (16 - 4 * i)
        return score

    def _evaluate_hand(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        best_score = 0
        for combo in itertools.combinations(all_cards, 5):
            score = self._evaluate_hand_five(combo)
            if score > best_score:
                best_score = score
        return best_score

    def _monte_carlo_win_prob(self, hole_cards, community_cards, round_stage, num_opponents, n_simulations=100):
        if num_opponents <= 0:
            return 1.0
        
        base_deck = [card for card in self.full_deck if card not in hole_cards and card not in community_cards]
        wins = 0
        ties = 0
        
        for _ in range(n_simulations):
            deck = base_deck.copy()
            random.shuffle(deck)
            sim_community = community_cards.copy()
            
            if round_stage == 'Flop':
                sim_community.extend([deck.pop(), deck.pop()])
            elif round_stage == 'Turn':
                sim_community.append(deck.pop())
            
            opp_hands = []
            for _ in range(num_opponents):
                hand = [deck.pop(), deck.pop()]
                opp_hands.append(hand)
            
            our_score = self._evaluate_hand(hole_cards, sim_community)
            opp_scores = [self._evaluate_hand(hand, sim_community) for hand in opp_hands]
            
            max_opp_score = max(opp_scores) if opp_scores else 0
            if our_score > max_opp_score:
                wins += 1
            elif our_score == max_opp_score:
                ties += 1
        
        return (wins + ties / 2) / n_simulations