from typing import List, Tuple, Dict, Optional, Set
from enum import Enum
import math
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class Suit(Enum):
    HEARTS = 'h'
    DIAMONDS = 'd'
    CLUBS = 'c'
    SPADES = 's'

class Rank(Enum):
    TWO = '2'
    THREE = '3'
    FOUR = '4'
    FIVE = '5'
    SIX = '6'
    SEVEN = '7'
    EIGHT = '8'
    NINE = '9'
    TEN = 'T'
    JACK = 'J'
    QUEEN = 'Q'
    KING = 'K'
    ACE = 'A'

RANK_VALUES = {
    Rank.TWO: 2, Rank.THREE: 3, Rank.FOUR: 4, Rank.FIVE: 5,
    Rank.SIX: 6, Rank.SEVEN: 7, Rank.EIGHT: 8, Rank.NINE: 9,
    Rank.TEN: 10, Rank.JACK: 11, Rank.QUEEN: 12, Rank.KING: 13, Rank.ACE: 14
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.id = None
        self.hand = []
        self.small_blind_amount = 0
        self.position = None
        self.last_action = None
        self.vpip_threshold = 1.4
        
    def set_id(self, player_id: int) -> None:
        self.id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.id = self.id if self.id else all_players[0]
        self.position = None
        self.last_action = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.hand = []
        self.position = self.get_position(round_state)

    def get_position(self, state: RoundStateClient) -> str:
        player_id_str = str(self.id)
        
        if player_id_str in state.player_bets:
            our_bet = state.player_bets[player_id_str]
            if our_bet == self.small_blind_amount:
                return "SB"
            elif our_bet == self.blind_amount:
                return "BB"
        
        player_index = self.all_players.index(self.id)
        dealer_index = (player_index - 3) % len(self.all_players)
        if player_index == (dealer_index + 1) % len(self.all_players):
            return "SB"
        elif player_index == (dealer_index + 2) % len(self.all_players):
            return "BB"
        
        positions = ["EP", "MP", "MP", "LP", "LP"]
        position_index = (player_index - dealer_index - 3) % len(self.all_players)
        if position_index < len(positions):
            return positions[position_index]
        return "LP"

    def _get_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        card_ranks = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
            '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return self._preflop_hand_strength(hole_cards, card_ranks)
        
        return self._postflop_hand_strength(hole_cards, community_cards, card_ranks)

    def _preflop_hand_strength(self, hole_cards: List[str], card_ranks: Dict[str, int]) -> float:
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        r1 = card_ranks[rank1]
        r2 = card_ranks[rank2]
        suited = 1 if suit1 == suit2 else 0
        
        is_pair = rank1 == rank2
        same_suit = suit1 == suit2
        gap = abs(r1 - r2)
        
        pair_bonus = 8 if is_pair else 0
        value = max(r1, r2)
        return value + (gap * 0.2) + (2 if is_pair else 0) + (1.2 if same_suit else 0)

    def _postflop_hand_strength(self, hole_cards: List[str], community_cards: List[str], card_ranks: Dict[str, int]) -> float:
        def is_flush(cards):
            suits = [card[1] for card in cards]
            for suit in set(suits):
                if suits.count(suit) >= 5:
                    flush_cards = [c for c in cards if c[1] == suit]
                    flush_ranks = sorted([card_ranks[c[0]] for c in flush_cards], reverse=True)
                    return flush_ranks[0] + 10
            return 0

        def is_straight(ranks):
            unique_ranks = list(set(ranks))
            unique_ranks.sort(reverse=True)
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    return unique_ranks[i] + 8
            return 0

        all_cards = hole_cards + community_cards
        ranks = [card_ranks[c[0]] for c in all_cards]
        ranks.sort(reverse=True)
        
        max_hand = 0
        if is_flush(all_cards) > 0:
            max_hand = max(max_hand, is_flush(all_cards))
        if is_straight(ranks) > 0:
            max_hand = max(max_hand, is_straight(ranks))
            
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
            
        pairs = []
        three_kind = False
        for r, count in rank_count.items():
            if count == 4:
                return 25 + r
            if count == 3:
                three_kind = True
            if count == 2:
                pairs.append(r)
                
        if three_kind and pairs:
            return 23
        if three_kind:
            return 17
        if len(pairs) >= 2:
            return 14 + sum(sorted(pairs, reverse=True)[:2]) / 20.0
        if len(pairs) == 1:
            return 11 + pairs[0] / 2.0
        
        return max(ranks)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.hand = round_state.player_hands.get(str(self.id), [])
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        player_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - player_bet
        
        position = self.position if self.position is not None else self.get_position(round_state)
        
        hand = self.hand
        if len(hand) != 2 and not community_cards:
            hand = [f"{random.choice('AKQJT98765432')}{random.choice('hdcs')}",
                    f"{random.choice('AKQJT98765432')}{random.choice('hdcs')}"]
        
        hand_strength = self._get_hand_strength(hand, community_cards)
        
        pot_odds = (call_amount) / (round_state.pot + call_amount + 1e-7)
        equity = self._estimate_equity(hand, community_cards, hand_strength)
        
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        min_raise_amount = min_raise if min_raise is not None else max_raise // 2
        if min_raise_amount is None:
            min_raise_amount = max_raise // 2
        
        if len(community_cards) == 0:
            return self._preflop_strategy(round_state, hand_strength, call_amount, min_raise_amount, max_raise, position, equity)
        else:
            return self._postflop_strategy(round_state, hand_strength, call_amount, min_raise_amount, max_raise, position, pot_odds, equity)

    def _preflop_strategy(self, state: RoundStateClient, hand_strength: float, call_amount: int, min_raise: int, max_raise: int, position: str, equity: float) -> Tuple[PokerAction, int]:
        
        premium = False
        strong = False
        playable = False
        
        if hand_strength > 15:
            premium = True
        elif hand_strength > 12:
            strong = True
        elif hand_strength > 8:
            playable = True
            
        call_threshold = random.uniform(0.23, 0.28) * self.vpip_threshold
        raise_threshold = max(0.15, (1 - (1/self.vpip_threshold)) * 0.8
        
        # Position adjustments
        if position in ["LP", "BB", "SB"]:
            call_threshold += 0.08
            raise_threshold -= 0.05
        
        if premium:
            # Open raise/re-raise with premium hands
            if position == "SB" and call_amount <= self.small_blind_amount * 2:
                raise_amt = max(min_raise, min(max_raise, max_raise // 3))
                if raise_amt > min_raise:
                    return (PokerAction.RAISE, raise_amt)
                else:
                    return (PokerAction.CALL, 0)
            elif call_amount == 0:
                raise_amt = max(min_raise, min(max_raise, max_raise // 3))
                return (PokerAction.RAISE, raise_amt)
            else:
                # If there's a bet, re-raise
                if max_raise >= min_raise * 2:
                    return (PokerAction.RAISE, min(max_raise, max_raise // 2))
                else:
                    return (PokerAction.ALL_IN, 0)
        
        elif strong:
            # Open raise or call small bets
            if call_amount == 0:
                # Only raise if in late position or blinds
                if position in ["LP", "BB", "SB"] and random.random() > 0.1:
                    return (PokerAction.RAISE, min_raise)
                else:
                    return (PokerAction.CALL, 0)
            else:
                pot_odds = call_amount / (state.pot + call_amount + 1e-7)
                if equity + 0.2 > pot_odds:
                    return (PokerAction.CALL, 0)
                elif call_amount < self.blind_amount * 1.8:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        elif playable:
            # Play in position or call small bets
            if call_amount == 0:
                if position in ["LP", "BB", "SB"] and random.random() > 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if call_amount < self.blind_amount * 3 and position in ["BB", "SB", "LP"]:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        else:
            if call_amount == 0 and position in ["BB"]:
                return (PokerAction.CHECK, 0)
            elif call_amount < self.small_blind_amount and random.random() > 0.7:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, state: RoundStateClient, hand_strength: float, call_amount: int, min_raise: int, max_raise: int, position: str, pot_odds: float, equity: float) -> Tuple[PokerAction, int]:
        community_cards = state.community_cards
        num_players = len([p for p in state.player_bets if state.player_bets[p] > 0])
        
        def is_dry_board():
            suits = [c[1] for c in community_cards]
            if len(set(suits)) == len(community_cards):
                return True
            return False
        
        potential = 0
        if hand_strength > 22:
            # Very strong hand - bet aggressively
            if max_raise > min_raise * 3:
                raise_amt = min(max_raise, max_raise)
                return (PokerAction.RAISE, max_raise // 2)
            elif max_raise > min_raise:
                return (PokerAction.RAISE, min_raise)
            else:
                return (PokerAction.CALL, 0)
        elif hand_strength > 18:
            # Strong hand - bet/raise for value
            if call_amount == 0:
                if random.random() < 0.8:
                    return (PokerAction.RAISE, min_raise)
                else:
                    return (PokerAction.CALL, 0)
            else:
                if equity * 0.9 > pot_odds:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.RAISE, min_raise)
        elif hand_strength > 14:
            # Medium strength - check/call or small bets
            if call_amount == 0:
                if num_players < 3 and position in ["LP", "BB", "SB"] and is_dray_board():
                    return (PokerAction.RAISE, min(min_raise, state.pot // 3))
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if (pot_odds < 0.25 and equity > 0.35) or (position in ["LP", "BB"] and call_amount < state.pot // 10):
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            # Weak hand - fold or opportunistic bluff
            if call_amount == 0:
                if num_players == 1 and position in ["LP", "BB", "SB"] and is_dry_board() and random.random() < 0.2:
                    return (PokerAction.RAISE, min_raise)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if pot_odds < 0.15 and hand_strength > 5:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def _estimate_equity(self, hole_cards: List[str], community_cards: List[str], hand_strength: float) -> float:
        if len(community_cards) == 0:
            # Preflop equity estimation
            return max(0.1, min(0.8, hand_strength/30))
        
        # Simplified postflop equity calculation
        if hand_strength > 22:
            equity = 0.85
        elif hand_strength > 18:
            equity = 0.55
        elif hand_strength > 14:
            equity = 0.35
        else:
            equity = 0.1
            
        if len(community_cards) == 3:
            return max(0.05, min(0.9, equity * 1.2))
        elif len(community_cards) == 4:
            return max(0.05, min(0.95, equity * 1.1))
        else:
            return max(0.05, min(0.99, equity))

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        if player_score < 0:
            adjustment = max(0.2, -player_score / (self.starting_chips * 10))
            self.vpip_threshold = max(0.8, self.vpip_threshold - adjustment * 0.01)
        elif player_score > 0:
            self.vpip_threshold = min(1.8, self.vpip_threshold + 0.01)
        else:
            self.vpip_threshold = min(1.5, max(1.0, self.vpip_threshold))