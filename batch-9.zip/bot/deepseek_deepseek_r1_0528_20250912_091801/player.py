import itertools
import random
from collections import Counter
from typing import List, Tuple, Dict, Any, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.player_position = {}
        self.hole_cards = []
        self.position = None
        self.hand_strength = 0.0
        self.preflop_group = 0
        self.rank_map = {'2':0, '3':1, '4':2, '5':3, '6':4, '7':5, '8':6, '9':7, 
                         'T':8, 'J':9, 'Q':10, 'K':11, 'A':12}
        self.reverse_rank_map = {v: k for k, v in self.rank_map.items()}
        
        # Preflop hand groups
        self.group1 = {'AA', 'KK', 'QQ', 'JJ', 'AKs'}
        self.group2 = {'TT', '99', '88', 'AK', 'AQ', 'AJs', 'KQs', 'QJs', 'JTs', 
                       'T9s', '98s', '87s', '76s', '65s', '77'}
        self.group3 = {'44', '33', '22', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 
                       'A3s', 'A2s', 'KJ', 'QJ', 'JT', 'T8s', '97s', '86s', '75s', 
                       '64s', '53s', '43s', '55', '66'}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        n = len(all_players)
        dealer_index = (all_players.index(small_blind_player_id) - 1) % n
        for i, player_id in enumerate(all_players):
            offset = (i - dealer_index) % n
            self.player_position[player_id] = offset

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.hole_cards = getattr(round_state, 'hole_cards', [])
            self.position = self.player_position.get(self.id, 0)
            if self.hole_cards:
                hand_str = self.canonical_hand(self.hole_cards)
                if hand_str in self.group1:
                    self.preflop_group = 1
                elif hand_str in self.group2:
                    self.preflop_group = 2
                elif hand_str in self.group3:
                    self.preflop_group = 3
                else:
                    self.preflop_group = 4
            else:
                self.preflop_group = 0

    def canonical_hand(self, cards: List[str]) -> str:
        card1, card2 = cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        r1 = self.rank_map[rank1]
        r2 = self.rank_map[rank2]
        
        if r1 == r2:
            return f"{rank1}{rank1}"
        
        if r1 > r2:
            high_rank, low_rank = rank1, rank2
            high_suit, low_suit = suit1, suit2
        else:
            high_rank, low_rank = rank2, rank1
            high_suit, low_suit = suit2, suit1
            
        suited = 's' if suit1 == suit2 else 'o'
        return f"{high_rank}{low_rank}{suited}"

    def evaluate_5cards(self, cards: List[str]) -> Tuple:
        ranks = sorted([self.rank_map[c[0]] for c in cards], reverse=True)
        suits = [c[1] for c in cards]
        
        # Check flush
        flush = len(set(suits)) == 1
        
        # Check straight
        straight = False
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) >= 5:
            # Check normal straight
            for i in range(len(unique_ranks)-4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    straight = True
                    straight_high = unique_ranks[i]
                    break
            # Check wheel straight (A-2-3-4-5)
            if not straight and set(unique_ranks) >= {0,1,2,3,12}:
                straight = True
                straight_high = 3
        
        # Straight flush
        if flush and straight:
            return (9, straight_high)
        
        # Four of a kind
        count = Counter(ranks)
        if 4 in count.values():
            quad_rank = [r for r, cnt in count.items() if cnt == 4][0]
            kicker = max(r for r in ranks if r != quad_rank)
            return (8, quad_rank, kicker)
        
        # Full house
        if 3 in count.values() and 2 in count.values():
            trip_rank = max(r for r, cnt in count.items() if cnt == 3)
            pair_rank = max(r for r, cnt in count.items() if cnt >= 2 and r != trip_rank)
            return (7, trip_rank, pair_rank)
        
        # Flush
        if flush:
            return (6, *sorted(ranks, reverse=True)[:5])
        
        # Straight
        if straight:
            return (5, straight_high)
        
        # Three of a kind
        if 3 in count.values():
            trip_rank = max(r for r, cnt in count.items() if cnt == 3)
            kickers = sorted([r for r in ranks if r != trip_rank], reverse=True)[:2]
            return (4, trip_rank, *kickers)
        
        # Two pair
        pairs = [r for r, cnt in count.items() if cnt == 2]
        if len(pairs) >= 2:
            pairs_sorted = sorted(pairs, reverse=True)[:2]
            kicker = max(r for r in ranks if r not in pairs_sorted)
            return (3, *pairs_sorted, kicker)
        
        # One pair
        if len(pairs) == 1:
            pair_rank = pairs[0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
            return (2, pair_rank, *kickers)
        
        # High card
        return (1, *sorted(ranks, reverse=True)[:5])

    def hand_rank(self, cards: List[str]) -> Tuple:
        best_rank = None
        for comb in itertools.combinations(cards, 5):
            current_rank = self.evaluate_5cards(comb)
            if best_rank is None or current_rank > best_rank:
                best_rank = current_rank
        return best_rank

    def calculate_equity(self, round_state: RoundStateClient, n_opponents: int, trials=100) -> float:
        if not self.hole_cards:
            return 0.0
            
        all_cards = [f"{r}{s}" for r in '23456789TJQKA' for s in 'shdc']
        used_cards = self.hole_cards + round_state.community_cards
        deck = [card for card in all_cards if card not in used_cards]
        total_equity = 0.0
        
        for _ in range(trials):
            random.shuffle(deck)
            
            # Complete the board
            if round_state.round == 'Preflop':
                board = deck[:5]
                remaining_deck = deck[5:]
            elif round_state.round == 'Flop':
                board = round_state.community_cards + deck[:2]
                remaining_deck = deck[2:]
            elif round_state.round == 'Turn':
                board = round_state.community_cards + deck[:1]
                remaining_deck = deck[1:]
            else:  # River
                board = round_state.community_cards
                remaining_deck = deck
                
            our_hand_rank = self.hand_rank(self.hole_cards + board)
            opp_hands = []
            
            for i in range(n_opponents):
                opp_cards = remaining_deck[2*i:2*i+2]
                opp_hand_rank = self.hand_rank(opp_cards + board)
                opp_hands.append(opp_hand_rank)
                
            all_hands = [our_hand_rank] + opp_hands
            best_hand_value = max(all_hands)
            count_best = sum(1 for hand in all_hands if hand == best_hand_value)
            
            if our_hand_rank == best_hand_value:
                total_equity += 1.0 / count_best
                
        return total_equity / trials

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not hasattr(self, 'hole_cards') or not self.hole_cards:
            if hasattr(round_state, 'hole_cards'):
                self.hole_cards = round_state.hole_cards
            else:
                return (PokerAction.FOLD, 0)
                
        player_id_str = str(self.id)
        my_current_bet = round_state.player_bets.get(player_id_str, 0)
        to_call = round_state.current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        n_active = len(round_state.current_player)
        n_opponents = n_active - 1
        
        # Preflop strategy
        if round_state.round == 'Preflop':
            if self.preflop_group == 0:
                return (PokerAction.FOLD, 0)
                
            # Premium hands
            if self.preflop_group == 1:
                if to_call == 0:  # No raise yet
                    if self.position < 4:  # Early position
                        raise_amt = min(max(3 * self.blind_amount, min_raise), max_raise)
                        total_raise = round_state.current_bet + raise_amt
                        if total_raise >= remaining_chips + my_current_bet:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, total_raise)
                    else:  # Late position
                        raise_amt = min(max(2.5 * self.blind_amount, min_raise), max_raise)
                        total_raise = round_state.current_bet + raise_amt
                        if total_raise >= remaining_chips + my_current_bet:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, total_raise)
                else:  # Facing a raise
                    if to_call <= 0.1 * remaining_chips:  # Small raise
                        return (PokerAction.CALL, 0)
                    elif to_call <= 0.3 * remaining_chips:  # Medium raise
                        return (PokerAction.CALL, 0)
                    else:  # Large raise
                        if random.random() < 0.7:  # 70% chance to call
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)
            
            # Good hands
            elif self.preflop_group == 2:
                if to_call == 0:  # No raise
                    if self.position >= 6:  # Late position
                        raise_amt = min(max(2 * self.blind_amount, min_raise), max_raise)
                        total_raise = round_state.current_bet + raise_amt
                        if total_raise >= remaining_chips + my_current_bet:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, total_raise)
                    else:  # Early/middle position
                        return (PokerAction.CALL, 0)
                else:  # Facing a raise
                    if to_call <= 0.15 * remaining_chips:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
            
            # Playable hands
            elif self.preflop_group == 3:
                if to_call == 0:  # No raise
                    if self.position >= 7:  # Button or late
                        return (PokerAction.CALL, 0)
                    elif self.position == 0:  # Small blind
                        if to_call <= self.blind_amount / 2:
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)
                    elif self.position == 1:  # Big blind
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
                else:  # Facing a raise
                    return (PokerAction.FOLD, 0)
            
            # Weak hands
            else:
                if self.position >= 7 and to_call == 0:  # Late position, no raise
                    return (PokerAction.CALL, 0)
                elif self.position == 1 and to_call == 0:  # Big blind, no raise
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
        
        # Postflop strategy
        else:
            equity = self.calculate_equity(round_state, n_opponents, 100)
            pot = round_state.pot
            pot_odds = to_call / (pot + to_call + 1e-8) if to_call > 0 else 0
            
            if to_call == 0:  # First to act
                if equity > 0.65:
                    bet_amt = min(max(int(0.6 * pot), min_raise), max_raise)
                    total_bet = round_state.current_bet + bet_amt
                    if total_bet >= remaining_chips + my_current_bet:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, total_bet)
                elif equity > 0.45:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:  # Facing a bet
                if equity > pot_odds + 0.15:  # Good equity
                    if equity > 0.7:
                        raise_amt = min(max(int(1.5 * to_call), min_raise), max_raise)
                        total_raise = round_state.current_bet + raise_amt
                        if total_raise >= remaining_chips + my_current_bet:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, total_raise)
                    else:
                        return (PokerAction.CALL, 0)
                elif equity > pot_odds:  # Marginal equity
                    return (PokerAction.CALL, 0)
                else:  # Poor equity
                    if pot_odds < 0.1 and equity > 0.2:  # Cheap bluff catch
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict):
        pass