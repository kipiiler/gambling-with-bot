from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.position_aggressive = False
        self.hand_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.position_aggressive = (self.id == small_blind_player_id)
        self.hand_count = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate pot odds and current investment
        pot_size = round_state.pot
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, round_state.current_bet - my_current_bet)
        
        # If we can check, consider checking or betting
        if amount_to_call == 0:
            # Evaluate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            if hand_strength >= 0.7:  # Strong hand
                # Make a value bet
                bet_size = min(int(pot_size * 0.75), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            elif hand_strength >= 0.4:  # Medium hand
                # Sometimes bet for protection
                if self.position_aggressive and pot_size > 0:
                    bet_size = min(int(pot_size * 0.5), remaining_chips)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
            
            return (PokerAction.CHECK, 0)
        
        # We need to call or fold
        pot_odds = amount_to_call / (pot_size + amount_to_call + 0.001)
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Call if hand strength is better than pot odds
        if hand_strength > pot_odds:
            # Sometimes raise with very strong hands
            if hand_strength >= 0.8 and remaining_chips > amount_to_call:
                raise_amount = min(
                    max(round_state.min_raise, int(pot_size * 0.75)),
                    remaining_chips
                )
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            
            # Just call
            if amount_to_call >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, 0)
        
        # Fold weak hands
        return (PokerAction.FOLD, 0)
        
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        # Parse hole cards
        card1 = self.hole_cards[0]
        card2 = self.hole_cards[1]
        
        rank1 = self._card_rank(card1[0])
        rank2 = self._card_rank(card2[0])
        suited = (card1[1] == card2[1])
        
        # Preflop evaluation
        if round_state.round == 'Preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                elif rank1 >= 5:  # 55-77
                    return 0.65
                else:  # 22-44
                    return 0.55
            
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            gap = high_rank - low_rank
            
            # Ace high
            if high_rank == 14:
                if low_rank >= 11:  # AJ+
                    return 0.8 if suited else 0.75
                elif low_rank >= 9:  # A9-AT
                    return 0.65 if suited else 0.6
                else:
                    return 0.5 if suited else 0.45
            
            # King high
            if high_rank == 13:
                if low_rank >= 11:  # KJ+
                    return 0.7 if suited else 0.65
                elif low_rank >= 9:  # K9-KT
                    return 0.55 if suited else 0.5
                else:
                    return 0.4 if suited else 0.35
            
            # Connected cards
            if gap <= 1:  # Connected or one-gappers
                base_strength = (high_rank + low_rank) / 28.0
                return base_strength + (0.05 if suited else 0)
            
            # Default
            return max(0.2, (high_rank + low_rank) / 35.0)
        
        # Postflop - simplified evaluation
        community = round_state.community_cards
        if not community:
            return 0.3
        
        # Check for pairs with board
        board_ranks = [self._card_rank(c[0]) for c in community]
        
        # Check if we hit the board
        hits = 0
        if rank1 in board_ranks:
            hits += 1
        if rank2 in board_ranks:
            hits += 1
        
        # Overpairs
        if rank1 == rank2 and rank1 > max(board_ranks):
            return 0.85
        
        # Top pair or better
        if hits > 0:
            if rank1 in board_ranks and rank1 == max(board_ranks):
                return 0.75
            elif rank2 in board_ranks and rank2 == max(board_ranks):
                return 0.75
            else:
                return 0.6
        
        # High cards that might be good
        if max(rank1, rank2) > max(board_ranks):
            return 0.4
        
        # Nothing
        return 0.25
        
    def _card_rank(self, rank_char: str) -> int:
        """Convert card rank character to numeric value"""
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            try:
                return int(rank_char)
            except:
                return 2
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass