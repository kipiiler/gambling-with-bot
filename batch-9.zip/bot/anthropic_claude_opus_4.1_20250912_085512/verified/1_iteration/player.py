from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_stats = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hand_count += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_stats:
                self.opponent_stats[player_id] = {
                    'vpip': 0,  # Voluntarily put in pot
                    'pfr': 0,   # Pre-flop raise
                    'hands': 0,
                    'aggression': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)  # Add small value to avoid division by zero
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Position awareness
        is_in_position = self._is_in_position(round_state)
        
        # Stack size considerations
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, to_call)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, to_call, pot_odds, is_in_position, stack_to_pot_ratio)

    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, to_call: int) -> Tuple[PokerAction, int]:
        """Pre-flop strategy based on starting hand strength."""
        
        # Premium hands (AA, KK, QQ, AKs)
        if hand_strength > 0.85:
            if round_state.current_bet == 0:
                raise_amount = min(remaining_chips, int(round_state.pot * 3))
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.5:
                raise_amount = min(remaining_chips, to_call * 3)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.ALL_IN, 0)
        
        # Strong hands (JJ, TT, AQ, AJs)
        elif hand_strength > 0.7:
            if round_state.current_bet == 0:
                raise_amount = min(remaining_chips, int(round_state.pot * 2.5))
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Playable hands
        elif hand_strength > 0.5:
            if round_state.current_bet == 0:
                if random.random() < 0.3:  # Sometimes raise with medium hands
                    raise_amount = min(remaining_chips, int(round_state.pot * 2))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif to_call < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, to_call: int, pot_odds: float, is_in_position: bool, stack_to_pot_ratio: float) -> Tuple[PokerAction, int]:
        """Post-flop strategy based on board texture and hand strength."""
        
        # Very strong hands (likely best hand)
        if hand_strength > 0.8:
            if round_state.current_bet == 0:
                # Value bet
                bet_size = int(round_state.pot * 0.75)
                if bet_size <= remaining_chips and bet_size > 0:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Raise for value
                if stack_to_pot_ratio > 2:
                    raise_amount = min(remaining_chips, to_call * 2 + round_state.pot // 2)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
        
        # Good hands
        elif hand_strength > 0.6:
            if round_state.current_bet == 0:
                if is_in_position or random.random() < 0.4:
                    bet_size = int(round_state.pot * 0.5)
                    if bet_size <= remaining_chips and bet_size > 0:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                if pot_odds < hand_strength - 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Marginal hands
        elif hand_strength > 0.4:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                if pot_odds < 0.2 and to_call < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Weak hands/bluffs
        else:
            if round_state.current_bet == 0:
                # Occasional bluff
                if random.random() < 0.15 and is_in_position:
                    bet_size = int(round_state.pot * 0.4)
                    if bet_size <= remaining_chips and bet_size > 0:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards."""
        
        if round_state.round == 'Preflop':
            return self._evaluate_preflop_strength()
        else:
            return self._evaluate_postflop_strength(round_state.community_cards)

    def _evaluate_preflop_strength(self) -> float:
        """Simple pre-flop hand strength evaluation."""
        if len(self.hole_cards) != 2:
            return 0.3
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Pocket pairs
        if rank1 == rank2:
            pair_strength = {14: 0.95, 13: 0.93, 12: 0.90, 11: 0.85, 10: 0.80, 
                           9: 0.75, 8: 0.70, 7: 0.65, 6: 0.60, 5: 0.55, 
                           4: 0.50, 3: 0.45, 2: 0.40}
            return pair_strength.get(rank1, 0.35)
        
        # High cards
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        
        # Ace high
        if high_rank == 14:
            if low_rank >= 11:  # AK, AQ, AJ
                return 0.85 if suited else 0.80
            elif low_rank >= 9:  # AT, A9
                return 0.70 if suited else 0.65
            else:
                return 0.55 if suited else 0.50
        
        # King high
        elif high_rank == 13:
            if low_rank >= 11:  # KQ, KJ
                return 0.75 if suited else 0.70
            elif low_rank >= 9:
                return 0.60 if suited else 0.55
            else:
                return 0.45 if suited else 0.40
        
        # Queen high
        elif high_rank == 12:
            if low_rank >= 10:
                return 0.65 if suited else 0.60
            else:
                return 0.50 if suited else 0.45
        
        # Connectors
        if abs(rank1 - rank2) == 1:
            return 0.55 if suited else 0.50
        
        # Default
        return 0.35 if suited else 0.30

    def _evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        """Evaluate post-flop hand strength."""
        all_cards = self.hole_cards + community_cards
        
        # Check for various hand types
        if self._has_flush(all_cards):
            return 0.85
        if self._has_straight(all_cards):
            return 0.80
        if self._has_three_of_kind(all_cards):
            return 0.75
        if self._has_two_pair(all_cards):
            return 0.65
        if self._has_pair(all_cards):
            # Top pair, overpair, etc.
            pair_rank = self._get_pair_rank(all_cards)
            board_high = max([self._card_rank(c) for c in community_cards])
            if pair_rank >= board_high:
                return 0.60
            else:
                return 0.45
        
        # High card
        high_card_rank = max([self._card_rank(c) for c in self.hole_cards])
        return 0.30 + (high_card_rank / 14) * 0.15

    def _has_flush(self, cards: List[str]) -> bool:
        """Check if cards contain a flush."""
        suits = {}
        for card in cards:
            suit = card[-1]
            suits[suit] = suits.get(suit, 0) + 1
            if suits[suit] >= 5:
                return True
        return False

    def _has_straight(self, cards: List[str]) -> bool:
        """Check if cards contain a straight."""
        ranks = sorted(set([self._card_rank(c) for c in cards]), reverse=True)
        
        # Check for ace-low straight
        if 14 in ranks:
            ranks.append(1)
        
        for i in range(len(ranks) - 4):
            if ranks[i] - ranks[i+4] == 4:
                return True
        return False

    def _has_three_of_kind(self, cards: List[str]) -> bool:
        """Check if cards contain three of a kind."""
        ranks = [self._card_rank(c) for c in cards]
        for rank in set(ranks):
            if ranks.count(rank) >= 3:
                return True
        return False

    def _has_two_pair(self, cards: List[str]) -> bool:
        """Check if cards contain two pair."""
        ranks = [self._card_rank(c) for c in cards]
        pairs = 0
        for rank in set(ranks):
            if ranks.count(rank) >= 2:
                pairs += 1
        return pairs >= 2

    def _has_pair(self, cards: List[str]) -> bool:
        """Check if cards contain a pair."""
        ranks = [self._card_rank(c) for c in cards]
        for rank in set(ranks):
            if ranks.count(rank) >= 2:
                return True
        return False

    def _get_pair_rank(self, cards: List[str]) -> int:
        """Get the rank of the highest pair."""
        ranks = [self._card_rank(c) for c in cards]
        for rank in sorted(set(ranks), reverse=True):
            if ranks.count(rank) >= 2:
                return rank
        return 0

    def _card_rank(self, card: str) -> int:
        """Convert card to numeric rank."""
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)

    def _is_in_position(self, round_state: RoundStateClient) -> bool:
        """Check if we're in position (acting last or late)."""
        active_players = [p for p in self.all_players if str(p) not in round_state.player_actions or round_state.player_actions[str(p)] != 'Fold']
        if len(active_players) <= 2:
            return True
        
        # Simple position check - we're in position if we're one of the last 2 to act
        my_position = active_players.index(self.id) if self.id in active_players else 0
        return my_position >= len(active_players) - 2

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass