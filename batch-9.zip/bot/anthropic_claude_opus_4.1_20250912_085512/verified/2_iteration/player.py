from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.hand_count = 0
        self.opponent_fold_count = {}
        self.opponent_raise_count = {}
        self.opponent_call_count = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hand_count = 0
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_fold_count[player_id] = 0
                self.opponent_raise_count[player_id] = 0
                self.opponent_call_count[player_id] = 0
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.hand_count += 1
            
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action == 'Fold':
                    self.opponent_fold_count.setdefault(int(player_id), 0)
                    self.opponent_fold_count[int(player_id)] += 1
                elif action == 'Raise':
                    self.opponent_raise_count.setdefault(int(player_id), 0)
                    self.opponent_raise_count[int(player_id)] += 1
                elif action == 'Call':
                    self.opponent_call_count.setdefault(int(player_id), 0)
                    self.opponent_call_count[int(player_id)] += 1
        
        # Get current situation
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot_size = round_state.pot
        
        # Calculate pot odds
        pot_odds = to_call / (pot_size + to_call + 0.001)
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Position-based strategy
        is_last_to_act = len([p for p in round_state.current_player if p != self.id]) == 0
        
        # Aggressive heads-up strategy
        if len(round_state.current_player) == 2:  # Heads-up
            if round_state.round == 'Preflop':
                # Aggressive preflop in heads-up
                if hand_strength >= 0.6:
                    # Strong hand - raise aggressively
                    raise_amount = min(remaining_chips, int(pot_size * 1.5))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                elif hand_strength >= 0.4:
                    # Medium hand - call or small raise
                    if to_call <= pot_size * 0.3:
                        if to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            # Try to steal with position
                            raise_amount = min(remaining_chips, int(pot_size * 0.75))
                            if raise_amount >= round_state.min_raise:
                                return (PokerAction.RAISE, raise_amount)
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand - fold to big bets
                    if to_call > pot_size * 0.2:
                        return (PokerAction.FOLD, 0)
                    elif to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                # Post-flop heads-up play
                if hand_strength >= 0.7:
                    # Very strong hand - bet for value
                    raise_amount = min(remaining_chips, int(pot_size * 1.2))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                elif hand_strength >= 0.5:
                    # Good hand - bet or call
                    if to_call <= pot_size * 0.5:
                        if to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            # Bet for value/protection
                            raise_amount = min(remaining_chips, int(pot_size * 0.6))
                            if raise_amount >= round_state.min_raise:
                                return (PokerAction.RAISE, raise_amount)
                            return (PokerAction.CHECK, 0)
                    else:
                        if pot_odds < hand_strength - 0.2:
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand - check/fold
                    if to_call > pot_size * 0.3:
                        return (PokerAction.FOLD, 0)
                    elif to_call > 0:
                        if pot_odds < 0.2:
                            return (PokerAction.CALL, 0)
                        return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CHECK, 0)
        
        # Multi-way pot strategy (more conservative)
        else:
            if round_state.round == 'Preflop':
                if hand_strength >= 0.75:
                    # Premium hand
                    raise_amount = min(remaining_chips, int(pot_size * 1.0))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                elif hand_strength >= 0.5:
                    # Decent hand
                    if to_call <= pot_size * 0.25:
                        if to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand
                    if to_call > 0:
                        return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                # Post-flop multi-way
                if hand_strength >= 0.8:
                    # Very strong hand
                    raise_amount = min(remaining_chips, int(pot_size * 0.8))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                elif hand_strength >= 0.6:
                    # Good hand
                    if to_call <= pot_size * 0.3:
                        if to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand
                    if to_call > 0:
                        return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CHECK, 0)
        
        # Default action
        if to_call > 0:
            return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.CHECK, 0)
    
    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.0
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self.get_card_rank_suit(card1)
        rank2, suit2 = self.get_card_rank_suit(card2)
        
        if round_state.round == 'Preflop':
            # Preflop hand strength evaluation
            strength = 0.0
            
            # Pairs
            if rank1 == rank2:
                pair_strength = {
                    'A': 0.95, 'K': 0.90, 'Q': 0.85, 'J': 0.80,
                    'T': 0.75, '9': 0.70, '8': 0.65, '7': 0.60,
                    '6': 0.55, '5': 0.50, '4': 0.45, '3': 0.40, '2': 0.35
                }
                strength = pair_strength.get(rank1, 0.3)
            else:
                # High cards
                high_card_value = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                                 '9': 9, '8': 8, '7': 7, '6': 6, '5': 5,
                                 '4': 4, '3': 3, '2': 2}
                high1 = high_card_value.get(rank1, 0)
                high2 = high_card_value.get(rank2, 0)
                max_rank = max(high1, high2)
                min_rank = min(high1, high2)
                
                # Base strength from high cards
                strength = (max_rank + min_rank) / 28.0  # Normalize
                
                # Suited bonus
                if suit1 == suit2:
                    strength += 0.15
                
                # Connectivity bonus
                if abs(high1 - high2) == 1:
                    strength += 0.10
                elif abs(high1 - high2) == 2:
                    strength += 0.05
                
                # Special hands
                if (rank1 == 'A' and rank2 == 'K') or (rank1 == 'K' and rank2 == 'A'):
                    strength = 0.85
                elif (rank1 == 'A' and rank2 == 'Q') or (rank1 == 'Q' and rank2 == 'A'):
                    strength = 0.75
                elif (rank1 == 'A' and rank2 == 'J') or (rank1 == 'J' and rank2 == 'A'):
                    strength = 0.70
                elif (rank1 == 'K' and rank2 == 'Q') or (rank1 == 'Q' and rank2 == 'K'):
                    strength = 0.65
            
            return min(1.0, strength)
        else:
            # Post-flop evaluation
            all_cards = self.hole_cards + round_state.community_cards
            hand_type = self.get_hand_type(all_cards)
            
            # Map hand types to strength values
            hand_strength_map = {
                'high_card': 0.2,
                'pair': 0.4,
                'two_pair': 0.6,
                'three_of_a_kind': 0.7,
                'straight': 0.75,
                'flush': 0.8,
                'full_house': 0.9,
                'four_of_a_kind': 0.95,
                'straight_flush': 0.99,
                'royal_flush': 1.0
            }
            
            base_strength = hand_strength_map.get(hand_type, 0.1)
            
            # Adjust for kicker strength in pairs
            if hand_type == 'pair':
                if rank1 == rank2:  # Pocket pair
                    rank_value = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                                '9': 9, '8': 8, '7': 7, '6': 6, '5': 5,
                                '4': 4, '3': 3, '2': 2}
                    pair_rank = rank_value.get(rank1, 2)
                    base_strength += (pair_rank - 2) / 12 * 0.15
            
            return min(1.0, base_strength)
    
    def get_card_rank_suit(self, card: str) -> Tuple[str, str]:
        """Extract rank and suit from card string"""
        if len(card) >= 2:
            return card[0], card[1]
        return '2', 's'
    
    def get_hand_type(self, cards: List[str]) -> str:
        """Determine the type of poker hand from cards"""
        if len(cards) < 5:
            return 'high_card'
        
        ranks = []
        suits = []
        for card in cards:
            rank, suit = self.get_card_rank_suit(card)
            ranks.append(rank)
            suits.append(suit)
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
                      '9': 9, '8': 8, '7': 7, '6': 6, '5': 5,
                      '4': 4, '3': 3, '2': 2}
        
        numeric_ranks = sorted([rank_values.get(r, 0) for r in ranks])
        is_straight = False
        
        for i in range(len(numeric_ranks) - 4):
            if numeric_ranks[i+4] - numeric_ranks[i] == 4:
                consecutive = True
                for j in range(4):
                    if numeric_ranks[i+j+1] - numeric_ranks[i+j] != 1:
                        consecutive = False
                        break
                if consecutive:
                    is_straight = True
                    break
        
        # Check for wheel straight (A-2-3-4-5)
        if 14 in numeric_ranks and 2 in numeric_ranks and 3 in numeric_ranks and 4 in numeric_ranks and 5 in numeric_ranks:
            is_straight = True
        
        # Determine hand type
        counts = sorted(rank_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            return 'straight_flush'
        elif counts[0] == 4:
            return 'four_of_a_kind'
        elif counts[0] == 3 and len(counts) > 1 and counts[1] >= 2:
            return 'full_house'
        elif is_flush:
            return 'flush'
        elif is_straight:
            return 'straight'
        elif counts[0] == 3:
            return 'three_of_a_kind'
        elif counts[0] == 2 and len(counts) > 1 and counts[1] == 2:
            return 'two_pair'
        elif counts[0] == 2:
            return 'pair'
        else:
            return 'high_card'
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass