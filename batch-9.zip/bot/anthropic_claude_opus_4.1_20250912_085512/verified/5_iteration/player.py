from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.game_count = 0
        self.round_num = 0
        self.opponent_aggression = {}  # Track opponent behavior
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.game_count += 1
        self.blind_amount = blind_amount
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self.remaining_chips = remaining_chips
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current game state
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_current_bet)
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
        
        # Track opponent actions
        self._update_opponent_tracking(round_state)
        
        # Get opponent aggression level
        aggression_level = self._get_opponent_aggression_level()
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(hand_strength, to_call, pot, remaining_chips, 
                                         current_bet, min_raise, max_raise, aggression_level)
        else:
            return self._postflop_strategy(hand_strength, to_call, pot, remaining_chips,
                                          current_bet, min_raise, max_raise, round_state, aggression_level)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Premium hands
            if (rank1 >= 12 and rank2 >= 12):  # QQ+
                return 0.95
            if (rank1 == 14 and rank2 >= 10) or (rank2 == 14 and rank1 >= 10):  # AK, AQ, AJ, AT
                return 0.85 if suit1 == suit2 else 0.80
            if (rank1 >= 10 and rank2 >= 10):  # TT+, KQ, KJ, QJ
                return 0.75
            
            # Medium strength
            if rank1 >= 8 and rank2 >= 8:  # 88+
                return 0.65
            if (rank1 == 14) or (rank2 == 14):  # Any ace
                return 0.60
            if suit1 == suit2:  # Suited cards
                return 0.55
            if abs(rank1 - rank2) <= 2:  # Connected cards
                return 0.50
            
            return 0.40
        else:
            # Postflop: Basic evaluation based on community cards
            community = round_state.community_cards
            if not community:
                return 0.5
            
            # Check for pairs, flushes, straights (simplified)
            all_cards = self.hole_cards + community
            ranks = [self._parse_card(card)[0] for card in all_cards]
            suits = [self._parse_card(card)[1] for card in all_cards]
            
            # Check for pairs with hole cards
            for hole_rank in [rank1, rank2]:
                if ranks.count(hole_rank) >= 2:
                    if hole_rank >= 12:  # High pair
                        return 0.80
                    elif hole_rank >= 8:  # Medium pair
                        return 0.65
                    else:  # Low pair
                        return 0.55
            
            # Check for flush draw
            for suit in set(suits):
                if suits.count(suit) >= 4:
                    return 0.70
            
            # Default postflop strength
            if rank1 >= 12 or rank2 >= 12:  # High cards
                return 0.50
            return 0.40
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit"""
        if not card or len(card) < 2:
            return (2, 's')
        
        rank_str = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)
    
    def _preflop_strategy(self, hand_strength: float, to_call: int, pot: int, 
                         remaining_chips: int, current_bet: int, min_raise: int,
                         max_raise: int, aggression_level: float) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        # Adjust strategy based on position
        position_bonus = 0.1 if self.is_small_blind else 0.05 if self.is_big_blind else 0
        adjusted_strength = hand_strength + position_bonus
        
        # Premium hands - always raise
        if adjusted_strength >= 0.85:
            if current_bet == 0:
                raise_amount = min(3 * self.blind_amount, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call > 0 and to_call <= remaining_chips * 0.3:
                # Re-raise with premium hands
                raise_amount = min(current_bet + 2 * to_call, remaining_chips)
                if raise_amount >= min_raise:
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif to_call > 0:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Good hands - raise or call
        elif adjusted_strength >= 0.65:
            if current_bet == 0:
                raise_amount = min(2 * self.blind_amount, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call > 0 and to_call <= remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            elif to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands - call small bets
        elif adjusted_strength >= 0.50:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, hand_strength: float, to_call: int, pot: int,
                          remaining_chips: int, current_bet: int, min_raise: int,
                          max_raise: int, round_state: RoundStateClient,
                          aggression_level: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        # Calculate pot-sized bet
        pot_bet = pot
        
        # Strong hands - bet/raise
        if hand_strength >= 0.75:
            if current_bet == 0:
                # Bet 50-75% of pot
                bet_amount = min(int(pot * 0.6), remaining_chips)
                if bet_amount >= min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif to_call > 0:
                # Call or raise depending on pot odds
                if to_call <= remaining_chips * 0.4:
                    if hand_strength >= 0.85:
                        raise_amount = min(current_bet + pot_bet, remaining_chips)
                        if raise_amount >= min_raise:
                            return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                elif to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Medium strength hands
        elif hand_strength >= 0.55:
            if current_bet == 0:
                # Sometimes bet for value
                if hand_strength >= 0.65:
                    bet_amount = min(int(pot * 0.4), remaining_chips)
                    if bet_amount >= min_raise:
                        return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif to_call > 0:
                # Call if pot odds are good
                if to_call <= pot * 0.3 and to_call <= remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Weak hands or draws
        else:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= pot * 0.1 and to_call <= remaining_chips * 0.05:
                # Call very small bets with draws
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _update_opponent_tracking(self, round_state: RoundStateClient):
        """Track opponent actions"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[int(player_id)]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[int(player_id)]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[int(player_id)]['folds'] += 1
    
    def _get_opponent_aggression_level(self) -> float:
        """Calculate average opponent aggression"""
        total_aggression = 0
        count = 0
        
        for player_id, stats in self.opponent_aggression.items():
            total_actions = stats['raises'] + stats['calls'] + stats['folds']
            if total_actions > 0:
                aggression = (stats['raises'] * 2 + stats['calls']) / (total_actions + 0.001)
                total_aggression += aggression
                count += 1
        
        if count > 0:
            return total_aggression / count
        return 0.5
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Learn from game results
        if player_score > 0:
            # Won money - remember successful patterns
            pass
        else:
            # Lost money - adjust strategy
            pass