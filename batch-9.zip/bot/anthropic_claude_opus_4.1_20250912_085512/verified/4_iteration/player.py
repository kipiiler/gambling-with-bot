from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.game_history = []
        self.opponent_aggression = {}
        self.blind_amount = 0
        self.hand_count = 0
        self.position_stats = {'button': 0, 'big_blind': 0, 'small_blind': 0}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.hand_count = 0
        for player_id in all_players:
            if player_id != self.id:
                if player_id not in self.opponent_aggression:
                    self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_count += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
        
        # Calculate pot odds
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001)
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Position awareness
        is_last_to_act = self._is_last_to_act(round_state)
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, is_last_to_act)
    
    def _is_last_to_act(self, round_state: RoundStateClient) -> bool:
        active_players = [p for p in round_state.current_player if str(p) not in round_state.player_actions or 
                         round_state.player_actions[str(p)] not in ['Fold', 'All-in']]
        return len(active_players) <= 1
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, 
                         hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        # Premium hands - always raise/reraise
        if hand_strength > 0.85:
            if call_amount == 0:
                raise_amount = min(int(round_state.pot * 0.75), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            else:
                # 3-bet or 4-bet with premium hands
                raise_amount = min(int(call_amount * 3), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
        
        # Strong hands - raise first in, call raises
        if hand_strength > 0.7:
            if call_amount == 0:
                raise_amount = min(int(round_state.pot * 0.6), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
        
        # Playable hands - limp or call small raises
        if hand_strength > 0.5:
            if call_amount <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
        
        # Marginal hands in position
        if hand_strength > 0.35 and self._is_last_to_act(round_state):
            if call_amount <= self.blind_amount:
                return (PokerAction.CALL, 0)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
        
        # Default fold
        if call_amount > 0:
            return (PokerAction.FOLD, 0)
        return (PokerAction.CHECK, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, 
                          hand_strength: float, pot_odds: float, is_last_to_act: bool) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        # Very strong hands - bet/raise aggressively
        if hand_strength > 0.8:
            if call_amount == 0:
                # Value bet
                bet_size = int(round_state.pot * 0.7)
                if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
                elif remaining_chips < round_state.pot:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Value raise
                if call_amount < remaining_chips * 0.5:
                    raise_amount = min(int(call_amount * 2.5), remaining_chips)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif pot_odds < hand_strength:
                    return (PokerAction.CALL, 0)
        
        # Good hands - bet for value, call if pot odds are good
        if hand_strength > 0.6:
            if call_amount == 0:
                # Continuation bet
                bet_size = int(round_state.pot * 0.5)
                if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength - 0.1:
                return (PokerAction.CALL, 0)
        
        # Drawing hands - call if pot odds are favorable
        if hand_strength > 0.4:
            if call_amount == 0:
                # Semi-bluff occasionally
                if random.random() < 0.25 and is_last_to_act:
                    bet_size = int(round_state.pot * 0.4)
                    if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength:
                return (PokerAction.CALL, 0)
        
        # Weak hands - check/fold
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        
        # Bluff catch with decent hands if pot odds are very good
        if hand_strength > 0.25 and pot_odds < 0.25:
            return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.5
        
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        if round_state.round == 'Preflop':
            # Preflop hand strength evaluation
            if rank1 == rank2:  # Pairs
                if rank1 >= 12:  # AA, KK, QQ
                    return 0.95
                elif rank1 >= 10:  # JJ, TT
                    return 0.85
                elif rank1 >= 8:  # 99, 88
                    return 0.75
                elif rank1 >= 5:  # 77-55
                    return 0.65
                else:  # 44-22
                    return 0.55
            
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            gap = high_rank - low_rank
            
            # High cards
            if high_rank == 14:  # Ace high
                if low_rank >= 12:  # AK, AQ
                    return 0.9 if suited else 0.85
                elif low_rank >= 10:  # AJ, AT
                    return 0.75 if suited else 0.7
                elif low_rank >= 8:  # A9, A8
                    return 0.6 if suited else 0.55
                else:
                    return 0.5 if suited else 0.4
            
            if high_rank >= 12:  # King or Queen high
                if gap <= 2:
                    return 0.7 if suited else 0.65
                elif gap <= 3:
                    return 0.6 if suited else 0.55
                else:
                    return 0.45 if suited else 0.35
            
            # Connectors and suited connectors
            if gap == 1:
                if high_rank >= 10:
                    return 0.65 if suited else 0.6
                else:
                    return 0.55 if suited else 0.5
            elif gap == 2:
                return 0.5 if suited else 0.45
            
            # Default
            return 0.4 if suited else 0.3
        
        else:
            # Postflop hand strength evaluation
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Simple postflop evaluation
            hand_value = self._evaluate_postflop_hand(all_cards)
            
            # Normalize to 0-1 range
            if hand_value >= 8:  # Straight flush or better
                return 1.0
            elif hand_value >= 7:  # Four of a kind
                return 0.98
            elif hand_value >= 6:  # Full house
                return 0.95
            elif hand_value >= 5:  # Flush
                return 0.9
            elif hand_value >= 4:  # Straight
                return 0.85
            elif hand_value >= 3:  # Three of a kind
                return 0.75
            elif hand_value >= 2:  # Two pair
                return 0.65
            elif hand_value >= 1:  # One pair
                return 0.5 + (hand_value - 1) * 0.15
            else:  # High card
                return 0.3 + hand_value * 0.2
    
    def _evaluate_postflop_hand(self, cards: List[str]) -> float:
        if len(cards) < 5:
            return 0
        
        ranks = [self._card_rank(card) for card in cards]
        suits = [card[-1] for card in cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush
        has_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        unique_ranks = sorted(set(ranks), reverse=True)
        has_straight = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                has_straight = True
                break
        
        # Special case for A-2-3-4-5 straight
        if 14 in unique_ranks and set([2, 3, 4, 5]).issubset(set(unique_ranks)):
            has_straight = True
        
        # Count pairs, trips, quads
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)
        
        # Determine hand value
        if has_straight and has_flush:
            return 8.0  # Straight flush
        elif quads > 0:
            return 7.0
        elif trips > 0 and pairs > 0:
            return 6.0  # Full house
        elif has_flush:
            return 5.0
        elif has_straight:
            return 4.0
        elif trips > 0:
            return 3.0
        elif pairs >= 2:
            return 2.0
        elif pairs == 1:
            # Add kicker strength for pairs
            pair_rank = max(rank for rank, count in rank_counts.items() if count == 2)
            return 1.0 + pair_rank / 14.0
        else:
            # High card value
            return max(ranks) / 14.0
    
    def _card_rank(self, card: str) -> int:
        if len(card) < 2:
            return 2
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.game_history.append({
            'score': player_score,
            'hands': active_players_hands,
            'all_scores': all_scores
        })