from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import collections
import math

# --- Helper Functions for Hand Evaluation ---

def hand_strength(hand_cards: List[str], community_cards: List[str]) -> float:
    """
    A fast approximation of hand strength (0 to 1). 
    This is not a full poker hand evaluator but a heuristic.
    A full evaluator would be more accurate but also more complex.
    """
    all_cards = hand_cards + community_cards
    if len(all_cards) < 5:
        return 0.0 # Not enough cards to evaluate

    ranks = '23456789TJQKA'
    suits = 'cdhs'
    
    rank_counts = collections.defaultdict(int)
    suit_counts = collections.defaultdict(int)
    rank_vals = []

    for card in all_cards:
        r = card[0]
        s = card[1]
        rank_counts[r] += 1
        suit_counts[s] += 1
        rank_vals.append(ranks.index(r) + 2) # 2->2, A->14

    rank_vals.sort()
    
    score = 0.0
    counts = sorted(rank_counts.values(), reverse=True)

    # --- Scoring Heuristics ---
    
    # 1. High Card
    score += max(rank_vals) / 30.0

    # 2. Pair
    if counts[0] == 2:
        pair_rank = [r for r, c in sorted(rank_counts.items(), key=lambda item: item[1], reverse=True) if c == 2]
        pair_val = ranks.index(pair_rank[0]) + 2
        score += 10 + pair_val * 0.5
        
    # 3. Two Pair
    if len(counts) > 1 and counts[0] == 2 and counts[1] == 2:
        pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], key=lambda r: ranks.index(r), reverse=True)
        high_pair_val = ranks.index(pair_ranks[0]) + 2
        low_pair_val = ranks.index(pair_ranks[1]) + 2
        score += 30 + high_pair_val * 0.7 + low_pair_val * 0.3

    # 4. Three of a Kind
    if counts[0] == 3:
        trips_rank = [r for r, c in rank_counts.items() if c == 3][0]
        trips_val = ranks.index(trips_rank) + 2
        score += 50 + trips_val * 1.0

    # 5. Straight
    is_straight = False
    unique_ranks = sorted(list(set(rank_vals)))
    if len(unique_ranks) >= 5:
        # Check for regular straight (e.g., 5,6,7,8,9)
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                is_straight = True
                score += 100 + unique_ranks[i+4] * 1.5 # High card of the straight
                break
        # Check for Ace-low straight (A,2,3,4,5)
        if not is_straight and set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            is_straight = True
            score += 100 # Ace-low straight is the lowest straight
            
    # 6. Flush
    if suit_counts and max(suit_counts.values()) >= 5:
        score += 150
        # Bonus for high cards in the flush
        flush_suit = [s for s, c in suit_counts.items() if c >= 5][0]
        flush_ranks = sorted([ranks.index(c[0]) + 2 for c in all_cards if c[1] == flush_suit], reverse=True)
        score += sum(flush_ranks[:5]) * 0.2

    # 7. Full House
    if counts[0] == 3 and counts[1] >= 2: # Counts can be [3,2] or [3,3]
        trips_rank = [r for r, c in rank_counts.items() if c == 3][0]
        pair_ranks = [r for r, c in rank_counts.items() if c >= 2]
        pair_val = ranks.index(sorted(pair_ranks, key=lambda r: ranks.index(r), reverse=True)[0 - (pair_ranks[0] == trips_rank)]) + 2 # Avoid using a card from trips for pair if it's a quad
        
        trips_val = ranks.index(trips_rank) + 2
        score += 200 + trips_val * 2.0 + pair_val * 1.0

    # 8. Four of a Kind
    if counts[0] == 4:
        quads_rank = [r for r, c in rank_counts.items() if c == 4][0]
        quads_val = ranks.index(quads_rank) + 2
        score += 400 + quads_val * 3.0

    # 9. Straight Flush and Royal Flush
    if is_straight and suit_counts and max(suit_counts.values()) >= 5:
        # This is a simplified check. A robust check requires finding 5 consecutive ranks of the same suit.
        score += 600 # Straight Flush

    # Royal flush is a type of straight flush, so it gets the base score plus a big bonus.
    # The Ace-high straight flush (Royal Flush) would have a very high high card value.
    if round(score) >= 600 + 14 * 1.5: # A rough heuristic for royal flush (A-high straight flush)
        score += 500
        
    return min(score / 1500.0, 1.0) # Normalize to 0-1 range

# --- The Bot Class ---

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.my_hand = []
        self.round_num = 0
        self.my_bets_this_round = 0
        self.aggression_factor = 1.0
        self.vpip_count = 0
        self.pfr_count = 0 # Pre-Flop Raise
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hands_played += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        self.my_bets_this_round = round_state.player_bets.get(str(self.id), 0)
        
    def _get_num_opponents(self, round_state: RoundStateClient) -> int:
        # Number of players who have not folded and are still in the game
        return len([pid for pid, action in round_state.player_actions.items() if action != 'FOLD' and int(pid) != self.id])

    def _get_opponent_model(self, round_state: RoundStateClient) -> Dict[str, Any]:
        # Basic opponent modeling based on their actions in the current hand
        model = {"aggressive": 0, "passive": 0, "tight": 0, "loose": 0}
        
        for player_id_str, action_str in round_state.player_actions.items():
            if int(player_id_str) == self.id:
                continue
            
            if action_str in ('Raise', 'All-In'):
                model["aggressive"] += 1
            elif action_str in ('Check', 'Call'):
                model["passive"] += 1
            
            # Preflop actions can indicate tightness/looseness
            if round_state.round == 'Preflop':
                if action_str == 'Fold':
                    model["tight"] += 1
                elif action_str in ('Call', 'Raise', 'All-In'):
                    model["loose"] += 1

        return model

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract current hand information
        community_cards = round_state.community_cards
        pot = round_state.pot
        current_bet_to_call = round_state.current_bet - self.my_bets_this_round
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        num_opponents = self._get_num_opponents(round_state)
        opponent_model = self._get_opponent_model(round_state)

        # --- Core Strategy Logic ---

        # 1. Fold if no chips left (shouldn't happen as player is eliminated)
        if remaining_chips <= 0:
            return (PokerAction.FOLD, 0)

        # 2. Evaluate Hand Strength
        strength = hand_strength(self.my_hand, community_cards)
        
        # 3. Pot Odds Calculation
        if current_bet_to_call > 0:
            pot_odds = current_bet_to_call / (pot + current_bet_to_call + 1e-9) # Add delta to avoid div by zero
        else:
            pot_odds = 0
            
        # 4. Determine Action Based on Context and Strength
        
        action = PokerAction.FOLD # Default to fold
        bet_amount = 0

        # --- Preflop Strategy ---
        if round_state.round == 'Preflop':
            # Use a simplified hand chart for preflop
            ranks = '23456789TJQKA'
            suits = 'cdhs'
            c1, c2 = self.my_hand
            r1, r2 = ranks.index(c1[0]), ranks.index(c2[0])
            is_suited = c1[1] == c2[1]
            is_pair = r1 == r2
            
            # Convert to a sortable value (e.g., pair, then suited, then offsuit)
            hand_val = 0
            if is_pair:
                hand_val = 100 + r1
            elif is_suited:
                hand_val = 50 + max(r1, r2) * 2 + min(r1, r2)
            else:
                hand_val = max(r1, r2) * 2 + min(r1, r2)

            # Adjust strategy based on position relative to blinds
            is_big_blind = str(self.id) == str(self.big_blind_player_id)
            is_small_blind = str(self.id) == str(self.small_blind_player_id)
            in_blinds = is_big_blind or is_small_blind
            
            # Adjust for number of opponents, be tighter from early position
            position_factor = 1.0 - (num_opponents / 10.0) # Looser in late position (fewer opponents)
            hand_val_adjusted = hand_val * position_factor

            # Raise thresholds
            strong_raise_threshold = 90  # Pairs TT+, AKs, AKo
            medium_raise_threshold = 70  # Pairs 88+, AJs+, KQs, AQo+
            call_threshold = 40          # Pairs 77+, A9s+, KJs+, QJs, ATo+

            # Blind defense: defend blinds with a wider range
            if in_blinds and current_bet_to_call <= 2 * self.blind_amount:
                call_threshold *= 0.8

            # --- Action Logic for Preflop ---
            hand_folded = False
            if current_bet_to_call == 0: # No one has bet, can check or raise
                if hand_val_adjusted > medium_raise_threshold:
                    action = PokerAction.RAISE
                    bet_amount = min(3 * self.blind_amount, remaining_chips) # Standard raise
                    if remaining_chips < 4 * self.blind_amount: # Short stack, just shove
                         action = PokerAction.ALL_IN
                    self.pfr_count += 1
                elif hand_val_adjusted > call_threshold:
                    action = PokerAction.CHECK # Effectively a limp/call
                else:
                    action = PokerAction.FOLD # Check in dark, but better to fold trash
                    hand_folded = True
                if action != PokerAction.FOLD: self.vpip_count += 1

            elif current_bet_to_call > 0: # There is a bet to face (call, raise, or fold)
                if hand_val_adjusted > strong_raise_threshold:
                    action = PokerAction.RAISE
                    # 3-bet sizing (3x the current raise)
                    total_bet = round_state.current_bet + (round_state.current_bet * 2)
                    bet_amount = max(min_raise, total_bet - self.my_bets_this_round)
                    if bet_amount > remaining_chips:
                        action = PokerAction.ALL_IN
                    self.pfr_count += 1
                elif hand_val_adjusted > call_threshold:
                    # Call if pot odds are reasonable
                    if strength * (1.0 + float(opponent_model['aggressive']) / (num_opponents+1 + 1e-9)) > pot_odds:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                        hand_folded = True
                else:
                    action = PokerAction.FOLD
                    hand_folded = True

                if action != PokerAction.FOLD: self.vpip_count += 1

        # --- Postflop Strategy (Flop, Turn, River) ---
        else:
            # Adjust strength based on number of opponents (more players = lower relative strength)
            adjusted_strength = strength / (1.0 + (num_opponents - 1) * 0.2)
            
            # Factor in opponent model
            if opponent_model['aggressive'] > opponent_model['passive']:
                # Against aggressive opponents, tighten up calling range
                pot_odds *= 1.1
                # But also bluff catchers go up in value
                if strength > 0.4 and strength < 0.65: # Made hands that are not monsters
                    adjusted_strength *= 1.05

            # --- Action Logic for Postflop ---
            if current_bet_to_call == 0: # Check to us
                # Standard Continuation Bet (if we were the preflop raiser)
                is_pfr_raiser = self.pfr_count > 0 and self.hands_played > 0 and float(self.pfr_count) / self.hands_played > 0.1
                if is_pfr_raiser and adjusted_strength > 0.45 and strength > 0.5:
                    # Bet 50-70% of the pot
                    bet_amount = int(pot * random.uniform(0.5, 0.7))
                    action = PokerAction.RAISE
                elif adjusted_strength > 0.7: # Strong hand, value bet
                    bet_amount = int(pot * random.uniform(0.7, 1.0))
                    action = PokerAction.RAISE
                elif adjusted_strength > 0.2 and random.random() < 0.3: # Weak hand, semi-bluff or small bet
                    bet_amount = int(pot * 0.4)
                    action = PokerAction.RAISE
                else: # Check with medium/weak hands
                    action = PokerAction.CHECK
            else: # There is a bet to call
                # Value Call/Raise
                if adjusted_strength > pot_odds:
                    if adjusted_strength > 0.8: # Monster hand, raise for value
                        # Pot-sized raise
                        total_bet_size = self.my_bets_this_round + current_bet_to_call + pot
                        bet_amount = max(min_raise, total_bet_size - self.my_bets_this_round)
                        action = PokerAction.RAISE
                        if bet_amount > remaining_chips:
                            action = PokerAction.ALL_IN
                    elif adjusted_strength > 0.9 and num_opponents == 1 and opponent_model["aggressive"] > 0: # Trap a single aggressive opponent
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.CALL
                # Bluff Catch (if opponent is aggressive and we have a showdownable hand)
                elif adjusted_strength > 0.4 * (1.0 + float(opponent_model['aggressive']) / (num_opponents+1 + 1e-9)) and pot_odds < 0.2:
                    action = PokerAction.CALL
                # Block bet / Bluff raise (less common, needs specific conditions)
                elif adjusted_strength < 0.3 and current_bet_to_call < pot * 0.3 and random.random() < 0.1:
                    # A small bluff raise. Risky.
                    bet_amount = int(pot * 1.2) # Raise to 1.2x total pot
                    if bet_amount > remaining_chips:
                        action = PokerAction.ALL_IN
                    else:
                        action = PokerAction.RAISE
                else: # Fold if we are not getting good odds or have a weak hand
                    action = PokerAction.FOLD
        
        # --- Final Sanity Check and Action Enforcement ---
        
        # Convert base action to final valid action based on game state
        final_action = action
        final_amount = bet_amount

        # Rule: Cannot CHECK if there's a current bet to be called
        if final_action == PokerAction.CHECK and current_bet_to_call > 0:
            # Convert check to a more appropriate action
            if strength > pot_odds * 1.1: # We are willing to call
                final_action = PokerAction.CALL
                final_amount = 0 # Amount is implicit for CALL
            else: # We are not willing to call, so fold
                final_action = PokerAction.FOLD
                final_amount = 0

        # Rule: Cannot CALL if current bet is 0 (this shouldn't happen with logic above, but be safe)
        if final_action == PokerAction.CALL and current_bet_to_call == 0:
            final_action = PokerAction.CHECK # Check is the appropriate action

        # Rule: For RAISE, amount must be within [min_raise, max_raise] and must cover the call
        if final_action == PokerAction.RAISE:
            if final_amount < min_raise: # Raise too small
                # If the intended raise is too small, convert to call or fold
                if strength > pot_odds * 1.1:
                    final_action = PokerAction.CALL
                    final_amount = 0
                else:
                    final_action = PokerAction.FOLD
                    final_amount = 0
            else: # Raise amount is acceptable
                # Ensure total bet (current bet + raise) is within stack limits
                # Server handles the total bet, just need to pass the "raise on top" amount.
                # The amount passed should be total_bet - my_bets_this_round.
                # Our logic should already have `bet_amount` calculated this way.
                pass # Keep the action and amount

        # Rule: If remaining chips are very low, shoving might be the only option other than fold/call
        if remaining_chips > 0 and remaining_chips <= current_bet_to_call + min_raise * 2:
            if final_action == PokerAction.RAISE:
                 final_action = PokerAction.ALL_IN
            elif final_action == PokerAction.CALL and strength > 0.7: # Strong hand, just shove
                 final_action = PokerAction.ALL_IN
            elif final_action == PokerAction.CHECK and strength > 0.7: # Strong hand, bet all-in
                 final_action = PokerAction.ALL_IN

        # If we are all-in, the amount is implicit (all chips)
        if final_action == PokerAction.ALL_IN:
            final_amount = 0 # Amount is ignored by server for ALL_IN

        # Final fallback: if any error in logic, fold to be safe
        if final_action not in [PokerAction.FOLD, PokerAction.CHECK, PokerAction.CALL, PokerAction.RAISE, PokerAction.ALL_IN]:
            final_action = PokerAction.FOLD
            final_amount = 0
            
        return (final_action, final_amount)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round counters
        self.my_bets_this_round = 0
        self.vpip_count = 0
        self.pfr_count = 0
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This could be used for long-term learning or logging
        # For now, we don't use it.
        pass