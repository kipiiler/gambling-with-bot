from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
from collections import Counter

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.tighten_factor = 0.0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.starting_chips = 0
        self.last_action = None
        self.hand_history = []
        self.aggression_count = 0
        self.pot_history = []
        
        # Pre-flop hand strength table (Sklansky-Chubukov adjusted)
        self.preflop_hand_strength = {
            'AA': 1.0, 'KK': 0.9, 'QQ': 0.85, 'JJ': 0.8, 'TT': 0.75,
            'AKs': 0.75, 'AQs': 0.7, 'AJs': 0.65, 'ATs': 0.6,
            'KQs': 0.65, 'KJs': 0.6, 'KTs': 0.55,
            'QJs': 0.6, 'QTs': 0.55, 'JTs': 0.55,
            'AKo': 0.7, 'AQo': 0.65, 'AJo': 0.6, 'ATo': 0.55,
            'KQo': 0.6, 'KJo': 0.55, 'KTo': 0.5,
            'QJo': 0.55, 'QTo': 0.5, 'JTo': 0.5,
            '99': 0.7, '88': 0.65, '77': 0.6, '66': 0.55,
            '55': 0.5, '44': 0.45, '33': 0.4, '22': 0.35
        }

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str], num_opponents: int) -> float:
        """Evaluate hand strength using Monte Carlo simulation"""
        if not hole_cards:
            return 0.0
            
        trials = min(100, max(50, 200 // (num_opponents + 1)))
        wins = 0
        ties = 0
        
        deck = self.create_deck(hole_cards + community_cards)
        
        for _ in range(trials):
            shuffled_deck = deck[:]
            random.shuffle(shuffled_deck)
            
            # Deal remaining community cards
            remaining_board_len = 5 - len(community_cards)
            sim_community = community_cards[:]
            
            for _ in range(remaining_board_len):
                if shuffled_deck:
                    sim_community.append(shuffled_deck.pop())
            
            # Deal opponents' hands
            opponents = []
            for _ in range(num_opponents):
                if len(shuffled_deck) >= 2:
                    opponents.append(shuffled_deck.pop() + shuffled_deck.pop())
            
            # Evaluate hands
            my_hand_str = self.get_hand_strength_value(hole_cards + sim_community)
            for opp_cards in opponents:
                opp_hand_str = self.get_hand_strength_value(opp_cards + sim_community)
                
                if my_hand_str > opp_hand_str:
                    wins += 1
                elif my_hand_str == opp_hand_str:
                    ties += 0.5
                    
        return (wins + ties) / (trials * num_opponents) if num_opponents > 0 else 0.5

    def create_deck(self, known_cards: List[str]) -> List[str]:
        """Create a standard deck excluding known cards"""
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        suits = ['h', 'd', 'c', 's']
        deck = [rank + suit for suit in suits for rank in ranks]
        return [card for card in deck if card not in known_cards]

    def get_hand_strength_value(self, hand: List[str]) -> int:
        """Calculate numerical hand strength value"""
        if not hand:
            return 0
            
        # Values for card ranks
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                      '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        ranks = []
        suits = []
        for card in hand:
            if card and len(card) >= 2:
                ranks.append(rank_values.get(card[0], 0))
                suits.append(card[1])
        
        if not ranks:
            return 0
            
        ranks.sort(reverse=True)
        
        # Check for flush
        suit_counts = Counter(suits)
        is_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        is_straight = False
        unique_ranks = sorted(set(ranks), reverse=True)
        
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                is_straight = True
                break
        # Special case for A-2-3-4-5 straight
        if set(unique_ranks) >= {14, 2, 3, 4, 5} and len(unique_ranks) >= 5:
            is_straight = True
            
        # Count rank occurrences
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        
        # Determine hand rank
        if is_straight and is_flush:
            return 8000000 + max(ranks)  # Straight flush
        elif counts == [4, 1]:
            return 7000000 + max(ranks)  # Four of a kind
        elif counts == [3, 2]:
            return 6000000 + max(ranks)  # Full house
        elif is_flush:
            return 5000000 + sum(ranks[:5])  # Flush
        elif is_straight:
            return 4000000 + max(ranks)  # Straight
        elif counts == [3, 1, 1]:
            return 3000000 + max(ranks)  # Three of a kind
        elif counts == [2, 2, 1]:
            return 2000000 + ranks[0] * 100 + ranks[2]  # Two pair
        elif counts == [2, 1, 1, 1]:
            return 1000000 + ranks[0]  # One pair
        else:
            return sum(ranks[:5])  # High card

    def get_position_factor(self, player_id: int, current_players: List[int]) -> float:
        """Calculate position factor (earlier positions are tighter)"""
        if not current_players:
            return 0.5
            
        try:
            position = current_players.index(player_id)
            return 0.3 + (0.7 * position / max(1, len(current_players) - 1))
        except ValueError:
            return 0.5

    def get_preflop_action(self, round_state: RoundStateClient, hole_cards: List[str], remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine pre-flop action based on hand strength and position"""
        if len(hole_cards) != 2:
            return (PokerAction.CALL, 0)
            
        card1, card2 = hole_cards[0], hole_cards[1]
        hand_key = ''
        
        # Sort cards by rank strength
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                      '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        if card1[0] in rank_values and card2[0] in rank_values:
            if rank_values[card1[0]] >= rank_values[card2[0]]:
                higher_card = card1[0]
                lower_card = card2[0]
            else:
                higher_card = card2[0]
                lower_card = card1[0]
                
            suited = 's' if card1[1] == card2[1] else 'o'
            hand_key = higher_card + lower_card + suited
        
        base_strength = self.preflop_hand_strength.get(hand_key, 0.3)
        
        # Adjust for position
        position_factor = self.get_position_factor(self.id, round_state.current_player)
        strength = base_strength * position_factor
        
        # Adjust for blinds and tightness
        blind_factor = min(1.0, self.blind_amount / 100)
        adjusted_strength = strength * (1 - self.tighten_factor) * (1 - 0.2 * blind_factor)
        
        # Determine action
        current_bet = round_state.current_bet
        current_pot = round_state.pot
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        current_max_bet = my_current_bet + current_bet
        min_raise = round_state.min_raise
        
        if current_bet == 0:
            if adjusted_strength > 0.8:
                # Strong hand - raise
                raise_amount = int(min(remaining_chips, current_max_bet + min_raise + current_pot * 0.5))
                return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength > 0.5:
                # Good hand - call or small raise
                if random.random() > 0.7 and min_raise < remaining_chips:
                    raise_amount = int(min(remaining_chips, current_max_bet + min_raise + current_pot * 0.3))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # Weak hand - check
                return (PokerAction.CHECK, 0)
        else:
            # Facing a bet
            pot_odds = current_bet / (current_pot + current_bet + 0.001)
            
            if adjusted_strength > 0.9:
                # Very strong - reraise
                if remaining_chips > current_max_bet + min_raise:
                    raise_amount = int(min(remaining_chips, current_max_bet + min_raise * 2 + current_pot * 0.5))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif adjusted_strength > 0.7 or adjusted_strength > pot_odds:
                # Good hand or good odds - call
                return (PokerAction.CALL, 0)
            else:
                # Weak hand - fold
                return (PokerAction.FOLD, 0)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.tighten_factor = 0.0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        self.pot_history.append(round_state.pot)
        if len(self.pot_history) > 10:
            self.pot_history.pop(0)
            
        # Increase tighten factor as blinds increase relative to stack
        if remaining_chips > 0:
            blind_ratio = self.blind_amount / remaining_chips
            self.tighten_factor = min(0.5, blind_ratio * 2)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get hole cards
        hole_cards = []
        if hasattr(self, 'id') and round_state.player_bets:
            # In a real implementation, hole cards would be passed separately
            # Here we assume they're available through another mechanism
            pass
        
        # Determine number of active opponents
        num_opponents = len(round_state.current_player) - 1
        
        if round_state.round == 'Preflop':
            # Use pre-flop strategy
            # This is a placeholder - in a real bot, hole cards would be passed
            hand = ['As', 'Ks']  # Placeholder for actual hole cards
            return self.get_preflop_action(round_state, hand, remaining_chips)
        else:
            # Post-flop strategy using Monte Carlo
            hand = ['As', 'Ks']  # Placeholder for actual hole cards
            hand_strength = self.evaluate_hand_strength(hand, round_state.community_cards, num_opponents)
            
            current_bet = round_state.current_bet
            current_pot = round_state.pot
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            current_max_bet = my_current_bet + current_bet
            min_raise = round_state.min_raise
            
            if current_bet == 0:
                # No bet to face
                if hand_strength > 0.7:
                    # Strong hand - bet
                    bet_amount = int(min(remaining_chips, current_pot * 0.75))
                    return (PokerAction.RAISE, max(min_raise, bet_amount))
                elif hand_strength > 0.4:
                    # Decent hand - check
                    return (PokerAction.CHECK, 0)
                else:
                    # Weak hand - check
                    return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                pot_odds = current_bet / (current_pot + current_bet + 0.001)
                
                if hand_strength > 0.85:
                    # Very strong hand - raise or all-in
                    if remaining_chips > current_max_bet + min_raise:
                        raise_amount = int(min(remaining_chips, current_max_bet + min_raise + current_pot * 0.5))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif hand_strength > 0.6 or (hand_strength > pot_odds + self.tighten_factor):
                    # Good hand or good pot odds - call
                    return (PokerAction.CALL, 0)
                else:
                    # Weak hand - fold
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round."""
        self.last_action = None
        if hasattr(round_state, 'player_actions'):
            actions = round_state.player_actions
            for player_id, action in actions.items():
                if player_id != str(self.id) and action in ['RAISE', 'ALL_IN']:
                    self.aggression_count += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset between games
        self.aggression_count = 0
        self.pot_history = []
        # Update tighten factor based on performance
        if player_score < 0:
            self.tighten_factor = min(0.5, self.tighten_factor + 0.05)
        else:
            self.tighten_factor = max(0.0, self.tighten_factor - 0.05)