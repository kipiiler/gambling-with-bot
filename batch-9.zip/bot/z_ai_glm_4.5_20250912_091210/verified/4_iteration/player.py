from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import math

# Poker card and hand evaluation helpers
class Suit(Enum):
    HEARTS = 'h'
    DIAMONDS = 'd'
    CLUBS = 'c'
    SPADES = 's'

class Rank(Enum):
    TWO = 2
    THREE = 3
    FOUR = 4
    FIVE = 5
    SIX = 6
    SEVEN = 7
    EIGHT = 8
    NINE = 9
    TEN = 10
    JACK = 11
    QUEEN = 12
    KING = 13
    ACE = 14

def card_to_rank_suit(card_str):
    """Convert card string like 'As' to (Rank, Suit) tuple"""
    rank_char = card_str[0]
    suit_char = card_str[1]
    
    rank_map = {
        '2': Rank.TWO, '3': Rank.THREE, '4': Rank.FOUR, '5': Rank.FIVE,
        '6': Rank.SIX, '7': Rank.SEVEN, '8': Rank.EIGHT, '9': Rank.NINE,
        'T': Rank.TEN, 'J': Rank.JACK, 'Q': Rank.QUEEN, 'K': Rank.KING, 'A': Rank.ACE
    }
    
    suit_map = {
        'h': Suit.HEARTS, 'd': Suit.DIAMONDS, 'c': Suit.CLUBS, 's': Suit.SPADES
    }
    
    return rank_map[rank_char], suit_map[suit_char]

def evaluate_hand_strength(hole_cards, community_cards):
    """Evaluate hand strength using a simple heuristic-based approach"""
    all_cards = hole_cards + community_cards
    if not community_cards:
        # Pre-flop evaluation
        card1 = card_to_rank_suit(hole_cards[0])
        card2 = card_to_rank_suit(hole_cards[1])
        r1, r2 = card1[0].value, card2[0].value
        
        # Pair bonus
        if r1 == r2:
            return 0.8 + (r1 / 14.0) * 0.2
        
        # Suited bonus
        suited = card1[1] == card2[1]
        
        # High card bonus
        high_card = max(r1, r2)
        low_card = min(r1, r2)
        
        # Gap calculation
        gap = abs(r1 - r2)
        
        base_strength = (high_card / 14.0) * 0.5 + (low_card / 14.0) * 0.3
        
        # Adjust for gap
        gap_penalty = gap * 0.05
        if gap == 1:  # Connected
            gap_penalty = -0.1
        
        # Suited bonus
        suited_bonus = 0.1 if suited else 0
        
        strength = base_strength - gap_penalty + suited_bonus
        return min(0.9, max(0.1, strength))
    
    # Post-flop evaluation (simplified)
    strength = 0.0
    
    # Check for pairs, two pairs, etc.
    ranks = [card_to_rank_suit(card)[0].value for card in all_cards]
    rank_counts = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    
    counts = sorted(rank_counts.values(), reverse=True)
    
    if counts[0] == 4:
        return 0.95  # Four of a kind
    elif len(counts) > 1 and counts[0] == 3 and counts[1] == 2:
        return 0.9  # Full house
    elif counts[0] == 3:
        return 0.7  # Three of a kind
    elif len(counts) > 1 and counts[0] == 2 and counts[1] == 2:
        return 0.6  # Two pair
    elif counts[0] == 2:
        return 0.5  # One pair
    
    # High card value
    strength = max(ranks) / 14.0 * 0.4
    
    # Check for flush draws or completed flushes
    suits = [card_to_rank_suit(card)[1] for card in all_cards]
    suit_counts = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    
    if max(suit_counts.values()) >= 5:
        strength = 0.8  # Flush
    elif max(suit_counts.values()) >= 4:
        strength += 0.2  # Flush draw
    
    # Check for straight draws or completed straights
    unique_ranks = sorted(set(ranks))
    consecutive = 1
    max_consecutive = 1
    
    for i in range(1, len(unique_ranks)):
        if unique_ranks[i] - unique_ranks[i-1] == 1:
            consecutive += 1
            max_consecutive = max(max_consecutive, consecutive)
        else:
            consecutive = 1
    
    if max_consecutive >= 5:
        strength = max(strength, 0.75)  # Straight
    elif max_consecutive >= 4:
        strength += 0.15  # Straight draw
    
    return min(1.0, strength)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.aggression_factor = 1.0
        self tighten_factor = 0.0
        self.opp_tendencies = {}
        self.pot_odds_threshold = 0.2
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        
        # Initialize opponent tracking
        for player_id in all_players:
            self.opp_tendencies[player_id] = {
                'aggression': 1.0,  # 0 = passive, 1 = aggressive
                'tightness': 0.5,   # 0 = loose, 1 = tight
                'hands_played': 0
            }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []
        self.round_state = round_state
        self.remaining_chips = remaining_chips
        self.street = round_state.round
        self.community_cards = round_state.community_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract hole cards from player_actions if available
        if len(self.hole_cards) == 0 and str(self.id) in round_state.player_actions:
            # This is a bit hacky; in real implementation we'd get hole cards differently
            pass
            
        # Evaluate hand strength
        if hasattr(self, 'hole_cards') and len(self.hole_cards) == 2:
            hand_strength = evaluate_hand_strength(self.hole_cards, self.community_cards)
        else:
            # Fallback if we don't have hole cards yet
            hand_strength = 0.5
        
        # Calculate pot odds
        pot_odds = 0.0
        if round_state.current_bet > 0:
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
        
        # Adjust hand strength based on position and opponents
        position_factor = 0.0
        if len(round_state.current_player) > 1:
            # Later positions are better
            position_index = round_state.current_player.index(self.id)
            position_factor = position_index / len(round_state.current_player) * 0.1
        
        adjusted_strength = hand_strength + position_factor
        
        # Action decision logic
        action, amount = self._decide_action(round_state, remaining_chips, adjusted_strength, pot_odds)
        
        return action, amount

    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float):
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_cost = current_bet - my_bet
        
        # Fold if hand is very weak and we have to invest
        if hand_strength < 0.3 and call_cost > 0:
            return PokerAction.FOLD, 0
        
        # All-in with strong hands
        if hand_strength > 0.85:
            return PokerAction.ALL_IN, 0
        
        # Raise with strong hands
        if hand_strength > 0.7 and call_cost <= remaining_chips * 0.5:
            # Calculate raise amount
            min_raise = round_state.min_raise
            max_raise = remaining_chips
            
            # Pot-sized raise or half pot if we don't have enough
            raise_amount = min(
                max_raise,
                round_state.pot + call_cost + round_state.current_bet
            )
            
            if raise_amount >= min_raise:
                return PokerAction.RAISE, raise_amount
        
        # Call if pot odds are favorable
        if pot_odds < hand_strength and call_cost <= remaining_chips:
            return PokerAction.CALL, 0
        
        # Check if possible
        if current_bet == my_bet:
            return PokerAction.CHECK, 0
        
        # Call if we have to
        if call_cost <= remaining_chips:
            return PokerAction.CALL, 0
        
        # Default to fold
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent tendencies based on actions
        for player_id, actions in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opp_tendencies:
                tendencies = self.opp_tendencies[player_id]
                tendencies['hands_played'] += 1
                
                # Update aggression based on raises
                if actions == 'Raise':
                    tendencies['aggression'] = min(1.0, tendencies['aggression'] + 0.05)
                elif actions in ['Check', 'Call']:
                    tendencies['aggression'] = max(0.0, tendencies['aggression'] - 0.05)
                
                # Slowly revert to mean
                tendencies['aggression'] = tendencies['aggression'] * 0.9 + 0.5 * 0.1
                tendencies['tightness'] = tendencies['tightness'] * 0.9 + 0.5 * 0.1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # See what hands opponents showed at showdown
        for player_id, hand in active_players_hands.items():
            if player_id != str(self.id) and player_id in self.opp_tendencies:
                # Adjust tightness based on shown hand strength
                if hand:
                    # Opponent showed a hand (didn't fold)
                    evaluate_hand_strength(hand, round_state.community_cards)
                    # Strength would be calculated, could update tightness based on this
                    pass
                else:
                    # Opponent folded, might indicate weak hand
                    self.opp_tendencies[player_id]['tightness'] = min(1.0, 
                        self.opp_tendencies[player_id]['tightness'] + 0.1)