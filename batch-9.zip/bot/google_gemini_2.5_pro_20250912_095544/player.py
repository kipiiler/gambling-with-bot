from typing import List, Tuple, Dict, Any
from collections import Counter
from itertools import combinations
from enum import Enum
from dataclasses import dataclass, field

# The Bot, PokerAction, and RoundStateClient classes are provided by the game environment.
# They are included here for completeness and to make the code self-contained for review.
# In the actual environment, they would be imported from the framework's modules.

# --- Framework Provided Definitions (for context) ---

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]] = field(default_factory=list)

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        # In a real scenario, this helps construct the object from server messages.
        # We can assume the framework handles this instantiation.
        # This is a simplified constructor for the placeholder class.
        return cls(**message)

class Bot:
    def __init__(self) -> None:
        """ Initializes the player. """
        self.id = None

    def set_id(self, player_id: int) -> None:
        """ Sets the player ID. """
        self.id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        raise NotImplementedError

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        raise NotImplementedError

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        raise NotImplementedError

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        raise NotImplementedError

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        raise NotImplementedError

# --- End of Framework Provided Definitions ---


class SimplePlayer(Bot):
    """
    A poker bot that implements a rule-based strategy based on hand strength and pot odds.
    """
    RANKS = '23456789TJQKA'
    
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.all_players: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called at the start of a new hand. We assume this is called for each new hand
        because it's the only place we receive our hole cards (`player_hands`).
        """
        self.hand = player_hands
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each betting round.
        FIX: The previous version's error was trying to access `round_state.player_hands`,
        which does not exist. The hand is already stored in `self.hand` from `on_start`.
        This method now does nothing, but is required by the framework.
        """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Calculates and returns the bot's action for the current turn.
        """
        can_check = round_state.current_bet == round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)

        if not self.hand:
            # Safety check in case hand is not dealt
            return PokerAction.FOLD, 0

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, can_check, amount_to_call)
        else:
            return self._get_postflop_action(round_state, remaining_chips, can_check, amount_to_call)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the end of a hand. Used for cleanup.
        """
        self.hand = []  # Clear hand for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """
        Called at the end of the game match.
        """
        pass

    # ------------------------
    # --- Strategy Methods ---
    # ------------------------

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int):
        category = self._get_preflop_category(self.hand)
        
        big_blind = round_state.min_raise - round_state.current_bet if round_state.min_raise > round_state.current_bet else 50
        if big_blind <= 0: big_blind = 50

        num_raises = sum(1 for action in round_state.player_actions.values() if 'Raise' in action)

        if category == "PREMIUM":
            raise_amount = max(round_state.min_raise, big_blind * 4)
            if num_raises > 0:
                raise_amount = max(round_state.min_raise, round_state.current_bet * 3)
            
            if raise_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.RAISE, raise_amount

        if category == "STRONG":
            if num_raises == 0:
                raise_amount = max(round_state.min_raise, big_blind * 3)
                if raise_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif num_raises == 1 and amount_to_call < 0.1 * remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        if category == "SPECULATIVE":
            if num_raises == 0 and amount_to_call <= big_blind * 2:
                return PokerAction.CALL, 0
            elif can_check:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        # FOLD category
        if can_check:
            return PokerAction.CHECK, 0
        # Defend big blind cheaply
        elif amount_to_call <= big_blind:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, can_check: bool, amount_to_call: int):
        pot = round_state.pot
        pot_odds = amount_to_call / (pot + amount_to_call + 1e-9)

        strength, _ = self._get_best_hand(self.hand, round_state.community_cards)

        # MONSTER: Full House or better (strength >= 6)
        if strength >= 6:
            raise_amount = max(round_state.min_raise, int(pot * 0.75))
            if raise_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.RAISE, raise_amount

        # STRONG_MADE: Straight, Flush, Trips (strength 3, 4, 5)
        if strength >= 3:
            if amount_to_call > 0:  # Facing a bet
                if amount_to_call > pot: # Facing a pot-sized or larger bet
                    return PokerAction.CALL, 0 # Just call, don't re-raise into extreme strength
                else: 
                    raise_amount = max(round_state.min_raise, int(amount_to_call * 2.5))
                    if raise_amount >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
            else: # Can check or bet
                bet_amount = max(round_state.min_raise, int(pot * 0.6))
                if bet_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount

        # DECENT_MADE: Two Pair, Top Pair (strength 1, 2)
        is_top_pair = self._is_top_pair(self.hand, round_state.community_cards)
        if strength == 2 or (strength == 1 and is_top_pair):
            if amount_to_call > 0: # Facing a bet
                if pot_odds < 0.33: # Call if odds are good
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Can check or bet
                bet_amount = max(round_state.min_raise, int(pot * 0.5))
                if bet_amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, bet_amount

        # DRAWING HANDS (Semi-bluff logic is omitted for simplicity/safety)
        outs, draw_type = self._calculate_draws(self.hand, round_state.community_cards)
        if draw_type == "STRONG" and round_state.round != 'River':
            draw_equity = outs / (52 - len(self.hand) - len(round_state.community_cards))
            if amount_to_call > 0: # Facing bet
                if pot_odds < draw_equity: # Good direct odds to call
                    return PokerAction.CALL, 0
            else: # No bet, take a free card
                return PokerAction.CHECK, 0
        
        # BLUFF CATCHING with weak pairs / draws
        if can_check:
            return PokerAction.CHECK, 0
        elif amount_to_call > 0 and (strength > 0 or draw_type != "NONE"):
            if pot_odds < 0.2: # Call very small bets
                return PokerAction.CALL, 0

        # NOTHING / FOLD
        if can_check:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0

    # ---------------------------
    # --- Hand Analysis Tools ---
    # ---------------------------

    def _parse_card(self, card_str: str) -> tuple:
        rank = card_str[:-1]
        suit = card_str[-1:].lower()
        return self.RANKS.index(rank) + 2, suit

    def _get_preflop_category(self, hole_cards: List[str]) -> str:
        c1 = self._parse_card(hole_cards[0])
        c2 = self._parse_card(hole_cards[1])
        r1, s1 = c1
        r2, s2 = c2
        
        high_r, low_r = (max(r1, r2), min(r1, r2))
        is_suited = s1 == s2
        is_pair = r1 == r2
        
        if is_pair and high_r >= 10: return "PREMIUM" # TT+
        if high_r == 14 and low_r >= 12: return "PREMIUM" # AK, AQ
        if is_suited and high_r == 14 and low_r >= 11: return "PREMIUM" # AKs, AQs, AJs
        
        if is_pair: return "STRONG" # 22-99
        if is_suited and high_r == 14: return "STRONG" # A2s-ATs
        if high_r >= 11 and low_r >= 10: return "STRONG" # KQ, KJ, QJ...
        
        if is_suited and high_r - low_r <= 2: return "SPECULATIVE"

        return "FOLD"

    def _get_best_hand(self, hole_cards: List[str], community_cards: List[str]) -> tuple:
        all_cards_str = hole_cards + community_cards
        if len(all_cards_str) < 5: return (-1, [])

        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        best_hand_rank = (-1, [])
        for hand_cards in combinations(all_cards, 5):
            current_hand_rank = self._evaluate_5_card_hand(list(hand_cards))
            if current_hand_rank[0] > best_hand_rank[0]:
                best_hand_rank = current_hand_rank
            elif current_hand_rank[0] == best_hand_rank[0]:
                if current_hand_rank[1] > best_hand_rank[1]:
                    best_hand_rank = current_hand_rank
        return best_hand_rank

    def _evaluate_5_card_hand(self, hand: list) -> tuple:
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        
        is_flush = len(set(suits)) == 1
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        is_straight = (len(set(ranks)) == 5 and ranks[0] - ranks[4] == 4) or is_ace_low_straight
        
        effective_ranks = [5, 4, 3, 2, 1] if is_ace_low_straight else ranks

        if is_straight and is_flush: return (8, tuple(effective_ranks))
        
        rank_counts = Counter(ranks)
        main_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)
        
        if len(main_ranks) == 2: # Full House or Quads
            if rank_counts[main_ranks[0]] == 4: return (7, tuple(main_ranks)) # Quads
            else: return (6, tuple(main_ranks)) # Full House
        if is_flush: return (5, tuple(ranks))
        if is_straight: return (4, tuple(effective_ranks))
        if len(main_ranks) == 3: # Trips or Two Pair
            if rank_counts[main_ranks[0]] == 3: return (3, tuple(main_ranks)) # Trips
            else: return (2, tuple(main_ranks)) # Two Pair
        if len(main_ranks) == 4: return (1, tuple(main_ranks)) # One Pair
        return (0, tuple(ranks)) # High Card

    def _calculate_draws(self, hole: List[str], community: List[str]) -> tuple:
        all_cards = [self._parse_card(c) for c in hole + community]
        
        suit_counts = Counter(c[1] for c in all_cards)
        if 4 in suit_counts.values():
            return 9, "STRONG" # Flush draw (9 outs)
        
        unique_ranks = sorted(list(set(c[0] for c in all_cards)))
        for i in range(len(unique_ranks) - 3):
            # Check for 4-card sequence (e.g., 5,6,7,8) for OESD
            if unique_ranks[i+3] - unique_ranks[i] == 3:
                return 8, "STRONG" # Open-ended straight draw (8 outs)
        # Simplified: Not checking for gutshots
        
        return 0, "NONE"

    def _is_top_pair(self, hole: List[str], community: List[str]):
        if not community: return False
        
        strength, kickers_tuple = self._get_best_hand(hole, community)
        if strength != 1: return False

        kickers = list(kickers_tuple)
        hole_ranks = [self._parse_card(c)[0] for c in hole]
        board_ranks = [self._parse_card(c)[0] for c in community]
        pair_rank = kickers[0]
        
        if (pair_rank in hole_ranks) and (pair_rank >= max(board_ranks)):
            return True
        return False