import random
from typing import List, Tuple, Dict
from collections import Counter
from itertools import combinations

# These classes are provided by the game server.
# We are including them here for type hinting and local testing.
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Constants for Hand Ranks
HIGH_CARD = 0
ONE_PAIR = 1
TWO_PAIR = 2
THREE_OF_A_KIND = 3
STRAIGHT = 4
FLUSH = 5
FULL_HOUSE = 6
FOUR_OF_A_KIND = 7
STRAIGHT_FLUSH = 8

class SimplePlayer(Bot):
    """
    A poker bot that implements a tight-aggressive strategy.
    - Pre-flop: Uses a hand tier system to decide whether to raise, call, or fold.
    - Post-flop: Evaluates hand strength and draw potential to make decisions.
    - Betting: Uses pot-relative bet sizing for value betting and raising.
    - Risk Management: Plays cautiously with speculative hands and avoids overly risky plays.
    """
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.board: List[str] = []
        self.total_players: int = 0
        self.initial_stack: int = 0
        self.big_blind: int = 0
        self.all_players_ids: List[int] = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once per hand. This is where the bot receives its hole cards.
        """
        self.hand = player_hands
        self.initial_stack = starting_chips
        self.big_blind = blind_amount
        self.all_players_ids = all_players
        self.total_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each betting round (Preflop, Flop, etc.).
        """
        self.board = round_state.community_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        """
        legal_actions = self._get_legal_actions(round_state, remaining_chips)
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet

        # Pre-flop Strategy
        if round_state.round == 'Preflop':
            tier = self._get_preflop_hand_tier(self.hand)
            is_raised = round_state.current_bet > self.big_blind
            
            if tier == 1:  # Premium hands (AA, KK, QQ, AKs)
                if PokerAction.RAISE in legal_actions:
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'strong', is_raised)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0

            if tier == 2:  # Very Good hands (JJ, TT, AQs, AJs, KQs, AKo)
                if not is_raised:
                    if PokerAction.RAISE in legal_actions:
                        raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'medium', is_raised)
                        return PokerAction.RAISE, raise_amount
                elif PokerAction.CALL in legal_actions and amount_to_call < 0.15 * remaining_chips:
                    return PokerAction.CALL, 0
                if PokerAction.CHECK in legal_actions: return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
                
            if tier <= 4: # Playable/Speculative hands (mid-low pairs, suited connectors, etc.)
                if not is_raised:
                    if PokerAction.CALL in legal_actions: return PokerAction.CALL, 0
                elif PokerAction.CALL in legal_actions and amount_to_call < 0.05 * remaining_chips:
                    return PokerAction.CALL, 0
                if PokerAction.CHECK in legal_actions: return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            # Tier 5 (Trash)
            if amount_to_call == 0 and PokerAction.CHECK in legal_actions:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Post-flop Strategy
        else:
            win_prob = self._estimate_win_probability(self.hand, self.board, self._get_active_players_count(round_state))

            if win_prob > 0.85:  # Very strong hand (likely the nuts)
                if PokerAction.RAISE in legal_actions:
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'strong', True)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0
            
            if win_prob > 0.65: # Strong hand with value
                if PokerAction.RAISE in legal_actions:
                    raise_amount = self._calculate_raise_amount(round_state, remaining_chips, 'medium', True)
                    return PokerAction.RAISE, raise_amount
                if PokerAction.CALL in legal_actions: return PokerAction.CALL, 0
                return PokerAction.ALL_IN, 0

            if win_prob > 0.4: # Decent hand or good draw
                pot_odds = (round_state.pot + amount_to_call) / (amount_to_call + 1e-9)
                draw_prob, is_draw = self._get_draw_probability(self.hand + self.board)
                
                if is_draw and (draw_prob * pot_odds > 1): # Profitable to call
                    if PokerAction.CALL in legal_actions: return PokerAction.CALL, 0
                
                if PokerAction.CHECK in legal_actions: return PokerAction.CHECK, 0
                if PokerAction.CALL in legal_actions and amount_to_call < 0.1 * round_state.pot:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Weak hand or busted draw
            if PokerAction.CHECK in legal_actions:
               return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
        
    # --- Helper methods ---
    
    def _get_active_players_count(self, round_state: RoundStateClient) -> int:
        count = 0
        for p_id in self.all_players_ids:
            if round_state.player_actions.get(str(p_id)) != 'Fold':
                count += 1
        return count

    def _get_legal_actions(self, round_state: RoundStateClient, remaining_chips: int) -> List[PokerAction]:
        legal = []
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)

        if amount_to_call == 0:
            legal.append(PokerAction.CHECK)
        else:
            legal.append(PokerAction.FOLD)
            if remaining_chips >= amount_to_call:
                legal.append(PokerAction.CALL)

        if round_state.min_raise <= remaining_chips - amount_to_call:
            legal.append(PokerAction.RAISE)
        
        legal.append(PokerAction.ALL_IN)
        return list(set(legal))

    def _calculate_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, strength: str, is_raised: bool) -> int:
        pot = round_state.pot
        bb = self.big_blind
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        if not is_raised:
            amount = 3 * bb if strength == 'medium' else 4 * bb
        else:
            amount = pot if strength == 'strong' else int(0.6 * pot)
        
        return min(max_raise, max(min_raise, amount))

    def _card_to_val(self, card: str) -> Tuple[int, str]:
        rank_str, suit = card[:-1], card[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return (rank, suit)

    def _get_preflop_hand_tier(self, hand: List[str]) -> int:
        c1 = self._card_to_val(hand[0])
        c2 = self._card_to_val(hand[1])
        ranks = sorted([c1[0], c2[0]], reverse=True)
        suited = c1[1] == c2[1]
        is_pair = ranks[0] == ranks[1]

        if is_pair and ranks[0] >= 12: return 1  # AA, KK, QQ
        if suited and ranks == [14, 13]: return 1  # AKs

        if is_pair and ranks[0] >= 10: return 2  # JJ, TT
        if suited and ranks[0] == 14 and ranks[1] >= 11: return 2  # AQs, AJs
        if suited and ranks == [13, 12]: return 2  # KQs
        if not suited and ranks == [14, 13]: return 2  # AKo

        if is_pair and ranks[0] >= 8: return 3  # 99, 88
        if suited and (ranks in [[13, 11], [12, 11], [11, 10], [14, 10]]): return 3
        if not suited and ranks == [14, 12]: return 3  # AQo

        if is_pair: return 4  # 77-22
        if suited and (abs(ranks[0] - ranks[1]) <= 4 or ranks[0] == 14): return 4 # Suited Gappers / Aces

        return 5  # Trash

    def _evaluate_7_cards(self, cards_str: List[str]):
        if len(cards_str) < 5: return -1, []
        cards = sorted([self._card_to_val(c) for c in cards_str], key=lambda x: x[0], reverse=True)
        best_rank = (-1, [])

        for hand_cards in combinations(cards, 5):
            rank_val, kickers = self._evaluate_5_card_hand(list(hand_cards))
            if rank_val > best_rank[0]:
                best_rank = (rank_val, kickers)
            elif rank_val == best_rank[0] and kickers > best_rank[1]:
                best_rank = (rank_val, kickers)
        return best_rank

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]):
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        is_flush = len(set(suits)) == 1
        is_wheel = ranks == [14, 5, 4, 3, 2]
        is_straight = all(ranks[i] - ranks[i+1] == 1 for i in range(4)) or is_wheel
        
        if is_straight and is_flush: return (STRAIGHT_FLUSH, [ranks[0] if not is_wheel else 5])
        
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)
        
        if counts[0] == 4: return (FOUR_OF_A_KIND, [main_ranks[0], main_ranks[1]])
        if counts == [3, 2]: return (FULL_HOUSE, [main_ranks[0], main_ranks[1]])
        if is_flush: return (FLUSH, ranks)
        if is_straight: return (STRAIGHT, [ranks[0] if not is_wheel else 5])
        if counts[0] == 3: return (THREE_OF_A_KIND, [main_ranks[0]] + sorted([r for r in main_ranks[1:]], reverse=True))
        if counts == [2, 2, 1]: return (TWO_PAIR, sorted(main_ranks[:2], reverse=True) + [main_ranks[2]])
        if counts[0] == 2: return (ONE_PAIR, [main_ranks[0]] + sorted([r for r in main_ranks[1:]], reverse=True))
        return (HIGH_CARD, ranks)
    
    def _get_draw_probability(self, all_cards_str: List[str]):
        num_cards = len(all_cards_str)
        if num_cards >= 5: return 0, False

        my_hand = [self._card_to_val(c) for c in all_cards_str]
        suits = Counter(c[1] for c in my_hand)
        ranks = sorted(list(set(c[0] for c in my_hand)))

        outs = 0
        is_draw = False

        if 4 in suits.values(): # Flush draw
            outs += 9
            is_draw = True

        # Straight draw
        for i in range(1, 11):
            needed = set(range(i, i + 5))
            have = set(ranks)
            missing = needed - have
            if len(missing) == 1:
                is_draw = True
                outs += 1

        if is_draw:
            unseen_cards = 52 - num_cards
            prob = outs / unseen_cards if num_cards == 4 else 1 - (((unseen_cards - outs) / unseen_cards) * ((unseen_cards - 1 - outs) / (unseen_cards - 1)))
            return prob, True
        return 0, False

    def _estimate_win_probability(self, hand: List[str], board: List[str], num_opponents: int) -> float:
        """
        Estimates win probability using a Monte Carlo simulation.
        """
        if num_opponents == 0: return 1.0
        
        simulations = 200 # Balance of accuracy and speed
        wins = 0
        
        my_cards_val = [self._card_to_val(c) for c in hand]
        board_val = [self._card_to_val(c) for c in board]
        
        my_full_hand_str = hand + board
        
        for _ in range(simulations):
            deck = [r + s for r in '23456789TJQKA' for s in 'shdc']
            for card_str in my_full_hand_str: deck.remove(card_str)
            
            random.shuffle(deck)
            
            opponents_hands = [deck[i*2:i*2+2] for i in range(num_opponents)]
            
            num_community_needed = 5 - len(board)
            sim_board_val = board_val + [self._card_to_val(c) for c in deck[num_opponents*2:num_opponents*2+num_community_needed]]
            
            my_rank, my_kickers = self._evaluate_7_cards(hand + [c[0] + c[1] for c in sim_board_val])
            my_best = (my_rank, my_kickers)
            
            is_winner = True
            for opp_hand in opponents_hands:
                opp_rank, opp_kickers = self._evaluate_7_cards(opp_hand + [c[0] + c[1] for c in sim_board_val])
                opp_best = (opp_rank, opp_kickers)
                
                if opp_best[0] > my_best[0] or (opp_best[0] == my_best[0] and opp_best[1] > my_best[1]):
                    is_winner = False
                    break
            
            if is_winner:
                wins += 1
                
        return wins / simulations