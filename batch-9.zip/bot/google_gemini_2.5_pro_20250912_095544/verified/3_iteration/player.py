import random
from typing import List, Tuple
from itertools import combinations
from collections import Counter

# The Bot, PokerAction and RoundStateClient classes will be provided by the environment.
# They are included here for context and to allow for stand-alone code analysis.
class Bot:
    def __init__(self) -> None:
        self.id = None
    def set_id(self, player_id: int) -> None:
        self.id = player_id
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass
    def on_round_start(self, round_state, remaining_chips: int) -> None:
        pass
    def get_action(self, round_state, remaining_chips: int) -> Tuple['PokerAction', int]:
        pass
    def on_end_round(self, round_state, remaining_chips: int) -> None:
        pass
    def on_end_game(self, round_state, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

from enum import Enum
class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand charts, Monte Carlo simulation for post-flop
    hand strength estimation, and pot odds calculation to make decisions.
    """
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.board: List[str] = []
        self.all_players: List[int] = []
        self.starting_chips: int = 10000
        self.blind_amount: int = 0

        # Card and hand ranking constants
        self.ranks = "23456789TJQKA"
        self.suits = "shdc"
        self.ranks_map = {r: i for i, r in enumerate(self.ranks, 2)}
        self.inv_ranks_map = {i: r for r, i in self.ranks_map.items()}

        self.HAND_RANK_MAP = {
            "HIGH_CARD": 0, "ONE_PAIR": 1, "TWO_PAIR": 2, "THREE_OF_A_KIND": 3,
            "STRAIGHT": 4, "FLUSH": 5, "FULL_HOUSE": 6, "FOUR_OF_A_KIND": 7,
            "STRAIGHT_FLUSH": 8, "ROYAL_FLUSH": 9
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.all_players = all_players
        self.hand = player_hands

    def on_round_start(self, round_state, remaining_chips: int):
        self.hand = round_state.player_hands[str(self.id)]
        self.board = round_state.community_cards
        if round_state.round_num == 0: # Get initial blind amount
            self.blind_amount = round_state.current_bet

    def get_action(self, round_state, remaining_chips: int) -> Tuple[PokerAction, int]:
        # --- 1. Get Game State Information ---
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        active_players = self._get_active_players_count(round_state)
        num_opponents = active_players - 1

        # --- 2. Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            action, amount = self._get_preflop_action(self.hand, round_state, remaining_chips)
            return self._validate_action(action, amount, round_state, remaining_chips)

        # --- 3. Post-flop Strategy ---
        # Estimate win probability using Monte Carlo simulation
        win_prob = self._estimate_win_probability(self.hand, round_state.community_cards, num_opponents)

        # Calculate pot odds
        pot_odds = 0
        if (round_state.pot + amount_to_call) > 0:
            pot_odds = amount_to_call / (round_state.pot + amount_to_call)

        # --- 4. Decision Making ---
        # If we can check, it's the safest action for non-monster hands.
        if amount_to_call == 0:
            if win_prob > 0.75: # Strong hand, bet for value
                bet_amount = int(round_state.pot * 0.7)
                return self._validate_action(PokerAction.RAISE, bet_amount, round_state, remaining_chips)
            else: # Medium or weak hand, check
                return PokerAction.CHECK, 0

        # We must call, raise, or fold.
        # If win probability is greater than pot odds, a call is mathematically justified.
        if win_prob > pot_odds:
            if win_prob > 0.85 and round_state.round != 'River': # Very strong hand with potential to improve. Raise.
                raise_amount = int(round_state.pot * 1.5)
                return self._validate_action(PokerAction.RAISE, raise_amount, round_state, remaining_chips)
            elif win_prob > 0.9: # Almost certainly winning on the river. Push hard.
                return self._validate_action(PokerAction.RAISE, remaining_chips, round_state, remaining_chips)
            else:
                # Just call if the odds are in our favor but the hand isn't a monster.
                return self._validate_action(PokerAction.CALL, 0, round_state, remaining_chips)
        else:
            # Pot odds are not favorable. Fold unless it's a very small bet.
            # Simple bluff: if we are heads-up on the river and opponent showed weakness
            if num_opponents == 1 and round_state.round == 'River' and win_prob < 0.1:
                # Check if opponent checked to us
                last_player_id = list(round_state.player_actions.keys())[-1]
                if round_state.player_actions[last_player_id] == 'Check':
                     # Bluff with a half-pot bet
                     bluff_amount = int(round_state.pot * 0.5)
                     return self._validate_action(PokerAction.RAISE, bluff_amount, round_state, remaining_chips)
            
            # Not worth calling. Fold.
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state, remaining_chips: int):
        self.hand = []
        self.board = []

    def on_end_game(self, round_state, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    # --------------------------------------------------------------------------
    # Helper Methods
    # --------------------------------------------------------------------------

    def _get_active_players_count(self, round_state) -> int:
        """Counts players who have not folded."""
        # Active players are those in player_bets, or all players if bets haven't started.
        if not round_state.player_bets:
            return len(self.all_players)
        
        # In later rounds, check who hasn't folded.
        # Find player ids that have bet
        players_in_pot = set(round_state.player_bets.keys())
        # Find actions of players that folded
        folded_players = {p_id for p_id, action in round_state.player_actions.items() if action == 'Fold'}
        
        return len(players_in_pot - folded_players)


    def _validate_action(self, action: PokerAction, amount: int, round_state, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Ensures the chosen action is legal, otherwise defaults to a safe action."""
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round

        if action == PokerAction.RAISE:
            # The 'amount' for RAISE is the amount to add on top of the call.
            # Total bet will be amount_to_call + amount
            total_bet = my_bet_in_round + amount_to_call + amount
            
            # Adhere to minimum raise rules
            min_raise_amount = round_state.min_raise
            if amount < min_raise_amount:
                amount = min_raise_amount

            # Can't raise more than we have
            if amount >= remaining_chips - amount_to_call:
                return PokerAction.ALL_IN, 0
            
            return PokerAction.RAISE, amount

        elif action == PokerAction.CALL:
            if amount_to_call <= 0:
                return PokerAction.CHECK, 0
            if amount_to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        elif action == PokerAction.CHECK:
            return (PokerAction.CHECK, 0) if amount_to_call == 0 else (PokerAction.FOLD, 0)

        elif action == PokerAction.ALL_IN:
            return PokerAction.ALL_IN, 0

        return PokerAction.FOLD, 0


    def _get_preflop_action(self, hand: List[str], round_state, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determines pre-flop action based on hand strength and table action."""
        rank1, rank2 = self.ranks_map[hand[0][0]], self.ranks_map[hand[1][0]]
        high_rank, low_rank = max(rank1, rank2), min(rank1, rank2)
        is_suited = hand[0][1] == hand[1][1]
        is_pair = rank1 == rank2

        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        
        # Check if there has been a raise before us
        has_been_raised = round_state.current_bet > self.blind_amount

        # Tier 1 Hands: AA, KK, QQ, JJ, AKs -> Always raise or re-raise
        if (is_pair and high_rank >= 11) or (high_rank == 14 and low_rank == 13 and is_suited):
            if not has_been_raised:
                return PokerAction.RAISE, self.blind_amount * 3  # Raise 4x BB
            else:
                # Re-raise: pot-sized raise
                raise_amount = round_state.pot + amount_to_call
                return PokerAction.RAISE, raise_amount

        # Tier 2 Hands: TT, AQs, AJs, KQs, AKo -> Raise if unopened, call a raise
        if (is_pair and high_rank == 10) or \
           (is_suited and high_rank >= 12 and low_rank >= 11) or \
           (high_rank == 14 and low_rank == 13 and not is_suited):
            if not has_been_raised:
                return PokerAction.RAISE, self.blind_amount * 2 # Raise 3x BB
            elif amount_to_call < remaining_chips * 0.1: # Call if raise is < 10% of our stack
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

        # Tier 3 Hands: 99-77, A10s+, KJs+, QJs, JTs, T9s
        if (is_pair and high_rank >= 7) or \
           (is_suited and high_rank == 14 and low_rank >= 10) or \
           (is_suited and high_rank >= 11):
            if not has_been_raised: # Limp or call small raise
                 return PokerAction.CALL, 0
            elif amount_to_call <= self.blind_amount * 2: # Call small raise
                return PokerAction.CALL, 0

        # Tier 4: Small pairs for set mining
        if is_pair and high_rank < 7:
            # Call only if it's cheap, for implied odds.
            if amount_to_call <= self.blind_amount * 2:
                return PokerAction.CALL, 0

        # All other hands
        return PokerAction.CHECK, 0 # Will be validated to FOLD if a bet is required

    def _estimate_win_probability(self, hand: List[str], board: List[str], num_opponents: int, num_simulations=300) -> float:
        """Estimates win probability using Monte Carlo simulation."""
        if num_opponents == 0:
            return 1.0

        my_hand_val = [self._card_to_val(c) for c in hand]
        board_val = [self._card_to_val(c) for c in board]

        deck_val = [(self.ranks_map[r], s) for r in self.ranks for s in self.suits]
        
        # Remove known cards from the deck
        known_cards_val = set(my_hand_val + board_val)
        deck_val = [card for card in deck_val if card not in known_cards_val]

        wins = 0
        for _ in range(num_simulations):
            sim_deck = deck_val[:]
            random.shuffle(sim_deck)
            
            # Deal cards to opponents and remaining community cards
            opp_hands = []
            for _ in range(num_opponents):
                opp_hands.append(sim_deck[0:2])
                sim_deck = sim_deck[2:]

            num_community_to_deal = 5 - len(board)
            sim_board_xtra = sim_deck[0:num_community_to_deal]

            # Combine original board with simulated cards
            full_sim_board_val = board_val + sim_board_xtra
            community_cards_str = [self.inv_ranks_map[c[0]] + c[1] for c in full_sim_board_val]

            # Evaluate my hand
            my_full_hand_str = hand + community_cards_str
            my_rank, my_kickers = self._evaluate_7_cards(my_full_hand_str)

            # Evaluate opponent hands
            best_opp_rank, best_opp_kickers = -1, []
            for opp_hand_val in opp_hands:
                opp_hand_str = [self.inv_ranks_map[c[0]] + c[1] for c in opp_hand_val]
                opp_full_hand_str = opp_hand_str + community_cards_str
                opp_rank, opp_kickers = self._evaluate_7_cards(opp_full_hand_str)

                if opp_rank > best_opp_rank:
                    best_opp_rank, best_opp_kickers = opp_rank, opp_kickers
                elif opp_rank == best_opp_rank:
                    # Tie-breaking
                    for i in range(len(opp_kickers)):
                        if i >= len(best_opp_kickers) or opp_kickers[i] > best_opp_kickers[i]:
                            best_opp_rank, best_opp_kickers = opp_rank, opp_kickers
                            break
                        if opp_kickers[i] < best_opp_kickers[i]:
                            break

            # Compare my hand to the best opponent hand
            if my_rank > best_opp_rank:
                wins += 1
            elif my_rank == best_opp_rank:
                is_tie = True
                for i in range(len(my_kickers)):
                    if my_kickers[i] > best_opp_kickers[i]:
                        wins += 1
                        is_tie = False
                        break
                    if my_kickers[i] < best_opp_kickers[i]:
                        is_tie = False
                        break
                if is_tie:
                    wins += 0.5 # Split pot

        return wins / num_simulations

    def _card_to_val(self, card_str: str) -> tuple:
        """Converts a card string like 'As' to a value tuple (14, 's')."""
        return self.ranks_map[card_str[0]], card_str[1]

    def _evaluate_7_cards(self, cards_str: List[str]) -> Tuple[int, List[int]]:
        """Finds the best 5-card hand from a list of 7 cards."""
        best_hand_rank = -1, []
        for combo in combinations(cards_str, 5):
            current_rank, current_kickers = self._evaluate_5_cards(list(combo))
            if current_rank > best_hand_rank[0]:
                best_hand_rank = current_rank, current_kickers
            elif current_rank == best_hand_rank[0]:
                # Tie-breaking with kickers
                for i in range(len(current_kickers)):
                     if i >= len(best_hand_rank[1]) or current_kickers[i] > best_hand_rank[1][i]:
                        best_hand_rank = current_rank, current_kickers
                        break
                     if current_kickers[i] < best_hand_rank[1][i]:
                        break
        return best_hand_rank

    def _evaluate_5_cards(self, hand_str: List[str]) -> Tuple[int, List[int]]:
        """Evaluates a 5-card hand and returns its rank and kickers."""
        vals = sorted([self.ranks_map[c[0]] for c in hand_str], reverse=True)
        suits = [c[1] for c in hand_str]
        
        is_flush = len(set(suits)) == 1
        is_straight = (len(set(vals)) == 5) and (vals[0] - vals[4] == 4)
        is_ace_low_straight = vals == [14, 5, 4, 3, 2]
        if is_ace_low_straight:
            is_straight = True
            vals = [5, 4, 3, 2, 1] # Treat Ace as 1 for kicker comparison

        if is_straight and is_flush:
            if vals[0] == 14: # Ace-high straight flush is a Royal Flush
              return self.HAND_RANK_MAP["ROYAL_FLUSH"], [vals[0]]
            return self.HAND_RANK_MAP["STRAIGHT_FLUSH"], [vals[0]]

        counts = Counter(vals)
        rank_counts = sorted(counts.values(), reverse=True)
        
        if rank_counts[0] == 4:
            four_rank = [r for r, c in counts.items() if c == 4][0]
            kicker = [r for r, c in counts.items() if c == 1][0]
            return self.HAND_RANK_MAP["FOUR_OF_A_KIND"], [four_rank, kicker]
        
        if rank_counts == [3, 2]:
            three_rank = [r for r, c in counts.items() if c == 3][0]
            two_rank = [r for r, c in counts.items() if c == 2][0]
            return self.HAND_RANK_MAP["FULL_HOUSE"], [three_rank, two_rank]

        if is_flush:
            return self.HAND_RANK_MAP["FLUSH"], vals

        if is_straight:
            return self.HAND_RANK_MAP["STRAIGHT"], [vals[0]]

        if rank_counts[0] == 3:
            three_rank = [r for r, c in counts.items() if c == 3][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return self.HAND_RANK_MAP["THREE_OF_A_KIND"], [three_rank] + kickers

        if rank_counts == [2, 2, 1]:
            pairs = sorted([r for r, c in counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in counts.items() if c == 1][0]
            return self.HAND_RANK_MAP["TWO_PAIR"], pairs + [kicker]

        if rank_counts[0] == 2:
            pair_rank = [r for r, c in counts.items() if c == 2][0]
            kickers = sorted([r for r, c in counts.items() if c == 1], reverse=True)
            return self.HAND_RANK_MAP["ONE_PAIR"], [pair_rank] + kickers
            
        return self.HAND_RANK_MAP["HIGH_CARD"], vals