import random
from typing import List, Tuple
from collections import Counter
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot implementing a strategy based on hand equity estimation, pot odds,
    and situational awareness (position, opponent actions).
    """

    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.round_state: RoundStateClient = None
        self.remaining_chips: int = 0
        self.starting_chips: int = 10000
        self.num_players: int = 0
        self.was_preflop_aggressor: bool = False
        
        # Card ranks and suits for evaluation
        self.card_ranks = '23456789TJQKA'
        self.card_rank_map = {rank: i for i, rank in enumerate(self.card_ranks, 2)}
    
    # --- Event Handlers ---

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.num_players = len(all_players)
        self.my_hand = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips
        self.was_preflop_aggressor = False
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used later to build opponent models
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Can be used for post-game analysis or learning
        pass

    # --- Core Action Logic ---

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.round_state = round_state
        self.remaining_chips = remaining_chips

        # Safe bet amount calculation
        def get_bet_amount(fraction, min_bet, max_bet):
            amount = int(self.round_state.pot * fraction)
            return min(max_bet, max(min_bet, amount))

        # Core Decision Logic
        if self.round_state.round == 'Preflop':
            # Preflop: Use Chen formula for hand strength
            chen_score = self._get_chen_score(self.my_hand)
            num_active_players = sum(1 for bet in self.round_state.player_bets.values() if bet > -1)
            
            # Action history
            raises_count = sum(1 for action in self.round_state.player_actions.values() if action == 'Raise')
            calls_count = sum(1 for action in self.round_state.player_actions.values() if action == 'Call')
            
            amount_to_call = self.round_state.current_bet - self.round_state.player_bets.get(str(self.id), 0)

            # Decision based on score and game state
            if chen_score >= 10:  # Premium hands (AA, KK, QQ, AKs)
                if raises_count == 0:
                    bet_amount = get_bet_amount(1.0, self.round_state.min_raise, self.round_state.max_raise)
                    self.was_preflop_aggressor = True
                    return PokerAction.RAISE, max(bet_amount, 3 * round_state.current_bet) if round_state.current_bet > 0 else 3 * 10 # 10 is default big blind
                else: # Re-raise (3-bet)
                    bet_amount = get_bet_amount(2.5, self.round_state.min_raise, self.round_state.max_raise)
                    self.was_preflop_aggressor = True
                    return PokerAction.RAISE, bet_amount
            elif chen_score >= 8: # Strong hands
                if raises_count == 0:
                    bet_amount = get_bet_amount(0.8, self.round_state.min_raise, self.round_state.max_raise)
                    self.was_preflop_aggressor = True
                    return PokerAction.RAISE, max(bet_amount, int(2.5 * round_state.current_bet)) if round_state.current_bet > 0 else 3 * 10
                elif raises_count == 1 and amount_to_call < self.remaining_chips * 0.1:
                    return PokerAction.CALL, 0
            elif chen_score >= 6: # Playable hands
                if raises_count == 0 and calls_count <= 2:
                    if amount_to_call > 0:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.CHECK, 0
                elif amount_to_call > 0 and amount_to_call < self.remaining_chips * 0.05:
                     return PokerAction.CALL, 0
            
            # Default fallback action
            if amount_to_call == 0:
                return PokerAction.CHECK, 0
            
            # If cost to call is minimal (e.g. big blind facing a limp), call with wider range
            if amount_to_call <= 10 and self.round_state.player_bets.get(str(self.id), 0) >= 5: # Assuming 5/10 blinds
                 return PokerAction.CALL, 0
            
            return PokerAction.FOLD, 0
        
        else:
            # Postflop: Use Monte Carlo Equity calculation
            num_opponents = len([pid for pid, bet in round_state.player_bets.items() if pid != str(self.id) and bet != -1])
            if num_opponents == 0: return PokerAction.CHECK, 0

            # More simulations on later streets
            sim_count = 200 if self.round_state.round == 'Flop' else 400
            
            equity = self._monte_carlo_equity(self.my_hand, self.round_state.community_cards, num_opponents, sim_count)
            amount_to_call = self.round_state.current_bet - self.round_state.player_bets.get(str(self.id), 0)
            
            pot_odds = amount_to_call / (self.round_state.pot + amount_to_call + 1e-6)

            # Decision based on equity
            if amount_to_call == 0: # We can check or bet
                if equity > 0.85: # Monster hand, bet big for value
                    return PokerAction.RAISE, get_bet_amount(0.8, self.round_state.min_raise, self.round_state.max_raise)
                elif equity > 0.6: # Strong hand, value bet
                    return PokerAction.RAISE, get_bet_amount(0.6, self.round_state.min_raise, self.round_state.max_raise)
                elif equity > 0.4 and self.was_preflop_aggressor and self.round_state.round == 'Flop': # C-bet
                    return PokerAction.RAISE, get_bet_amount(0.5, self.round_state.min_raise, self.round_state.max_raise)
                else:
                    return PokerAction.CHECK, 0
            else: # Facing a bet
                if equity > 0.85 and round_state.min_raise <= remaining_chips: # Re-raise with monsters
                    return PokerAction.RAISE, get_bet_amount(2.0, self.round_state.min_raise, self.round_state.max_raise)
                if equity > pot_odds: # Call if odds are good
                    # If we have a very strong hand, but not monster, just call to not scare opponent
                    if amount_to_call > self.remaining_chips * 0.4:
                        if equity > 0.7:
                            return PokerAction.ALL_IN, 0 
                        else:
                            return PokerAction.FOLD, 0
                    return PokerAction.CALL, 0
                else: # Fold if odds are bad
                    return PokerAction.FOLD, 0

    # --- Helper Functions ---

    def _get_chen_score(self, hand: List[str]) -> float:
        """ Calculates hand strength using the Chen formula. """
        card1, card2 = hand
        rank1, suit1 = card1[:-1], card1[-1]
        rank2, suit2 = card2[:-1], card2[-1]
        
        val1, val2 = self.card_rank_map[rank1], self.card_rank_map[rank2]
        high_card = max(val1, val2)
        low_card = min(val1, val2)

        # 1. High card score
        score = 0
        if high_card == 14: score = 10  # Ace
        elif high_card == 13: score = 8 # King
        elif high_card == 12: score = 7 # Queen
        elif high_card == 11: score = 6 # Jack
        else: score = high_card / 2.0
            
        # 2. Pair bonus
        if val1 == val2:
            score = max(score * 2, 5)

        # 3. Suited bonus
        if suit1 == suit2:
            score += 2

        # 4. Connector penalty
        gap = high_card - low_card - 1
        if gap == 0 and high_card < 12: score += 1
        if gap == 1 and high_card < 12: score += 1
        if gap == 1: score -= 1
        elif gap == 2: score -= 2
        elif gap == 3: score -= 4
        elif gap >= 4: score -= 5
        
        return score

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """ 'As' -> (14, 's') """
        rank, suit = card[:-1], card[-1]
        return self.card_rank_map[rank], suit

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple:
        """ Evaluates the best 5-card hand from 7 cards. """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            # Not enough cards to form a 5-card hand, evaluate based on what's available
            # This is a fallback and shouldn't happen in a normal game post-flop
            parsed_cards = [self._parse_card(c) for c in all_cards]
            ranks = sorted([p[0] for p in parsed_cards], reverse=True)
            return (0, *ranks)

        best_rank = (-1,)
        for combo in combinations(all_cards, 5):
            current_rank = self._get_5_card_rank(list(combo))
            if current_rank > best_rank:
                best_rank = current_rank
        return best_rank

    def _get_5_card_rank(self, hand: List[str]) -> Tuple:
        """ Determines the rank of a 5-card hand. Returns a tuple for comparison. """
        parsed_cards = [self._parse_card(c) for c in hand]
        ranks = sorted([p[0] for p in parsed_cards], reverse=True)
        suits = [p[1] for p in parsed_cards]
        
        is_flush = len(set(suits)) == 1
        # Straight check (handles A-5 straight)
        is_straight = (ranks[0] - ranks[4] == 4 and len(set(ranks)) == 5) or (ranks == [14, 5, 4, 3, 2])
        if ranks == [14, 5, 4, 3, 2]: ranks = [5, 4, 3, 2, 1] # Ace low for ranking

        # Hand Ranks
        if is_straight and is_flush: return (8, ranks[0])  # Straight Flush
        
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)

        if counts[0] == 4: return (7, main_ranks[0], main_ranks[1])  # Four of a Kind
        if counts == [3, 2]: return (6, main_ranks[0], main_ranks[1])  # Full House
        if is_flush: return (5, *ranks)  # Flush
        if is_straight: return (4, ranks[0])  # Straight
        if counts[0] == 3: return (3, main_ranks[0], main_ranks[1], main_ranks[2])  # Three of a Kind
        if counts == [2, 2, 1]: return (2, main_ranks[0], main_ranks[1], main_ranks[2])  # Two Pair
        if counts[0] == 2: return (1, main_ranks[0], *[r for r in main_ranks if r != main_ranks[0]]) # One Pair
        return (0, *ranks)  # High Card

    def _monte_carlo_equity(self, my_hand: List[str], community_cards: List[str], num_opponents: int, num_simulations: int) -> float:
        """ Estimates win probability via Monte Carlo simulation. """
        wins = 0
        full_deck = {r + s for r in self.card_ranks for s in 'shdc'}
        known_cards = set(my_hand + community_cards)
        remaining_deck = list(full_deck - known_cards)

        for _ in range(num_simulations):
            deck_copy = remaining_deck[:]
            random.shuffle(deck_copy)
            
            # Deal remaining community cards
            num_to_deal = 5 - len(community_cards)
            sim_community = community_cards + deck_copy[:num_to_deal]
            
            # Deal opponent hands
            opp_hands = []
            start_index = num_to_deal
            for i in range(num_opponents):
                opp_hands.append(deck_copy[start_index : start_index + 2])
                start_index += 2

            my_best_rank = self._evaluate_hand(my_hand, sim_community)
            
            # Check if my hand wins
            is_winner = True
            is_tie = False
            for opp_hand in opp_hands:
                opp_best_rank = self._evaluate_hand(opp_hand, sim_community)
                if opp_best_rank > my_best_rank:
                    is_winner = False
                    break
                if opp_best_rank == my_best_rank:
                    is_tie = True

            if is_winner:
                if is_tie:
                    # simplistic tie handling
                    wins += 0.5
                else:
                    wins += 1
        
        return wins / num_simulations if num_simulations > 0 else 0