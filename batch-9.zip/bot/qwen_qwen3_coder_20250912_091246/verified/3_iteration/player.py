from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.starting_chips = 0
        self.current_chips = 0
        self.player_id = None
        self.all_players = []
        self.position = 0  # 0 = early, 1 = middle, 2 = late
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.current_chips = starting_chips
        self.hand_cards = player_hands
        self.all_players = all_players
        self.player_id = None  # Will be set by set_id method
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get our current bet
        our_bet = round_state.player_bets.get(str(self.id), 0)
        # Amount needed to call
        call_amount = round_state.current_bet - our_bet
        
        # Calculate pot odds
        pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
        
        # Simple hand strength evaluation
        hand_strength = self._evaluate_hand_strength(self.hand_cards, round_state.community_cards)
        
        # Position calculation (simplified)
        active_players = len(round_state.current_player)
        if active_players <= 2:
            position_factor = 1.2  # Heads-up, more aggressive
        else:
            position_factor = 1.0
            
        # Decision making based on hand strength and situation
        if call_amount == 0:
            # We can check - no current bet
            if hand_strength > 0.7:
                # Strong hand, try to build pot
                min_raise = round_state.min_raise
                max_raise = min(round_state.max_raise, int(remaining_chips * 0.5))
                if min_raise <= max_raise and min_raise > 0:
                    raise_amount = min_raise + int((max_raise - min_raise) * random.random() * 0.3)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength > 0.4:
                # Decent hand, check to see what happens
                return (PokerAction.CHECK, 0)
            else:
                # Weak hand, still might check to see flop
                if random.random() < 0.7:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)  # Default to check
        else:
            # There is a bet to call
            if hand_strength > 0.85:
                # Very strong hand, consider raising or calling
                if hand_strength > 0.95 and random.random() < 0.7:
                    # Try to raise if we have a very strong hand
                    min_raise = round_state.min_raise
                    max_raise = min(round_state.max_raise, remaining_chips)
                    if min_raise <= max_raise and min_raise > 0:
                        raise_amount = min_raise + int((max_raise - min_raise) * random.random() * 0.5)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
            elif hand_strength > 0.6:
                # Medium strength, call if pot odds are reasonable
                if pot_odds < 0.35:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength > 0.4:
                # Weak but playable, only call if getting good odds
                if pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Very weak hand, fold unless getting excellent odds
                if pot_odds < 0.1:
                    return (PokerAction.CALL, 0)  # Desperation call
                else:
                    return (PokerAction.FOLD, 0)
                
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Extract ranks and suits
        ranks = [card[0] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        
        # Pair bonus
        pair_bonus = 0.2 if ranks[0] == ranks[1] else 0
        
        # High card value
        high_card_value = 0
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        high_card_value = max(rank_values.get(ranks[0], 0), rank_values.get(ranks[1], 0)) / 14.0
        
        # suited bonus
        suited_bonus = 0.1 if suits[0] == suits[1] else 0
        
        # Connectors bonus
        rank1 = rank_values.get(ranks[0], 0)
        rank2 = rank_values.get(ranks[1], 0)
        connector_bonus = 0.05 if abs(rank1 - rank2) == 1 else 0
        
        # Base strength calculation
        strength = (high_card_value * 0.5) + pair_bonus + suited_bonus + connector_bonus
        
        # Adjust based on community cards (simplified)
        if len(community_cards) > 0:
            # If we have more than 2 cards, we're past preflop
            # This is a very simplified estimation
            strength = min(1.0, strength * (1.0 + len(community_cards) * 0.1))
        
        return min(1.0, strength)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass