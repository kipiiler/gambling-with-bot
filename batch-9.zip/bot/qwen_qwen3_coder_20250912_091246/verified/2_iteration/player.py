from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hand = []
        self.all_players = []
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.blind_amount = 0
        self.round_num = 0
        self.preflop_count = 0
        self.aggressive_factor = 0.5  # Default aggression level
        self.tightness_factor = 0.3   # Default tightness level

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.all_players = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.blind_amount = blind_amount
        self.preflop_count = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """Estimate hand strength based on hole cards and community cards."""
        # Simplified hand strength evaluation
        # In a real implementation, you'd use a more robust hand evaluator
        
        # High card values for initial strength (preflop)
        card_values = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
            '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        suits = [card[1] for card in hand]
        ranks = [card[0] for card in hand]
        
        # Initial strength based on hole cards
        rank1_val = card_values[ranks[0]]
        rank2_val = card_values[ranks[1]]
        
        # Pair bonus
        if rank1_val == rank2_val:
            return min(0.9, (rank1_val / 14) * 0.7 + 0.3)
        
        # Suited bonus
        suited_bonus = 0.1 if suits[0] == suits[1] else 0
        
        # High card value
        high_card_val = max(rank1_val, rank2_val) / 14
        low_card_val = min(rank1_val, rank2_val) / 14
        
        # Connectors bonus
        gap = abs(rank1_val - rank2_val)
        connectors_bonus = 0
        if gap == 1:  # Connected cards
            connectors_bonus = 0.05
        elif gap == 2:  # One gap
            connectors_bonus = 0.03
        elif gap == 3:  # Two gaps
            connectors_bonus = 0.01
            
        # Base strength calculation
        base_strength = (high_card_val + low_card_val) / 2
        strength = min(0.9, base_strength + suited_bonus + connectors_bonus)
        
        # Post-flop adjustments
        if len(community_cards) > 0:
            # This is a very simplified post-flop evaluation
            # In reality, this would involve checking for pairs, straights, flushes, etc.
            strength = min(0.95, strength + len(community_cards) * 0.05)
            
        return strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get current bet information
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - my_current_bet
        
        # Calculate pot odds
        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-8) if round_state.pot > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hand, round_state.community_cards)
        
        # Adjust based on position and game stage
        is_preflop = round_state.round == "Preflop"
        is_turn_or_river = round_state.round in ["Turn", "River"]
        
        # Positional adjustments
        active_players = len(round_state.current_player)
        position_factor = 1.0
        if self.id == self.big_blind_player_id and is_preflop:
            position_factor = 1.2  # Slightly more aggressive in big blind
        
        # Modify hand strength based on game situation
        adjusted_strength = hand_strength * position_factor
        
        # Aggression factors based on position and stack size
        stack_ratio = remaining_chips / self.starting_chips if self.starting_chips > 0 else 1
        
        # Determine action based on hand strength and game situation
        if is_preflop:
            self.preflop_count += 1
            
            # Very strong hands (AA, KK, QQ, AK)
            if adjusted_strength > 0.8:
                if amount_to_call == 0:
                    # We can raise
                    raise_amount = min(
                        max(round_state.min_raise, int(remaining_chips * 0.1)),
                        round_state.max_raise
                    )
                    return (PokerAction.RAISE, raise_amount)
                elif pot_odds < 0.33:  # Good pot odds
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Medium strength hands (JJ, TT, AQ, AJ)
            elif adjusted_strength > 0.6:
                if amount_to_call == 0:
                    # We can raise
                    raise_amount = min(
                        max(round_state.min_raise, int(remaining_chips * 0.05)),
                        round_state.max_raise
                    )
                    return (PokerAction.RAISE, raise_amount)
                elif pot_odds < 0.25:
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Weak but playable hands
            elif adjusted_strength > 0.4:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.15 and amount_to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Very weak hands
            else:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        else:  # Post-flop
            # Very strong made hands
            if adjusted_strength > 0.8:
                if amount_to_call == 0:
                    raise_amount = min(
                        max(round_state.min_raise, int(round_state.pot * 0.75)),
                        round_state.max_raise
                    )
                    return (PokerAction.RAISE, raise_amount)
                elif pot_odds < 0.4:
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
            
            # Medium strength hands
            elif adjusted_strength > 0.5:
                if amount_to_call == 0:
                    raise_amount = min(
                        max(round_state.min_raise, int(round_state.pot * 0.5)),
                        round_state.max_raise
                    )
                    return (PokerAction.RAISE, raise_amount)
                elif pot_odds < 0.3:
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Weak hands
            else:
                if amount_to_call == 0:
                    if active_players <= 2:  # We're heads-up or in a steal situation
                        raise_amount = min(
                            max(round_state.min_raise, int(round_state.pot * 0.5)),
                            round_state.max_raise
                        )
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                elif pot_odds < 0.15:
                    if amount_to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Fallback - if we get here, check/call if possible, otherwise fold
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        elif amount_to_call <= remaining_chips:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could be used for learning/statistics tracking
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could be used for final analysis
        pass