from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_remaining_chips = 10000
        self.aggression_factor = 0.6  # Base chance to bluff or raise
        self.tightness_factor = 0.4   # Threshold for hand strength to play
        self.positional_advantage = 0 # Track position relative to blinds
        self.game_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_remaining_chips = starting_chips
        # Identify our position relative to blinds (late position is better)
        my_index = all_players.index(self.id)
        bb_index = all_players.index(big_blind_player_id)
        sb_index = all_players.index(small_blind_player_id)
        # Calculate distance from acting last (late position advantage)
        self.positional_advantage = (len(all_players) - ((my_index - bb_index) % len(all_players))) / len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ A simplified heuristic-based hand strength evaluator """
        if not hole_cards:
            return 0.0
            
        # Convert cards to ranks and suits
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # High card value
        high_card = max(hole_ranks)
        pair_bonus = 0
        suited_bonus = 0
        
        # Pair bonus
        if hole_ranks[0] == hole_ranks[1]:
            pair_bonus = 0.3 + (hole_ranks[0] / 14) * 0.4  # Pair strength scaled by rank
            
        # Suited bonus
        if hole_suits[0] == hole_suits[1]:
            suited_bonus = 0.15
            
        # Connector/Gapper adjustment
        gap = abs(hole_ranks[0] - hole_ranks[1])
        connector_bonus = max(0, 0.1 - gap * 0.02)  # Decreases with gap size
        
        # Base strength calculation
        base_strength = (high_card / 14) * 0.4 + pair_bonus + suited_bonus + connector_bonus
        
        # Community cards influence (simplified)
        if len(community_cards) >= 3:
            # Simple top pair check
            comm_ranks = [ranks[card[0]] for card in community_cards]
            comm_suits = [card[1] for card in community_cards]
            
            # Count matches with hole cards
            matches = sum(1 for r in comm_ranks if r in hole_ranks)
            if matches >= 1:
                base_strength += 0.2  # Top pair or better
                
            # Flush draw potential
            for suit in set(hole_suits + comm_suits):
                total_suited = (hole_suits + comm_suits).count(suit)
                if total_suited >= 4:
                    base_strength += 0.15  # Flush draw or made flush
                    
        return min(1.0, base_strength)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.my_remaining_chips = remaining_chips
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Adjust strategy based on position and game stage
        positional_boost = self.positional_advantage * 0.15
        round_multiplier = 1.0
        if round_state.round == "Preflop":
            round_multiplier = 0.8
        elif round_state.round == "Flop":
            round_multiplier = 1.0
        elif round_state.round == "Turn":
            round_multiplier = 1.1
        elif round_state.round == "River":
            round_multiplier = 1.2
            
        # Dynamic tightness and aggression based on stack depth
        stack_ratio = remaining_chips / self.starting_chips
        dynamic_tightness = self.tightness_factor * (1.0 if stack_ratio > 0.5 else 1.2)  # Tighten when short stacked
        dynamic_aggression = self.aggression_factor * (1.0 if stack_ratio > 0.3 else 0.7)  # Less bluffing when short
        
        # Combined decision factors
        effective_strength = hand_strength + positional_boost
        threshold = dynamic_tightness * round_multiplier
        
        # All-in situations
        if to_call >= remaining_chips:
            if effective_strength > 0.7:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # No need to call, check or potentially bluff
        if to_call == 0:
            if effective_strength > threshold or random.random() < dynamic_aggression * 0.2:
                raise_amount = min(max_raise, max(min_raise, int(0.7 * max_raise)))
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
                
        # Need to call, evaluate whether to call, raise, or fold
        pot_odds = to_call / (round_state.pot + to_call + 1e-5)  # Add epsilon to avoid division by zero
        
        if effective_strength > pot_odds * 1.2:  # Slightly better than break-even
            if effective_strength > threshold + 0.1 and random.random() < dynamic_aggression:
                raise_amount = min(max_raise, max(min_raise, int((0.6 + 0.4 * random.random()) * max_raise)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CALL, 0)
        else:
            # Consider bluffing with some probability
            if random.random() < dynamic_aggression * 0.1 and round_state.round in ["Flop", "Turn"]:
                raise_amount = min(max_raise, max(min_raise, int(0.7 * max_raise)))
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass