from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.player_id = None
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.player_id = self.id
        self.is_big_blind = (big_blind_player_id == self.player_id)
        self.is_small_blind = (small_blind_player_id == self.player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset flags for new round if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Parse hole cards
        hole_cards = self.hole_cards
        
        # Basic hand strength evaluation
        hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
        
        # Positional play - check if we're in early/mid/late position
        # Approximate position by counting active players after us
        active_players_after = 0
        current_players = list(round_state.current_player)
        try:
            my_index = current_players.index(self.player_id)
            active_players_after = len(current_players) - my_index - 1
        except ValueError:
            # Fallback if not in current player list (shouldn't happen)
            active_players_after = 0
        
        # Aggression factor based on position and hand strength
        # Late position + strong hand = more aggressive
        # Early position + weak hand = more passive/fold
        
        # Determine required action
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        
        # Pre-flop strategy
        if round_state.round == "Preflop":
            # Simple pre-flop hand ranking
            rank_value = self._preflop_rank(hole_cards)
            
            # Adjust based on position
            if active_players_after <= 1:  # Button or blinds
                min_rank = 0.4
            elif active_players_after <= 3:  # Cutoff or MP
                min_rank = 0.6
            else:  # Early position
                min_rank = 0.7
                
            if rank_value >= min_rank:
                if to_call == 0:
                    # No bet yet, raise
                    raise_amount = min(round_state.min_raise * 2, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    # There's a bet, decide to call or raise
                    if rank_value > 0.8 or (rank_value > 0.6 and to_call <= remaining_chips * 0.1):
                        raise_amount = min(to_call * 2 + round_state.min_raise, remaining_chips)
                        if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    elif to_call <= remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Post-flop strategy
        else:
            # Post-flop decisions based on hand strength
            if hand_strength >= 0.8:  # Strong hand
                if to_call == 0:
                    raise_amount = min(max(int(round_state.pot * 0.75), round_state.min_raise), remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    if to_call <= remaining_chips * 0.3:
                        return (PokerAction.CALL, 0)
                    elif to_call <= remaining_chips * 0.5:
                        raise_amount = min(to_call + round_state.min_raise, remaining_chips)
                        if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)  # For value with strong hand
            elif hand_strength >= 0.5:  # Medium strength
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif hand_strength >= 0.3:  # Weak but playable
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:  # Very weak
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                
        # Default fallback
        if to_call > 0:
            if to_call <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up any round-specific state if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or logging if needed
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """A very simplified hand strength evaluator."""
        if not community_cards:
            # Pre-flop strength
            return self._preflop_rank(hole_cards)
        
        # Simple approximation based on made hands
        # Count potential pairs, straights, flushes
        all_cards = hole_cards + community_cards
        
        # Very basic heuristic - replace with more sophisticated logic
        rank_chars = [card[0] for card in all_cards]
        suit_chars = [card[1] for card in all_cards]
        
        # Count pairs
        rank_counts = {}
        for r in rank_chars:
            rank_counts[r] = rank_counts.get(r, 0) + 1
            
        pairs = len([c for c in rank_counts.values() if c >= 2])
        trips = len([c for c in rank_counts.values() if c >= 3])
        quads = len([c for c in rank_counts.values() if c >= 4])
        
        # Flush draw
        suit_counts = {}
        for s in suit_chars:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        flush_draw = max(suit_counts.values()) >= 4
        
        # Straight draw would require more complex logic
        
        value = 0.2  # Base value
        
        # Add value for made hands
        if quads:
            value = 0.95
        elif trips:
            value = 0.85
        elif pairs >= 2:
            value = 0.7
        elif pairs:
            value = 0.5
        else:
            # High card strength
            high_ranks = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
            max_rank = 0
            for card in hole_cards:
                r = card[0]
                val = high_ranks.get(r, int(r) if r.isdigit() else 0)
                max_rank = max(max_rank, val)
            value += min(0.3, max_rank / 30.0)  # Normalize to ~0.3 max
        
        # Add value for draws
        if flush_draw:
            value += 0.1
            
        return min(1.0, value)

    def _preflop_rank(self, hole_cards: List[str]) -> float:
        """Simple pre-flop hand ranking."""
        if len(hole_cards) < 2:
            return 0.0
            
        ranks = [card[0] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        
        # Rank values
        rank_values = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        vals = sorted([rank_values[r] for r in ranks], reverse=True)
        
        is_pair = vals[0] == vals[1]
        is_suited = suits[0] == suits[1]
        
        high_card = vals[0]
        low_card = vals[1]
        
        if is_pair:
            # Pocket pairs
            if high_card >= 13:  # AA, KK, QQ, JJ
                return 0.9
            elif high_card >= 11:  # TT, 99
                return 0.75
            elif high_card >= 8:  # 88, 77
                return 0.6
            else:
                return 0.5  # Smaller pairs
        else:
            # Non-pairs
            gap = high_card - low_card
            high_value = high_card/14.0
            low_value = low_card/14.0
            
            base = (high_value + low_value) / 2.0
            
            # Connector bonus
            if gap == 1:
                base += 0.05
            # One gap
            elif gap == 2:
                base += 0.03
                
            # Suited bonus
            if is_suited:
                base += 0.1
                
            # Top cards bonus
            if high_card >= 13:  # A or K
                base += 0.1
            elif high_card >= 11:  # Q or J
                base += 0.05
                
            return min(0.95, base)