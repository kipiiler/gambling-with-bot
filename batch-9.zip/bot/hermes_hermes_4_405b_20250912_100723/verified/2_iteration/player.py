from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.player_index = None
        self.starting_chips = 10000

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.player_index = all_players.index(self.id)
            self.hole_cards = player_hands[self.player_index]
        except (ValueError, IndexError):
            self.hole_cards = None
        self.starting_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if round_state.round_num == 0 and self.hole_cards is not None:
                ranks = [card[0] for card in self.hole_cards]
                suits = [card[1] for card in self.hole_cards]
                
                is_pair = ranks[0] == ranks[1]
                is_suited = suits[0] == suits[1]
                high_cards = ranks[0] in ['A', 'K'] and ranks[1] in ['A', 'K']
                
                if is_pair and ranks[0] in ['Q', 'K', 'A']:
                    if remaining_chips >= round_state.min_raise + round_state.current_bet:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif high_cards and is_suited:
                    if remaining_chips >= round_state.min_raise + round_state.current_bet:
                        return (PokerAction.RAISE, round_state.min_raise)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if round_state.current_bet == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        except:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass