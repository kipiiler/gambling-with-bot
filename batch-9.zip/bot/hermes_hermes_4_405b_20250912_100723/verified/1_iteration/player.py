import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }

    def _parse_card(self, card_str):
        rank_char = card_str[0]
        suit_char = card_str[1]
        rank = self.rank_map[rank_char]
        return (rank, suit_char)

    def _get_preflop_strength(self, hand):
        if len(hand) != 2:
            return 0
        
        card1 = self._parse_card(hand[0])
        card2 = self._parse_card(hand[1])
        rank1, suit1 = card1
        rank2, suit2 = card2
        
        # Sort by rank
        ranks = sorted([rank1, rank2])
        is_suited = (suit1 == suit2)
        
        # Pairs
        if ranks[0] == ranks[1]:
            if ranks[0] >= 10:  # TT+
                return 2
            elif ranks[0] >= 5:  # 55-99
                return 1
            else:
                return 0
        
        # High cards
        if is_suited:
            if ranks[1] == 14 and ranks[0] >= 12:  # AKs, AQs
                return 2
            if ranks[1] == 13 and ranks[0] == 12:  # KQs
                return 2
            if ranks[1] == 12 and ranks[0] == 11:  # QJs
                return 1
            if ranks[1] == 11 and ranks[0] == 10:  # JTs
                return 1
            if ranks[1] == 14 and ranks[0] >= 5:  # A5s+ (suited aces)
                return 1
        else:
            if ranks[1] == 14 and ranks[0] == 13:  # AKo
                return 2
            if ranks[1] == 14 and ranks[0] == 12:  # AQo
                return 1
            if ranks[1] == 13 and ranks[0] == 12:  # KQo
                return 1
            if ranks[1] == 13 and ranks[0] == 11:  # KJo
                return 1
            if ranks[1] == 12 and ranks[0] == 11:  # QJo
                return 1
            if ranks[1] == 11 and ranks[0] == 10:  # JTo
                return 1
        
        return 0

    def _evaluate_combo(self, combo):
        ranks = sorted([card[0] for card in combo])
        suits = [card[1] for card in combo]
        flush = len(set(suits)) == 1
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        straight = False
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    straight = True
                    break
            if not straight and set(ranks) >= {14, 2, 3, 4, 5}:
                straight = True
        
        # Count ranks
        count = {}
        for r in ranks:
            count[r] = count.get(r, 0) + 1
        count_values = sorted(count.values(), reverse=True)
        
        if straight and flush:
            if ranks == [10, 11, 12, 13, 14]:
                return 10  # Royal flush
            return 9  # Straight flush
        if count_values[0] == 4:
            return 8  # Four of a kind
        if count_values[0] == 3 and count_values[1] == 2:
            return 7  # Full house
        if flush:
            return 6  # Flush
        if straight:
            return 5  # Straight
        if count_values[0] == 3:
            return 4  # Three of a kind
        if count_values[0] == 2 and count_values[1] == 2:
            return 3  # Two pair
        if count_values[0] == 2:
            return 2  # One pair
        return 1  # High card

    def _evaluate_hand(self, cards):
        if len(cards) < 5:
            return 0
        best_score = 0
        for combo in itertools.combinations(cards, 5):
            score = self._evaluate_combo(combo)
            if score > best_score:
                best_score = score
        return best_score

    def _has_flush_draw(self, cards):
        suits = [card[1] for card in cards]
        suit_count = {}
        for suit in suits:
            suit_count[suit] = suit_count.get(suit, 0) + 1
        for count in suit_count.values():
            if count >= 4:
                return True
        return False

    def _has_straight_draw(self, cards):
        ranks = [card[0] for card in cards]
        unique_ranks = sorted(set(ranks))
        
        # Wheel draw
        if set(ranks) >= {14, 2, 3, 4} or set(ranks) >= {2, 3, 4, 5}:
            return True
        
        # Open-ended or gutshot
        for i in range(len(unique_ranks) - 3):
            gap1 = unique_ranks[i+3] - unique_ranks[i]
            if gap1 == 3:  # 4 consecutive (open-ended)
                return True
            if gap1 == 4:  # Gutshot (one missing in the middle)
                return True
        return False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - our_bet
            
            if round_state.round == 'Preflop':
                hand_category = self._get_preflop_strength(self.hole_cards)
                
                if hand_category == 2:
                    if amount_to_call == 0:
                        bet_amount = 3 * self.blind_amount
                        if bet_amount < round_state.min_raise:
                            bet_amount = round_state.min_raise
                        if bet_amount > round_state.max_raise:
                            bet_amount = round_state.max_raise
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        if amount_to_call < 0.1 * remaining_chips:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif hand_category == 1:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call < 0.05 * remaining_chips:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if amount_to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                cards = [self._parse_card(c) for c in self.hole_cards]
                cards += [self._parse_card(c) for c in round_state.community_cards]
                hand_score = self._evaluate_hand(cards)
                
                if hand_score >= 5:
                    if amount_to_call == 0:
                        bet_amount = round_state.pot // 2
                        if bet_amount < round_state.min_raise:
                            bet_amount = round_state.min_raise
                        if bet_amount > round_state.max_raise:
                            bet_amount = round_state.max_raise
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        raise_amount = round_state.pot // 2
                        if raise_amount < round_state.min_raise:
                            raise_amount = round_state.min_raise
                        if raise_amount > round_state.max_raise:
                            raise_amount = round_state.max_raise
                        return (PokerAction.RAISE, raise_amount)
                elif hand_score >= 2:
                    if amount_to_call == 0:
                        bet_amount = round_state.pot // 4
                        if bet_amount < round_state.min_raise:
                            bet_amount = round_state.min_raise
                        if bet_amount > round_state.max_raise:
                            bet_amount = round_state.max_raise
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        if amount_to_call <= round_state.pot:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if round_state.round in ['Flop', 'Turn']:
                        if self._has_flush_draw(cards) or self._has_straight_draw(cards):
                            if amount_to_call <= 0.3 * (round_state.pot + amount_to_call):
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.FOLD, 0)
                        else:
                            if amount_to_call > 0:
                                return (PokerAction.FOLD, 0)
                            else:
                                return (PokerAction.CHECK, 0)
                    else:
                        if amount_to_call > 0:
                            return (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.CHECK, 0)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass