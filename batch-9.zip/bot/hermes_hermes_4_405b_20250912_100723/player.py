from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = None
        self.starting_chips = 10000
        self.opponent_aggression = {}
        self.hand_strength_cache = {}
        self.current_round = None
        self.initialized = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_id = self.id
        self.initialized = True

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.player_bets = round_state.player_bets
        self.player_actions = round_state.player_actions

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.initialized:
            return (PokerAction.FOLD, 0)
        
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.player_id), 0)
        call_amount = current_bet - my_bet

        if current_bet == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount > remaining_chips:
            return (PokerAction.ALL_IN, 0)
        elif call_amount > 0:
            if random.random() < 0.1:  # Occasionally call to avoid being too predictable
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass