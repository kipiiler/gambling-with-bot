from typing import List, Tuple, Dict, Any
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_MAP = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}


class SimplePlayer(Bot):
    """
    A very light-weight (no external dependency) No-Limit Texas Hold’em bot.
    The bot uses
      • quick pre-flop hand evaluation (pair / high card strength / suitedness / connectivity)
      • position/blind awareness
      • a conservative post-flop policy (cheap calls only, otherwise fold)
    It never times out, never raises illegally and never allocates large memory,
    satisfying the competition requirements.
    """

    def __init__(self):
        super().__init__()
        # Persistent game information
        self.starting_chips: int = 0
        self.big_blind_amount: int = 0
        self.small_blind_amount: int = 0
        self.all_players: List[int] = []
        # Hand specific information (reset every round)
        self.hole_cards: List[str] = []
        # Random generator (seed once for reproducibility inside container)
        random.seed(2025)

    # ----------  Helper utilities  -------------------------------------------------------------

    @staticmethod
    def _card_rank(card: str) -> int:
        """Return numerical rank 2-14 (A)."""
        return RANK_MAP.get(card[0], 0)

    @staticmethod
    def _is_suited(card1: str, card2: str) -> bool:
        return card1[1] == card2[1]

    @staticmethod
    def _preflop_score(cards: List[str]) -> float:
        """
        Extremely light pre-flop evaluator that returns a continuous score.
        Higher is better. The scale roughly spans 4 – 30.
        """
        if len(cards) != 2:
            return 0.0
        r1, r2 = SimplePlayer._card_rank(cards[0]), SimplePlayer._card_rank(cards[1])
        high, low = max(r1, r2), min(r1, r2)
        score = high                             # base on high card
        if r1 == r2:                             # pair bonus
            score += high + 6                    # small pairs still get boost but less
        else:
            score += low / 2
            if SimplePlayer._is_suited(cards[0], cards[1]):
                score += 2                       # suited bonus
            if abs(r1 - r2) == 1:
                score += 1.5                     # connectors
            elif abs(r1 - r2) == 2:
                score += 0.5
        return score

    def _cost_to_call(self, round_state: RoundStateClient) -> int:
        """How many chips we have to put in to call."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        return max(round_state.current_bet - my_bet, 0)

    # ----------  Mandatory interface  ----------------------------------------------------------

    def on_start(self, starting_chips: int, player_hands: List[str],
                 blind_amount: int, big_blind_player_id: int,
                 small_blind_player_id: int, all_players: List[int]):
        """
        Called once at table start.  Note: player_hands is empty at this moment
        (hole cards are dealt per round), still included for API compatibility.
        """
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount * 2
        self.small_blind_amount = blind_amount
        self.all_players = all_players or []
        # nothing else to store

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        At Husky Hold’em the engine augments the initial round_state message
        with your hole cards under one of the following keys:
            • round_state.player_hands  (dict[player_id -> [c1, c2]])
            • round_state.hole_cards    ([c1, c2])
        We try to detect either to stay robust.
        """
        self.hole_cards = []
        # 1. player_hands dict
        phands: Dict[str, List[str]] = getattr(round_state, "player_hands", None)
        if isinstance(phands, dict):
            self.hole_cards = phands.get(str(self.id), [])
        # 2. direct list
        if not self.hole_cards:
            self.hole_cards = getattr(round_state, "hole_cards", [])
        # Defensive: ensure correct length
        if self.hole_cards is None or len(self.hole_cards) != 2:
            self.hole_cards = []

    def get_action(self, round_state: RoundStateClient,
                   remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Main decision method. Returns (action, amount).  For CHECK/CALL/ALL_IN
        amount is ignored by the engine; for RAISE the amount is the total bet
        you want to make this round (NOT the raise increment).
        """
        # Easy shortcuts -----------------------------------------------------------------
        cost_to_call = self._cost_to_call(round_state)
        can_check = cost_to_call == 0
        min_raise_total = round_state.min_raise
        max_raise_total = min(round_state.max_raise, remaining_chips)

        # PRE-FLOP strategy --------------------------------------------------------------
        if round_state.round.lower() in ("preflop", "prefloP", "pre-flop"):
            score = self._preflop_score(self.hole_cards)
            # Decide tier thresholds (roughly top 15 %, 40 %, rest)
            #   • Strong   : score >= 23  (e.g. any pair 9+, big aces, etc.)
            #   • Medium   : 18–23
            #   • Weak     : < 18
            if score >= 23:
                # Aggressive raise: pot-building 4× BB, capped at max legal
                target_bet = max(4 * self.big_blind_amount, min_raise_total)
                target_bet = min(target_bet, max_raise_total)
                # If we already have money in the pot, ensure target bet >= current_bet + min_raise
                target_bet = max(target_bet, round_state.current_bet + round_state.min_raise)
                if target_bet <= remaining_chips and target_bet > cost_to_call:
                    return PokerAction.RAISE, target_bet
                # fallback to ALL-IN if stack short
                if remaining_chips <= 10 * self.big_blind_amount:
                    return PokerAction.ALL_IN, 0
                return (PokerAction.CALL, 0) if cost_to_call else (PokerAction.CHECK, 0)

            elif score >= 18:
                # Medium hand: flat call; raise small if we can check
                if can_check:
                    # small probing raise with 50 % chance
                    if random.random() < 0.5 and min_raise_total <= max_raise_total:
                        return PokerAction.RAISE, min_raise_total
                    return PokerAction.CHECK, 0
                # Facing a raise – call if cheap (<4 BB), else fold
                if cost_to_call <= 4 * self.big_blind_amount:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                # Weak hand
                if can_check:
                    return PokerAction.CHECK, 0
                # Occasionally (5 %) defend big blind if cheap
                if cost_to_call <= 2 * self.big_blind_amount and random.random() < 0.05:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

        # POST-FLOP strategy -------------------------------------------------------------
        # We do not run heavy equity computations – instead apply a simple pot-odds rule.
        # Cheap calls up to 2 % of our stack or 10 % of the pot, whichever is smaller.
        pot = max(round_state.pot, 1)
        max_affordable_call = min(int(0.02 * remaining_chips), int(0.10 * pot))
        if can_check:
            # Occasionally fire a small continuation bet if we were the aggressor pre-flop
            if round_state.current_bet == 0 and min_raise_total <= max_raise_total \
                    and random.random() < 0.15:
                return PokerAction.RAISE, min_raise_total
            return PokerAction.CHECK, 0
        else:
            # There is a bet to us
            if cost_to_call <= max_affordable_call:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing fancy – just forget the hole cards (avoid memory leak)
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient,
                    player_score: float, all_scores: dict,
                    active_players_hands: Dict[str, Any]):
        # We don’t currently perform post-game learning. Placeholder for logging.
        pass