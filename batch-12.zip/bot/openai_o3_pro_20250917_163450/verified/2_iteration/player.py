import random
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Try importing the powerful pure-python “treys” evaluator.
# If it is unavailable at runtime we fall back to a (very weak) stub evaluator
# so the bot never crashes because of a missing dependency.
try:
    from treys import Card, Evaluator, Deck

    TREYS_AVAILABLE = True
except ImportError:  # ----------  Fallback (guarantees no ImportError) ----------
    TREYS_AVAILABLE = False

    class Card:  # type: ignore
        @staticmethod
        def new(card_str: str):
            return card_str  # just return the raw string

    class Evaluator:  # type: ignore
        def evaluate(self, cards, board):
            # Return a random score in the normal treys range [1, 7462]
            return random.randint(1, 7462)

    class Deck:  # type: ignore
        def __init__(self):
            ranks = "23456789TJQKA"
            suits = "shdc"
            self.cards = [r + s for r in ranks for s in suits]

        def shuffle(self):
            random.shuffle(self.cards)

        def draw(self, n: int = 1):
            if n == 1:
                return self.cards.pop()
            return [self.cards.pop() for _ in range(n)]


class SimplePlayer(Bot):
    """
    Minimal yet fully-featured No-Limit Hold’em bot.

    Strategy outline:
    1.  Pre-flop & post-flop strength is estimated with Monte-Carlo
        simulation (treys Evaluator). 250 iterations keeps decisions fast.
    2.  Action is chosen with a simple equity-vs-pot-odds rule:
        • fold if equity clearly worse than pot odds,
        • call when roughly indifferent,
        • raise / value-bet when equity is strong.
    3.  All decisions are guarded so invalid actions are never returned.
    """

    # ------------------------------------------------------------------ #
    #                         Life-cycle callbacks                       #
    # ------------------------------------------------------------------ #
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind_amount: int = 0
        self.hole_cards: List[str] = []  # our current 2-card hand
        self.evaluator = Evaluator()
        self.rng = random.Random()

    def on_start(
        self,
        starting_chips: int,
        player_hands,
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount * 2  # small blind value given → bb = 2×
        # Attempt to grab our hole cards if already dealt (heads-up start)
        self.hole_cards = self._extract_hole_cards_from_container(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Each new hand, update our 2 cards
        self.hole_cards = self._extract_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        # Keep our hole cards in sync
        self.hole_cards = self._extract_hole_cards(round_state)

        active_players = len(round_state.current_player)
        community_cards = round_state.community_cards

        # --------- 1. Estimate equity via quick Monte-Carlo simulation ----------
        equity = self._estimate_equity(
            self.hole_cards, community_cards, active_players, iterations=250
        )

        # --------- 2. Gather pot / bet sizing information ----------
        current_bet = round_state.current_bet  # amount to match
        my_bet = round_state.player_bets.get(str(self.id), 0) or 0
        to_call = max(0, current_bet - my_bet)  # chips needed to stay in hand

        pot = round_state.pot
        pot_odds = to_call / (pot + to_call + 1e-9) if to_call else 0.0

        min_raise = round_state.min_raise or 0
        max_raise = round_state.max_raise or remaining_chips

        # --------- 3. Decision logic ----------
        # a) No bet to us → we may check or open the action.
        if to_call == 0:
            if equity > 0.60 and min_raise <= remaining_chips:
                raise_amt = int(max(min_raise, pot * 0.5))
                raise_amt = min(max_raise, raise_amt)
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0

        # b) Facing a bet.
        # If equity is far worse than pot odds ⇒ fold
        if equity + 0.02 < pot_odds:
            return PokerAction.FOLD, 0

        # Strong hand → raise for value
        if equity > 0.75 and min_raise <= remaining_chips:
            raise_amt = max(min_raise, to_call * 2)
            raise_amt = min(max_raise, raise_amt)
            if raise_amt >= min_raise:
                return PokerAction.RAISE, raise_amt

        # Otherwise call (or shove if we’re short)
        if to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0
        return PokerAction.CALL, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []  # clear stored hand for next deal

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # No persistent storage needed for this simple bot
        pass

    # ------------------------------------------------------------------ #
    #                            Helper methods                          #
    # ------------------------------------------------------------------ #
    def _extract_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """
        Best-effort extraction of our two hole cards from RoundStateClient,
        handling a variety of possible attribute layouts.
        """
        possible_attrs = ["player_hands", "player_hand", "hole_cards", "hole_card"]
        for attr in possible_attrs:
            data = getattr(round_state, attr, None)
            if data is None:
                continue

            # dict keyed by player id
            if isinstance(data, dict):
                if self.id in data:
                    return data[self.id]
                if str(self.id) in data:
                    return data[str(self.id)]
            # list indexed by seat / id
            if isinstance(data, list):
                try:
                    return data[self.id]
                except (IndexError, KeyError):
                    pass
        return self.hole_cards  # fall back to last known (or empty)

    def _extract_hole_cards_from_container(self, container) -> List[str]:
        """
        Helper for on_start where the ‘player_hands’ parameter may vary in type.
        """
        if isinstance(container, dict):
            return container.get(str(self.id), container.get(self.id, []))
        if isinstance(container, list):
            try:
                return container[self.id]
            except (IndexError, KeyError):
                return []
        return []

    @staticmethod
    def _to_int_cards(card_strs: List[str]) -> List[int]:
        """Convert e.g. ['Ah', 'Kd'] to treys integer representation."""
        return [Card.new(c) for c in card_strs]

    def _estimate_equity(
        self,
        my_cards: List[str],
        community_cards: List[str],
        n_players: int,
        iterations: int = 250,
    ) -> float:
        """Monte-Carlo estimate of winning probability versus random hands."""
        if not my_cards:
            return 0.5  # unknown cards → neutral estimate

        my_ints = self._to_int_cards(my_cards)
        board_ints = self._to_int_cards(community_cards)

        wins = ties = 0
        for _ in range(iterations):
            deck = Deck()
            if TREYS_AVAILABLE:
                # Remove seen cards from the deck (need ints)
                for card in my_cards + community_cards:
                    c_int = Card.new(card)
                    try:
                        deck.cards.remove(c_int)
                    except ValueError:
                        pass
            else:
                for card in my_cards + community_cards:
                    try:
                        deck.cards.remove(card)
                    except ValueError:
                        pass
            deck.shuffle()

            # Complete community board to 5 cards
            remaining_board = 5 - len(board_ints)
            drawn_board = (
                deck.draw(remaining_board) if remaining_board > 0 else []
            )
            if remaining_board == 1:
                drawn_board = [drawn_board]  # draw() returns single int when n==1

            full_board = board_ints + drawn_board

            # Sample opponents
            opp_hands = []
            for _ in range(n_players - 1):
                opp_hands.append(deck.draw(2))

            my_score = self.evaluator.evaluate(my_ints, full_board)
            best = True
            tied = False
            for hand in opp_hands:
                opp_score = self.evaluator.evaluate(hand, full_board)
                if opp_score < my_score:
                    best = False
                    break
                if opp_score == my_score:
                    tied = True
            if best:
                if tied:
                    ties += 1
                else:
                    wins += 1

        return (wins + ties * 0.5) / (iterations + 1e-9)