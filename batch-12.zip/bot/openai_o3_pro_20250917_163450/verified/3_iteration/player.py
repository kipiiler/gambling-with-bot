import random
import itertools
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# ---------- Helper functions -------------------------------------------------

RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i + 2 for i, r in enumerate(RANK_ORDER)}  # 2 -> 2, ..., A -> 14
SUITS = ["h", "d", "c", "s"]
FULL_DECK = [r + s for r in RANK_ORDER for s in SUITS]


def _card_rank(card: str) -> int:
    return RANK_VALUE[card[0]]


def _card_suit(card: str) -> str:
    return card[1]


def _is_straight(ranks: List[int]) -> int:
    """Return highest card of straight (int) or 0 if none.
    ranks must be unique & sorted ASCENDING"""
    # Handle wheel straight A-2-3-4-5
    if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
        return 5
    for i in range(len(ranks) - 4):
        window = ranks[i:i + 5]
        if window == list(range(window[0], window[0] + 5)):
            return window[-1]
    return 0


def _evaluate_five(cards: List[str]) -> Tuple[int, List[int]]:
    """Return (category, tiebreaker list) for EXACTLY 5 cards.
    Higher tuple means stronger hand."""
    ranks = sorted([_card_rank(c) for c in cards])
    counts: Dict[int, int] = {}
    for r in ranks:
        counts[r] = counts.get(r, 0) + 1
    # sort ranks by (count, rank) for grouping
    counts_sorted = sorted(counts.items(), key=lambda x: (-x[1], -x[0]))
    is_flush = len({_card_suit(c) for c in cards}) == 1
    unique_ranks = sorted(set(ranks))
    straight_high = _is_straight(unique_ranks)
    # Straight / straight flush?
    if is_flush and straight_high:
        category = 9  # Straight Flush
        return (category, [straight_high])
    # Four of a kind
    if counts_sorted[0][1] == 4:
        quad_rank = counts_sorted[0][0]
        kicker = max([r for r in ranks if r != quad_rank])
        return (8, [quad_rank, kicker])
    # Full house
    if counts_sorted[0][1] == 3 and counts_sorted[1][1] == 2:
        return (7, [counts_sorted[0][0], counts_sorted[1][0]])
    if is_flush:
        return (6, sorted(ranks, reverse=True))
    if straight_high:
        return (5, [straight_high])
    if counts_sorted[0][1] == 3:
        trips_rank = counts_sorted[0][0]
        kickers = sorted([r for r in ranks if r != trips_rank], reverse=True)
        return (4, [trips_rank] + kickers)
    if counts_sorted[0][1] == 2 and counts_sorted[1][1] == 2:
        pair_high = max(counts_sorted[0][0], counts_sorted[1][0])
        pair_low = min(counts_sorted[0][0], counts_sorted[1][0])
        kicker = max([r for r in ranks if r not in [pair_high, pair_low]])
        return (3, [pair_high, pair_low, kicker])
    if counts_sorted[0][1] == 2:
        pair_rank = counts_sorted[0][0]
        kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
        return (2, [pair_rank] + kickers)
    # High card
    return (1, sorted(ranks, reverse=True))


def _evaluate_seven(cards: List[str]) -> Tuple[int, List[int]]:
    """Evaluate best 5-card hand out of 7 cards"""
    best: Tuple[int, List[int]] = (0, [])
    for combo in itertools.combinations(cards, 5):
        score = _evaluate_five(list(combo))
        if score > best:
            best = score
    return best


def _compare_hands(c1: List[str], c2: List[str]) -> int:
    """Return 1 if c1 wins, -1 if c2 wins, 0 if tie."""
    s1 = _evaluate_seven(c1)
    s2 = _evaluate_seven(c2)
    if s1 > s2:
        return 1
    if s2 > s1:
        return -1
    return 0


def _chen_score(card1: str, card2: str) -> float:
    """Very rough pre-flop strength (Chen formula)."""
    ranks = sorted([_card_rank(card1), _card_rank(card2)], reverse=True)
    high = ranks[0]
    low = ranks[1]
    gap = abs(high - low) - 1
    same_suit = _card_suit(card1) == _card_suit(card2)
    score = max(0, [0, 5, 6, 7, 8, 9, 10, 10, 10, 11, 11, 12, 13][high - 2])
    if high == low:  # pair
        score = max(5, high * 2)
    else:
        if gap == 0:
            score += 2
        elif gap == 1:
            score += 1
        elif gap == 2:
            score += 0
        elif gap == 3:
            score -= 1
        elif gap >= 4:
            score -= 4
    if same_suit:
        score += 2
    return score


# ---------- Bot implementation -----------------------------------------------

class SimplePlayer(Bot):
    """
    A reasonably fast Monte-Carlo / rule-based No-Limit Texas Hold’em bot.
    Focuses on playing tight–aggressive pre-flop and uses equity
    simulation post-flop to make decisions.  The implementation avoids
    external libraries and obeys the interface specified by the contest.
    """

    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards: List[str] = []
        self.random_gen = random.Random()
        self.round_number = 0
        self.table_players: List[int] = []

    # -------------------- Lifecycle hooks ------------------------------------

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.table_players = all_players
        self._set_hole_cards(player_hands)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_number = round_state.round_num
        # Hole cards may be provided inside the round_state for every round.
        # Support multiple possible field names to be robust.
        possible_fields = ["player_hands", "hole_cards", "private_hands", "private_cards"]
        cards = []
        for field in possible_fields:
            if hasattr(round_state, field):
                maybe = getattr(round_state, field)
                if isinstance(maybe, dict):
                    cards = maybe.get(str(self.id), []) or maybe.get(self.id, [])
                elif isinstance(maybe, list):
                    cards = maybe
                if cards:
                    break
        self._set_hole_cards(cards)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Main decision logic each turn."""
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = max(1, round_state.pot)  # avoid div by zero

        # If no hole cards (shouldn't happen) – play ultra-tight
        if len(self.hole_cards) != 2:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

        if round_state.round == "Preflop":
            return self._preflop_decision(round_state, remaining_chips, to_call)
        else:
            return self._postflop_decision(round_state, remaining_chips, to_call, pot)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Nothing to clean up right now.
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # -------------------- Decision helpers -----------------------------------

    def _preflop_decision(
        self, round_state: RoundStateClient, remaining_chips: int, to_call: int
    ) -> Tuple[PokerAction, int]:
        """Rule-based pre-flop play using Chen formula."""
        c1, c2 = self.hole_cards
        chen = _chen_score(c1, c2)
        aggressive = chen >= 10
        playable = chen >= 7
        trash = chen < 7

        # No bet yet against us.
        if to_call == 0:
            if aggressive:
                raise_amt = max(round_state.min_raise, int(round_state.pot * 0.5))
                raise_amt = min(raise_amt, remaining_chips)
                if raise_amt < round_state.min_raise:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.RAISE, raise_amt)
            elif playable:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:  # we face a bet
            if trash:
                return (PokerAction.FOLD, 0)
            call_limit = 0.1 * self.starting_chips  # don’t get crazy pre-flop
            if playable and to_call <= call_limit:
                return (PokerAction.CALL, 0)
            if aggressive:
                # Occasionally 3-bet
                raise_amt = max(round_state.min_raise, to_call * 3)
                raise_amt = min(raise_amt, remaining_chips)
                if raise_amt >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, raise_amt)
            return (PokerAction.FOLD, 0)

    def _postflop_decision(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
        to_call: int,
        pot: int,
    ) -> Tuple[PokerAction, int]:
        """Monte-Carlo equity estimation & pot-odds decision."""
        equity = self._estimate_equity(
            self.hole_cards, round_state.community_cards, samples=80
        )

        # When facing a bet
        if to_call > 0:
            pot_odds = to_call / (pot + to_call)
            if equity - pot_odds > 0.1:
                # Call profitably
                if equity > 0.7:
                    # Raise strong hands
                    raise_amt = min(
                        max(round_state.min_raise, int(pot)), remaining_chips
                    )
                    if raise_amt >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        # No bet – decide whether to bet
        else:
            if equity > 0.6:
                bet_amt = min(
                    max(round_state.min_raise, int(pot * 0.75)),
                    remaining_chips,
                )
                if bet_amt < round_state.min_raise:
                    return (PokerAction.CHECK, 0)
                if bet_amt >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, bet_amt)
            return (PokerAction.CHECK, 0)

    # -------------------- Equity estimation ----------------------------------

    def _estimate_equity(
        self,
        my_cards: Any,
        community_cards: Any,
        samples: int = 80,
    ) -> float:
        """
        Monte-Carlo equity vs ONE random opponent.
        Very light-weight heuristic – suitable for 30-second limit.
        """
        # Normalise inputs to list[str]
        if isinstance(my_cards, str):
            if len(my_cards) % 2 == 0:
                my_cards = [my_cards[i : i + 2] for i in range(0, len(my_cards), 2)]
            else:
                my_cards = [my_cards]
        my_cards = list(my_cards)
        community_cards = list(community_cards)

        known_cards = set(my_cards + community_cards)
        deck = [c for c in FULL_DECK if c not in known_cards]
        wins = ties = 0

        needed_comm_cards = 5 - len(community_cards)
        rng = self.random_gen

        for _ in range(samples):
            rng.shuffle(deck)
            index = 0
            opp_hand = deck[index : index + 2]
            index += 2
            sim_comm = community_cards.copy()
            sim_comm += deck[index : index + needed_comm_cards]
            index += needed_comm_cards
            result = _compare_hands(my_cards + sim_comm, opp_hand + sim_comm)
            if result == 1:
                wins += 1
            elif result == 0:
                ties += 1
            # else loss – do nothing
        total = float(samples)
        return (wins + ties * 0.5) / max(total, 1.0)

    # -------------------- Utilities ------------------------------------------

    def _set_hole_cards(self, cards: List[str]):
        """Ensure we always store exactly 2 card strings."""
        if isinstance(cards, str):
            # Attempt to split
            if len(cards) == 4:
                cards = [cards[:2], cards[2:]]
            else:
                cards = [cards]
        cards = list(cards)
        self.hole_cards = cards[:2] if len(cards) >= 2 else []