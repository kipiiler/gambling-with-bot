# player.py
import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.round_state import RoundStateClient
from type.poker_action import PokerAction
from enum import Enum

# -------------  3-rd-party evaluator (pure python, fast) -----------------
# Requires the pure-python “treys” library for hand evaluation
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A reasonably strong, safe-to-run No-Limit Texas Hold’em bot.

    Design goals:
    1. ALWAYS return a legal action – no crashes, no invalid raises.
    2. Light-weight – stays well within 30-second / 100 MB limits.
    3. Profitable default strategy:
       • Pre-flop – Chen formula starting-hand model
       • Post-flop – Monte-Carlo equity estimate with treys Evaluator
    """

    # --- Chen formula base values for highest card -----------------------
    _CHEN_BASE = {
        'A': 10, 'K': 8, 'Q': 7, 'J': 6, 'T': 5,
        '9': 4.5, '8': 4, '7': 3.5, '6': 3,
        '5': 2.5, '4': 2, '3': 1.5, '2': 1
    }

    # --------------------------------------------------------------------
    def __init__(self) -> None:
        super().__init__()
        self.evaluator = Evaluator()

        # Game/session level bookkeeping
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.hole_cards: List[str] = []     # e.g. ['Ah', 'Kd']
        self.round_num: int = 0

    # ------------------  Life-cycle hooks  ------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ) -> None:
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        # We may or may not receive our first hand here – store if present
        if player_hands:
            # best effort: we may be given every player’s hand – extract ours
            try:
                # If list of dicts
                for item in player_hands:
                    if int(item['id']) == int(self.id):
                        self.hole_cards = item['hand']
                        break
            except Exception:
                # If list of 2-card strings – assume this is ours
                if len(player_hands) == 2 and all(isinstance(c, str) for c in player_hands):
                    self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.round_num = round_state.round_num
        # The framework may supply our hole cards inside the round_state;
        # try to extract them robustly.
        self.hole_cards = self._extract_hole_cards(round_state) or self.hole_cards

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Main decision routine – chooses among FOLD / CHECK / CALL / RAISE / ALL_IN
        and always returns a legal action-amount tuple.
        """
        # ----------------------------------------------------------------
        call_amount = max(0, round_state.current_bet -
                          round_state.player_bets.get(str(self.id), 0))
        can_check = call_amount == 0

        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        # --------------------------------------------------  PRE-FLOP  ---
        if round_state.round.lower() in ('preflop', 'prefloP', 'prefLop', 'pre-flop'):   # tolerant
            strength = self._chen_strength(self.hole_cards)    # 0-to-10 scale
            if can_check:
                if strength >= 9:
                    amount = self._clamp_raise(int(self.big_blind * 3), min_raise, max_raise)
                    if amount:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0

            # Calling / raising situation
            if strength >= 9:         # premium
                amount = self._clamp_raise(int(round_state.pot * 0.75), min_raise, max_raise)
                if amount:
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CALL, 0
            elif strength >= 7:       # decent
                if call_amount < 0.05 * remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:                     # trash
                return PokerAction.FOLD, 0

        # --------------------------------------------------  POST-FLOP --
        # Estimate equity with Monte-Carlo simulation
        win_prob = self._estimate_equity(
            self.hole_cards,
            round_state.community_cards,
            num_opponents=max(1, len(round_state.current_player) - 1),
            simulations=120  # fast enough for 30-second limit
        )

        # Decision rules (simple but effective)
        if can_check:
            if win_prob > 0.6:
                amount = self._clamp_raise(int(round_state.pot * 0.5), min_raise, max_raise)
                if amount:
                    return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0

        # Need to put money in
        pot_odds = call_amount / max(1, round_state.pot + call_amount)
        # Positive EV call?
        if win_prob > pot_odds + 0.05:  # small positive margin
            # Consider raising with strong equity
            if win_prob > 0.75:
                amount = self._clamp_raise(int(round_state.pot), min_raise, max_raise)
                if amount:
                    return PokerAction.RAISE, amount
            return PokerAction.CALL, 0

        # Fold poor equity hands
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # No specific round-end processing necessary for this bot
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[Any, Any],
        active_players_hands: Dict[Any, Any]
    ) -> None:
        # Nothing to clean up across games
        pass

    # =========================  Helper routines =========================
    def _extract_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """
        Try to obtain this player’s hole cards from round_state if provided.
        """
        # common locations used by many frameworks
        for attr in ('player_hands', 'hole_cards', 'hands'):
            if hasattr(round_state, attr):
                try:
                    data = getattr(round_state, attr)
                    if isinstance(data, dict):
                        return data.get(str(self.id), []) or data.get(self.id, [])
                    elif isinstance(data, list) and len(data) == 2:
                        return data
                except Exception:
                    continue
        return []

    # ----------------------------  Chen formula -------------------------
    def _chen_strength(self, cards: List[str]) -> float:
        if len(cards) != 2:
            return 0.0

        ranks = [c[0] for c in cards]
        suits = [c[1] for c in cards]

        v1, v2 = self._CHEN_BASE[ranks[0]], self._CHEN_BASE[ranks[1]]
        high = max(v1, v2)
        low_rank = min(v1, v2)

        # pair
        if ranks[0] == ranks[1]:
            score = max(5, high * 2)
        else:
            score = high

            # suited bonus
            if suits[0] == suits[1]:
                score += 2

            # gap penalty
            gap = abs(self._rank_index(ranks[0]) - self._rank_index(ranks[1])) - 1
            if gap == 0:
                gap_penalty = 0
            elif gap == 1:
                gap_penalty = 1
            elif gap == 2:
                gap_penalty = 2
            elif gap == 3:
                gap_penalty = 4
            else:
                gap_penalty = 5
            score -= gap_penalty

            # small bonus for connectors 5+ with gap 0-1
            if gap <= 1 and all(self._rank_index(r) >= self._rank_index('5') for r in ranks):
                score += 1

        return max(0, score)

    def _rank_index(self, rank: str) -> int:
        order = '23456789TJQKA'
        return order.index(rank.upper())

    # --------------------  Monte-Carlo equity estimate ------------------
    def _estimate_equity(
        self,
        hole_cards: List[str],
        community: List[str],
        num_opponents: int,
        simulations: int = 100
    ) -> float:
        """
        Return approximate probability of winning (0-1) versus `num_opponents`
        random hands using `simulations` Monte-Carlo trials.
        """
        if len(hole_cards) != 2:
            return 0.0

        try:
            hole_ints = [Card.new(c[0] + c[1]) for c in hole_cards]
            community_ints = [Card.new(c[0] + c[1]) for c in community]
        except Exception:
            # In case of bad card strings – be safe
            return 0.0

        wins = ties = 0
        need_cards = 5 - len(community_ints)
        evaluator = self.evaluator

        for _ in range(simulations):
            deck = Deck()
            # Remove known cards from deck
            for c in hole_ints + community_ints:
                deck.cards.remove(c)

            opp_hands = []
            for _ in range(num_opponents):
                opp_hands.append([deck.draw(1)[0], deck.draw(1)[0]])

            # Complete the board
            board = community_ints[:]
            for _ in range(need_cards):
                board.append(deck.draw(1)[0])

            hero_rank = evaluator.evaluate(board, hole_ints)
            best_opp = min(evaluator.evaluate(board, h) for h in opp_hands)

            if hero_rank < best_opp:
                wins += 1
            elif hero_rank == best_opp:
                ties += 1

        total = simulations
        return (wins + ties * 0.5) / max(1, total)

    # ---------------------------  Utilities  ----------------------------
    def _clamp_raise(self, desired: int, min_raise: int, max_raise: int) -> int:
        """
        Return a raise amount that is within min/max bounds. 0 if raising
        is impossible (e.g., stack too small or min_raise > max_raise).
        """
        if min_raise > max_raise:
            return 0
        amount = max(desired, min_raise)
        amount = min(amount, max_raise)
        # Respect min_raise rule: raise must be strictly greater than call
        if amount < min_raise:
            return 0
        return amount


# -----------------------------------------------------------------------
# END of player.py