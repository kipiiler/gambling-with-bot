from __future__ import annotations

import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

RANK_ORDER = "23456789TJQKA"
RANK_VALUE: Dict[str, int] = {r: i for i, r in enumerate(RANK_ORDER, 2)}


def card_rank(card: str) -> str:
    """Return rank character of a card string, e.g. 'Ah' -> 'A'."""
    return card[0]


def card_suit(card: str) -> str:
    """Return suit character of a card string, e.g. 'Ah' -> 'h'."""
    return card[1]


class SimplePlayer(Bot):
    """
    Very small-footprint, no-limit Texas Hold’em bot.

    Strategy outline
    -----------------
    1.  Pre-flop hand is grouped into four tiers.  We open-raise or
        re-raise with strong tiers, limp/call with mediocre ones and fold
        garbage when facing aggression.
    2.  Post-flop we build a coarse hand-strength score (0–5) using a
        lightweight evaluator (pair, two-pair, straight, flush, full-house,
        quads).  We value-bet or raise with score ≥ 4, call with medium
        strength and check/fold otherwise.
    3.  All decisions are checked against the actual legal actions given
        by the environment to avoid invalid moves.
    4.  No external libraries and < 100 MB memory.
    """

    # ---------- life-cycle hooks ------------------------------------------------
    def __init__(self) -> None:
        super().__init__()
        self.starting_chips = 0
        self.big_blind = 0
        self.small_blind = 0
        self.hole_cards: List[str] = []
        self.button_player_id: int | None = None
        # Fast lookup for our current contribution in the pot inside a hand
        self._current_bet_this_round: int = 0

    # --------------------------------------------------------------------------
    # Game / round notifications
    # --------------------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ) -> None:
        self.starting_chips = starting_chips
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        # first hand hole cards are supplied here (some frameworks)
        if player_hands:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # Try to fetch hole cards if the framework attaches them to round_state
        self.hole_cards = self._extract_hole_cards(round_state)
        self._current_bet_this_round = 0  # reset

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        # housekeeping – not used now
        self.hole_cards.clear()

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ) -> None:
        # nothing to persist between games
        pass

    # --------------------------------------------------------------------------
    # Main decision logic
    # --------------------------------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide an action and **amount** (required for RAISE only).
        Always returns a legal move (falls back to FOLD if unsure).
        """
        # Convenience variables
        stage = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'
        pot = round_state.pot
        min_raise = round_state.min_raise
        current_round_bet = round_state.current_bet
        our_contribution = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_round_bet - our_contribution)

        # Remember our max contribution this betting round so that we
        # can track it for future decisions inside the same round.
        self._current_bet_this_round = our_contribution

        # ------------------------------------------------------------------
        # PRE-FLOP
        # ------------------------------------------------------------------
        if stage.lower() == "preflop":
            tier = self._preflop_tier(self.hole_cards)
            # Nobody has opened the pot
            if to_call == 0:
                if tier >= 3:
                    # Big raise with monsters
                    return self._safe_raise(min_raise * 3, remaining_chips)
                elif tier == 2:
                    return self._safe_raise(min_raise * 2, remaining_chips)
                elif tier == 1:
                    return self._safe_check()
                else:
                    return self._safe_check()
            # Facing an open / raise
            else:
                if tier >= 3:
                    # Re-raise for value
                    return self._safe_raise(min_raise * 2, remaining_chips)
                elif tier == 2:
                    # Just call
                    return self._safe_call(to_call, remaining_chips)
                elif tier == 1 and to_call <= self.big_blind:
                    # Cheap call with speculative hand
                    return self._safe_call(to_call, remaining_chips)
                else:
                    return self._safe_fold()

        # ------------------------------------------------------------------
        # POST-FLOP (Flop / Turn / River)
        # ------------------------------------------------------------------
        hand_score = self._postflop_strength(self.hole_cards, round_state.community_cards)

        # When we can check for free
        if to_call == 0:
            if hand_score >= 4:
                # Build the pot – value bet
                bet_amount = min_raise
                return self._safe_raise(bet_amount, remaining_chips)
            elif hand_score >= 2:
                # Pot control
                return self._safe_check()
            else:
                # Weak – just check
                return self._safe_check()
        # Facing a bet
        else:
            if hand_score >= 4:
                # Strong – raise
                return self._safe_raise(min_raise * 2, remaining_chips)
            elif hand_score >= 2:
                # Medium strength – call if odds are fine
                if to_call <= pot // 4:  # simple pot-odds heuristic
                    return self._safe_call(to_call, remaining_chips)
                else:
                    return self._safe_fold()
            else:
                # Very weak
                return self._safe_fold()

    # --------------------------------------------------------------------------
    # Helper: extract hole cards from RoundStateClient if present
    # --------------------------------------------------------------------------
    def _extract_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        # The framework might provide 'player_hands' or similar; try both
        if hasattr(round_state, "player_hands"):
            ph = round_state.player_hands
            if isinstance(ph, dict):
                return ph.get(str(self.id), []) or ph.get(self.id, [])
            elif isinstance(ph, list) and len(ph) == 2:
                return ph
        return self.hole_cards  # keep previous value if nothing found

    # --------------------------------------------------------------------------
    # Helper: pre-flop hand categorisation
    # --------------------------------------------------------------------------
    @staticmethod
    def _preflop_tier(hole: List[str]) -> int:
        """
        Return an integer tier 0-3 where 3 is premium.
        Simple hard-coded chart for heads-up.
        """
        if len(hole) != 2:
            return 0
        r1, r2 = card_rank(hole[0]), card_rank(hole[1])
        s1, s2 = card_suit(hole[0]), card_suit(hole[1])
        suited = s1 == s2
        ranks = "".join(sorted([r1, r2], key=lambda r: RANK_VALUE[r], reverse=True))
        pair = r1 == r2

        # Tier definitions (hard-coded)
        premium_pairs = {"AA", "KK", "QQ", "JJ", "TT"}
        premium_suited = {"AK", "AQ", "AJ"}
        strong_off = {"AK", "AQ", "AJ", "KQ"}

        if pair and ranks in premium_pairs:
            return 3
        if suited and ranks in premium_suited:
            return 3
        if pair and ranks in {"99", "88", "77"}:
            return 2
        if ranks in strong_off:
            return 2
        if suited and ranks in {
            "KJ",
            "QJ",
            "JT",
            "T9",
            "98",
            "87",
            "76",
            "65",
        }:
            return 1
        if pair:
            return 1  # any other pair
        return 0

    # --------------------------------------------------------------------------
    # Helper: post-flop coarse strength evaluator (0–5)
    # --------------------------------------------------------------------------
    @staticmethod
    def _postflop_strength(hole: List[str], board: List[str]) -> int:
        """
        Very lightweight evaluator returning numbers

        5  -> Straight / Flush / Full house / Quads
        4  -> Trips or two-pair
        3  -> One pair where rank == top board rank
        2  -> Any other pair or strong draw (not implemented, treat as 2)
        1  -> Ace-high
        0  -> Everything else
        """
        cards = hole + board
        if len(cards) < 5:
            return 0

        # Flush
        suit_counts = {}
        for c in cards:
            suit_counts[card_suit(c)] = suit_counts.get(card_suit(c), 0) + 1
        if any(v >= 5 for v in suit_counts.values()):
            return 5

        # Rank counts
        rank_counts = {}
        for c in cards:
            rank_counts[card_rank(c)] = rank_counts.get(card_rank(c), 0) + 1
        counts = sorted(rank_counts.values(), reverse=True)

        if 4 in counts:
            return 5
        if 3 in counts and 2 in counts:
            return 5
        if 3 in counts:
            return 4
        if counts.count(2) >= 2:
            return 4

        # Straight (simple – ignore wheel properly, but still fine)
        uniq = sorted({RANK_VALUE[card_rank(c)] for c in cards})
        consec = 1
        for i in range(1, len(uniq)):
            if uniq[i] == uniq[i - 1] + 1:
                consec += 1
                if consec >= 5:
                    return 5
            else:
                consec = 1

        # One pair?
        if 2 in counts:
            # top-pair check
            board_ranks = [card_rank(c) for c in board]
            top_board_rank = max(board_ranks, key=lambda r: RANK_VALUE[r])
            if any(r == top_board_rank and cnt == 2 for r, cnt in rank_counts.items()):
                return 3
            return 2

        # Ace high?
        if any(card_rank(c) == "A" for c in hole):
            return 1

        return 0

    # --------------------------------------------------------------------------
    # Helper: safe wrappers producing always-valid moves
    # --------------------------------------------------------------------------
    @staticmethod
    def _safe_fold() -> Tuple[PokerAction, int]:
        return PokerAction.FOLD, 0

    @staticmethod
    def _safe_check() -> Tuple[PokerAction, int]:
        return PokerAction.CHECK, 0

    @staticmethod
    def _safe_call(to_call: int, remaining: int) -> Tuple[PokerAction, int]:
        if to_call == 0:
            return PokerAction.CHECK, 0
        if to_call >= remaining:
            return PokerAction.ALL_IN, 0
        return PokerAction.CALL, 0  # env will take exact amount

    @staticmethod
    def _cap_raise_amount(amount: int, remaining: int) -> int:
        return max(0, min(amount, remaining))

    def _safe_raise(self, raise_amount: int, remaining: int) -> Tuple[PokerAction, int]:
        """
        Return a valid RAISE (or ALL_IN if we don't have enough chips).
        The `amount` field we send is the raise size *not* our final bet.
        """
        if remaining <= 0:
            return PokerAction.CHECK, 0  # should not happen
        amount = self._cap_raise_amount(raise_amount, remaining)
        if amount <= 0:
            return PokerAction.ALL_IN, 0
        if amount >= remaining:
            return PokerAction.ALL_IN, 0
        return PokerAction.RAISE, amount