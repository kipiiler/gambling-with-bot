from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.current_round = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_hole_cards(round_state)
        self.current_round = round_state.round_num

    def get_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """ Extract the bot's hole cards from the round state if available """
        # Simulated method — in actual game server implementation, this may be stored elsewhere.
        # Since the bot isn't directly told its hole cards in round_state, this would come from on_start.
        # If not available, fall back to empty list.
        return self.hole_cards if hasattr(self, 'hole_cards') else []

    def card_rank(self, card: str) -> int:
        """ Convert card rank to numerical value (2-14) """
        rank_char = card[0]
        if rank_char == 'T': return 10
        if rank_char == 'J': return 11
        if rank_char == 'Q': return 12
        if rank_char == 'K': return 13
        if rank_char == 'A': return 14
        return int(rank_char)

    def card_suit(self, card: str) -> str:
        """ Extract suit of card """
        return card[-1]

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Very basic hand strength evaluation for preflop and postflop """
        if not hole_cards:
            return 0.0

        all_cards = hole_cards + community_cards
        ranks = [self.card_rank(c) for c in all_cards]
        suits = [self.card_suit(c) for c in all_cards]
        rank_count = {r: ranks.count(r) for r in ranks}
        suit_count = {s: suits.count(s) for s in suits}

        # Preflop logic for hole cards only
        if len(community_cards) == 0:
            r1, r2 = sorted([self.card_rank(c) for c in hole_cards], reverse=True)
            # High pocket pairs and high cards are strong
            if r1 == r2:
                return 0.3 + (r1 - 2) * 0.05  # Pocket 2s ~0.3, Pocket Aces ~0.8
            elif r1 >= 11 or r2 >= 11:
                # High cards
                strength = 0.1 + (r1 - 2) * 0.025
                if r1 - r2 <= 4 and (r1 <= 13 and r2 >= 9):
                    strength += 0.05  # Connectors
                if self.card_suit(hole_cards[0]) == self.card_suit(hole_cards[1]):
                    strength += 0.05  # Suited
                return min(strength, 0.9)
            else:
                return 0.05 + (r1 - 2) * 0.01

        # Post-flop: very simplified
        # Prioritize pairs, draws
        pairs = sum(1 for count in rank_count.values() if count >= 2)
        trips = sum(1 for count in rank_count.values() if count >= 3)
        quads = sum(1 for count in rank_count.values() if count >= 4)
        flush_draw = any(count >= 4 for count in suit_count.values()) and len(community_cards) < 5
        flush = any(count >= 5 for count in suit_count.values())
        straight_cards = sorted(set(ranks))
        straight_draw = False
        for i in range(len(straight_cards) - 3):
            if straight_cards[i+3] - straight_cards[i] <= 4:
                straight_draw = True
                break
        straight = self.check_straight(ranks)

        # Assign hand strength
        if quads:
            return 1.0
        if trips and pairs >= 2:  # Full house
            return 0.95
        if flush:
            return 0.9
        if straight:
            return 0.85
        if trips:
            return 0.7
        if pairs >= 2:
            return 0.6
        if pairs == 1:
            # Overpair?
            paired_rank = [r for r, count in rank_count.items() if count >= 2][0]
            max_hole = max(self.card_rank(c) for c in hole_cards)
            if paired_rank == max_hole and paired_rank >= 12:
                return 0.45
            return 0.4
        # High card
        top_rank = max(ranks)
        if top_rank >= 13:
            if flush_draw or straight_draw:
                return 0.35
            return 0.25
        return 0.1

    def check_straight(self, ranks: List[int]) -> bool:
        unique_ranks = sorted(set(ranks))
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        # Special case: A-5 straight
        if set([14, 2, 3, 4, 5]).issubset(unique_ranks):
            return True
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = self.hole_cards
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_bet = round_state.player_bets.get(str(self.id), 0)
        pot_size = round_state.pot
        amount_to_call = current_bet - player_bet

        # Default action
        action = PokerAction.FOLD
        raise_amount = 0

        # Ensure valid values
        if remaining_chips <= 0:
            return PokerAction.FOLD, 0

        # Get hand strength
        hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)

        # Adjust action based on game state
        if amount_to_call == 0:
            # Can check
            if hand_strength > 0.2:
                # Strong enough to play: check or raise
                if hand_strength > 0.6 and min_raise > 0 and remaining_chips >= min_raise:
                    raise_by = min(int(pot_size * 0.7), remaining_chips)
                    raise_by = max(min_raise, raise_by)
                    if raise_by > remaining_chips:
                        action = PokerAction.ALL_IN
                        raise_amount = 0
                    else:
                        action = PokerAction.RAISE
                        raise_amount = raise_by
                else:
                    action = PokerAction.CHECK
            else:
                action = PokerAction.CHECK
        else:
            # Must decide to call, raise, or fold
            if amount_to_call >= remaining_chips:
                # All-in to call: only do it if decent hand
                if hand_strength > 0.5:
                    action = PokerAction.ALL_IN
                else:
                    action = PokerAction.FOLD
            else:
                if hand_strength > 0.7:
                    # Strong hand: raise
                    raise_by = min(int(pot_size * 1.5), remaining_chips - amount_to_call)
                    raise_by = max(min_raise, raise_by)
                    # Ensure raise is valid: new bet > current bet
                    current_total_bet = player_bet + amount_to_call
                    if player_bet + raise_by + amount_to_call > current_total_bet and remaining_chips >= raise_by:
                        action = PokerAction.RAISE
                        raise_amount = raise_by
                    else:
                        action = PokerAction.CALL
                elif hand_strength > 0.4:
                    # Medium hand, call if price is right
                    if amount_to_call <= pot_size * 0.5:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    # Weak hand
                    if amount_to_call == 0:
                        action = PokerAction.CHECK
                    else:
                        action = PokerAction.FOLD

        # Final validation of actions
        if action == PokerAction.RAISE:
            total_bet = player_bet + raise_amount
            # Ensure total raise exceeds current bet
            if raise_amount < min_raise or raise_amount > max_raise:
                # Fallback
                if remaining_chips > amount_to_call and amount_to_call > 0:
                    action = PokerAction.CALL
                else:
                    action = PokerAction.CHECK
            else:
                raise_amount = int(raise_amount)  # Ensure int

        # If no valid raise, fallback to call/check or all-in
        if action == PokerAction.CALL and amount_to_call == 0:
            action = PokerAction.CHECK

        if action == PokerAction.ALL_IN:
            raise_amount = 0  # ALL_IN uses all remaining chips
        elif action == PokerAction.CALL:
            raise_amount = 0  # CALL uses exact call amount
        elif action == PokerAction.CHECK:
            raise_amount = 0
        elif action == PokerAction.FOLD:
            raise_amount = 0
        elif action == PokerAction.RAISE:
            # Ensure raise amount is within bounds
            raise_amount = max(min_raise, min(raise_amount, max_raise, remaining_chips))

        return action, raise_amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: track stats or reset state
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: analyze results
        pass