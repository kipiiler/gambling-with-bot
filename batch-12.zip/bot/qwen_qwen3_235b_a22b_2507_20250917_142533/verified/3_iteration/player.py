from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.our_hand = []
        self.positional_sense = {}  # Track how players behave
        self.opp_stats = {}  # Win rates, aggressiveness
        self.hand_strength_cache = {}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_hands = {pid: [] for pid in all_players}
        self.our_hand = player_hands
        self.opp_stats = {pid: {'hands_played': 0, 'bets_made': 0, 'aggression_freq': 0.0} for pid in all_players if pid != self.id}
        self.hand_strength_cache = {}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round logic if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            player_bet = round_state.player_bets.get(str(self.id), 0)

            # Calculate call amount
            call_amount = current_bet - player_bet

            # Determine phase of the game
            is_preflop = round_state.round == 'Preflop'
            is_flop = round_state.round == 'Flop'
            is_turn = round_state.round == 'Turn'
            is_river = round_state.round == 'River'

            # Calculate hand strength heuristic
            hand_score = self.estimate_hand_strength(self.our_hand, community_cards)

            # Position awareness (simplified): assume we have position if not first to act
            active_players = round_state.current_player
            is_in_position = len(active_players) <= 2 or str(self.id) == str(active_players[-1])  # Last to act

            # Adjust strategy based on game phase and hand strength
            if is_preflop:
                action, amount = self.preflop_strategy(call_amount, min_raise, max_raise, pot, hand_score, remaining_chips)
            else:
                board_textures = self.analyze_board_texture(community_cards)
                draw_potential = self.calculate_draw_potential(self.our_hand, community_cards)
                hand_category = self.classify_hand(self.our_hand, community_cards)

                action, amount = self.postflop_strategy(
                    hand_score, hand_category, draw_potential, board_textures,
                    call_amount, min_raise, max_raise, pot, remaining_chips,
                    is_in_position, is_river
                )
            return action, amount

        except Exception as e:
            # Fallback: fold on error to avoid penalty
            return PokerAction.FOLD, 0

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Estimate normalized hand strength from 0 (weak) to 1 (strong) """
        if not hole_cards:
            return 0.0

        # Use cached result if available
        key = (tuple(sorted(hole_cards)), tuple(sorted(community_cards)))
        if key in self.hand_strength_cache:
            return self.hand_strength_cache[key]

        total_cards = hole_cards + community_cards
        ranks = [self.parse_rank(card) for card in total_cards]
        suits = [self.parse_suit(card) for card in total_cards]

        # Check for pairs, two pair, trips, etc.
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        pairs = sum(1 for count in rank_count.values() if count == 2)
        trips = sum(1 for count in rank_count.values() if count == 3)
        quads = sum(1 for count in rank_count.values() if count == 4)

        # Flush check
        suit_count = {s: suits.count(s) for s in set(suits)}
        has_flush = any(count >= 5 for count in suit_count.values())

        # Straight check
        unique_ranks = sorted(set(ranks))
        has_straight = self.has_straight(unique_ranks)

        # High card
        high_card_rank = max(ranks)

        # Pre-flop hand strength approximation
        if len(community_cards) == 0:
            rank1, rank2 = sorted([self.card_rank_value(hole_cards[0][0]), self.card_rank_value(hole_cards[1][0])])
            suited = hole_cards[0][1] == hole_cards[1][1]
            pair_bonus = 1.0 if rank1 == rank2 else 0.0
            suited_bonus = 0.2 if suited else 0.0
            connected_bonus = 0.1 if abs(rank1 - rank2) == 1 else 0.05 if abs(rank1 - rank2) == 2 else 0.0
            premium_bonus = 0.5 if rank1 >= 10 else 0.0  # High cards
            score = (rank1 + rank2) / 26 + pair_bonus + suited_bonus + connected_bonus + premium_bonus
            strength = min(score / 2.0, 1.0)
        else:
            # Post-flop hand strength
            strength = 0.0
            if quads:
                strength = 0.98
            elif trips and pairs >= 1:
                strength = 0.95
            elif has_flush:
                strength = 0.90
            elif has_straight:
                strength = 0.85
            elif trips:
                strength = 0.7
            elif pairs >= 2:
                strength = 0.6
            elif pairs == 1:
                if max(rank_count.keys(), key=lambda x: rank_count[x]) in [r for r in ranks[:2]]:  # Pocket pair hit
                    strength = 0.55
                elif high_card_rank >= 12:  # Overpair or top pair with high kicker
                    strength = 0.5
                else:
                    strength = 0.35
            else:
                # High card strength
                kickers = sorted([r for r in ranks[:2] if r in rank_count], reverse=True)
                if len(kickers) > 0:
                    top_kicker = kickers[0]
                    if top_kicker >= 12:
                        strength = 0.25
                    elif top_kicker >= 10:
                        strength = 0.15
                    else:
                        strength = 0.1

        self.hand_strength_cache[key] = strength
        return strength

    def has_straight(self, sorted_ranks: List[int]) -> bool:
        for i in range(len(sorted_ranks) - 4):
            if (sorted_ranks[i+4] - sorted_ranks[i] == 4 and
                len(set(sorted_ranks[i:i+5])) == 5):
                return True
        # Special case: A-2-3-4-5
        if set([1, 2, 3, 4, 5]).issubset(set(sorted_ranks)):
            return True
        return False

    def parse_rank(self, card: str) -> int:
        r = card[0]
        if r == 'A': return 14
        if r == 'K': return 13
        if r == 'Q': return 12
        if r == 'J': return 11
        if r == 'T': return 10
        return int(r)

    def parse_suit(self, card: str) -> str:
        return card[-1]

    def card_rank_value(self, rank_char: str) -> int:
        mapping = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return mapping.get(rank_char, 0)

    def preflop_strategy(self, call_amount: int, min_raise: int, max_raise: int, pot: int, hand_score: float, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Preflop raising logic
        if hand_score >= 0.9:  # Premium hands
            if max_raise > min_raise * 3:
                return PokerAction.RAISE, min(max_raise, min_raise * 3)
            else:
                return PokerAction.RAISE, max_raise if random.random() < 0.7 else min_raise * 2
        elif hand_score >= 0.7:  # Strong hands
            raise_amount = min(min_raise * 2, max_raise)
            if call_amount == 0:
                return PokerAction.RAISE, raise_amount
            elif call_amount <= min_raise * 2:
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.CALL, 0
        elif hand_score >= 0.4:  # Marginal hands
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif call_amount <= min_raise:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:  # Weak hands
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def postflop_strategy(self, hand_score: float, hand_category: str, draw_potential: float,
                          board_texture: Dict, call_amount: int, min_raise: int, max_raise: int,
                          pot: int, remaining_chips: int, is_in_position: bool, is_river: bool) -> Tuple[PokerAction, int]:

        aggression_factor = 1.0
        if is_in_position:
            aggression_factor += 0.3
        if board_texture.get('dry', False):
            aggression_factor += 0.2
        if board_texture.get('monotone', False):
            aggression_factor -= 0.3

        effective_strength = hand_score * (1 + draw_potential) * (1 + aggression_factor - 1)

        # Adjust for stack size: short stack plays tighter
        stack_to_pot_ratio = remaining_chips / (pot + 1e-8)
        if stack_to_pot_ratio < 1:
            # Short stack: shove or fold
            if effective_strength > 0.6:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        # Decision logic
        if effective_strength > 0.8:
            if max_raise > min_raise * 2:
                raise_amt = min(max_raise, int(pot * 0.75))
                return PokerAction.RAISE, max(min_raise * 2, raise_amt)
            else:
                return PokerAction.ALL_IN, 0
        elif effective_strength > 0.5:
            if call_amount == 0:
                bet_size = min(pot // 3, max(min_raise, max_raise // 10))
                return PokerAction.RAISE, max(min_raise, bet_size)
            elif call_amount <= pot // 4:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        elif effective_strength > 0.3:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif call_amount <= pot // 4:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

    def classify_hand(self, hole_cards: List[str], community_cards: List[str]) -> str:
        total_cards = hole_cards + community_cards
        ranks = [self.parse_rank(card) for card in total_cards]
        suits = [self.parse_suit(card) for card in total_cards]

        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        suit_count = {s: suits.count(s) for s in set(suits)}
        pairs = sum(1 for count in rank_count.values() if count == 2)
        trips = sum(1 for count in rank_count.values() if count == 3)
        quads = 1 if any(count == 4 for count in rank_count.values()) else 0
        has_flush = any(count >= 5 for count in suit_count.values())
        has_straight = self.has_straight(sorted(set(ranks)))

        if quads:
            return 'quads'
        elif trips and pairs >= 1:
            return 'full_house'
        elif has_flush:
            return 'flush'
        elif has_straight:
            return 'straight'
        elif trips:
            return 'trips'
        elif pairs >= 2:
            return 'two_pair'
        elif pairs == 1:
            return 'one_pair'
        else:
            return 'high_card'

    def calculate_draw_potential(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Estimate probability of improving hand """
        if len(community_cards) >= 4:
            return 0.0  # Too late for draws on river

        outs = 0
        total_cards = hole_cards + community_cards
        seen_ranks = set(self.parse_rank(c) for c in total_cards)
        seen_suits = [self.parse_suit(c) for c in total_cards]

        # Flush draw: need 2 more of same suit
        for suit in set(seen_suits):
            if seen_suits.count(suit) == 4:
                outs += 9  # 13 - 4 = 9 left

        # Open-ended straight draw
        ranks = sorted(set(self.parse_rank(c) for c in total_cards))
        for i in range(len(ranks)-1):
            if ranks[i+1] - ranks[i] == 1:
                if i > 0 and ranks[i-1] + 1 == ranks[i]:
                    outs += 8  # OESD
                if i+2 < len(ranks) and ranks[i+2] - ranks[i+1] == 1:
                    outs += 8

        # Gutshot straight draw
        for i in range(len(ranks)-1):
            if ranks[i+1] - ranks[i] == 2:
                outs += 4

        # Overcards (can make top pair)
        hole_ranks = [self.parse_rank(c) for c in hole_cards]
        high_ranks_on_board = set(r for r in seen_ranks if r >= 11)
        for hr in hole_ranks:
            if hr >= 11 and hr not in high_ranks_on_board:
                outs += 3  # About 3 outs for overcard making a pair

        # Probability approximation: outs * 2 * streets_remaining
        streets_remaining = 5 - len(community_cards)
        draw_chance = (outs * streets_remaining * 2) / 100.0
        return min(draw_chance, 1.0)

    def analyze_board_texture(self, community_cards: List[str]) -> Dict[str, bool]:
        if len(community_cards) < 3:
            return {'coordinated': False, 'dry': True, 'flush_draw': False, 'straight_draw': False, 'monotone': False}

        suits = [self.parse_suit(card) for card in community_cards]
        suit_count = {s: suits.count(s) for s in set(suits)}
        ranks = sorted(set(self.parse_rank(card) for card in community_cards))
        connected = all(ranks[i+1] - ranks[i] <= 2 for i in range(len(ranks)-1))

        has_flush_draw = any(count >= 3 for count in suit_count.values())
        has_straight_draw = len(ranks) >= 3 and any(ranks[i+2] - ranks[i] <= 4 for i in range(len(ranks)-2))
        monotone = any(count >= 4 for count in suit_count.values())
        coordinated = has_flush_draw or has_straight_draw or connected
        dry = not coordinated

        return {
            'coordinated': coordinated,
            'dry': dry,
            'flush_draw': has_flush_draw,
            'straight_draw': has_straight_draw,
            'monotone': monotone
        }

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: update opponent stats
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: learn from revealed hands
        pass