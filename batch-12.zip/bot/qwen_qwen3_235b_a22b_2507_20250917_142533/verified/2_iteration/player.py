from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_id = None
        self.hand_strength_weight = {
            'High card': 0.1,
            'One pair': 0.25,
            'Two pair': 0.4,
            'Three of a kind': 0.55,
            'Straight': 0.7,
            'Flush': 0.75,
            'Full house': 0.9,
            'Four of a kind': 0.95,
            'Straight flush': 1.0,
            'Royal flush': 1.0
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def card_rank(self, card):
        rank = card[:-1]
        if rank == 'A': return 14
        if rank == 'K': return 13
        if rank == 'Q': return 12
        if rank == 'J': return 11
        if rank == 'T': return 10
        return int(rank)

    def suit(self, card):
        return card[-1]

    def evaluate_hole_strength(self, hole_cards):
        r1, r2 = sorted([self.card_rank(c) for c in hole_cards])
        s1, s2 = self.suit(hole_cards[0]), self.suit(hole_cards[1])
        suited = s1 == s2
        pair = r1 == r2
        gap = r2 - r1
        premium_pairs = [14, 13, 12, 11, 10]
        strong_connected = gap <= 1 and r2 >= 10
        ace_high_suited = (r2 == 14 and suited and r1 >= 10)

        if pair and r1 in premium_pairs:
            return 0.9
        elif pair:
            return 0.6 + (r1 / 14) * 0.2
        elif suited and ace_high_suited:
            return 0.85
        elif suited and strong_connected:
            return 0.8
        elif suited and gap <= 3:
            return 0.4 + (r2 / 14) * 0.3
        elif gap <= 1:
            return 0.5 + (r2 / 14) * 0.25
        else:
            return 0.1 + (r2 / 14) * 0.2

    def count_outs(self, hole_cards, community_cards):
        if len(community_cards) < 3:
            return 0
        all_cards = hole_cards + community_cards
        ranks = [c[:-1] for c in all_cards]
        suits = [c[-1] for c in all_cards]

        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1

        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        flush_draw = max(suit_count.values()) == 4
        straight_draw = self.has_straight_draw(ranks)

        outs = 0
        if flush_draw:
            outs += 9
        if straight_draw:
            outs += 8
        for r, cnt in rank_count.items():
            if cnt == 2:
                outs += 2
        return outs

    def has_straight_draw(self, ranks):
        rank_vals = set()
        for r in ranks:
            if r == 'A': rank_vals.update([1, 14])
            elif r == 'K': rank_vals.add(13)
            elif r == 'Q': rank_vals.add(12)
            elif r == 'J': rank_vals.add(11)
            elif r == 'T': rank_vals.add(10)
            else: rank_vals.add(int(r))
        sorted_vals = sorted(rank_vals)
        for i in range(len(sorted_vals) - 3):
            if sorted_vals[i+3] - sorted_vals[i] <= 4:
                return True
        return False

    def simulate_win_probability(self, hole_cards, community_cards, simulations=100):
        if len(community_cards) == 5:
            return 0.5
        deck = self.generate_remaining_deck(hole_cards, community_cards)
        if len(community_cards) == 0:
            return self.evaluate_hole_strength(hole_cards)
        elif len(community_cards) == 3 or len(community_cards) == 4:
            wins = 0
            for _ in range(simulations):
                simulated_board = community_cards[:]
                needed = 5 - len(simulated_board)
                burn = random.sample(deck, min(len(deck), needed + 1))
                turn_river = burn[1:]
                simulated_board += turn_river[:needed]
                my_hand = self.best_hand(hole_cards, simulated_board)
                opp_hand = self.best_hand(random.sample(deck, 2), simulated_board)
                if self.compare_hands(my_hand, opp_hand) > 0:
                    wins += 1
            return wins / simulations if simulations > 0 else 0.5
        return 0.5

    def generate_remaining_deck(self, hole_cards, community_cards):
        all_used = hole_cards + community_cards
        deck = []
        suits = ['h', 'd', 'c', 's']
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        for r in ranks:
            for s in suits:
                card = r + s
                if card not in all_used:
                    deck.append(card)
        return deck

    def best_hand(self, hole_cards, community_cards):
        from itertools import combinations
        all_cards = hole_cards + community_cards
        best_rank = -1
        best_hand_cards = []

        for combo in combinations(all_cards, 5):
            rank = self.hand_rank(combo)
            if rank > best_rank:
                best_rank = rank
                best_hand_cards = list(combo)
        return best_hand_cards

    def hand_rank(self, hand):
        ranks = sorted([self.card_rank(c) for c in hand], reverse=True)
        suits = [self.suit(c) for c in hand]
        is_flush = len(set(suits)) == 1
        is_straight = all(ranks[i] - ranks[i+1] == 1 for i in range(4))
        if ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]

        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        count_vals = sorted(rank_count.values(), reverse=True)
        count_rank = {}
        for r, cnt in rank_count.items():
            count_rank[cnt] = count_rank.get(cnt, []) + [r]
        for counts in count_rank.values():
            counts.sort(reverse=True)

        if is_straight and is_flush:
            if ranks[0] == 14:
                return 9
            return 8
        if count_vals == [4, 1]:
            return 7
        if count_vals == [3, 2]:
            return 6
        if is_flush:
            return 5
        if is_straight:
            return 4
        if count_vals == [3, 1, 1]:
            return 3
        if count_vals == [2, 2, 1]:
            return 2
        if count_vals == [2, 1, 1, 1]:
            return 1
        return 0

    def compare_hands(self, hand1, hand2):
        r1 = self.hand_rank(hand1)
        r2 = self.hand_rank(hand2)
        if r1 != r2:
            return 1 if r1 > r2 else -1

        h1_ranks = sorted([self.card_rank(c) for c in hand1], reverse=True)
        h2_ranks = sorted([self.card_rank(c) for c in hand2], reverse=True)
        for a, b in zip(h1_ranks, h2_ranks):
            if a != b:
                return 1 if a > b else -1
        return 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        player_id_str = str(self.id)
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_bet = round_state.player_bets.get(player_id_str, 0)
        amount_to_call = current_bet - player_bet

        hole_cards = None
        if hasattr(self, '_hole_cards'):
            hole_cards = self._hole_cards
        else:
            hole_cards = []

        # Default action to fold if error
        try:
            # Estimate strength
            if len(community_cards) == 0:
                hole_strength = self.evaluate_hole_strength(hole_cards)
            else:
                win_prob = self.simulate_win_probability(hole_cards, community_cards, simulations=50)
                hole_strength = win_prob

            aggression_factor = 1.0
            if len(community_cards) == 3:
                outs = self.count_outs(hole_cards, community_cards)
                if outs >= 8:
                    aggression_factor = 1.5

            in_position = round_state.current_player[0] == self.id
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-9)
            equity = hole_strength

            # Decision logic
            if amount_to_call == 0:
                if equity > 0.3:
                    if equity > 0.7 and random.random() < 0.7:
                        raise_amount = min(max(pot, min_raise), max_raise)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if random.random() < 0.3:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)

            # Folding threshold
            if equity < pot_odds * 0.7:
                return (PokerAction.FOLD, 0)

            # Calling
            if equity > pot_odds:
                if amount_to_call <= remaining_chips:
                    if equity > 0.8 and random.random() < 0.4 and max_raise > 0:
                        raise_amount = min(int(pot * 1.5), max_raise)
                        raise_amount = max(raise_amount, min_raise)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)

            # Bluff occasionally on flop if checked to
            if (len(community_cards) == 3 and equity > 0.4 and amount_to_call / (pot + 1e-9) < 0.5
                and random.random() < 0.2 and in_position):
                bluff_raise = min(pot, max_raise)
                if bluff_raise >= min_raise:
                    return (PokerAction.RAISE, bluff_raise)

            # All-in strong hands
            if equity > 0.85 and remaining_chips > 0:
                return (PokerAction.ALL_IN, 0)

            return (PokerAction.CALL, 0)

        except Exception as e:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass