from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.position = 0  # 0 = early, 1 = middle, 2 = late (button/big blind)
        self.hand_strength = 0.0
        self.estimated_equity = 0.0
        self.volatility = 0.0
        self.tight_aggressive = True
        self.tightness_factor = 1.2  # Higher means tighter
        self.aggression_factor = 1.5  # Multiplier for raise size
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update position relative to dealer
        current_id = str(self.id)
        if not round_state.current_player:
            return
        
        # Estimate position: late if next to act near end of betting order
        acting_player_ids = [str(pid) for pid in round_state.current_player]
        try:
            my_idx = acting_player_ids.index(current_id)
            total_players = len(acting_player_ids)
            if my_idx == total_players - 1 or my_idx == total_players - 2:
                self.position = 2  # Late position
            elif my_idx >= total_players // 2:
                self.position = 1  # Middle
            else:
                self.position = 0  # Early
        except ValueError:
            self.position = 0
        
        # Reset hand-specific data
        self.evaluate_hand_strength(round_state, remaining_chips)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_id = str(self.id)
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        my_current_bet = round_state.player_bets.get(current_id, 0)
        to_call = current_bet - my_current_bet
        my_stack = remaining_chips

        # If no valid action possible, fold (should not happen normally)
        if my_stack <= 0:
            return (PokerAction.FOLD, 0)

        # Auto-fold if can't call and not already all-in
        if to_call > my_stack and to_call > 0:
            return (PokerAction.FOLD, 0)

        # Determine phase
        phase = round_state.round
        is_preflop = phase == 'Preflop'
        is_postflop = not is_preflop

        # Get adjusted hand strength
        strength = self.hand_strength
        equity = self.estimated_equity
        volatility = self.volatility

        # Adjust strength based on position and phase
        if is_preflop:
            pos_adj = 1.0 + 0.1 * self.position  # Better in late position
            strength *= pos_adj
        else:
            # Postflop: consider board texture and draw potential
            strength = min(equity + volatility * 0.5, 1.0)

        # Fold threshold
        if strength < 0.15:
            return (PokerAction.FOLD, 0)

        # Check/fold if weak and facing large bet
        if strength < 0.3 and to_call > 0:
            call_threshold = 0.1 * pot
            if to_call > call_threshold:
                return (PokerAction.FOLD, 0)
            elif to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CALL, 0)

        # Strong hand actions
        if strength >= 0.8:
            if to_call == 0:
                # Initiative: bet for value
                bet_size = min(int(pot * self.aggression_factor), my_stack)
                bet_size = max(min_raise, min(bet_size, max_raise))
                return (PokerAction.RAISE, bet_size)
            elif to_call > 0:
                if to_call >= my_stack * 0.4:
                    return (PokerAction.ALL_IN, 0)
                else:
                    # Call or raise depending on aggression
                    if random.random() < 0.7:
                        return (PokerAction.CALL, 0)
                    else:
                        raise_amount = min(current_bet * 2, my_stack)
                        raise_amount = max(min_raise, min(raise_amount, max_raise))
                        return (PokerAction.RAISE, raise_amount)

        # Medium strength
        if strength >= 0.5:
            if to_call == 0:
                # Bet for value or semi-bluff
                bet_size = min(int(pot * 0.7), my_stack)
                bet_size = max(min_raise, min(bet_size, max_raise))
                return (PokerAction.RAISE, bet_size)
            else:
                call_threshold = 0.4 * pot
                if to_call <= call_threshold or to_call < my_stack * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Weak to medium: trap or fold
        if strength >= 0.3:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                call_threshold = 0.2 * pot
                if to_call <= call_threshold:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Default fallback
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        elif to_call >= my_stack:
            return (PokerAction.ALL_IN, 0)
        else:
            return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optionally track results for adaptive strategy
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally learn from revealed hands
        pass

    def evaluate_hand_strength(self, round_state: RoundStateClient, remaining_chips: int):
        hole_cards = self.player_hands
        community_cards = round_state.community_cards
        is_preflop = len(community_cards) == 0

        if is_preflop and hole_cards:
            strength, _ = self.preflop_hand_rank(hole_cards[0], hole_cards[1])
            self.hand_strength = min(strength * self.tightness_factor, 1.0)
            self.estimated_equity = self.hand_strength
            self.volatility = 0.1
        else:
            eval_result = self.full_eval(hole_cards, community_cards)
            self.hand_strength = eval_result['strength']
            self.estimated_equity = eval_result['equity']
            self.volatility = eval_result['volatility']

    def preflop_hand_rank(self, card1: str, card2: str) -> Tuple[float, str]:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suit1 = card1[-1]
        suit2 = card2[-1]
        rank1 = rank_map[card1[0:-1]]
        rank2 = rank_map[card2[0:-1]]

        is_suited = (suit1 == suit2)
        is_pair = (rank1 == rank2)
        gap = abs(rank1 - rank2)
        top_rank = max(rank1, rank2)
        bottom_rank = min(rank1, rank2)

        score = 0.0

        # Pair bonus
        if is_pair:
            score = 0.3 + (top_rank - 2) * 0.05
        else:
            # High cards
            if top_rank >= 11:  # J, Q, K, A
                score += 0.1 + (top_rank - 11) * 0.05
            if bottom_rank >= 10:  # T, J, Q, K, A
                score += 0.05 + max(0, (bottom_rank - 10)) * 0.02

            # Suited bonus
            if is_suited:
                score += 0.05

            # Connectedness
            if gap == 0:
                score += 0.1
            elif gap == 1:
                score += 0.08
            elif gap == 2:
                score += 0.05
            elif gap == 3:
                score += 0.02

            # Adjust for connector under 6s
            if top_rank <= 5 and gap <= 1:
                score += 0.05

            # Penalize big gap with high cards
            if gap >= 4 and top_rank >= 12:
                score -= 0.05

        # Scale to [0,1]
        score = min(max(score, 0.0), 1.0)
        hand_type = "Premium" if score >= 0.5 else "Strong" if score >= 0.3 else "Marginal" if score >= 0.15 else "Weak"
        return (score, hand_type)

    def full_eval(self, hole_cards: List[str], community_cards: List[str]) -> Dict:
        if not hole_cards:
            return {'strength': 0.0, 'equity': 0.0, 'volatility': 0.1}
        
        all_cards = hole_cards + community_cards
        hand_rank = self.evaluate_hand_rank(all_cards)
        
        # Simple strength mapping
        hand_type_scores = {
            'StraightFlush': 0.95,
            'FourOfAKind': 0.90,
            'FullHouse': 0.80,
            'Flush': 0.70,
            'Straight': 0.60,
            'ThreeOfAKind': 0.50,
            'TwoPair': 0.40,
            'OnePair': 0.30,
            'HighCard': 0.15
        }
        
        hand_type = hand_rank['type']
        strength = hand_type_scores.get(hand_type, 0.1)
        
        # Adjust for kicker
        if hand_type == 'OnePair':
            kicker = hand_rank.get('kicker', 0)
            strength += min(kicker * 0.01, 0.1)
        elif hand_type == 'HighCard':
            top_kicker = hand_rank.get('ranks', [0])[0]
            strength = 0.05 + top_kicker * 0.008
        
        # Estimate equity vs unknown hands
        num_known = len(community_cards) + len(hole_cards)
        unknown_cards = 52 - num_known
        equity_estimate = strength
        
        # Volatility based on draws
        draws = self.identify_draws(hole_cards, community_cards)
        flush_draw = draws.get('flush', False)
        straight_draw = draws.get('straight', False)
        overcards = draws.get('overcards', 0)
        
        volatility = 0.0
        if flush_draw or straight_draw or overcards > 0:
            volatility = 0.3 + random.uniform(-0.05, 0.05)
        else:
            volatility = 0.1
        
        # Improve equity if drawing
        if flush_draw:
            equity_estimate = max(equity_estimate, 0.4)
        if straight_draw:
            equity_estimate = max(equity_estimate, 0.35)
        if overcards and len(community_cards) < 5:
            equity_estimate = max(equity_estimate, 0.25)
        
        return {
            'strength': strength,
            'equity': equity_estimate,
            'volatility': volatility,
            'draws': draws
        }

    def evaluate_hand_rank(self, cards: List[str]) -> Dict:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suits = [card[-1] for card in cards]
        ranks = [rank_map[card[0:-1]] for card in cards]
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        # Sort ranks by count (desc) then by value (desc)
        sorted_ranks = sorted(rank_counts.keys(), key=lambda x: (-rank_counts[x], -x))
        
        # Group by count
        by_count = {}
        for r in sorted_ranks:
            c = rank_counts[r]
            by_count.setdefault(c, []).append(r)
        
        is_flush = any(suits.count(s) >= 5 for s in set(suits))
        unique_ranks = sorted(set(ranks), reverse=True)
        has_ace = 14 in unique_ranks
        
        # Check straight
        def has_straight(ranks_list):
            sorted_uniq = sorted(set(ranks_list), reverse=True)
            if len(sorted_uniq) < 5:
                return False, []
            # Add A-5-4-3-2 low straight
            extended = sorted_uniq[:]
            if 14 in sorted_uniq:
                extended.append(1)
            extended.sort(reverse=True)
            for i in range(len(extended) - 4):
                window = extended[i:i+5]
                if all(window[j] == window[j+1] + 1 for j in range(4)):
                    return True, window[0]
            return False, 0
        
        straight, high_straight = has_straight(ranks)
        
        # Royal Flush
        if is_flush and straight and high_straight == 14:
            return {'type': 'StraightFlush', 'ranks': [14, 13, 12, 11, 10], 'kicker': 0}
        
        # Straight Flush
        if is_flush and straight:
            return {'type': 'StraightFlush', 'ranks': list(range(high_straight, high_straight-5, -1)), 'kicker': high_straight}
        
        # Four of a kind
        if 4 in by_count:
            quad_rank = by_count[4][0]
            kicker = by_count.get(1, [0])[0]
            return {'type': 'FourOfAKind', 'ranks': [quad_rank]*4, 'kicker': kicker}
        
        # Full House
        if 3 in by_count and (2 in by_count or len(by_count.get(3, [])) > 1):
            trips = by_count[3][0]
            pair = by_count[2][0] if 2 in by_count else by_count[3][1]
            return {'type': 'FullHouse', 'ranks': [trips]*3 + [pair]*2, 'kicker': 0}
        
        # Flush
        if is_flush:
            flush_ranks = []
            for s in set(suits):
                if suits.count(s) >= 5:
                    suited_ranks = [r for r, suit in zip(ranks, suits) if suit == s]
                    flush_ranks = sorted(suited_ranks, reverse=True)[:5]
                    break
            return {'type': 'Flush', 'ranks': flush_ranks, 'kicker': flush_ranks[0]}
        
        # Straight
        if straight:
            return {'type': 'Straight', 'ranks': list(range(high_straight, high_straight-5, -1)), 'kicker': high_straight}
        
        # Three of a kind
        if 3 in by_count:
            trips_rank = by_count[3][0]
            kickers = by_count.get(1, [])[:2]
            return {'type': 'ThreeOfAKind', 'ranks': [trips_rank]*3, 'kicker': max(kickers) if kickers else 0}
        
        # Two pair
        if 2 in by_count and len(by_count[2]) >= 2:
            pairs = by_count[2][:2]
            kicker = by_count.get(1, [0])[0]
            return {'type': 'TwoPair', 'ranks': [pairs[0], pairs[0], pairs[1], pairs[1]], 'kicker': kicker}
        
        # One pair
        if 2 in by_count:
            pair_rank = by_count[2][0]
            kickers = by_count.get(1, [])[:3]
            return {'type': 'OnePair', 'ranks': [pair_rank, pair_rank], 'kicker': max(kickers) if kickers else 0}
        
        # High card
        return {'type': 'HighCard', 'ranks': unique_ranks[:5], 'kicker': unique_ranks[0]}

    def identify_draws(self, hole_cards: List[str], community_cards: List[str]) -> Dict:
        if len(community_cards) < 3:
            return {'flush': False, 'straight': False, 'overcards': 0}
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        hole_ranks = [rank_map[card[0:-1]] for card in hole_cards]
        hole_suits = [card[-1] for card in hole_cards]
        comm_ranks = [rank_map[card[0:-1]] for card in community_cards]
        comm_suits = [card[-1] for card in community_cards]
        
        # Flush draw: 4 cards of same suit
        all_suits = hole_suits + comm_suits
        suit_count = {s: all_suits.count(s) for s in set(all_suits)}
        has_flush_draw = any(v >= 4 for v in suit_count.values())
        
        # Check if we contribute to flush
        if has_flush_draw:
            flush_suit = next(s for s, cnt in suit_count.items() if cnt >= 4)
            hole_suited = hole_suits.count(flush_suit)
            has_flush_draw = (hole_suited >= 1)
        else:
            has_flush_draw = False
        
        # Straight draw
        all_ranks = hole_ranks + comm_ranks
        unique_ranks = set(all_ranks)
        has_ace = 14 in unique_ranks
        extended_ranks = set(unique_ranks)
        if has_ace:
            extended_ranks.add(1)
        
        # Check open-ended or gutshot
        has_straight_draw = False
        for r in range(2, 12):
            needed = [r+1, r+2, r+3, r+4]
            missing = [x for x in needed if x not in unique_ranks and (x if x > 1 else 14) not in unique_ranks]
            if len(missing) <= 1:
                has_straight_draw = True
                break
        
        # Overcards to board
        if community_cards:
            board_top = max(comm_ranks)
            overcards = sum(1 for hr in hole_ranks if hr > board_top)
        else:
            overcards = 0
        
        return {
            'flush': has_flush_draw,
            'straight': has_straight_draw,
            'overcards': overcards
        }