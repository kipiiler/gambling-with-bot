from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.assigned_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hole_cards = []
        self.positional_advantage = False
        self.tight_aggressive_factor = 0.7
        self.last_round_pot = 0
        self.voluntary_put_in_pot = 0
        self.hand_strength_estimate = 0.0
        self.estimated_equity = 0.0
        self.bets_this_round = 0
        self.fold_threshold = 0.3
        self.call_threshold = 0.5
        self.raise_threshold = 0.7
        self.aggression_factor = 1.5
        self.raise_multiplier = 3.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.assigned_id = str(self.id)
        if self.assigned_id in player_hands:
            self.hole_cards = player_hands[self.assigned_id]
        self.voluntary_put_in_pot = 0
        self.last_round_pot = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.bets_this_round = round_state.player_bets.get(self.assigned_id, 0)
        self.hole_cards = []  # Will be set only once per hand via on_start, but cleared here for consistency
        self.hand_strength_estimate = 0.0
        self.estimated_equity = 0.0

    def card_rank_value(self, card: str) -> int:
        """Convert card rank to numeric value: 2-14 (Ace=14)"""
        if len(card) < 2:
            return 0
        r = card[0]
        if r == 'T': return 10
        if r == 'J': return 11
        if r == 'Q': return 12
        if r == 'K': return 13
        if r == 'A': return 14
        return int(r)

    def card_suit(self, card: str) -> str:
        """Extract suit of card"""
        return card[-1]

    def is_suited(self) -> bool:
        if len(self.hole_cards) < 2:
            return False
        return self.card_suit(self.hole_cards[0]) == self.card_suit(self.hole_cards[1])

    def is_pair(self) -> bool:
        if len(self.hole_cards) < 2:
            return False
        return self.card_rank_value(self.hole_cards[0]) == self.card_rank_value(self.hole_cards[1])

    def is_connected(self) -> bool:
        if len(self.hole_cards) < 2:
            return False
        r1 = self.card_rank_value(self.hole_cards[0])
        r2 = self.card_rank_value(self.hole_cards[1])
        return abs(r1 - r2) == 1

    def is_broadway(self) -> bool:
        if len(self.hole_cards) < 2:
            return False
        r1 = self.card_rank_value(self.hole_cards[0])
        r2 = self.card_rank_value(self.hole_cards[1])
        return r1 >= 10 and r2 >= 10

    def hole_card_strength(self) -> float:
        """Evaluate hole card strength using a simplified system based on known good starting hands."""
        if len(self.hole_cards) < 2:
            return 0.1
        r1 = self.card_rank_value(self.hole_cards[0])
        r2 = self.card_rank_value(self.hole_cards[1])
        high_card = max(r1, r2)
        low_card = min(r1, r2)
        score = 0.0

        # Pocket pairs
        if self.is_pair():
            score += 0.2 + (high_card / 100)  # Stronger pairs get higher base
            if high_card >= 10:
                score += 0.15
        else:
            # Non-pairs
            if self.is_suited():
                score += 0.1
            if self.is_connected():
                score += 0.05
            if abs(r1 - r2) == 2:  # One-gapper
                score += 0.03
            if abs(r1 - r2) == 3:  # Two-gapper
                score += 0.01

            # High cards bonus
            if high_card >= 10:
                score += 0.1
            if low_card >= 10:
                score += 0.05

            # Ace bonus
            if high_card == 14:
                score += 0.1
                if low_card >= 10:
                    score += 0.07
                elif low_card >= 2:
                    score += 0.02

        # Reduce for weak combos
        if low_card <= 6 and high_card >= 10 and not self.is_suited() and abs(r1 - r2) > 2:
            score -= 0.15

        # Normalize roughly between 0 and 1
        score = max(0.05, min(0.95, score))
        return score

    def count_outs(self, round_state: RoundStateClient) -> int:
        """Roughly count outs given current hole cards and community cards."""
        if len(self.hole_cards) < 2:
            return 0

        all_cards = self.hole_cards + round_state.community_cards
        ranks = [self.card_rank_value(c) for c in all_cards]
        suits = [self.card_suit(c) for c in all_cards]

        outs = 0
        possible_cards = [f"{r}{s}" for r in '23456789TJQKA' for s in 'shdc']
        for card in possible_cards:
            if card in all_cards:
                continue
            new_ranks = ranks + [self.card_rank_value(card)]
            new_suits = suits + [self.card_suit(card)]

            # Flush draw
            if suits.count(self.card_suit(card)) >= 4 and self.card_suit(card) in [self.card_suit(c) for c in self.hole_cards]:
                outs += 1

            # Straight draw
            sorted_unq_ranks = sorted(set(new_ranks))
            if len(sorted_unq_ranks) >= 4:
                for i in range(len(sorted_unq_ranks) - 3):
                    if sorted_unq_ranks[i+3] - sorted_unq_ranks[i] <= 4:
                        outs += 1
                        break

        return outs

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Estimate hand strength based on hole cards and board."""
        hole = self.hole_cards
        board = round_state.community_cards
        n_board = len(board)

        if n_board == 0:
            return self.hole_card_strength()

        # Count pairs, draws
        all_cards = hole + board
        ranks = [self.card_rank_value(c) for c in all_cards]
        suits = [self.card_suit(c) for c in all_cards]

        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        pairs = sum(1 for count in rank_count.values() if count == 2)
        trips = sum(1 for count in rank_count.values() if count == 3)
        quads = sum(1 for count in rank_count.values() if count == 4)
        flush_draw = any(count >= 4 for count in suit_count.values())
        has_flush = any(count >= 5 for count in suit_count.values())
        has_pair = pairs >= 1 or trips >= 1 or quads >= 1

        # Straight check
        sorted_ranks = sorted(set(ranks))
        has_straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                has_straight = True
                break
        if 14 in sorted_ranks:
            # Ace low straight
            low_straight = {2, 3, 4, 5}
            if low_straight.issubset(set(sorted_ranks)):
                has_straight = True

        # Outs based
        outs = self.count_outs(round_state)
        improvement_potential = min(1.0, outs / 15)

        base_strength = 0.0
        if has_flush:
            base_strength = 0.8
        elif has_straight:
            base_strength = 0.7
        elif trips:
            base_strength = 0.6
        elif pairs >= 2:
            base_strength = 0.5
        elif has_pair:
            base_strength = 0.4
        else:
            high_card_strength = max(ranks) / 14
            base_strength = 0.1 + high_card_strength * 0.2

        if n_board < 5:
            # Adjust based on draw potential
            if flush_draw and not has_flush:
                base_strength = max(base_strength, 0.5)
                base_strength += improvement_potential * 0.3
            if outs >= 8:
                base_strength += improvement_potential * 0.3

        # Use hole cards relevance
        hole_ranks = [self.card_rank_value(c) for c in hole]
        hole_suits = [self.card_suit(c) for c in hole]
        hole_contributes = False
        if has_flush and any(suit_count[s] >= 5 for s in hole_suits):
            hole_contributes = True
        elif has_pair:
            if any(rank_count[r] >= 2 for r in hole_ranks):
                hole_contributes = True
        else:
            if max(hole_ranks) == max(ranks):
                hole_contributes = True

        if not hole_contributes:
            base_strength *= 0.7

        return max(0.01, min(0.99, base_strength))

    def estimate_equity(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Estimate equity against average opponent range."""
        hand_strength = self.evaluate_hand_strength(round_state)
        n_board = len(round_state.community_cards)

        if n_board == 0:
            # Preflop: use hole strength directly as proxy
            return hand_strength

        # Opponent range width estimation (simplified)
        opponent_tightness = 0.7
        position = self.get_position_value(round_state)
        pot_odds = self.get_pot_odds(round_state, remaining_chips)

        # Update estimate with board texture
        equity = hand_strength

        # Add uncertainty
        uncertainty = 0.15 * (1 - n_board * 0.2)
        equity = equity * (1 - uncertainty) + random.random() * uncertainty

        return max(0.01, min(0.99, equity))

    def get_position_value(self, round_state: RoundStateClient) -> float:
        """Estimate positional advantage: late position = better"""
        active_players = len(round_state.current_player)
        if active_players < 2:
            return 0.5
        own_index = round_state.current_player.index(int(self.assigned_id)) if int(self.assigned_id) in round_state.current_player else 0
        # Later positions are better
        return own_index / max(1, active_players - 1)

    def get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling."""
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(self.assigned_id, 0))
        if to_call <= 0:
            return 1.0
        if to_call > remaining_chips:
            to_call = remaining_chips  # All-in
        return to_call / (round_state.pot + to_call + 1e-9)

    def should_raise(self, equity: float, pot_odds: float, position: float, bet_size_ratio: float) -> bool:
        """Determine if raise is favorable."""
        if equity < self.call_threshold:
            return False
        required_equity_for_raise = 0.5 + bet_size_ratio * 0.2
        return equity > required_equity_for_raise

    def calculate_raise_amount(self, round_state: RoundStateClient, remaining_chips: int, equity: float, position: float) -> int:
        """Calculate appropriate raise amount based on equity and position."""
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot

        # Base raise size on pot
        bet_size = pot * (1.0 + (equity - 0.5) * self.aggression_factor)
        bet_size = max(min_raise, min(bet_size, max_raise, remaining_chips))

        # Position adjustment
        if position > 0.6:
            bet_size *= 1.2
        bet_size = min(bet_size, remaining_chips)

        return int(bet_size)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Store assigned_id as string once
            if self.assigned_id is None:
                self.assigned_id = str(self.id)

            # Retrieve or set hole cards (they should be passed in on_start but not in get_action)
            # Unfortunately, they aren't in round_state — so we rely on on_start having set them.

            # If we don't have hole cards, play extremely tight
            if not self.hole_cards:
                to_call = round_state.current_bet - round_state.player_bets.get(self.assigned_id, 0)
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Update bets this round
            self.bets_this_round = round_state.player_bets.get(self.assigned_id, 0)

            # Estimate equity and position
            self.estimated_equity = self.estimate_equity(round_state, remaining_chips)
            equity = self.estimated_equity
            position = self.get_position_value(round_state)
            pot_odds = self.get_pot_odds(round_state, remaining_chips)

            current_bet = round_state.current_bet
            player_bet = round_state.player_bets.get(self.assigned_id, 0)
            to_call = max(0, current_bet - player_bet)

            # Action decisions
            if to_call == 0:
                # Can check or bet
                if equity > self.raise_threshold:
                    amt = self.calculate_raise_amount(round_state, remaining_chips, equity, position)
                    if amt >= round_state.min_raise and amt <= remaining_chips:
                        return (PokerAction.RAISE, int(amt))
                    elif remaining_chips > 0:
                        return (PokerAction.ALL_IN, 0)
                return (PokerAction.CHECK, 0)

            # We must respond to a bet
            if equity >= self.call_threshold and equity > pot_odds:
                if equity > self.raise_threshold and self.should_raise(equity, pot_odds, position, to_call / (round_state.pot + 1e-9)):
                    amt = self.calculate_raise_amount(round_state, remaining_chips, equity, position)
                    actual_amt = max(round_state.min_raise, min(amt, remaining_chips, round_state.max_raise))
                    if actual_amt >= round_state.min_raise and actual_amt <= remaining_chips:
                        return (PokerAction.RAISE, int(actual_amt))
                if to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                # Fold if not profitable
                return (PokerAction.FOLD, 0)

        except Exception as e:
            # Fallback: fold on any error to avoid crash
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: learn from actions
        self.last_round_pot = round_state.pot

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: final cleanup
        pass