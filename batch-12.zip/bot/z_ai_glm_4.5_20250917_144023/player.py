from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        
        # Find our own hole cards
        if str(self.id) not in all_players:
            return
            
        idx = all_players.index(str(self.id))
        hand_str = player_hands[idx]
        
        # Parse hole cards
        if len(hand_str) == 4:
            self.hole_cards = [hand_str[0:2], hand_str[2:4]]
        elif len(hand_str) == 5:
            parts = hand_str.split()
            if len(parts) == 2:
                self.hole_cards = parts
            else:
                self.hole_cards = [hand_str[0:2], hand_str[3:5]]
        else:
            self.hole_cards = ["", ""]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Default fallback - fold if anything goes wrong
            if remaining_chips <= 0:
                return (PokerAction.FOLD, 0)
                
            # Get current state information
            current_bet = round_state.current_bet
            our_current_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - our_current_bet
            
            # Check if we can afford to call
            if to_call > remaining_chips:
                return (PokerAction.ALL_IN, 0) if remaining_chips > 0 else (PokerAction.FOLD, 0)
            
            # Pre-flop strategy
            if round_state.round == "Preflop":
                category = self._classify_hand_preflop()
                
                # Premium hands: aggressive play
                if category == "premium":
                    raise_amt = min(3 * self.blind_amount, remaining_chips)
                    total_bet = our_current_bet + raise_amt
                    min_raise = round_state.min_raise
                    
                    # Ensure raise meets minimum
                    if total_bet < min_raise:
                        total_bet = min_raise
                    if total_bet > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, total_bet)
                
                # Strong hands: call if affordable
                elif category == "strong":
                    if to_call <= remaining_chips // 3:  # Call if not too expensive
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                
                # Weak hands: fold
                else:
                    if current_bet == our_current_bet:  # Can check
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
            
            # Post-flop strategy
            else:
                # Evaluate hand strength
                hand_rank = self._evaluate_hand_strength(round_state.community_cards)
                
                # Premium hands (flush or better): aggressive play
                if hand_rank >= 6:  # Flush or better
                    # Pot-sized raise if possible
                    raise_amt = min(round_state.pot, remaining_chips)
                    total_bet = our_current_bet + raise_amt + to_call
                    min_raise = round_state.min_raise
                    
                    if total_bet < min_raise:
                        total_bet = min_raise
                    if total_bet > remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, total_bet)
                
                # Strong hands (straight or three of a kind): call if affordable
                elif hand_rank >= 4:  # Straight or three of a kind
                    if to_call <= remaining_chips // 4:  # Call if not too expensive
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                
                # Weak hands: check if possible, otherwise fold
                else:
                    if current_bet == our_current_bet:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
                    
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    # Helper methods
    def _classify_hand_preflop(self) -> str:
        if not self.hole_cards or len(self.hole_cards) < 2 or not self.hole_cards[0] or not self.hole_cards[1]:
            return "weak"
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        r1, s1 = card1[0], card1[1]
        r2, s2 = card2[0], card2[1]
        
        # Convert ranks to numerical values
        try:
            v1 = self.rank_map[r1]
            v2 = self.rank_map[r2]
        except KeyError:
            return "weak"
            
        # Sort in descending order
        vr = sorted([v1, v2], reverse=True)
        suited = (s1 == s2)
        
        # Pocket pairs
        if v1 == v2:
            if vr[0] >= 13:  # AA, KK
                return "premium"
            elif vr[0] >= 10:  # QQ, JJ, TT
                return "strong"
            return "weak"
        
        # Non-paired hands
        if vr[0] == 14 and vr[1] == 13:  # AK
            return "premium" if suited else "strong"
        elif (vr[0] == 14) and (vr[1] in [12, 11]):  # AQ, AJ
            return "strong" if suited else "weak"
        elif (vr[0] == 13) and (vr[1] == 12):  # KQ
            return "strong" if suited else "weak"
            
        return "weak"
    
    def _evaluate_hand_strength(self, community_cards: List[str]) -> int:
        if not self.hole_cards or not community_cards:
            return 1  # High card by default
            
        all_cards = self.hole_cards + community_cards
        if len(all_cards) < 5:
            return 1
            
        best_rank = 1
        from itertools import combinations
        
        for combo in combinations(all_cards, 5):
            rank_val = self._evaluate_5card_hand(list(combo))
            if rank_val > best_rank:
                best_rank = rank_val
                
        return best_rank
    
    def _evaluate_5card_hand(self, cards: List[str]) -> int:
        ranks = []
        suits = []
        
        # Parse cards
        for card in cards:
            if len(card) < 2:
                continue
            r = card[0]
            s = card[1]
            try:
                ranks.append(self.rank_map[r])
                suits.append(s)
            except KeyError:
                continue
                
        # Check flush
        flush = len(set(suits)) == 1
        
        # Sort ranks
        sorted_ranks = sorted(ranks)
        
        # Check for straight
        straight = True
        for i in range(1, 5):
            if sorted_ranks[i] != sorted_ranks[i-1] + 1:
                straight = False
                break
        # Special case for A-2-3-4-5 straight
        if not straight and sorted_ranks == [2, 3, 4, 5, 14]:
            straight = True
            
        # Get rank counts
        from collections import defaultdict
        rank_count = defaultdict(int)
        for r in ranks:
            rank_count[r] += 1
        counts = sorted(rank_count.values(), reverse=True)
        
        # Determine hand rank
        if straight and flush:
            return 9  # Straight flush
        elif counts[0] == 4:
            return 8  # Four of a kind
        elif counts[0] == 3 and counts[1] >= 2:
            return 7  # Full house
        elif flush:
            return 6  # Flush
        elif straight:
            return 5  # Straight
        elif counts[0] == 3:
            return 4  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 3  # Two pair
        elif counts[0] == 2:
            return 2  # One pair
        else:
            return 1  # High card