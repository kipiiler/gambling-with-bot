from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hole_cards = []
        self.current_round_state = None
        self.opponent_aggression = {}  # Track opponent aggression
        self.position = None
        self.table_history = []  # Store round outcomes for learning
        
        # Hand strength lookup table (simplified)
        self.hand_strength_table = {
            'AA': 0.85, 'KK': 0.82, 'QQ': 0.80, 'JJ': 0.77, 'AKs': 0.75,
            'AQs': 0.73, 'AJs': 0.71, 'KQs': 0.70, 'AKo': 0.68, 'TT': 0.67,
            '99': 0.63, '88': 0.60, 'AQo': 0.66, 'KJs': 0.64, 'ATs': 0.62,
            'QJs': 0.61, 'KTs': 0.59, 'QTs': 0.58, 'JTs': 0.57, 'A9s': 0.56
        }
        
        # Card rank lookup
        self.ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                     '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Initialize the game session"""
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_aggression[player_id] = 0.5  # baseline aggression
                
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round"""
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        
        # Determine position (simplified)
        if self.id in round_state.current_player:
            self.position = round_state.current_player.index(self.id)
            
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player"""
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        
        # Ensure we have hole cards
        if not hasattr(self, 'my_hole_cards') or not self.my_hole_cards:
            self.my_hole_cards = []  # Initialize if missing
            return PokerAction.FOLD, 0
            
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds()
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength()
        
        # Adjust based on opponent aggression
        if self.id in [p for p in round_state.current_player if p != self.id]:
            opp_id = [p for p in round_state.current_player if p != self.id][0]
            hand_strength *= (1 + 0.2 * (self.opponent_aggression.get(opp_id, 0.5) - 0.5))
        
        # Decision logic based on hand strength and pot odds
        if round_state.current_bet == 0:  # No one has bet yet
            if hand_strength > 0.7:
                # Strong hand - raise
                raise_amount = min(3 * round_state.pot, remaining_chips)
                raise_amount = max(raise_amount, round_state.min_raise)
                return PokerAction.RAISE, raise_amount
            elif hand_strength > 0.5:
                # Medium hand - check to see free cards
                return PokerAction.CHECK, 0
            else:
                # Weak hand - check or fold
                if random.random() < 0.2:  # Occasional bluff
                    raise_amount = min(2 * round_state.pot, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.CHECK, 0
        else:  # Someone has bet
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            
            if call_amount >= remaining_chips:  # All-in situation
                if hand_strength > 0.6:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            
            if hand_strength > 0.8:  # Very strong hand
                # Re-raise
                raise_amount = min(3 * round_state.pot, remaining_chips)
                raise_amount = max(raise_amount, round_state.min_raise)
                return PokerAction.RAISE, raise_amount
            elif hand_strength > pot_odds:
                # Worth calling
                return PokerAction.CALL, 0
            else:
                # Bluff with some probability
                if random.random() < 0.15 and hand_strength > 0.3:
                    raise_amount = min(2 * round_state.pot, remaining_chips)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.FOLD, 0
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round"""
        # Update opponent aggression based on their actions
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id != self.id:
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression[player_id] = min(1.0, self.opposition_aggression.get(player_id, 0.5) + 0.05)
                elif action == 'Fold':
                    self.opponent_aggression[player_id] = max(0.0, self.opposition_aggression.get(player_id, 0.5) - 0.01)
                    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        # Store game result for analysis
        self.table_history.append({
            'score': player_score,
            'all_scores': all_scores,
            'hands': active_players_hands
        })
        
    def _calculate_pot_odds(self) -> float:
        """Calculate the pot odds for the current situation"""
        if not self.current_round_state or self.current_round_state.current_bet == 0:
            return 0.0
            
        call_amount = self.current_round_state.current_bet - self.current_round_state.player_bets.get(str(self.id), 0)
        if call_amount <= 0:
            return 0.0
            
        # Avoid division by zero
        pot_size = max(self.current_round_state.pot + call_amount, 1)
        return call_amount / pot_size
        
    def _evaluate_hand_strength(self) -> float:
        """Evaluate the strength of the current hand (0.0 to 1.0)"""
        if not self.my_hole_cards or not self.current_round_state:
            return 0.1  # Default weak hand
            
        # Fix for concatenation error
        hole_cards = self.my_hole_cards if isinstance(self.my_hole_cards, list) else [self.my_hole_cards]
        all_cards = hole_cards + self.current_round_state.community_cards
        
        # Preflop hand evaluation
        if self.current_round_state.round == 'Preflop':
            if len(hole_cards) == 2:
                # Convert to standard notation
                card1, card2 = hole_cards
                ranks = sorted([card1[0], card2[0]], key=lambda x: self.ranks[x], reverse=True)
                suited = card1[1] == card2[1]
                hand_key = ranks[0] + ranks[1] + ('s' if suited else 'o')
                return self.hand_strength_table.get(hand_key, 0.4)
            return 0.5
            
        # Postflop hand evaluation (simplified)
        return self._evaluate_postflop_hand(all_cards)
        
    def _evaluate_postflop_hand(self, cards: List[str]) -> float:
        """Evaluate hand strength after the flop"""
        if len(cards) < 5:
            return 0.5
            
        # Count high cards
        high_cards = sum(1 for card in cards if self.ranks[card[0]] >= 10)
        
        # Check for pairs
        rank_counts = {}
        for card in cards:
            rank = card[0]
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        pairs = sum(1 for count in rank_counts.values() if count >= 2)
        three_of_a_kind = sum(1 for count in rank_counts.values() if count >= 3)
        four_of_a_kind = sum(1 for count in rank_counts.values() if count >= 4)
        
        # Check for flush draws
        suit_counts = {}
        for card in cards:
            suit = card[1]
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        flush_draw = max(suit_counts.values()) >= 4
        flush = max(suit_counts.values()) >= 5
        
        # Simple hand strength calculation
        if four_of_a_kind:
            return 0.95
        elif three_of_a_kind and pairs >= 1:
            return 0.9  # Full house
        elif flush:
            return 0.85
        elif three_of_a_kind:
            return 0.7
        elif pairs >= 2:
            return 0.6
        elif pairs == 1:
            return 0.5 + 0.05 * high_cards
        elif flush_draw:
            return 0.45
        else:
            return 0.3 + 0.02 * high_cards