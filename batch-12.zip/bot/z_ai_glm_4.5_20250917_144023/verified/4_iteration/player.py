from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import collections

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class HandStrength(Enum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.my_hole_cards = []
        self.my_hand = None
        self.position_adjustment = 1.0
        self.bluff_frequency = 0.15
        self.aggression_factor = 1.0
        self.villain_aggression = collections.defaultdict(lambda: 1.0)
        self.villain_tightness = collections.defaultdict(lambda: 0.5)
        self.hand_history = []
        self.table_position = None
        self.total_hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hole_cards = player_hands[0] if player_hands else []
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.table_position = self._calculate_position()
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.total_hands_played += 1
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        self.current_player = round_state.current_player
        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        self.current_bet = round_state.current_bet
        self.min_raise = round_state.min_raise
        self.max_raise = round_state.max_raise
        self.player_bets = round_state.player_bets
        self.player_actions = round_state.player_actions
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.current_round_state = round_state
        self.remaining_chips = remaining_chips
        
        if not self.my_hole_cards:
            return PokerAction.FOLD, 0
            
        hand_strength = self._evaluate_hand_strength()
        pot_odds = self._calculate_pot_odds()
        equity = self._estimate_equity()
        
        round_name = round_state.round
        is_preflop = (round_name == 'Preflop')
        
        position_factor = self._get_position_factor()
        stack_factor = self._get_stack_factor()
        
        opponents = [p for p in round_state.current_player if p != self.id]
        num_opponents = len(opponents)
        
        if is_preflop:
            return self._preflop_strategy(hand_strength, position_factor, num_opponents)
        else:
            return self._postflop_strategy(hand_strength, equity, pot_odds, position_factor, num_opponents, round_name)
    
    def _preflop_strategy(self, hand_strength: float, position_factor: float, num_opponents: int) -> Tuple[PokerAction, int]:
        call_amount = self.current_round_state.current_bet
        
        if hand_strength < 0.3:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        
        elif hand_strength < 0.6:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                if self._calculate_pot_odds() > hand_strength * 1.2:
                    return PokerAction.FOLD, 0
                return PokerAction.CALL, 0
        
        elif hand_strength < 0.8:
            if call_amount == 0:
                raise_amount = min(self.min_raise * 2, self.remaining_chips // 3)
                return PokerAction.RAISE, raise_amount
            else:
                if self._calculate_pot_odds() < hand_strength:
                    if random.random() < (0.3 + position_factor * 0.2):
                        raise_amount = min(self.min_raise * 3, self.remaining_chips // 2)
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
        
        else:
            if call_amount == 0:
                raise_amount = min(self.current_round_state.pot * 0.75, self.remaining_chips // 2)
                return PokerAction.RAISE, max(raise_amount, self.min_raise * 2)
            else:
                if random.random() < (0.5 + position_factor * 0.3):
                    return PokerAction.ALL_IN, 0
                else:
                    raise_amount = min(self.remaining_chips * 0.4, self.current_round_state.pot)
                    return PokerAction.RAISE, max(raise_amount, self.min_raise * 2)
    
    def _postflop_strategy(self, hand_strength: float, equity: float, pot_odds: float, position_factor: float, num_opponents: int, round_name: str) -> Tuple[PokerAction, int]:
        call_amount = self.current_round_state.current_bet
        
        if hand_strength < 0.3:
            if call_amount == 0:
                if random.random() < self.bluff_frequency and position_factor > 0.5 and num_opponents <= 2:
                    raise_amount = min(self.min_raise * 2, self.remaining_chips // 4)
                    return PokerAction.RAISE, raise_amount
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        
        elif hand_strength < 0.5:
            if call_amount == 0:
                return PokerAction.CHECK, 0
            else:
                if pot_odds < equity * 1.1:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
        
        elif hand_strength < 0.7:
            if call_amount == 0:
                if random.random() < (0.4 + position_factor * 0.2):
                    raise_amount = min(self.current_round_state.pot * 0.6, self.remaining_chips // 3)
                    return PokerAction.RAISE, max(raise_amount, self.min_raise)
                return PokerAction.CHECK, 0
            else:
                if pot_odds < equity:
                    if random.random() < (0.3 + position_factor * 0.3):
                        raise_amount = min(self.current_round_state.pot * 0.75, self.remaining_chips // 2)
                        return PokerAction.RAISE, max(raise_amount, self.min_raise * 2)
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
        
        else:
            if call_amount == 0:
                if random.random() < (0.6 + position_factor * 0.2):
                    raise_amount = min(self.current_round_state.pot, self.remaining_chips // 2)
                    return PokerAction.RAISE, max(raise_amount, self.min_raise * 2)
                return PokerAction.CHECK, 0
            else:
                if random.random() < (0.4 + position_factor * 0.3):
                    return PokerAction.ALL_IN, 0
                else:
                    raise_amount = min(self.remaining_chips * 0.5, self.current_round_state.pot * 1.5)
                    return PokerAction.RAISE, max(raise_amount, self.min_raise * 3)
    
    def _evaluate_hand_strength(self) -> float:
        all_cards = self.my_hole_cards + self.current_round_state.community_cards
        if not all_cards:
            return 0.0
            
        hand_type, strength = self._evaluate_poker_hand(all_cards)
        return min(1.0, strength / 10.0)
    
    def _evaluate_poker_hand(self, cards: List[str]) -> Tuple[str, float]:
        if not cards:
            return "High Card", 0.0
            
        if len(cards) < 5:
            return "High Card", 1.0
            
        value_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                     '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        values = []
        suits = []
        for card in cards:
            if len(card) < 2:
                continue
            value = card[:-1]
            suit = card[-1]
            if value in value_map:
                values.append(value_map[value])
            suits.append(suit)
        
        if not values:
            return "High Card", 0.0
            
        values.sort(reverse=True)
        value_counts = collections.Counter(values)
        suit_counts = collections.Counter(suits)
        
        is_flush = max(suit_counts.values()) >= 5
        is_straight = self._check_straight(values)
        
        counts = sorted(value_counts.values(), reverse=True)
        
        if is_straight and is_flush:
            return "Straight Flush", 9.0
        if counts[0] == 4:
            return "Four of a Kind", 8.0
        if counts[0] == 3 and counts[1] >= 2:
            return "Full House", 7.0
        if is_flush:
            return "Flush", 6.0
        if is_straight:
            return "Straight", 5.0
        if counts[0] == 3:
            return "Three of a Kind", 4.0
        if counts[0] == 2 and counts[1] == 2:
            return "Two Pair", 3.0
        if counts[0] == 2:
            return "One Pair", 2.0
        
        return "High Card", min(1.0, values[0] / 14.0)
    
    def _check_straight(self, values: List[int]) -> bool:
        unique_values = sorted(list(set(values)), reverse=True)
        if len(unique_values) < 5:
            return False
            
        for i in range(len(unique_values) - 4):
            if unique_values[i] - unique_values[i + 4] == 4:
                return True
        
        if 14 in unique_values and 2 in unique_values and 3 in unique_values and 4 in unique_values and 5 in unique_values:
            return True
            
        return False
    
    def _calculate_pot_odds(self) -> float:
        if self.current_round_state.current_bet <= 0:
            return 0.0
            
        call_amount = self.current_round_state.current_bet
        total_pot = self.current_round_state.pot + call_amount
        
        if total_pot <= 0:
            return 0.0
            
        return call_amount / (total_pot + 1e-6)
    
    def _estimate_equity(self) -> float:
        hand_strength = self._evaluate_hand_strength()
        
        num_opponents = len([p for p in self.current_round_state.current_player if p != self.id])
        if num_opponents == 0:
            return hand_strength
        
        round_factor = {
            'Preflop': 0.7,
            'Flop': 0.8,
            'Turn': 0.9,
            'River': 1.0
        }.get(self.current_round_state.round, 1.0)
        
        adjusted_equity = hand_strength * round_factor
        
        for i in range(1, num_opponents + 1):
            adjusted_equity *= 0.9
        
        return max(0.05, min(1.0, adjusted_equity))
    
    def _get_position_factor(self) -> float:
        if not self.table_position:
            return 0.5
            
        players_order = sorted(self.all_players)
        my_idx = players_order.index(self.id)
        
        active_players = [p for p in players_order if p in self.current_round_state.current_player]
        relative_position = len(active_players) - active_players.index(self.id) - 1
        
        return relative_position / (len(active_players) + 1e-6)
    
    def _get_stack_factor(self) -> float:
        big_blinds = self.remaining_chips / (self.blind_amount + 1e-6)
        
        if big_blinds < 10:
            return 1.5
        elif big_blinds < 20:
            return 1.2
        elif big_blinds < 50:
            return 1.0
        else:
            return 0.8
    
    def _calculate_position(self) -> int:
        players_order = sorted(self.all_players)
        return players_order.index(self.id)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass