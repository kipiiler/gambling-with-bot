import random
from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = -1
        self.blinds_amount = 0
        self.starting_chips = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_id = self.id # Bot parent class sets self.id
        self.hole_cards = player_hands
        self.blinds_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_player_hole_cards(round_state, self.player_id)
        # Reset any round-specific states if needed

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        
        # If current_bet_to_match is 0, we can check. Otherwise, we can only call, raise, or fold.
        can_check = current_bet_to_match == 0

        hand_strength_enum = self._get_hand_strength(self.hole_cards, round_state.community_cards)
        hand_strength_value = hand_strength_enum.value

        # Small adjustments for early rounds and blind status
        is_big_blind = str(self.player_id) == str(round_state.big_blind_player_id)
        is_small_blind = str(self.player_id) == str(round_state.small_blind_player_id)

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Aggressive hands
            if self._is_premium_preflop_hand(self.hole_cards):
                # Always raise or call with premium hands
                if current_bet_to_match > 0 or not can_check:
                    raise_amount = max(round_state.min_raise, self.blinds_amount * 3)
                    if remaining_chips >= current_bet_to_match + raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    elif remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, current_bet_to_match)
                    else: # All-in if unable to call/raise
                        return (PokerAction.ALL_IN, remaining_chips)
                else: # Can check, but with premium hand, prefer to raise for value
                    raise_amount = max(round_state.min_raise, self.blinds_amount * 3)
                    if remaining_chips >= raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)
            
            # Medium hands (suited connectors, high pairs, broadways)
            elif self._is_medium_preflop_hand(self.hole_cards):
                # Call small bets, raise if no bet or small raise, fold to large raises
                if current_bet_to_match == 0: # No bet, check or small raise
                    if random.random() < 0.3: # Sometimes raise for value/to protect blinds
                        raise_amount = max(round_state.min_raise, self.blinds_amount * 2)
                        if remaining_chips >= raise_amount:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.ALL_IN, remaining_chips)
                    else:
                        return (PokerAction.CHECK, 0)
                elif current_bet_to_match <= self.blinds_amount * 2: # Small bet, call
                    if remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, current_bet_to_match)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)
                else: # Large bet for a medium hand, consider folding
                    if random.random() < 0.6: # Fold more often to large bets
                        return (PokerAction.FOLD, 0)
                    elif remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, current_bet_to_match)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)

            # Weak hands
            else:
                if current_bet_to_match == 0:
                    return (PokerAction.CHECK, 0)
                elif is_big_blind and current_bet_to_match <= self.blinds_amount: # Call minimum to defend blind
                    if remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, current_bet_to_match)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            bet_factor = 0
            if hand_strength_value >= HandRank.TWO_PAIR.value: # Strong hands
                bet_factor = 0.7 + random.random() * 0.3 # Bet 70-100% pot
            elif hand_strength_value >= HandRank.ONE_PAIR.value: # Medium hands
                bet_factor = 0.3 + random.random() * 0.3 # Bet 30-60% pot
            elif self._has_strong_draw(self.hole_cards, round_state.community_cards): # Draw hands
                bet_factor = 0.2 + random.random() * 0.2 # Bet 20-40% pot
            
            # Simple aggregation of pot and player bets to estimate current pot size
            # This is a rough estimation as side pots might exist.
            current_pot_estimate = round_state.pot + sum(round_state.player_bets.values())

            if bet_factor > 0 and current_bet_to_match == 0: # We can bet
                bet_amount = int(current_pot_estimate * bet_factor)
                bet_amount = max(bet_amount, round_state.min_raise)
                bet_amount = min(bet_amount, round_state.max_raise)
                bet_amount = max(bet_amount, current_bet_to_match + round_state.min_raise) # Ensure valid raise amount if current bet is 0
                
                if remaining_chips <= bet_amount:
                    return (PokerAction.ALL_IN, remaining_chips)
                elif bet_amount > 0:
                    return (PokerAction.RAISE, bet_amount)
                else:
                    return (PokerAction.CHECK, 0)
            
            elif bet_factor > 0 and current_bet_to_match > 0: # Opponent bet, we have a hand
                # If bet is relatively small, call. If large, consider raising or folding.
                if current_bet_to_match < current_pot_estimate * 0.4: # Call small bets
                    if remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, current_bet_to_match)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)
                else: # Larger bet
                    if hand_strength_value >= HandRank.TWO_PAIR.value: # Strong hand, consider raising
                        raise_amount = int(current_pot_estimate * (bet_factor + 0.2)) # Raise more
                        raise_amount = max(raise_amount, round_state.current_bet + round_state.min_raise)
                        raise_amount = min(raise_amount, remaining_chips)
                        raise_amount = min(raise_amount, round_state.max_raise)
                        if raise_amount > current_bet_to_match: # Ensure it's a valid raise
                            return (PokerAction.RAISE, raise_amount)
                        elif remaining_chips >= current_bet_to_match:
                            return (PokerAction.CALL, current_bet_to_match)
                        else:
                            return (PokerAction.ALL_IN, remaining_chips)
                    elif remaining_chips >= current_bet_to_match and random.random() < 0.4: # Sometimes call with medium/draw hands
                        return (PokerAction.CALL, current_bet_to_match)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Default action if no strong hand or specific bet logic applies
            if current_bet_to_match == 0:
                return (PokerAction.CHECK, 0)
            elif remaining_chips >= current_bet_to_match and random.random() < 0.2: # Occasionally bluff call
                return (PokerAction.CALL, current_bet_to_match)
            else:
                return (PokerAction.FOLD, 0)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_player_hole_cards(self, round_state: RoundStateClient, player_id: int) -> List[str]:
        # This method assumes player_hands from on_start is sufficient for self.hole_cards
        # If hole cards can change (e.g., in subsequent rounds, which they shouldn't in standard NLHE),
        # this would need to pull from round_state if it contained player-specific hole cards.
        # However, typically, bots know their own hole cards and the server doesn't re-send them.
        # This is primarily for clarity and might be redundant if self.hole_cards is updated elsewhere.
        return self.hole_cards

    def _get_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> 'HandRank':
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2:
            return HandRank.HIGH_CARD # Not enough cards to form a hand

        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        suits = ['c', 'd', 'h', 's']

        # Parse cards into a more usable format: list of (rank_value, suit)
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) < 2: # Handle malformed card strings
                continue
            rank_str = card_str[:-1]
            suit_str = card_str[-1]
            try:
                rank_value = ranks.index(rank_str) # 0 for '2', 12 for 'A'
                parsed_cards.append((rank_value, suit_str))
            except ValueError:
                # Handle unknown ranks, effectively ignoring the card or logging an error
                continue

        parsed_cards.sort(key=lambda x: x[0], reverse=True) # Sort by rank descending

        # Helper to get rank counts and suit counts
        rank_counts = {}
        suit_counts = {}
        for rank_val, suit in parsed_cards:
            rank_counts[rank_val] = rank_counts.get(rank_val, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for Flush
        is_flush, flush_suit = self._check_flush(parsed_cards, suit_counts)

        # Check for Straight (and Straight Flush)
        is_straight, high_straight_rank = self._check_straight(parsed_cards)

        # Check for N of a Kind and Full House
        four_of_a_kind = None
        three_of_a_kind = None
        pairs = []
        for rank_val, count in rank_counts.items():
            if count == 4:
                four_of_a_kind = rank_val
            elif count == 3:
                three_of_a_kind = rank_val
            elif count == 2:
                pairs.append(rank_val)
        pairs.sort(reverse=True)

        # Determine HandRank
        if is_straight and is_flush:
            # Check Royal Flush (A, K, Q, J, T of same suit)
            if high_straight_rank == ranks.index('A') and \
               ranks.index('K') in [x[0] for x in parsed_cards if x[1] == flush_suit] and \
               ranks.index('Q') in [x[0] for x in parsed_cards if x[1] == flush_suit] and \
               ranks.index('J') in [x[0] for x in parsed_cards if x[1] == flush_suit] and \
               ranks.index('T') in [x[0] for x in parsed_cards if x[1] == flush_suit]:
                return HandRank.ROYAL_FLUSH
            return HandRank.STRAIGHT_FLUSH
        if four_of_a_kind is not None:
            return HandRank.FOUR_OF_A_KIND
        if three_of_a_kind is not None and len(pairs) >= 1:
            return HandRank.FULL_HOUSE
        if is_flush:
            return HandRank.FLUSH
        if is_straight:
            return HandRank.STRAIGHT
        if three_of_a_kind is not None:
            return HandRank.THREE_OF_A_KIND
        if len(pairs) >= 2:
            return HandRank.TWO_PAIR
        if len(pairs) == 1:
            return HandRank.ONE_PAIR
        
        return HandRank.HIGH_CARD

    def _check_flush(self, parsed_cards: List[Tuple[int, str]], suit_counts: Dict[str, int]) -> Tuple[bool, str]:
        for suit, count in suit_counts.items():
            if count >= 5:
                return True, suit
        return False, None

    def _check_straight(self, parsed_cards: List[Tuple[int, str]]) -> Tuple[bool, int]:
        unique_ranks = sorted(list(set([card[0] for card in parsed_cards])))
        if not unique_ranks:
            return False, -1

        # Add Ace as low card for A-5 straight
        if 12 in unique_ranks: # Ace is rank 12
            unique_ranks.insert(0, -1) # Represent Ace as low (0 for 2, -1 for A low)

        for i in range(len(unique_ranks) - 4):
            # Check for 5 consecutive ranks
            if (unique_ranks[i] == unique_ranks[i+1] - 1 and
                unique_ranks[i+1] == unique_ranks[i+2] - 1 and
                unique_ranks[i+2] == unique_ranks[i+3] - 1 and
                unique_ranks[i+3] == unique_ranks[i+4] - 1):
                return True, unique_ranks[i+4] # Return highest rank in the straight

        return False, -1

    def _is_premium_preflop_hand(self, hole_cards: List[str]) -> bool:
        if not hole_cards or len(hole_cards) < 2:
            return False
        
        c1_rank = hole_cards[0][:-1]
        c2_rank = hole_cards[1][:-1]
        c1_suit = hole_cards[0][-1]
        c2_suit = hole_cards[1][-1]

        # Convert to a comparable format, e.g., '2' -> 2, 'T' -> 10, 'J' -> 11, 'Q' -> 12, 'K' -> 13, 'A' -> 14
        def card_to_int_rank(rank_str):
            if rank_str.isdigit(): return int(rank_str)
            return {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank_str]

        r1 = card_to_int_rank(c1_rank)
        r2 = card_to_int_rank(c2_rank)

        is_suited = (c1_suit == c2_suit)

        # High pairs
        if r1 == r2 and r1 >= 11: # JJ, QQ, KK, AA
            return True
        # AK, AQ suited
        if (sorted([r1, r2]) == [13, 14] and is_suited) or \
           (sorted([r1, r2]) == [12, 14] and is_suited):
           return True
        # AK, AQ offsuit (still strong)
        if (sorted([r1, r2]) == [13, 14]) or \
           (sorted([r1, r2]) == [12, 14]):
           return True
        
        return False

    def _is_medium_preflop_hand(self, hole_cards: List[str]) -> bool:
        if not hole_cards or len(hole_cards) < 2:
            return False

        c1_rank = hole_cards[0][:-1]
        c2_rank = hole_cards[1][:-1]
        c1_suit = hole_cards[0][-1]
        c2_suit = hole_cards[1][-1]

        def card_to_int_rank(rank_str):
            if rank_str.isdigit(): return int(rank_str)
            return {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank_str]

        r1 = card_to_int_rank(c1_rank)
        r2 = card_to_int_rank(c2_rank)

        is_suited = (c1_suit == c2_suit)

        # Medium pairs (77-TT)
        if r1 == r2 and r1 >= 7 and r1 <= 10:
            return True
        # Suited connectors (e.g., 89s, TJs, QJs, KQs)
        if is_suited and abs(r1 - r2) == 1 and max(r1, r2) >= 8: # 78s+, suited broadways
            return True
        # Broadway cards (unsuited high cards)
        if max(r1, r2) >= 10 and min(r1, r2) >= 8: # e.g., KQo, QJo, KTo, JTo (not covered by premium or suited)
             return True
        # Suited Aces (A2s - ATs)
        if is_suited and (r1 == 14 or r2 == 14) and min(r1,r2) >= 2 and min(r1,r2) <= 9: # A2s-A9s
            return True

        return False

    def _has_strong_draw(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 4: # Need at least 4 cards (2 hole, 2 community) for a possible draw
            return False

        # Check for Flush Draw (4 cards of same suit)
        suits = [card[-1] for card in all_cards]
        for suit in ['c', 'd', 'h', 's']:
            if suits.count(suit) >= 4:
                return True # Open-ended flush draw

        # Check for Open-Ended Straight Draw (e.g., 5-6-7-8, needs a 4 or 9)
        # Or Gutshot Straight Draw (e.g., 5-7-8-9, needs a 6)
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        rank_values = sorted(list(set([ranks.index(card[:-1]) for card in all_cards])))

        # Simulate adding potential cards to check for straight
        # For simplicity, focus on open-ended straight draws
        for i in range(len(rank_values) - 3):
            sub_ranks = rank_values[i:i+4]
            # Check for sequential ranks with one gap or two ends open
            # Example: [5,6,7,8] - needs 4 or 9
            # Example: [5,7,8,9] - needs 6 (gutshot, not as strong)
            
            # Simple check for a 4-card sequence where a 5-card straight is possible
            # Check if 4 cards are consecutive
            if (sub_ranks[1] == sub_ranks[0] + 1 and
                sub_ranks[2] == sub_ranks[1] + 1 and
                sub_ranks[3] == sub_ranks[2] + 1):
                return True # Open-ended straight draw possibilities

            # Check for gutshot, A-5 straight draws, etc. (can be more complex)
            # For iteration 4, just basic open-ended straight draw detection or strong gutshots.
            # Example for gutshot: check if 3 consecutive + 1 card makes a draw (e.g. 5,7,8,9 -> need 6)
            # Simplified: check for sequences of 4 where a straight can be completed.
            gaps = [sub_ranks[j+1] - sub_ranks[j] for j in range(3)]
            if sum(gaps) <= 4 and max(gaps) <= 2: # e.g. 1,1,1 (open ended), 1,1,2 (gutshot)
                return True
            
        return False


from enum import Enum

class HandRank(Enum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9