from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class HandRank(Enum):
    HIGH_CARD = 1
    ONE_PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9
    ROYAL_FLUSH = 10

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_my_hole_cards(round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        
        # If we are already all-in, no action is needed
        if remaining_chips + my_bet_in_round <= round_state.current_bet and remaining_chips == 0:
            return PokerAction.CHECK, 0 # Or some default action if no action is truly needed

        # Determine hand strength
        hand_strength, _ = self._evaluate_hand(self.hole_cards, round_state.community_cards)

        num_active_players = len(round_state.current_player)

        # Pre-flop strategy
        if round_state.round == PokerRound.PREFLOP.name:
            if num_active_players <= 2:  # Heads-up or very few players
                if hand_strength >= HandRank.ONE_PAIR:
                    return self._aggressive_action(round_state, remaining_chips, amount_to_call)
                elif self._is_suited_connector(self.hole_cards) or self._is_high_card_hand(self.hole_cards):
                    if amount_to_call <= self.blind_amount * 2: # Call small raises with speculative hands
                        return PokerAction.CALL, amount_to_call
                    else:
                        return PokerAction.FOLD, 0
                else:
                    if amount_to_call == 0: # Check if possible
                        return PokerAction.CHECK, 0
                    elif amount_to_call < remaining_chips / 10: # Call small bets
                        return PokerAction.CALL, amount_to_call
                    else:
                        return PokerAction.FOLD, 0
            else: # Multi-way pot
                if hand_strength >= HandRank.ONE_PAIR:
                    return self._aggressive_action(round_state, remaining_chips, amount_to_call) # Value bet strong hands
                elif self._is_premium_starting_hand(self.hole_cards): # Premium starting hands (AA, KK, QQ, AKs)
                    return self._aggressive_action(round_state, remaining_chips, amount_to_call)
                else:
                    if amount_to_call == 0:
                        return PokerAction.CHECK, 0
                    elif amount_to_call < self.blind_amount: # Call small blinds
                        return PokerAction.CALL, amount_to_call
                    else:
                        return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            if hand_strength >= HandRank.ONE_PAIR:
                # Strong hand, bet for value, or call if already a big bet
                return self._aggressive_action(round_state, remaining_chips, amount_to_call)
            elif self._has_draw_potential(self.hole_cards, round_state.community_cards):
                # Draw hand, call small to see next card, or semi-bluff if no one bet big
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call < remaining_chips / 5:
                    # Implement a small raise for semi-bluffing, especially on turn/river
                    if random.random() < 0.2 and round_state.round != PokerRound.RIVER.name: # Semi-bluff 20% of the time, not on river
                       raise_amount = min(round_state.min_raise, remaining_chips)
                       if raise_amount > 0:
                           return PokerAction.RAISE, raise_amount
                    return PokerAction.CALL, amount_to_call
                else:
                    return PokerAction.FOLD, 0
            else:
                # Weak hand, fold unless we can check for free
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def _aggressive_action(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int) -> Tuple[PokerAction, int]:
        """
        Helper function for aggressive actions (raise/all-in).
        """
        if amount_to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0
        
        # Consider the number of active players and pot size when determining raise amount
        # Small pot, less players -> bigger raise relative to pot
        # Big pot, more players -> smaller raise relative to pot
        pot_size = round_state.pot + sum(round_state.player_bets.values()) # Estimate total current pot
        
        # Calculate a raise amount, aiming for 50-75% of the pot often, but respect min_raise
        raise_amount_option1 = int(pot_size * 0.6) # 60% pot bet
        raise_amount_option2 = round_state.min_raise * 2 # Or 2x min raise
        
        # Choose a reasonable raise amount, ensuring it's at least min_raise and within stack limits
        target_raise = max(round_state.min_raise, raise_amount_option1, raise_amount_option2)
        
        # Ensure the raise is valid:
        # 1. Total bet (current_bet_in_round + raise_amount) must be at least min_raise over round.current_bet
        # 2. Cannot raise more than remaining_chips
        
        # My current bet in the round
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # How much I need to pay to match the current bet
        amount_to_match = round_state.current_bet - my_current_bet
        
        # The amount I want to add on top of matching (the actual "raise" portion)
        # This raise portion must be at least round_state.min_raise
        
        calculated_raise_portion = target_raise # This is an ideal raise size on top of the call
        
        # Ensure the calculated_raise_portion meets the minimum raise requirement
        if round_state.current_bet > 0: # If there's an existing bet to raise over
            # The new total bet must be >= (current_bet_to_match + min_raise_amount) effectively
            # The 'raise' value passed with PokerAction.RAISE is the TOTAL bet.
            # No, the PokerAction.RAISE value is the *additional* amount to RAISE ON TOP of what is needed to CALL.
            # Example: Current bet is 100. I have bet 0. I call 100.
            # If I want to raise 100 more, total bet becomes 200. The raise value is 100.
            
            # The amount that will be my *new total bet* if I raise this amount
            proposed_total_bet_after_raise = round_state.current_bet + calculated_raise_portion
            
            # Check if this proposed total bet is valid as a raise
            # The new bet must be at least the current bet + min_raise
            min_valid_total_bet = round_state.current_bet + round_state.min_raise
            
            if proposed_total_bet_after_raise < min_valid_total_bet:
                calculated_raise_portion = min_valid_total_bet - round_state.current_bet

        # Ensure we don't bet more than we have
        actual_raise_amount = min(calculated_raise_portion, remaining_chips - amount_to_match)
        
        # If the actual raise plus the amount to call would put us all-in
        if amount_to_match + actual_raise_amount >= remaining_chips:
            return PokerAction.ALL_IN, 0
        elif actual_raise_amount > 0: # Only raise if we can actually make a raise
            # Need to ensure the amount passed with RAISE is the additional amount *on top of* the current bet.
            # The competition rules state: "For RAISE: the amount raise combine with your current bet must be larger than the the current raise."
            # This implies the amount for RAISE is the actual *raise amount* on top of the call, not the total bet.
            # Let's re-read: "minimum bet is 2x current call amount". This means the *new total bet* must be 2x the current bet.
            # This is confusing. Let's assume RAISE amount is the final bet amount.
            # "For RAISE: the amount raise combine with your current bet must be larger than the the current raise."
            # This implies that the 'RAISE' value is the *new total amount you are betting in the round*.
            
            # Let's adjust to this interpretation.
            # `target_raise` is the amount we want our *total bet* to be *in this round*.
            # It must be at least `round_state.current_bet + round_state.min_raise`
            
            proposed_total_bet = max(round_state.current_bet + round_state.min_raise, target_raise)
            
            # Ensure it's not more than we have
            proposed_total_bet = min(proposed_total_bet, remaining_chips + my_current_bet)
            
            # The actual value to return for RAISE is this total bet amount
            
            # But the documentation for `get_action` says `Tuple[PokerAction, int]`, where int is the `amount`
            # For `RAISE`, the amount is the `combine with your current bet`.
            # This literally means it's my total bet for the round if I choose to raise.
            # So, if current_bet is 100, my_bet_in_round is 0, min_raise is 100 (so minimum raise to 200).
            # If I want to raise 150 (making total bet 250), I return `RAISE, 250`.
            
            final_raise_amount = proposed_total_bet
            
            # Ensure the raise is valid compared to `round_state.current_bet`
            # The new total bet must be >= round_state.current_bet + round_state.min_raise
            if final_raise_amount < round_state.current_bet + round_state.min_raise:
                final_raise_amount = round_state.current_bet + round_state.min_raise
            
            # Don't bet more than we have
            final_raise_amount = min(final_raise_amount, remaining_chips + my_bet_in_round)
            
            # If after all this, the final_raise_amount is effectively just a call, then call
            if final_raise_amount <= round_state.current_bet:
                if amount_to_call > 0:
                    return PokerAction.CALL, amount_to_call
                else: # current_bet is 0, so CHECK
                    return PokerAction.CHECK, 0
            
            return PokerAction.RAISE, final_raise_amount

        elif amount_to_call > 0:
            return PokerAction.CALL, amount_to_call
        else:
            return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_my_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        # The hole cards are not directly in round_state for the current player
        # They are usually passed in on_start and on_round_start or kept in self.hole_cards.
        # Assuming `on_round_start` updates `self.hole_cards` correctly.
        return self.hole_cards

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[HandRank, List[str]]:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2:  # Need at least 2 cards to form a hand (minimum 2 hole cards)
            return HandRank.HIGH_CARD, []
        
        # Parse cards into (rank, suit) tuples
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) == 2:
                rank_str, suit = card_str[0], card_str[1]
            else:  # e.g., '10h'
                rank_str, suit = card_str[:2], card_str[2]

            if rank_str == 'T':
                rank = 10
            elif rank_str == 'J':
                rank = 11
            elif rank_str == 'Q':
                rank = 12
            elif rank_str == 'K':
                rank = 13
            elif rank_str == 'A':
                rank = 14  # Ace is high for evaluating straights/high cards
            else:
                rank = int(rank_str)
            parsed_cards.append((rank, suit))

        parsed_cards.sort(key=lambda x: x[0], reverse=True)

        # Helper functions for hand evaluation
        def _get_rank_counts(cards):
            counts = {}
            for rank, _ in cards:
                counts[rank] = counts.get(rank, 0) + 1
            return counts

        def _get_suit_counts(cards):
            counts = {}
            for _, suit in cards:
                counts[suit] = counts.get(suit, 0) + 1
            return counts
        
        def _has_straight(cards):
            unique_ranks = sorted(list(set([c[0] for c in cards])))
            # Handle Ace as low (for A2345 straight)
            if 14 in unique_ranks:
                unique_ranks.insert(0, 1) # Add Ace as 1
                
            unique_ranks = sorted(list(set(unique_ranks))) # Remove duplicates after adding 1

            if len(unique_ranks) < 5:
                return False, []

            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] == unique_ranks[i] + 4:
                    return True, [unique_ranks[i+4]] # Return the highest card of the straight

            return False, []

        def _has_flush(cards):
            suit_counts = _get_suit_counts(cards)
            for suit, count in suit_counts.items():
                if count >= 5:
                    flush_cards = sorted([c for c in cards if c[1] == suit], key=lambda x: x[0], reverse=True)[:5]
                    return True, flush_cards
            return False, []
        
        # Check for Royal Flush, Straight Flush
        if _has_flush(parsed_cards)[0]:
            flush_suit = _has_flush(parsed_cards)[1][0][1] # Get suit of flush
            flush_cards = [c for c in parsed_cards if c[1] == flush_suit]
            straight_flush, straight_high_card = _has_straight(flush_cards)
            if straight_flush and straight_high_card[0] == 14: # Ace high straight
                return HandRank.ROYAL_FLUSH, sorted(flush_cards, key=lambda x: x[0], reverse=True)[:5]
            if straight_flush:
                return HandRank.STRAIGHT_FLUSH, sorted(flush_cards, key=lambda x: x[0], reverse=True)[:5]

        # Check for Four of a Kind, Full House
        rank_counts = _get_rank_counts(parsed_cards)
        pairs = {rank: count for rank, count in rank_counts.items() if count == 2}
        trips = {rank: count for rank, count in rank_counts.items() if count == 3}
        quads = {rank: count for rank, count in rank_counts.items() if count == 4}

        if quads:
            quad_rank = max(quads.keys())
            kicker = next((c[0] for c in parsed_cards if c[0] != quad_rank), None)
            return HandRank.FOUR_OF_A_KIND, [quad_rank] + ([kicker] if kicker else []) # Kicker can be any high card

        if trips and pairs:
            trip_rank = max(trips.keys())
            pair_rank = max(pairs.keys())
            return HandRank.FULL_HOUSE, [trip_rank, pair_rank]
        
        if len(trips) >= 2: # Two sets of trips, use the higher trip and higher pair from remaining cards
            sorted_trips = sorted(trips.keys(), reverse=True)
            trip_rank = sorted_trips[0]
            pair_rank = sorted_trips[1] # Use the second trip as a pair
            return HandRank.FULL_HOUSE, [trip_rank, pair_rank]


        # Check for Flush
        if _has_flush(parsed_cards)[0]:
            return HandRank.FLUSH, _has_flush(parsed_cards)[1]

        # Check for Straight
        straight_found, straight_high_card = _has_straight(parsed_cards)
        if straight_found:
            return HandRank.STRAIGHT, straight_high_card # Returns just the high card rank for the straight

        # Check for Three of a Kind
        if trips:
            trip_rank = max(trips.keys())
            kickers = sorted([c[0] for c in parsed_cards if c[0] != trip_rank], reverse=True)[:2]
            return HandRank.THREE_OF_A_KIND, [trip_rank] + kickers

        # Check for Two Pair
        if len(pairs) >= 2:
            sorted_pairs = sorted(pairs.keys(), reverse=True)[:2]
            kicker = next((c[0] for c in parsed_cards if c[0] not in sorted_pairs), None)
            return HandRank.TWO_PAIR, sorted_pairs + ([kicker] if kicker else [])

        # Check for One Pair
        if pairs:
            pair_rank = max(pairs.keys())
            kickers = sorted([c[0] for c in parsed_cards if c[0] != pair_rank], reverse=True)[:3]
            return HandRank.ONE_PAIR, [pair_rank] + kickers

        # High Card
        return HandRank.HIGH_CARD, sorted([c[0] for c in parsed_cards], reverse=True)[:5]

    def _is_premium_starting_hand(self, hole_cards: List[str]) -> bool:
        """
        Evaluates if the hole cards are a premium starting hand (pairs of J+ or AKs/AKo).
        """
        if len(hole_cards) < 2:
            return False

        card1_rank_str, card1_suit = (hole_cards[0][0], hole_cards[0][1]) if len(hole_cards[0]) == 2 else (hole_cards[0][:2], hole_cards[0][2])
        card2_rank_str, card2_suit = (hole_cards[1][0], hole_cards[1][1]) if len(hole_cards[1]) == 2 else (hole_cards[1][:2], hole_cards[1][2])

        def _get_rank_val(rank_str):
            if rank_str == 'T': return 10
            if rank_str == 'J': return 11
            if rank_str == 'Q': return 12
            if rank_str == 'K': return 13
            if rank_str == 'A': return 14
            return int(rank_str)

        rank1 = _get_rank_val(card1_rank_str)
        rank2 = _get_rank_val(card2_rank_str)
        
        # Pocket pairs J+
        if rank1 == rank2 and rank1 >= 11: # JJ, QQ, KK, AA
            return True
        
        # AK suited or off-suit
        if (rank1 == 14 and rank2 == 13) or (rank1 == 13 and rank2 == 14): # AK
            return True

        return False

    def _is_suited_connector(self, hole_cards: List[str]) -> bool:
        """
        Checks for suited connectors (e.g., 7h8h, JTs).
        """
        if len(hole_cards) < 2:
            return False

        card1_rank_str, card1_suit = (hole_cards[0][0], hole_cards[0][1]) if len(hole_cards[0]) == 2 else (hole_cards[0][:2], hole_cards[0][2])
        card2_rank_str, card2_suit = (hole_cards[1][0], hole_cards[1][1]) if len(hole_cards[1]) == 2 else (hole_cards[1][:2], hole_cards[1][2])

        def _get_rank_val(rank_str):
            if rank_str == 'T': return 10
            if rank_str == 'J': return 11
            if rank_str == 'Q': return 12
            if rank_str == 'K': return 13
            if rank_str == 'A': return 14
            return int(rank_str)

        rank1 = _get_rank_val(card1_rank_str)
        rank2 = _get_rank_val(card2_rank_str)
        
        if card1_suit == card2_suit and abs(rank1 - rank2) == 1 and rank1 <= 12 and rank2 <= 12: # Suited connectors, excluding AKs
            return True
        
        return False

    def _is_high_card_hand(self, hole_cards: List[str]) -> bool:
        """
        Checks if the hand has high cards (e.g., AT, KJ, Q9).
        """
        if len(hole_cards) < 2:
            return False

        card1_rank_str, _ = (hole_cards[0][0], hole_cards[0][1]) if len(hole_cards[0]) == 2 else (hole_cards[0][:2], hole_cards[0][2])
        card2_rank_str, _ = (hole_cards[1][0], hole_cards[1][1]) if len(hole_cards[1]) == 2 else (hole_cards[1][:2], hole_cards[1][2])

        def _get_rank_val(rank_str):
            if rank_str == 'T': return 10
            if rank_str == 'J': return 11
            if rank_str == 'Q': return 12
            if rank_str == 'K': return 13
            if rank_str == 'A': return 14
            return int(rank_str)

        rank1 = _get_rank_val(card1_rank_str)
        rank2 = _get_rank_val(card2_rank_str)
        
        if rank1 >= 10 or rank2 >= 10: # At least one card is 10 or higher
            return True
        
        return False
    
    def _has_draw_potential(self, hole_cards: List[str], community_cards: List[str]) -> bool:
        """
        Checks for flush draws or open-ended straight draws.
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 3: # Need at least flop to have draw potential
            return False

        # Flush draw check
        suit_counts = {}
        for card_str in all_cards:
            suit = card_str[-1]
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        for suit, count in suit_counts.items():
            if count >= 4: # Flush draw (4 cards of same suit)
                return True

        # Straight draw check (open-ended)
        parsed_cards = []
        for card_str in all_cards:
            if len(card_str) == 2:
                rank_str = card_str[0]
            else:
                rank_str = card_str[:2]

            if rank_str == 'T': rank = 10
            elif rank_str == 'J': rank = 11
            elif rank_str == 'Q': rank = 12
            elif rank_str == 'K': rank = 13
            elif rank_str == 'A': rank = 14
            else: rank = int(rank_str)
            parsed_cards.append(rank)

        unique_ranks = sorted(list(set(parsed_cards)))
        
        # Add Ace as 1 for A2345 straight consideration
        if 14 in unique_ranks:
            unique_ranks.insert(0, 1)
        unique_ranks = sorted(list(set(unique_ranks))) # Re-sort after adding 1, and remove potential duplicates

        if len(unique_ranks) < 4: # Need at least 4 unique ranks for an open-ended straight draw
            return False

        for i in range(len(unique_ranks) - 3):
            # Check for open-ended straight draw: four consecutive ranks
            if unique_ranks[i+3] == unique_ranks[i] + 3:
                return True
        
        return False