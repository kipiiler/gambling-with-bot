import random
from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.num_players_start_round = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands 
        self.blind_amount = blind_amount
        # Note: big_blind_player_id and small_blind_player_id are not part of RoundStateClient
        # and are only passed in on_start. We should not try to access them from round_state in get_action.
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.player_id)] if hasattr(round_state, 'player_hands') else []
        self.num_players_start_round = len(round_state.current_player)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.player_id), 0)
        
        # Calculate pot odds for calling
        if round_state.pot > 0:
            pot_odds_call = current_bet_to_match / (round_state.pot + current_bet_to_match + 1e-9)
        else:
            pot_odds_call = 1.0 # Effectively infinite odds against, or 0 if current_bet_to_match is 0

        # Estimate hand strength (very simple for now)
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards, self.num_players_start_round)

        # Basic strategy:
        # 1. Pre-flop: Aggressive with strong hands, cautious with weak hands.
        # 2. Post-flop: Consider hand strength, pot size, and opponent actions.
        # 3. Adjust based on number of players.

        num_active_players = len(round_state.current_player)
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Premium hands
            if hand_strength > 0.8: # e.g., AA, KK, QQ, AKs
                if current_bet_to_match == 0: # First to act or no raise yet
                    return PokerAction.RAISE, min(remaining_chips, round_state.min_raise * 3)
                elif current_bet_to_match < remaining_chips * 0.2: # Re-raise if not too expensive
                    return PokerAction.RAISE, min(remaining_chips, current_bet_to_match + round_state.min_raise * 2)
                else: # Call a large bet or go all-in if very strong
                    return PokerAction.ALL_IN if current_bet_to_match >= remaining_chips * 0.7 else PokerAction.CALL
            # Medium hands
            elif hand_strength > 0.6: # e.g., JJ, TT, AQs, KQs
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, min(remaining_chips, round_state.min_raise * 2)
                elif current_bet_to_match < remaining_chips * 0.1 and pot_odds_call < 0.3: # Call small raises if pot odds are good
                    return PokerAction.CALL
                else:
                    return PokerAction.FOLD
            # Speculative hands
            elif hand_strength > 0.4 and num_active_players > 2 and current_bet_to_match <= self.blind_amount: # Call small blinds with speculative hands in multi-way pots
                return PokerAction.CALL
            # Weak hands
            else:
                if current_bet_to_match == 0: # Check if possible, otherwise fold
                    return PokerAction.CHECK
                else:
                    return PokerAction.FOLD
        
        # Post-flop strategy (Flop, Turn, River)
        else:
            bet_factor = 0.0
            if hand_strength > 0.9: # Very strong hand (e.g., Flush, Straight, Two Pair+)
                bet_factor = 0.7
            elif hand_strength > 0.7: # Strong hand (e.g., Top Pair, Overpair)
                bet_factor = 0.5
            elif hand_strength > 0.5: # Medium hand (e.g., Middle Pair, Good Draw)
                bet_factor = 0.3
            elif hand_strength > 0.2: # Weak hand but might improve (e.g., Gutshot, Small Pair)
                bet_factor = 0.0 # Check or Call with good odds
            
            if current_bet_to_match > 0: # Opponent has bet
                # Consider calling if pot odds are good or hand is strong enough
                # Adjust required pot odds based on hand strength: stronger hand needs lower pot_odds_call
                required_pot_odds = 0.2 if hand_strength > 0.7 else (0.35 if hand_strength > 0.5 else 0.5)

                if current_bet_to_match >= remaining_chips: # If facing an all-in
                    if hand_strength > 0.7 or (hand_strength > 0.5 and pot_odds_call < 0.4):
                        return PokerAction.ALL_IN
                    else:
                        return PokerAction.FOLD
                elif pot_odds_call < required_pot_odds and hand_strength > 0.2: # Call if odds are good and not a completely garbage hand
                    return PokerAction.CALL
                elif hand_strength > 0.8 and num_active_players > 1: # Re-raise with very strong hands
                    raise_amount = int(round_state.pot * bet_factor)
                    return PokerAction.RAISE, max(round_state.min_raise, min(remaining_chips, raise_amount))
                else:
                    return PokerAction.FOLD
            else: # No bet, player can check or bet
                if hand_strength > 0.6: # Bet with strong hands
                    bet_amount = int(round_state.pot * bet_factor)
                    actual_bet_amount = max(round_state.min_raise, bet_amount)
                    
                    if actual_bet_amount > remaining_chips:
                        return PokerAction.ALL_IN
                    elif actual_bet_amount + round_state.player_bets.get(str(self.player_id), 0) > round_state.current_bet + round_state.min_raise:
                        return PokerAction.RAISE, actual_bet_amount
                    else:
                        # If calculated bet is less than min_raise, just check if possible, or min_raise
                        if remaining_chips >= round_state.min_raise:
                            return PokerAction.RAISE, round_state.min_raise
                        else:
                            return PokerAction.CHECK if current_bet_to_match == 0 else PokerAction.FOLD # should be check, and it's 0 if no bet.
                else: # Check with medium to weak hands
                    return PokerAction.CHECK

        # Default action if nothing else applies
        if current_bet_to_match == 0:
            return PokerAction.CHECK
        elif current_bet_to_match < remaining_chips and pot_odds_call < 0.4: # Call if current bet is small relative to pot
            return PokerAction.CALL
        else:
            return PokerAction.FOLD
            
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str], num_players: int) -> float:
        """
        Estimates hand strength based on a very simplified heuristic.
        A more robust implementation would use Monte Carlo simulations or pre-computed equities.
        For now, this is a basic card strength evaluation.
        Returns a float between 0.0 (weakest) and 1.0 (strongest).
        """
        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0.0

        # Rank mapping for easier comparison (A=14, K=13, Q=12, J=11, T=10)
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        ranks = sorted([rank_map[card[0]] for card in all_cards], reverse=True)
        suits = [card[1] for card in all_cards]

        # Simple high card-based pre-flop strength (just hole cards)
        if not community_cards and len(hole_cards) == 2:
            card1_rank = rank_map[hole_cards[0][0]]
            card2_rank = rank_map[hole_cards[1][0]]
            is_suited = (hole_cards[0][1] == hole_cards[1][1])
            is_paired = (card1_rank == card2_rank)

            if is_paired:
                if card1_rank >= 12: return 0.9 # AA, KK, QQ
                if card1_rank >= 9: return 0.75 # JJ, TT
                return 0.6 # Other pairs
            if card1_rank >= 12 and card2_rank >= 10: return 0.85 # AK, AQ, AJ, KQ
            if card1_rank >= 10 and is_suited: return 0.7 # Suited connectors/high cards
            if max(card1_rank, card2_rank) >= 10 and abs(card1_rank - card2_rank) <= 2: return 0.65 # Connectors like T9s
            return 0.3 # Default weak
        
        # Post-flop basic hand evaluation (more community cards)
        # This is very rudimentary and far from a full poker hand evaluator
        
        strength = 0.0
        
        # Check for pairs
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        pairs = 0
        trips = 0
        quads = 0
        
        for r, count in rank_counts.items():
            if count == 2: pairs += 1
            if count == 3: trips += 1
            if count == 4: quads += 1

        if quads: strength = max(strength, 0.99)
        elif trips and pairs: strength = max(strength, 0.95) # Full House
        elif pairs >= 2: strength = max(strength, 0.85) # Two Pair
        elif trips: strength = max(strength, 0.80) # Three of a kind
        elif pairs == 1: strength = max(strength, 0.70) # One Pair
        
        # Check for flushes (not perfect, just counts suits)
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
        
        if any(count >= 5 for count in suit_counts.values()):
            strength = max(strength, 0.90) # Flush
            
        # Check for straights (very basic, doesn't handle all cases)
        unique_ranks = sorted(list(set(ranks)))
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    strength = max(strength, 0.88) # Straight

        # Add a small randomness factor to make actions less predictable
        strength += random.uniform(-0.05, 0.05) if strength < 0.9 else 0
        strength = max(0.01, min(0.99, strength)) # Keep within bounds

        # Adjust strength based on number of players (tighter with more players)
        if num_players > 2:
            strength -= (num_players - 2) * 0.05
        strength = max(0.01, strength)

        return strength

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards for the next round
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass