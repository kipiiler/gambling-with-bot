from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.hand_strength_preflop_thresholds = {
            # Premium hands
            'AA': 0.85, 'KK': 0.82, 'QQ': 0.79, 'AKs': 0.78, 'AQs': 0.75,
            'JJ': 0.76, 'TT': 0.72, 'AKo': 0.70, 'KQs': 0.68,
            # Strong hands
            '99': 0.65, '88': 0.60, 'AQo': 0.62, 'KJs': 0.60, 'QJs': 0.58,
            'AJs': 0.55, 'ATs': 0.53, 'KQo': 0.5
        }
        self.hand_strength_postflop_thresholds = {
            PokerRound.FLOP: 0.5,
            PokerRound.TURN: 0.6,
            PokerRound.RIVER: 0.7
        }
        self.card_rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.num_opponents = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.hole_cards = player_hands 
        # Calculate number of opponents
        self.num_opponents = len(all_players) - 1 if self.id in all_players else len(all_players)


    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_my_hole_cards(round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet_in_round
        
        # Ensure remaining_chips is updated for the current action
        # This is crucial if we made an action in a previous street in the same hand
        current_chips = remaining_chips - my_bet_in_round # The chips effectively available for new bets/raises

        can_check = amount_to_call == 0

        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic strategy based on hand strength and round
        current_round_enum = self._get_poker_round_enum(round_state.round)

        if current_round_enum == PokerRound.PREFLOP:
            return self._handle_preflop(hand_strength, amount_to_call, can_check, current_chips, round_state)
        else:
            return self._handle_postflop(hand_strength, amount_to_call, can_check, current_chips, current_round_enum, round_state)
    
    def _handle_preflop(self, hand_strength: float, amount_to_call: int, can_check: bool, current_chips: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        # Simple pre-flop strategy:
        # 1. Premium hands (AA, KK, QQ, AKs): Aggressively raise
        # 2. Strong hands (JJ, TT, AQs, KQs, etc.): Call or small raise
        # 3. MediumHands: Call if pot odds are good, otherwise fold
        # 4. Weak hands: Fold

        # Map hole cards to a standardized key for preflop strength
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        suit1, suit2 = card1[1], card2[1]
        rank1, rank2 = card1[0], card2[0]

        if self.card_rank_map[rank1] < self.card_rank_map[rank2]:
            rank1, rank2 = rank2, rank1
            card1, card2 = card2, card1 # swap if not sorted
        
        hand_key = f"{rank1}{rank2}"
        if suit1 == suit2:
            hand_key += 's'
        elif rank1 != rank2:
            hand_key += 'o'

        threshold = self.hand_strength_preflop_thresholds.get(hand_key, 0.45) # Default for weaker hands

        num_active_players = len(round_state.current_player)

        # Adjust threshold based on number of opponents
        if num_active_players < 4: # Heads-up or 3-handed, play tighter
            threshold += 0.05
        else: # Multi-way, play looser with strong hands
            threshold -= 0.05

        current_bet_val = round_state.current_bet
        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max_raise
        
        # Aggressive play for strong hands
        if hand_strength >= threshold * 1.2: # Premium hands
            if amount_to_call == 0: # Option to check/bet
                return PokerAction.RAISE, self._get_raise_amount_aggressive(min_raise_amount, max_raise_amount, current_chips, round_state)
            elif amount_to_call < current_chips: # Can call or raise
                if min_raise_amount > current_chips - amount_to_call: # Cannot make min raise
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, self._get_raise_amount_aggressive(min_raise_amount, max_raise_amount, current_chips + my_bet_in_round, round_state)
            else: # All-in to call
                return PokerAction.ALL_IN, 0
        
        # Moderate play for medium hands
        elif hand_strength >= threshold:
            if amount_to_call == 0: # Check before betting
                return PokerAction.CHECK, 0
            elif amount_to_call <= current_chips / 2: # Call if not too expensive
                return PokerAction.CALL, 0
            else: # Expensive call, consider fold
                return PokerAction.FOLD, 0
        
        # Weak hands or marginal situations
        else:
            if can_check:
                return PokerAction.CHECK, 0
            elif amount_to_call < current_chips and amount_to_call <= 0.1 * self.starting_chips: # Call small bets
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _handle_postflop(self, hand_strength: float, amount_to_call: int, can_check: bool, current_chips: int, current_round_enum: PokerRound, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        
        threshold = self.hand_strength_postflop_thresholds.get(current_round_enum, 0.5)
        num_active_players = len(round_state.current_player)

        # Adjust threshold based on number of active players
        if num_active_players <= 2: # Heads-up
            threshold -= 0.05 
        else: # Multi-way
            threshold += 0.05

        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max_raise
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)

        # Aggressively bet/raise with strong hands
        if hand_strength >= threshold + 0.1: # Strong hand
            if amount_to_call == 0:
                raise_amount = self._get_raise_amount_aggressive(min_raise_amount, max_raise_amount, current_chips, round_state)
                return PokerAction.RAISE, raise_amount
            elif amount_to_call < current_chips:
                # If already facing a bet, consider re-raising
                if min_raise_amount > current_chips - amount_to_call: # Cannot make min raise
                    return PokerAction.ALL_IN, 0
                raise_amount = self._get_raise_amount_aggressive(min_raise_amount, max_raise_amount, current_chips + my_bet_in_round, round_state)
                return PokerAction.RAISE, raise_amount
            else:
                return PokerAction.ALL_IN, 0

        # Call with medium hands or if pot odds are good
        elif hand_strength >= threshold: # Medium hand
            if can_check:
                return PokerAction.CHECK, 0
            
            # Calculate pot odds for calling
            pot = round_state.pot
            # If current_bet is just my current bet, it means others have folded to me or haven't acted yet.
            # Else current_bet is the bet I need to match (amount_to_call is correct).
            
            # The pot after I call
            if amount_to_call > 0:
                pot_after_call = pot + amount_to_call
                pot_odds = amount_to_call / (pot_after_call + 1e-9) # Add epsilon to prevent division by zero
            else:
                pot_odds = 0 # No bet to call, so pot odds not relevant for calling decision

            # If pot odds are good (e.g., I need to risk less than 20% of the pot to call)
            # This is a simplification; ideally, pot odds should be compared to implied odds
            if amount_to_call <= current_chips / 3 or (current_round_enum == PokerRound.RIVER and hand_strength > 0.5):
                return PokerAction.CALL, 0
            
            # Small re-raise if confident with good pot odds and deep stack
            if hand_strength >= threshold + 0.05 and current_chips > 2 * amount_to_call and amount_to_call > 0:
                if min_raise_amount > current_chips - amount_to_call: # Cannot make min raise
                    return PokerAction.CALL, 0 # Fallback to call if cannot make minimum raise
                raise_amount = min(max_raise_amount, amount_to_call + min_raise_amount)
                return PokerAction.RAISE, raise_amount


            return PokerAction.FOLD, 0 # Even with a medium hand, fold if bet is too large

        # Fold with weak hands
        else: # Weak hand
            if can_check:
                return PokerAction.CHECK, 0
            elif amount_to_call < current_chips and amount_to_call <= self.blind_amount: # Call small bets
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0


    def _get_raise_amount_aggressive(self, min_raise: int, max_raise: int, current_chips: int, round_state: RoundStateClient) -> int:
        # Raise 2.5x to 3x the current bet, or a significant portion of the pot
        current_bet = round_state.current_bet
        pot = round_state.pot

        # Try to raise 2.5x current bet or 0.7x pot size
        # Ensure the raise is at least min_raise
        
        # Calculate target_raise_amount based on a multiplier of the current bet
        # The amount to add on top of current_bet to form the new total bet
        raise_delta = max(min_raise, current_bet * 2 if current_bet > 0 else self.blind_amount * 2) 
        
        # Calculate a pot-based raise amount (total bet to poker.py)
        pot_raise_amount = int(pot * 0.75) 

        # Combine strategies: use a mix of bet-based and pot-based raises
        # Prioritize keeping opponents honest but don't overcommit
        if current_bet == 0 and pot == 0: # If first to act preflop
            raise_val = max(min_raise, self.blind_amount * 3) # 3BB open raise
        elif current_bet == 0: # First to act postflop
            raise_val = max(min_raise, int(pot * 0.5)) # Bet half pot
        else:
            raise_val = max(min_raise, current_bet * 2, pot_raise_amount)

        # The raise amount returned is the *new total bet*, not the difference
        # poker.py will interpret this as current_bet + raise_amount_you_passed_back - my_bet_in_round
        # So we need to calculate the total bet correctly
        my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        total_bet_for_raise = my_bet_in_round + raise_val
        
        # Clamp between min_raise and max_raise (effectively all_in)
        # min_raise in RoundStateClient is the minimum extra amount you need to put in to make a valid raise.
        # So the NEW_TOTAL_BET must be at least current_bet + min_raise.
        
        # If calling requires us to go all-in anyway due to current_chips, just do that
        if total_bet_for_raise >= current_chips + my_bet_in_round:
            return current_chips + my_bet_in_round # All-in

        # Ensure raise is at least the minimum required to be a "raise"
        # The total amount committed must be at least current_bet + min_raise
        valid_total_bet = max(round_state.current_bet + min_raise, total_bet_for_raise)
        
        # We need to make sure we don't bet more than we have
        valid_total_bet = min(valid_total_bet, current_chips + my_bet_in_round) # Clamp to all-in if needed

        return valid_total_bet
        

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_my_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        # The hole cards are passed in on_start and on_round_start.
        # This method is just a placeholder if you need to fetch them from round_state,
        # but typically they are part of the bot's internal state.
        # Assuming self.hole_cards is updated correctly in on_start/on_round_start
        return self.hole_cards

    def calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Estimates the strength of the player's hand given hole cards and community cards.
        This is a very simplified estimation. A real bot would run Monte Carlo simulations.
        Returns a float between 0.0 and 1.0.
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 2:
            return 0.0 # Cannot determine strength without at least 2 cards

        # Rank mapping for easier comparison
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        ranks = sorted([rank_map[card[0]] for card in all_cards], reverse=True)
        suits = [card[1] for card in all_cards]

        # Check for flushes (very basic)
        flush_possible = False
        if len(community_cards) >= 3:
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            for suit_count in suit_counts.values():
                if suit_count >= 5:
                    flush_possible = True
                    break

        # Check for straights (very basic)
        straight_possible = False
        if len(ranks) >= 5:
            unique_ranks = sorted(list(set(ranks)))
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    straight_possible = True
                    break
            # Check for A-5 straight (Ace low)
            if 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
                straight_possible = True

        # Check for pairs and higher combinations
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1

        pairs = 0
        three_of_a_kind = 0
        four_of_a_kind = 0
        for rank_count in rank_counts.values():
            if rank_count == 2:
                pairs += 1
            elif rank_count == 3:
                three_of_a_kind += 1
            elif rank_count == 4:
                four_of_a_kind += 1
        
        # Assign arbitrary strength values
        strength = 0.0
        if four_of_a_kind > 0:
            strength = 0.95
        elif three_of_a_kind > 0 and pairs > 0 or three_of_a_kind > 1: # Full house
            strength = 0.90
        elif flush_possible:
            strength = 0.80
        elif straight_possible:
            strength = 0.75
        elif three_of_a_kind > 0:
            strength = 0.70
        elif pairs >= 2:
            strength = 0.60
        elif pairs == 1:
            # High pair gets more strength
            highest_pair_rank = 0
            for rank, count in rank_counts.items():
                if count == 2:
                    highest_pair_rank = max(highest_pair_rank, rank)
            
            if highest_pair_rank >= rank_map['T']: # Ten or higher pair
                strength = 0.50
            else:
                strength = 0.40
        else: # High card
            strength = ranks[0] / 14.0 * 0.3 # Scale highest card rank

        # Pre-flop adjustments for hole cards
        if not community_cards:
            rank1 = rank_map[hole_cards[0][0]]
            rank2 = rank_map[hole_cards[1][0]]
            suit1 = hole_cards[0][1]
            suit2 = hole_cards[1][1]

            if rank1 == rank2: # Pocket pair
                strength = 0.40 + (rank1 - 2) / 12.0 * 0.55 # Scales from 22 (0.40) to AA (0.95)
            elif suit1 == suit2: # Suited connector/gapper
                strength = max(strength, (rank1 + rank2) / 28.0 * 0.3 + 0.1) # Boost for suited cards
                if abs(rank1 - rank2) <= 2: # Suited connectors
                     strength += 0.05
            elif abs(rank1 - rank2) == 1 and rank1 < 10 and rank2 < 10: # Small connectors
                strength += 0.05
            else: # Other hands
                strength = max(strength, (rank1 + rank2) / 28.0 * 0.2) # Basic high card, no pair
        
        # Add random noise to avoid predictable play (within a small range)
        strength += random.uniform(-0.02, 0.02)
        return min(max(0.0, strength), 1.0) # Clamp between 0 and 1

    def _get_poker_round_enum(self, round_name: str) -> PokerRound:
        if round_name == 'Preflop':
            return PokerRound.PREFLOP
        elif round_name == 'Flop':
            return PokerRound.FLOP
        elif round_name == 'Turn':
            return PokerRound.TURN
        elif round_name == 'River':
            return PokerRound.RIVER
        else:
            raise ValueError(f"Unknown poker round: {round_name}")