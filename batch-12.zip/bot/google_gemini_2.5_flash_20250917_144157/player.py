from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random

# Re-define PokerRound here since it was causing an import error
class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.is_small_blind = False
        self.is_big_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        # player_hands will only contain the bot's own hand at the start of the game
        # so we store it for later or just use the first element
        self.blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the current hand, they are given in player_hands
        # but the on_start method only provides it once for the entire game, this needs dynamic updating.
        # However, the provided template doesn't give player_hands on_round_start,
        # so assuming that `player_hands` from `on_start` is actually a list of *all* players' hands
        # and we need to find our own. A more robust system would pass our specific hole cards.
        # For now, let's assume `on_start`'s `player_hands` actually sets our hand, or `get_action` gets it.
        # This is a key ambiguity. Given the problem definition, on_start gives `player_hands` for the whole game,
        # but that doesn't make sense for poker. I'll make a pragmatic assumption that `get_action`
        # is the place where we receive relevant player-specific info like hole cards indirectly if not explicitly passed.
        # Or, the `on_start` means our initial hand for the *first* game, and further updates would be handled differently.
        # The prompt says `player_hands: List[str]` in on_start and that it's for 'the player' (singular).
        # Let's assume for now, our hole cards are passed in `get_action` if not found in `round_state`.
        # However, `round_state` also doesn't contain hole cards. This implies a need for an external call
        # or for the initial `player_hands` to be available to `get_action`.
        # Based on typical bot frameworks, the bot's private information (hole cards) is usually
        # fetched from a game state object directly or passed as an argument to `get_action`.
        # The `on_start` method's `player_hands` argument is highly ambiguous.
        # If the structure is that `player_hands` on `on_start` gives the bot *its* hands,
        # then it implies the bot knows all its hands for all future rounds (which is not how poker works).
        # Assuming `self.hole_cards` would be set by the game server if it were to implement `on_new_hand`
        # and pass current hole cards. For now, I'll assume they become available through other means (or default to empty).

        # Reset state specific to the round
        self.is_small_blind = (round_state.small_blind_player_id == self.id) if hasattr(round_state, 'small_blind_player_id') else False
        self.is_big_blind = (round_state.big_blind_player_id == self.id) if hasattr(round_state, 'big_blind_player_id') else False
        # The above attributes (small_blind_player_id, big_blind_player_id) are not in RoundStateClient definition
        # so I remove them to prevent errors. The blinds are just part of the betting structure.
        pass

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        """
        Evaluates the strength of a poker hand.
        Returns a tuple: (hand_rank, [kickers/relevant_card_ranks]).
        hand_rank: 0=High Card, 1=Pair, 2=Two Pair, ..., 8=Straight Flush, 9=Royal Flush.
        """
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            # Not enough cards to form a hand yet
            # For preflop, rely solely on hole cards
            if len(hole_cards) == 2:
                rank1 = self._get_card_rank_value(hole_cards[0][0])
                rank2 = self._get_card_rank_value(hole_cards[1][0])
                if rank1 == rank2:
                    return (1, [rank1]) # Pair
                # Good starting hands: high pairs, suited connectors, high cards
                if (rank1 >= 10 and rank2 >= 10) or \
                   (abs(rank1 - rank2) <= 1 and self._get_card_suit(hole_cards[0]) == self._get_card_suit(hole_cards[1])) or \
                   (rank1 == 14 and rank2 >= 10) or (rank2 == 14 and rank1 >= 10): # A-K, A-Q etc.
                    return (0, sorted([rank1, rank2], reverse=True)) # Just high card, but strong
            return (0, []) # Default for insufficient cards or weak preflop
        
        # Convert cards to a simpler format: (rank_value, suit_char)
        # Ranks: 2-10, J=11, Q=12, K=13, A=14
        processed_cards = []
        for card_str in all_cards:
            rank_char = card_str[0]
            suit_char = card_str[1]
            processed_cards.append((self._get_card_rank_value(rank_char), suit_char))

        # Generate all 5-card combinations
        import itertools
        best_rank = -1
        best_kickers = []

        for combo in itertools.combinations(processed_cards, 5):
            rank, kickers = self._evaluate_five_card_hand(list(combo))
            if rank > best_rank:
                best_rank = rank
                best_kickers = kickers
            elif rank == best_rank:
                # Compare kickers for tie-breaking
                if not best_kickers or kickers > best_kickers: # Assuming higher kickers are better
                     best_kickers = kickers
        
        return (best_rank, best_kickers)

    def _get_card_rank_value(self, rank_char: str) -> int:
        if rank_char.isdigit():
            return int(rank_char)
        elif rank_char == 'T':
            return 10
        elif rank_char == 'J':
            return 11
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'K':
            return 13
        elif rank_char == 'A':
            return 14
        return 0 # Should not happen

    def _get_card_suit(self, card_str: str) -> str:
        return card_str[1]

    def _evaluate_five_card_hand(self, five_cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        """
        Evaluates a 5-card hand. Private helper for _evaluate_hand.
        """
        ranks = sorted([card[0] for card in five_cards], reverse=True)
        suits = [card[1] for card in five_cards]

        is_flush = len(set(suits)) == 1
        is_straight = self._is_straight(ranks)

        if is_straight and is_flush:
            if ranks[0] == 14 and ranks[1] == 13: # A, K, Q, J, T of same suit
                return (9, []) # Royal Flush (kickers not needed)
            return (8, [ranks[0]]) # Straight Flush (highest card)

        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1

        if 4 in rank_counts.values():
            quad_rank = [rank for rank, count in rank_counts.items() if count == 4][0]
            kicker = [rank for rank in ranks if rank != quad_rank][0]
            return (7, [quad_rank, kicker]) # Four of a Kind

        if 3 in rank_counts.values() and 2 in rank_counts.values():
            trips_rank = [rank for rank, count in rank_counts.items() if count == 3][0]
            pair_rank = [rank for rank, count in rank_counts.items() if count == 2][0]
            return (6, [trips_rank, pair_rank]) # Full House

        if is_flush:
            return (5, ranks) # Flush

        if is_straight:
            return (4, [ranks[0]]) # Straight

        if 3 in rank_counts.values():
            trips_rank = [rank for rank, count in rank_counts.items() if count == 3][0]
            kickers = sorted([rank for rank in ranks if rank != trips_rank], reverse=True)
            return (3, [trips_rank] + kickers) # Three of a Kind

        pairs = sorted([rank for rank, count in rank_counts.items() if count == 2], reverse=True)
        if len(pairs) == 2:
            kicker = [rank for rank in ranks if rank not in pairs][0]
            return (2, pairs + [kicker]) # Two Pair

        if len(pairs) == 1:
            pair_rank = pairs[0]
            kickers = sorted([rank for rank in ranks if rank != pair_rank], reverse=True)
            return (1, [pair_rank] + kickers) # One Pair

        return (0, ranks) # High Card

    def _is_straight(self, sorted_ranks: List[int]) -> bool:
        unique_ranks = sorted(list(set(sorted_ranks)), reverse=True)
        if len(unique_ranks) < 5:
            return False

        # Check for regular straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                return True
        
        # Check for A-5 straight (Ace low)
        if set([14, 5, 4, 3, 2]).issubset(set(unique_ranks)):
            # Special case for A-5 straight, 14 (Ace) acts as 1
            return True
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # This is where the core logic of the bot should be.
        # The bot needs to know its hole cards. Since `player_hands` on `on_start` is ambiguous,
        # and `RoundStateClient` does not contain hole cards, I'll assume for competitive purposes
        # that the bot's hole cards are available internally or provided by the framework in a way
        # that `self.hole_cards` would be set.
        # For this iteration, I'll add a placeholder to simulate setting `self.hole_cards`
        # if they are not already set, which would be managed by the competition system.
        # If `self.hole_cards` is empty, it means we don't know our hand, which is not intended.
        # This needs to be resolved by the competition server's implementation details.
        
        # For now, let's assume `self.hole_cards` is somehow populated correctly before `get_action` is called for any specific hand.
        # If not, the bot will play randomly or conservatively.
        # A simple hack for testing if `self.hole_cards` is not passed:
        if not self.hole_cards:
            # This is a critical point. Without hole cards, a poker bot cannot function.
            # Assuming the competition framework will supply them via `on_round_start` or `on_start`
            # in a usable fashion. Given the `on_start` signature: `player_hands: List[str]`
            # this *might* be intended to be the bot's own two hole cards at game start,
            # which then would be invalid for subsequent hands.
            # For the purpose of getting rid of errors, I will define a dummy hand if not set,
            # but this MUST be corrected by the actual competition environment.
            self.hole_cards = ['Ah', 'Kh'] # Dummy default for error-prevention if not provided

        # Current betting state
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate potential immediate profit (how much to win if everyone folds)
        # This is a simplified pot_odds as it doesn't consider future betting rounds
        pot_size = round_state.pot

        # Hand evaluation
        hand_rank, hand_kickers = self._evaluate_hand(self.hole_cards, round_state.community_cards)
        
        num_active_players = sum(1 for player_id in round_state.current_player if player_id != self.id) + 1 # Include self

        if num_active_players <= 2: # Heads-up strategy might differ
            # Be more aggressive heads-up
            if hand_rank >= 1: # Pair or better
                if current_bet_to_match > remaining_chips * 0.3 and hand_rank < 3: # If big bet and only a pair
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                elif hand_rank >= 2: # Two pair or better, be aggressive
                    if current_bet_to_match > 0:
                        if round_state.current_bet < remaining_chips * 0.5 and remaining_chips > min_raise + 10:
                            raise_amount = min(max_raise, max(min_raise, round_state.current_bet + self.blind_amount * 2))
                            if raise_amount > 0:
                                return (PokerAction.RAISE, raise_amount)
                            else:
                                return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    elif round_state.current_bet == 0:
                        raise_amount = min(max_raise, self.blind_amount * 3) # Make a small bet if checked to
                        if raise_amount > 0 and remaining_chips >= raise_amount :
                            return (PokerAction.RAISE, raise_amount)
                        else: # Can't raise, check
                            return (PokerAction.CHECK, 0)
                else: # Only a pair
                    if current_bet_to_match > 0:
                        return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CHECK, 0)
            elif current_bet_to_match == 0:
                return (PokerAction.CHECK, 0)
            else: # Weak hand, small blind, or just high card
                call_percentage = current_bet_to_match / (pot_size + 0.001) # Avoid div by zero
                if call_percentage < 0.2: # Small call relative to pot
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Multi-way strategy
        if hand_rank >= 8: # Straight Flush or Royal Flush
            # Extremely strong hand, bet big or go all-in
            if max_raise > 0:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
        elif hand_rank >= 6: # Full House or Four of a Kind
            # Very strong hand, bet aggressively
            if max_raise > 0:
                # Value bet: raise significantly, but maybe not all-in to get more action
                raise_amount = min(max_raise, max(min_raise, remaining_chips // 2))
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
            else: # Cannot raise, just call or check
                return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)

        elif hand_rank >= 4: # Flush or Straight
            # Strong hand, bet for value
            if max_raise > 0:
                raise_amount = min(max_raise, max(min_raise, remaining_chips // 4)) # Quarter of stack
                if raise_amount > 0:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
            
        elif hand_rank >= 2: # Two Pair or Three of a Kind
            # Decent hand, proceed cautiously with big bets
            if current_bet_to_match == 0:
                # Check for free card, or small bet
                if random.random() < 0.3: # 30% chance to make a small bet
                    raise_amount = min(max_raise, self.blind_amount * 2)
                    if raise_amount > 0 and remaining_chips >= raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Pot odds calculation: (Pot + current_bet_to_match) / current_bet_to_match
                # If we're getting good odds, call. Else, consider folding.
                pot_odds_needed = current_bet_to_match / (pot_size + current_bet_to_match + 0.001)
                # Estimate win probability (very rough, this needs simulations for accuracy)
                # A hand rank of 2 (Two Pair) might have ~20-30% chance if opponent is strong
                # Or consider if there are likely draws for stronger hands on the board
                
                # Simple threshold:
                if current_bet_to_match / (remaining_chips + 0.001) < 0.25: # Don't commit too much with a medium hand
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0) # Too expensive for a medium hand
        
        elif hand_rank == 1: # One Pair
            # Weak-medium hand, be very cautious
            if current_bet_to_match == 0:
                return (PokerAction.CHECK, 0) # Check to see next card or get free showdown
            else:
                # Consider folding unless the bet is very small
                if current_bet_to_match / (remaining_chips + 0.001) < 0.15:
                    return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        else: # High Card (includes pre-flop strong pairs/connectors for now)
            if round_state.round == PokerRound.PREFLOP.name:
                # Pre-flop strategy based on hole cards (hand_kickers represents pre-flop strength here)
                rank1_val, rank2_val = 0, 0
                if self.hole_cards:
                    rank1_val = self._get_card_rank_value(self.hole_cards[0][0])
                    rank2_val = self._get_card_rank_value(self.hole_cards[1][0])
                
                # Very strong pre-flop hands (AA, KK, QQ, AKs)
                if (rank1_val == 14 and rank2_val == 14) or \
                   (rank1_val == 13 and rank2_val == 13) or \
                   (rank1_val == 12 and rank2_val == 12) or \
                   (sorted([rank1_val, rank2_val], reverse=True) == [14, 13] and self._get_card_suit(self.hole_cards[0]) == self._get_card_suit(self.hole_cards[1])):
                    if max_raise > 0:
                        raise_amount = min(max_raise, max(min_raise, self.blind_amount * 4))
                        if raise_amount > 0:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)

                # Strong pre-flop hands (JJ, TT, AQs, AKo, KQs)
                elif (rank1_val == 11 and rank2_val == 11) or \
                     (rank1_val == 10 and rank2_val == 10) or \
                     (sorted([rank1_val, rank2_val], reverse=True) == [14, 12] and self._get_card_suit(self.hole_cards[0]) == self._get_card_suit(self.hole_cards[1])) or \
                     (sorted([rank1_val, rank2_val], reverse=True) == [14, 13]) or \
                     (sorted([rank1_val, rank2_val], reverse=True) == [13, 12] and self._get_card_suit(self.hole_cards[0]) == self._get_card_suit(self.hole_cards[1])):
                    if current_bet_to_match <= self.blind_amount * 3: # Call small raises
                        return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    elif max_raise > 0 and current_bet_to_match == 0: # If checked to, make a small raise
                        raise_amount = min(max_raise, self.blind_amount * 2)
                        if raise_amount > 0 and remaining_chips >= raise_amount:
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                    else: # Bet too high for this hand, fold
                        return (PokerAction.FOLD, 0)
                
                # Medium pre-flop hands (suited connectors, small pairs)
                elif (rank1_val == rank2_val and rank1_val >= 7) or \
                     (self._get_card_suit(self.hole_cards[0]) == self._get_card_suit(self.hole_cards[1]) and abs(rank1_val - rank2_val) <= 2 and rank1_val >= 6):
                    if current_bet_to_match <= self.blind_amount * 2: # Call minimal raises for potential
                        return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    elif current_bet_to_match == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0) # Fold to larger bets
                
                else: # Weak pre-flop hands
                    if current_bet_to_match == 0:
                        return (PokerAction.CHECK, 0)
                    elif current_bet_to_match <= self.blind_amount: # Only call the big blind if it's cheap
                        return (PokerAction.CALL, 0) if current_bet_to_match <= remaining_chips else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            else: # Post-flop, high card or busted draw
                if current_bet_to_match == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Pure bluff mechanism or trying to take a free card
                    # For safety, mostly fold
                    if remaining_chips > current_bet_to_match and random.random() < 0.05: # Small chance to bluff call
                         return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

        # Default fallback, should be rarely hit if logic is comprehensive
        if current_bet_to_match == 0:
            return (PokerAction.CHECK, 0)
        elif current_bet_to_match < remaining_chips * 0.1: # Small bet, just call
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # The bot needs to know its hole cards for the *next* round.
        # This method signature doesn't provide them explicitly.
        # If the competition system design implies `player_hands` from `on_start` is dynamic,
        # it needs to be set. For now, empty `self.hole_cards` for the next round.
        self.hole_cards = [] 
        # In a real game, new hole cards would be dealt and stored at the start of a new hand/round.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # self.hole_cards = [] # Reset for a completely new game if necessary
        pass