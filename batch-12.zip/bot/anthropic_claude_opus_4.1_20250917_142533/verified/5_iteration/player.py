from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_strength_cache = {}
        self.position_aggression_factor = 1.0
        self.opponent_stats = {}
        self.round_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_cache = {}
        
        for player_id in all_players:
            if player_id not in self.opponent_stats:
                self.opponent_stats[player_id] = {
                    'vpip': 0,
                    'pfr': 0,
                    'aggression': 0,
                    'hands_played': 0,
                    'total_hands': 0
                }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1
        self.position_aggression_factor = self._calculate_position_factor(round_state)
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if remaining_chips <= 0:
            return (PokerAction.FOLD, 0)
            
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot_odds = to_call / (round_state.pot + to_call + 0.001)
        
        hand_strength = self._evaluate_hand_strength(round_state)
        
        if round_state.round == 'Preflop':
            return self._get_preflop_action(hand_strength, round_state, remaining_chips, to_call, pot_odds)
        else:
            return self._get_postflop_action(hand_strength, round_state, remaining_chips, to_call, pot_odds)
    
    def _get_preflop_action(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, to_call: int, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        
        if to_call == 0:
            if hand_strength > 0.7:
                raise_amount = min(int(round_state.pot * 0.75), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount + round_state.current_bet)
            elif hand_strength > 0.5:
                raise_amount = min(int(round_state.pot * 0.5), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount + round_state.current_bet)
            return (PokerAction.CHECK, 0)
        
        if to_call >= remaining_chips:
            if hand_strength > 0.75:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.FOLD, 0)
        
        if hand_strength > 0.85:
            return (PokerAction.ALL_IN, 0)
        elif hand_strength > 0.7:
            raise_amount = min(int(to_call * 3), remaining_chips)
            if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                return (PokerAction.RAISE, raise_amount + round_state.current_bet)
            elif to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.5 and pot_odds < hand_strength:
            if to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.35 and to_call <= self.blind_amount * 2:
            if to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def _get_postflop_action(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, to_call: int, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        
        if to_call == 0:
            if hand_strength > 0.8:
                bet_amount = min(int(round_state.pot * 0.75), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount + round_state.current_bet)
            elif hand_strength > 0.6:
                bet_amount = min(int(round_state.pot * 0.5), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount + round_state.current_bet)
            return (PokerAction.CHECK, 0)
        
        if to_call >= remaining_chips:
            if hand_strength > 0.85:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.FOLD, 0)
        
        if hand_strength > 0.9:
            return (PokerAction.ALL_IN, 0)
        elif hand_strength > 0.75:
            raise_amount = min(int(round_state.pot * 0.75), remaining_chips)
            if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                return (PokerAction.RAISE, raise_amount + round_state.current_bet)
            elif to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.5 and pot_odds < hand_strength:
            if to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.3 and pot_odds < 0.2:
            if to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        cache_key = (tuple(self.hand), tuple(round_state.community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        if round_state.round == 'Preflop':
            strength = self._evaluate_preflop_strength()
        else:
            strength = self._evaluate_postflop_strength(round_state.community_cards)
        
        strength *= self.position_aggression_factor
        strength = min(1.0, max(0.0, strength))
        
        self.hand_strength_cache[cache_key] = strength
        return strength
    
    def _evaluate_preflop_strength(self) -> float:
        if not self.hand or len(self.hand) < 2:
            return 0.3
        
        card1_rank = self._get_rank_value(self.hand[0][0])
        card2_rank = self._get_rank_value(self.hand[1][0])
        suited = self.hand[0][1] == self.hand[1][1]
        
        if card1_rank == card2_rank:
            if card1_rank >= 12:
                return 0.85
            elif card1_rank >= 10:
                return 0.75
            elif card1_rank >= 8:
                return 0.65
            else:
                return 0.55
        
        high_card = max(card1_rank, card2_rank)
        low_card = min(card1_rank, card2_rank)
        gap = high_card - low_card
        
        base_strength = 0.4
        base_strength += high_card * 0.03
        base_strength += low_card * 0.02
        base_strength -= gap * 0.02
        
        if suited:
            base_strength += 0.1
        
        if high_card == 14 and low_card >= 10:
            base_strength += 0.15
        
        return min(0.95, max(0.15, base_strength))
    
    def _evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        all_cards = self.hand + community_cards
        
        if len(all_cards) < 5:
            return 0.3
        
        ranks = [self._get_rank_value(card[0]) for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        max_same_rank = max(rank_counts.values())
        max_same_suit = max(suit_counts.values())
        
        sorted_ranks = sorted(ranks, reverse=True)
        is_straight = self._check_straight(sorted_ranks)
        
        if max_same_suit >= 5 and is_straight:
            return 0.99
        elif max_same_rank == 4:
            return 0.95
        elif max_same_rank == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
            return 0.90
        elif max_same_suit >= 5:
            return 0.85
        elif is_straight:
            return 0.80
        elif max_same_rank == 3:
            return 0.70
        elif len([c for c in rank_counts.values() if c == 2]) >= 2:
            return 0.60
        elif max_same_rank == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return 0.40 + pair_rank * 0.02
        else:
            return 0.20 + sorted_ranks[0] * 0.01
    
    def _check_straight(self, sorted_ranks: List[int]) -> bool:
        unique_ranks = list(set(sorted_ranks))
        unique_ranks.sort(reverse=True)
        
        if 14 in unique_ranks:
            unique_ranks.append(1)
        
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                return True
        return False
    
    def _get_rank_value(self, rank: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                    '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank, 2)
    
    def _calculate_position_factor(self, round_state: RoundStateClient) -> float:
        active_players = len(round_state.current_player)
        if active_players <= 2:
            return 1.1
        
        my_position = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
        position_ratio = my_position / (active_players + 0.001)
        
        return 0.9 + (position_ratio * 0.3)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        for player_id in round_state.player_actions:
            if player_id != str(self.id) and player_id in self.opponent_stats:
                action = round_state.player_actions[player_id]
                stats = self.opponent_stats[player_id]
                stats['total_hands'] += 1
                
                if action in ['Call', 'Raise', 'All-in']:
                    stats['hands_played'] += 1
                    if round_state.round == 'Preflop':
                        stats['vpip'] += 1
                        if action in ['Raise', 'All-in']:
                            stats['pfr'] += 1
                    if action in ['Raise', 'All-in']:
                        stats['aggression'] += 1
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.hand_strength_cache.clear()