from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.round_history = []
        self.opponent_aggression = {}
        self.hand_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_count += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track opponent actions for aggression factor
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current bet situation
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_size = round_state.pot
        
        # Calculate position (are we in position?)
        in_position = self.is_in_position(round_state)
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Get pot odds
        pot_odds = self.calculate_pot_odds(call_amount, pot_size)
        
        # Determine aggression factor based on game stage
        aggression_factor = self.get_aggression_factor(round_state, remaining_chips)
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self.preflop_strategy(round_state, remaining_chips, hand_strength, in_position, aggression_factor)
        else:
            return self.postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, in_position, aggression_factor)
    
    def is_in_position(self, round_state: RoundStateClient) -> bool:
        """Check if we're in position (acting last)"""
        active_players = [p for p in self.all_players if str(p) in round_state.player_bets]
        if not active_players:
            return False
        return self.id == active_players[-1]
    
    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        if round_state.round == 'Preflop':
            return self.evaluate_preflop_strength()
        else:
            return self.evaluate_postflop_strength(round_state.community_cards)
    
    def evaluate_preflop_strength(self) -> float:
        """Evaluate preflop hand strength"""
        if not self.hand or len(self.hand) < 2:
            return 0.3
        
        card1_rank = self.get_card_rank(self.hand[0])
        card2_rank = self.get_card_rank(self.hand[1])
        card1_suit = self.hand[0][-1] if len(self.hand[0]) > 1 else ''
        card2_suit = self.hand[1][-1] if len(self.hand[1]) > 1 else ''
        
        is_suited = card1_suit == card2_suit
        is_pair = card1_rank == card2_rank
        
        # Premium hands
        if is_pair:
            if card1_rank >= 12:  # QQ+
                return 0.95
            elif card1_rank >= 10:  # TT-JJ
                return 0.85
            elif card1_rank >= 7:  # 77-99
                return 0.75
            else:  # 22-66
                return 0.65
        
        high_card = max(card1_rank, card2_rank)
        low_card = min(card1_rank, card2_rank)
        
        # High cards
        if high_card == 14:  # Ace
            if low_card >= 11:  # AJ+
                return 0.85 if is_suited else 0.80
            elif low_card >= 9:  # A9-AT
                return 0.70 if is_suited else 0.65
            else:
                return 0.60 if is_suited else 0.55
        
        if high_card == 13:  # King
            if low_card >= 11:  # KJ+
                return 0.75 if is_suited else 0.70
            elif low_card >= 9:
                return 0.65 if is_suited else 0.60
        
        # Connectors
        if abs(card1_rank - card2_rank) == 1:
            if min(card1_rank, card2_rank) >= 8:
                return 0.65 if is_suited else 0.60
            else:
                return 0.55 if is_suited else 0.50
        
        # Default
        if high_card >= 10:
            return 0.55 if is_suited else 0.50
        
        return 0.40
    
    def evaluate_postflop_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if not self.hand or not community_cards:
            return 0.3
        
        all_cards = self.hand + community_cards
        
        # Check for various hand types
        if self.has_pair(all_cards):
            pair_rank = self.get_pair_rank(all_cards)
            if pair_rank >= 12:  # High pair
                return 0.75
            elif pair_rank >= 9:  # Medium pair
                return 0.65
            else:
                return 0.55
        
        if self.has_two_pair(all_cards):
            return 0.80
        
        if self.has_three_of_kind(all_cards):
            return 0.85
        
        if self.has_straight(all_cards):
            return 0.88
        
        if self.has_flush(all_cards):
            return 0.90
        
        if self.has_full_house(all_cards):
            return 0.95
        
        # High card only
        high_card = max([self.get_card_rank(card) for card in self.hand])
        if high_card >= 12:
            return 0.45
        
        return 0.35
    
    def get_card_rank(self, card: str) -> int:
        """Get numeric rank of a card"""
        if not card or len(card) < 1:
            return 2
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
    
    def has_pair(self, cards: List[str]) -> bool:
        """Check if cards contain a pair"""
        ranks = [self.get_card_rank(card) for card in cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        return any(count >= 2 for count in rank_counts.values())
    
    def get_pair_rank(self, cards: List[str]) -> int:
        """Get the rank of the highest pair"""
        ranks = [self.get_card_rank(card) for card in cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        for rank in sorted(rank_counts.keys(), reverse=True):
            if rank_counts[rank] >= 2:
                return rank
        return 0
    
    def has_two_pair(self, cards: List[str]) -> bool:
        """Check for two pair"""
        ranks = [self.get_card_rank(card) for card in cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        pairs = sum(1 for count in rank_counts.values() if count >= 2)
        return pairs >= 2
    
    def has_three_of_kind(self, cards: List[str]) -> bool:
        """Check for three of a kind"""
        ranks = [self.get_card_rank(card) for card in cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        return any(count >= 3 for count in rank_counts.values())
    
    def has_straight(self, cards: List[str]) -> bool:
        """Check for straight"""
        ranks = sorted(set([self.get_card_rank(card) for card in cards]))
        if len(ranks) < 5:
            return False
        
        for i in range(len(ranks) - 4):
            if ranks[i+4] - ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5 straight
        if 14 in ranks and set([2, 3, 4, 5]).issubset(set(ranks)):
            return True
        
        return False
    
    def has_flush(self, cards: List[str]) -> bool:
        """Check for flush"""
        suits = [card[-1] for card in cards if len(card) > 1]
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        return any(count >= 5 for count in suit_counts.values())
    
    def has_full_house(self, cards: List[str]) -> bool:
        """Check for full house"""
        ranks = [self.get_card_rank(card) for card in cards]
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        has_three = any(count >= 3 for count in rank_counts.values())
        has_pair = sum(1 for count in rank_counts.values() if count >= 2) >= 2
        return has_three and has_pair
    
    def calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot_size + call_amount
        return call_amount / (total_pot + 0.01)
    
    def get_aggression_factor(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate aggression factor based on stack size and game stage"""
        stack_to_pot_ratio = remaining_chips / (round_state.pot + 0.01)
        
        # Be more aggressive with larger stacks
        if stack_to_pot_ratio > 10:
            return 1.3
        elif stack_to_pot_ratio > 5:
            return 1.1
        elif stack_to_pot_ratio > 2:
            return 1.0
        else:
            return 0.9
    
    def preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, in_position: bool, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_size = round_state.pot
        
        # Adjust strength for position
        adjusted_strength = hand_strength * (1.1 if in_position else 0.95) * aggression_factor
        
        # No one has raised yet
        if round_state.current_bet <= self.blind_amount * 2:
            if adjusted_strength >= 0.85:
                # Raise with premium hands
                raise_amount = min(pot_size * 3, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength >= 0.70:
                # Raise with strong hands
                raise_amount = min(pot_size * 2, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif adjusted_strength >= 0.55:
                # Call with decent hands
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            
            # Check if possible, otherwise fold
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Someone has raised
        else:
            raise_to_pot_ratio = round_state.current_bet / (pot_size + 0.01)
            
            if adjusted_strength >= 0.90:
                # Re-raise with premium hands
                raise_amount = min(round_state.current_bet * 3, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength >= 0.75 and raise_to_pot_ratio < 0.5:
                # Call with strong hands if raise is reasonable
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength >= 0.60 and raise_to_pot_ratio < 0.3:
                # Call with decent hands if raise is small
                if call_amount <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
            
            return (PokerAction.FOLD, 0)
    
    def postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, in_position: bool, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        pot_size = round_state.pot
        
        # Adjust strength for position
        adjusted_strength = hand_strength * (1.05 if in_position else 0.95) * aggression_factor
        
        # No bet to us
        if call_amount == 0:
            if adjusted_strength >= 0.80:
                # Bet with strong hands
                bet_amount = min(int(pot_size * 0.75), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            elif adjusted_strength >= 0.65:
                # Bet smaller with medium hands
                bet_amount = min(int(pot_size * 0.5), remaining_chips)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            elif adjusted_strength >= 0.50 and in_position:
                # Sometimes bluff in position
                if self.hand_count % 3 == 0:  # Bluff 33% of the time
                    bet_amount = min(int(pot_size * 0.4), remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
            
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        else:
            # Calculate if we should call based on pot odds and hand strength
            required_equity = pot_odds
            
            if adjusted_strength >= 0.85:
                # Raise with very strong hands
                raise_amount = min(call_amount * 3, remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength >= 0.70:
                # Call with strong hands
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
            elif adjusted_strength >= required_equity * 1.2:
                # Call if we have good odds
                if call_amount <= remaining_chips * 0.5:
                    return (PokerAction.CALL, 0)
            
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass