from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.hand_strength_cache = {}
        self.opponent_aggression = {}
        self.fold_count = {}
        self.total_hands = 0
        self.position_late = False
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hand_strength_cache = {}
        for player_id in all_players:
            if player_id != self.id:
                if player_id not in self.opponent_aggression:
                    self.opponent_aggression[player_id] = 0.5
                    self.fold_count[player_id] = 0
        self.total_hands += 1
        
        # Determine position
        if len(all_players) == 2:
            self.position_late = (self.id == small_blind_player_id)
        else:
            my_index = all_players.index(self.id)
            bb_index = all_players.index(big_blind_player_id)
            distance = (my_index - bb_index) % len(all_players)
            self.position_late = distance >= len(all_players) // 2
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                pid = int(player_id)
                if action in ['Raise', 'All In']:
                    self.opponent_aggression[pid] = min(1.0, self.opponent_aggression.get(pid, 0.5) + 0.05)
                elif action == 'Fold':
                    self.fold_count[pid] = self.fold_count.get(pid, 0) + 1
                    self.opponent_aggression[pid] = max(0.0, self.opponent_aggression.get(pid, 0.5) - 0.02)
        
        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(round_state.community_cards)
        
        # Get pot odds
        pot = round_state.pot
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_odds = to_call / (pot + to_call + 0.001)
        
        # Count active opponents
        active_opponents = len([p for p in round_state.current_player if p != self.id])
        
        # Adjust strength based on opponents and position
        adjusted_strength = hand_strength
        if active_opponents > 1:
            adjusted_strength *= (0.85 ** (active_opponents - 1))
        if self.position_late:
            adjusted_strength *= 1.1
            
        # Get average opponent aggression
        avg_aggression = 0.5
        if active_opponents > 0:
            active_agg = [self.opponent_aggression.get(p, 0.5) for p in round_state.current_player if p != self.id]
            avg_aggression = sum(active_agg) / len(active_agg)
        
        # Adjust for opponent tendencies
        if avg_aggression > 0.7:
            adjusted_strength *= 1.15
        elif avg_aggression < 0.3:
            adjusted_strength *= 0.9
            
        # Make decision
        if to_call == 0:
            # Can check
            if adjusted_strength > 0.7 or (adjusted_strength > 0.5 and random.random() < 0.3):
                # Bet for value or bluff
                bet_size = self.calculate_bet_size(pot, remaining_chips, adjusted_strength, round_state)
                if bet_size > 0:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        else:
            # Need to call or fold
            if remaining_chips <= to_call:
                # Would be all-in to call
                if adjusted_strength > pot_odds * 0.8:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Calculate implied odds
            implied_odds = pot_odds * 0.8
            
            if adjusted_strength > implied_odds:
                # Decide between call and raise
                if adjusted_strength > 0.75 and remaining_chips > to_call * 2:
                    bet_size = self.calculate_bet_size(pot + to_call, remaining_chips - to_call, adjusted_strength, round_state)
                    if bet_size > 0 and to_call + bet_size <= remaining_chips:
                        return (PokerAction.RAISE, to_call + bet_size)
                return (PokerAction.CALL, 0)
            else:
                # Check if we should bluff
                if self.should_bluff(round_state, remaining_chips, pot_odds):
                    bet_size = int(pot * 0.75)
                    if to_call + bet_size <= remaining_chips and bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, to_call + bet_size)
                return (PokerAction.FOLD, 0)
    
    def calculate_bet_size(self, pot: int, remaining_chips: int, strength: float, round_state: RoundStateClient) -> int:
        # Base bet sizing on strength and pot
        if strength > 0.9:
            bet_pct = random.uniform(0.75, 1.0)
        elif strength > 0.75:
            bet_pct = random.uniform(0.5, 0.75)
        elif strength > 0.6:
            bet_pct = random.uniform(0.33, 0.5)
        else:
            bet_pct = random.uniform(0.25, 0.4)
            
        bet_size = int(pot * bet_pct)
        
        # Ensure valid bet
        min_bet = round_state.min_raise
        if bet_size < min_bet:
            if strength > 0.7 and min_bet <= remaining_chips * 0.5:
                bet_size = min_bet
            else:
                return 0
                
        # Cap at remaining chips
        bet_size = min(bet_size, remaining_chips)
        
        return bet_size
    
    def should_bluff(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> bool:
        # Bluff occasionally based on game state
        if round_state.round == 'River':
            bluff_freq = 0.1
        elif round_state.round == 'Turn':
            bluff_freq = 0.15
        else:
            bluff_freq = 0.2
            
        # Adjust for stack size
        if remaining_chips < self.starting_chips * 0.3:
            bluff_freq *= 0.5
            
        # Adjust for pot odds
        if pot_odds > 0.3:
            bluff_freq *= 0.5
            
        return random.random() < bluff_freq
    
    def calculate_hand_strength(self, community_cards: List[str]) -> float:
        cache_key = tuple(sorted(self.hand + community_cards))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]
        
        if len(community_cards) == 0:
            # Pre-flop
            strength = self.preflop_strength()
        elif len(community_cards) == 3:
            # Flop
            strength = self.postflop_strength(community_cards)
        elif len(community_cards) == 4:
            # Turn
            strength = self.postflop_strength(community_cards)
        else:
            # River
            strength = self.postflop_strength(community_cards)
            
        self.hand_strength_cache[cache_key] = strength
        return strength
    
    def preflop_strength(self) -> float:
        if len(self.hand) != 2:
            return 0.5
            
        card1_rank = self.get_rank(self.hand[0])
        card2_rank = self.get_rank(self.hand[1])
        suited = self.hand[0][-1] == self.hand[1][-1]
        
        # Pocket pairs
        if card1_rank == card2_rank:
            if card1_rank >= 12:  # QQ+
                return 0.95
            elif card1_rank >= 10:  # TT-JJ
                return 0.85
            elif card1_rank >= 7:  # 77-99
                return 0.75
            else:
                return 0.65
        
        # High cards
        high_rank = max(card1_rank, card2_rank)
        low_rank = min(card1_rank, card2_rank)
        gap = high_rank - low_rank
        
        if high_rank == 14:  # Ace high
            if low_rank >= 11:  # AJ+
                return 0.8 if suited else 0.75
            elif low_rank >= 8:
                return 0.65 if suited else 0.6
            else:
                return 0.55 if suited else 0.5
        elif high_rank >= 12:  # King/Queen high
            if gap <= 2:
                return 0.7 if suited else 0.65
            else:
                return 0.55 if suited else 0.5
        elif high_rank >= 10:  # Jack/Ten high
            if gap <= 2:
                return 0.6 if suited else 0.55
            else:
                return 0.45 if suited else 0.4
        else:
            if gap <= 1 and suited:
                return 0.5
            else:
                return 0.4
    
    def postflop_strength(self, community_cards: List[str]) -> float:
        all_cards = self.hand + community_cards
        
        # Check for made hands
        ranks = [self.get_rank(card) for card in all_cards]
        suits = [card[-1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        has_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        has_straight = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                has_straight = True
                break
        # Check A-5 straight
        if 14 in unique_ranks and set([2,3,4,5]).issubset(set(unique_ranks)):
            has_straight = True
            
        # Count pairs, trips, quads
        pairs = sum(1 for count in rank_counts.values() if count == 2)
        trips = sum(1 for count in rank_counts.values() if count == 3)
        quads = sum(1 for count in rank_counts.values() if count == 4)
        
        # Determine hand strength
        if has_flush and has_straight:
            return 0.99
        elif quads > 0:
            return 0.98
        elif trips > 0 and pairs > 0:
            return 0.95
        elif has_flush:
            return 0.92
        elif has_straight:
            return 0.88
        elif trips > 0:
            return 0.80
        elif pairs >= 2:
            return 0.70
        elif pairs == 1:
            # Check if we have top pair
            board_ranks = [self.get_rank(card) for card in community_cards]
            hand_ranks = [self.get_rank(card) for card in self.hand]
            max_board = max(board_ranks) if board_ranks else 0
            
            for hand_rank in hand_ranks:
                if rank_counts[hand_rank] == 2:
                    if hand_rank >= max_board:
                        return 0.65
                    else:
                        return 0.55
            return 0.50
        else:
            # High card only
            hand_ranks = [self.get_rank(card) for card in self.hand]
            if max(hand_ranks) >= 12:
                return 0.35
            else:
                return 0.25
    
    def get_rank(self, card: str) -> int:
        rank_char = card[0] if len(card) == 2 else card[0:2]
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, '10': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank_char, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass