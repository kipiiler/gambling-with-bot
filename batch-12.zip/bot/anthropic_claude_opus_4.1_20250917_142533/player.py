from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 10
        self.game_count = 0
        self.total_games = 0
        self.aggression_factor = 0.4
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.game_count += 1
        self.total_games += 1
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get my current bet from player_bets
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Calculate pot odds
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001) if call_amount > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # If we can check for free, check with weak hands
        if call_amount == 0:
            if hand_strength < 0.4:
                return (PokerAction.CHECK, 0)
            elif hand_strength > 0.7 and remaining_chips > round_state.pot:
                # Make a proper raise - at least 2x current bet or min_raise
                raise_amount = max(round_state.min_raise, round_state.pot // 2)
                if raise_amount > 0 and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CHECK, 0)
        
        # If we need to call
        if call_amount > 0:
            # Fold weak hands
            if hand_strength < 0.3:
                return (PokerAction.FOLD, 0)
            
            # Call with medium hands if pot odds are good
            if hand_strength < 0.6:
                if pot_odds < 0.3 or call_amount <= round_state.pot * 0.5:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Strong hands - consider raising
            if hand_strength > 0.7:
                # Calculate a proper raise amount
                raise_amount = max(round_state.min_raise, call_amount * 2)
                if raise_amount <= remaining_chips and raise_amount > 0:
                    # Make sure our total bet will be higher than current bet
                    total_bet_after_raise = my_bet + raise_amount
                    if total_bet_after_raise > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
                
                # If we can't raise properly, just call
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
            
            # Default to call if we have chips
            if call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
        
        # Default to check if possible, otherwise fold
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)
        
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards."""
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Pre-flop hand strength
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            strength = 0.5 + (rank1 / 14) * 0.4
            if rank1 >= 10:  # High pairs
                strength = 0.85
            elif rank1 >= 7:  # Medium pairs
                strength = 0.65
        else:
            high_card = max(rank1, rank2)
            low_card = min(rank1, rank2)
            gap = high_card - low_card
            
            # High cards
            if high_card >= 12:  # Ace or King
                strength = 0.55
                if low_card >= 10:
                    strength = 0.7
            elif high_card >= 10:  # Queen or Jack
                strength = 0.45
                if low_card >= 8:
                    strength = 0.55
            else:
                strength = 0.3
            
            # Suited bonus
            if suited:
                strength += 0.05
            
            # Connected cards bonus
            if gap == 1:
                strength += 0.05
            elif gap > 4:
                strength -= 0.05
        
        # Adjust based on community cards
        if round_state.community_cards:
            community_count = len(round_state.community_cards)
            
            # Count matches with community cards
            matches = 0
            for comm_card in round_state.community_cards:
                comm_rank = self._card_rank(comm_card)
                if comm_rank == rank1 or comm_rank == rank2:
                    matches += 1
            
            if matches > 0:
                strength += matches * 0.2
            
            # Be more conservative with more community cards
            if community_count >= 3:
                strength *= 0.9
            if community_count == 5:
                strength *= 0.85
        
        # Adjust based on round
        if round_state.round == 'Preflop':
            strength *= 1.1
        elif round_state.round == 'River':
            strength *= 0.9
            
        return min(1.0, max(0.0, strength))
        
    def _card_rank(self, card: str) -> int:
        """Convert card rank to numerical value."""
        rank = card[:-1]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 2
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Adjust aggression based on performance
        if player_score < 0:
            self.aggression_factor = max(0.2, self.aggression_factor - 0.05)
        elif player_score > 0:
            self.aggression_factor = min(0.6, self.aggression_factor + 0.05)