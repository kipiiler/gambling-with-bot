from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import defaultdict

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.big_blind = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def card_to_tuple(self, card: str) -> Tuple[int, str]:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map[card[0]]
        suit = card[1]
        return rank, suit

    def score_five(self, cards: List[str]) -> Tuple[int, List[int]]:
        parsed = [self.card_to_tuple(c) for c in cards]
        ranks = sorted([p[0] for p in parsed], reverse=True)
        suits = [p[1] for p in parsed]
        is_flush = all(s == suits[0] for s in suits)
        is_straight = False
        if len(set(ranks)) == 5:
            if ranks[0] - ranks[4] == 4:
                is_straight = True
            elif ranks == [14, 5, 4, 3, 2]:
                is_straight = True
                ranks = [5, 4, 3, 2, 1]

        rank_counts = defaultdict(int)
        for r in ranks:
            rank_counts[r] += 1
        counts = sorted(rank_counts.values(), reverse=True)

        if counts[0] == 4:
            type_ = 7
            four_rank = next(r for r in rank_counts if rank_counts[r] == 4)
            kicker = next(r for r in ranks if rank_counts[r] != 4)
            tiebreak = [four_rank, kicker]
        elif counts == [3, 2]:
            type_ = 6
            three = next(r for r in rank_counts if rank_counts[r] == 3)
            two = next(r for r in rank_counts if rank_counts[r] == 2)
            tiebreak = [three, two]
        elif is_flush and is_straight:
            if ranks[0] == 14 and ranks[1] == 13:
                type_ = 9
                tiebreak = []
            else:
                type_ = 8
                tiebreak = ranks
        elif is_flush:
            type_ = 5
            tiebreak = ranks
        elif is_straight:
            type_ = 4
            tiebreak = ranks
        elif counts[0] == 3:
            type_ = 3
            three = next(r for r in rank_counts if rank_counts[r] == 3)
            kickers = sorted([r for r in ranks if r != three], reverse=True)
            tiebreak = [three] + kickers[:2]
        elif counts == [2, 2]:
            type_ = 2
            pairs = sorted([r for r in rank_counts if rank_counts[r] == 2], reverse=True)
            kicker = next(r for r in rank_counts if rank_counts[r] == 1)
            tiebreak = pairs + [kicker]
        elif counts[0] == 2:
            type_ = 1
            pair = next(r for r in rank_counts if rank_counts[r] == 2)
            kickers = sorted([r for r in ranks if r != pair], reverse=True)
            tiebreak = [pair] + kickers[:3]
        else:
            type_ = 0
            tiebreak = ranks

        return (type_, tiebreak)

    def evaluate_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole + community
        best_score = (0, [])
        for combo in combinations(all_cards, 5):
            score = self.score_five(list(combo))
            if score > best_score:
                best_score = score
        return best_score

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        min_r = round_state.min_raise
        max_r = round_state.max_raise
        pot = round_state.pot
        phase = round_state.round
        community = round_state.community_cards

        if to_call > remaining_chips:
            return PokerAction.FOLD, 0

        if phase == "Preflop":
            ranks = sorted([self.card_to_tuple(c)[0] for c in self.hole_cards], reverse=True)
            suits = [self.card_to_tuple(c)[1] for c in self.hole_cards]
            suited = suits[0] == suits[1]
            pair = ranks[0] == ranks[1]
            gap = ranks[0] - ranks[1]
            high = ranks[0]
            if pair and high >= 7:
                strength = 'strong'
            elif pair or (suited and high >= 10 and gap < 4) or (high >= 12 and gap < 3):
                strength = 'medium'
            else:
                strength = 'weak'
        else:
            hand_score = self.evaluate_hand(self.hole_cards, community)
            type_ = hand_score[0]
            if type_ >= 4:
                strength = 'strong'
            elif type_ >= 1:
                strength = 'medium'
            else:
                strength = 'weak'

        if strength == 'weak':
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
        elif strength == 'medium':
            if to_call == 0:
                bet_size = (pot // 2) + 1
                bet_size = max(min_r, bet_size)
                bet_size = min(max_r, bet_size)
                if bet_size >= min_r:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            else:
                if to_call < (pot // 2) + 1:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        elif strength == 'strong':
            if to_call == 0:
                bet_size = pot + 1
                bet_size = max(min_r, bet_size)
                bet_size = min(max_r, bet_size)
                if bet_size >= min_r:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            else:
                raise_size = to_call + (pot // 2) + 1
                raise_size = max(min_r, raise_size)
                raise_size = min(max_r, raise_size)
                if raise_size >= max_r:
                    return PokerAction.ALL_IN, 0
                elif raise_size >= min_r:
                    return PokerAction.RAISE, raise_size
                else:
                    return PokerAction.CALL, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass