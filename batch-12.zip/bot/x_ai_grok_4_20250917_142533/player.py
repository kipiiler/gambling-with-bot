from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import defaultdict
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        self.suits = {'h': 0, 's': 1, 'd': 2, 'c': 3}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def evaluate5(self, cards):
        sorted_cards = sorted(cards, key=lambda x: x[0], reverse=True)
        ranks_list = [c[0] for c in sorted_cards]
        suits_list = [c[1] for c in sorted_cards]
        is_flush = all(s == suits_list[0] for s in suits_list)

        is_straight = True
        for i in range(1, 5):
            if ranks_list[i - 1] - ranks_list[i] != 1:
                is_straight = False
                break
        wheel = False
        if not is_straight and ranks_list == [14, 5, 4, 3, 2]:
            is_straight = True
            wheel = True
            ranks_list = [5, 4, 3, 2, 1]

        rank_count = defaultdict(int)
        for r in ranks_list:
            rank_count[r] += 1

        quads = [r for r, count in rank_count.items() if count == 4]
        trips = [r for r, count in rank_count.items() if count == 3]
        pairs = [r for r, count in rank_count.items() if count == 2]

        if is_flush and is_straight:
            if not wheel and ranks_list[0] == 14 and ranks_list[1] == 13:
                return 9, ranks_list  # royal flush
            return 8, ranks_list  # straight flush

        if quads:
            kicker = [r for r in sorted(ranks_list, reverse=True) if r != quads[0]][0]
            return 7, [quads[0], kicker]  # four of a kind

        if trips and pairs:
            return 6, [trips[0], pairs[0]]  # full house
        elif len(trips) == 2:
            t = sorted(trips, reverse=True)
            return 6, [t[0], t[1]]

        if is_flush:
            return 5, ranks_list  # flush

        if is_straight:
            return 4, ranks_list  # straight

        if trips:
            kickers = sorted([r for r in ranks_list if r != trips[0]], reverse=True)
            return 3, [trips[0]] + kickers[:2]  # three of a kind

        if len(pairs) >= 2:
            p = sorted(pairs, reverse=True)[:2]
            kicker = sorted([r for r in ranks_list if r not in p], reverse=True)[0]
            return 2, p + [kicker]  # two pair

        if pairs:
            kickers = sorted([r for r in ranks_list if r != pairs[0]], reverse=True)
            return 1, [pairs[0]] + kickers[:3]  # one pair

        return 0, ranks_list  # high card

    def get_hand_strength(self, hole, community):
        if not community:
            # preflop strength approximation
            if len(hole) != 2:
                return 0.0
            card1, card2 = sorted(hole, key=lambda c: self.ranks[c[0]], reverse=True)
            r1 = self.ranks[card1[0]]
            r2 = self.ranks[card2[0]]
            suited = card1[1] == card2[1]
            diff = abs(r1 - r2)
            if r1 == r2:
                if r1 >= 10:
                    return 0.85
                elif r1 >= 6:
                    return 0.6
                else:
                    return 0.4
            if r1 == 14 and r2 >= 12:
                return 0.75 if suited else 0.65
            if suited and diff <= 4:
                return 0.5
            if diff <= 2:
                return 0.4
            return 0.2 + min(r1, r2) / 100.0
        else:
            card_list = [(self.ranks[c[0]], self.suits[c[1]]) for c in hole + community]
            best_type = -1
            for combo in combinations(card_list, 5):
                hand_type, _ = self.evaluate5(combo)
                if hand_type > best_type:
                    best_type = hand_type
            return (best_type + 1) / 10.0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if self.hole_cards is None or self.id is None:
            return PokerAction.FOLD, 0
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        call_amount = round_state.current_bet - my_bet
        can_check = call_amount == 0
        min_raise_by = round_state.min_raise
        max_raise_by = round_state.max_raise

        strength = self.get_hand_strength(self.hole_cards, round_state.community_cards)

        if remaining_chips <= 0:
            return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0

        if call_amount >= remaining_chips:
            if strength > 0.4:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        pot = round_state.pot
        pot_odds = (call_amount / (pot + call_amount + 0.0001)) if call_amount > 0 else 0

        if call_amount > 0:
            if strength > 0.6 or (strength > 0.3 and pot_odds < 0.2):
                if random.random() < 0.4 and max_raise_by > 0:
                    raise_by = max(min_raise_by, int(pot * 0.5))
                    raise_by = min(raise_by, max_raise_by)
                    if call_amount + raise_by >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_by
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            if strength > 0.5 and max_raise_by > 0:
                raise_by = max(min_raise_by, int(pot * 0.3))
                raise_by = min(raise_by, max_raise_by)
                if raise_by >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_by
            return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass