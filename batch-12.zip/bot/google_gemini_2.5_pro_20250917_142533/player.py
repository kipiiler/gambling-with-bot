import itertools
import random
from collections import Counter
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Global constants for card ranks and suits
RANKS = '23456789TJQKA'
SUITS = 'shdc'

class SimplePlayer(Bot):
    """
    A poker bot for No-Limit Texas Hold'em.

    Strategy:
    - Pre-flop: Uses a tier-based system for starting hands (Chen formula inspired).
      Plays tighter in early positions and looser in later positions.
    - Post-flop: Uses a Monte Carlo simulation to estimate hand equity (win probability).
      The decision to bet, call, check, or fold is based on this equity, pot odds,
      and pot size.
    - Bet Sizing: Bets are typically sized relative to the pot (e.g., 1/2 or 3/4 pot).
    - Error Handling: Includes checks to prevent invalid actions and crashes.
    """
    def __init__(self):
        super().__init__()
        self.my_hand: List[str] = []
        self.all_players: List[int] = []
        self.initial_stack: int = 0
        self.bb_amount: int = 0
        self.player_count: int = 0
        
        # This is a critical assumption. The problem description does not specify how
        # the bot receives its hand for rounds after the first. We receive a hand
        # in `on_start`, which we will store. If this hand is not updated by the
        # game runner for subsequent rounds, the bot will perform poorly by playing
        # the same hand repeatedly. This implementation assumes some mechanism
        # (not specified in the prompt) updates `self.my_hand` for each new round.
        # For now, we will use the hand given at the start for all rounds as it's the
        # only information available according to the function signatures.

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_stack = starting_chips
        self.my_hand = player_hands
        self.bb_amount = blind_amount
        self.all_players = all_players
        self.player_count = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # NOTE: As mentioned in the __init__ docstring, there's no defined way to get
        # the new hand for the current round. We are proceeding with the hand we
        # have stored in self.my_hand. If the game has a hidden mechanism to update hands
        # (e.g. updating self.my_hand directly), this will work. Otherwise, this bot's
        # logic depends on a piece of information it may not have after round 1.
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # --- Action Validation ---
            can_check = round_state.current_bet == round_state.player_bets.get(str(self.id), 0)
            can_raise = round_state.min_raise is not None and remaining_chips > 0

            # --- Pre-flop Strategy ---
            if round_state.round == 'Preflop':
                strength = self._get_preflop_strength(self.my_hand)
                num_active_players = self._get_active_players_count(round_state)
                
                # Adjust strength threshold based on number of players
                # Tighter with more players
                raise_threshold = 0.7 + (self.player_count - num_active_players) * 0.05
                call_threshold = 0.4 + (self.player_count - num_active_players) * 0.05

                # Someone has raised
                if round_state.current_bet > self.bb_amount:
                    if strength > raise_threshold + 0.15: # Re-raise with premium hands
                         return self._make_raise(round_state, remaining_chips, multiplier=3.0)
                    if strength > call_threshold + 0.2: # Call with strong hands
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                # No raise yet
                else:
                    if strength > raise_threshold:
                        return self._make_raise(round_state, remaining_chips, multiplier=2.5)
                    if strength > call_threshold and can_check: # Limp in with playable hands if possible
                        return PokerAction.CHECK, 0
                    if strength > call_threshold:
                        return PokerAction.CALL, 0
                    
                    if can_check: # Check if we are BB and no one raised
                        return PokerAction.CHECK, 0
                    return PokerAction.FOLD, 0
            
            # --- Post-flop Strategy ---
            else:
                num_opponents = self._get_active_players_count(round_state) - 1
                if num_opponents <= 0: # We are the only one left
                    return PokerAction.CHECK, 0
                    
                win_prob = self._monte_carlo_simulation(self.my_hand, round_state.community_cards, num_opponents)

                call_cost = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                pot_total = round_state.pot
                
                pot_odds = 0
                if call_cost > 0:
                    denominator = pot_total + call_cost
                    if denominator > 0:
                        pot_odds = call_cost / denominator

                # Decision logic based on win probability
                if can_check: # We can check
                    if win_prob > 0.8: # Bet strong with high prob
                        return self._make_bet(round_state, remaining_chips, 0.75)
                    elif win_prob > 0.5: # Bet weaker with medium prob
                        return self._make_bet(round_state, remaining_chips, 0.5)
                    else: # Check otherwise
                        return PokerAction.CHECK, 0
                else: # We must call, raise, or fold
                    if win_prob > 0.8: # Re-raise/raise with very strong hands
                        return self._make_raise(round_state, remaining_chips, multiplier=2.5)
                    if win_prob > pot_odds: # If winning more than pot odds, call
                        return PokerAction.CALL, 0
                    else: # Not worth calling
                        return PokerAction.FOLD, 0

        except Exception:
            # If any error occurs, fold to be safe
            if round_state.current_bet == round_state.player_bets.get(str(self.id), 0):
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0
        
        # Fallback action
        if round_state.current_bet == round_state.player_bets.get(str(self.id), 0):
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    def _make_raise(self, round_state: RoundStateClient, remaining_chips: int, multiplier: float) -> Tuple[PokerAction, int]:
        """Calculates a raise amount and returns the action."""
        if not round_state.min_raise or not round_state.max_raise:
            return PokerAction.CALL, 0 # Can't raise, so just call
        
        # Raise relative to pot if first to bet, or relative to previous bet
        base_raise = round_state.pot if round_state.current_bet == 0 else round_state.current_bet
        raise_amount = int(base_raise * multiplier)
        
        # Clamp raise amount to legal limits
        amount = max(round_state.min_raise, raise_amount)
        amount = min(round_state.max_raise, amount)

        if amount >= remaining_chips:
            return PokerAction.ALL_IN, 0
        
        if amount >= round_state.min_raise:
            return PokerAction.RAISE, amount
        else: # Cannot meet min_raise, must call or fold. Let's call.
             return PokerAction.CALL, 0


    def _make_bet(self, round_state: RoundStateClient, remaining_chips: int, multiplier: float) -> Tuple[PokerAction, int]:
        """Calculates a bet amount and returns the action."""
        if not round_state.min_raise or not round_state.max_raise:
             return PokerAction.CHECK, 0

        amount = int(round_state.pot * multiplier)
        amount = max(round_state.min_raise, amount)
        amount = min(round_state.max_raise, amount)
        
        if amount >= remaining_chips:
            return PokerAction.ALL_IN, 0
            
        if amount >= round_state.min_raise:
            return PokerAction.RAISE, amount
        else:
            return PokerAction.CHECK, 0

    def _get_active_players_count(self, round_state: RoundStateClient) -> int:
        """Counts players who have not folded."""
        # A player is active if they are in player_bets. Folded players might be removed.
        # This is an assumption. A more robust way might be needed if folded players
        # remain in the dictionary with a special status.
        return len(round_state.player_bets)

    # --- Poker Hand Evaluation and Simulation ---

    @staticmethod
    def _card_to_rank_suit(card: str) -> Tuple[int, str]:
        """Converts 'Th' to (10, 'h')."""
        rank = RANKS.index(card[0]) + 2
        suit = card[1]
        return rank, suit

    @staticmethod
    def _evaluate_hand(hand_7_cards: List[str]) -> Tuple:
        """
        Evaluates the best 5-card hand from 7 cards.
        Returns a tuple representing hand strength, e.g., (8, 14, 5) for four aces with a 5 kicker.
        Hand Ranks:
        9: Straight Flush
        8: Four of a Kind
        7: Full House
        6: Flush
        5: Straight
        4: Three of a Kind
        3: Two Pair
        2: One Pair
        1: High Card
        """
        if not hand_7_cards or len(hand_7_cards) < 5:
            return (0,)
        
        best_rank = (0,)

        for hand_5 in itertools.combinations(hand_7_cards, 5):
            ranks = sorted([SimplePlayer._card_to_rank_suit(c)[0] for c in hand_5], reverse=True)
            suits = [SimplePlayer._card_to_rank_suit(c)[1] for c in hand_5]
            
            is_flush = len(set(suits)) == 1
            
            is_straight = all(ranks[i] - 1 == ranks[i+1] for i in range(4))
            # Ace-low straight
            if not is_straight and ranks == [14, 5, 4, 3, 2]:
                is_straight = True
                ranks = [5, 4, 3, 2, 1] # Treat ace as 1 for ranking purposes

            # Counts of each rank
            rank_counts = Counter(ranks)
            counts = sorted(rank_counts.values(), reverse=True)
            main_ranks = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)

            current_rank = (0,)
            if is_straight and is_flush:
                current_rank = (9, main_ranks[0]) # Straight Flush
            elif counts[0] == 4:
                current_rank = (8, main_ranks[0], main_ranks[1]) # Four of a Kind
            elif counts == [3, 2]:
                current_rank = (7, main_ranks[0], main_ranks[1]) # Full House
            elif is_flush:
                current_rank = (6, tuple(ranks)) # Flush
            elif is_straight:
                current_rank = (5, main_ranks[0]) # Straight
            elif counts[0] == 3:
                current_rank = (4, main_ranks[0], main_ranks[1], main_ranks[2]) # Three of a Kind
            elif counts == [2, 2, 1]:
                current_rank = (3, main_ranks[0], main_ranks[1], main_ranks[2]) # Two Pair
            elif counts[0] == 2:
                current_rank = (2, main_ranks[0], main_ranks[1], main_ranks[2], main_ranks[3]) # One Pair
            else:
                current_rank = (1, tuple(ranks)) # High Card
            
            if current_rank > best_rank:
                best_rank = current_rank

        return best_rank

    @staticmethod
    def _monte_carlo_simulation(my_hand: List[str], community_cards: List[str], num_opponents: int, num_simulations: int = 300) -> float:
        """
        Estimates win probability using Monte Carlo simulation.
        """
        deck = [r + s for r in RANKS for s in SUITS]
        known_cards = set(my_hand + community_cards)
        deck = [c for c in deck if c not in known_cards]
        
        wins = 0
        ties = 0

        for _ in range(num_simulations):
            try:
                sim_deck = deck[:]
                random.shuffle(sim_deck)

                # Deal cards to opponents and community
                num_cards_to_deal = num_opponents * 2 + (5 - len(community_cards))
                deals = sim_deck[:num_cards_to_deal]
                
                opp_hands = [deals[i*2:i*2+2] for i in range(num_opponents)]
                sim_community = community_cards + deals[num_opponents*2:]

                my_rank = SimplePlayer._evaluate_hand(my_hand + sim_community)
                
                best_opp_rank = (0,)
                for opp_hand in opp_hands:
                    opp_rank = SimplePlayer._evaluate_hand(opp_hand + sim_community)
                    if opp_rank > best_opp_rank:
                        best_opp_rank = opp_rank

                if my_rank > best_opp_rank:
                    wins += 1
                elif my_rank == best_opp_rank:
                    ties += 1
            except (ValueError, IndexError):
                # In case of sampling issues, just skip this simulation run
                continue

        if num_simulations == 0: return 0.0
        return (wins + ties / 2) / num_simulations

    @staticmethod
    def _get_preflop_strength(hand: List[str]) -> float:
        """
        Assigns a score from 0.0 to 1.0 for a pre-flop hand.
        Based on a simplified Chen formula / Sklansky-Malmuth tables.
        """
        c1_rank, c1_suit = SimplePlayer._card_to_rank_suit(hand[0])
        c2_rank, c2_suit = SimplePlayer._card_to_rank_suit(hand[1])
        
        high_card = max(c1_rank, c2_rank)
        low_card = min(c1_rank, c2_rank)
        
        # Base score from high card
        score = 0
        if high_card == 14: score = 10
        elif high_card == 13: score = 8
        elif high_card == 12: score = 7
        elif high_card == 11: score = 6
        else: score = high_card / 2.0

        # Pairs
        if c1_rank == c2_rank:
            score *= 2
            # Minimum score for a pair is 5 (for 22)
            if score < 5: score = 5
        
        # Suited
        if c1_suit == c2_suit:
            score += 2
            
        # Gappers
        gap = high_card - low_card - 1
        if gap == 0 and c1_rank != c2_rank: # Connector
            score += 1
        elif gap == 1: # 1-gap
            pass
        elif gap == 2:
            score -= 1
        elif gap == 3:
            score -= 2
        elif gap >= 4:
            score -= 4
        
        # Bonus for connectors under rank 5
        if high_card < 12 and c1_rank != c2_rank and gap < 2:
            score += 1
            
        # Normalize score to be roughly 0-1
        # Max theoretical score for AA is 20. AKs is 13.
        # Let's map this range to 0-1. Max around 20. Let's use 20 as scaler.
        return min(max(score / 20.0, 0), 1)