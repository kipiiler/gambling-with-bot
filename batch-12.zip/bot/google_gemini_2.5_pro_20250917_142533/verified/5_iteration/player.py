import random
import itertools
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that uses a combination of pre-flop hand strength analysis,
    post-flop Monte Carlo equity simulation, and pot odds to make decisions.
    """

    def __init__(self):
        """ Initializes the player, setting up internal state variables. """
        super().__init__()
        self.my_cards: List[str] = []
        self.all_players: List[int] = []
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int = 0
        self.small_blind_player_id: int = 0
        self.hand_evaluator = HandEvaluator()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once at the start of the game.
        Initializes game-level information.
        """
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # player_hands at the start is just the first hand.
        # on_round_start will be called for the first round,
        # so we can handle it there.
        # However, the framework might send hands here, so better be safe.
        self.my_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each new hand.
        `player_hands` is passed in on_start and not updated, so we need to get our hand from the round_state if possible.
        The template shows player_hands in on_start. Assuming it is updated or we manage it ourselves.
        If player_hands is not updated per round, this bot design is flawed.
        Let's assume the framework handles giving us our new hand before a new round.
        The template's on_start receives `player_hands`, which is likely our hand for the first round.
        For subsequent rounds, we might need to rely on other mechanisms not described, or the game re-instantiates the bot.
        Let's assume the simplest case: on_start is called for every hand. If not, this state management needs changing.
        If `on_round_start` is where we get the new hand, we must find it. Let's stick to the given `on_start` signature.
        """
        # The hand for the current round is passed in on_start of the game run
        # but the problem states blind rotate and games continue.
        # This implies we must track our own hand if it's not passed again.
        # Since there's no way to know our new hand, we assume `on_start` is called per hand.
        pass


    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        The main decision-making function for the bot.
        Returns a tuple of (PokerAction, amount).
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet

        can_check = amount_to_call == 0
        can_call = amount_to_call > 0 and remaining_chips >= amount_to_call
        
        # --- PRE-FLOP LOGIC ---
        if round_state.round == 'Preflop':
            preflop_score = self._get_preflop_hand_score(self.my_cards)
            is_pot_unopened = round_state.current_bet == self.blind_amount
            
            # Category 1: Premium hands (Score >= 30: AA, KK, QQ, AKs)
            if preflop_score >= 30:
                if is_pot_unopened:
                    # Open raise to 3x BB
                    raise_amount = self.blind_amount * 3
                else:
                    # Re-raise to 3x the current bet
                    raise_amount = round_state.current_bet * 3
                
                # Ensure raise is valid
                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, round_state.max_raise)
                
                if raise_amount > round_state.current_bet and raise_amount <= remaining_chips:
                    return PokerAction.RAISE, int(raise_amount)
                # If calculated raise isn't enough or affordable, go all-in or call
                return (PokerAction.CALL, 0) if can_call else (PokerAction.ALL_IN, 0)

            # Category 2: Strong hands (Score >= 24: JJ, TT, AQs, AKo)
            elif preflop_score >= 24:
                if is_pot_unopened:
                    # Open raise to 2.5x BB
                    raise_amount = self.blind_amount * 2.5
                    raise_amount = max(raise_amount, round_state.min_raise)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    if raise_amount > round_state.current_bet and raise_amount <= remaining_chips:
                        return PokerAction.RAISE, int(raise_amount)
                
                # If facing a raise, call if it's not too large
                if round_state.current_bet < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0) if can_call else (PokerAction.FOLD, 0)
                return PokerAction.FOLD, 0
                
            # Category 3: Speculative hands (Score >= 18: Mid-pairs, suited connectors)
            elif preflop_score >= 18:
                # Call small raises, check if possible
                if amount_to_call < remaining_chips * 0.05:
                    if can_check: return PokerAction.CHECK, 0
                    if can_call: return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Category 4: Trash hands
            else:
                if can_check and self.id == self.big_blind_player_id:
                    return PokerAction.CHECK, 0 # Free play from BB
                return PokerAction.FOLD, 0

        # --- POST-FLOP LOGIC ---
        else:
            num_opponents = sum(1 for bet in round_state.player_bets.values() if bet >= 0 and str(bet) != str(self.id))
            if num_opponents == 0:
                return PokerAction.CHECK, 0 # Should not happen usually, but take the free pot

            # Estimate equity using Monte Carlo simulation
            equity = self._monte_carlo_equity(self.my_cards, round_state.community_cards, num_opponents)

            # Calculate pot odds
            pot_odds = 0
            if (round_state.pot + amount_to_call) > 0:
                pot_odds = amount_to_call / (round_state.pot + amount_to_call)

            # Decision based on equity
            # Value Bet/Raise (high equity)
            if equity > 0.75:
                if can_check:
                    # Bet 3/4 of the pot
                    bet_amount = int(round_state.pot * 0.75)
                else:
                    # Raise pot-sized
                    bet_amount = int(round_state.pot + 2 * amount_to_call)
                
                bet_amount = max(bet_amount, round_state.min_raise)
                bet_amount = min(bet_amount, round_state.max_raise)
                
                if bet_amount > round_state.current_bet and bet_amount <= remaining_chips:
                    return PokerAction.RAISE, bet_amount
                return (PokerAction.CALL, 0) if can_call else (PokerAction.ALL_IN, 0)

            # Call/Check (medium equity, good pot odds)
            elif equity > pot_odds:
                if can_check:
                    return PokerAction.CHECK, 0
                else: 
                    # Call if the bet is not too large
                    if amount_to_call < remaining_chips * 0.2:
                         return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

            # Semi-Bluff with draws
            elif equity > 0.3 and round_state.round != "River": # Draws have some equity
                if can_check: # semi-bluff
                    bet_amount = int(round_state.pot * 0.5)
                    bet_amount = max(bet_amount, round_state.min_raise)
                    bet_amount = min(bet_amount, round_state.max_raise)
                    if bet_amount > 0 and bet_amount <= remaining_chips:
                        return PokerAction.RAISE, bet_amount
                # Calling a bet with a draw
                elif pot_odds < 0.35 and can_call: # good implied odds if calling cheap
                    return PokerAction.CALL, 0


            # Fold/Bluff (low equity)
            return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. Can be used for learning. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    def _get_preflop_hand_score(self, hand: List[str]) -> float:
        """ Calculates a score for a 2-card pre-flop hand. """
        c1, c2 = hand
        rank1 = self.hand_evaluator.RANKS[c1[0]]
        rank2 = self.hand_evaluator.RANKS[c2[0]]
        suit1 = c1[1]
        suit2 = c2[1]

        r1, r2 = sorted([rank1, rank2], reverse=True)
        is_suited = suit1 == suit2
        is_pair = r1 == r2
        gap = r1 - r2 - 1

        score = (r1 + r2) / 2.0  # Base value from high cards

        if is_pair:
            score = max(20, r1 * 2) # Pairs are very strong
        
        if is_suited:
            score += 4

        if gap == 0: # Connector
            score += 5
        elif gap == 1: # One-gapper
            score += 2
        elif gap == 2: # Two-gapper
            score += 1
        
        # Penalize large gaps
        if gap > 2:
            score -= gap
            
        return score

    def _monte_carlo_equity(self, my_cards: List[str], community: List[str], num_opponents: int, iterations: int = 500) -> float:
        """
        Estimates hand equity using Monte Carlo simulation.
        """
        deck = [r + s for r in self.hand_evaluator.RANKS.keys() for s in self.hand_evaluator.SUITS.keys()]
        
        # Remove known cards from deck
        for card in my_cards + community:
            if card in deck:
                deck.remove(card)

        my_hand_val = [self.hand_evaluator.to_card_val(c) for c in my_cards]
        community_val = [self.hand_evaluator.to_card_val(c) for c in community]

        wins = 0
        ties = 0

        for _ in range(iterations):
            sim_deck = deck[:]
            random.shuffle(sim_deck)
            
            # Deal cards to opponents and remaining community cards
            opponents_hands = []
            for _ in range(num_opponents):
                opponents_hands.append([
                    self.hand_evaluator.to_card_val(sim_deck.pop()),
                    self.hand_evaluator.to_card_val(sim_deck.pop())
                ])
                
            num_remaining_community = 5 - len(community)
            sim_community = community_val + [self.hand_evaluator.to_card_val(c) for c in sim_deck[:num_remaining_community]]
            
            # Evaluate hands
            my_best = self.hand_evaluator.evaluate(my_hand_val, sim_community)
            
            opp_best = max(self.hand_evaluator.evaluate(opp_hand, sim_community) for opp_hand in opponents_hands) if opponents_hands else (0,)

            if my_best > opp_best:
                wins += 1
            elif my_best == opp_best:
                ties += 1

        return (wins + ties / 2.0) / iterations


class HandEvaluator:
    """
    A helper class for evaluating poker hands.
    Converts cards to numerical values and determines the best 5-card hand from 7 cards.
    """
    
    RANKS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    SUITS = {'s': 1, 'h': 2, 'd': 3, 'c': 4}

    def to_card_val(self, card_str: str) -> Tuple[int, int]:
        """ Converts a card string like 'Ah' to a tuple (14, 2). """
        return (self.RANKS[card_str[0]], self.SUITS[card_str[1]])

    def evaluate(self, hole_cards: List[Tuple[int, int]], community_cards: List[Tuple[int, int]]) -> tuple:
        """
        Evaluates the best 5-card hand from a 7-card combination.
        Returns a tuple representing hand rank for comparison.
        """
        all_cards = hole_cards + community_cards
        best_rank = (0,)

        for combo in itertools.combinations(all_cards, 5):
            current_rank = self._evaluate_5_card_hand(list(combo))
            if current_rank > best_rank:
                best_rank = current_rank
        
        return best_rank

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, int]]) -> tuple:
        """
        Evaluates a 5-card hand.
        Hand rank tuple format: (category, high_card_1, high_card_2, ...)
        """
        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]

        is_flush = len(set(suits)) == 1
        
        # Check for straight
        is_straight = (ranks[0] - ranks[4] == 4 and len(set(ranks)) == 5)
        # Ace-low straight (A, 2, 3, 4, 5)
        is_ace_low_straight = (ranks == [14, 5, 4, 3, 2])
        if is_ace_low_straight:
            ranks = [5, 4, 3, 2, 1] # Treat Ace as 1 for ranking
            is_straight = True

        # Check for flush and straight combinations
        if is_straight and is_flush:
            return (9, *ranks)  # Straight Flush (Royal Flush is just the highest straight flush)
        
        # Count rank occurrences
        rank_counts = {rank: ranks.count(rank) for rank in ranks}
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4: # Four of a Kind
            four_kind = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (8, four_kind, kicker)
        
        if counts == [3, 2]: # Full House
            three_kind = [r for r, c in rank_counts.items() if c == 3][0]
            pair = [r for r, c in rank_counts.items() if c == 2][0]
            return (7, three_kind, pair)

        if is_flush:
            return (6, *ranks) # Flush
        
        if is_straight:
            return (5, *ranks) # Straight
            
        if counts[0] == 3: # Three of a Kind
            three_kind = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (4, three_kind, *kickers)

        if counts == [2, 2, 1]: # Two Pair
            pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (3, *pairs, kicker)

        if counts[0] == 2: # One Pair
            pair = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (2, pair, *kickers)
            
        return (1, *ranks) # High Card