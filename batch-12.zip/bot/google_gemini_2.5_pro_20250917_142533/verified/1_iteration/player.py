from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import collections
from itertools import combinations

class SimplePlayer(Bot):
    """
    A poker bot for No-Limit Texas Hold'em.
    This bot uses a strategy based on hand strength, position, and pot odds.
    - Pre-flop: Uses a hand-ranking chart to decide whether to fold, call, or raise. It plays tighter in early positions and looser in late positions.
    - Post-flop: Evaluates the current hand strength (pair, two-pair, etc.) and draw potential (flush/straight draws).
    - Betting:
        - With strong made hands, it bets for value.
        - With strong draws, it plays aggressively (semi-bluff) or calls if pot odds are favorable.
        - With weak hands, it tends to check or fold to aggression.
    - It is designed to be robust and avoid making invalid moves.
    """

    def __init__(self):
        super().__init__()
        self.all_my_hands: List[List[str]] = []
        self.hole_cards: List[str] = []
        
        self.initial_chips: int = 0
        self.big_blind_amount: int = 0
        self.small_blind_amount: int = 0
        
        # Player IDs
        self.all_player_ids: List[int] = []
        self.big_blind_player_id: int = 0
        self.small_blind_player_id: int = 0

        # Pre-flop hand strength tiers (1 is strongest)
        self.preflop_hand_tiers = {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs'],
            2: ['TT', 'AQs', 'AJs', 'KQs', 'AKo'],
            3: ['99', '88', 'JTs', 'QJs', 'KJs', 'ATs', 'AQo'],
            4: ['77', '66', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 'AJo', 'KQo'],
            5: ['55', '44', '33', '22', 'K9s', 'K8s', 'Q9s', 'T8s', '97s', '87s', '76s', '65s', '54s', 'ATo', 'KJo', 'QJo'],
            6: ['K7s', 'K6s', 'K5s', 'K4s', 'K3s', 'K2s', 'Q8s', 'J8s', 'T7s', '86s', '75s', '64s', 'A9o', 'KTo', 'QTo'],
        }
        self.hand_to_tier: Dict[str, int] = {}
        for tier, hands in self.preflop_hand_tiers.items():
            for hand in hands:
                self.hand_to_tier[hand] = tier

    # --- Card and Hand Evaluation Utilities ---

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """Converts a card string like 'Ah' to a tuple (rank, suit), e.g., (14, 'h')."""
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank_str = card_str[:-1]
        suit = card_str[-1]
        rank = rank_map.get(rank_str) or int(rank_str)
        return (rank, suit)

    def _canonicalize_hand(self, hole_cards: List[str]) -> str:
        """Converts two hole cards into a standardized string like 'AKs' or 'T9o'."""
        c1, c2 = self._parse_card(hole_cards[0]), self._parse_card(hole_cards[1])
        r1, s1 = c1
        r2, s2 = c2
        
        suited = 's' if s1 == s2 else 'o'
        rank_map = {14: 'A', 13: 'K', 12: 'Q', 11: 'J', 10: 'T'}
        
        if r1 < r2: r1, r2 = r2, r1
            
        rank1_str = rank_map.get(r1, str(r1))
        rank2_str = rank_map.get(r2, str(r2))
        
        if r1 == r2:
            return f"{rank1_str}{rank2_str}"
        else:
            return f"{rank1_str}{rank2_str}{suited}"

    def _evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple:
        """
        Evaluates 5 to 7 cards and returns the best 5-card hand score.
        Score is a tuple for direct comparison: (rank, primary_ranks, secondary_ranks, kickers)
        - rank: 9 (Royal Flush) down to 0 (High Card)
        """
        all_cards_str = hole_cards + community_cards
        if not all_cards_str or len(all_cards_str) < 5:
            return (0, [0], [0], [0])
            
        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        best_hand_score = (-1,)
        for hand_combo in combinations(all_cards, 5):
            score = self._evaluate_5_card_hand(list(hand_combo))
            if score > best_hand_score:
                best_hand_score = score
                
        return best_hand_score

    def _evaluate_5_card_hand(self, hand: List[Tuple[int, str]]) -> Tuple:
        """Evaluates exactly 5 cards and returns a score tuple."""
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]

        is_flush = len(set(suits)) == 1
        is_straight = (len(set(ranks)) == 5 and ranks[0] - ranks[4] == 4) or \
                      (ranks == [14, 5, 4, 3, 2])

        if is_straight and is_flush:
            high_card = 5 if ranks == [14, 5, 4, 3, 2] else ranks[0]
            return (8, high_card) 
        
        rank_counts = collections.Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4:
            quad_rank = [r for r, c in rank_counts.items() if c == 4][0]
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (7, quad_rank, kicker)
        
        if counts == [3, 2]:
            trio_rank = [r for r, c in rank_counts.items() if c == 3][0]
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            return (6, trio_rank, pair_rank)

        if is_flush:
            return (5, tuple(ranks))

        if is_straight:
            high_card = 5 if ranks == [14, 5, 4, 3, 2] else ranks[0]
            return (4, high_card)

        if counts[0] == 3:
            trio_rank = [r for r, c in rank_counts.items() if c == 3][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (3, trio_rank, tuple(kickers))

        if counts == [2, 2]:
            pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
            kicker = [r for r, c in rank_counts.items() if c == 1][0]
            return (2, tuple(pair_ranks), kicker)

        if counts[0] == 2:
            pair_rank = [r for r, c in rank_counts.items() if c == 2][0]
            kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
            return (1, pair_rank, tuple(kickers))
        
        return (0, tuple(ranks))

    def _calculate_outs(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, int]:
        """Calculates flush and straight outs."""
        all_cards = [self._parse_card(c) for c in hole_cards + community_cards]
        ranks = {c[0] for c in all_cards}
        suits = collections.Counter(c[1] for c in all_cards)
        
        flush_outs = 0
        for suit, count in suits.items():
            if count == 4:
                flush_outs = 13 - len([c for c in all_cards if c[1] == suit])
                break

        straight_outs = 0
        # Check for open-ended or gutshot draws
        unique_ranks = sorted(list(ranks))
        for i in range(len(unique_ranks) - 3):
             # 4 cards in a 5-card window -> straight draw
            if unique_ranks[i+3] - unique_ranks[i] <= 4:
                # This is a simplification; for a robust count, one must check all combinations
                # Let's use a simpler heuristic
                is_open_ended = unique_ranks[i+3] - unique_ranks[i] == 3
                straight_outs = 8 if is_open_ended else 4

        return flush_outs, straight_outs

    # --- Game State and Strategy Helpers ---

    def _get_num_active_players(self, round_state: RoundStateClient) -> int:
        """Counts players who have not folded."""
        folded_players = {pid for pid, action in round_state.player_actions.items() if action == 'Fold'}
        return len(self.all_player_ids) - len(folded_players)

    def _get_position_info(self, round_state: RoundStateClient) -> Tuple[str, int]:
        """Determines our position: 'early', 'middle', 'late', or 'blinds'."""
        if self.id == self.big_blind_player_id or self.id == self.small_blind_player_id: return "blinds", 0
        
        my_turn_index = round_state.current_player.index(self.id) if self.id in round_state.current_player else -1
        players_to_act_after = len(round_state.current_player) - my_turn_index - 1
        
        if players_to_act_after <= 1: return "late", 2
        if players_to_act_after <= 3: return "middle", 1
        return "early", 0

    # --- Bot Lifecycle Methods ---
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_chips = starting_chips
        self.all_my_hands = player_hands
        self.all_player_ids = all_players
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        hand_index = round_state.round_num - 1
        if hand_index < len(self.all_my_hands):
            self.hole_cards = self.all_my_hands[hand_index]
        else:
            self.hole_cards = [] 

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Main decision-making function """
        
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        can_check = amount_to_call == 0

        # --- PRE-FLOP ---
        if round_state.round == 'Preflop':
            if not self.hole_cards: return PokerAction.FOLD, 0
            
            if round_state.current_bet > self.big_blind_amount and all(v in [0, self.small_blind_amount] for k, v in round_state.player_bets.items() if k != str(self.big_blind_player_id)):
                self.big_blind_amount = round_state.current_bet
            
            canonical_hand = self._canonicalize_hand(self.hole_cards)
            tier = self.hand_to_tier.get(canonical_hand, 99)
            
            position_name, position_val = self._get_position_info(round_state)
            
            limpers = len([bet for bet in round_state.player_bets.values() if bet == self.big_blind_amount]) -1
            is_raised = round_state.current_bet > self.big_blind_amount

            playability_threshold = 4
            if position_name == 'middle': playability_threshold = 5
            if position_name == 'late': playability_threshold = 6

            if tier <= 2:
                if not is_raised:
                    raise_amount = (3 + limpers) * self.big_blind_amount
                else:
                    raise_amount = 3 * round_state.current_bet
                
                if remaining_chips <= raise_amount * 1.5 : return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, int(raise_amount)))

            if tier <= playability_threshold:
                if not is_raised:
                    if position_val > 0: 
                        raise_amount = (2.5 + limpers) * self.big_blind_amount
                        return PokerAction.RAISE, min(remaining_chips, max(round_state.min_raise, int(raise_amount)))
                    else: 
                        return PokerAction.CALL, 0
                else:
                    if amount_to_call < remaining_chips * 0.1 and amount_to_call < 5 * self.big_blind_amount:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            
            if position_name == "blinds" and is_raised and amount_to_call <= 2 * self.big_blind_amount:
                return PokerAction.CALL, 0

            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # --- POST-FLOP ---
        else:
            hand_eval = self._evaluate_hand(self.hole_cards, round_state.community_cards)
            hand_rank = hand_eval[0]
            
            flush_outs, straight_outs = self._calculate_outs(self.hole_cards, round_state.community_cards)
            total_outs = flush_outs + straight_outs
            
            pot_size = round_state.pot
            is_strong_draw = total_outs >= 8
            is_monster_hand = hand_rank >= 6 
            is_very_strong_hand = hand_rank >= 3 
            is_good_hand = hand_rank >= 2 

            if round_state.round == 'River': is_strong_draw = False

            pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9) if amount_to_call > 0 else 0

            if is_monster_hand:
                if remaining_chips < pot_size * 2: return PokerAction.ALL_IN, 0
                if can_check:
                    bet_amount = int(pot_size * 0.75)
                    return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, bet_amount))
                else: 
                    raise_amount = int(2.5 * round_state.current_bet + pot_size)
                    return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, raise_amount))

            if is_very_strong_hand or is_good_hand:
                bet_amount = int(pot_size * 0.6)
                if can_check:
                    return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, bet_amount))
                else:
                    if amount_to_call < remaining_chips * 0.3 and amount_to_call < pot_size:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            
            if is_strong_draw:
                draw_prob = total_outs / (52 - len(self.hole_cards) - len(round_state.community_cards))
                if draw_prob > pot_odds:
                    if can_check:
                        bet_amount = int(pot_size * 0.5)
                        return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, bet_amount))
                    else: 
                        if amount_to_call < remaining_chips * 0.2:
                           return PokerAction.CALL, 0
                        else:
                           return PokerAction.FOLD, 0
                else:
                    return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)
            
            if hand_rank == 1:
                if can_check:
                    return PokerAction.CHECK, 0
                else:
                    if amount_to_call < pot_size * 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)