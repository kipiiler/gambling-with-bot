from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.all_players = []
        self.starting_chips = 10000
        self.my_chips = 10000

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.my_chips = starting_chips
        self.all_players = all_players
        if self.id == big_blind_player_id:
            self.is_big_blind = True
        else:
            self.is_big_blind = False
        if self.id == small_blind_player_id:
            self.is_small_blind = True
        else:
            self.is_small_blind = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update my chip count
        self.my_chips = remaining_chips
        
        # Get my current bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        pot_odds = amount_to_call / (round_state.pot + amount_to_call) if (round_state.pot + amount_to_call) > 0 else 0
        
        # Check if we can check (no bet to call)
        if amount_to_call == 0:
            # We can check, decide whether to check or bet
            hand_strength = self._evaluate_hand_strength(round_state)
            if hand_strength > 0.7 or random.random() < 0.3:  # Strong hand or bluff
                # Decide bet amount - ensure it's valid
                min_bet = round_state.min_raise
                max_bet = min(round_state.max_raise, remaining_chips)
                if min_bet <= max_bet:
                    bet_amount = min(max(min_bet, int(0.5 * round_state.pot)), max_bet)
                    return (PokerAction.RAISE, bet_amount)
            return (PokerAction.CHECK, 0)
        else:
            # There is a bet to call
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # If we have a strong hand or good pot odds, call or raise
            if hand_strength > 0.8 or (hand_strength > 0.5 and pot_odds < 0.3):
                # Raise with strong hands
                if hand_strength > 0.85 and round_state.max_raise > amount_to_call:
                    min_raise = round_state.min_raise
                    max_raise = min(round_state.max_raise, remaining_chips)
                    if min_raise <= max_raise:
                        raise_amount = min(max(min_raise, amount_to_call * 2), max_raise)
                        # Make sure raise is valid
                        if raise_amount + my_current_bet > round_state.current_bet:
                            return (PokerAction.RAISE, raise_amount)
                # Otherwise just call
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
            
            # Fold in other cases
            return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Simple hand strength evaluation"""
        if not self.hole_cards:
            return 0.0
            
        # Basic hand ranking logic
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Parse hole cards
        card1_rank = self.hole_cards[0][0]
        card2_rank = self.hole_cards[1][0]
        card1_suit = self.hole_cards[0][1]
        card2_suit = self.hole_cards[1][1]
        
        rank1_val = rank_values[card1_rank]
        rank2_val = rank_values[card2_rank]
        
        # Check for pocket pair
        if card1_rank == card2_rank:
            # Pocket pair strength (higher is better)
            return min(0.5 + (rank1_val / 14) * 0.5, 0.95)
        
        # Check for suited connectors
        is_suited = card1_suit == card2_suit
        rank_diff = abs(rank1_val - rank2_val)
        
        # High cards
        high_card_value = max(rank1_val, rank2_val) / 14
        low_card_value = min(rank1_val, rank2_val) / 14
        
        # Base strength on high card
        strength = high_card_value * 0.6
        
        # Bonus for suited
        if is_suited:
            strength += 0.1
            
        # Bonus for connectors (1 gap or less)
        if rank_diff <= 2:
            strength += 0.1
            
        # Bonus for high cards
        if high_card_value > 0.8:  # T, J, Q, K, A
            strength += 0.15
        elif high_card_value > 0.6:  # 8, 9
            strength += 0.05
            
        return min(strength, 0.95)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass