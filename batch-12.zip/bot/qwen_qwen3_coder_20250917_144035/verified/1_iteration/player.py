from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.remaining_chips = 0
        self.round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.round_state = round_state
        self.remaining_chips = remaining_chips

        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Preflop strategy
        if round_state.round == 'Preflop':
            hand_strength = self.evaluate_preflop_hand(self.hand)
            if hand_strength >= 8:  # Premium hands
                if to_call <= remaining_chips * 0.1:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        raise_amount = min(max_raise, max(min_raise, remaining_chips * 0.1))
                        return (PokerAction.RAISE, int(raise_amount))
                else:
                    if to_call <= remaining_chips * 0.25:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            elif hand_strength >= 5:  # Medium strength hands
                if to_call <= remaining_chips * 0.05:
                    if to_call > 0:
                        return (PokerAction.CALL, 0)
                    else:
                        raise_amount = min(max_raise, max(min_raise, remaining_chips * 0.05))
                        return (PokerAction.RAISE, int(raise_amount))
                else:
                    if to_call <= remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:  # Weak hands
                if to_call == 0:
                    if random.random() < 0.5:
                        raise_amount = min(max_raise, max(min_raise, remaining_chips * 0.02))
                        return (PokerAction.RAISE, int(raise_amount))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if to_call <= remaining_chips * 0.02:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        # Postflop strategy
        else:
            hand_rank = self.evaluate_hand(self.hand, round_state.community_cards)
            
            # Aggressive with strong hands
            if hand_rank >= 3:  # Two pair or better
                if to_call == 0:
                    raise_amount = min(max_raise, max(min_raise, remaining_chips * 0.2))
                    return (PokerAction.RAISE, int(raise_amount))
                else:
                    if hand_rank >= 5:  # Flush or better
                        if to_call <= remaining_chips * 0.5:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.ALL_IN, 0)
                    elif hand_rank >= 3:  # Two pair or better
                        if to_call <= remaining_chips * 0.3:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
            
            # Conservative with weak hands
            elif hand_rank >= 1:  # One pair
                if to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Very weak hands
            else:
                if to_call == 0:
                    if random.random() < 0.3:
                        raise_amount = min(max_raise, max(min_raise, remaining_chips * 0.05))
                        return (PokerAction.RAISE, int(raise_amount))
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if to_call <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        # Default fallback
        if to_call <= remaining_chips * 0.05:
            return (PokerAction.CALL, 0)
        elif to_call == 0:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def evaluate_preflop_hand(self, hand: List[str]) -> int:
        """Evaluate pre-flop hand strength (0-10 scale)"""
        if len(hand) != 2:
            return 0
            
        ranks = [card[0] for card in hand]
        suits = [card[1] for card in hand]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        r1 = rank_values[ranks[0]]
        r2 = rank_values[ranks[1]]
        
        # Pair
        if r1 == r2:
            if r1 >= 13:  # AA, KK, QQ
                return 10
            elif r1 >= 10:  # JJ, TT
                return 9
            elif r1 >= 8:  # 88, 99
                return 7
            else:  # Small pairs
                return 5
        
        # High cards
        high_card = max(r1, r2)
        low_card = min(r1, r2)
        
        # Ace-King, Ace-Queen, Ace-Jack
        if high_card == 14 and low_card >= 12:
            return 9
        elif high_card == 14 and low_card >= 10:
            return 7
        elif high_card == 14:
            return 6
            
        # Connected cards
        if abs(r1 - r2) == 1:
            if high_card >= 10:
                return 6
            elif high_card >= 8:
                return 5
            else:
                return 4
                
        # Suited cards
        if suits[0] == suits[1]:
            if high_card >= 12:
                return 6
            elif high_card >= 10:
                return 5
            else:
                return 4
        
        # General high cards
        if high_card >= 12:
            return 5
        elif high_card >= 10:
            return 4
        else:
            return 3

    def evaluate_hand(self, hand: List[str], community_cards: List[str]) -> int:
        """Evaluate hand strength (0-8 scale) - simplified version"""
        all_cards = hand + community_cards
        
        if len(all_cards) < 5:
            return 0
            
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        flush = False
        for count in suit_counts.values():
            if count >= 5:
                flush = True
                
        # Check for straight
        ranks = sorted([rank_values[r] for r in rank_counts.keys()], reverse=True)
        straight = False
        if len(ranks) >= 5:
            for i in range(len(ranks) - 4):
                if ranks[i] - ranks[i+4] == 4:
                    straight = True
                    break
            # Check for wheel (A-2-3-4-5)
            if set([14, 2, 3, 4, 5]).issubset(set(ranks)):
                straight = True
                
        # Check for straight flush
        straight_flush = straight and flush
        
        # Count rank patterns
        counts = list(rank_counts.values())
        counts.sort(reverse=True)
        
        # Royal flush
        if straight_flush and 14 in ranks and 13 in ranks and 12 in ranks and 11 in ranks and 10 in ranks:
            return 8
        # Straight flush
        elif straight_flush:
            return 7
        # Four of a kind
        elif counts[0] == 4:
            return 6
        # Full house
        elif counts[0] == 3 and counts[1] >= 2:
            return 5
        # Flush
        elif flush:
            return 4
        # Straight
        elif straight:
            return 3
        # Three of a kind
        elif counts[0] == 3:
            return 2
        # Two pair
        elif counts[0] == 2 and counts[1] == 2:
            return 1
        # One pair or high card
        else:
            return 0