from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.remaining_chips = 0
        self.round_state = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.remaining_chips = remaining_chips

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if not hole_cards:
            return 0.0
            
        # Convert cards to ranks and suits
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        hole_ranks = [ranks[card[0]] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # Basic hand strength heuristic
        strength = 0.0
        
        # High card value
        strength += max(hole_ranks) / 14.0
        
        # Pair bonus
        if hole_ranks[0] == hole_ranks[1]:
            strength += 0.2 + (hole_ranks[0] / 14.0) * 0.3
        
        # Connected cards bonus
        if abs(hole_ranks[0] - hole_ranks[1]) == 1:
            strength += 0.1
            
        # Suited cards bonus
        if hole_suits[0] == hole_suits[1]:
            strength += 0.15
            
        # Adjust based on community cards
        if community_cards:
            comm_ranks = [ranks[card[0]] for card in community_cards]
            comm_suits = [card[1] for card in community_cards]
            
            # Potential straight/flush draws
            all_ranks = hole_ranks + comm_ranks
            all_suits = hole_suits + comm_suits
            
            # Flush draw
            for suit in set(all_suits):
                if all_suits.count(suit) >= 4:
                    strength += 0.1
                    
            # Straight draw
            unique_ranks = sorted(list(set(all_ranks)))
            if len(unique_ranks) >= 4:
                consecutive = 0
                for i in range(len(unique_ranks)-1):
                    if unique_ranks[i+1] - unique_ranks[i] == 1:
                        consecutive += 1
                if consecutive >= 3:
                    strength += 0.1
        
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate pot odds
        pot_odds = to_call / (round_state.pot + to_call + 1e-8) if round_state.pot + to_call > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Position awareness (simplified)
        is_preflop = round_state.round == "Preflop"
        is_blind = (self.id == self.big_blind_player_id or self.id == self.small_blind_player_id)
        
        # Aggression factor based on position and hand strength
        aggressive = hand_strength > 0.6 or (not is_preflop and hand_strength > 0.4)
        very_aggressive = hand_strength > 0.8
        
        # Decision logic
        if to_call == 0:
            # We can check
            if very_aggressive:
                raise_amount = min(max_raise, max(min_raise, int(0.5 * round_state.pot)))
                if raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif aggressive and not is_preflop:
                raise_amount = min(max_raise, max(min_raise, int(0.3 * round_state.pot)))
                if raise_amount <= max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # We need to call, fold, or raise
            if very_aggressive:
                # Re-raise or call
                if random.random() < 0.7:  # 70% chance to re-raise
                    raise_amount = min(max_raise, max(min_raise, int(2.5 * to_call)))
                    if raise_amount <= max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            elif aggressive and pot_odds < hand_strength:
                # Call if odds are favorable
                return (PokerAction.CALL, 0)
            elif hand_strength > 0.3 and pot_odds < hand_strength / 2:
                # Call with decent hands if odds are very favorable
                return (PokerAction.CALL, 0)
            elif is_preflop and is_blind and hand_strength > 0.25:
                # Defend blinds with reasonable hands
                return (PokerAction.CALL, 0)
            else:
                # Fold otherwise
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass