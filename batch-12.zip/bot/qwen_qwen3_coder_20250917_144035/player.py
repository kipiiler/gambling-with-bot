from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_position = 0
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        if self.id == big_blind_player_id:
            self.is_big_blind = True
        else:
            self.is_big_blind = False
            
        if self.id == small_blind_player_id:
            self.is_small_blind = True
        else:
            self.is_small_blind = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset position tracking for new round if needed
        pass

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Basic hand strength evaluation"""
        if not self.hole_cards:
            return 0.0
            
        # Simplified hand strength based on hole cards and board
        strength = 0.5  # Default baseline
        
        ranks = [card[0] for card in self.hole_cards]
        suits = [card[1] for card in self.hole_cards]
        
        # Pocket pairs
        if ranks[0] == ranks[1]:
            if ranks[0] in ['A', 'K', 'Q', 'J']:
                strength = 0.8
            elif ranks[0] in ['T', '9']:
                strength = 0.7
            else:
                strength = 0.6
        # High cards
        elif 'A' in ranks or 'K' in ranks:
            if 'A' in ranks and 'K' in ranks:
                strength = 0.75
            else:
                strength = 0.65
        # Suited connectors
        elif suits[0] == suits[1] and abs(ord(ranks[0]) - ord(ranks[1])) <= 2:
            strength = 0.6
        
        # Adjust based on community cards and round
        if round_state.round == "Flop":
            strength *= 0.9
        elif round_state.round == "Turn":
            strength *= 0.85
        elif round_state.round == "River":
            strength *= 0.8
            
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Positional adjustment
        positional_bonus = 0
        if hasattr(self, 'is_big_blind') and self.is_big_blind and round_state.round == "Preflop":
            positional_bonus = -0.1  # Play tighter in big blind
        
        adjusted_strength = hand_strength + positional_bonus
        
        # Make decision based on hand strength and pot odds
        if call_amount == 0:
            # We can check
            if adjusted_strength > 0.6 or random.random() < 0.3:  # Sometimes bet even with weak hand
                # Decide on raise amount
                if max_raise >= min_raise:
                    raise_amount = min(max(min_raise, int(remaining_chips * 0.1)), max_raise)
                    if raise_amount + my_current_bet > current_bet:  # Valid raise
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # We need to call, fold, or raise
            pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
            
            if adjusted_strength > 0.8 or pot_odds < adjusted_strength:
                # Good enough to call or raise
                if adjusted_strength > 0.7 and max_raise >= min_raise:
                    # Consider raising
                    raise_amount = min(max(min_raise, int(remaining_chips * 0.15)), max_raise)
                    if raise_amount + my_current_bet > current_bet:  # Valid raise
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # Not good enough, fold
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up any round-specific state if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup
        pass