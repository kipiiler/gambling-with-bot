from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.opponent_types = {}  # Track opponent tendencies
        self.my_actions = []      # Track my own actions
        self.round_count = 0
        self.wins = 0
        self.losses = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands[0] if player_hands else None
        self.big_blind = blind_amount
        self.all_players = all_players
        self.position = self._determine_position(big_blind_player_id, small_blind_player_id)
        
    def _determine_position(self, bb_player_id: int, sb_player_id: int) -> str:
        if self.id == bb_player_id:
            return "big_blind"
        elif self.id == sb_player_id:
            return "small_blind"
        else:
            return "other"
            
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1
        self.current_round = round_state.round
        self.community_cards = round_state.community_cards
        self.pot = round_state.pot
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            hand_strength = self._evaluate_hand_strength()
            pot_odds = self._calculate_pot_odds(round_state)
            position_factor = self._get_position_factor()
            aggression_factor = self._get_aggression_factor()
            
            # Base decision on hand strength and situation
            if hand_strength >= 0.8:  # Premium hand
                return self._play_premium_hand(round_state, remaining_chips)
            elif hand_strength >= 0.6:  # Strong hand
                return self._play_strong_hand(round_state, remaining_chips, pot_odds)
            elif hand_strength >= 0.4:  # Medium hand
                return self._play_medium_hand(round_state, remaining_chips, pot_odds, position_factor)
            else:  # Weak hand
                return self._play_weak_hand(round_state, remaining_chips, pot_odds, aggression_factor)
                
        except Exception as e:
            # Fallback to conservative play
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.my_hand:
            return 0.0
            
        hole_cards = self.my_hand.split()
        if len(hole_cards) != 2:
            return 0.0
            
        # Parse cards
        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1, r2 = rank_values.get(rank1, 0), rank_values.get(rank2, 0)
        
        # Premium pairs
        if rank1 == rank2:
            if r1 >= 12:  # QQ, KK, AA
                return 0.9
            elif r1 >= 9:  # 99, TT, JJ
                return 0.75
            elif r1 >= 6:  # 66, 77, 88
                return 0.6
            else:
                return 0.4
                
        # Suited cards
        suited = suit1 == suit2
        high_card = max(r1, r2)
        low_card = min(r1, r2)
        gap = high_card - low_card
        
        # Premium suited connectors
        if suited and gap <= 1 and high_card >= 12:
            return 0.8
        elif suited and gap <= 2 and high_card >= 11:
            return 0.7
        elif suited and gap <= 3 and high_card >= 10:
            return 0.6
            
        # Premium unsuited
        if high_card >= 13 and gap <= 2:
            return 0.65
        elif high_card >= 12 and gap <= 1:
            return 0.55
        elif high_card >= 11:
            return 0.45
            
        # Weak hands
        return 0.2
        
    def _calculate_pot_odds(self, round_state: RoundStateClient) -> float:
        """Calculate pot odds as percentage"""
        if round_state.current_bet == 0:
            return 0.0
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if call_amount <= 0:
            return 0.0
        return call_amount / (round_state.pot + call_amount + 1e-6)
        
    def _get_position_factor(self) -> float:
        """Get position advantage factor"""
        if self.position == "small_blind":
            return 1.1
        elif self.position == "big_blind":
            return 1.0
        else:
            return 1.2
            
    def _get_aggression_factor(self) -> float:
        """Calculate aggression based on recent actions"""
        if not self.my_actions:
            return 1.0
            
        recent_actions = self.my_actions[-10:]
        aggressive_actions = sum(1 for action, _ in recent_actions if action in [PokerAction.RAISE, PokerAction.ALL_IN])
        return 0.5 + (aggressive_actions / len(recent_actions)) * 1.5
        
    def _play_premium_hand(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Play premium hands aggressively"""
        if round_state.current_bet == 0:
            raise_amount = max(round_state.min_raise, int(round_state.pot * 0.75))
            if raise_amount <= remaining_chips:
                self.my_actions.append((PokerAction.RAISE, raise_amount))
                return (PokerAction.RAISE, raise_amount)
            else:
                self.my_actions.append((PokerAction.ALL_IN, 0))
                return (PokerAction.ALL_IN, 0)
        else:
            call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
            if call_amount >= remaining_chips * 0.5:
                self.my_actions.append((PokerAction.ALL_IN, 0))
                return (PokerAction.ALL_IN, 0)
            else:
                raise_amount = max(round_state.min_raise, int(round_state.current_bet * 1.5))
                if raise_amount <= remaining_chips:
                    self.my_actions.append((PokerAction.RAISE, raise_amount))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    self.my_actions.append((PokerAction.ALL_IN, 0))
                    return (PokerAction.ALL_IN, 0)
                    
    def _play_strong_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Play strong hands with good strategy"""
        if pot_odds < 0.3:  # Good pot odds
            if round_state.current_bet == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.5))
                if raise_amount <= remaining_chips:
                    self.my_actions.append((PokerAction.RAISE, raise_amount))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    self.my_actions.append((PokerAction.CHECK, 0))
                    return (PokerAction.CHECK, 0)
            else:
                if round_state.current_bet <= round_state.player_bets.get(str(self.id), 0) + remaining_chips * 0.2:
                    self.my_actions.append((PokerAction.CALL, 0))
                    return (PokerAction.CALL, 0)
                else:
                    raise_amount = max(round_state.min_raise, round_state.current_bet)
                    if raise_amount <= remaining_chips:
                        self.my_actions.append((PokerAction.RAISE, raise_amount))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        self.my_actions.append((PokerAction.CALL, 0))
                        return (PokerAction.CALL, 0)
        else:  # Bad pot odds
            if round_state.current_bet == 0:
                self.my_actions.append((PokerAction.CHECK, 0))
                return (PokerAction.CHECK, 0)
            else:
                self.my_actions.append((PokerAction.FOLD, 0))
                return (PokerAction.FOLD, 0)
                
    def _play_medium_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float, position_factor: float) -> Tuple[PokerAction, int]:
        """Play medium hands cautiously"""
        adjusted_pot_odds = pot_odds / position_factor
        
        if adjusted_pot_odds < 0.25:
            if round_state.current_bet == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.3))
                if raise_amount <= remaining_chips and self.current_round == 'Preflop':
                    self.my_actions.append((PokerAction.RAISE, raise_amount))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    self.my_actions.append((PokerAction.CHECK, 0))
                    return (PokerAction.CHECK, 0)
            else:
                if round_state.current_bet <= round_state.player_bets.get(str(self.id), 0) + remaining_chips * 0.15:
                    self.my_actions.append((PokerAction.CALL, 0))
                    return (PokerAction.CALL, 0)
                else:
                    self.my_actions.append((PokerAction.FOLD, 0))
                    return (PokerAction.FOLD, 0)
        else:
            if round_state.current_bet == 0:
                self.my_actions.append((PokerAction.CHECK, 0))
                return (PokerAction.CHECK, 0)
            else:
                self.my_actions.append((PokerAction.FOLD, 0))
                return (PokerAction.FOLD, 0)
                
    def _play_weak_hand(self, round_state: RoundStateClient, remaining_chips: int, pot_odds: float, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Play weak hands conservatively with occasional bluffs"""
        # Occasional bluff based on aggression factor
        bluff_chance = 0.1 * aggression_factor
        
        if round_state.current_bet == 0:
            if self.current_round == 'Preflop' and bluff_chance > 0.3:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.4))
                if raise_amount <= remaining_chips:
                    self.my_actions.append((PokerAction.RAISE, raise_amount))
                    return (PokerAction.RAISE, raise_amount)
            self.my_actions.append((PokerAction.CHECK, 0))
            return (PokerAction.CHECK, 0)
        else:
            if pot_odds < 0.1:  # Very good pot odds
                self.my_actions.append((PokerAction.CALL, 0))
                return (PokerAction.CALL, 0)
            else:
                self.my_actions.append((PokerAction.FOLD, 0))
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        if player_score > 0:
            self.wins += 1
        else:
            self.losses += 1