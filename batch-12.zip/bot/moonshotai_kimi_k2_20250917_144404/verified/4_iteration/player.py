from typing import List, Tuple, Dict, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.blind_amount = 10
        self.all_players = []
        self.opponent_id = None
        self.my_bet = 0
        self.hole_cards = []
        self.round_actions = []
        self.tightness = 0.7
        self.aggression = 0.4
        self.position_factor = 0.5

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # determine opponent id (only other player in heads-up)
        opp_candidates = [pid for pid in all_players if pid != self.id]
        self.opponent_id = opp_candidates[0] if opp_candidates else None
        
        # hand and betting tracking
        self.hole_cards = []
        self.round_actions = []
        self.my_bet = 0  # track our bet in current round

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_actions.clear()
        self.my_bet = 0  # reset when new round starts
        # track our hole cards if known or parse from message
        if round_state.player_bets and str(self.id) in round_state.player_bets:
            self.my_bet = round_state.player_bets[str(self.id)]

    def _card_rank_value(self, rank: str) -> int:
        # Convert card rank to numeric value for strength
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5,
            '6': 6, '7': 7, '8': 8, '9': 9,
            'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        return rank_map.get(rank, 0)
    
    def _hole_cards_strength(self, hole: List[str]) -> float:
        # very basic hole-card strength: suitedness and connectors
        if not hole or len(hole) != 2:
            return 0.0
        c1, c2 = hole
        rank1 = self._card_rank_value(c1[0])
        rank2 = self._card_rank_value(c2[0])
        suited = c1[1] == c2[1]
        gap = abs(rank1 - rank2)
        strength = (max(rank1, rank2) / 14.0) * 0.7
        if gap <= 1:
            strength += 0.2
        elif gap <= 2:
            strength += 0.1
        if suited:
            strength += 0.1
        return min(strength, 1.0)

    def _stack_to_pot_ratio(self, remaining_chips: int, pot: int) -> float:
        if pot == 0:
            return 99.0
        return remaining_chips / float(pot + 1e-6)

    def _preflop_action(self, rs: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Utilize blinds info
        in_position = (rs.player_bets and 
                      str(self.opponent_id) in rs.player_bets and 
                      rs.player_bets[str(self.opponent_id)] < rs.player_bets.get(str(self.id), 0))
                      
        hole_strength = self._hole_cards_strength(self.player_hands)
        
        # Conservative open range
        opening_range = self.tightness
        if in_position:
            opening_range = min(0.8, opening_range + 0.15)
        
        # default call size = current_bet - my_bet = rs.current_bet - rs.player_bets[str(self.id)]
        call_needed = max(rs.current_bet - rs.player_bets.get(str(self.id), 0), 0)
        
        stack_ratio = self._stack_to_pot_ratio(remaining_chips, rs.pot)
        
        # ALL_IN or FOLD based on hole strength
        if hole_strength >= 0.9 and stack_ratio < 10:
            return (PokerAction.ALL_IN, 0)
        
        # strong raising
        if hole_strength >= opening_range:
            if rs.current_bet <= 0:  # unopened pot
                amount = max(rs.min_raise, int(rs.pot * 0.35))
                if amount <= rs.max_raise:
                    return (PokerAction.RAISE, amount)
            else:
                # facing reraise
                if call_needed <= remaining_chips:
                    if hole_strength > 0.85:
                        amount = max(rs.min_raise, min(rs.max_raise, call_needed + int(rs.pot * 0.4)))
                        return (PokerAction.RAISE, amount)
                    # passive call with medium hands
                    if hole_strength > 0.7 and stack_ratio > 6:
                        return (PokerAction.CALL, 0)
        
        # fold very weak hands preflop unless checked to us and bb is small
        if hole_strength < 0.35:
            # check small situations
            if rs.current_bet <= rs.player_bets.get(str(self.id), 0):
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)
        
        # default call middling pot odds
        if call_needed <= remaining_chips and call_needed <= rs.pot and stack_ratio > 5:
            return (PokerAction.CALL, 0)
        
        # else fold
        return (PokerAction.FOLD, 0)

    def _postflop_action(self, rs: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Super simple: rather safe toughness. Avoid bluffing much.
        call_needed = max(rs.current_bet - rs.player_bets.get(str(self.id), 0), 0)
        
        if rs.pot <= 0:
            # free card
            return (PokerAction.CHECK, 0)
        
        stack_ratio = self._stack_to_pot_ratio(remaining_chips, rs.pot)
        
        # If no bet yet, check with middling/weak hands; otherwise attempt semibluff (medium freq)
        if rs.current_bet <= rs.player_bets.get(str(self.id), 0):
            if remaining_chips > 1 and rs.pot > 1 and stack_ratio < 3:
                # shortstacked, try to protect/take down
                amount = max(rs.min_raise, int(rs.pot * 0.6))
                if amount <= rs.max_raise and len(rs.community_cards) <= 3:
                    return (PokerAction.RAISE, amount)
            return (PokerAction.CHECK, 0)
        
        # compute a very rough connection (3-card with board)
        raw_conn = min(self._card_connectivity(self.player_hands, rs.community_cards), 1.0)
        strength_pot = raw_conn * 0.9
        
        # fold very weak holdings
        if strength_pot < 0.15:
            return (PokerAction.FOLD, 0)
        
        # bet/fold if facing small allin and weak-ish
        if call_needed >= remaining_chips * 0.8 and strength_pot < 0.7:
            return (PokerAction.FOLD, 0)
        
        # call if strong enough and odds seem decent
        if strength_pot > 0.6 and call_needed <= rs.pot * (0.55 + strength_pot):
            return (PokerAction.CALL, 0)
        
        # raise if huge strength (>0.8)
        if strength_pot > 0.8 and remaining_chips > rs.pot:
            amount = min(rs.max_raise, max(rs.min_raise, call_needed + int(rs.pot * 0.7)))
            return (PokerAction.RAISE, amount)
        
        return (PokerAction.FOLD, 0)

    def _card_connectivity(self, hole, board) -> float:
        # very basic: pair on board? flush draw? straight draw by crude heuristic
        h = hole if hole else []
        b = board if board else []
        all_cards = h + b
        if not all_cards:
            return 0.0
        
        ranks = [c[0] for c in all_cards]
        suits = [c[1] for c in all_cards]
        
        # pair in hole or board pairing
        pair = False
        extra_pair = False
        if len(h)>=2 and h[0][0] == h[1][0]:
            pair = True
        for r in ranks:
            if ranks.count(r) >= 2:
                pair = True
            if ranks.count(r) >= 3:
                extra_pair = True
        
        # flush draw from hole + board?
        flush_draw = False
        for s in set(suits):
            if suits.count(s) >= 4:
                flush_draw = True
            if suits.count(s) >= 5:
                flush_draw = False  # made flush
        
        # board or hole straight potential (extremely crude)
        values = sorted([self._card_rank_value(r) for r in ranks])
        straight_pot = 0
        if len(values) >= 3:
            gap = 0
            for i in range(1, len(values)):
                gap += max(0, values[i] - values[i-1] - 1)
            straight_pot = max(0, 1 - gap*0.2)
        
        strength = 0
        if pair:
            strength += 0.4
        if extra_pair:
            strength += 0.2
        if flush_draw:
            strength += 0.3
        strength += straight_pot * 0.2
        
        return min(max(strength, 0.0), 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # always validate amounts for raise to avoid 0 invalids
            if round_state.round.lower() == 'preflop':
                act, amt = self._preflop_action(round_state, remaining_chips)
            else:
                act, amt = self._postflop_action(round_state, remaining_chips)
            
            # clamp raise amount
            if act == PokerAction.RAISE:
                amt = max(rs.min_raise if hasattr(rs,'min_raise') else round_state.min_raise, amt)
                amt = min(round_state.max_raise, amt)
                if amt < round_state.min_raise or amt > round_state.max_raise:
                    act = PokerAction.FOLD
            
            # important fix: if raise amount is equal or less than the current call, that’s not valid.
            if act == PokerAction.RAISE:
                bet_so_far = round_state.player_bets.get(str(self.id), 0)
                total_raise = bet_so_far + amt
                if total_raise <= round_state.current_bet:
                    # invalid raise; choose conservative action
                    if round_state.current_bet <= bet_so_far:
                        act = PokerAction.CHECK
                        amt = 0
                    else:
                        if remaining_chips > round_state.current_bet - bet_so_far:
                            act = PokerAction.CALL
                            amt = 0
                        else:
                            act = PokerAction.FOLD
                            amt = 0
            
            # safe check: fold instead of any invalid action
            if act == PokerAction.RAISE and amt <= 0:
                act = PokerAction.FOLD
            if act == PokerAction.CALL and round_state.current_bet <= round_state.player_bets.get(str(self.id), 0):
                act = PokerAction.CHECK
            if act == PokerAction.CHECK and round_state.current_bet > round_state.player_bets.get(str(self.id), 0):
                act = PokerAction.FOLD
            
            self.round_actions.append(act.name)
            return (act, amt)
        except Exception as e:
            # any fail: just fold (safe)
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # keep log or update any stats if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # reset all if needed, but nothing persistent
        self.hole_cards = []
        self.round_actions = []