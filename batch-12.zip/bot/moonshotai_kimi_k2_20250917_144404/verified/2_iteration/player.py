from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Hand strength tracking
        self.starting_chips = 10000
        self.hole_cards = []
        self.is_big_blind = False
        self.is_small_blind = False
        self.big_blind_amount = 10
        # Track opponent behavior
        self.opponent_raises = 0
        self.opponent_checks = 0
        self.opponent_folds = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands.copy()
        self.big_blind_amount = blind_amount
        self.is_big_blind = str(self.id) == str(big_blind_player_id)
        self.is_small_blind = str(self.id) == str(small_blind_player_id)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get current bet and minimum raise
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
            
            # Determine action based on hand strength and position
            if hand_strength >= 0.8:  # Strong hand
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Raise with strong hand
                    raise_amount = max(min_raise, int(current_bet * 1.5))
                    if raise_amount <= max_raise:
                        return PokerAction.RAISE, raise_amount
                    else:
                        return PokerAction.ALL_IN, 0
                        
            elif hand_strength >= 0.6:  # Medium strength
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Call medium bets
                    call_amount = current_bet - (round_state.player_bets.get(str(self.id), 0))
                    if call_amount <= remaining_chips * 0.15:  # Call if reasonable
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                        
            elif hand_strength >= 0.4:  # Weak hand but playable
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Fold to significant bets
                    call_amount = current_bet - (round_state.player_bets.get(str(self.id), 0))
                    if call_amount <= remaining_chips * 0.05:  # Very small bet
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                        
            else:  # Very weak hand
                if current_bet == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
                    
        except Exception as e:
            # Fallback to safe action
            if round_state.current_bet == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
                
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass
        
    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation (0.0 to 1.0)"""
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Get card values and suits
        card1, card2 = hole_cards
        rank1 = self._get_rank_value(card1[0])
        rank2 = self._get_rank_value(card2[0])
        suit1 = card1[1]
        suit2 = card2[1]
        
        # Start with base strength
        strength = 0.0
        
        # Pocket pairs (stronger with higher ranks)
        if rank1 == rank2:
            if rank1 >= 12:  # AA, KK, QQ
                strength = 0.9
            elif rank1 >= 10:  # JJ, TT
                strength = 0.8
            elif rank1 >= 7:  # 99, 88, 77
                strength = 0.7
            else:
                strength = 0.5
                
        # Suited cards
        elif suit1 == suit2:
            # Suited connectors
            if abs(rank1 - rank2) <= 2:
                if max(rank1, rank2) >= 11:  # AKs, AQs, KQs
                    strength = 0.8
                elif max(rank1, rank2) >= 8:  # Medium suited connectors
                    strength = 0.6
                else:
                    strength = 0.4
            # Suited but not connected
            elif max(rank1, rank2) >= 11:  # Big suited cards
                strength = 0.6
            else:
                strength = 0.3
                
        # Offsuit cards
        else:
            # High cards
            if min(rank1, rank2) >= 11:  # AK, AQ, KQ
                strength = 0.7
            elif max(rank1, rank2) >= 12:  # Ax, Kx with ace or king
                strength = 0.5
            elif max(rank1, rank2) >= 9:  # Medium cards
                strength = 0.3
            else:
                strength = 0.1
                
        # Community cards improvement (simple logic)
        if community_cards:
            # Check for potential flush draws
            if suit1 == suit2:  # Pocket suited
                suited_community = sum(1 for card in community_cards if card[1] == suit1)
                if suited_community >= 2:  # Flush draw or made flush
                    strength = min(1.0, strength + 0.2)
                    
            # Check for straight draws (simplified)
            all_ranks = [rank1, rank2] + [self._get_rank_value(card[0]) for card in community_cards]
            if len(set(all_ranks)) >= 4:  # Potential straight possibilities
                strength = min(1.0, strength + 0.1)
                
        return min(1.0, strength)
        
    def _get_rank_value(self, rank: str) -> int:
        """Convert card rank to numeric value (2-14)"""
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank, 0)