from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hole_cards = []
        self.position = None
        self.big_blind = 10
        self.opponent_tendencies = {}
        self.aggro_level = 0
        self.tightness = 0.5
        self.hand_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind = blind_amount
        self.position = 'BB' if self.id == big_blind_player_id else 'SB'
        self.opp_id = [p for p in all_players if p != self.id][0] if len(all_players) == 2 else None
        
    def card_rank(self, card: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]
    
    def is_suited(self, cards: List[str]) -> bool:
        return cards[0][1] == cards[1][1]
    
    def is_pocket_pair(self, cards: List[str]) -> bool:
        return cards[0][0] == cards[1][0]
    
    def hand_strength_preflop(self, cards: List[str]) -> float:
        rank1 = self.card_rank(cards[0])
        rank2 = self.card_rank(cards[1])
        suited = self.is_suited(cards)
        pair = self.is_pocket_pair(cards)
        
        if pair:
            if rank1 >= 10: return 0.9
            elif rank1 >= 7: return 0.75
            elif rank1 >= 5: return 0.6
            else: return 0.4
            
        high = max(rank1, rank2)
        low = min(rank1, rank2)
        gap = high - low
        
        if suited:
            if gap == 0: return 0.8
            elif gap == 1: return 0.7
            elif gap == 2: return 0.6
            elif gap == 3: return 0.5
            else: return 0.4
        else:
            if gap == 0: return 0.75
            elif gap == 1 and high >= 10: return 0.65
            elif gap <= 2 and high >= 11: return 0.55
            else: return 0.3
        
    def pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if round_state.pot == 0:
            return 0.0
        return to_call / (round_state.pot + to_call + 1e-9)
    
    def effective_stack(self, remaining_chips: int, round_state: RoundStateClient) -> int:
        opp_stack = 10000
        for pid in round_state.current_player:
            if pid != self.id:
                bet_so_far = round_state.player_bets.get(str(pid), 0)
                opp_stack = 10000 - bet_so_far
        return min(remaining_chips, opp_stack)
    
    def should_continue(self, round_state: RoundStateClient, remaining_chips: int, strength: float) -> bool:
        pot_odds_val = self.pot_odds(round_state, remaining_chips)
        equity_threshold = 0.3
        
        if round_state.round == 'Preflop':
            if strength > 0.7: return True
            if pot_odds_val < 0.1 and strength > 0.4: return True
            if self.position == 'SB' and round_state.current_bet <= self.big_blind * 3 and strength > 0.5: return True
            return strength > 0.6
            
        elif round_state.round in ['Flop', 'Turn']:
            if strength > 0.8: return True
            if pot_odds_val < 0.2 and strength > 0.4: return True
            if pot_odds_val < 0.3 and strength > 0.6: return True
            return strength > 0.5
            
        else:  # River
            return strength > 0.5 or (pot_odds_val < 0.25 and strength > 0.4)
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        strength = self.hand_strength_preflop(self.hole_cards)
        
        if round_state.round != 'Preflop':
            strength = self.evaluate_board_strength(round_state.community_cards)
        
        if to_call >= remaining_chips:
            return (PokerAction.ALL_IN, 0)
            
        if to_call < 0:
            to_call = 0
            
        if to_call == 0:
            if strength > 0.8:
                bet_size = min(int(round_state.pot * 0.8), remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            elif strength > 0.6:
                bet_size = min(int(round_state.pot * 0.5), remaining_chips, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            else:
                return (PokerAction.CHECK, 0)
        else:
            if self.should_continue(round_state, remaining_chips, strength):
                if strength > 0.85:
                    raise_amount = min(int(to_call + round_state.pot), remaining_chips, round_state.max_raise)
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif strength > 0.7:
                    if to_call <= self.big_blind * 4:
                        return (PokerAction.CALL, 0)
                elif strength > 0.5:
                    if to_call <= self.big_blind * 2:
                        return (PokerAction.CALL, 0)
                else:
                    if to_call <= self.big_blind and round_state.round == 'Preflop':
                        return (PokerAction.CALL, 0)
                        
        return (PokerAction.FOLD, 0)
    
    def evaluate_board_strength(self, community_cards: List[str]) -> float:
        if len(community_cards) == 0:
            return self.hand_strength_preflop(self.hole_cards)
            
        all_cards = self.hole_cards + community_cards
        board_ranks = [self.card_rank(c) for c in community_cards]
        hole_ranks = [self.card_rank(c) for c in self.hole_cards]
        
        pair_count = 0
        board_pairs = 0
        hole_pairs = 0
        
        for rank in board_ranks:
            if board_ranks.count(rank) >= 2:
                board_pairs += 1
                
        if hole_ranks[0] == hole_ranks[1]:
            hole_pairs = 1
            
        pair_count = board_pairs // 2 + hole_pairs
        
        if pair_count >= 2:
            return 0.9
        elif pair_count == 1:
            return 0.7
            
        suited_cards = len([c for c in all_cards if c[1] == self.hole_cards[0][1]])
        if suited_cards >= 4:
            return 0.8
            
        connected_cards = 0
        all_ranks = sorted([self.card_rank(c) for c in all_cards])
        for i in range(len(all_ranks)-1):
            if all_ranks[i+1] - all_ranks[i] <= 1:
                connected_cards += 1
                
        if connected_cards >= 3:
            return 0.6
            
        high_card = max(hole_ranks)
        if high_card >= 12 and len(community_cards) <= 3:
            return 0.5
            
        return 0.3
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass