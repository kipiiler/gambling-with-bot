from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.player_hands = []
        self.all_players = []
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        
        # Hand strength evaluation
        self.card_ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                          '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Tracking variables
        self.hand_history = []
        self.opponent_stats = {}  # Track opponent tendencies
        self.position = 0
        self.current_hand = []
        self.round_bets = 0
        
        # Pre-flop hand rankings (simplified)
        self.preflop_strength = {
            # Premium hands
            ('A', 'A'): 100, ('K', 'K'): 95, ('Q', 'Q'): 90, ('J', 'J'): 85, ('T', 'T'): 80,
            ('A', 'K'): 75, ('A', 'Q'): 70, ('K', 'Q'): 65, ('A', 'J'): 65, ('K', 'J'): 60,
            ('Q', 'J'): 58, ('J', 'T'): 55, ('T', '9'): 52, ('9', '9'): 50, ('8', '8'): 48,
            ('A', 'T'): 45, ('K', 'T'): 43, ('Q', 'T'): 40, ('7', '7'): 38, ('6', '6'): 35,
            ('5', '5'): 33, ('4', '4'): 30, ('3', '3'): 28, ('2', '2'): 25
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'hands_aggressive': 0,
                    'vpip': 0,  # Voluntarily put money in pot
                    'pfr': 0,   # Pre-flop raise
                    'aggression_factor': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_hand = round_state.community_cards
        self.round_bets = 0
        
        # Update position
        if self.id in round_state.current_player:
            self.position = round_state.current_player.index(self.id)
        
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            player_id_int = int(player_id)
            if player_id_int != self.id and player_id_int in self.opponent_stats:
                self.opponent_stats[player_id_int]['hands_played'] += 1
                if action in ['Raise', 'All-in']:
                    self.opponent_stats[player_id_int]['hands_aggressive'] += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get hole cards
        hole_cards = self.player_hands
        
        # Calculate pot odds
        pot = round_state.pot
        current_bet = round_state.current_bet
        to_call = max(0, current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(hole_cards, round_state.community_cards, round_state.round)
        
        # Calculate effective stack size
        effective_stack = min(remaining_chips, max([round_state.max_raise] + [round_state.player_bets.get(str(p), 0) for p in round_state.current_player]))
        
        # Determine action based on hand strength and position
        if round_state.round == 'Preflop':
            return self.preflop_strategy(hole_cards, round_state, remaining_chips, hand_strength)
        else:
            return self.postflop_strategy(hole_cards, round_state, remaining_chips, hand_strength, to_call, pot)

    def preflop_strategy(self, hole_cards: List[str], round_state: RoundStateClient, 
                        remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        # Extract card ranks and suits
        ranks = [card[0] for card in hole_cards]
        suits = [card[1] for card in hole_cards]
        
        # Get pre-flop hand strength
        strength = self.get_preflop_strength(ranks, suits)
        
        # Position-based adjustments
        position_factor = 1.0
        if self.position <= 2:  # Early position
            position_factor = 0.8
        elif self.position >= len(round_state.current_player) - 2:  # Late position
            position_factor = 1.2
        
        # Adjust strength based on position
        adjusted_strength = strength * position_factor
        
        # Action based on strength
        to_call = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        if adjusted_strength >= 70:
            # Premium hands - raise
            if to_call == 0:
                raise_amount = min(round_state.min_raise * 3, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                if remaining_chips > to_call * 3:
                    raise_amount = min(to_call * 3, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CALL, 0)
        
        elif adjusted_strength >= 50:
            # Good hands - call or small raise
            if to_call <= round_state.min_raise * 2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        elif adjusted_strength >= 30:
            # Marginal hands - call small bets in late position
            if to_call <= round_state.min_raise and position_factor > 1.0:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        else:
            # Weak hands - fold
            return (PokerAction.FOLD, 0)

    def postflop_strategy(self, hole_cards: List[str], round_state: RoundStateClient,
                         remaining_chips: int, hand_strength: float, to_call: int, pot: int) -> Tuple[PokerAction, int]:
        # Calculate pot odds
        pot_odds = to_call / (pot + to_call + 1e-10)
        
        # Determine action based on hand strength and pot odds
        if hand_strength > 0.8:
            # Very strong hand - bet/raise big
            if to_call == 0:
                bet_size = min(pot * 0.75, remaining_chips)
                return (PokerAction.RAISE, max(bet_size, round_state.min_raise))
            else:
                if remaining_chips > to_call * 2:
                    raise_amount = min(to_call * 2, remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
        
        elif hand_strength > 0.6:
            # Strong hand - bet/call
            if to_call == 0:
                bet_size = min(pot * 0.5, remaining_chips)
                return (PokerAction.RAISE, max(bet_size, round_state.min_raise))
            else:
                if pot_odds < 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        elif hand_strength > 0.4:
            # Medium strength - check/call small bets
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                if pot_odds < 0.25:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        elif hand_strength > 0.2:
            # Weak hand - check/fold
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        else:
            # Very weak hand - check/fold
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def get_preflop_strength(self, ranks: List[str], suits: List[str]) -> float:
        # Sort ranks for consistent lookup
        rank1, rank2 = sorted(ranks, key=lambda x: self.card_ranks[x])
        
        # Check for pairs
        if rank1 == rank2:
            pair_key = (rank1, rank2)
            return self.preflop_strength.get(pair_key, 20)
        
        # Check for suited hands
        suited = suits[0] == suits[1]
        key = (rank2, rank1) if self.card_ranks[rank2] > self.card_ranks[rank1] else (rank1, rank2)
        
        base_strength = self.preflop_strength.get(key, 15)
        if suited:
            base_strength += 5
        
        return base_strength

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str], round_name: str) -> float:
        # Simple hand strength evaluation
        all_cards = hole_cards + community_cards
        
        if len(all_cards) < 5:
            return 0.0
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for card in all_cards:
            rank = card[0]
            suit = card[1]
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for flush
        flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        ranks = sorted([self.card_ranks[r] for r in rank_counts.keys()], reverse=True)
        straight = False
        if len(ranks) >= 5:
            for i in range(len(ranks) - 4):
                if ranks[i] - ranks[i+4] == 4:
                    straight = True
                    break
        
        # Check for straight flush and royal flush
        if flush and straight:
            return 0.95
        
        # Check for four of a kind
        if 4 in rank_counts.values():
            return 0.9
        
        # Check for full house
        if 3 in rank_counts.values() and 2 in rank_counts.values():
            return 0.85
        
        # Check for flush
        if flush:
            return 0.8
        
        # Check for straight
        if straight:
            return 0.75
        
        # Check for three of a kind
        if 3 in rank_counts.values():
            return 0.7
        
        # Check for two pair
        if list(rank_counts.values()).count(2) >= 2:
            return 0.6
        
        # Check for one pair
        if 2 in rank_counts.values():
            # Check if pair is in hole cards
            hole_ranks = [card[0] for card in hole_cards]
            hole_pairs = [r for r in hole_ranks if rank_counts[r] >= 2]
            if hole_pairs:
                return 0.5
            else:
                return 0.3
        
        # High card
        return 0.1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hand history
        self.hand_history.append({
            'round': round_state.round,
            'pot': round_state.pot,
            'community_cards': round_state.community_cards,
            'player_bets': round_state.player_bets
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_history = []
        self.opponent_stats = {k: {'hands_played': 0, 'hands_aggressive': 0, 'vpip': 0, 'pfr': 0, 'aggression_factor': 0} 
                              for k in self.opponent_stats.keys()}