import random
from typing import List, Tuple, Dict, Optional
from enum import Enum
from collections import defaultdict

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class RoundStateClient:
    def __init__(self, round_num: int, round: str, community_cards: List[str], pot: int, 
                 current_player: List[int], current_bet: int, min_raise: int, max_raise: int, 
                 player_bets: Dict[str, int], player_actions: Dict[str, str], side_pots: List[Dict] = None):
        self.round_num = round_num
        self.round = round
        self.community_cards = community_cards
        self.pot = pot
        self.current_player = current_player
        self.current_bet = current_bet
        self.min_raise = min_raise
        self.max_raise = max_raise
        self.player_bets = player_bets
        self.player_actions = player_actions
        self.side_pots = side_pots if side_pots else []

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None

    def set_id(self, player_id: int) -> None:
        self.id = player_id

    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass

    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass

    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict) -> None:
        pass

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_amount = 0
        self.starting_chips = 0
        self.player_stacks = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.player_stacks = {player: starting_chips for player in all_players}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.player_stacks[self.id] = remaining_chips
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_id_str = str(self.id)
        our_bet = round_state.player_bets.get(our_id_str, 0)
        to_call = max(0, round_state.current_bet - our_bet)
        min_raise = max(round_state.min_raise, 2*self.big_blind_amount) if round_state.round == 'Preflop' else round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        call_amount = min(to_call, remaining_chips)
        community_cards = round_state.community_cards if round_state.community_cards else []
        
        # Calculate immediate pot odds
        pot_odds = to_call / (round_state.pot + to_call + 0.0001) if to_call > 0 else 0
        estimated_strength = self.estimate_hand_strength(self.hole_cards, community_cards)
        is_preflop = (round_state.round == 'Preflop')
        num_players = len(round_state.current_player)
        
        # Pre-flop strategy based on hand groups
        if is_preflop:
            group = self.get_hand_group(self.hole_cards)
            if group <= 2:  # Premium hands
                if to_call == 0:  # No bet to call
                    return (PokerAction.RAISE, min(max_raise, self.big_blind_amount * 3))
                elif to_call <= 3 * self.big_blind_amount:  # Good pot odds
                    if PokerAction.FOLD not in round_state.player_actions.values() and to_call == self.big_blind_amount:
                        return (PokerAction.RAISE, min(max_raise, 3 * self.big_blind_amount))
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0) if (estimated_strength >= 0.75) and (to_call < remaining_chips * 0.3) else (PokerAction.FOLD, 0)
            elif group == 3:  # Speculative hands
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= self.big_blind_amount:
                    if pot_odds < 0.3:
                        return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:  # Post-flop
            if estimated_strength > 0.7:  # Strong hand
                if to_call == 0:
                    bet_size = min(max_raise, max(min_raise, int(round_state.pot * 0.6)))
                    return (PokerAction.RAISE, bet_size)
                elif to_call > 0:
                    if pot_odds <= 0.3 or estimated_strength > 0.85:
                        return (PokerAction.CALL, 0)
                    elif num_players == 1:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.RAISE, min_raise)
            elif estimated_strength > 0.5:  # Medium hand
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.25:
                    return (PokerAction.CALL, 0)
            elif to_call > 0 and pot_odds < 0.2:  # Drawing hand with good odds
                return (PokerAction.CALL, 0)
                
            # Default fold
            return (PokerAction.FOLD, 0) if to_call > 0 else (PokerAction.CHECK, 0)
                
    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str], trials: int = 100) -> float:
        if not hole_cards:
            return 0.0
            
        if len(community_cards) == 0:
            # Pre-flop hand group as proxy for strength
            group = self.get_hand_group(hole_cards)
            return min(0.99, 0.2 + group * 0.15)
            
        # Count wins against random player hands
        all_cards = self.generate_deck(hole_cards + community_cards)
        our_hand_rank = self._evaluate_hand(hole_cards, community_cards)
        wins = 0
        
        for _ in range(trials):
            # Random opponent hand
            opp_hole = random.sample(all_cards, 2)
            remaining = [card for card in all_cards if card not in opp_hole]
            # Complete community cards if needed
            board = community_cards[:]
            if len(board) < 5:
                board_ext = random.sample(remaining, 5 - len(board))
                board_complete = board + board_ext
            else:
                board_complete = board
                
            opp_rank = self._evaluate_hand(opp_hole, board_complete)
            if our_hand_rank > opp_rank:
                wins += 1
            elif our_hand_rank == opp_rank:
                wins += 0.5
                
        return wins / trials
        
    def _evaluate_hand(self, hole_cards: List[str], community: List[str]) -> int:
        rank_str = "23456789TJQKA"
        all_cards = hole_cards + community
        all_cards.sort(key=lambda x: (-rank_str.index(x[0]), 0)
        best_score = 0
        
        if len(all_cards) >= 5:
            all_combinations = all_cards if len(all_cards) == 5 else self._combinations(all_cards, 5)
            for combo in all_combinations:
                score = self._score_hand(combo)
                if score > best_score:
                    best_score = score
                    
        return best_score
        
    def _score_hand(self, hand: List[str]) -> int:
        values = [card[0] for card in hand]
        suits = [card[1] for card in hand]
        value_counts = defaultdict(int)
        for v in values:
            value_counts[v] += 1
        ranks = sorted(values, key=lambda x: ("23456789TJQKA".index(x), x != 'A'))
        is_flush = len(set(suits)) == 1
        is_straight = self._is_consecutive(ranks)
        counts = sorted(value_counts.values(), reverse=True)
        
        if is_straight and is_flush and ranks[0] == 'A' and ranks[1] == 'K':
            return 1000  # Royal flush
        if is_straight and is_flush:
            return 900 + self._card_val(ranks[0])  # Straight flush
        if counts == [4, 1]:
            return 800 + self._card_val(ranks[0])  # Four of a kind
        if counts == [3, 2]:
            return 700 + self._card_val(ranks[0])  # Full house
        if is_flush:
            return 600 + self._high_card_value(ranks)  # Flush
        if is_straight:
            return 500 + self._card_val(ranks[0])  # Straight
        if counts == [3, 1, 1]:
            return 400 + self._card_val(ranks[0])  # Three of a kind
        if counts == [2, 2, 1]:
            pairs = [v for v, cnt in value_counts.items() if cnt == 2]
            return 300 + max(map(self._card_val, pairs))  # Two pair
        if counts == [2, 1, 1, 1]:
            return 200 + self._card_val([v for v, cnt in value_counts.items() if cnt == 2][0])  # One pair
        return self._high_card_value(ranks)  # High card
        
    def _high_card_value(self, values: List[str]) -> int:
        return sum(self._card_val(v) * (14**(4-i)) for i, v in enumerate(values[:5]))
        
    def _is_consecutive(self, values: List[str]) -> bool:
        rank_str = "23456789TJQKA"
        indices = sorted(rank_str.index(v) for v in values)
        return all(indices[i]+1 == indices[i+1] for i in range(len(indices)-1))
        
    def _card_val(self, rank: str) -> int:
        return "23456789TJQKA".index(rank) + 2
        
    def _combinations(self, cards: List[str], k: int) -> List[List[str]]:
        if k == 0:
            return [[]]
        if not cards:
            return []
        lst = cards.copy()
        head, *tail = lst
        return self._combinations(tail, k) + [[head] + x for x in self._combinations(tail, k-1)]
        
    def generate_deck(self, exclude: List[str] = []) -> List[str]:
        ranks = "23456789TJQKA"
        suits = "CDHS"
        deck = [r+s for s in suits for r in ranks]
        for card in exclude:
            if card in deck:
                deck.remove(card)
        return deck
        
    def get_hand_group(self, hole_cards: List[str]) -> int:
        rank_to_value = {r: v for v, r in enumerate("23456789TJQKA", 2)}
        values = sorted((rank_to_value[c[0]] for c in hole_cards), reverse=True)
        suited = hole_cards[0][1] == hole_cards[1][1]
        high, low = values
        
        if values[0] == values[1]:  # Pair
            if high >= 14: return 1   # AA
            if high >= 12: return 2   # KK-QQ
            if high >= 10: return 3   # JJ-1010
            return 4  # Lower pairs
            
        # Suited connectors
        gap = high - low
        if gap == 0:
            return 1
        if suited:
            if gap == 1:  # Suited connector
                if high >= 12: return 1
                if high >= 10: return 2
                if high >= 8: return 3
            if gap == 2:  # Suited gap 1
                if high >= 11: return 3
                
        # Offsuit
        if high == 14:  # Ace high
            if low >= 12: return 1  # AK, AQ
            if low >= 10: return 2  # AJ, AT
            if low >= 8: return 3
            
        return 4  # Fold
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.player_stacks[self.id] = remaining_chips
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict) -> None:
        # Learning: Analyze results to improve future strategy
        pass