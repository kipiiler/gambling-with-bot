import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = None
        self.starting_chips = None
        self.blind_amount = None
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.player_order = None
        self.hand_groups = self._create_hand_groups()
        
        self.rank_to_num = {
            '2': 0, '3': 1, '4': 2, '5': 3, '6': 4, 
            '7': 5, '8': 6, '9': 7, 'T': 8, 'J': 9, 
            'Q': 10, 'K': 11, 'A': 12
        }
        self.num_to_rank = {v: k for k, v in self.rank_to_num.items()}
        self.hand_rank_names = {
            8: "Straight Flush",
            7: "Four of a Kind",
            6: "Full House",
            5: "Flush",
            4: "Straight",
            3: "Three of a Kind",
            2: "Two Pair",
            1: "One Pair",
            0: "High Card"
        }

    def _create_hand_groups(self):
        return {
            'AA': 1, 'KK': 1, 'QQ': 1, 'JJ': 1, 'AKs': 1,
            'AQs': 2, 'AJs': 2, 'KQs': 2, 'TT': 2,
            'ATs': 3, 'KJs': 3, 'QJs': 3, 'JTs': 3, '99': 3,
            'A9s': 4, 'KTs': 4, 'QTs': 4, 'J9s': 4, 'T9s': 4, '98s': 4, '88': 4,
            'A8s': 5, 'K9s': 5, 'Q9s': 5, 'J8s': 5, 'T8s': 5, '97s': 5, '87s': 5, '77': 5, 'AKo': 5,
            'A7s': 6, 'A6s': 6, 'A5s': 6, 'A4s': 6, 'A3s': 6, 'A2s': 6, 'K8s': 6, 'Q8s': 6, 'J7s': 6, 
            'T7s': 6, '96s': 6, '86s': 6, '76s': 6, '66': 6, 'AQo': 6,
            'K7s': 7, 'Q7s': 7, 'J6s': 7, 'T6s': 7, '95s': 7, '85s': 7, '75s': 7, '65s': 7, '55': 7, 
            'AJo': 7, 'KQo': 7,
            'K6s': 8, 'Q6s': 8, 'J5s': 8, 'T5s': 8, '94s': 8, '84s': 8, '74s': 8, '64s': 8, '54s': 8, 
            '44': 8, 'ATo': 8, 'KJo': 8, 'QJo': 8
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.player_order = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def _hand_to_string(self, hand):
        if len(hand) != 2:
            return ""
        card1, card2 = hand
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        r1 = self.rank_to_num[rank1]
        r2 = self.rank_to_num[rank2]
        
        if r1 < r2:
            r1, r2 = r2, r1
            rank1, rank2 = rank2, rank1
            
        suited = 's' if suit1 == suit2 else 'o'
        
        if rank1 == rank2:
            return rank1 + rank2
        else:
            return rank1 + rank2 + suited

    def _hand_group(self, hand_str):
        return self.hand_groups.get(hand_str, 9)

    def _evaluate_5card_hand(self, hand):
        rank_to_num = self.rank_to_num
        suits = [card[1] for card in hand]
        ranks = [rank_to_num[card[0]] for card in hand]
        sorted_ranks = sorted(ranks)
        
        flush = len(set(suits)) == 1
        
        is_wheel = sorted_ranks == [0, 1, 2, 3, 12]
        straight_high = None
        if not is_wheel:
            is_consecutive = True
            for i in range(1, 5):
                if sorted_ranks[i] - sorted_ranks[i-1] != 1:
                    is_consecutive = False
                    break
            if is_consecutive:
                straight_high = sorted_ranks[-1]
        else:
            straight_high = 3
            
        straight = is_wheel or (not is_wheel and is_consecutive)
        
        if flush and straight:
            return (8, (straight_high,))
        
        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        sorted_counts = sorted(rank_count.items(), key=lambda x: (-x[1], -x[0]))
        
        if sorted_counts[0][1] == 4:
            four_rank = sorted_counts[0][0]
            kicker = sorted_counts[1][0]
            return (7, (four_rank, kicker))
        
        if sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
            three_rank = sorted_counts[0][0]
            two_rank = sorted_counts[1][0]
            return (6, (three_rank, two_rank))
        
        if flush:
            high_cards = sorted(ranks, reverse=True)
            return (5, tuple(high_cards))
        
        if straight:
            return (4, (straight_high,))
        
        if sorted_counts[0][1] == 3:
            three_rank = sorted_counts[0][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)
            return (3, (three_rank, kickers[0], kickers[1]))
        
        if sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
            pair_ranks = sorted([sorted_counts[0][0], sorted_counts[1][0]], reverse=True)
            kicker = sorted_counts[2][0]
            return (2, (pair_ranks[0], pair_ranks[1], kicker))
        
        if sorted_counts[0][1] == 2:
            pair_rank = sorted_counts[0][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return (1, (pair_rank, kickers[0], kickers[1], kickers[2]))
        
        high_cards = sorted(ranks, reverse=True)
        return (0, tuple(high_cards))

    def evaluate_hand(self, cards):
        if len(cards) < 5:
            return (0, (0,))
            
        best_hand_value = None
        for combo in itertools.combinations(cards, 5):
            hand_value = self._evaluate_5card_hand(combo)
            if best_hand_value is None or hand_value > best_hand_value:
                best_hand_value = hand_value
        return best_hand_value

    def calculate_hand_strength(self, cards):
        if len(cards) < 5:
            return 0.0
            
        hand_rank, tie_breakers = self.evaluate_hand(cards)
        pad_tie = list(tie_breakers) + [0] * (5 - len(tie_breakers))
        strength = hand_rank * 100 + pad_tie[0] + pad_tie[1]/100.0 + pad_tie[2]/10000.0 + pad_tie[3]/1000000.0 + pad_tie[4]/100000000.0
        max_strength = 800 + 12 + 12/100.0 + 12/10000.0 + 12/1000000.0 + 12/100000000.0
        return strength / max_strength

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_id_str = str(self.id)
        our_current_bet = round_state.player_bets.get(our_id_str, 0)
        amount_to_call = max(0, round_state.current_bet - our_current_bet)
        
        if amount_to_call >= remaining_chips:
            return (PokerAction.ALL_IN, 0)
            
        pot_odds = 0.0
        if amount_to_call > 0:
            pot_total = round_state.pot + amount_to_call
            pot_odds = amount_to_call / pot_total if pot_total > 0 else 0

        if round_state.round == 'Preflop':
            num_players = len(round_state.current_player)
            our_index = round_state.current_player.index(self.id)
            position = our_index / max(num_players, 1)
            
            hand_str = self._hand_to_string(self.hand)
            group = self._hand_group(hand_str)
            
            if num_players <= 3:
                max_group = 9
            else:
                if position < 0.33:
                    max_group = 3
                elif position < 0.66:
                    max_group = 6
                else:
                    max_group = 8
                    
            if group > max_group:
                return (PokerAction.FOLD, 0)
            else:
                if amount_to_call == 0:
                    if group <= 3:
                        raise_amount = min(
                            round_state.max_raise,
                            max(round_state.min_raise, int(0.5 * round_state.pot))
                        )
                        if raise_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if group <= 5:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        else:
            cards = self.hand + round_state.community_cards
            hand_strength = self.calculate_hand_strength(cards)
            
            if amount_to_call == 0:
                if hand_strength > 0.5:
                    raise_amount = min(
                        round_state.max_raise,
                        max(round_state.min_raise, int(0.5 * round_state.pot))
                    )
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if hand_strength > pot_odds:
                    if hand_strength > 0.7 and round_state.min_raise <= remaining_chips:
                        raise_amount = min(
                            round_state.max_raise,
                            max(round_state.min_raise, int(0.5 * round_state.pot))
                        )
                        if raise_amount >= remaining_chips:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass