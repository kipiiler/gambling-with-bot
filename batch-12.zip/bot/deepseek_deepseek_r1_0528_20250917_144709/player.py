from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from typing import List, Tuple, Dict, Any
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.chips = 0
        self.hand = []
        self.position = -1
        self.small_blind_pos = -1
        self.big_blind_pos = -1
        self.players = []
        self.initial_players = []
        self.player_bets = {}

    def get_current_position(self, round_state: RoundStateClient) -> int:
        remaining_players = [p for p in self.players if str(p) in round_state.player_actions]
        if not remaining_players:
            return self.position
        current_idx = remaining_players.index(self.id)
        return (current_idx - self.players.index(self.id)) % len(self.players)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.chips = starting_chips
        self.hand = player_hands
        self.small_blind_pos = all_players.index(small_blind_player_id)
        self.big_blind_pos = all_players.index(big_blind_player_id)
        self.players = all_players
        self.initial_players = all_players.copy()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.chips = remaining_chips
        self.player_bets = {}

    def hand_strength(self, hand: List[str], board: List[str]) -> float:
        def card_rank(card: str) -> int:
            rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, 
                        '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
            return rank_map[card[:-1]]
        
        def hand_rank(cards: List[str]) -> Tuple[int, List[int]]:
            ranks = [card_rank(c) for c in cards]
            sorted_ranks = sorted(ranks, reverse=True)
            
            if len(cards) < 5:
                return 1, [max(ranks)]
                
            suits = [c[-1] for c in cards]
            flush = any(suits.count(suit) >= 5 for suit in set(suits))
            
            rank_counter = {}
            for r in sorted_ranks:
                rank_counter[r] = rank_counter.get(r, 0) + 1
            
            pairs = [r for r, count in rank_counter.items() if count == 2]
            trips = [r for r, count in rank_counter.items() if count == 3]
            quads = [r for r, count in rank_counter.items() if count == 4]
            full_house = 1 if trips and pairs else 0
            
            straight = 0
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i] - sorted_ranks[i+4] == 4:
                    straight = sorted_ranks[i]
                    break
                    
            if straight and flush and straight == 14:  # royal flush marker
                return 10, [14]
            elif straight and flush:
                return 9, [straight]
            elif quads:
                return 8, [quads[0], sorted_ranks[0] if sorted_ranks[0] != quads[0] else sorted_ranks[4]]
            elif full_house:
                return 7, [trips[0], pairs[0]]
            elif flush:
                return 6, sorted_ranks[:5]
            elif straight:
                return 5, [straight]
            elif trips:
                return 4, [trips[0]] + sorted_ranks[:3]
            elif pairs:
                if len(pairs) >= 2:
                    return 3, pairs[:2] + [sorted_ranks[-1]]
                else:
                    return 2, pairs + [sorted_ranks[-1]]
            else:
                return 1, sorted_ranks[:5]
        
        if not board:
            # Preflop handling
            r1, r2 = card_rank(hand[0]), card_rank(hand[1])
            high = max(r1, r2)
            low = min(r1, r2)
            
            # Chen formula components
            base_score = max(r1, r2)
            if r1 == r2:  # pair
                base_score = max(5, base_score * 2)
                
            gap_penalty = max(0, high - low - 1)
            if gap_penalty == 1: gap_penalty = 1
            elif gap_penalty == 2: gap_penalty = 2
            elif gap_penalty >= 3: gap_penalty = 4
            else: gap_penalty = 0
                
            suited_bonus = 2 if hand[0][-1] == hand[1][-1] else 0
            connector_bonus = 0
            if 0 <= (high - low) <= 1:
                connector_bonus = 1 if high < 12 else 2
            
            chen_score = base_score - gap_penalty + suited_bonus + connector_bonus
            return min(20, max(1, chen_score)) / 20.0
        else:
            score, _ = hand_rank(hand + board)
            return score / 10.0  # Normalize 1-10 to 0.1-1.0

    def pot_odds(self, round_state: RoundStateClient) -> float:
        call_value = round_state.current_bet - self.player_bets.get(str(self.id), 0)
        if call_value <= 0:
            return 1.0
        pot = round_state.pot
        odds = call_value / (pot + call_value + 1e-8)
        return min(1.0, max(0.0, odds))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.player_bets = round_state.player_bets

        # Update player bets tracking
        current_player_id = str(self.id)
        if current_player_id not in self.player_bets:
            self.player_bets[current_player_id] = 0

        bet_diff = round_state.current_bet - self.player_bets.get(current_player_id, 0)
        pot_odds = self.pot_odds(round_state)
        hand_str = self.hand_strength(self.hand, round_state.community_cards)

        # Calculate position factor
        try:
            player_index = self.players.index(self.id)
            relative_position = (player_index - self.big_blind_pos) % len(self.players)
            position_factor = relative_position / max(1, len(self.players) - 1)
        except:
            position_factor = 0.5

        # Default action is fold
        action = PokerAction.FOLD
        amount = 0

        # Action decision logic
        if bet_diff == 0:
            # No bet to call, can check or bet
            if hand_str > (0.4 + position_factor * 0.2):
                action = PokerAction.RAISE
                base_raise = min(round_state.min_raise, int(self.chips * 0.3))
                amount = min(self.chips, max(round_state.min_raise, base_round_state.min_raise))
        else:
            # Action needed to call
            if hand_str > 0.8 and self.chips > bet_diff * 3:
                # Very strong hand, re-raise
                action = PokerAction.RAISE
                amount = min(self.chips, round_state.min_raise * 3)
            elif hand_str > pot_odds * 1.4 or hand_str > 0.7:
                # Good hand or favorable pot odds
                if bet_diff < remaining_chips and hand_str > pot_odds * 1.2:
                    # Raise if we have good equity
                    action = PokerAction.RAISE
                    amount = min(self.chips, round_state.min_raise * 2)
                else:
                    action = PokerAction.CALL
            elif hand_str * 1.2 > pot_odds and remaining_chips > bet_diff * 10:
                # Drawing hand with decent odds
                action = PokerAction.CALL

        # Specific all-in conditions
        if remaining_chips <= round_state.min_raise * 4 and hand_str > 0.5:
            action = PokerAction.ALL_IN
        elif remaining_chips <= round_state.current_bet:
            action = PokerAction.ALL_IN if hand_str > 0.35 else PokerAction.FOLD

        # Verify raise amount validity
        if action == PokerAction.RAISE:
            if amount < round_state.min_raise:
                amount = round_state.min_raise
            if amount > remaining_chips:
                amount = remaining_chips
            if amount > round_state.max_raise:
                action = PokerAction.ALL_IN

        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        self.chips = remaining_chips
        self.hand = []
        self.player_bets = {}

    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                    all_scores: dict, active_players_hands: dict) -> None:
        pass

    # Helper for position calculation
    def effective_position(self, player_id: int) -> int:
        bb_index = self.players.index(self.big_blind_pos)
        player_index = self.players.index(player_id)
        return (player_index - bb_index) % len(self.players)