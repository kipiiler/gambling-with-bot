from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 10
        self.hole_cards = []
        self.position = None  # 'sb', 'bb', or position relative to dealer
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'sb'
        elif self.id == big_blind_player_id:
            self.position = 'bb'
        else:
            self.position = 'other'

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Get pot odds and betting info
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = self._calculate_pot_odds(round_state.pot, call_amount)
            
            # Determine action based on hand strength and situation
            action, amount = self._decide_action(round_state, remaining_chips, hand_strength, call_amount, pot_odds)
            
            return action, amount
            
        except Exception as e:
            # Fallback to safe action if any error occurs
            if round_state.current_bet == 0:
                return PokerAction.CHECK, 0
            elif round_state.current_bet <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (weak) to 1.0 (strong)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.3  # Default conservative strength
            
        card1, card2 = self.hole_cards
        
        # Parse cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Base strength on pocket cards
        strength = 0.0
        
        # High cards bonus
        high_cards = [rank for rank in [rank1, rank2] if rank >= 10]  # 10, J, Q, K, A
        strength += len(high_cards) * 0.15
        
        # Pair bonus
        if rank1 == rank2:
            if rank1 >= 10:  # High pairs (TT+)
                strength += 0.7
            elif rank1 >= 7:  # Medium pairs (77-99)
                strength += 0.5
            else:  # Low pairs (22-66)
                strength += 0.3
        
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
            
        # Connected cards bonus (straight potential)
        if abs(rank1 - rank2) == 1 or (rank1 == 14 and rank2 == 2):  # A-2 is connected
            strength += 0.1
            
        # Ace bonus
        if rank1 == 14 or rank2 == 14:
            strength += 0.2
            
        # Face cards bonus
        face_cards = sum(1 for rank in [rank1, rank2] if rank >= 11)
        strength += face_cards * 0.1
        
        # Adjust based on community cards
        if round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
        
        return min(1.0, max(0.0, strength))
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank (int) and suit (str)"""
        if len(card) != 2:
            return 7, 'h'  # Default fallback
            
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_char, 7)
        return rank, suit
    
    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        if not community_cards:
            return base_strength
            
        # Simple adjustment: increase strength if we have potential draws
        # This is a simplified version - in a real bot you'd want more sophisticated analysis
        adjustment = 0.0
        
        # Count suits for flush potential
        suits = {}
        for card in community_cards + self.hole_cards:
            suit = card[1] if len(card) == 2 else 'h'
            suits[suit] = suits.get(suit, 0) + 1
            
        max_suit_count = max(suits.values()) if suits else 0
        if max_suit_count >= 4:  # Flush draw or made flush
            adjustment += 0.2
        elif max_suit_count == 3:  # Flush draw
            adjustment += 0.1
            
        return min(1.0, base_strength + adjustment)
    
    def _calculate_pot_odds(self, pot_size: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return float('inf')
        return pot_size / (pot_size + call_amount)
    
    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, 
                      hand_strength: float, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Decide action based on hand strength and game state"""
        
        # If no bet to call, check or bet
        if round_state.current_bet == 0:
            if hand_strength >= 0.7:  # Strong hand - bet
                bet_size = min(round_state.pot // 2 + self.blind_amount, remaining_chips)
                bet_size = max(bet_size, round_state.min_raise)
                return PokerAction.RAISE, bet_size
            elif hand_strength >= 0.4:  # Medium hand - sometimes bet for value/bluff
                if len(round_state.community_cards) == 0 and hand_strength >= 0.5:  # Preflop aggression
                    bet_size = min(self.blind_amount * 3, remaining_chips)
                    bet_size = max(bet_size, round_state.min_raise)
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            else:  # Weak hand - check
                return PokerAction.CHECK, 0
        
        # There's a bet to call
        if call_amount >= remaining_chips:
            # All-in situation
            if hand_strength >= 0.6:
                return PokerAction.CALL, 0  # Call all-in with strong hands
            else:
                return PokerAction.FOLD, 0
        
        # Normal betting situation
        if hand_strength >= 0.8:  # Very strong hand - raise
            raise_size = min(round_state.pot, remaining_chips)
            raise_size = max(raise_size, round_state.min_raise)
            if raise_size <= remaining_chips:
                return PokerAction.RAISE, raise_size
            else:
                return PokerAction.CALL, 0
                
        elif hand_strength >= 0.6:  # Strong hand - call or raise
            if pot_odds >= 0.3:  # Good pot odds
                if hand_strength >= 0.7:
                    raise_size = min(round_state.pot // 2, remaining_chips)
                    raise_size = max(raise_size, round_state.min_raise)
                    if raise_size <= remaining_chips:
                        return PokerAction.RAISE, raise_size
                return PokerAction.CALL, 0
            else:
                return PokerAction.CALL, 0
                
        elif hand_strength >= 0.4:  # Medium hand - call with good odds
            if pot_odds >= 0.4 or call_amount <= self.blind_amount * 2:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
                
        elif hand_strength >= 0.25:  # Weak hand - call small bets only
            if call_amount <= self.blind_amount or pot_odds >= 0.6:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:  # Very weak hand - fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass