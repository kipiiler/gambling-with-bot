from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.opponents = []
        self.big_blind_amount = 0
        self.hands_played = 0
        self.opponent_stats = {}
        self.position_stats = {}
        self.round_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount
        self.opponents = [p for p in all_players if p != self.id]
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id:
                self.opponent_stats[player] = {
                    'hands_played': 0,
                    'folds': 0,
                    'calls': 0,
                    'raises': 0,
                    'aggression': 0.0,
                    'vpip': 0.0,
                    'pfr': 0.0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Calculate position strength (later position is better)
        position_strength = self._calculate_position_strength(round_state)
        
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Get opponent aggression factor
        aggression_factor = self._get_opponent_aggression(round_state)
        
        # Calculate stack size relative to blinds
        stack_bb_ratio = remaining_chips / max(self.big_blind_amount, 1)
        
        # Determine action based on multiple factors
        action, amount = self._determine_action(
            round_state, remaining_chips, hand_strength, 
            position_strength, pot_odds, aggression_factor, stack_bb_ratio
        )
        
        return action, amount
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and int(player_id) in self.opponent_stats:
                stats = self.opponent_stats[int(player_id)]
                stats['hands_played'] += 1
                
                if action == 'Fold':
                    stats['folds'] += 1
                elif action == 'Call':
                    stats['calls'] += 1
                elif action in ['Raise', 'All_in']:
                    stats['raises'] += 1
                    
                # Update derived stats
                total_actions = stats['folds'] + stats['calls'] + stats['raises']
                if total_actions > 0:
                    stats['aggression'] = (stats['raises'] + stats['calls']) / max(total_actions, 1)
                    stats['vpip'] = (stats['calls'] + stats['raises']) / max(stats['hands_played'], 1)
                    stats['pfr'] = stats['raises'] / max(stats['hands_played'], 1)
    
    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        # Parse cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 10:  # AA, KK, QQ, JJ, TT
                strength = 0.9
            elif rank1 >= 7:   # 99, 88, 77
                strength = 0.7
            else:             # 66, 55, 44, 33, 22
                strength = 0.5
        
        # High cards
        elif rank1 >= 11 or rank2 >= 11:  # Ace or King
            if rank1 >= 12 and rank2 >= 12:  # AK, AQ, KQ
                strength = 0.8 if suit1 == suit2 else 0.75
            elif rank1 >= 11 and rank2 >= 11:  # AJ, AT, KJ, KT, QJ, QT, JT
                strength = 0.6 if suit1 == suit2 else 0.55
            else:
                strength = 0.4 if suit1 == suit2 else 0.35
        
        # Suited connectors
        elif suit1 == suit2 and abs(rank1 - rank2) <= 1:
            strength = 0.5
        
        # Connected cards
        elif abs(rank1 - rank2) <= 1:
            strength = 0.3
        
        # Suited cards
        elif suit1 == suit2:
            strength = 0.25
        
        else:
            strength = 0.1
            
        # Adjust based on community cards
        if round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards)
            
        return min(1.0, max(0.0, strength))
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        if len(card) != 2:
            return 2, 'h'
            
        rank_str, suit = card[0], card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return rank, suit
    
    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        if not community_cards:
            return base_strength
            
        # Simple adjustment based on potential improvements
        adjustment = 0.0
        
        # Check for potential flushes
        suits = [self._parse_card(card)[1] for card in self.hole_cards + community_cards]
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        if max_suit_count >= 4:
            adjustment += 0.2
        elif max_suit_count >= 3:
            adjustment += 0.1
            
        # Check for potential straights
        ranks = [self._parse_card(card)[0] for card in self.hole_cards + community_cards]
        unique_ranks = sorted(set(ranks))
        
        max_consecutive = 1
        current_consecutive = 1
        for i in range(1, len(unique_ranks)):
            if unique_ranks[i] == unique_ranks[i-1] + 1:
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 1
                
        if max_consecutive >= 4:
            adjustment += 0.15
        elif max_consecutive >= 3:
            adjustment += 0.05
            
        return min(1.0, base_strength + adjustment)
    
    def _calculate_position_strength(self, round_state: RoundStateClient) -> float:
        if not round_state.current_player:
            return 0.5
            
        total_players = len(round_state.player_bets)
        if total_players <= 1:
            return 0.5
            
        # Later position is better (closer to 1.0)
        try:
            my_position = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
            return my_position / max(len(round_state.current_player) - 1, 1)
        except:
            return 0.5
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        if round_state.current_bet == 0:
            return 1.0
            
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 1.0
            
        if call_amount >= remaining_chips:
            call_amount = remaining_chips
            
        pot_odds = round_state.pot / max(call_amount, 1)
        return min(10.0, pot_odds)  # Cap at 10:1 odds
    
    def _get_opponent_aggression(self, round_state: RoundStateClient) -> float:
        if not self.opponent_stats:
            return 0.5
            
        total_aggression = 0.0
        active_opponents = 0
        
        for player_id in round_state.current_player:
            if player_id != self.id and player_id in self.opponent_stats:
                total_aggression += self.opponent_stats[player_id]['aggression']
                active_opponents += 1
                
        return total_aggression / max(active_opponents, 1)
    
    def _determine_action(self, round_state: RoundStateClient, remaining_chips: int, 
                         hand_strength: float, position_strength: float, pot_odds: float,
                         aggression_factor: float, stack_bb_ratio: float) -> Tuple[PokerAction, int]:
        
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        # Emergency fold for very weak hands
        if hand_strength < 0.1 and call_amount > 0:
            return PokerAction.FOLD, 0
            
        # All-in with very strong hands
        if hand_strength > 0.85 and call_amount > 0:
            return PokerAction.ALL_IN, 0
            
        # Short stack strategy
        if stack_bb_ratio < 10:
            if hand_strength > 0.6:
                return PokerAction.ALL_IN, 0
            elif call_amount > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        
        # No betting action required
        if call_amount == 0:
            if hand_strength > 0.7:
                # Strong hand - bet for value
                bet_size = max(round_state.min_raise, int(round_state.pot * 0.6))
                bet_size = min(bet_size, remaining_chips)
                if bet_size <= remaining_chips:
                    return PokerAction.RAISE, bet_size
            return PokerAction.CHECK, 0
        
        # Facing a bet
        hand_threshold = 0.3 + (aggression_factor * 0.2) - (position_strength * 0.1)
        
        if hand_strength < hand_threshold:
            return PokerAction.FOLD, 0
        elif hand_strength > 0.7 and position_strength > 0.5:
            # Strong hand in good position - raise
            raise_size = max(round_state.min_raise, call_amount + int(round_state.pot * 0.5))
            raise_size = min(raise_size, remaining_chips)
            if raise_size <= remaining_chips and raise_size >= round_state.min_raise:
                return PokerAction.RAISE, raise_size
        
        # Default to call if we can afford it
        if call_amount <= remaining_chips:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store round information for learning
        self.round_history.append({
            'round_num': round_state.round_num,
            'final_pot': round_state.pot,
            'remaining_chips': remaining_chips
        })
        
        # Keep only recent history to manage memory
        if len(self.round_history) > 100:
            self.round_history = self.round_history[-50:]

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended - could implement learning here
        pass