from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hands_played = 0
        self.big_blind_amount = 0
        self.position = ""
        self.hole_cards = []
        self.opponent_aggression = {}
        self.opponent_fold_frequency = {}
        self.game_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.big_blind_amount = blind_amount
        self.hole_cards = player_hands
        self.hands_played = 0
        
        # Initialize opponent tracking
        for player in all_players:
            if player != self.id:
                self.opponent_aggression[player] = 0.5
                self.opponent_fold_frequency[player] = 0.5

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        
        # Determine position
        if len(round_state.current_player) == 2:  # Heads up
            if str(self.id) in round_state.player_bets:
                my_bet = round_state.player_bets[str(self.id)]
                if my_bet == self.big_blind_amount // 2:  # Small blind
                    self.position = "SB"
                else:
                    self.position = "BB"
            else:
                self.position = "BTN"

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate pot odds and hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            opponent_tendency = self._analyze_opponent_behavior(round_state)
            
            # Get the amount needed to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Determine action based on hand strength and situation
            if round_state.current_bet == 0:
                return self._decide_no_bet_action(round_state, remaining_chips, hand_strength)
            elif call_amount >= remaining_chips:
                # All-in decision
                if hand_strength >= 0.6 or (hand_strength >= 0.4 and pot_odds > 1.5):
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return self._decide_bet_action(round_state, remaining_chips, hand_strength, pot_odds, opponent_tendency)
                
        except Exception:
            # Safe fallback
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 10:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _decide_no_bet_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        """Decide action when no bet is made (can check or bet)"""
        # Aggressive betting with strong hands
        if hand_strength >= 0.8:
            bet_size = min(int(round_state.pot * 0.8), remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, bet_size)
        elif hand_strength >= 0.65:
            bet_size = min(int(round_state.pot * 0.6), remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, bet_size)
        elif hand_strength >= 0.45 and round_state.round in ['Flop', 'Turn']:
            # Continuation betting
            bet_size = min(int(round_state.pot * 0.4), remaining_chips)
            if bet_size >= round_state.min_raise:
                return (PokerAction.RAISE, bet_size)
        elif hand_strength >= 0.3 and len(round_state.current_player) == 2:
            # Bluff in heads-up
            if self.hands_played % 4 == 0:  # Bluff 25% of the time
                bet_size = min(int(round_state.pot * 0.5), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
        
        return (PokerAction.CHECK, 0)

    def _decide_bet_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, opponent_tendency: float) -> Tuple[PokerAction, int]:
        """Decide action when facing a bet"""
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Very strong hands - raise
        if hand_strength >= 0.85:
            raise_amount = min(int(round_state.pot * 1.2), remaining_chips)
            if raise_amount >= round_state.min_raise:
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.CALL, 0)
        
        # Strong hands - call or raise
        elif hand_strength >= 0.7:
            if pot_odds > 2.0 or opponent_tendency < 0.4:  # Good odds or weak opponent
                raise_amount = min(int(round_state.pot * 0.8), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        
        # Decent hands - call if odds are good
        elif hand_strength >= 0.5:
            if pot_odds > 1.5:
                return (PokerAction.CALL, 0)
            elif call_amount <= remaining_chips // 20:  # Small bet
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Marginal hands - call only with great odds
        elif hand_strength >= 0.35:
            if pot_odds > 3.0 or call_amount <= remaining_chips // 50:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - mostly fold, occasional bluff
        else:
            if opponent_tendency < 0.3 and self.hands_played % 6 == 0:  # Rare bluff against weak opponents
                raise_amount = min(int(round_state.pot * 1.5), remaining_chips)
                if raise_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            
            if pot_odds > 5.0:  # Extremely good odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 to 1"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        try:
            card1, card2 = self.hole_cards[0], self.hole_cards[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Convert ranks to numbers
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            val1 = rank_values.get(rank1, 7)
            val2 = rank_values.get(rank2, 7)
            
            high_card = max(val1, val2)
            low_card = min(val1, val2)
            is_suited = suit1 == suit2
            is_pair = val1 == val2
            
            # Pre-flop evaluation
            if round_state.round == 'Preflop':
                if is_pair:
                    if high_card >= 10:  # TT+
                        return 0.9
                    elif high_card >= 7:  # 77+
                        return 0.75
                    else:
                        return 0.6
                elif high_card == 14:  # Ace
                    if low_card >= 10:  # AK, AQ, AJ, AT
                        return 0.85 if is_suited else 0.8
                    elif low_card >= 7:  # A9-A7
                        return 0.65 if is_suited else 0.55
                    else:
                        return 0.5 if is_suited else 0.4
                elif high_card == 13:  # King
                    if low_card >= 10:  # KQ, KJ, KT
                        return 0.75 if is_suited else 0.7
                    elif low_card >= 8:
                        return 0.6 if is_suited else 0.5
                    else:
                        return 0.4 if is_suited else 0.3
                elif high_card >= 10:  # QJ, QT, JT
                    if abs(val1 - val2) <= 2:
                        return 0.65 if is_suited else 0.55
                    else:
                        return 0.5 if is_suited else 0.4
                else:
                    if abs(val1 - val2) <= 1 and low_card >= 6:
                        return 0.55 if is_suited else 0.45
                    else:
                        return 0.35 if is_suited else 0.25
            
            # Post-flop evaluation
            else:
                community = round_state.community_cards
                all_cards = [card1, card2] + community
                strength = self._calculate_hand_rank(all_cards)
                
                # Adjust based on draws
                if len(community) < 5:
                    draw_potential = self._calculate_draw_potential(card1, card2, community)
                    strength += draw_potential * 0.1
                
                return min(strength, 1.0)
                
        except Exception:
            return 0.3

    def _calculate_hand_rank(self, cards: List[str]) -> float:
        """Calculate hand rank strength"""
        if len(cards) < 5:
            return 0.3
        
        try:
            ranks = []
            suits = []
            
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            
            for card in cards:
                if len(card) >= 2:
                    ranks.append(rank_values.get(card[0], 7))
                    suits.append(card[1])
            
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            # Check for pairs, trips, quads
            counts = list(rank_counts.values())
            counts.sort(reverse=True)
            
            # Check for flush
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            has_flush = max(suit_counts.values()) >= 5
            
            # Check for straight
            unique_ranks = sorted(set(ranks))
            has_straight = False
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    has_straight = True
                    break
            
            # Royal/Straight flush
            if has_flush and has_straight:
                return 0.95
            
            # Four of a kind
            if counts[0] == 4:
                return 0.9
            
            # Full house
            if counts[0] == 3 and counts[1] >= 2:
                return 0.85
            
            # Flush
            if has_flush:
                return 0.8
            
            # Straight
            if has_straight:
                return 0.75
            
            # Three of a kind
            if counts[0] == 3:
                return 0.7
            
            # Two pair
            if counts[0] == 2 and counts[1] == 2:
                return 0.65
            
            # One pair
            if counts[0] == 2:
                pair_rank = max([rank for rank, count in rank_counts.items() if count == 2])
                if pair_rank >= 10:
                    return 0.6
                else:
                    return 0.5
            
            # High card
            high_card = max(ranks)
            if high_card == 14:
                return 0.45
            elif high_card >= 12:
                return 0.4
            else:
                return 0.35
                
        except Exception:
            return 0.3

    def _calculate_draw_potential(self, card1: str, card2: str, community: List[str]) -> float:
        """Calculate potential for draws"""
        try:
            all_cards = [card1, card2] + community
            suits = [card[1] for card in all_cards if len(card) >= 2]
            ranks = [card[0] for card in all_cards if len(card) >= 1]
            
            # Flush draw
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            if max_suit_count == 4:
                return 0.4  # Flush draw
            
            # Straight draw potential
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            rank_nums = sorted(set([rank_values.get(rank, 0) for rank in ranks]))
            
            gaps = 0
            for i in range(len(rank_nums) - 1):
                if rank_nums[i+1] - rank_nums[i] == 1:
                    gaps += 1
            
            if gaps >= 3:
                return 0.3  # Straight draw potential
            
            return 0.0
            
        except Exception:
            return 0.0

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        try:
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount <= 0:
                return float('inf')
            
            total_pot = round_state.pot + call_amount
            return total_pot / (call_amount + 0.001)
            
        except Exception:
            return 1.0

    def _analyze_opponent_behavior(self, round_state: RoundStateClient) -> float:
        """Analyze opponent aggression level"""
        try:
            for player_id, action in round_state.player_actions.items():
                if int(player_id) != self.id:
                    if action in ['Raise', 'All-in']:
                        self.opponent_aggression[int(player_id)] = min(1.0, self.opponent_aggression.get(int(player_id), 0.5) + 0.1)
                    elif action == 'Fold':
                        self.opponent_fold_frequency[int(player_id)] = min(1.0, self.opponent_fold_frequency.get(int(player_id), 0.5) + 0.05)
            
            # Return average opponent aggression
            if self.opponent_aggression:
                return sum(self.opponent_aggression.values()) / len(self.opponent_aggression)
            else:
                return 0.5
                
        except Exception:
            return 0.5

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game history for learning
        self.game_history.append({
            'round': round_state.round,
            'pot': round_state.pot,
            'chips_change': remaining_chips - getattr(self, 'last_chips', remaining_chips)
        })
        self.last_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        pass