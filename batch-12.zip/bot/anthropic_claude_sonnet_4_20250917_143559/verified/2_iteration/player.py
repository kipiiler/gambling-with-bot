from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.blind_amount = 10
        self.all_players = []
        self.big_blind_player = None
        self.small_blind_player = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Get current bet we need to call
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Pot odds and position considerations
        pot_size = round_state.pot
        num_players = len(round_state.current_player)
        
        # Aggressive strategy based on hand strength and position
        if hand_strength >= 0.8:  # Very strong hands
            if round_state.current_bet == 0:
                # No bet to us, make a strong bet
                bet_size = max(round_state.min_raise, pot_size // 2)
                bet_size = min(bet_size, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # There's a bet, raise if we can
                if call_amount < remaining_chips and round_state.min_raise > 0:
                    raise_size = max(round_state.min_raise, call_amount * 2)
                    raise_size = min(raise_size, remaining_chips - call_amount)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, call_amount + raise_size)
                    else:
                        return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CALL, 0)
                    
        elif hand_strength >= 0.6:  # Good hands
            if round_state.current_bet == 0:
                # No bet, make a moderate bet
                bet_size = max(round_state.min_raise, pot_size // 3)
                bet_size = min(bet_size, remaining_chips)
                if bet_size >= round_state.min_raise and remaining_chips > bet_size:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Call reasonable bets
                if call_amount <= remaining_chips // 4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        elif hand_strength >= 0.4:  # Marginal hands
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Only call small bets
                if call_amount <= remaining_chips // 8 and call_amount <= pot_size // 4:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        else:  # Weak hands
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        
        if not hole_cards or len(hole_cards) != 2:
            return 0.0
            
        # Parse hole cards
        card1_rank, card1_suit = self._parse_card(hole_cards[0])
        card2_rank, card2_suit = self._parse_card(hole_cards[1])
        
        if card1_rank is None or card2_rank is None:
            return 0.0
        
        # Base strength on hole cards
        strength = 0.0
        
        # Pocket pairs
        if card1_rank == card2_rank:
            if card1_rank >= 10:  # JJ, QQ, KK, AA
                strength = 0.9
            elif card1_rank >= 7:  # 77-TT
                strength = 0.7
            else:  # 22-66
                strength = 0.5
        
        # High cards
        elif max(card1_rank, card2_rank) >= 11:  # Ace or King
            if min(card1_rank, card2_rank) >= 10:  # AK, AQ, AJ, KQ, KJ
                strength = 0.8 if card1_suit == card2_suit else 0.75
            elif min(card1_rank, card2_rank) >= 7:  # A7+, K7+
                strength = 0.6 if card1_suit == card2_suit else 0.5
            else:
                strength = 0.4 if card1_suit == card2_suit else 0.3
                
        # Medium pairs and suited connectors
        elif card1_suit == card2_suit:  # Suited
            if abs(card1_rank - card2_rank) <= 2:  # Suited connectors/gaps
                strength = 0.5
            else:
                strength = 0.3
        
        # Connected cards
        elif abs(card1_rank - card2_rank) <= 1:  # Connectors
            strength = 0.4
        else:
            strength = 0.2
            
        # Adjust based on community cards if available
        if community_cards and len(community_cards) >= 3:
            all_cards = hole_cards + community_cards
            made_hand_strength = self._evaluate_made_hand(all_cards)
            strength = max(strength, made_hand_strength)
            
        return min(strength, 1.0)
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string like 'Ah' into (rank, suit)"""
        if len(card) != 2:
            return None, None
            
        rank_char = card[0]
        suit = card[1]
        
        if rank_char == 'A':
            rank = 14
        elif rank_char == 'K':
            rank = 13
        elif rank_char == 'Q':
            rank = 12
        elif rank_char == 'J':
            rank = 11
        elif rank_char == 'T':
            rank = 10
        elif rank_char.isdigit():
            rank = int(rank_char)
        else:
            return None, None
            
        return rank, suit
    
    def _evaluate_made_hand(self, all_cards: List[str]) -> float:
        """Evaluate strength of made hand with community cards"""
        
        if len(all_cards) < 5:
            return 0.0
            
        # Parse all cards
        parsed_cards = []
        for card in all_cards:
            rank, suit = self._parse_card(card)
            if rank is not None:
                parsed_cards.append((rank, suit))
        
        if len(parsed_cards) < 5:
            return 0.0
            
        ranks = [card[0] for card in parsed_cards]
        suits = [card[1] for card in parsed_cards]
        
        # Count ranks and suits
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for various hands
        counts = sorted(rank_counts.values(), reverse=True)
        
        # Four of a kind
        if counts[0] == 4:
            return 0.95
            
        # Full house
        if counts[0] == 3 and counts[1] == 2:
            return 0.9
            
        # Flush
        if max(suit_counts.values()) >= 5:
            return 0.85
            
        # Straight (simplified check)
        sorted_ranks = sorted(set(ranks), reverse=True)
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if sorted_ranks[i] - sorted_ranks[i+4] == 4:
                    return 0.8
                    
        # Three of a kind
        if counts[0] == 3:
            return 0.7
            
        # Two pair
        if counts[0] == 2 and counts[1] == 2:
            return 0.6
            
        # One pair
        if counts[0] == 2:
            return 0.5
            
        # High card
        return 0.3

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass