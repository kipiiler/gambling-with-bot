from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.current_chips = 0
        self.blind_amount = 0
        self.opponents = []
        self.game_history = []
        self.opponent_aggression = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.current_chips = starting_chips
        self.blind_amount = blind_amount
        self.hole_cards = player_hands
        self.opponents = [p for p in all_players if p != self.id]
        
        # Initialize opponent tracking
        for opponent in self.opponents:
            if opponent not in self.opponent_aggression:
                self.opponent_aggression[opponent] = {'raises': 0, 'calls': 0, 'folds': 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update current chips
            self.current_chips = remaining_chips
            
            # Get my current bet for this round
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            
            # Calculate how much I need to call
            call_amount = round_state.current_bet - my_current_bet
            
            # Hand strength evaluation
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Position and pot odds
            pot_odds = self._calculate_pot_odds(round_state, call_amount)
            position_factor = self._get_position_factor(round_state)
            
            # Opponent analysis
            opponent_aggression = self._analyze_opponent_aggression(round_state)
            
            # Betting round adjustment
            round_factor = self._get_round_factor(round_state.round)
            
            # Adjust hand strength based on all factors
            adjusted_strength = hand_strength * round_factor * position_factor
            
            # Decision logic
            if call_amount == 0:
                # We can check
                if adjusted_strength >= 0.7:
                    # Strong hand - bet for value
                    bet_size = max(round_state.min_raise, int(round_state.pot * 0.6))
                    bet_size = min(bet_size, remaining_chips, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                elif adjusted_strength >= 0.4:
                    # Medium hand - check
                    return (PokerAction.CHECK, 0)
                else:
                    # Weak hand - check (it's free)
                    return (PokerAction.CHECK, 0)
            else:
                # There's a bet to call
                if call_amount >= remaining_chips:
                    # All-in situation
                    if adjusted_strength >= 0.6:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                
                # Normal betting situation
                if adjusted_strength >= 0.8:
                    # Very strong hand - raise
                    if opponent_aggression > 0.6:
                        # Opponent is aggressive, be more careful
                        if pot_odds >= 2.0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Calculate raise size
                        raise_size = max(round_state.min_raise, int(round_state.pot * 0.8))
                        total_bet_needed = my_current_bet + call_amount + raise_size
                        
                        if total_bet_needed <= remaining_chips and total_bet_needed > round_state.current_bet:
                            return (PokerAction.RAISE, raise_size)
                        else:
                            return (PokerAction.CALL, 0)
                            
                elif adjusted_strength >= 0.6:
                    # Good hand - call or raise based on pot odds
                    if pot_odds >= 2.0 or (pot_odds >= 1.5 and opponent_aggression < 0.4):
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
                elif adjusted_strength >= 0.4:
                    # Marginal hand - call if pot odds are good
                    if pot_odds >= 3.0:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand - fold
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Safety fallback
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        
        # Parse cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 7), rank_values.get(rank2, 7)
        high_card, low_card = max(val1, val2), min(val1, val2)
        
        # Base strength calculation
        if rank1 == rank2:
            # Pocket pairs
            if val1 >= 13:  # AA, KK
                strength = 0.9
            elif val1 >= 11:  # QQ, JJ
                strength = 0.8
            elif val1 >= 8:  # 88-TT
                strength = 0.7
            else:  # Low pairs
                strength = 0.5
        elif suit1 == suit2:
            # Suited cards
            if high_card == 14 and low_card >= 10:  # A-K, A-Q, A-J, A-T suited
                strength = 0.8
            elif high_card >= 13 and low_card >= 11:  # K-Q, K-J suited
                strength = 0.7
            elif high_card >= 12:  # Any queen high suited
                strength = 0.6
            else:
                strength = 0.4
        else:
            # Offsuit cards
            if high_card == 14 and low_card >= 12:  # A-K, A-Q offsuit
                strength = 0.7
            elif high_card == 14 and low_card >= 10:  # A-J, A-T offsuit
                strength = 0.6
            elif high_card >= 13 and low_card >= 11:  # K-Q, K-J offsuit
                strength = 0.5
            else:
                strength = 0.3
        
        # Adjust based on community cards
        if round_state.community_cards:
            # Simple improvement check
            community_ranks = [card[0] for card in round_state.community_cards]
            if rank1 in community_ranks or rank2 in community_ranks:
                strength += 0.1  # Pair improvement
            
            # Check for possible straights/flushes
            if suit1 == suit2:
                community_suits = [card[1] for card in round_state.community_cards]
                suit_count = community_suits.count(suit1)
                if suit_count >= 2:
                    strength += 0.1  # Flush draw potential
        
        return min(strength, 1.0)

    def _calculate_pot_odds(self, round_state: RoundStateClient, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return float('inf')
        
        total_pot = round_state.pot + call_amount
        return total_pot / (call_amount + 1e-6)  # Add small epsilon to avoid division by zero

    def _get_position_factor(self, round_state: RoundStateClient) -> float:
        """Get position advantage factor"""
        active_players = len(round_state.current_player)
        if active_players <= 2:
            return 1.1  # Heads up - slight advantage
        elif len(round_state.current_player) <= 1:
            return 1.2  # Last to act
        else:
            return 0.9  # Early position

    def _analyze_opponent_aggression(self, round_state: RoundStateClient) -> float:
        """Analyze opponent aggression level"""
        aggression = 0.0
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All_in']:
                    aggression += 0.3
                elif action == 'Call':
                    aggression += 0.1
        
        return min(aggression, 1.0)

    def _get_round_factor(self, round_name: str) -> float:
        """Adjust strategy based on betting round"""
        round_factors = {
            'Preflop': 1.0,
            'Flop': 0.9,
            'Turn': 0.8,
            'River': 0.7
        }
        return round_factors.get(round_name, 0.8)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        
        # Update opponent tracking
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and int(player_id) in self.opponent_aggression:
                opponent_id = int(player_id)
                if action in ['Raise', 'All_in']:
                    self.opponent_aggression[opponent_id]['raises'] += 1
                elif action == 'Call':
                    self.opponent_aggression[opponent_id]['calls'] += 1
                elif action == 'Fold':
                    self.opponent_aggression[opponent_id]['folds'] += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Store game result for learning
        self.game_history.append({
            'score': player_score,
            'final_chips': self.current_chips,
            'opponents': list(all_scores.keys())
        })