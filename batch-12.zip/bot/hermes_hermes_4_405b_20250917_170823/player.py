import itertools

from typing import List, Tuple, Dict, Any
from enum import Enum
from dataclasses import dataclass

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: list[Dict[str, any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.my_hand = []
        self.big_blind = 0
        self.strong_hands = {
            'AA', 'KK', 'QQ', 'JJ', 'TT', '99', '88', '77',
            'AKs', 'AQs', 'AJs', 'ATs', 'KQs', 'KJs', 'QJs', 'JTs',
            'AKo', 'AQo'
        }
    
    def _parse_hand(self, hand_str: str) -> List[str]:
        if ' ' in hand_str:
            return hand_str.split()
        elif len(hand_str) == 4:
            return [hand_str[:2], hand_str[2:4]]
        return [hand_str]
    
    def _card_rank(self, card: str) -> int:
        rank_char = card[0]
        if rank_char == '2': return 2
        if rank_char == '3': return 3
        if rank_char == '4': return 4
        if rank_char == '5': return 5
        if rank_char == '6': return 6
        if rank_char == '7': return 7
        if rank_char == '8': return 8
        if rank_char == '9': return 9
        if rank_char == 'T': return 10
        if rank_char == 'J': return 11
        if rank_char == 'Q': return 12
        if rank_char == 'K': return 13
        if rank_char == 'A': return 14
        return 0
    
    def _get_hand_string(self, hole_cards: List[str]) -> str:
        if len(hole_cards) != 2:
            return ''
        
        card1, card2 = hole_cards
        r1 = self._card_rank(card1)
        r2 = self._card_rank(card2)
        suit1 = card1[1]
        suit2 = card2[1]
        
        if r1 == r2:
            return card1[0] + card2[0]
        else:
            if r1 < r2:
                r1, r2 = r2, r1
                suit1, suit2 = suit2, suit1
                card1, card2 = card2, card1
            hand_str = card1[0] + card2[0]
            if suit1 == suit2:
                hand_str += 's'
            else:
                hand_str += 'o'
            return hand_str
    
    def _evaluate_5cards(self, cards: List[str]) -> Tuple[int, Tuple[int]]:
        rank_counts = {}
        suits = []
        ranks = []
        
        for card in cards:
            r = self._card_rank(card)
            s = card[1]
            ranks.append(r)
            suits.append(s)
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        sorted_ranks = sorted(ranks, reverse=True)
        flush = len(set(suits)) == 1
        
        unique_ranks = sorted(set(ranks))
        straight = False
        straight_high = 0
        
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                straight = True
                straight_high = unique_ranks[i+4]
                break
        
        if not straight and set(unique_ranks) == {2, 3, 4, 5, 14}:
            straight = True
            straight_high = 5
        
        if straight and flush:
            if straight_high == 14:
                return (9, (straight_high,))
            return (8, (straight_high,))
        
        quad_rank = next((r for r, count in rank_counts.items() if count == 4), None)
        if quad_rank is not None:
            kicker = next((r for r in sorted_ranks if r != quad_rank), 0)
            return (7, (quad_rank, kicker))
        
        triple = next((r for r, count in rank_counts.items() if count == 3), None)
        if triple is not None:
            pairs = [r for r, count in rank_counts.items() if count == 2]
            if pairs:
                return (6, (triple, pairs[0]))
            kickers = [r for r in sorted_ranks if r != triple][:2]
            return (3, (triple,) + tuple(kickers))
        
        if flush:
            return (5, tuple(sorted_ranks[:5]))
        
        if straight:
            return (4, (straight_high,))
        
        pairs = sorted([r for r, count in rank_counts.items() if count == 2], reverse=True)
        if len(pairs) >= 2:
            kickers = [r for r in sorted_ranks if r not in pairs[:2]][0]
            return (2, (pairs[0], pairs[1], kickers))
        elif len(pairs) == 1:
            kickers = [r for r in sorted_ranks if r != pairs[0]][:3]
            return (1, (pairs[0],) + tuple(kickers))
        
        return (0, tuple(sorted_ranks[:5]))
    
    def _get_best_hand(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        best_rank = None
        best_kickers = None
        
        for combo in itertools.combinations(all_cards, 5):
            rank, kickers = self._evaluate_5cards(list(combo))
            if best_rank is None or rank > best_rank or (rank == best_rank and kickers > best_kickers):
                best_rank = rank
                best_kickers = kickers
                
        return best_rank, best_kickers
    
    def _has_flush_draw(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        suits = [card[1] for card in all_cards]
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        return any(count >= 4 for count in suit_count.values())
    
    def _has_straight_draw(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        ranks = [self._card_rank(card) for card in all_cards]
        ranks_with_low_ace = ranks.copy()
        for i, r in enumerate(ranks_with_low_ace):
            if r == 14:
                ranks_with_low_ace[i] = 1
                
        unique_ranks = sorted(set(ranks_with_low_ace))
        for i in range(len(unique_ranks) - 3):
            if unique_ranks[i+3] - unique_ranks[i] == 3:
                return True
        return False
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        idx = all_players.index(self.id)
        self.my_hand = self._parse_hand(player_hands[idx])
        self.big_blind = blind_amount
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            if round_state.round == 'Preflop':
                hand_str = self._get_hand_string(self.my_hand)
                if hand_str in self.strong_hands:
                    if round_state.current_bet == 0:
                        amount = 3 * self.big_blind
                        if amount < round_state.min_raise:
                            amount = round_state.min_raise
                        if amount > round_state.max_raise:
                            amount = round_state.max_raise
                        return (PokerAction.RAISE, amount)
                    else:
                        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                        total_bet_we_want = 3 * round_state.current_bet
                        amount = total_bet_we_want - round_state.player_bets.get(str(self.id), 0)
                        if amount < round_state.min_raise:
                            amount = round_state.min_raise
                        if amount > round_state.max_raise:
                            amount = round_state.max_raise
                        return (PokerAction.RAISE, amount)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                hand_rank, kickers = self._get_best_hand(self.my_hand, round_state.community_cards)
                flush_draw = self._has_flush_draw(self.my_hand, round_state.community_cards)
                straight_draw = self._has_straight_draw(self.my_hand, round_state.community_cards)
                
                if hand_rank >= 2:
                    if round_state.current_bet == 0:
                        amount = round_state.pot
                        if amount < round_state.min_raise:
                            amount = round_state.min_raise
                        if amount > round_state.max_raise:
                            amount = round_state.max_raise
                        return (PokerAction.RAISE, amount)
                    else:
                        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                        raise_amount = round_state.pot
                        if raise_amount < round_state.min_raise:
                            raise_amount = round_state.min_raise
                        total_amount = call_amount + raise_amount
                        if total_amount > round_state.max_raise:
                            total_amount = round_state.max_raise
                        return (PokerAction.RAISE, total_amount)
                elif hand_rank == 1:
                    if round_state.current_bet == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                        if call_amount <= 0.1 * round_state.pot:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    if flush_draw or straight_draw:
                        if round_state.current_bet == 0:
                            return (PokerAction.CHECK, 0)
                        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                        if call_amount == 0:
                            return (PokerAction.CHECK, 0)
                        total_pot_after_call = round_state.pot + call_amount
                        required_equity = call_amount / (total_pot_after_call + 1e-7)
                        outs = 9 if flush_draw else 0
                        outs += 5 if straight_draw else 0
                        equity = outs / 47.0
                        if equity > required_equity:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        if round_state.current_bet == 0:
                            return (PokerAction.CHECK, 0)
                        else:
                            return (PokerAction.FOLD, 0)
        except Exception:
            return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass