import itertools
from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.blind_amount = 0
        self.all_players = []
        self.hand_strength_cache = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.big_blind_player_id = big_blind_player_id
            self.small_blind_player_id = small_blind_player_id
            self.blind_amount = blind_amount
            self.all_players = all_players
            
            if self.id in all_players:
                idx = all_players.index(self.id)
                hand_str = player_hands[idx]
                if len(hand_str) == 4:
                    self.hole_cards = [hand_str[0:2], hand_str[2:4]]
                else:
                    self.hole_cards = []
            else:
                self.hole_cards = []
        except Exception:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand_strength_cache = None

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            amount_to_call = round_state.current_bet - my_bet
            
            if round_state.round == 'Preflop':
                return self.handle_preflop(round_state, amount_to_call, remaining_chips)
            else:
                return self.handle_postflop(round_state, amount_to_call, remaining_chips)
        except Exception:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def card_to_tuple(self, card_str: str) -> Tuple[int, str]:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
                    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return (rank_map[card_str[0]], card_str[1])

    def evaluate_hand(self, hand: List[Tuple[int, str]]) -> Tuple[int, ...]:
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        is_flush = len(set(suits)) == 1
        
        straight_high = 0
        if len(set(ranks)) >= 5:
            unique_ranks = sorted(list(set(ranks)), reverse=True)
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    straight_high = unique_ranks[i]
                    break
            if straight_high == 0 and set(ranks) == {14, 2, 3, 4, 5}:
                straight_high = 5
        
        if is_flush and straight_high > 0:
            if straight_high == 14:
                return (9,)
            return (8, straight_high)
        
        if is_flush:
            return (5, ranks)
        
        if straight_high > 0:
            return (4, straight_high)
        
        count_values = sorted(rank_counts.values(), reverse=True)
        if count_values[0] == 4:
            quad_rank = [r for r, cnt in rank_counts.items() if cnt == 4][0]
            kicker = [r for r in ranks if r != quad_rank][0]
            return (7, quad_rank, kicker)
        
        if count_values[0] == 3 and count_values[1] == 2:
            three_rank = [r for r, cnt in rank_counts.items() if cnt == 3][0]
            pair_rank = [r for r, cnt in rank_counts.items() if cnt == 2][0]
            return (6, three_rank, pair_rank)
        
        if count_values[0] == 3:
            three_rank = [r for r, cnt in rank_counts.items() if cnt == 3][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)[:2]
            return (3, three_rank, kickers)
        
        if count_values[0] == 2 and count_values[1] == 2:
            pairs = sorted([r for r, cnt in rank_counts.items() if cnt == 2], reverse=True)
            kicker = [r for r in ranks if r not in pairs][0]
            return (2, pairs[0], pairs[1], kicker)
        
        if count_values[0] == 2:
            pair_rank = [r for r, cnt in rank_counts.items() if cnt == 2][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)[:3]
            return (1, pair_rank, kickers)
        
        return (0, ranks)

    def get_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, ...]:
        if not hole_cards or not community_cards:
            return (0, [])
        cards = [self.card_to_tuple(c) for c in hole_cards + community_cards]
        best = None
        for combo in itertools.combinations(cards, 5):
            score = self.evaluate_hand(list(combo))
            if best is None or score > best:
                best = score
        return best

    def determine_position(self, round_state: RoundStateClient) -> str:
        if not self.all_players or not self.big_blind_player_id or not self.small_blind_player_id:
            return 'middle'
        
        try:
            big_blind_idx = self.all_players.index(self.big_blind_player_id)
            start_idx = (big_blind_idx + 1) % len(self.all_players)
            players_in_order = []
            current = start_idx
            for _ in range(len(self.all_players)):
                players_in_order.append(self.all_players[current])
                current = (current + 1) % len(self.all_players)
            
            num_players = len(players_in_order)
            early_cutoff = num_players // 3
            middle_cutoff = early_cutoff * 2
            
            if self.id in players_in_order[:early_cutoff]:
                return 'early'
            elif self.id in players_in_order[early_cutoff:middle_cutoff]:
                return 'middle'
            else:
                return 'late'
        except Exception:
            return 'middle'

    def hand_to_representation(self, hole_cards: List[str]) -> Tuple[int, int, bool]:
        if len(hole_cards) != 2:
            return (0, 0, False)
        card1 = self.card_to_tuple(hole_cards[0])
        card2 = self.card_to_tuple(hole_cards[1])
        r1, r2 = sorted([card1[0], card2[0]])
        suited = card1[1] == card2[1]
        return (r1, r2, suited)

    def handle_preflop(self, round_state: RoundStateClient, amount_to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.hole_cards:
            return (PokerAction.FOLD, 0)
        
        position = self.determine_position(round_state)
        hand_rep = self.hand_to_representation(self.hole_cards)
        r1, r2, suited = hand_rep
        
        early_set = {
            (10, 10, True), (10, 10, False),
            (11, 11, True), (11, 11, False),
            (12, 12, True), (12, 12, False),
            (13, 13, True), (13, 13, False),
            (14, 14, True), (14, 14, False),
            (10, 11, True), (10, 12, True), (10, 13, True),
            (11, 12, True), (11, 13, True), (11, 14, True),
            (12, 13, True), (12, 14, True),
            (13, 14, True),
            (10, 11, False), (10, 12, False), (10, 13, False),
            (11, 12, False), (11, 13, False), (11, 14, False),
            (12, 13, False), (12, 14, False),
            (13, 14, False)
        }
        
        middle_set = {
            (8, 8, True), (8, 8, False),
            (9, 9, True), (9, 9, False),
            (8, 9, True), (8, 10, True), (8, 11, True),
            (9, 10, True), (9, 11, True), (9, 12, True),
            (10, 11, True), (10, 12, True), (10, 13, True),
            (8, 9, False), (8, 10, False), (8, 11, False),
            (9, 10, False), (9, 11, False), (9, 12, False),
            (10, 11, False), (10, 12, False), (10, 13, False)
        }
        
        late_set = {
            (2, 2, True), (2, 2, False),
            (3, 3, True), (3, 3, False),
            (4, 4, True), (4, 4, False),
            (5, 5, True), (5, 5, False),
            (6, 6, True), (6, 6, False),
            (7, 7, True), (7, 7, False),
            (2, 3, True), (2, 4, True), (2, 5, True),
            (3, 4, True), (3, 5, True), (3, 6, True),
            (4, 5, True), (4, 6, True), (4, 7, True),
            (5, 6, True), (5, 7, True), (5, 8, True),
            (6, 7, True), (6, 8, True), (6, 9, True),
            (7, 8, True), (7, 9, True), (7, 10, True),
            (2, 3, False), (2, 4, False), (2, 5, False),
            (3, 4, False), (3, 5, False), (3, 6, False),
            (4, 5, False), (4, 6, False), (4, 7, False),
            (5, 6, False), (5, 7, False), (5, 8, False),
            (6, 7, False), (6, 8, False), (6, 9, False),
            (7, 8, False), (7, 9, False), (7, 10, False)
        }
        
        playable = False
        strong = False
        if position == 'early' and hand_rep in early_set:
            playable = True
            if r1 >= 10 and r2 >= 10:
                strong = True
        elif position == 'middle' and hand_rep in early_set.union(middle_set):
            playable = True
            if r1 >= 9 and r2 >= 9:
                strong = True
        elif position == 'late' and hand_rep in early_set.union(middle_set).union(late_set):
            playable = True
            if r1 >= 8 and r2 >= 8:
                strong = True
        
        if not playable:
            return (PokerAction.FOLD, 0)
        
        if amount_to_call == 0:
            if strong:
                return (PokerAction.RAISE, round_state.min_raise * 2)
            else:
                return (PokerAction.CALL, 0)
        else:
            if strong:
                return (PokerAction.RAISE, round_state.min_raise * 2)
            elif amount_to_call <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def handle_postflop(self, round_state: RoundStateClient, amount_to_call: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.hole_cards:
            return (PokerAction.FOLD, 0)
        
        if self.hand_strength_cache is None:
            self.hand_strength_cache = self.get_hand_strength(self.hole_cards, round_state.community_cards)
        hand_strength = self.hand_strength_cache
        
        if hand_strength[0] >= 4:
            if amount_to_call == 0:
                return (PokerAction.RAISE, round_state.min_raise * 2)
            else:
                if hand_strength[0] >= 8:
                    raise_amount = min(round_state.max_raise, round_state.min_raise * 3)
                else:
                    raise_amount = min(round_state.max_raise, round_state.min_raise * 2)
                return (PokerAction.RAISE, raise_amount)
        elif hand_strength[0] >= 2:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CALL, 0)
        elif hand_strength[0] == 1:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            elif amount_to_call <= 0.1 * round_state.pot:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.FOLD, 0)