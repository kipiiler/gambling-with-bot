from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_id = None
        self.hand_strength_cache = {}

    def set_id(self, player_id: int) -> None:
        self.player_id = player_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_cache = {}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.player_id), 0)
            call_amount = current_bet - my_bet
            
            if round_state.round == 'Preflop':
                return self.handle_preflop(round_state, remaining_chips, call_amount)
            else:
                return self.handle_postflop(round_state, remaining_chips, call_amount)
        except Exception:
            return (PokerAction.FOLD, 0)

    def handle_preflop(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        hand_rank = self.get_pre_flop_rank()
        
        if hand_rank in self.get_premium_hands():
            raise_amount = 3 * self.blind_amount
            if raise_amount < round_state.min_raise:
                raise_amount = round_state.min_raise
            if raise_amount > remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.RAISE, raise_amount)
        elif hand_rank in self.get_medium_hands():
            if call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.FOLD, 0)

    def handle_postflop(self, round_state: RoundStateClient, remaining_chips: int, call_amount: int) -> Tuple[PokerAction, int]:
        hand_strength = self.evaluate_hand(round_state.community_cards)
        
        if hand_strength >= 4:  # Two pair or better
            bet_amount = round_state.min_raise
            if bet_amount > remaining_chips:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.RAISE, bet_amount)
        elif hand_strength == 3:  # One pair
            if call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def get_pre_flop_rank(self):
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                    '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        r1 = rank_map[self.hole_cards[0][0]]
        r2 = rank_map[self.hole_cards[1][0]]
        suits = [self.hole_cards[0][1], self.hole_cards[1][1]]
        is_suited = suits[0] == suits[1]
        
        if r1 < r2:
            r1, r2 = r2, r1
        
        if r1 == r2:
            return (r1,)
        return (r1, r2, is_suited)

    def get_premium_hands(self):
        premium_pairs = {(14,), (13,), (12,), (11,), (10,)}
        premium_non_pairs = {
            (14, 13, True), (14, 12, True), (14, 11, True), (14, 10, True),
            (13, 12, True), (13, 11, True), (13, 10, True),
            (14, 13, False), (14, 12, False), (14, 11, False), (14, 10, False),
            (13, 12, False), (13, 11, False), (13, 10, False)
        }
        return premium_pairs | premium_non_pairs

    def get_medium_hands(self):
        medium_pairs = {(9,), (8,), (7,)}
        medium_non_pairs = {
            (14, 9, True), (14, 8, True), (14, 7, True), (14, 6, True), (14, 5, True), (14, 4, True), (14, 3, True), (14, 2, True),
            (13, 9, True), (13, 8, True), (13, 7, True), (13, 6, True), (13, 5, True), (13, 4, True), (13, 3, True), (13, 2, True),
            (12, 9, True), (12, 8, True), (12, 7, True), (12, 6, True), (12, 5, True), (12, 4, True), (12, 3, True), (12, 2, True),
            (11, 9, True), (11, 8, True), (11, 7, True), (11, 6, True), (11, 5, True), (11, 4, True), (11, 3, True), (11, 2, True),
            (10, 9, True), (10, 8, True), (10, 7, True),
            (9, 8, True), (8, 7, True),
            (14, 9, False), (14, 8, False), (14, 7, False),
            (13, 9, False), (13, 8, False), (13, 7, False),
            (12, 9, False), (12, 8, False), (12, 7, False),
            (11, 9, False), (11, 8, False), (11, 7, False),
            (10, 9, False), (10, 8, False),
            (9, 8, False)
        }
        return medium_pairs | medium_non_pairs

    def evaluate_hand(self, community_cards: List[str]) -> int:
        cards = self.hole_cards + community_cards
        if len(cards) < 5:
            return 0
        
        cards = [(self.rank_to_value(c[0]), c[1]) for c in cards]
        hand_rank = self.get_hand_rank(cards)
        return hand_rank

    def rank_to_value(self, rank: str) -> int:
        return {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}[rank]

    def get_hand_rank(self, cards: List[Tuple[int, str]]) -> int:
        if len(cards) < 5:
            return 0
        
        flush = False
        flush_suit = None
        if all(card[1] == cards[0][1] for card in cards):
            flush = True
            flush_suit = cards[0][1]
        
        ranks = sorted([card[0] for card in cards], reverse=True)
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        pairs = [r for r, count in rank_counts.items() if count == 2]
        triples = [r for r, count in rank_counts.items() if count == 3]
        quads = [r for r, count in rank_counts.items() if count == 4]
        
        straight = False
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight = True
                break
        if not straight and set(unique_ranks) >= {14, 2, 3, 4, 5}:
            straight = True
        
        if flush and straight:
            return 8  # Straight flush
        if quads:
            return 7  # Four of a kind
        if triples and pairs:
            return 6  # Full house
        if flush:
            return 5  # Flush
        if straight:
            return 4  # Straight
        if triples:
            return 3  # Three of a kind
        if len(pairs) >= 2:
            return 2  # Two pair
        if pairs:
            return 1  # One pair
        return 0  # High card

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass