from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def _rank_char_to_val(rc: str) -> int:
    rc = rc.upper()
    if rc == 'A':
        return 14
    if rc == 'K':
        return 13
    if rc == 'Q':
        return 12
    if rc == 'J':
        return 11
    if rc in ('T', '10'):
        return 10
    # fallback for digits
    try:
        v = int(rc)
        if 2 <= v <= 9:
            return v
    except Exception:
        pass
    # unknown -> minimal
    return 2


def _normalize_card(card: str) -> Optional[str]:
    """
    Normalize a card string to format 'Rs' where R in [2..9,T,J,Q,K,A], s in [h,d,c,s].
    Returns None if invalid.
    """
    if not card or len(card) < 2:
        return None
    card = card.strip()
    # Handle cases like '10h', 'Th', 'tH'
    rank_part = card[:-1]
    suit_part = card[-1].lower()
    rank_part = rank_part.upper()
    if rank_part == '10':
        rank_part = 'T'
    elif rank_part in ['A', 'K', 'Q', 'J']:
        pass
    else:
        # numeric ranks
        try:
            rv = int(rank_part)
            if 2 <= rv <= 9:
                rank_part = str(rv)
            else:
                return None
        except Exception:
            return None
    if suit_part not in ['h', 'd', 'c', 's']:
        return None
    return f"{rank_part}{suit_part}"


def _parse_hole_cards(player_hands: List[str]) -> List[str]:
    """
    Accepts a list like ['As', 'Kd'] or ['As Kd'] and returns normalized two cards if possible.
    """
    cards: List[str] = []
    if not player_hands:
        return cards
    # Player hands might already be two items
    if len(player_hands) == 2:
        for c in player_hands:
            nc = _normalize_card(c)
            if nc:
                cards.append(nc)
        return cards if len(cards) == 2 else []
    # Might be a single string like "As Kd"
    if len(player_hands) == 1:
        parts = player_hands[0].replace(',', ' ').split()
        for p in parts:
            nc = _normalize_card(p)
            if nc:
                cards.append(nc)
        if len(cards) >= 2:
            return cards[:2]
    # General fallback: normalize all entries and pick first two valid
    tmp: List[str] = []
    for p in player_hands:
        nc = _normalize_card(p)
        if nc:
            tmp.append(nc)
    return tmp[:2]


def _card_rank(card: str) -> int:
    return _rank_char_to_val(card[0])


def _card_suit(card: str) -> str:
    return card[1].lower()


def _rank_value_for_chen(rc: str) -> float:
    rc = rc.upper()
    if rc == 'A':
        return 10.0
    if rc == 'K':
        return 8.0
    if rc == 'Q':
        return 7.0
    if rc == 'J':
        return 6.0
    if rc in ('T', '10'):
        return 5.0
    try:
        v = int(rc)
        mapping = {9: 4.5, 8: 4.0, 7: 3.5, 6: 3.0, 5: 2.5, 4: 2.0, 3: 1.5, 2: 1.0}
        return mapping.get(v, 1.0)
    except Exception:
        return 1.0


def chen_score(hand: List[str]) -> float:
    """
    Approximate Chen formula for preflop strength.
    hand: two cards like ['As','Kd']
    """
    if len(hand) != 2:
        return 0.0
    r1 = hand[0][0].upper()
    r2 = hand[1][0].upper()
    s1 = _card_suit(hand[0])
    s2 = _card_suit(hand[1])

    v1 = _rank_value_for_chen(r1)
    v2 = _rank_value_for_chen(r2)

    high = max(v1, v2)
    low = min(v1, v2)
    base = high

    # Pair rule: double base, minimum 5
    if r1 == r2:
        score = max(base * 2.0, 5.0)
    else:
        score = base

    # Suited +2
    if s1 == s2:
        score += 2.0

    # Gap penalty
    # find numerical ranks
    n1 = _rank_char_to_val(r1)
    n2 = _rank_char_to_val(r2)
    gap = abs(n1 - n2) - 1
    if gap <= 0:
        score += 1.0  # connected bonus
    elif gap == 1:
        score += 0.0
    elif gap == 2:
        score -= 1.0
    elif gap == 3:
        score -= 2.0
    else:
        score -= 5.0

    # Ace-low wheel A-2 slight adjust: if A2 suited reduce connected bonus effect
    if {'A', '2'} == {r1, r2}:
        score -= 0.5

    # Do not allow negative
    if score < 0:
        score = 0.0
    return score


def _bitmask_from_ranks(ranks: List[int]) -> int:
    m = 0
    for r in ranks:
        bit = 1 << (r - 2)  # 2->bit0 ... A(14)->bit12
        m |= bit
    return m


def _highest_straight_top(bitmask: int) -> int:
    """
    Returns top rank of the best straight present in the bitmask (2..14),
    with 5 representing A-2-3-4-5 straight (wheel, top=5). Returns 0 if none.
    """
    # Handle A as both high and low; for wheel add A bit to rank 1 concept by manual check
    # Bits: 2..14 => indices 0..12
    # Check 5 consecutive bits
    for top in range(14, 5 - 1, -1):
        # top=14 means 10-J-Q-K-A : indices 8..12
        # compute required mask
        mask = 0
        for r in range(top - 4, top + 1):
            mask |= 1 << (r - 2)
        if (bitmask & mask) == mask:
            return top
    # Wheel A-2-3-4-5: ranks 14,2,3,4,5 => top=5
    wheel_mask = (1 << (14 - 2)) | (1 << (2 - 2)) | (1 << (3 - 2)) | (1 << (4 - 2)) | (1 << (5 - 2))
    if (bitmask & wheel_mask) == wheel_mask:
        return 5
    return 0


def evaluate_7cards(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Evaluate up to 7 cards and return a tuple:
    (category, tiebreakers)
    Category mapping:
      8: Straight flush
      7: Four of a kind
      6: Full house
      5: Flush
      4: Straight
      3: Three of a kind
      2: Two pair
      1: One pair
      0: High card
    tiebreakers is a list of ranks high to low depending on category.
    """
    ranks = [_card_rank(c) for c in cards]
    suits = [_card_suit(c) for c in cards]
    rank_counts: Dict[int, int] = {}
    suit_counts: Dict[str, List[int]] = {'h': [], 'd': [], 'c': [], 's': []}
    for r, s in zip(ranks, suits):
        rank_counts[r] = rank_counts.get(r, 0) + 1
        suit_counts[s].append(r)

    # sort suit lists high->low
    for s in suit_counts:
        suit_counts[s].sort(reverse=True)

    # Straight / Straight Flush detection
    bitmask_all = _bitmask_from_ranks(list(set(ranks)))

    # Check flush and straight flush
    flush_suit = None
    for s, rs in suit_counts.items():
        if len(rs) >= 5:
            flush_suit = s
            break

    if flush_suit is not None:
        bitmask_flush = _bitmask_from_ranks(list(set(suit_counts[flush_suit])))
        st_top = _highest_straight_top(bitmask_flush)
        if st_top:
            # straight flush
            return 8, [st_top]

    # Check four of a kind
    fours = [r for r, c in rank_counts.items() if c == 4]
    if fours:
        quad = max(fours)
        kickers = sorted([r for r in ranks if r != quad], reverse=True)
        return 7, [quad, kickers[0] if kickers else 0]

    # Full house
    trips = sorted([r for r, c in rank_counts.items() if c == 3], reverse=True)
    pairs = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
    if trips:
        if len(trips) >= 2:
            # Use top trip as three, next trip as pair
            return 6, [trips[0], trips[1]]
        if pairs:
            return 6, [trips[0], pairs[0]]

    # Flush
    if flush_suit is not None:
        top5 = suit_counts[flush_suit][:5]
        return 5, top5

    # Straight
    st_top = _highest_straight_top(bitmask_all)
    if st_top:
        return 4, [st_top]

    # Three of a kind
    if trips:
        trip = trips[0]
        kickers = sorted([r for r in ranks if r != trip], reverse=True)[:2]
        return 3, [trip] + kickers

    # Two pair
    if len(pairs) >= 2:
        top2 = pairs[:2]
        remaining = [r for r in ranks if r not in top2]
        kicker = max(remaining) if remaining else 0
        return 2, top2 + [kicker]

    # One pair
    if len(pairs) == 1:
        pair = pairs[0]
        kickers = sorted([r for r in ranks if r != pair], reverse=True)[:3]
        return 1, [pair] + kickers

    # High card
    top5 = sorted(ranks, reverse=True)[:5]
    return 0, top5


def has_flush_draw(cards: List[str]) -> bool:
    suits = {}
    for c in cards:
        s = _card_suit(c)
        suits[s] = suits.get(s, 0) + 1
    return max(suits.values()) >= 4 if suits else False


def straight_draw_strength(cards: List[str]) -> int:
    """
    Returns:
      2 for open-ended straight draw
      1 for gutshot
      0 otherwise
    """
    ranks = sorted(list(set([_card_rank(c) for c in cards])))
    bitmask = _bitmask_from_ranks(ranks)
    # Check windows of length 5 for missing one (gutshot) or two missing?
    # We'll approximate by checking sequences of 4 consecutive present ranks for OESD
    for top in range(14, 5 - 1, -1):
        window = [top - i for i in range(4)]  # 4-long
        if all(((bitmask >> (r - 2)) & 1) for r in window):
            # Need either (top-4) or (top+1) to complete 5
            lower = top - 4
            upper = top + 1
            lower_ok = 2 <= lower <= 14 and ((bitmask >> (lower - 2)) & 1) == 0
            upper_ok = 2 <= upper <= 14 and ((bitmask >> (upper - 2)) & 1) == 0
            # if any missing at ends -> OESD
            return 2
    # Gutshot approximate: check any 5-window missing exactly 1 rank
    for top in range(14, 5 - 1, -1):
        window = [top - i for i in range(5)]
        present = sum(1 for r in window if ((bitmask >> (r - 2)) & 1))
        if present == 4:
            return 1
    # Wheel draw
    wheel = [14, 5, 4, 3, 2]
    present = sum(1 for r in wheel if ((bitmask >> (r - 2)) & 1))
    if present == 4:
        return 1
    return 0


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.current_round_name: str = ""
        self.rng = random.Random(1337)
        self.hand_counter: int = 0
        self.stats: Dict[str, float] = {
            "vpip": 0.0,
            "pfr": 0.0,
            "hands": 0.0
        }
        self.last_round_num: int = -1
        self.current_hand_seen_preflop: bool = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game-level info and update hole cards if provided
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Try to parse and set hole cards for the current hand
        hc = _parse_hole_cards(player_hands)
        if hc:
            self.hole_cards = hc
            self.hand_counter += 1
            self.current_hand_seen_preflop = True
        else:
            # Keep previous if not provided
            if not self.hole_cards:
                self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Detect new hand by round number decreasing or other cues
        # If it's Preflop and we didn't just set hole cards, we might be starting a new hand.
        self.current_round_name = (round_state.round or "").lower()
        # If new top-level hand detection is possible by round_num or pot reset
        if round_state.round_num != self.last_round_num:
            # New betting street or new hand; if Preflop and no hole cards, keep existing
            if self.current_round_name == 'preflop':
                # We expect new hole cards to be provided via a separate callback, but just in case, reset markers
                self.current_hand_seen_preflop = True
                # Do not clear hole_cards here unless provided externally
            self.last_round_num = round_state.round_num

    def _get_our_bet(self, round_state: RoundStateClient) -> int:
        pid_str = str(self.id) if self.id is not None else None
        if pid_str and round_state.player_bets and pid_str in round_state.player_bets:
            try:
                return int(round_state.player_bets[pid_str])
            except Exception:
                return 0
        # Fallback check if keys might be int
        if self.id is not None and self.id in round_state.player_bets:
            try:
                return int(round_state.player_bets[self.id])
            except Exception:
                return 0
        return 0

    def _safe_raise_amount(self, round_state: RoundStateClient, target_mult: float = 1.0) -> Optional[int]:
        """
        Compute a safe raise amount within [min_raise, max_raise].
        target_mult: multiplier to min_raise (e.g., 1.0 means min raise; 2.0 means 2x min raise)
        """
        min_r = max(0, int(round_state.min_raise or 0))
        max_r = max(0, int(round_state.max_raise or 0))
        if min_r <= 0 or max_r <= 0:
            return None
        amt = int(min_r * target_mult)
        if amt < min_r:
            amt = min_r
        if amt > max_r:
            amt = max_r
        # Must ensure amt + current bet > current raise (server guarantees if using min_raise)
        return amt if amt >= min_r else None

    def _pot_odds_call_ok(self, call_amount: int, pot: int, equity: float) -> bool:
        # Call if call_amount / (pot + call_amount) <= equity
        denom = pot + call_amount + 1e-9
        return (call_amount / denom) <= (equity - 1e-9)

    def _decide_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = self._get_our_bet(round_state)
        call_amount = max(0, int(round_state.current_bet) - our_bet)
        can_check = call_amount == 0
        min_r = round_state.min_raise
        max_r = round_state.max_raise

        s = chen_score(self.hole_cards) if self.hole_cards else 0.0

        # Conservative preflop strategy with occasional steals
        # Thresholds
        strong = 8.0
        medium = 6.0
        marginal = 4.5

        # If unraised pot and we can check, raise with strong/medium sometimes, else check
        if can_check:
            if s >= strong:
                # Aggressive raise
                ra = self._safe_raise_amount(round_state, target_mult=2.0) or self._safe_raise_amount(round_state, target_mult=1.0)
                if ra:
                    self.stats["pfr"] += 1.0
                    self.stats["vpip"] += 1.0
                    self.stats["hands"] += 1.0
                    return PokerAction.RAISE, ra
                else:
                    return PokerAction.CHECK, 0
            elif s >= medium:
                # Small raise or check
                if self.rng.random() < 0.5:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        self.stats["pfr"] += 1.0
                        self.stats["vpip"] += 1.0
                        self.stats["hands"] += 1.0
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
            elif s >= marginal:
                # Mostly check; small steal 15% of time
                if self.rng.random() < 0.15:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        self.stats["pfr"] += 1.0
                        self.stats["vpip"] += 1.0
                        self.stats["hands"] += 1.0
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
            else:
                # Weak hand: check
                return PokerAction.CHECK, 0

        # Facing a bet
        # Decide call/raise/fold based on strength and price
        pot = int(round_state.pot)
        blind = max(1, self.blind_amount or 1)
        # Price thresholds
        if s >= strong:
            # Mostly call; sometimes 3-bet minimum
            if self.rng.random() < 0.25:
                ra = self._safe_raise_amount(round_state, target_mult=1.0)
                if ra:
                    self.stats["pfr"] += 1.0
                    self.stats["vpip"] += 1.0
                    self.stats["hands"] += 1.0
                    return PokerAction.RAISE, ra
            self.stats["vpip"] += 1.0
            self.stats["hands"] += 1.0
            return PokerAction.CALL, 0
        elif s >= medium:
            # Call if price not too high (<= 6bb), else fold
            if call_amount <= 6 * blind:
                self.stats["vpip"] += 1.0
                self.stats["hands"] += 1.0
                return PokerAction.CALL, 0
            else:
                self.stats["hands"] += 1.0
                return PokerAction.FOLD, 0
        elif s >= marginal:
            # Call if very small (<= 2.5bb)
            if call_amount <= int(2.5 * blind):
                self.stats["vpip"] += 1.0
                self.stats["hands"] += 1.0
                return PokerAction.CALL, 0
            else:
                self.stats["hands"] += 1.0
                return PokerAction.FOLD, 0
        else:
            self.stats["hands"] += 1.0
            return PokerAction.FOLD, 0

    def _decide_postflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        our_bet = self._get_our_bet(round_state)
        call_amount = max(0, int(round_state.current_bet) - our_bet)
        can_check = call_amount == 0
        pot = int(round_state.pot)
        community = [_normalize_card(c) for c in (round_state.community_cards or []) if _normalize_card(c)]
        board_cards = community
        all_cards: List[str] = []
        if self.hole_cards and len(self.hole_cards) == 2:
            all_cards = self.hole_cards + board_cards

        # If we don't know our cards, play very cautiously
        if len(all_cards) < 2:
            if can_check:
                # Occasional small bluff bet if allowed? We need to RAISE to bet.
                # But if no bet, CHECK; bluffing without hole cards is risky.
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0

        category, tiebreak = evaluate_7cards(all_cards)
        # Draw detection from combined
        flush_draw = has_flush_draw(all_cards)
        sdraw = straight_draw_strength(all_cards)

        # Strength mapping to equity guesses
        # rough equity vs one player:
        equity_map = {
            8: 0.95,  # straight flush
            7: 0.90,  # quads
            6: 0.85,  # full house
            5: 0.75,  # flush
            4: 0.70,  # straight
            3: 0.55,  # trips
            2: 0.45,  # two pair
            1: 0.30,  # one pair
            0: 0.10   # high card
        }
        equity = equity_map.get(category, 0.2)

        # Improve equity if strong draw on flop/turn
        if category <= 1:
            if flush_draw and sdraw == 2:
                equity = max(equity, 0.36)  # combo draw
            elif flush_draw:
                equity = max(equity, 0.20 if self.current_round_name == 'river' else 0.34)
            elif sdraw == 2:
                equity = max(equity, 0.17 if self.current_round_name == 'river' else 0.32)
            elif sdraw == 1:
                equity = max(equity, 0.08 if self.current_round_name == 'river' else 0.16)

        # Decide based on current pressure
        if can_check:
            # Decide to bet/raise if strong
            if category >= 5:
                # Strong value: raise/bet
                ra = self._safe_raise_amount(round_state, target_mult=2.0) or self._safe_raise_amount(round_state, target_mult=1.0)
                if ra:
                    return PokerAction.RAISE, ra
                else:
                    return PokerAction.CHECK, 0
            elif category == 4 or category == 3:
                # Semi-strong: often bet small
                if self.rng.random() < 0.6:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
            elif category == 2:
                # Two pair: small bet ~50% to protect
                if self.rng.random() < 0.5:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
            elif category == 1:
                # One pair: value/protection sometimes
                if self.rng.random() < 0.35:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
            else:
                # High card: rare bluff on dry flops/turns
                if self.rng.random() < 0.15:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        return PokerAction.RAISE, ra
                return PokerAction.CHECK, 0
        else:
            # Facing a bet: decide to call/raise/fold using pot odds
            if category >= 6:
                # Very strong: raise or all-in if short
                ra = self._safe_raise_amount(round_state, target_mult=2.0) or self._safe_raise_amount(round_state, target_mult=1.0)
                if ra:
                    return PokerAction.RAISE, ra
                # If cannot raise, call
                return PokerAction.CALL, 0
            elif category == 5 or category == 4:
                # Strong: call most, raise sometimes
                if self.rng.random() < 0.25:
                    ra = self._safe_raise_amount(round_state, target_mult=1.0)
                    if ra:
                        return PokerAction.RAISE, ra
                # Pot odds call
                if self._pot_odds_call_ok(call_amount, pot, equity):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif category == 3 or category == 2:
                # Medium strength: call if price is right
                if self._pot_odds_call_ok(call_amount, pot, equity):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif category == 1 or flush_draw or sdraw >= 1:
                # Pair or draw: call with proper odds
                if self._pot_odds_call_ok(call_amount, pot, equity):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                # High card: mostly fold
                if self.rng.random() < 0.05 and self._pot_odds_call_ok(call_amount, pot, equity):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Ensure round name
            self.current_round_name = (round_state.round or "").lower()

            # Basic safety: if we are not among current players or no chips, fold
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            # Decide based on street
            if self.current_round_name == 'preflop':
                return self._decide_preflop(round_state, remaining_chips)
            else:
                return self._decide_postflop(round_state, remaining_chips)
        except Exception:
            # On any exception, return a safe action to avoid auto-fold by error handling
            try:
                # If can check, check; else fold
                our_bet = self._get_our_bet(round_state)
                call_amount = max(0, int(round_state.current_bet) - our_bet)
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Detect end of hand if river complete or players folded out
        # Reset hole cards when a new hand likely starts on next preflop
        # We keep hole cards until new ones are provided via on_start to avoid None usage.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No external logging to keep environment clean
        pass