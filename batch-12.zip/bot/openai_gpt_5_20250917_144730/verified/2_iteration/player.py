from typing import List, Tuple, Dict, Any, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def clamp(v: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, v))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session level info
        self.starting_chips: int = 0
        self.small_blind: int = 0
        self.big_blind: int = 0  # will attempt to infer from blind_amount argument
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []

        # Round-level tracking
        self.round_num: int = 0
        self.hole_cards: List[str] = []  # store if provided
        self.random = random.Random(1337)

        # Opponent stats
        self.vpip: Dict[str, int] = {}     # voluntarily put money in preflop
        self.pfr: Dict[str, int] = {}      # preflop raise count
        self.hands_seen: Dict[str, int] = {}

        # Session aggression toggles
        self.open_freq_flop = 0.5
        self.open_freq_turn = 0.35
        self.open_freq_river = 0.3
        self.steal_freq_preflop = 0.35

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize session-level data
        self.starting_chips = starting_chips
        # We will assume blind_amount is big blind if available. If even, also infer small blind.
        self.big_blind = max(1, int(blind_amount))
        # Try to infer small blind; in many games SB = BB/2
        self.small_blind = max(1, self.big_blind // 2)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []

        # If the server provides our hole cards here, store them
        if isinstance(player_hands, list):
            self.hole_cards = player_hands[:]

        # Initialize stats for opponents
        for pid in self.all_players:
            pid_str = str(pid)
            self.vpip[pid_str] = 0
            self.pfr[pid_str] = 0
            self.hands_seen[pid_str] = 0

        # Seed randomness with player_id for reproducibility per tournament, if available
        try:
            if self.id is not None:
                self.random.seed(self.id)
        except Exception:
            pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Track round number and reset any per-round variables
        self.round_num = round_state.round_num

        # We don't have an explicit hole card update in the RoundStateClient definition,
        # but if environment provides them elsewhere, ensure safe handling.
        # Keep previous or empty if not provided.
        # No action needed otherwise.

        # Update stats baseline for each player
        for pid in round_state.player_bets.keys():
            if pid not in self.hands_seen:
                self.hands_seen[pid] = 0
                self.vpip[pid] = 0
                self.pfr[pid] = 0
            self.hands_seen[pid] += 1

    def _get_to_call(self, round_state: RoundStateClient) -> int:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = max(0, int(round_state.current_bet) - int(my_bet))
        return to_call

    def _can_check(self, round_state: RoundStateClient) -> bool:
        return self._get_to_call(round_state) <= 0

    def _safe_raise_amount(self, round_state: RoundStateClient, desired: int) -> Optional[int]:
        """
        Determine a safe raise amount respecting min/max constraints.
        Assumption: min_raise is the minimum increment above a call amount.
        If current_bet == 0, then a "raise" is effectively an opening bet of at least min_raise.
        """
        try:
            min_r = int(round_state.min_raise)
            max_r = int(round_state.max_raise)
        except Exception:
            return None

        if max_r <= 0:
            return None
        # Ensure desired is within [min_raise, max_raise]
        amount = clamp(int(desired), min_r, max_r)
        if amount < min_r:
            return None
        return amount

    def _bet_when_checked(self, round_state: RoundStateClient, street: str) -> Tuple[PokerAction, int]:
        # Determine desired sizing
        pot = max(0, int(round_state.pot))
        # Default to half-pot sizing, but translate to raise amount per environment semantics.
        half_pot = max(1, pot // 2)
        desired = max(half_pot, round_state.min_raise if hasattr(round_state, 'min_raise') else half_pot)

        amt = self._safe_raise_amount(round_state, desired)
        if amt is None:
            # If we cannot produce a valid raise, fall back to CHECK
            return PokerAction.CHECK, 0
        return PokerAction.RAISE, amt

    def _choose_open_bet(self, round_state: RoundStateClient, freq: float) -> Tuple[PokerAction, int]:
        # Randomized betting when checked to, to maintain aggression
        if self.random.random() < freq:
            return self._bet_when_checked(round_state, round_state.round)
        # Otherwise check
        return PokerAction.CHECK, 0

    def _handle_preflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._get_to_call(round_state)
        can_check = self._can_check(round_state)
        players_remaining = len(round_state.current_player) if round_state.current_player else 2

        # Steal attempt when we can check (i.e., likely BB and no raise)
        if can_check:
            # Opening raise frequency scaled by players_remaining (less frequent in multi-way)
            freq = max(0.15, self.steal_freq_preflop - 0.03 * max(0, players_remaining - 2))
            # Desired raise size: 2.5x-3x big blind as open
            desired_open = int(2.5 * max(1, self.big_blind))
            # Randomized open
            if self.random.random() < freq:
                amt = self._safe_raise_amount(round_state, desired_open)
                if amt is not None:
                    return PokerAction.RAISE, amt
            # Otherwise just check
            return PokerAction.CHECK, 0

        # Facing an open/raise preflop
        # Simple rule: call small raises, otherwise fold.
        bb = max(1, self.big_blind)
        # If to_call is up to 2x BB, we call; otherwise fold.
        if to_call <= 2 * bb:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def _handle_postflop(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = self._get_to_call(round_state)
        can_check = self._can_check(round_state)
        pot = max(0, int(round_state.pot))
        tiny = 1e-9

        # Randomized aggression when checked to (c-bet/float-like behavior)
        if can_check:
            if round_state.round.lower() == 'flop':
                return self._choose_open_bet(round_state, self.open_freq_flop)
            elif round_state.round.lower() == 'turn':
                return self._choose_open_bet(round_state, self.open_freq_turn)
            elif round_state.round.lower() == 'river':
                return self._choose_open_bet(round_state, self.open_freq_river)
            else:
                return PokerAction.CHECK, 0

        # Facing a bet: use pot-odds based calling threshold.
        # pot odds = to_call / (pot + to_call)
        pot_odds = to_call / (pot + to_call + tiny)

        # Strategy:
        # - Call small bets often (pot_odds <= 0.25)
        # - Call medium bets sometimes (pot_odds <= 0.4 with some randomness)
        # - Fold big bets usually.
        if pot_odds <= 0.25:
            return PokerAction.CALL, 0
        elif pot_odds <= 0.4:
            if self.random.random() < 0.5:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        else:
            # Occasionally bluff-raise small if bet size is miniscule and raise allowed
            if to_call <= max(1, self.big_blind) and self.random.random() < 0.1:
                desired = max(int(pot * 0.75), round_state.min_raise if hasattr(round_state, 'min_raise') else to_call)
                amt = self._safe_raise_amount(round_state, desired)
                if amt is not None:
                    return PokerAction.RAISE, amt
            return PokerAction.FOLD, 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Ensure sane blinds in case of blind changes
            if round_state.min_raise is not None:
                # Often preflop min_raise equals big blind; keep track conservatively.
                self.big_blind = max(self.big_blind, int(round_state.min_raise))

            street = (round_state.round or '').lower()
            if street == 'preflop':
                return self._handle_preflop(round_state, remaining_chips)
            else:
                return self._handle_postflop(round_state, remaining_chips)
        except Exception:
            # Fallback: avoid exception leading to auto-fold; do a safe action
            try:
                if self._can_check(round_state):
                    return PokerAction.CHECK, 0
                else:
                    # If calling is cheap, call; otherwise fold
                    if self._get_to_call(round_state) <= max(1, self.big_blind):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            except Exception:
                # As last resort, fold
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update simple stats: count VPIP/PFR from round_state.player_actions if available
        try:
            actions = round_state.player_actions or {}
            for pid_str, action in actions.items():
                # Count VPIP if voluntarily put chips in preflop (Call/Raise preflop)
                # We don't have per-street segmentation here; best effort:
                act = (action or '').lower()
                if pid_str not in self.vpip:
                    self.vpip[pid_str] = 0
                if pid_str not in self.pfr:
                    self.pfr[pid_str] = 0
                if pid_str not in self.hands_seen:
                    self.hands_seen[pid_str] = 0

                if 'raise' in act:
                    self.vpip[pid_str] += 1
                    self.pfr[pid_str] += 1
                elif 'call' in act:
                    self.vpip[pid_str] += 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could adjust future aggression based on results; keep it simple.
        try:
            # If we're losing across games, slightly increase aggression to compensate
            if player_score is not None and player_score < 0:
                self.open_freq_flop = min(0.65, self.open_freq_flop + 0.05)
                self.open_freq_turn = min(0.5, self.open_freq_turn + 0.03)
                self.open_freq_river = min(0.45, self.open_freq_river + 0.02)
                self.steal_freq_preflop = min(0.5, self.steal_freq_preflop + 0.05)
            elif player_score is not None and player_score > 0:
                # Winning: lock in with slightly less variance
                self.open_freq_flop = max(0.4, self.open_freq_flop - 0.03)
                self.open_freq_turn = max(0.25, self.open_freq_turn - 0.02)
                self.open_freq_river = max(0.2, self.open_freq_river - 0.01)
                self.steal_freq_preflop = max(0.25, self.steal_freq_preflop - 0.03)
        except Exception:
            pass