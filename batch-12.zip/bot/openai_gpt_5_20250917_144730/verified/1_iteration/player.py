from typing import List, Tuple, Dict, Any, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_TO_VAL = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}
VAL_TO_RANK = {v: k for k, v in RANK_TO_VAL.items()}
SUITS = ['h', 'd', 'c', 's']


def card_rank(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    return RANK_TO_VAL.get(card[0].upper(), 0)


def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()


def sorted_ranks_desc(ranks: List[int]) -> List[int]:
    return sorted(ranks, reverse=True)


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.players: List[int] = []
        self.active_players: List[int] = []
        self.hole_cards: List[str] = []  # e.g., ['Ah', 'Kd']
        self.round_num: int = 0
        self.last_round_seen: int = -1
        self.random = random.Random()
        self.random.seed(123456789)  # deterministic
        # Aggression tuning
        self.aggression = 0.5  # 0 to 1
        self.table_looseness = 0.5

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game/session wide state
        self.starting_chips = starting_chips
        self.blind_amount = max(1, blind_amount)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = list(all_players) if all_players else []
        # If we are given initial hole cards
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.hole_cards = [player_hands[0], player_hands[1]]
        else:
            self.hole_cards = []
        self.round_num = 0
        self.last_round_seen = -1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round variables and try to fetch hole cards if present in round_state via non-standard keys
        self.round_num = round_state.round_num
        # Attempt to fetch hole cards if provided by engine via extra attributes (defensive)
        # Some engines might add 'player_hands' or 'hole_cards' to the message
        hole = self._extract_hole_cards_from_state(round_state)
        if hole:
            self.hole_cards = hole
        # Track active players from player_actions if available
        self.active_players = self._infer_active_players(round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive guards
        try:
            epsilon = 1e-9
            my_id_str = str(self.id)
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(round_state.current_bet)
            amount_to_call = max(0, current_bet - my_bet)
            min_raise = int(round_state.min_raise) if isinstance(round_state.min_raise, int) else 0
            max_raise = int(round_state.max_raise) if isinstance(round_state.max_raise, int) else 0
            pot = int(round_state.pot)
            street = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'
            comm_cards = list(round_state.community_cards) if round_state.community_cards else []
            # Update active players if needed
            self.active_players = self._infer_active_players(round_state)
            num_active_players = max(1, len(self.active_players)) if self.active_players else max(2, len(self.players))  # assume at least 2
            # If we have no chips, check or fold
            if remaining_chips <= 0:
                if amount_to_call <= 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Use min_raise fallback if weird values
            if min_raise <= 0:
                # try to infer a sensible min_raise as blind or 1
                inferred = max(1, self.blind_amount)
                min_raise = min(inferred, max_raise if max_raise > 0 else inferred)

            # Preflop strategy if we know our hole cards
            if street.lower() == 'preflop':
                return self._act_preflop(round_state, remaining_chips, amount_to_call, min_raise, max_raise, pot, num_active_players)

            # Postflop
            return self._act_postflop(round_state, remaining_chips, amount_to_call, min_raise, max_raise, pot, comm_cards, num_active_players)
        except Exception:
            # Fail-safe: never crash; fold if something is wrong
            if round_state.current_bet <= round_state.player_bets.get(str(self.id), 0):
                return (PokerAction.CHECK, 0)
            else:
                # If can't check, fold
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear our per-round hole cards unless engine persists them
        self.hole_cards = []
        self.active_players = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could adjust aggression or looseness based on results; keep simple
        pass

    # ============================= Helper methods =============================

    def _extract_hole_cards_from_state(self, round_state: RoundStateClient) -> Optional[List[str]]:
        # Try to defensively extract from potential extended fields
        # Not in the provided dataclass, but some engines may put it in player_actions as a reveal, not helpful here
        # We return None if not found
        try:
            # Attempt to access hidden metadata
            if hasattr(round_state, 'player_hands') and isinstance(round_state.player_hands, dict):
                # possibly keyed by str(player_id)
                my_id_str = str(self.id)
                val = round_state.player_hands.get(my_id_str)
                if isinstance(val, list) and len(val) >= 2:
                    return [val[0], val[1]]
            if hasattr(round_state, 'hole_cards') and isinstance(round_state.hole_cards, list) and len(round_state.hole_cards) >= 2:
                return [round_state.hole_cards[0], round_state.hole_cards[1]]
        except Exception:
            pass
        # Else, if on_start passed initial cards and we still hold them, keep
        if self.hole_cards and len(self.hole_cards) >= 2:
            return self.hole_cards
        return None

    def _infer_active_players(self, round_state: RoundStateClient) -> List[int]:
        # Build a list of players who haven't folded (rough heuristic based on actions)
        active = []
        try:
            actions = round_state.player_actions or {}
            # If we have known players list
            candidates = self.players if self.players else [int(pid) for pid in actions.keys() if pid.isdigit()]
            for pid in candidates:
                s_pid = str(pid)
                act = actions.get(s_pid, "")
                if isinstance(act, str):
                    if 'Fold' in act or act.lower() == 'fold':
                        continue
                active.append(pid)
            # If no candidates and we have current_player list
            if not active and round_state.current_player:
                active = [int(pid) for pid in round_state.current_player]
        except Exception:
            # fallback
            active = self.players[:] if self.players else []
        return active

    def _act_preflop(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, min_raise: int, max_raise: int, pot: int, num_active_players: int) -> Tuple[PokerAction, int]:
        # If we don't know our hole cards, play very tight: only call in big blind when free or fold to raises; occasionally open raise with small probability if checked to us
        if len(self.hole_cards) < 2 or not self._valid_card(self.hole_cards[0]) or not self._valid_card(self.hole_cards[1]):
            if amount_to_call <= 0:
                # Sometimes open-raise small if unopened and random
                if self.random.random() < 0.05 and max_raise >= min_raise:
                    raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=0.6, floor=min_raise)
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            else:
                # Very tight fold if we don't know cards
                if amount_to_call <= max(1, self.blind_amount) and self.random.random() < 0.1:
                    # defend occasionally cheap
                    if remaining_chips <= amount_to_call:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        c1, c2 = self.hole_cards[0], self.hole_cards[1]
        s = self._chen_score(c1, c2)  # 0..>20
        s_norm = min(1.0, s / 20.0)  # normalize to ~[0,1]
        # Adjust by number of players (tighter when more players)
        players_factor = max(0.6, min(1.2, 1.05 - 0.05 * (num_active_players - 2)))
        strength = s_norm * players_factor

        # If facing no raise (amount_to_call == 0): open with stronger hands
        if amount_to_call <= 0:
            if strength >= 0.7:
                # Premium open
                raise_amt = self._choose_raise_size(min_raise, max_raise, pot=max(pot, self.blind_amount * 3), target_frac=0.8, floor=min_raise * 2)
                return (PokerAction.RAISE, raise_amt)
            elif strength >= 0.5:
                # Standard open
                raise_amt = self._choose_raise_size(min_raise, max_raise, pot=max(pot, self.blind_amount * 2), target_frac=0.6, floor=min_raise)
                # Mix in some checks with marginal hands
                if self.random.random() < 0.2:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.RAISE, raise_amt)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Facing a raise: decide call/3bet/fold
            # Compute effective pot odds
            call_amt = amount_to_call
            # If we don't have enough to call
            if call_amt >= remaining_chips:
                # Decide whether to go all-in based on strength
                if strength >= 0.85:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            pot_odds = call_amt / (pot + call_amt + 1e-9)
            # 3-bet with very strong hands
            if strength >= 0.85 and max_raise >= min_raise:
                # choose a 3b size around 3x raise or pot-proportional
                target = max(min_raise, int(max(self.blind_amount * 6, pot * 0.8)))
                raise_amt = max(min_raise, min(max_raise, target))
                # Sometimes jam with top range if short SPR
                if remaining_chips < pot * 2 and self.random.random() < 0.5:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, raise_amt)
            # Call if hand is decent and pot odds are ok
            call_threshold = 0.9 * pot_odds + 0.15  # require slightly more than pot odds
            if strength >= call_threshold:
                return (PokerAction.CALL, 0)
            # Occasionally defend light if cheap
            if call_amt <= self.blind_amount and strength >= 0.35 and self.random.random() < 0.3:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

    def _act_postflop(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, min_raise: int, max_raise: int, pot: int, community_cards: List[str], num_active_players: int) -> Tuple[PokerAction, int]:
        # If we don't know our hole cards, play passively
        if len(self.hole_cards) < 2 or not self._valid_card(self.hole_cards[0]) or not self._valid_card(self.hole_cards[1]):
            if amount_to_call <= 0:
                # small stab occasionally
                if self.random.random() < 0.05 and max_raise >= min_raise:
                    raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=0.4, floor=min_raise)
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            else:
                # fold most of the time without info; occasionally call small bet
                if amount_to_call <= max(1, pot // 10) and self.random.random() < 0.2:
                    if remaining_chips <= amount_to_call:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        # Evaluate made hand and draws
        my_cards = self.hole_cards + community_cards
        hand_rank_tuple, category = self._evaluate_7cards(my_cards)
        board_rank_tuple, board_category = self._evaluate_7cards(community_cards) if len(community_cards) >= 5 else (None, -1)
        # Determine if we are just playing the board (no kicker advantage)
        plays_board = (board_rank_tuple is not None and hand_rank_tuple == board_rank_tuple)

        # Assess draws
        draws = self._detect_draws(self.hole_cards, community_cards)
        outs = draws.get('outs', 0)
        oesd = draws.get('oesd', False)
        gutshot = draws.get('gutshot', False)
        flush_draw = draws.get('flush_draw', False)

        # Approx equity estimate
        round_name = (round_state.round or '').lower()
        remaining_draws = 2 if round_name == 'flop' else 1 if round_name == 'turn' else 0
        draw_equity = 0.0
        if remaining_draws == 2:
            # by river from flop
            # Use exact combinatorial approx: P = 1 - C(47-outs,2)/C(47,2)
            # but to avoid heavy math, use rule-of-4 approx
            draw_equity = min(0.99, outs * 0.04)
        elif remaining_draws == 1:
            draw_equity = min(0.99, outs * 0.02)
        else:
            draw_equity = 0.0

        made_equity = self._made_hand_equity_estimate(category, community_cards, self.hole_cards, plays_board, num_active_players)
        equity = max(made_equity, draw_equity)

        # Pot odds to call
        if amount_to_call > 0:
            pot_odds = amount_to_call / (pot + amount_to_call + 1e-9)
        else:
            pot_odds = 0.0

        # Decide action
        # If no bet yet: consider betting for value or semi-bluffing
        if amount_to_call <= 0:
            # Value bet with strong made hands
            if category >= 4:  # Straight or better
                bet_frac = 0.65 if category < 6 else 0.8
                raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=bet_frac, floor=min_raise)
                return (PokerAction.RAISE, raise_amt)
            # Trips or two pair
            if category == 3 or category == 2:
                bet_frac = 0.6 if category == 3 else 0.5
                raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=bet_frac, floor=min_raise)
                # Occasionally slowplay
                if self.random.random() < 0.15:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.RAISE, raise_amt)
            # One pair: c-bet sometimes esp. with top pair or strong kicker
            if category == 1:
                top_pair_like = self._is_top_pair_or_overpair(self.hole_cards, community_cards)
                if top_pair_like:
                    if self.random.random() < 0.8:
                        raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=0.4, floor=min_raise)
                        return (PokerAction.RAISE, raise_amt)
                else:
                    if self.random.random() < 0.3:
                        raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=0.35, floor=min_raise)
                        return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            # Semi-bluff draws
            if flush_draw or oesd or gutshot:
                if self.random.random() < 0.6:
                    raise_amt = self._choose_raise_size(min_raise, max_raise, pot, target_frac=0.45, floor=min_raise)
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            # Otherwise check
            return (PokerAction.CHECK, 0)
        else:
            # Facing a bet: decide call/raise/fold based on equity vs pot odds
            # If we can't afford the call
            if amount_to_call >= remaining_chips:
                # Jam only with strong
                if equity >= 0.7:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Compare equity to pot odds
            # Multiway adjust: require higher equity with more players
            multi_adj = 1.0 + 0.1 * max(0, num_active_players - 2)
            call_threshold = min(0.95, pot_odds * multi_adj * 1.05)
            if equity >= max(call_threshold, 0.25):
                # Value raise with very strong hands; semi-bluff sometimes with strong draws
                should_raise = False
                target_frac = 0.6
                if category >= 4:
                    should_raise = True
                    target_frac = 0.7
                elif category == 3 or category == 2:
                    should_raise = True if self.random.random() < 0.7 else False
                    target_frac = 0.6
                elif (flush_draw or oesd) and self.random.random() < 0.35:
                    should_raise = True
                    target_frac = 0.55
                # All-in if SPR is low and strong
                spr = (remaining_chips - amount_to_call) / (pot + amount_to_call + 1e-9)
                if equity >= 0.85 and spr < 2.0 and self.random.random() < 0.5:
                    return (PokerAction.ALL_IN, 0)
                if should_raise and max_raise >= min_raise:
                    raise_amt = self._choose_raise_size(min_raise, max_raise, pot + amount_to_call, target_frac=target_frac, floor=min_raise)
                    return (PokerAction.RAISE, raise_amt)
                else:
                    return (PokerAction.CALL, 0)
            else:
                # if draw and implied odds are good, consider calling small bets
                if (flush_draw or oesd) and amount_to_call <= pot * 0.25 and equity >= pot_odds * 0.8:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def _valid_card(self, c: str) -> bool:
        return isinstance(c, str) and len(c) >= 2 and c[0].upper() in RANK_TO_VAL and c[1].lower() in SUITS

    def _choose_raise_size(self, min_raise: int, max_raise: int, pot: int, target_frac: float = 0.6, floor: int = 0) -> int:
        # Choose a raise (bet) size relative to pot, clamped to allowed range
        if max_raise <= 0:
            return max(0, min_raise)
        target = int(max(floor, target_frac * max(1, pot)))
        # add small randomness
        jitter = 0.1 + self.random.random() * 0.2
        target = int(target * jitter)
        # Ensure at least min_raise
        target = max(min_raise, target)
        # Clamp to max_raise
        target = min(max_raise, target)
        # Avoid zero
        if target <= 0:
            target = min_raise if min_raise > 0 else 1
        return target

    def _chen_score(self, c1: str, c2: str) -> float:
        # Chen formula approximation for preflop hand strength
        r1, r2 = card_rank(c1), card_rank(c2)
        s1, s2 = card_suit(c1), card_suit(c2)
        ranks = sorted([r1, r2], reverse=True)
        high, low = ranks[0], ranks[1]
        # base points for highest card
        def base_points(r):
            if r == 14:
                return 10
            elif r == 13:
                return 8
            elif r == 12:
                return 7
            elif r == 11:
                return 6
            else:
                return r / 2.0
        pts = base_points(high)
        # Pair bonus: double points, ensure at least 5
        if r1 == r2:
            pts = max(5, pts * 2)
        # suited bonus
        if s1 == s2:
            pts += 2
        # gap penalty
        gap = max(0, high - low - 1)
        if gap == 0:
            pts += 0
        elif gap == 1:
            pts -= 1
        elif gap == 2:
            pts -= 2
        elif gap == 3:
            pts -= 4
        else:
            pts -= 5
        # bonus for low straight potential (if connected and low ranks)
        if (gap == 0 or gap == 1) and high < 12:
            pts += 1
        # cap lower bound
        pts = max(0.0, pts)
        return pts

    def _evaluate_7cards(self, cards: List[str]) -> Tuple[Tuple, int]:
        # Returns ((category, tiebreakers...)), category int where:
        # 8: Straight Flush, 7: Four of a Kind, 6: Full House, 5: Flush, 4: Straight,
        # 3: Three of a Kind, 2: Two Pair, 1: One Pair, 0: High Card
        if not cards:
            return ((0, 0, 0, 0, 0, 0), 0)
        ranks = [card_rank(c) for c in cards if self._valid_card(c)]
        suits = [card_suit(c) for c in cards if self._valid_card(c)]
        if not ranks:
            return ((0, 0, 0, 0, 0, 0), 0)

        # Count suits for flush
        suit_counts: Dict[str, List[int]] = {s: [] for s in SUITS}
        for r, s in zip(ranks, suits):
            suit_counts[s].append(r)
        flush_suit = None
        for s, rs in suit_counts.items():
            if len(rs) >= 5:
                flush_suit = s
                break

        # Count ranks
        rank_count: Dict[int, int] = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        counts_sorted = sorted(rank_count.items(), key=lambda x: (x[1], x[0]), reverse=True)
        distinct_ranks_desc = sorted(rank_count.keys(), reverse=True)

        # Helper to find best straight high
        def straight_high(ranks_list: List[int]) -> int:
            uniq = sorted(set(ranks_list))
            # Handle wheel A-2-3-4-5: treat Ace as 1 as well
            if 14 in uniq:
                uniq.insert(0, 1)
            longest_high = 0
            run = 1
            for i in range(1, len(uniq)):
                if uniq[i] == uniq[i - 1] + 1:
                    run += 1
                else:
                    run = 1
                if run >= 5:
                    longest_high = max(longest_high, uniq[i])
            return longest_high

        # Straight flush check
        if flush_suit:
            flush_ranks = [r for r, s in zip(ranks, suits) if s == flush_suit]
            sf_high = straight_high(flush_ranks)
            if sf_high > 0:
                return ((8, sf_high), 8)

        # Four of a kind
        if counts_sorted[0][1] == 4:
            quad = counts_sorted[0][0]
            kicker = max([r for r in distinct_ranks_desc if r != quad]) if len(distinct_ranks_desc) > 1 else 0
            return ((7, quad, kicker), 7)

        # Full house
        trips = [r for r, c in rank_count.items() if c == 3]
        pairs = [r for r, c in rank_count.items() if c == 2]
        if trips:
            t_high = max(trips)
            remaining = [r for r in trips if r != t_high] + pairs
            if remaining:
                p_high = max(remaining)
                return ((6, t_high, p_high), 6)

        # Flush
        if flush_suit:
            flush_ranks_sorted = sorted([r for r, s in zip(ranks, suits) if s == flush_suit], reverse=True)[:5]
            return ((5, *flush_ranks_sorted), 5)

        # Straight
        s_high = straight_high(ranks)
        if s_high > 0:
            return ((4, s_high), 4)

        # Three of a kind
        if trips:
            t_high = max(trips)
            kickers = [r for r in distinct_ranks_desc if r != t_high][:2]
            while len(kickers) < 2:
                kickers.append(0)
            return ((3, t_high, kickers[0], kickers[1]), 3)

        # Two pair
        if len(pairs) >= 2:
            p_sorted = sorted(pairs, reverse=True)
            p1, p2 = p_sorted[0], p_sorted[1]
            kicker = max([r for r in distinct_ranks_desc if r != p1 and r != p2]) if len(distinct_ranks_desc) > 2 else 0
            return ((2, p1, p2, kicker), 2)

        # One pair
        if len(pairs) == 1:
            p = pairs[0]
            kickers = [r for r in distinct_ranks_desc if r != p][:3]
            while len(kickers) < 3:
                kickers.append(0)
            return ((1, p, kickers[0], kickers[1], kickers[2]), 1)

        # High card
        highcards = distinct_ranks_desc[:5]
        while len(highcards) < 5:
            highcards.append(0)
        return ((0, *highcards), 0)

    def _detect_draws(self, hole: List[str], board: List[str]) -> Dict[str, Any]:
        # Detect simple flush draw and straight draw types; return outs
        result = {'flush_draw': False, 'oesd': False, 'gutshot': False, 'outs': 0}
        try:
            cards = (hole or []) + (board or [])
            if len(cards) < 3 or len(hole) < 1:
                return result
            ranks = [card_rank(c) for c in cards if self._valid_card(c)]
            suits = [card_suit(c) for c in cards if self._valid_card(c)]
            # Flush draw: exactly 4 cards to a flush (consider suits including at least one of hole cards)
            suit_counts: Dict[str, int] = {}
            for s in suits:
                suit_counts[s] = suit_counts.get(s, 0) + 1
            flush_suit = None
            for s, cnt in suit_counts.items():
                if cnt == 4:
                    flush_suit = s
                    break
            if flush_suit:
                # Ensure at least one of our hole cards is of that suit to realistically have draw
                if any(card_suit(c) == flush_suit for c in hole):
                    result['flush_draw'] = True

            # Straight draw detection using set of ranks
            uniq = set(ranks)
            if 14 in uniq:
                uniq_with_ace_low = uniq | {1}
            else:
                uniq_with_ace_low = uniq
            oesd, gutshot = self._straight_draw_type(uniq_with_ace_low)
            result['oesd'] = oesd
            result['gutshot'] = gutshot

            outs = 0
            if result['flush_draw']:
                outs += 9
            if result['oesd']:
                outs += 8
            elif result['gutshot']:
                outs += 4
            # Cap outs to 15 to avoid overcounting
            outs = min(outs, 15)
            result['outs'] = outs
        except Exception:
            pass
        return result

    def _straight_draw_type(self, ranks_set: set) -> Tuple[bool, bool]:
        # Return (oesd, gutshot)
        # Check all 5-length windows from A(14) down to 5 (considering Ace can be 1 via ranks_set inclusion)
        oesd = False
        gutshot = False
        for high in range(14, 5 - 1, -1):
            window = [high - i for i in range(0, 5)]
            present = [r in ranks_set for r in window]
            cnt = sum(1 for p in present if p)
            if cnt == 5:
                # Already a straight; not a draw
                continue
            if cnt == 4:
                # Find missing position
                missing_idx = [i for i, p in enumerate(present) if not p]
                if len(missing_idx) == 1:
                    mi = missing_idx[0]
                    # OESD if missing is at either end
                    if mi == 0 or mi == 4:
                        oesd = True
                    else:
                        gutshot = True
            elif cnt == 3:
                # two-gapper inside counts as gutshot at best -> ignore to be conservative
                pass
        return (oesd, gutshot)

    def _made_hand_equity_estimate(self, category: int, board: List[str], hole: List[str], plays_board: bool, num_active_players: int) -> float:
        # Rough equity estimate of our current hand strength vs one opponent; scaled for multiway
        # base heads-up estimates
        if category >= 8:  # straight flush
            base = 0.995
        elif category == 7:  # quads
            base = 0.99
        elif category == 6:  # full house
            base = 0.97
        elif category == 5:  # flush
            base = 0.86
        elif category == 4:  # straight
            base = 0.82
        elif category == 3:  # trips
            base = 0.75
        elif category == 2:  # two pair
            base = 0.68
        elif category == 1:  # one pair -> depends on kicker/top pair/overpair
            if self._is_overpair(hole, board):
                base = 0.65
            elif self._is_top_pair_or_overpair(hole, board):
                base = 0.6
            else:
                # weak pair
                base = 0.4
        else:
            # high card only
            base = 0.2

        # If we are just playing the board, reduce equity
        if plays_board and category <= 4:
            base = min(base, 0.45)

        # Multiway scaling: reduce equity with more players
        if num_active_players > 2:
            scale = max(0.5, 1.0 - 0.1 * (num_active_players - 2))
            base *= scale
        # Bound
        return max(0.01, min(0.99, base))

    def _is_top_pair_or_overpair(self, hole: List[str], board: List[str]) -> bool:
        return self._is_overpair(hole, board) or self._is_top_pair(hole, board)

    def _is_overpair(self, hole: List[str], board: List[str]) -> bool:
        if len(hole) < 2 or len(board) < 3:
            return False
        r1, r2 = card_rank(hole[0]), card_rank(hole[1])
        if r1 != r2:
            return False
        max_board = max(card_rank(c) for c in board if self._valid_card(c))
        return r1 > max_board

    def _is_top_pair(self, hole: List[str], board: List[str]) -> bool:
        if len(hole) < 2 or len(board) < 3:
            return False
        board_ranks = [card_rank(c) for c in board if self._valid_card(c)]
        max_board = max(board_ranks) if board_ranks else 0
        r1, r2 = card_rank(hole[0]), card_rank(hole[1])
        pair_rank = 0
        # Determine if we have a pair that involves top board card
        if r1 == r2:
            pair_rank = r1
        else:
            # Do we pair a board card?
            if r1 in board_ranks:
                pair_rank = r1
            if r2 in board_ranks and r2 > pair_rank:
                pair_rank = r2
        return pair_rank == max_board