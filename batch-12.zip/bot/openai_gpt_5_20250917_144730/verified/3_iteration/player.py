from typing import List, Tuple, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game-level tracking
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.players: List[int] = []
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None

        # Round-level tracking
        self.round_num: int = 0
        self.position: str = "UNKNOWN"  # "SB", "BB", "OTHER"
        self.current_hand: List[str] = []  # Not always provided by engine; keep for compatibility
        self.rng = random.Random()

        # Strategy parameters (simple, conservative)
        self.open_raise_chance = 0.0  # avoid raises preflop when unopened to eliminate invalid-action risks
        self.call_pot_odds_factor_pre = 0.10  # call if to_call <= 10% of pot (preflop)
        self.call_pot_odds_factor_post = 0.15  # slightly looser post-flop
        self.max_call_abs = 200  # never call more than this absolute amount with unknown hand

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        # Initialize per-game state
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.players = all_players[:]
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.current_hand = player_hands[:] if player_hands else []
        # Seed RNG with a combination of IDs and blinds to get some variability but determinism per game
        seed_val = (starting_chips + blind_amount + (self.id or 0)) % (2**32 - 1)
        self.rng.seed(seed_val)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Determine position from posted blinds if available
        my_bet = self._get_my_bet(round_state)
        # Heuristic: if our bet equals small blind, we are SB; if equals big blind, we are BB; else OTHER
        if my_bet == max(1, self.blind_amount // 2):
            self.position = "SB"
        elif my_bet == self.blind_amount:
            self.position = "BB"
        else:
            self.position = "OTHER"

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Basic safety checks
            if remaining_chips <= 0:
                # Out of chips, attempt to check if possible, else fold (engine may auto-handle)
                if self._can_check(round_state):
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

            my_bet = self._get_my_bet(round_state)
            current_bet = max(0, int(round_state.current_bet))
            to_call = max(0, current_bet - my_bet)
            pot = max(0, int(round_state.pot))
            min_raise_amt = max(1, int(round_state.min_raise))
            max_raise_amt = max(0, int(round_state.max_raise))

            # Determine street
            street = (round_state.round or "").lower()

            # If we can check, generally check to avoid unnecessary risk
            if to_call == 0:
                # Optional: very rare open-raises with a safe, validated amount (kept 0 to prevent invalid raises)
                if self.open_raise_chance > 0 and self.rng.random() < self.open_raise_chance:
                    raise_amt = self._compute_valid_raise_amount(round_state, my_bet)
                    if raise_amt is not None:
                        return PokerAction.RAISE, int(raise_amt)
                # Default safe action
                return PokerAction.CHECK, 0

            # Facing a bet: decide between fold/call/raise
            # Pot odds thresholds differ slightly pre vs post flop
            call_factor = self.call_pot_odds_factor_pre if street == "preflop" else self.call_pot_odds_factor_post
            # Add a small epsilon to avoid division by zero
            eps = 1e-9
            # Use a simple, conservative heuristic: call if to_call <= min(max_call_abs, call_factor * (pot + to_call))
            # Note: pot may not include the opponent's current bet depending on server; include to_call to be safer
            call_threshold = min(self.max_call_abs, int(call_factor * (pot + to_call + 1)))
            if to_call <= call_threshold and to_call <= remaining_chips:
                return PokerAction.CALL, 0

            # Consider raising only if the required to_call is small; compute a valid raise amount
            # Keep conservative: raise only when the to_call is very small relative to pot and within stack
            if to_call <= int(0.05 * (pot + 1)) and to_call < remaining_chips:
                raise_amt = self._compute_valid_raise_amount(round_state, my_bet)
                if raise_amt is not None and raise_amt <= max_raise_amt:
                    return PokerAction.RAISE, int(raise_amt)

            # If calling exceeds our stack, consider all-in in rare cases when pot is already big
            if to_call > remaining_chips:
                if pot >= 5 * to_call:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

            # Default action when bet is too large for our conservative thresholds
            return PokerAction.FOLD, 0

        except Exception:
            # Any error -> play it safe to avoid auto-fold penalties for invalid actions
            if self._can_check(round_state):
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Reset per-round attributes if needed
        self.position = "UNKNOWN"

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset game-level if necessary
        pass

    # ---------------------------
    # Helper methods
    # ---------------------------
    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        try:
            return int(round_state.player_bets.get(str(self.id), 0))
        except Exception:
            return 0

    def _can_check(self, round_state: RoundStateClient) -> bool:
        my_bet = self._get_my_bet(round_state)
        current_bet = max(0, int(round_state.current_bet))
        return current_bet <= my_bet

    def _compute_valid_raise_amount(self, round_state: RoundStateClient, my_bet: int) -> Optional[int]:
        """
        Compute a safe, valid RAISE amount according to server constraints.
        The server requires:
          - amount + current (our) bet must be strictly greater than the current raise (round_state.current_bet)
          - amount must be within [min_raise, max_raise]
        We interpret 'amount' as the additional chips to put in (increment over our current bet).
        """
        try:
            current_bet = max(0, int(round_state.current_bet))
            min_raise_amt = max(1, int(round_state.min_raise))
            max_raise_amt = max(0, int(round_state.max_raise))

            to_call = max(0, current_bet - my_bet)

            # To raise, we must first cover the call and then add at least min_raise_amt.
            # Additionally, ensure the strict condition: my_bet + amount > current_bet
            # So we target amount = to_call + min_raise_amt, and if that still isn't strictly greater (edge cases),
            # push by +1.
            base_amount = to_call + min_raise_amt
            if my_bet + base_amount <= current_bet:
                base_amount = (current_bet - my_bet) + min_raise_amt + 1

            # Bound by max_raise
            if base_amount > max_raise_amt:
                return None

            # Ensure strictly increasing the current bet level
            if my_bet + base_amount <= current_bet:
                return None

            # Final sanity checks
            if base_amount < min_raise_amt:
                base_amount = min_raise_amt
                if base_amount > max_raise_amt:
                    return None
                if my_bet + base_amount <= current_bet:
                    return None

            return int(base_amount)
        except Exception:
            return None