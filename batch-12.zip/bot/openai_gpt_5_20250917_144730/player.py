from typing import List, Tuple, Dict, Any
from itertools import combinations
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


def clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Persistent game info
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []

        # Hand/round state
        self.round_num = 0
        self.current_round_name = ""
        self.preflop_aggressor = False  # track if we raised preflop this hand
        self.last_action_by_round: Dict[str, str] = {}  # 'Preflop','Flop','Turn','River' -> action name

        # Safety constants
        self.EPS = 1e-9

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game-level info
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players is not None else []
        self.hole_cards = list(player_hands) if player_hands is not None else []
        self.preflop_aggressor = False
        self.last_action_by_round.clear()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand flags at start of a new hand (Preflop)
        self.round_num = getattr(round_state, 'round_num', self.round_num)
        self.current_round_name = getattr(round_state, 'round', "")
        if (self.current_round_name or "").lower() == 'preflop':
            self.preflop_aggressor = False
            self.last_action_by_round.clear()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Read base state
            hero_id_str = str(self.id)
            stage = (round_state.round or "").lower()
            community = list(round_state.community_cards or [])
            pot = int(round_state.pot or 0)
            current_bet = int(round_state.current_bet or 0)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)
            player_bets = dict(round_state.player_bets or {})
            our_bet = int(player_bets.get(hero_id_str, 0))

            # Determine allowed actions
            call_amount = max(0, current_bet - our_bet)
            can_check = current_bet <= our_bet
            can_call = current_bet > our_bet and remaining_chips > 0
            can_raise = (max_raise >= max(min_raise, 1)) and (remaining_chips > 0)
            can_all_in = remaining_chips > 0

            # Safety fallback: if we somehow can't act, just fold
            if not (can_check or can_call or can_raise or can_all_in):
                return (PokerAction.FOLD, 0)

            # Compute pot odds for calling decisions
            pot_odds = 0.0
            if call_amount > 0:
                pot_odds = call_amount / (pot + call_amount + self.EPS)

            # Compute hand strength estimations
            # Preflop: if we have hole cards, use heuristic. Postflop: use evaluator.
            preflop_strength = self._estimate_preflop_strength(self.hole_cards) if self.hole_cards else 0.5
            made_strength, category, draw_info = self._postflop_strength(self.hole_cards, community)

            # Combine equity estimate: prefer made hand strength, add draw equity when applicable
            draw_equity = draw_info.get('equity', 0.0)
            combined_equity = max(made_strength, made_strength + draw_equity * (1.0 - made_strength))

            # Decision Logic
            # 1) All-in thresholds for absolute monsters (postflop only)
            if stage in ('flop', 'turn', 'river'):
                if category >= 7 and can_all_in:
                    # Four of a kind or full house+ -> shove (value)
                    return (PokerAction.ALL_IN, 0)

            # 2) Preflop Strategy (Heads-up / generic)
            if stage == 'preflop':
                if can_check:
                    # No bet to call: choose to open-bet with strong hands
                    if preflop_strength >= 0.75 and can_raise:
                        amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                        self.preflop_aggressor = True
                        self._track_action('Preflop', 'Raise')
                        return (PokerAction.RAISE, amt)
                    elif preflop_strength >= 0.55 and can_raise:
                        amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                        self.preflop_aggressor = True
                        self._track_action('Preflop', 'Raise')
                        return (PokerAction.RAISE, amt)
                    else:
                        self._track_action('Preflop', 'Check')
                        return (PokerAction.CHECK, 0)
                else:
                    # Facing bet (typically blinds or opens)
                    if preflop_strength >= max(0.8, pot_odds + 0.25):
                        # 3-bet / value raise
                        if can_raise:
                            amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                            self.preflop_aggressor = True
                            self._track_action('Preflop', 'Raise')
                            return (PokerAction.RAISE, amt)
                        elif can_call:
                            self._track_action('Preflop', 'Call')
                            return (PokerAction.CALL, 0)
                    if preflop_strength >= max(0.48, pot_odds + 0.07):
                        if can_call:
                            self._track_action('Preflop', 'Call')
                            return (PokerAction.CALL, 0)
                        else:
                            # If can't call, check fallback
                            if can_check:
                                self._track_action('Preflop', 'Check')
                                return (PokerAction.CHECK, 0)
                    # Otherwise fold weak hands facing bet
                    return (PokerAction.FOLD, 0)

            # 3) Postflop Strategy
            # Facing no bet: value bet strong, occasional c-bet if preflop aggressor with some equity
            if can_check:
                if combined_equity >= 0.75 and can_raise:
                    amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                    self._track_action(self._normalize_round_name(round_state.round), 'Bet')
                    return (PokerAction.RAISE, amt)
                # Controlled aggression: c-bet on flop if we were aggressor and have some equity
                if stage == 'flop' and self.preflop_aggressor and combined_equity >= 0.42 and can_raise:
                    amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                    self._track_action('Flop', 'Bet')
                    return (PokerAction.RAISE, amt)
                # Otherwise check
                self._track_action(self._normalize_round_name(round_state.round), 'Check')
                return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                if combined_equity >= 0.88:
                    # Very strong made hand -> raise for value if possible, else call
                    if can_raise:
                        amt = self._choose_safe_raise_amount(min_raise, max_raise, target='small')
                        self._track_action(self._normalize_round_name(round_state.round), 'Raise')
                        return (PokerAction.RAISE, amt)
                    elif can_call:
                        self._track_action(self._normalize_round_name(round_state.round), 'Call')
                        return (PokerAction.CALL, 0)
                # Pot odds call with appropriate equity buffer
                equity_threshold = max(pot_odds + 0.12, 0.5 if stage == 'river' else 0.45)
                if combined_equity >= equity_threshold and can_call:
                    self._track_action(self._normalize_round_name(round_state.round), 'Call')
                    return (PokerAction.CALL, 0)

                # Draw-based call if the draw equity alone makes it
                if draw_equity >= pot_odds + 0.05 and can_call:
                    self._track_action(self._normalize_round_name(round_state.round), 'Call')
                    return (PokerAction.CALL, 0)

                # Otherwise fold
                return (PokerAction.FOLD, 0)

        except Exception:
            # Robust fallback: prefer safe action to avoid invalid move
            try:
                # Try to check, else call cheaply, else fold
                if round_state.current_bet <= (round_state.player_bets or {}).get(str(self.id), 0):
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CALL, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Nothing persistent to update beyond hand
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Could use data to improve later, but keep stateless for now
        pass

    # -------------------- Helper functions --------------------

    def _track_action(self, round_name: str, action: str):
        if round_name:
            self.last_action_by_round[round_name] = action

    def _normalize_round_name(self, rn: str) -> str:
        # Normalize round naming to consistent keys
        rn = (rn or "").strip()
        if not rn:
            return ""
        up = rn.lower()
        if up == 'preflop':
            return 'Preflop'
        if up == 'flop':
            return 'Flop'
        if up == 'turn':
            return 'Turn'
        if up == 'river':
            return 'River'
        return rn

    def _choose_safe_raise_amount(self, min_raise: int, max_raise: int, target: str = 'small') -> int:
        # Keep sizing simple and always valid
        if max_raise < max(min_raise, 1):
            return max(max_raise, 1)
        if target == 'small':
            # Choose the smallest valid raise to reduce risk of invalid action
            return clamp(min_raise, min_raise, max_raise)
        # Default
        return clamp(min_raise, min_raise, max_raise)

    # ---------- Preflop evaluation ----------

    def _estimate_preflop_strength(self, hole: List[str]) -> float:
        if len(hole) < 2:
            return 0.5
        r1, s1 = self._parse_card(hole[0])
        r2, s2 = self._parse_card(hole[1])
        ranks = sorted([r1, r2], reverse=True)
        high, low = ranks[0], ranks[1]
        suited = (s1 == s2)
        gap = abs(r1 - r2) - 1
        gap = max(0, gap)

        # Pocket pairs
        if r1 == r2:
            # Base 0.70 to 0.99 for pairs 22..AA
            pair_value = (r1 - 2) / 12.0  # 0..1
            score = 0.70 + 0.29 * pair_value
            return max(0.70, min(0.99, score))

        # Non-paired hands
        high_value = (high - 2) / 12.0
        low_value = (low - 2) / 12.0
        connected_bonus = 0.06 if abs(r1 - r2) == 1 else (0.03 if abs(r1 - r2) == 2 else 0.0)
        suited_bonus = 0.06 if suited else 0.0
        gap_penalty = -0.03 * max(0, gap - 1)

        # Ace-x suited bonus
        acex_bonus = 0.04 if (high == 14 and suited) else 0.0

        base = 0.18 + 0.56 * high_value + 0.18 * low_value
        score = base + connected_bonus + suited_bonus + gap_penalty + acex_bonus

        # Clamp
        score = max(0.15, min(0.95, score))
        return score

    # ---------- Postflop evaluation ----------

    def _postflop_strength(self, hole: List[str], board: List[str]) -> Tuple[float, int, Dict[str, Any]]:
        # Return (made_strength 0..1, category, draw_info)
        # category: 0..8 (High..StraightFlush)
        # draw_info: {'outs': int, 'equity': float}
        if len(board) == 0 or len(hole) < 2:
            # No board yet, fall back to preflop approximation
            strength = self._estimate_preflop_strength(hole)
            return (max(0.2, strength * 0.9), 0, {'outs': 0, 'equity': 0.0})

        all_cards = list(hole) + list(board)
        cat, tiebreak = self._best_hand_category(all_cards)

        # Base made strength by category
        made_strength = self._category_to_strength(cat, hole, board)

        # Draw equity estimation (flop/turn typically)
        outs, draw_equity = self._estimate_draw_equity(hole, board)

        return (made_strength, cat, {'outs': outs, 'equity': draw_equity})

    def _category_to_strength(self, category: int, hole: List[str], board: List[str]) -> float:
        # Base category strength
        base_map = {
            8: 0.99,  # Straight Flush
            7: 0.97,  # Four of a Kind
            6: 0.95,  # Full House
            5: 0.90,  # Flush
            4: 0.88,  # Straight
            3: 0.82,  # Three of a kind
            2: 0.78,  # Two pair
            1: 0.55,  # One pair (adjust below)
            0: 0.18,  # High card (adjust below)
        }
        strength = base_map.get(category, 0.5)

        # Adjust for one-pair and high-card specifics
        if category == 1:
            # Distinguish between overpair/top pair/weak pair
            hr1, _ = self._parse_card(hole[0])
            hr2, _ = self._parse_card(hole[1])
            branks = sorted([self._parse_card(c)[0] for c in board], reverse=True)
            highest_board = branks[0] if branks else 0
            # Pocket pair case
            if hr1 == hr2:
                # Overpair to board?
                if hr1 > highest_board:
                    strength = 0.78
                else:
                    strength = 0.62
            else:
                # Did we pair top board?
                if any(self._parse_card(c)[0] == highest_board for c in hole):
                    strength = 0.68
                else:
                    # Mid/weak pair
                    strength = 0.52

        if category == 0:
            # High card: improve with overcards and backdoor potential (very rough)
            hr1, _ = self._parse_card(hole[0])
            hr2, _ = self._parse_card(hole[1])
            branks = sorted([self._parse_card(c)[0] for c in board], reverse=True)
            highest_board = branks[0] if branks else 0
            overcards = (1 if hr1 > highest_board else 0) + (1 if hr2 > highest_board else 0)
            strength = 0.18 + 0.05 * overcards

        return max(0.05, min(0.99, strength))

    def _estimate_draw_equity(self, hole: List[str], board: List[str]) -> Tuple[int, float]:
        # Estimate outs and equity for typical draws (flush, OESD, gutshot)
        known_count = len(hole) + len(board)
        if known_count < 5:
            return (0, 0.0)  # preflop or not enough info

        stage_lower = {0: 'preflop', 3: 'flop', 4: 'turn', 5: 'river'}.get(len(board), 'postflop')

        # Suits count for flush draws
        suits = [self._parse_card(c)[1] for c in (hole + board)]
        best_suit_count = max(suits.count('c'), suits.count('d'), suits.count('h'), suits.count('s'))
        flush_draw = (best_suit_count == 4)  # exactly 4 to a flush among 5-6 cards seen

        # Straight draw detection (approx)
        ranks = set(self._parse_card(c)[0] for c in (hole + board))
        # Add wheel ace as 1
        if 14 in ranks:
            ranks = ranks.union({1})

        longest_run = self._longest_consecutive_run(sorted(list(ranks)))
        straight_already = longest_run >= 5
        oesd = (longest_run == 4 and not straight_already)
        gutshot = False
        if not straight_already and not oesd:
            # Rough gutshot: look for windows of size 5 with 4 present (non-consecutive)
            gutshot = self._has_four_in_five_window(ranks)

        outs = 0
        if flush_draw:
            outs += 9
        if oesd:
            outs += 8
        elif gutshot:
            outs += 4

        # Equity approximation
        equity = 0.0
        # On flop (3 board cards), two cards to come
        if len(board) == 3:
            # Using approximation: chance to hit by river
            equity = 1.0 - ((47 - outs) / 47.0) * ((46 - outs) / 46.0) if outs > 0 else 0.0
        elif len(board) == 4:
            # On turn: 1 card to come
            equity = outs / 46.0 if outs > 0 else 0.0
        else:
            equity = 0.0

        equity = max(0.0, min(0.95, equity))
        return (outs, equity)

    def _longest_consecutive_run(self, sorted_unique_ranks: List[int]) -> int:
        if not sorted_unique_ranks:
            return 0
        longest, current = 1, 1
        for i in range(1, len(sorted_unique_ranks)):
            if sorted_unique_ranks[i] == sorted_unique_ranks[i - 1] + 1:
                current += 1
                longest = max(longest, current)
            elif sorted_unique_ranks[i] != sorted_unique_ranks[i - 1]:
                current = 1
        return longest

    def _has_four_in_five_window(self, ranks_set: set) -> bool:
        # For any 5-card sequence window, if we have 4 of the 5 ranks present => gutshot-ish
        for low in range(1, 11):  # 1..10 -> windows [low..low+4]
            window = {low, low + 1, low + 2, low + 3, low + 4}
            if len(window.intersection(ranks_set)) == 4:
                return True
        return False

    # ---------- Hand evaluator (7 -> best 5) ----------

    def _best_hand_category(self, cards: List[str]) -> Tuple[int, List[int]]:
        # Evaluate best 5-card hand among up to 7 cards
        best = (-1, [])  # (category, tiebreak list)
        select = cards[:]
        for combo in combinations(select, 5):
            cat, tb = self._evaluate_5_cards(list(combo))
            if self._compare_rank((cat, tb), best) > 0:
                best = (cat, tb)
        # If no combinations (shouldn't happen), return bottom
        if best[0] == -1:
            return (0, [])
        return best

    def _evaluate_5_cards(self, cards5: List[str]) -> Tuple[int, List[int]]:
        ranks = [self._parse_card(c)[0] for c in cards5]
        suits = [self._parse_card(c)[1] for c in cards5]

        # Count ranks
        counts: Dict[int, int] = {}
        for r in ranks:
            counts[r] = counts.get(r, 0) + 1

        # Sort ranks by (count desc, rank desc)
        # For tiebreakers
        sorted_by_count = sorted(counts.items(), key=lambda x: (x[1], x[0]), reverse=True)

        is_flush = len(set(suits)) == 1
        straight_high = self._straight_high_rank(ranks)

        if is_flush and straight_high > 0:
            return (8, [straight_high])  # Straight Flush
        if sorted_by_count[0][1] == 4:
            # Four of a kind
            quad_rank = sorted_by_count[0][0]
            kicker = max([r for r in ranks if r != quad_rank])
            return (7, [quad_rank, kicker])
        if sorted_by_count[0][1] == 3 and sorted_by_count[1][1] == 2:
            # Full house
            trips = sorted_by_count[0][0]
            pair = sorted_by_count[1][0]
            return (6, [trips, pair])
        if is_flush:
            return (5, sorted(sorted(ranks), reverse=True))
        if straight_high > 0:
            return (4, [straight_high])
        if sorted_by_count[0][1] == 3:
            trips = sorted_by_count[0][0]
            kickers = sorted([r for r in ranks if r != trips], reverse=True)
            return (3, [trips] + kickers[:2])
        if sorted_by_count[0][1] == 2 and sorted_by_count[1][1] == 2:
            pairs = sorted([sorted_by_count[0][0], sorted_by_count[1][0]], reverse=True)
            kicker = max([r for r in ranks if r not in pairs])
            return (2, pairs + [kicker])
        if sorted_by_count[0][1] == 2:
            pair = sorted_by_count[0][0]
            kickers = sorted([r for r in ranks if r != pair], reverse=True)
            return (1, [pair] + kickers[:3])
        # High card
        return (0, sorted(sorted(ranks), reverse=True))

    def _compare_rank(self, a: Tuple[int, List[int]], b: Tuple[int, List[int]]) -> int:
        # Compare two hand ranks
        if a[0] != b[0]:
            return 1 if a[0] > b[0] else -1
        # same category, compare tie-breakers
        for x, y in zip(a[1], b[1]):
            if x != y:
                return 1 if x > y else -1
        # longer tiebreaks win by length if necessary
        if len(a[1]) != len(b[1]):
            return 1 if len(a[1]) > len(b[1]) else -1
        return 0

    def _straight_high_rank(self, ranks: List[int]) -> int:
        # Return high card of straight, considering A-2-3-4-5
        unique = sorted(set(ranks))
        # Wheel: A-2-3-4-5
        if 14 in unique:
            unique = [1] + [r for r in unique if r != 14]
        if len(unique) < 5:
            # Try original unique with Ace high if length < 5
            unique2 = sorted(set(ranks), reverse=False)
            return self._straight_high_from_sorted(unique2)
        return self._straight_high_from_sorted(unique)

    def _straight_high_from_sorted(self, sorted_unique: List[int]) -> int:
        if len(sorted_unique) < 5:
            return 0
        # Look for sequences of 5 consecutive
        for i in range(len(sorted_unique) - 4):
            window = sorted_unique[i:i + 5]
            if window[0] + 4 == window[-1] and len(set(window)) == 5:
                return window[-1] if window[-1] != 5 or window[0] != 1 else 5
        return 0

    def _parse_card(self, c: str) -> Tuple[int, str]:
        # c like 'Ah', 'Ks', '3d'
        if not c or len(c) < 2:
            return (0, 'x')
        rch = c[0].upper()
        sch = c[1].lower()
        ranks_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                     '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return (ranks_map.get(rch, 0), sch)