from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import defaultdict
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength_cache = {}
        self.player_stats = defaultdict(lambda: {'aggression': 0, 'hands_seen': 0})
        self.position = 0
        self.players = []
        self.blind_amount = 0
        self.my_cards = []
        self.community_cards = []
        self.total_hands_seen = 0
        
    def card_value(self, card):
        rank = card[:-1]
        values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                  '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return values[rank]
    
    def get_suit(self, card):
        return card[-1]
    
    def evaluate_hand_strength(self, hole_cards, community_cards):
        all_cards = hole_cards + community_cards
        
        # Count occurrences and suits
        ranks = defaultdict(int)
        suits = defaultdict(int)
        for card in all_cards:
            rank = card[:-1]
            suit = card[-1]
            ranks[rank] += 1
            suits[suit] += 1
        
        # Sort ranks by value then count
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        sorted_ranks = sorted([(rank_values[r], r, count) for r, count in ranks.items()], reverse=True)
        
        is_flush = max(suits.values()) >= 5
        
        has_straight = False
        unique_values = sorted(set([rv for rv, _, _ in sorted_ranks]), reverse=True)
        if len(unique_values) >= 5:
            for i in range(len(unique_values) - 4):
                if unique_values[i] - unique_values[i + 4] == 4:
                    has_straight = True
                    break
            # Check wheel straight
            if set([14, 2, 3, 4, 5]).issubset(set(unique_values)):
                has_straight = True
        
        # Count pairs, trips, quads
        rank_counts = defaultdict(int)
        for r in ranks:
            rank_counts[ranks[r]] += 1
        
        # Calculate hand strength
        if is_flush and has_straight:
            return 8000  # Straight flush
        elif 4 in rank_counts:
            return 7000 + sorted_ranks[0][0]  # Four of a kind
        elif 3 in rank_counts and 2 in rank_counts:
            return 6000 + sorted_ranks[0][0] * 15 + sorted_ranks[1][0]  # Full house
        elif is_flush:
            return 5000 + max([rank_values[r] for r, _ in ranks.items() if suits[suits.keys().pop()] >= 5])
        elif has_straight:
            return 4000 + max(unique_values[:5])
        elif 3 in rank_counts:
            return 3000 + sorted_ranks[0][0] * 15 * 15 + sorted_ranks[1][0] * 15 + sorted_ranks[2][0]
        elif rank_counts[2] >= 2:
            pairs = [r for r, c in ranks.items() if c == 2]
            pairs_values = [rank_values[p] for p in pairs]
            pairs_values.sort(reverse=True)
            return 2000 + pairs_values[0] * 100 + pairs_values[1] * 10 + sorted_ranks[0][0]
        elif 2 in rank_counts:
            pair_value = max([rank_values[r] for r, c in ranks.items() if c == 2])
            kicker = [rv for rv, _, _ in sorted_ranks if rv != pair_value][0]
            return 1000 + pair_value * 100 + kicker
        else:
            return max([rank_values[card[:-1]] for card in hole_cards])
    
    def get_aggression_factor(self, player_id):
        if player_id not in self.player_stats:
            return 0.5
        stats = self.player_stats[player_id]
        if stats['hands_seen'] == 0:
            return 0.5
        return min(stats['aggression'] / stats['hands_seen'], 2.0)
    
    def should_aggressive_raise(self, hole_cards, community_cards, pot_size, to_call, remaining_chips):
        # Premium pairs
        if hole_cards[0][0] == hole_cards[1][0]:
            rank = self.card_value(hole_cards[0])
            if rank >= 11:  # JJ+
                return True
            
        # Suited connectors
        suit1 = hole_cards[0][-1]
        suit2 = hole_cards[1][-1]
        if suit1 == suit2:
            val1 = self.card_value(hole_cards[0])
            val2 = self.card_value(hole_cards[1])
            diff = abs(val1 - val2)
            if diff <= 2 and max(val1, val2) >= 10:
                return True
        
        # Strong hands on any street
        if community_cards:
            strength = self.evaluate_hand_strength(hole_cards, community_cards)
            if strength > 5000:  # Strong made hand
                return True
        
        return False
    
    def should_value_bet(self, hole_cards, community_cards, pot_size, to_call, remaining_chips):
        if not community_cards:
            return False
        
        strength = self.evaluate_hand_strength(hole_cards, community_cards)
        
        # Strong hand, bet for value
        if strength >= 5000:
            return True
        
        # Good hand on coordinated board
        if strength >= 4000 and pot_size > 1000:
            return True
            
        return False
    
    def should_bluff(self, hole_cards, community_cards, to_call, aggression_factor):
        # Only bluff if we have fold equity
        if aggression_factor > 1.5:
            return False
        
        # Good bluff hands: suited connectors, ace-high hands
        suit1 = hole_cards[0][-1]
        suit2 = hole_cards[1][-1]
        val1 = self.card_value(hole_cards[0])
        val2 = self.card_value(hole_cards[1])
        
        # Suited ace, suited connectors
        if suit1 == suit2:
            if (hole_cards[0][0] == 'A') or (abs(val1 - val2) <= 2):
                return True
        
        # Any ace-high for bluffing
        if hole_cards[0][0] == 'A' or hole_cards[1][0] == 'A':
            return True
        
        return False
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_cards = player_hands
        self.blind_amount = blind_amount
        self.players = all_players
        self.total_hands_seen = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.community_cards = round_state.community_cards
        self.total_hands_seen += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = round_state.current_bet - (round_state.player_bets.get(str(self.id), 0))
        pot_size = round_state.pot
        
        # Update player stats
        if round_state.player_actions:
            for pid, action in round_state.player_actions.items():
                if pid != str(self.id):
                    self.player_stats[pid]['hands_seen'] += 1
                    if action in ['RAISE', 'ALL_IN', 'BET']:
                        self.player_stats[pid]['aggression'] += 1
        
        # Basic preflop strategy
        if round_state.round == 'Preflop':
            hole_cards = self.my_cards
            if not hole_cards:
                return PokerAction.FOLD, 0
            
            # Check card strength
            val1 = self.card_value(hole_cards[0])
            val2 = self.card_value(hole_cards[1])
            min_val = min(val1, val2)
            max_val = max(val1, val2)
            
            # Premium hands
            if val1 == val2 and max_val >= 11:
                # JJ+ pairs
                raise_amount = min(3 * to_call, remaining_chips)
                return PokerAction.RAISE, max(raise_amount, round_state.min_raise)
            
            # Suited cards
            if hole_cards[0][-1] == hole_cards[1][-1]:
                if (max_val >= 12 and min_val >= 9) or (abs(val1 - val2) <= 2 and max_val >= 10):
                    # AKs, KQs, QJs, etc.
                    if to_call <= 3 * self.blind_amount:
                        return PokerAction.CALL, 0
                    elif to_call == 0:
                        return PokerAction.RAISE, max(2 * self.blind_amount, round_state.min_raise)
            
            # High card hands
            if max_val >= 14:  # Ace
                if to_call <= 2 * self.blind_amount:
                    return PokerAction.CALL, 0
            elif max_val >= 12 and min_val >= 9:
                # AT+, KJ+
                if to_call <= self.blind_amount:
                    return PokerAction.CALL, 0
            
            # Fold if facing significant action
            if to_call >= 5 * self.blind_amount:
                return PokerAction.FOLD, 0
            
            # Check if possible
            if to_call == 0:
                return PokerAction.CHECK, 0
            
            return PokerAction.FOLD, 0
        
        # Post-flop play
        else:
            if not self.my_cards:
                return PokerAction.FOLD, 0
            
            hand_strength = self.evaluate_hand_strength(self.my_cards, round_state.community_cards)
            
            # Very strong hand
            if hand_strength >= 6000:
                raise_amount = min(round_state.pot * 0.75, remaining_chips)
                return PokerAction.RAISE, max(raise_amount, round_state.min_raise)
            
            # Strong hand
            if hand_strength >= 5000:
                if to_call <= round_state.pot * 0.3:
                    return PokerAction.CALL, 0
                elif to_call == 0:
                    return PokerAction.RAISE, max(round_state.pot * 0.5, round_state.min_raise)
                return PokerAction.RAISE, max(round_state.pot * 0.5, round_state.min_raise)
            
            # Medium strength
            if hand_strength >= 2000:
                if to_call <= round_state.pot * 0.2:
                    return PokerAction.CALL, 0
                elif to_call == 0:
                    return PokerAction.CHECK, 0
            
            # Weak hand
            if to_call == 0:
                return PokerAction.CHECK, 0
            elif to_call <= self.blind_amount:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track results for analysis
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Update final statistics
        pass