from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import math
import collections

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blinds = []
        self.opponents = []
        self.hand_history = []
        self.position = None
        self.stack_sizes = {}
        self.aggression_factor = collections.defaultdict(float)
        self.pre_flop_raises = collections.defaultdict(int)
        self.fold_stats = collections.defaultdict(int)
        self.showdown_stats = collections.defaultdict(int)
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int], **kwargs):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        
        self.opponents = [p for p in all_players if p != self.id]
        self.stack_sizes = {p: starting_chips for p in all_players}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_state = round_state
        self.my_chips = remaining_chips
        
        for player_id, bet in round_state.player_bets.items():
            self.stack_sizes[player_id] = max(0, self.stack_sizes.get(player_id, 0) - bet + 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluator"""
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.0
        
        def card_rank(card):
            rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
                       'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            return rank_map[card[0]]
        
        ranks = [card_rank(c) for c in all_cards]
        suits = [c[1] for c in all_cards]
        
        rank_counts = collections.Counter(ranks)
        suit_counts = collections.Counter(suits)
        
        is_flush = max(suit_counts.values()) >= 5
        is_straight = False
        
        unique_ranks = sorted(set(ranks))
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                is_straight = True
                break
        
        if len(unique_ranks) == 5:
            counts = list(rank_counts.values())
            if 4 in counts:
                return 7.0
            elif 3 in counts and 2 in counts:
                return 6.5
            elif is_straight and is_flush:
                return 9.0
            elif is_flush:
                return 6.0
            elif is_straight:
                return 5.0
            elif 3 in counts:
                return 4.0
            elif counts.count(2) == 2:
                return 3.0
            elif 2 in counts:
                return 2.0
        
        return 1.0
        
    def _calculate_pot_odds(self, round_state: RoundStateClient) -> float:
        """Calculate pot odds for calling"""
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        if to_call <= 0:
            return float('inf')
        
        return round_state.pot / (to_call + 1e-6)
    
    def _get_position_factor(self) -> float:
        """Adjust for position in 6-max game"""
        if len(self.opponents) < 5:
            return 1.2
        elif len(self.opponents) < 3:
            return 1.5
        else:
            return 1.0
    
    def _magnitude_calculator(self, round_state: RoundStateClient, hand_strength: float) -> int:
        """Calculate raise size based on hand strength and situation"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Strong hands
        if hand_strength > 7.5:
            return min(max(min_raise, int(0.8 * pot)), max_raise)
        elif hand_strength > 6.0:
            return min(max(min_raise, int(0.6 * pot)), max_raise)
        elif hand_strength > 4.0:
            return min(max(min_raise, int(0.4 * pot)), max_raise)
        elif hand_strength > 2.5:
            return min(max(min_raise, int(0.2 * pot)), max_raise)
        
        return min_raise
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        hole_cards = self.player_hands
        community_cards = round_state.community_cards
        
        # Calculate hand strength
        if len(community_cards) == 0:
            # Pre-flop play
            high_card = max([int(c[0].replace('T', '10').replace('J', '11').replace('Q', '12').replace('K', '13').replace('A', '14')) 
                           for c in hole_cards])
            hand_strength = 1.5 if high_card > 10 else 1.0
            
            # Adjust for pairs
            if hole_cards[0][0] == hole_cards[1][0]:
                hand_strength = 5.0
            elif hole_cards[0][1] == hole_cards[1][1]:
                hand_strength += 0.5
                
            # Suited connectors
            rank_diff = abs(['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(hole_cards[0][0]) - 
                           ['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(hole_cards[1][0]))
            if hole_cards[0][1] == hole_cards[1][1] and rank_diff <= 2:
                hand_strength += 1.0
        else:
            hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        
        # Position and pot odds factors
        position_factor = self._get_position_factor()
        pot_odds = self._calculate_pot_odds(round_state)
        
        # Decision matrix
        effective_strength = hand_strength * position_factor
        
        # Fold if too weak and facing big bet
        if effective_strength < 1.5 and to_call > round_state.pot * 0.3:
            return (PokerAction.FOLD, 0)
        
        # All-in with premium hands
        if effective_strength > 7.0 and len(community_cards) >= 3:
            return (PokerAction.ALL_IN, 0)
        
        # Raise with strong hands
        if effective_strength > 4.0:
            raise_size = self._magnitude_calculator(round_state, effective_strength)
            return (PokerAction.RAISE, raise_size)
        
        # Call with decent odds
        if hand_strength * pot_odds > 1.5 and to_call <= remaining_chips * 0.2:
            return (PokerAction.CALL, to_call)
        
        # Check or fold if nothing else
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        
        # Default fold
        return (PokerAction.FOLD, 0)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass