from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_cards = []
        self.opponent_history = {}
        self.current_round = 0
        self.aggro_factor = 1.0
        self.hand_history = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called when the game starts """
        self.starting_chips = starting_chips
        self.my_cards = player_hands if len(player_hands) >= 2 else []
        self.opponent_history = {player_id: [] for player_id in all_players if player_id != self.id}
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each round """
        self.current_round = round_state.round_num
        
    def card_to_value(self, card: str) -> int:
        """ Convert card string to numerical value """
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = card[0]
        return rank_map.get(rank, int(rank))
    
    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """ Evaluate hand strength from 0.0 to 1.0 """
        if not hole_cards and not community_cards:
            return 0.0
            
        all_cards = hole_cards + community_cards
        
        # Count suits and ranks
        suits = [c[1] for c in all_cards]
        ranks = [c[0] for c in all_cards]
        
        # Convert ranks to values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 
                      'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Count rank frequencies
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        # Check flush
        flush_suit = None
        for suit in suits:
            if suits.count(suit) >= 5:
                flush_suit = suit
                break
        
        # Check straight
        unique_ranks = sorted(list(set([rank_values[r] for r in ranks])), reverse=True)
        straight = False
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if (unique_ranks[i] - unique_ranks[i+4] == 4):
                    straight = True
                    break
            
        # Check straight flush and royal flush
        if flush_suit and straight:
            return 1.0
        
        # Check four of a kind
        quads = [r for r, count in rank_counts.items() if count == 4]
        if quads:
            return 0.9
        
        # Check full house
        trips = [r for r, count in rank_counts.items() if count == 3]
        pairs = [r for r, count in rank_counts.items() if count == 2]
        
        if trips and pairs:
            return 0.85
        elif len(trips) >= 2:
            return 0.75
        
        # Check flush
        if flush_suit:
            return 0.65
        
        # Check straight
        if straight:
            return 0.60
        
        # Three of a kind
        if trips:
            return 0.55
        
        # Two pair
        if len(pairs) >= 2:
            return 0.45
    
        # One pair
        if pairs:
            return 0.30
        
        # High card
        return 0.15
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player """
        
        if not round_state or not hasattr(round_state, 'community_cards'):
            return PokerAction.FOLD, 0
            
        # Update my cards from round state if available
        if hasattr(self, 'my_cards'):
            hole_cards = self.my_cards
        else:
            hole_cards = []
            
        community_cards = round_state.community_cards or []
        
        # Evaluate hand strength
        hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)
        
        # Calculate pot odds
        pot = round_state.pot or 0
        to_call = round_state.current_bet or 0
        pot = max(pot, 0)
        to_call = max(to_call, 0)
        your_bet = round_state.player_bets.get(str(self.id), 0) or 0
        
        pot_odds = to_call / (pot + to_call + 1e-6) if (pot + to_call) > 0 else 0
        
        # Calculate effective raise
        effective_to_call = to_call - your_bet
        effective_to_call = max(effective_to_call, 0)
        
        # Position-based decision
        total_players = len(round_state.current_player) if hasattr(round_state, 'current_player') else 2
        position_factor = 1.0
        
        if round_state.round == 'Preflop':
            # Preflop strategy
            if hole_cards and len(hole_cards) >= 2:
                # Premium pairs
                if hole_cards[0][0] == hole_cards[1][0]:
                    value = self.card_to_value(hole_cards[0][0])
                    if value >= 10:
                        raise_amount = min(3 * to_call + round_state.min_raise, round_state.max_raise)
                        if remaining_chips > raise_amount > round_state.min_raise + 1:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.ALL_IN, 0
                    elif value >= 7:
                        raise_amount = min(2.5 * to_call + round_state.min_raise, round_state.max_raise)
                        if remaining_chips > raise_amount > round_state.min_raise + 1:
                            return PokerAction.RAISE, raise_amount
                        return PokerAction.CALL, 0
                
                # Suited connectors
                if hole_cards[0][1] == hole_cards[1][1]:
                    val1 = self.card_to_value(hole_cards[0][0])
                    val2 = self.card_to_value(hole_cards[1][0])
                    if abs(val1 - val2) <= 3 and val1 >= 8 and val2 >= 8:
                        if effective_to_call <= remaining_chips * 0.05:
                            return PokerAction.CALL, 0
                        return PokerAction.RAISE, min(round_state.min_raise * 2.2, round_state.max_raise)
                
                # Premium broadway
                high_cards = {'A', 'K', 'Q', 'J'}
                if hole_cards[0][0] in high_cards and hole_cards[1][0] in high_cards:
                    raise_amount = min(2.8 * to_call + round_state.min_raise, round_state.max_raise)
                    if remaining_chips > raise_amount > round_state.min_raise + 1:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.CALL, 0
        
        # Postflop strategy
        bet_threshold = 0.3
        if round_state.round == 'Flop':
            bet_threshold = 0.4
        elif round_state.round == 'Turn':
            bet_threshold = 0.5
        elif round_state.round == 'River':
            bet_threshold = 0.6
        
        # Adjust based on hand strength
        if hand_strength >= bet_threshold:
            # Strong hand
            raise_amount = min(pot * 0.75 + round_state.min_raise, round_state.max_raise)
            if remaining_chips > raise_amount > round_state.min_raise + 1:
                return PokerAction.RAISE, max(raise_amount, round_state.min_raise * 1.5)
            elif remaining_chips <= round_state.min_raise:
                return PokerAction.CALL, 0
            else:
                return PokerAction.ALL_IN, 0
        
        elif hand_strength >= 0.25:
            # Marginal hand
            if effective_to_call <= pot * 0.1:
                return PokerAction.CALL, 0
            elif effective_to_call == 0:
                return PokerAction.CHECK, 0
            
        # Weak hand - fold or aggressive bluff
        if effective_to_call > 0:
            if effective_to_call <= round_state.min_raise and hand_strength >= 0.2:
                return PokerAction.CALL, 0
            elif effective_to_call > remaining_chips * 0.1:
                return PokerAction.FOLD, 0
            else:
                # Bluff occasionally
                bluff_chance = 0.15
                if round_state.round == 'Flop' and pot > round_state.current_bet * 3:
                    bluff_amount = min(pot * 0.6 + round_state.min_raise, round_state.max_raise)
                    if remaining_chips > bluff_amount > round_state.min_raise + 1:
                        return PokerAction.RAISE, bluff_amount
        
        # Default actions
        if effective_to_call == 0:
            return PokerAction.CHECK, 0
        elif effective_to_call > 0:
            if effective_to_call <= remaining_chips:
                if hand_strength >= 0.2:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0
        
        return PokerAction.FOLD, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round """
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game """
        pass