from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 0
        self.ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = 2 * blind_amount  # Assuming blind_amount is small blind

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0
        my_stack = remaining_chips

        if to_call > my_stack:
            return (PokerAction.FOLD, 0)

        phase = round_state.round

        if phase == 'Preflop':
            if len(self.hole_cards) != 2:
                return (PokerAction.FOLD, 0)
            card1, card2 = self.hole_cards
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            r1 = self.ranks[rank1]
            r2 = self.ranks[rank2]
            suited = suit1 == suit2
            pair = r1 == r2
            high = max(r1, r2)
            low = min(r1, r2)

            if pair and high >= 10:
                amount = max(round_state.min_raise, 3 * self.big_blind)
                if amount > my_stack:
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.RAISE, amount)
            elif (high == 14 and low >= 10) or (high == 13 and low == 12) or (suited and high >= 12 and low >= 10):
                if to_call == 0:
                    amount = max(round_state.min_raise, 3 * self.big_blind)
                    if amount > my_stack:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.RAISE, amount)
                elif to_call <= 4 * self.big_blind:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                if can_check:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            hand_type, _ = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            pot = round_state.pot
            min_r = round_state.min_raise
            max_r = round_state.max_raise
            bet_size = int(pot / 2 + 1e-6)

            if hand_type >= 5:  # strong hand
                if max_r >= min_r:
                    amount = max(min_r, bet_size)
                    amount = min(amount, max_r)
                    return (PokerAction.RAISE, amount)
                else:
                    if can_check:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CALL, 0)
            elif hand_type >= 2:  # medium hand
                if to_call == 0:
                    amount = max(min_r, self.big_blind * 2)
                    if amount <= max_r:
                        return (PokerAction.RAISE, amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if to_call < (pot / 3 + 1e-6):
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:  # weak hand
                if can_check:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

    def evaluate_hand(self, hole: List[str], community: List[str]) -> Tuple[int, List[int]]:
        cards = hole + community
        if len(cards) < 5:
            return 0, []
        best_score = (0, [])
        for combo in itertools.combinations(cards, 5):
            score = self.score_hand(list(combo))
            if score > best_score:
                best_score = score
        return best_score

    def score_hand(self, five_cards: List[str]) -> Tuple[int, List[int]]:
        rank_list = []
        suit_list = []
        rank_count = {}
        suit_count = {}
        for card in five_cards:
            r, s = card[0], card[1]
            rn = self.ranks[r]
            rank_list.append(rn)
            suit_list.append(s)
            rank_count[rn] = rank_count.get(rn, 0) + 1
            suit_count[s] = suit_count.get(s, 0) + 1
        rank_list.sort(reverse=True)
        is_flush = any(count >= 5 for count in suit_count.values())
        unique_ranks = sorted(set(rank_list), reverse=True)
        is_straight = False
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i + 4] == 4:
                    is_straight = True
                    straight_high = unique_ranks[i]
                    break
        if set(unique_ranks) == {14, 5, 4, 3, 2}:
            is_straight = True
            straight_high = 5
        counts = list(rank_count.values())
        if max(rank_count.values()) == 4:
            quad_rank = next(k for k, v in rank_count.items() if v == 4)
            kicker = next(k for k, v in rank_count.items() if v == 1)
            return 7, [quad_rank, kicker]
        elif 3 in counts and 2 in counts:
            three_rank = next(k for k, v in rank_count.items() if v == 3)
            pair_rank = next(k for k, v in rank_count.items() if v == 2)
            return 6, [three_rank, pair_rank]
        elif max(rank_count.values()) == 3:
            three_rank = next(k for k, v in rank_count.items() if v == 3)
            kickers = sorted([k for k, v in rank_count.items() if v == 1], reverse=True)
            return 3, [three_rank] + kickers
        elif counts.count(2) >= 2:
            pairs = sorted([k for k, v in rank_count.items() if v == 2], reverse=True)
            kicker = next(k for k, v in rank_count.items() if v == 1)
            return 2, pairs + [kicker]
        elif max(rank_count.values()) == 2:
            pair_rank = next(k for k, v in rank_count.items() if v == 2)
            kickers = sorted([k for k, v in rank_count.items() if v == 1], reverse=True)
            return 1, [pair_rank] + kickers
        elif is_straight and is_flush:
            if straight_high == 14 and sorted(unique_ranks) == [14, 13, 12, 11, 10]:
                return 9, [14]
            return 8, [straight_high]
        elif is_flush:
            return 5, rank_list
        elif is_straight:
            return 4, [straight_high]
        else:
            return 0, rank_list

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass