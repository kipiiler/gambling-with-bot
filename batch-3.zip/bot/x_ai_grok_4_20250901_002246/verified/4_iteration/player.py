from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = None
        self.small_blind = 0
        self.big_blind = 0
        self.num_players = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.small_blind = blind_amount
        self.big_blind = 2 * blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def card_rank(self, card: str) -> int:
        r = card[0]
        if r == 'A': return 14
        if r == 'K': return 13
        if r == 'Q': return 12
        if r == 'J': return 11
        if r == 'T': return 10
        return int(r)

    def card_suit(self, card: str) -> str:
        return card[1]

    def get_preflop_strength(self, hole: List[str]) -> float:
        r1, r2 = sorted([self.card_rank(hole[0]), self.card_rank(hole[1])], reverse=True)
        s1, s2 = self.card_suit(hole[0]), self.card_suit(hole[1])
        suited = s1 == s2
        if r1 == r2:
            return 0.8 + (r1 / 14.0) * 0.2
        else:
            gap = r1 - r2
            high = r1 / 14.0
            if suited:
                return 0.4 + high * 0.3 - gap * 0.05
            else:
                return 0.2 + high * 0.2 - gap * 0.05

    def evaluate_hand(self, hole: List[str], community: List[str]) -> int:
        cards = hole + community
        ranks = [self.card_rank(c) for c in cards]
        suits = [self.card_suit(c) for c in cards]
        ranks.sort(reverse=True)
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        flush_suit = next((s for s, count in suit_count.items() if count >= 5), None)
        is_flush = flush_suit is not None

        unique_ranks = sorted(set(ranks), reverse=True)
        is_straight = False
        straight_high = 0
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i + 4] == 4:
                is_straight = True
                straight_high = unique_ranks[i]
                break
        if 14 in unique_ranks and all(x in unique_ranks for x in [2, 3, 4, 5]):
            is_straight = True
            straight_high = 5

        is_straight_flush = False
        straight_flush_high = 0
        if is_flush:
            flush_ranks = [ranks[j] for j in range(len(cards)) if suits[j] == flush_suit]
            flush_ranks.sort(reverse=True)
            unique_flush = sorted(set(flush_ranks), reverse=True)
            for i in range(len(unique_flush) - 4):
                if unique_flush[i] - unique_flush[i + 4] == 4:
                    is_straight_flush = True
                    straight_flush_high = unique_flush[i]
                    break
            if 14 in unique_flush and all(x in unique_flush for x in [2, 3, 4, 5]):
                is_straight_flush = True
                straight_flush_high = 5

        rank_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1

        quads = any(count == 4 for count in rank_count.values())
        trips = any(count == 3 for count in rank_count.values())
        pairs = sum(1 for count in rank_count.values() if count == 2)
        full_house = trips and pairs >= 1

        if is_straight_flush:
            return 9 if straight_flush_high < 14 else 10
        if quads:
            return 8
        if full_house:
            return 7
        if is_flush:
            return 6
        if is_straight:
            return 5
        if trips:
            return 4
        if pairs == 2:
            return 3
        if pairs == 1:
            return 2
        return 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        to_call = round_state.current_bet - my_bet
        can_check = to_call == 0
        pot = round_state.pot
        num_active = len(round_state.current_player)
        is_heads_up = num_active == 2
        phase = round_state.round

        raise_factor = 3 if is_heads_up else 4
        aggression = 0.4 if is_heads_up else 0.6

        if remaining_chips <= 0:
            return PokerAction.CHECK, 0 if can_check else PokerAction.FOLD, 0

        if phase == 'Preflop':
            strength = self.get_preflop_strength(self.hole_cards)
            if can_check:
                if strength > aggression:
                    raise_amount = self.big_blind * raise_factor
                    raise_amount = max(round_state.min_raise, min(raise_amount, round_state.max_raise))
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CHECK, 0
            else:
                pot_odds = to_call / (pot + to_call + 1e-6)
                if strength > pot_odds + (0.2 if is_heads_up else 0.1):
                    if strength > 0.8 and to_call < remaining_chips:
                        raise_amount = to_call + self.big_blind * raise_factor
                        raise_amount = max(round_state.min_raise, min(raise_amount, round_state.max_raise))
                        return PokerAction.RAISE, raise_amount
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0 if strength > 0.5 else PokerAction.FOLD, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
        else:
            hand_type = self.evaluate_hand(self.hole_cards, round_state.community_cards)
            strength = hand_type / 10.0
            if len(round_state.community_cards) > 3:
                strength += 0.1  # Adjust for later streets

            if can_check:
                if strength > 0.3:
                    bet_amount = int(pot * 0.6)
                    if bet_amount < self.big_blind:
                        bet_amount = self.big_blind
                    bet_amount = max(round_state.min_raise, min(bet_amount, round_state.max_raise))
                    return PokerAction.RAISE, bet_amount
                else:
                    return PokerAction.CHECK, 0
            else:
                pot_odds = to_call / (pot + to_call + 1e-6)
                if strength > pot_odds:
                    if strength > 0.7 and to_call < remaining_chips:
                        raise_amount = to_call + int(pot * 0.6)
                        raise_amount = max(round_state.min_raise, min(raise_amount, round_state.max_raise))
                        return PokerAction.RAISE, raise_amount
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0 if strength > 0.4 else PokerAction.FOLD, 0
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass