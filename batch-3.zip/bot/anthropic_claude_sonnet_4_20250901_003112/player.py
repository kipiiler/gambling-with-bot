from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hands = []
        self.blind_amount = 0
        self.all_players = []
        self.games_played = 0
        self.opponent_aggression = 0.5  # Track opponent aggression
        self.opponent_actions = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.games_played += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get hand strength
            hand_strength = self._evaluate_hand_strength(self.player_hands, round_state.community_cards)
            
            # Calculate pot odds and betting dynamics
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            pot_odds = call_amount / (round_state.pot + call_amount + 1)  # Add 1 to avoid division by zero
            
            # Determine position and opponent behavior
            is_heads_up = len(self.all_players) == 2
            
            # Update opponent aggression tracking
            self._update_opponent_tracking(round_state)
            
            # Basic strategy based on hand strength and position
            if hand_strength >= 0.8:  # Very strong hand
                if round_state.current_bet == 0:
                    # Bet for value
                    bet_amount = min(round_state.pot // 2 + self.blind_amount, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Raise with strong hands
                    raise_amount = min(round_state.current_bet + round_state.min_raise, remaining_chips)
                    if raise_amount <= remaining_chips and raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
            
            elif hand_strength >= 0.6:  # Good hand
                if round_state.current_bet == 0:
                    # Bet moderately
                    bet_amount = min(self.blind_amount * 2, remaining_chips)
                    if bet_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Call reasonable bets
                    if pot_odds < 0.3:  # Good pot odds
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            elif hand_strength >= 0.4:  # Marginal hand
                if round_state.current_bet == 0:
                    # Check or small bet depending on position
                    if round_state.round == "Preflop" and is_heads_up:
                        # In heads-up, be more aggressive preflop
                        bet_amount = min(self.blind_amount, remaining_chips)
                        if bet_amount >= round_state.min_raise:
                            return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    # Call small bets only
                    if pot_odds < 0.2:  # Very good pot odds
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            else:  # Weak hand
                if round_state.current_bet == 0:
                    # Bluff occasionally
                    if round_state.round != "Preflop" and len(round_state.community_cards) >= 3:
                        # Bluff on flop/turn/river sometimes
                        if self._should_bluff(round_state, remaining_chips):
                            bet_amount = min(round_state.pot // 3 + self.blind_amount, remaining_chips)
                            if bet_amount >= round_state.min_raise:
                                return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    # Fold weak hands to bets
                    return (PokerAction.FOLD, 0)
            
        except Exception:
            # Fallback to safe action
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        try:
            if not hole_cards or len(hole_cards) != 2:
                return 0.3
            
            # Parse cards
            def parse_card(card_str):
                if len(card_str) != 2:
                    return (2, 'h')
                rank_char = card_str[0]
                suit_char = card_str[1]
                
                rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                             '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
                rank = rank_values.get(rank_char, 2)
                return (rank, suit_char.lower())
            
            hole1 = parse_card(hole_cards[0])
            hole2 = parse_card(hole_cards[1])
            
            # Preflop evaluation
            if not community_cards:
                return self._evaluate_preflop_strength(hole1, hole2)
            
            # Post-flop evaluation
            all_cards = [hole1, hole2]
            for card in community_cards:
                all_cards.append(parse_card(card))
            
            return self._evaluate_postflop_strength(all_cards, hole1, hole2)
            
        except Exception:
            return 0.3

    def _evaluate_preflop_strength(self, hole1, hole2) -> float:
        """Evaluate preflop hand strength"""
        rank1, suit1 = hole1
        rank2, suit2 = hole2
        
        # Pocket pairs
        if rank1 == rank2:
            if rank1 >= 13:  # AA, KK
                return 0.95
            elif rank1 >= 11:  # QQ, JJ  
                return 0.85
            elif rank1 >= 9:  # TT, 99
                return 0.75
            elif rank1 >= 7:  # 88, 77
                return 0.65
            else:  # 66 and below
                return 0.55
        
        # Suited cards
        is_suited = suit1 == suit2
        high_rank = max(rank1, rank2)
        low_rank = min(rank1, rank2)
        gap = high_rank - low_rank
        
        # High cards
        if high_rank == 14:  # Ace
            if low_rank >= 12:  # AK, AQ
                return 0.85 if is_suited else 0.75
            elif low_rank >= 10:  # AJ, AT
                return 0.70 if is_suited else 0.60
            elif low_rank >= 8:  # A9, A8
                return 0.55 if is_suited else 0.45
            else:
                return 0.45 if is_suited else 0.35
        
        elif high_rank >= 12:  # King high
            if low_rank >= 11:  # KQ
                return 0.70 if is_suited else 0.60
            elif low_rank >= 10:  # KJ, KT
                return 0.60 if is_suited else 0.50
            else:
                return 0.40 if is_suited else 0.30
        
        # Connected cards
        if gap <= 1 and high_rank >= 9:  # 9T, JT, etc.
            return 0.55 if is_suited else 0.45
        elif gap <= 2 and high_rank >= 10 and is_suited:
            return 0.50
        
        # Default for other hands
        if is_suited and high_rank >= 8:
            return 0.45
        elif high_rank >= 11:
            return 0.40
        else:
            return 0.25

    def _evaluate_postflop_strength(self, all_cards, hole1, hole2) -> float:
        """Evaluate post-flop hand strength"""
        try:
            # Count ranks and suits
            ranks = {}
            suits = {}
            
            for rank, suit in all_cards:
                ranks[rank] = ranks.get(rank, 0) + 1
                suits[suit] = suits.get(suit, 0) + 1
            
            # Check for hands
            rank_counts = sorted(ranks.values(), reverse=True)
            max_suit = max(suits.values())
            sorted_ranks = sorted(ranks.keys(), reverse=True)
            
            # Four of a kind
            if 4 in rank_counts:
                return 0.98
            
            # Full house
            if rank_counts == [3, 2] or rank_counts[:2] == [3, 3]:
                return 0.95
            
            # Flush
            if max_suit >= 5:
                # Check if we have the flush
                flush_suit = None
                for suit, count in suits.items():
                    if count >= 5:
                        flush_suit = suit
                        break
                
                our_suited = 0
                if hole1[1] == flush_suit:
                    our_suited += 1
                if hole2[1] == flush_suit:
                    our_suited += 1
                
                if our_suited >= 1:
                    return 0.90
                else:
                    return 0.20  # Board flush, we don't have it
            
            # Straight
            straight_strength = self._check_straight(sorted_ranks)
            if straight_strength > 0:
                return 0.85
            
            # Three of a kind
            if 3 in rank_counts:
                # Check if we have the trips
                our_ranks = [hole1[0], hole2[0]]
                for rank, count in ranks.items():
                    if count == 3 and rank in our_ranks:
                        return 0.80
                return 0.65  # Set on board
            
            # Two pair
            if rank_counts.count(2) >= 2:
                our_pairs = 0
                our_ranks = [hole1[0], hole2[0]]
                for rank, count in ranks.items():
                    if count == 2 and rank in our_ranks:
                        our_pairs += 1
                
                if our_pairs == 2:
                    return 0.75
                elif our_pairs == 1:
                    return 0.60
                else:
                    return 0.40
            
            # One pair
            if 2 in rank_counts:
                our_ranks = [hole1[0], hole2[0]]
                for rank, count in ranks.items():
                    if count == 2:
                        if rank in our_ranks:
                            if rank >= 11:  # High pair
                                return 0.65
                            else:
                                return 0.55
                        else:
                            return 0.35  # Pair on board
            
            # High card
            our_high = max(hole1[0], hole2[0])
            if our_high >= 13:
                return 0.45
            elif our_high >= 11:
                return 0.35
            else:
                return 0.25
                
        except Exception:
            return 0.30

    def _check_straight(self, sorted_ranks) -> float:
        """Check for straight possibilities"""
        try:
            unique_ranks = list(set(sorted_ranks))
            unique_ranks.sort(reverse=True)
            
            # Check for 5 consecutive ranks
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    return 1.0
            
            # Check for A-2-3-4-5 straight (wheel)
            if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
                return 1.0
            
            return 0.0
        except Exception:
            return 0.0

    def _update_opponent_tracking(self, round_state: RoundStateClient):
        """Track opponent behavior"""
        try:
            # Simple aggression tracking
            opponent_id = None
            for player_id in self.all_players:
                if player_id != self.id:
                    opponent_id = str(player_id)
                    break
            
            if opponent_id and opponent_id in round_state.player_actions:
                action = round_state.player_actions[opponent_id]
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression = min(1.0, self.opponent_aggression + 0.1)
                elif action == 'Call':
                    self.opponent_aggression = max(0.0, self.opponent_aggression - 0.05)
                
        except Exception:
            pass

    def _should_bluff(self, round_state: RoundStateClient, remaining_chips: int) -> bool:
        """Decide whether to bluff"""
        try:
            # Don't bluff if low on chips
            if remaining_chips < self.blind_amount * 5:
                return False
            
            # Bluff more against tight opponents
            bluff_frequency = 0.15 if self.opponent_aggression < 0.4 else 0.08
            
            # Increase bluff frequency on later streets
            if round_state.round == "River":
                bluff_frequency *= 1.5
            elif round_state.round == "Turn":
                bluff_frequency *= 1.2
            
            # Simple pseudo-random based on pot size
            return (round_state.pot % 100) / 100.0 < bluff_frequency
            
        except Exception:
            return False

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass