from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate pot odds and position
            pot_size = round_state.pot
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            
            # Safety check for call amount
            if call_amount > remaining_chips:
                return (PokerAction.FOLD, 0)
            
            # Determine action based on hand strength and situation
            if hand_strength >= 0.8:  # Very strong hand
                if call_amount == 0:
                    # No bet to call, we can check or raise
                    if round_state.min_raise <= remaining_chips:
                        raise_amount = min(round_state.min_raise * 2, remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # There's a bet, raise if we can
                    if round_state.min_raise <= remaining_chips:
                        raise_amount = min(call_amount + round_state.min_raise, remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                        
            elif hand_strength >= 0.6:  # Good hand
                if call_amount == 0:
                    # Check or small raise
                    if round_state.min_raise <= remaining_chips and pot_size > 0:
                        raise_amount = min(round_state.min_raise, remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Call reasonable bets
                    if call_amount <= pot_size // 3:  # Good pot odds
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            elif hand_strength >= 0.4:  # Mediocre hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Only call small bets
                    if call_amount <= pot_size // 4 and call_amount <= self.blind_amount:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            else:  # Weak hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        except Exception as e:
            # Safe fallback - check if no bet, fold if there's a bet
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.3
            
        try:
            card1_rank, card1_suit = self._parse_card(self.hole_cards[0])
            card2_rank, card2_suit = self._parse_card(self.hole_cards[1])
            
            # Base strength on hole cards
            strength = 0.0
            
            # Pocket pairs are strong
            if card1_rank == card2_rank:
                if card1_rank >= 10:  # AA, KK, QQ, JJ, TT
                    strength = 0.9
                elif card1_rank >= 7:  # 99, 88, 77
                    strength = 0.7
                else:  # 66, 55, 44, 33, 22
                    strength = 0.5
            else:
                # High cards
                high_card = max(card1_rank, card2_rank)
                low_card = min(card1_rank, card2_rank)
                
                if high_card == 14:  # Ace
                    if low_card >= 10:  # AK, AQ, AJ, AT
                        strength = 0.8
                    elif low_card >= 7:  # A9, A8, A7
                        strength = 0.6
                    else:  # A6 and below
                        strength = 0.4
                elif high_card >= 12:  # King or Queen
                    if low_card >= 10:  # KQ, KJ, KT, QJ, QT
                        strength = 0.7
                    elif low_card >= 7:  # K9, K8, K7, Q9, Q8, Q7
                        strength = 0.5
                    else:
                        strength = 0.3
                elif high_card >= 10:  # Jack or Ten
                    if low_card >= 8:  # JT, J9, T9, T8
                        strength = 0.6
                    else:
                        strength = 0.3
                else:
                    strength = 0.2
                
                # Suited cards are better
                if card1_suit == card2_suit:
                    strength += 0.1
                    
                # Connected cards are better
                if abs(card1_rank - card2_rank) == 1:
                    strength += 0.05
            
            # Adjust based on community cards if available
            if round_state.community_cards:
                strength = self._adjust_for_community_cards(strength, round_state.community_cards)
                
            return min(1.0, max(0.0, strength))
            
        except Exception:
            return 0.3  # Default mediocre strength if parsing fails
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string like 'As' into rank (14) and suit ('s')"""
        if len(card) != 2:
            return (7, 'h')  # Default fallback
            
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        
        rank = rank_map.get(rank_char, 7)
        return (rank, suit)
    
    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        try:
            # Simple adjustment - if we have many community cards, be more conservative
            if len(community_cards) >= 4:  # Turn or River
                # More players likely to have made hands
                return base_strength * 0.9
            elif len(community_cards) == 3:  # Flop
                return base_strength * 0.95
            else:
                return base_strength
        except Exception:
            return base_strength

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track game results for learning
        game_result = {
            'final_chips': remaining_chips,
            'hole_cards': self.hole_cards,
            'community_cards': round_state.community_cards
        }
        self.game_history.append(game_result)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass