from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.opponent_stats = {}
        self.position = None
        self.hand_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'raises': 0,
                    'calls': 0,
                    'folds': 0,
                    'aggression': 0.5,
                    'tightness': 0.5
                }
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            # Extract hole cards from community cards in preflop (they're passed differently)
            # We need to track our hole cards somehow - let's use a simple approach
            pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Determine position
        is_in_position = self._determine_position(round_state)
        
        # Get aggression factor based on opponents
        aggression_factor = self._get_aggression_factor(round_state)
        
        # Make decision based on multiple factors
        return self._make_decision(round_state, remaining_chips, hand_strength, pot_odds, is_in_position, aggression_factor)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        community_cards = round_state.community_cards
        
        # Basic hand strength evaluation
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(community_cards)
        else:
            return self._postflop_hand_strength(community_cards)
    
    def _preflop_hand_strength(self, cards: List[str]) -> float:
        """Evaluate preflop hand strength - simplified since we don't have direct access to hole cards"""
        # Use a more aggressive preflop strategy
        return 0.6  # Assume decent hand strength for more action
    
    def _postflop_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate postflop hand strength"""
        if len(community_cards) < 3:
            return 0.5
        
        # Simplified hand evaluation based on community cards
        # Look for high cards, pairs, potential draws
        ranks = [card[0] for card in community_cards]
        suits = [card[1] for card in community_cards]
        
        strength = 0.3  # Base strength
        
        # High card bonus
        high_cards = sum(1 for rank in ranks if rank in 'AKQJT')
        strength += high_cards * 0.1
        
        # Pair potential
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        if any(count >= 2 for count in rank_counts.values()):
            strength += 0.2
        
        # Flush potential
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        if any(count >= 3 for count in suit_counts.values()):
            strength += 0.15
        
        # Straight potential
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        values = sorted([rank_values.get(rank, 0) for rank in ranks])
        
        if len(values) >= 3:
            for i in range(len(values) - 2):
                if values[i+2] - values[i] <= 4:
                    strength += 0.1
                    break
        
        return min(strength, 1.0)
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return 1.0
        
        pot_size = round_state.pot + call_amount
        return call_amount / (pot_size + 0.001)  # Add small delta to avoid division by zero
    
    def _determine_position(self, round_state: RoundStateClient) -> bool:
        """Determine if we're in position (simplified)"""
        # In heads-up, button is in position
        return True  # Simplified for heads-up play
    
    def _get_aggression_factor(self, round_state: RoundStateClient) -> float:
        """Calculate aggression factor based on opponent behavior"""
        total_aggression = 0.5
        count = 0
        
        for player_id, stats in self.opponent_stats.items():
            if stats['hands_played'] > 0:
                total_aggression += stats['aggression']
                count += 1
        
        return total_aggression / max(count, 1)
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        for player_id_str, action in round_state.player_actions.items():
            player_id = int(player_id_str)
            if player_id != self.id and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                
                if action.lower() == 'raise':
                    stats['raises'] += 1
                    stats['aggression'] = min(1.0, stats['aggression'] + 0.1)
                elif action.lower() == 'call':
                    stats['calls'] += 1
                elif action.lower() == 'fold':
                    stats['folds'] += 1
                    stats['tightness'] = min(1.0, stats['tightness'] + 0.05)
                
                stats['hands_played'] += 1
    
    def _make_decision(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, in_position: bool, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Make the final decision based on all factors"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Adjust hand strength based on position and aggression
        adjusted_strength = hand_strength
        if in_position:
            adjusted_strength += 0.1
        
        # More aggressive strategy
        if adjusted_strength >= 0.8:
            # Very strong hand - raise aggressively
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.75))
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            else:
                if call_amount < remaining_chips * 0.3:
                    raise_amount = max(round_state.min_raise, call_amount * 3)
                    if raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, round_state.current_bet + raise_amount)
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
        
        elif adjusted_strength >= 0.65:
            # Strong hand - raise or call
            if call_amount == 0:
                raise_amount = max(round_state.min_raise, int(round_state.pot * 0.5))
                if raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                if call_amount < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    # Consider pot odds
                    if pot_odds < 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
        
        elif adjusted_strength >= 0.45:
            # Marginal hand - play cautiously but don't be too passive
            if call_amount == 0:
                # Free card - check or small bet
                if in_position and round_state.round != 'River':
                    raise_amount = max(round_state.min_raise, int(round_state.pot * 0.3))
                    if raise_amount <= remaining_chips * 0.1:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:
                if pot_odds < 0.25 and call_amount < remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        else:
            # Weak hand - mostly fold but occasional bluff
            if call_amount == 0:
                # Bluff occasionally when in position
                if in_position and aggression_factor < 0.7 and round_state.round == 'River':
                    import random
                    if random.random() < 0.2:  # 20% bluff frequency
                        raise_amount = max(round_state.min_raise, int(round_state.pot * 0.6))
                        if raise_amount <= remaining_chips * 0.15:
                            return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store hand history for learning
        self.hand_history.append({
            'round_num': round_state.round_num,
            'final_pot': round_state.pot,
            'remaining_chips': remaining_chips
        })
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_history = []