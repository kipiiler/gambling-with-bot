from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand = []
        self.opponent_stats = {}
        self.game_history = []
        self.current_round_actions = []
        self.position_stats = {}
        self.blind_amount = 0
        self.total_hands_played = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggressive_actions': 0,
                    'total_actions': 0,
                    'showdown_hands': 0,
                    'won_showdowns': 0,
                    'preflop_raise_freq': 0,
                    'fold_to_raise_freq': 0,
                    'bet_sizes': []
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.total_hands_played += 1
            self.current_round_actions = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update opponent stats
            self._update_opponent_stats(round_state)
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Calculate position advantage
            position_factor = self._calculate_position_factor(round_state)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Analyze opponents
            aggression_factor = self._analyze_opponents(round_state)
            
            # Determine action based on strategy
            action, amount = self._determine_action(
                round_state, remaining_chips, hand_strength, 
                position_factor, pot_odds, aggression_factor
            )
            
            # Validate action
            return self._validate_action(action, amount, round_state, remaining_chips)
            
        except Exception as e:
            # Emergency fallback - fold to avoid errors
            return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength on scale 0-1"""
        if not self.hand or len(self.hand) < 2:
            return 0.1
            
        try:
            hole_cards = self.hand[:2]
            community_cards = round_state.community_cards
            
            # Preflop hand evaluation
            if round_state.round == 'Preflop':
                return self._evaluate_preflop_hand(hole_cards)
            
            # Post-flop evaluation
            return self._evaluate_postflop_hand(hole_cards, community_cards)
            
        except:
            return 0.3

    def _evaluate_preflop_hand(self, hole_cards: List[str]) -> float:
        """Evaluate preflop hand strength"""
        if len(hole_cards) != 2:
            return 0.1
            
        try:
            card1_rank = self._get_card_rank(hole_cards[0])
            card2_rank = self._get_card_rank(hole_cards[1])
            card1_suit = hole_cards[0][-1]
            card2_suit = hole_cards[1][-1]
            
            is_pair = card1_rank == card2_rank
            is_suited = card1_suit == card2_suit
            
            high_card = max(card1_rank, card2_rank)
            low_card = min(card1_rank, card2_rank)
            gap = high_card - low_card
            
            # Premium hands
            if is_pair:
                if high_card >= 10:  # TT+
                    return 0.9
                elif high_card >= 7:  # 77-99
                    return 0.7
                else:  # 22-66
                    return 0.5
            
            # High suited connectors and broadway
            if is_suited:
                if high_card >= 12:  # AK, AQ, etc.
                    return 0.85
                elif high_card >= 10 and gap <= 3:
                    return 0.65
                elif gap <= 1:  # Suited connectors
                    return 0.6
                else:
                    return 0.4
            
            # Offsuit high cards
            if high_card >= 12:  # AK, AQ offsuit
                return 0.75
            elif high_card >= 10 and gap <= 2:
                return 0.5
            else:
                return 0.3
                
        except:
            return 0.3

    def _evaluate_postflop_hand(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate post-flop hand strength"""
        try:
            all_cards = hole_cards + community_cards
            hand_rank = self._get_hand_rank(all_cards)
            
            # Convert hand rank to strength (higher rank = stronger hand)
            strength_map = {
                9: 1.0,   # Royal flush
                8: 0.95,  # Straight flush
                7: 0.9,   # Four of a kind
                6: 0.85,  # Full house
                5: 0.8,   # Flush
                4: 0.7,   # Straight
                3: 0.6,   # Three of a kind
                2: 0.45,  # Two pair
                1: 0.3,   # One pair
                0: 0.15   # High card
            }
            
            base_strength = strength_map.get(hand_rank, 0.15)
            
            # Add draw potential
            draw_strength = self._evaluate_draws(hole_cards, community_cards)
            
            return min(1.0, base_strength + draw_strength)
            
        except:
            return 0.3

    def _get_hand_rank(self, cards: List[str]) -> int:
        """Get hand ranking (0=high card, 9=royal flush)"""
        if len(cards) < 5:
            return 0
            
        try:
            ranks = sorted([self._get_card_rank(card) for card in cards], reverse=True)
            suits = [card[-1] for card in cards]
            
            # Count ranks
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            counts = sorted(rank_counts.values(), reverse=True)
            is_flush = len(set(suits)) == 1 if len(cards) == 5 else suits.count(suits[0]) >= 5
            is_straight = self._is_straight(ranks)
            
            # Check hand types
            if is_straight and is_flush:
                if max(ranks) == 14:  # Ace high straight flush
                    return 9  # Royal flush
                return 8  # Straight flush
            elif counts[0] == 4:
                return 7  # Four of a kind
            elif counts[0] == 3 and counts[1] == 2:
                return 6  # Full house
            elif is_flush:
                return 5  # Flush
            elif is_straight:
                return 4  # Straight
            elif counts[0] == 3:
                return 3  # Three of a kind
            elif counts[0] == 2 and counts[1] == 2:
                return 2  # Two pair
            elif counts[0] == 2:
                return 1  # One pair
            else:
                return 0  # High card
                
        except:
            return 0

    def _get_card_rank(self, card: str) -> int:
        """Convert card rank to numeric value"""
        if len(card) < 2:
            return 2
            
        rank_char = card[0]
        rank_map = {
            '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
            '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
        }
        return rank_map.get(rank_char, 2)

    def _is_straight(self, ranks: List[int]) -> bool:
        """Check if ranks form a straight"""
        unique_ranks = sorted(list(set(ranks)))
        if len(unique_ranks) < 5:
            return False
            
        # Check for normal straight
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
        
        # Check for A-2-3-4-5 straight (wheel)
        if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
            
        return False

    def _evaluate_draws(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate draw potential"""
        if len(community_cards) >= 5:
            return 0
            
        try:
            all_cards = hole_cards + community_cards
            suits = [card[-1] for card in all_cards]
            ranks = [self._get_card_rank(card) for card in all_cards]
            
            draw_value = 0
            
            # Flush draw
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            
            if max_suit_count == 4:
                draw_value += 0.15  # Flush draw
            elif max_suit_count >= 3:
                draw_value += 0.05  # Backdoor flush draw
            
            # Straight draw
            unique_ranks = sorted(list(set(ranks)))
            gaps = 0
            for i in range(len(unique_ranks) - 1):
                if unique_ranks[i+1] - unique_ranks[i] == 1:
                    gaps += 1
            
            if gaps >= 3:
                draw_value += 0.1  # Open-ended straight draw
            elif gaps >= 2:
                draw_value += 0.05  # Gutshot draw
            
            return draw_value
            
        except:
            return 0

    def _calculate_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage (1.0 = best position, 0.0 = worst)"""
        try:
            active_players = len([p for p in self.all_players if str(p) in round_state.player_bets])
            if active_players <= 2:
                return 0.8  # Heads up - position matters a lot
            
            # Estimate position based on action order
            my_id_str = str(self.id)
            if my_id_str in round_state.player_actions:
                # Later position is generally better
                return 0.7
            else:
                # Earlier position
                return 0.3
                
        except:
            return 0.5

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            
            if call_amount == 0:
                return 1.0  # No cost to continue
            
            if call_amount >= remaining_chips:
                call_amount = remaining_chips
            
            if call_amount == 0:
                return 1.0
                
            pot_odds = round_state.pot / (call_amount + 0.01)  # Avoid division by zero
            return min(1.0, pot_odds / 10.0)  # Normalize
            
        except:
            return 0.5

    def _analyze_opponents(self, round_state: RoundStateClient) -> float:
        """Analyze opponent aggression"""
        try:
            aggression_sum = 0
            opponent_count = 0
            
            for player_id, stats in self.opponent_stats.items():
                if str(player_id) in round_state.player_bets:
                    if stats['total_actions'] > 0:
                        aggression = stats['aggressive_actions'] / (stats['total_actions'] + 0.01)
                        aggression_sum += aggression
                        opponent_count += 1
            
            if opponent_count == 0:
                return 0.5
                
            return aggression_sum / opponent_count
            
        except:
            return 0.5

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent statistics"""
        try:
            for player_id_str, action in round_state.player_actions.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    stats = self.opponent_stats[player_id]
                    stats['total_actions'] += 1
                    
                    if action in ['RAISE', 'ALL_IN']:
                        stats['aggressive_actions'] += 1
                        
        except:
            pass

    def _determine_action(self, round_state: RoundStateClient, remaining_chips: int, 
                         hand_strength: float, position_factor: float, 
                         pot_odds: float, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Determine the best action"""
        
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        # Calculate overall strength
        overall_strength = (hand_strength * 0.5 + 
                          position_factor * 0.2 + 
                          pot_odds * 0.2 + 
                          (1.0 - aggression_factor) * 0.1)
        
        # Short stack adjustments
        stack_ratio = remaining_chips / (self.starting_chips + 0.01)
        if stack_ratio < 0.2:  # Short stack - push/fold strategy
            if hand_strength > 0.6:
                return PokerAction.ALL_IN, 0
            elif call_amount > remaining_chips * 0.3:
                return PokerAction.FOLD, 0
        
        # No bet to call - check or bet
        if call_amount == 0:
            if overall_strength > 0.7:
                # Strong hand - bet for value
                bet_size = int(round_state.pot * 0.7)
                bet_size = max(bet_size, round_state.min_raise)
                bet_size = min(bet_size, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
                else:
                    return PokerAction.CHECK, 0
            elif overall_strength > 0.4:
                # Medium hand - check
                return PokerAction.CHECK, 0
            else:
                # Weak hand - check
                return PokerAction.CHECK, 0
        
        # Facing a bet
        else:
            if call_amount >= remaining_chips:
                # All-in decision
                if overall_strength > 0.6:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Normal betting decision
            if overall_strength > 0.8:
                # Very strong - raise
                raise_size = int(call_amount + round_state.pot * 0.5)
                raise_size = max(raise_size, round_state.min_raise)
                raise_size = min(raise_size, remaining_chips)
                if raise_size >= round_state.min_raise:
                    return PokerAction.RAISE, raise_size
                else:
                    return PokerAction.CALL, 0
            elif overall_strength > 0.5:
                # Medium strength - call
                return PokerAction.CALL, 0
            elif pot_odds > 0.3 and overall_strength > 0.3:
                # Good pot odds with some equity
                return PokerAction.CALL, 0
            else:
                # Weak hand - fold
                return PokerAction.FOLD, 0

    def _validate_action(self, action: PokerAction, amount: int, 
                        round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Validate and fix action if needed"""
        
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        
        try:
            if action == PokerAction.CHECK:
                if round_state.current_bet > my_bet:
                    # Can't check when facing a bet
                    return PokerAction.FOLD, 0
                return PokerAction.CHECK, 0
            
            elif action == PokerAction.CALL:
                if call_amount == 0:
                    return PokerAction.CHECK, 0
                if call_amount >= remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.CALL, 0
            
            elif action == PokerAction.RAISE:
                if amount < round_state.min_raise:
                    if call_amount == 0:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CALL, 0
                
                if amount >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                
                return PokerAction.RAISE, min(amount, remaining_chips)
            
            elif action == PokerAction.ALL_IN:
                return PokerAction.ALL_IN, 0
            
            else:  # FOLD
                return PokerAction.FOLD, 0
                
        except:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round"""
        # Record game history for learning
        self.game_history.append({
            'round_state': round_state,
            'final_chips': remaining_chips,
            'hand': self.hand.copy() if self.hand else []
        })
        
        # Keep only recent history to manage memory
        if len(self.game_history) > 100:
            self.game_history = self.game_history[-100:]

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game"""
        # Update opponent stats based on revealed hands
        try:
            for player_id_str, hand in active_players_hands.items():
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_stats:
                    self.opponent_stats[player_id]['showdown_hands'] += 1
                    # Could analyze showdown tendencies here
        except:
            pass