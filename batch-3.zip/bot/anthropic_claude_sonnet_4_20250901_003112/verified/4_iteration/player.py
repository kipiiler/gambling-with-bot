from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 10000
        self.blind_amount = 10
        self.game_history = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(self.hand, round_state.community_cards)
            
            # Get current betting situation
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            
            # Pot odds calculation
            pot_size = round_state.pot
            if call_amount > 0:
                pot_odds = call_amount / (pot_size + call_amount + 0.001)  # Add small epsilon
            else:
                pot_odds = 0
            
            # Aggressive strategy based on hand strength and position
            if hand_strength >= 0.8:  # Very strong hand
                if call_amount == 0:
                    # Bet/raise aggressively
                    bet_size = max(round_state.min_raise, int(pot_size * 0.75))
                    bet_size = min(bet_size, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Strong hand, raise if possible
                    if call_amount < remaining_chips * 0.3:  # Don't risk too much
                        raise_size = call_amount + max(round_state.min_raise, int(pot_size * 0.5))
                        raise_size = min(raise_size, round_state.max_raise)
                        if raise_size >= round_state.min_raise and raise_size <= remaining_chips:
                            return (PokerAction.RAISE, raise_size)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.CALL, 0)
                        
            elif hand_strength >= 0.6:  # Good hand
                if call_amount == 0:
                    # Moderate bet
                    bet_size = max(round_state.min_raise, int(pot_size * 0.5))
                    bet_size = min(bet_size, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    # Call reasonable bets
                    if pot_odds <= 0.4 and call_amount <= remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            elif hand_strength >= 0.4:  # Marginal hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Call small bets with good pot odds
                    if pot_odds <= 0.25 and call_amount <= self.blind_amount * 2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
            else:  # Weak hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    # Only call very small bets with excellent pot odds
                    if pot_odds <= 0.15 and call_amount <= self.blind_amount:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # Fallback to safe play if any error occurs
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        try:
            if not hole_cards or len(hole_cards) != 2:
                return 0.3
                
            # Parse hole cards
            card1_rank, card1_suit = self._parse_card(hole_cards[0])
            card2_rank, card2_suit = self._parse_card(hole_cards[1])
            
            if card1_rank is None or card2_rank is None:
                return 0.3
            
            strength = 0.0
            
            # Pre-flop hand evaluation
            if len(community_cards) == 0:
                # Pocket pairs
                if card1_rank == card2_rank:
                    if card1_rank >= 12:  # AA, KK
                        strength = 0.95
                    elif card1_rank >= 10:  # QQ, JJ
                        strength = 0.85
                    elif card1_rank >= 8:  # TT, 99
                        strength = 0.75
                    elif card1_rank >= 6:  # 88, 77
                        strength = 0.65
                    else:  # 66 and below
                        strength = 0.55
                
                # Suited connectors and high cards
                elif card1_suit == card2_suit:  # Suited
                    high_card = max(card1_rank, card2_rank)
                    if high_card >= 12 and min(card1_rank, card2_rank) >= 10:  # AK, AQ, AJ, KQ suited
                        strength = 0.8
                    elif high_card >= 11:  # Other ace/king suited
                        strength = 0.6
                    elif abs(card1_rank - card2_rank) <= 2:  # Suited connectors
                        strength = 0.5
                    else:
                        strength = 0.4
                
                # Offsuit high cards
                else:
                    high_card = max(card1_rank, card2_rank)
                    low_card = min(card1_rank, card2_rank)
                    if high_card >= 12 and low_card >= 10:  # AK, AQ, AJ, KQ offsuit
                        strength = 0.7
                    elif high_card >= 12 and low_card >= 8:  # AT, A9, KJ, KT
                        strength = 0.5
                    elif high_card >= 10 and low_card >= 8:  # QJ, QT, JT
                        strength = 0.45
                    else:
                        strength = 0.3
            
            else:
                # Post-flop evaluation with community cards
                all_cards = hole_cards + community_cards
                hand_rank = self._get_hand_rank(all_cards)
                
                if hand_rank >= 8:  # Straight flush or better
                    strength = 0.99
                elif hand_rank == 7:  # Four of a kind
                    strength = 0.95
                elif hand_rank == 6:  # Full house
                    strength = 0.9
                elif hand_rank == 5:  # Flush
                    strength = 0.8
                elif hand_rank == 4:  # Straight
                    strength = 0.75
                elif hand_rank == 3:  # Three of a kind
                    strength = 0.7
                elif hand_rank == 2:  # Two pair
                    strength = 0.6
                elif hand_rank == 1:  # One pair
                    strength = 0.5
                else:  # High card
                    strength = 0.3
            
            return min(0.99, max(0.1, strength))
            
        except Exception:
            return 0.3

    def _parse_card(self, card: str) -> Tuple[int, str]:
        try:
            if len(card) != 2:
                return None, None
                
            rank_char = card[0]
            suit = card[1]
            
            if rank_char == 'A':
                rank = 12
            elif rank_char == 'K':
                rank = 11
            elif rank_char == 'Q':
                rank = 10
            elif rank_char == 'J':
                rank = 9
            elif rank_char == 'T':
                rank = 8
            elif rank_char.isdigit():
                rank = int(rank_char) - 2
            else:
                return None, None
                
            return rank, suit
        except Exception:
            return None, None

    def _get_hand_rank(self, cards: List[str]) -> int:
        try:
            if len(cards) < 5:
                return 0
                
            # Parse all cards
            parsed_cards = []
            for card in cards:
                rank, suit = self._parse_card(card)
                if rank is not None:
                    parsed_cards.append((rank, suit))
            
            if len(parsed_cards) < 5:
                return 0
                
            # Count ranks and suits
            rank_counts = {}
            suit_counts = {}
            ranks = []
            
            for rank, suit in parsed_cards:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
                ranks.append(rank)
            
            ranks.sort(reverse=True)
            count_values = sorted(rank_counts.values(), reverse=True)
            
            # Check for flush
            is_flush = max(suit_counts.values()) >= 5
            
            # Check for straight
            unique_ranks = sorted(set(ranks), reverse=True)
            is_straight = False
            if len(unique_ranks) >= 5:
                for i in range(len(unique_ranks) - 4):
                    if unique_ranks[i] - unique_ranks[i + 4] == 4:
                        is_straight = True
                        break
            
            # Determine hand rank
            if is_straight and is_flush:
                return 8  # Straight flush
            elif count_values[0] == 4:
                return 7  # Four of a kind
            elif count_values[0] == 3 and count_values[1] == 2:
                return 6  # Full house
            elif is_flush:
                return 5  # Flush
            elif is_straight:
                return 4  # Straight
            elif count_values[0] == 3:
                return 3  # Three of a kind
            elif count_values[0] == 2 and count_values[1] == 2:
                return 2  # Two pair
            elif count_values[0] == 2:
                return 1  # One pair
            else:
                return 0  # High card
                
        except Exception:
            return 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass