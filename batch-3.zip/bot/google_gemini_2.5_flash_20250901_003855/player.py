from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_amount = 0
        self.small_blind_amount = 0
        self.my_player_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.big_blind_amount = blind_amount
        self.small_blind_amount = blind_amount // 2 if blind_amount > 1 else 1 # Ensure small blind is at least 1
        # Player hands are not directly given to your bot at the start of the game,
        # but are revealed in on_round_start. We'll store our own player ID.
        self.my_player_id = self.id # Bot's own ID is set by the framework

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # In a real poker client, you only know your own hole cards.
        # This state object is simplified for competition to potentially include other hands.
        # We need to ensure we only use our hand.
        # The game environment provides player_hands on on_start, but it's empty for opponents.
        # RoundStateClient does not directly expose `player_hands` for the current round.
        # We assume `player_hands` from `on_start` is the initial deal to ME.
        # For this competition, `player_hands` in `on_start` is the bot's hole cards.
        self.hole_cards = [card for player, card in round_state.player_hands.items() if str(player) == str(self.my_player_id)] if hasattr(round_state, 'player_hands') else []
        if self.hole_cards:
            self.hole_cards = self.hole_cards[0] # It's a list within a list from the provided state
        else:
            self.hole_cards = [] # Fallback if not provided or empty

    def _get_card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def _evaluate_hand_strength_preflop(self) -> float:
        """
        Estimates pre-flop hand strength based on common poker hand rankings.
        Returns a value between 0.0 (weak) and 1.0 (strong).
        """
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.0 # Should not happen, but for safety

        card1_rank = self._get_card_rank(self.hole_cards[0])
        card2_rank = self._get_card_rank(self.hole_cards[1])
        card1_suit = self.hole_cards[0][-1]
        card2_suit = self.hole_cards[1][-1]

        ranks = sorted([card1_rank, card2_rank])
        is_suited = (card1_suit == card2_suit)
        is_pair = (card1_rank == card2_rank)

        strength = 0.0

        if is_pair:
            if ranks[0] >= 11: strength = 0.85 # JJ+
            elif ranks[0] >= 7: strength = 0.7 # 77-TT
            else: strength = 0.5 # 22-66
        elif is_suited:
            if ranks[0] >= 12 or ranks[1] >= 12: strength = 0.8 # AKs, AQs, KQs
            elif ranks[0] >= 10 and ranks[1] >= 10: strength = 0.7 # TJs+
            elif ranks[1] >= 10: strength = 0.6 # Suited Broadway (e.g. A2s, K2s, etc.)
            elif ranks[1] - ranks[0] <= 1 and ranks[1] >= 5: strength = 0.5 # Suited connectors 54s+
            else: strength = 0.3 # Other suited hands
        else: # Offsuit
            if ranks[1] >= 14 and ranks[0] >= 12: strength = 0.7 # AKo, AQo
            elif ranks[1] >= 13 and ranks[0] >= 11: strength = 0.6 # KQo, KJo
            elif ranks[1] >= 12: strength = 0.5 # QJo, QTo
            elif ranks[1] >= 10: strength = 0.4 # JTo
            else: strength = 0.2 # Others

        # Adjust for gap hands (more difficult to make straights)
        if not is_suited and not is_pair:
            gap = ranks[1] - ranks[0]
            if gap >= 3:
                strength *= 0.7
            elif gap == 2:
                strength *= 0.8
            
        return min(max(strength, 0.0), 1.0) # Ensure between 0 and 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.my_player_id), 0)
        
        # If current_bet_to_match is negative, it means we have overbet, so we can check.
        # This can happen if we are the big blind and no one else raised.
        can_check = current_bet_to_match <= 0

        # Basic strategy based on pre-flop strength
        hand_strength = self._evaluate_hand_strength_preflop()
        
        if round_state.round == 'Preflop':
            if hand_strength >= 0.75: # Strong hands (AA, KK, QQ, AKs, AKo)
                # Aggressive play: Raise significantly or go all-in
                if remaining_chips <= current_bet_to_match: # Can only call/all-in
                    return (PokerAction.ALL_IN, 0)
                
                # Try to raise 3-4x big blind or current bet
                raise_amount = max(3 * self.big_blind_amount, current_bet_to_match * 2)
                raise_amount = min(raise_amount, remaining_chips) # Cap at remaining chips
                raise_amount = max(raise_amount, round_state.min_raise) # Ensure at least min_raise
                
                if raise_amount + round_state.player_bets.get(str(self.my_player_id), 0) <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
                else: # Cannot raise desired amount, call or all-in
                    if current_bet_to_match > 0 and remaining_chips >= current_bet_to_match:
                         return (PokerAction.CALL, 0)
                    else: # If we can't call potentially (e.g. already matched or less than min raise), check or fold
                        if can_check: return (PokerAction.CHECK, 0)
                        return (PokerAction.FOLD, 0) # Fallback to fold if no better option

            elif hand_strength >= 0.5: # Medium strength hands (pairs 77-TT, suited connectors, strong broadways)
                if current_bet_to_match == 0: # No raise yet
                    return (PokerAction.CALL, 0) # Smooth call (limp) or check as big blind
                elif current_bet_to_match <= self.big_blind_amount * 2 or remaining_chips * 0.1 > current_bet_to_match: # Small raise from opponent
                    if remaining_chips >= current_bet_to_match:
                        # Consider a small raise back if opponent bet small
                        if current_bet_to_match < self.big_blind_amount * 2:
                            raise_amount = min(current_bet_to_match * 2, remaining_chips)
                            if raise_amount + round_state.player_bets.get(str(self.my_player_id), 0) <= round_state.max_raise:
                                return (PokerAction.RAISE, raise_amount)
                        return (PokerAction.CALL, 0) # Call
                    else:
                        return (PokerAction.ALL_IN, 0) # All-in if can't call
                else: # Large raise from opponent or can't afford to call comfortably
                    return (PokerAction.FOLD, 0)

            else: # Weak hands
                if current_bet_to_match == 0:
                    return (PokerAction.CHECK, 0) # Check if possible
                elif current_bet_to_match <= self.big_blind_amount: # Call only if minimal raise
                    if remaining_chips >= current_bet_to_match:
                        return (PokerAction.CALL, 0)
                    else: # Can't afford to call, fold
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Post-flop strategy (Flop, Turn, River) - more complex evaluation needed here
        # This is a very basic placeholder for post-flop: prioritize check/call, but fold to big bets.
        elif round_state.round in ['Flop', 'Turn', 'River']:
            # For simplicity, if we have made any bet previously and current bet is 0, check
            if current_bet_to_match == 0:
                return (PokerAction.CHECK, 0)
            
            # If current bet is reasonable (e.g., less than 20% of remaining chips) and we can afford it, call.
            # This is a very rough heuristic and needs robust hand evaluation.
            if remaining_chips >= current_bet_to_match and current_bet_to_match < remaining_chips * 0.25:
                # Add a small chance to bluff for medium strength preflop hands, or if few players remain.
                # This needs to be much more nuanced.
                if hand_strength >= 0.5 and random.random() < 0.1 and round_state.max_raise > 0 and remaining_chips > current_bet_to_match:
                    raise_amount = min(current_bet_to_match * 2, remaining_chips - current_bet_to_match) + current_bet_to_match # Raise at least 2x current bet
                    raise_amount = max(raise_amount, round_state.min_raise)
                    if raise_amount + round_state.player_bets.get(str(self.my_player_id), 0) <= round_state.max_raise :
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif remaining_chips <= current_bet_to_match: # Can only go all-in
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Default safety: If all else fails, fold or check if possible.
        if can_check:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for the next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass