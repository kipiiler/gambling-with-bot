from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.community_cards = []
        self.hand_strength = 0
        self.has_pair = False
        self.is_suited = False
        self.is_connected = False
        self.chip_stack = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.chip_stack = starting_chips
        self.blind_amount = blind_amount
        # In a heads-up game, sometimes the small blind is also the first to act pre-flop.
        # This determines if the bot is in a blind position for the whole game, not just one hand.
        self.is_big_blind_player_id = big_blind_player_id
        self.is_small_blind_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = self.get_my_hole_cards(round_state)
        self.community_cards = round_state.community_cards
        self.chip_stack = remaining_chips
        self.is_big_blind = (self.id == round_state.player_bets.get(str(self.is_big_blind_player_id), None) and self.blind_amount == round_state.player_bets.get(str(self.is_big_blind_player_id))) # Check if actually big blind in current round
        self.is_small_blind = (self.id == round_state.player_bets.get(str(self.is_small_blind_player_id), None) and self.blind_amount / 2 == round_state.player_bets.get(str(self.is_small_blind_player_id))) # Check if actually small blind in current round

        self.evaluate_hand()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.chip_stack = remaining_chips
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        # Pre-flop strategy
        if round_state.round == PokerRound.PREFLOP.name:
            if self.hand_strength == 2:  # Pair
                if current_bet_to_match == 0:  # No raise yet
                    return PokerAction.RAISE, max(min_raise, self.blind_amount * 3)
                elif current_bet_to_match < self.chip_stack / 4: # Small raise to call
                    return PokerAction.RAISE, max(min_raise, current_bet_to_match * 2)
                else: # Big raise, consider if pair is high
                    if self.get_card_rank(self.hole_cards[0]) >= self.get_rank_value('J'): # High pair (JJ-AA)
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.CALL, 0
            elif self.is_suited and self.is_connected and self.hand_strength == 1: # Suited connectors
                if current_bet_to_match == 0:
                    return PokerAction.RAISE, max(min_raise, self.blind_amount * 2)
                elif current_bet_to_match < self.chip_stack / 8:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            elif self.hand_strength == 1:  # High card or medium cards
                if current_bet_to_match == 0:
                    if self.get_card_rank(self.hole_cards[0]) >= self.get_rank_value('T'): # High Card (T-A)
                        return PokerAction.CALL, 0 # Just call to see the flop
                    else:
                        return PokerAction.CHECK, 0 # Check
                elif current_bet_to_match < self.chip_stack / 10: # Small bet to call
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else: # Weak hand
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        else:
            bet_pot_ratio = current_bet_to_match / (round_state.pot + 1e-9) # Add epsilon to avoid division by zero
            
            # Strong hand: Two Pair, Three of a Kind, Straights, Flushes, Full House, Four of a Kind, Straight Flush, Royal Flush
            if self.hand_strength >= 3:
                # Value bet: Raise proportional to hand strength and pot size
                if current_bet_to_match == 0:
                    # Bet 75% of pot
                    bet_amount = int(round_state.pot * 0.75)
                    bet_amount = max(min_raise, bet_amount)
                    bet_amount = min(bet_amount, max_raise, self.chip_stack)
                    return PokerAction.RAISE, bet_amount
                else: # If there's a bet to call
                    if bet_pot_ratio < 0.5: # Opponent bet less than half pot, re-raise
                        re_raise_amount = int(current_bet_to_match * 2.5) # Try to pot-size raise
                        re_raise_amount = max(min_raise, re_raise_amount)
                        re_raise_amount = min(re_raise_amount, max_raise, self.chip_stack)
                        return PokerAction.RAISE, re_raise_amount
                    elif bet_pot_ratio < 1.0: # Opponent bet around pot size, call
                        return PokerAction.CALL, 0
                    else: # Opponent all-in or over-bet, go all-in with strong hand
                        return PokerAction.ALL_IN, 0

            # Medium hand: One Pair (especially top pair), high card with drawing potential
            elif self.hand_strength == 2:
                if current_bet_to_match == 0: # Check or small bet
                    if self.get_card_rank(self.hole_cards[0]) >= self.get_rank_value('T') or self.has_pair: # Top pair or high card
                        # Bet 50% of pot
                        bet_amount = int(round_state.pot * 0.5)
                        bet_amount = max(min_raise, bet_amount)
                        bet_amount = min(bet_amount, max_raise, self.chip_stack)
                        return PokerAction.RAISE, bet_amount
                    else:
                        return PokerAction.CHECK, 0
                else: # If there's a bet to call
                    if bet_pot_ratio < 0.3: # Small bet, call
                        return PokerAction.CALL, 0
                    elif bet_pot_ratio < 0.75: # Moderate bet, depends on pair strength
                        if self.get_card_rank(self.hole_cards[0]) >= self.get_rank_value('Q') or self.has_pair: # High pair or top pair
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    else: # Large bet or all-in, fold unless strong
                        return PokerAction.FOLD, 0

            # Weak hand: High card, no pair, no strong draws
            else:
                if current_bet_to_match == 0:
                    return PokerAction.CHECK, 0
                else:
                    # If facing a bet, always fold with weak hand
                    return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.chip_stack = remaining_chips
        self.hole_cards = []
        self.community_cards = []
        self.hand_strength = 0
        self.has_pair = False
        self.is_suited = False
        self.is_connected = False
        self.is_big_blind = False
        self.is_small_blind = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def evaluate_hand(self):
        # Basic hand evaluation (can be greatly expanded)
        all_cards = self.hole_cards + self.community_cards
        
        # Reset strength
        self.hand_strength = 0
        self.has_pair = False
        self.is_suited = False
        self.is_connected = False

        if len(self.hole_cards) == 2:
            card1_rank = self.get_card_rank(self.hole_cards[0])
            card2_rank = self.get_card_rank(self.hole_cards[1])
            card1_suit = self.get_card_suit(self.hole_cards[0])
            card2_suit = self.get_card_suit(self.hole_cards[1])

            if card1_rank == card2_rank:
                self.hand_strength = 2 # A pair
                self.has_pair = True
            elif card1_suit == card2_suit:
                self.is_suited = True
            elif abs(card1_rank - card2_rank) == 1:
                self.is_connected = True
            
            # Simple high card check for pre-flop, assume it's at least 1 (high card)
            self.hand_strength = max(self.hand_strength, 1)

        # Post-flop hand evaluation
        if len(all_cards) >= 5:
            # Count rank occurrences for pairs, three of a kind, four of a kind
            rank_counts = {}
            for card in all_cards:
                rank = self.get_card_rank(card)
                rank_counts[rank] = rank_counts.get(rank, 0) + 1

            pairs = sum(1 for count in rank_counts.values() if count == 2)
            trips = sum(1 for count in rank_counts.values() if count == 3)
            quads = sum(1 for count in rank_counts.values() if count == 4)

            if quads > 0:
                self.hand_strength = 8  # Four of a kind
            elif trips > 0 and pairs > 0:
                self.hand_strength = 7 # Full House
            elif trips > 0:
                self.hand_strength = 4 # Three of a kind
            elif pairs >= 2:
                self.hand_strength = 3 # Two Pair
            elif pairs == 1:
                self.hand_strength = max(self.hand_strength, 2) # Just a pair

            # Check for Flush
            suit_counts = {}
            for card in all_cards:
                suit = self.get_card_suit(card)
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            if any(count >= 5 for count in suit_counts.values()):
                self.hand_strength = max(self.hand_strength, 6) # Flush

            # Check for Straight
            ranks = sorted(list(set(self.get_card_rank(card) for card in all_cards)))
            if len(ranks) >= 5:
                # Check for standard straights
                for i in range(len(ranks) - 4):
                    if ranks[i+4] - ranks[i] == 4:
                        self.hand_strength = max(self.hand_strength, 5) # Straight
                        break
                # Check for A-5 straight (Ace low)
                if self.get_rank_value('A') in ranks and self.get_rank_value('2') in ranks and \
                   self.get_rank_value('3') in ranks and self.get_rank_value('4') in ranks and \
                   self.get_rank_value('5') in ranks:
                    self.hand_strength = max(self.hand_strength, 5) # Straight

    def get_card_rank(self, card: str) -> int:
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def get_rank_value(self, rank_char: str) -> int:
        if rank_char == 'T': return 10
        if rank_char == 'J': return 11
        if rank_char == 'Q': return 12
        if rank_char == 'K': return 13
        if rank_char == 'A': return 14
        return int(rank_char)

    def get_card_suit(self, card: str) -> str:
        return card[1]

    def get_my_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        # This is a placeholder. The actual hole cards are usually passed to the bot
        # directly at the start of the round in the `player_hands` parameter of `on_start`,
        # but the `RoundStateClient` does not expose opponent hole cards.
        # This function assumes `self.hole_cards` would be populated through `on_round_start`
        # if the bot framework provided it directly.
        # For evaluation, we need to ensure the bot has access to its own hole cards.
        # Assuming `player_hands` would be updated for the bot for each new round.
        # In this simplistic bot, `self.hole_cards` is already received in `on_round_start`.
        return self.hole_cards # Already set by on_round_start