from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.big_blind_amount = blind_amount * 2
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards at the start of each round
        # This assumes the server sends hole cards with round_state at round start.
        # If not, you might need to infer from a different source or store it.
        # For this template, we assume `round_state.player_hands` would contain
        # the current player's hand. If it's not directly in round_state,
        # you might need to adjust based on how the server provides it.
        # A more robust solution would be to save it when `on_start` is called,
        # but `on_start` only provides `player_hands` generally.
        # We'll use a placeholder for now, assuming the bot internally knows its hand.
        # In a real setup, `get_action` would likely have the correct hole cards.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Simple strategy:
        # 1. Evaluate hand strength (placeholder for now)
        # 2. Adjust strategy based on round (Preflop, Flop, Turn, River)
        # 3. Consider current bet, minimum raise, and maximum raise
        # 4. Consider remaining chips

        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        can_check = (round_state.current_bet == 0)

        # Placeholder for hand strength evaluation (simplified)
        # Assign arbitrary strength based on available information.
        # In a real bot, this would involve card parsing and combination evaluation.
        # For simplicity, we'll assign strength based on number of community cards
        # and a random factor to simulate varying hand quality.
        
        # NOTE: self.hole_cards is not populated by the provided RoundStateClient or Bot interface.
        # In a real game, 'set_id' might be followed by 'on_start' where player_hands might be given to the bot.
        # Assuming for the moment that `player_hands` from `on_start` provides the current bot's hands.
        # This is a critical piece of information missing from the `RoundStateClient` example for `get_action`.
        # For now, we'll simulate hand knowledge by using a random strength.
        
        hand_rank_score = self._evaluate_hand_strength()

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            if hand_rank_score >= 0.8: # Strong hands
                raise_amount = min(round_state.max_raise, max(round_state.min_raise, self.big_blind_amount * 3))
                if raise_amount > 0 and remaining_chips >= raise_amount:
                    return (PokerAction.RAISE, raise_amount)
                elif remaining_chips >= amount_to_call and amount_to_call > 0:
                    return (PokerAction.CALL, 0)
                else: # if amount_to_call is 0
                    return (PokerAction.CHECK, 0)
            elif hand_rank_score >= 0.5: # Medium hands
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif remaining_chips >= amount_to_call and amount_to_call <= self.big_blind_amount * 2: # Call small bets
                    return (PokerAction.CALL, 0)
                else: # Fold if bet is too high for a medium hand
                    return (PokerAction.FOLD, 0)
            else: # Weak hands
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Post-flop (Flop, Turn, River) strategy
        else:
            # Adjust hand strength based on community cards
            # A more sophisticated eval would integrate hole cards with community cards here.
            # For iteration 2, we just use the `hand_rank_score` and add a small random element
            # to simulate board impact.
            # hand_rank_score += (len(round_state.community_cards) * 0.05) * random.uniform(-0.5, 0.5)

            if hand_rank_score >= 0.7: # Strong hands (e.g., made hands, strong draws)
                if round_state.max_raise > 0:
                    # Bet aggressively
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, round_state.pot // 2))
                    if raise_amount > 0 and remaining_chips >= raise_amount:
                        return (PokerAction.RAISE, raise_amount)
                
                if remaining_chips >= amount_to_call and amount_to_call > 0:
                        return (PokerAction.CALL, 0)
                elif can_check:
                    return (PokerAction.CHECK, 0)
                else: # If cannot check and cannot call, must fold or all_in
                    return (PokerAction.ALL_IN, 0) # Aggressive with strong hand if no other option
            
            elif hand_rank_score >= 0.4: # Medium hands (e.g., pairs, weak draws)
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif remaining_chips >= amount_to_call and amount_to_call <= round_state.pot // 3: # Call if bet is reasonable
                    return (PokerAction.CALL, 0)
                else: # Raise if aggressive opponent, else call/fold
                    # Consider a small raise bluff or value bet
                    if random.random() < 0.2: # 20% chance to bluff/value bet if allowed
                        raise_amount = min(round_state.max_raise, max(round_state.min_raise, round_state.pot // 4))
                        if raise_amount > 0 and remaining_chips >= raise_amount:
                            return (PokerAction.RAISE, raise_amount)
                        elif remaining_chips >= amount_to_call and amount_to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        if remaining_chips >= amount_to_call and amount_to_call > 0:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
            
            else: # Weak hands (e.g., high card, very weak draws)
                if can_check:
                    return (PokerAction.CHECK, 0)
                elif amount_to_call > 0:
                    # Only call if the bet is very small
                    if remaining_chips >= amount_to_call and amount_to_call < self.big_blind_amount / 2:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else: # Should not happen if can_check is false and amount_to_call is 0
                    return (PokerAction.FOLD, 0)

        # Fallback in case none of the above conditions are met (should not be reached with comprehensive logic)
        return (PokerAction.FOLD, 0)
    
    def _evaluate_hand_strength(self):
        # This is a very simplistic and random hand strength evaluator for demonstration.
        # In a real bot, you would parse self.hole_cards and round_state.community_cards
        # to determine actual poker hand strength.
        # Ranks: Royal flush (strongest) to High card (weakest)
        # Returns a score between 0.0 (weakest) and 1.0 (strongest)

        # For Iteration 2, a more nuanced random choice might simulate better play.
        # Let's say:
        # - 10% chance of a strong hand (0.8-1.0) - e.g., AA, KK, suited connectors
        # - 30% chance of a medium hand (0.4-0.7) - e.g., unpaired Broadway, small pairs
        # - 60% chance of a weak hand (0.0-0.3) - e.g., rag hands

        r = random.random()
        if r < 0.1: # Strong
            return random.uniform(0.8, 1.0)
        elif r < 0.4: # Medium
            return random.uniform(0.4, 0.7)
        else: # Weak
            return random.uniform(0.0, 0.3)


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards or other round-specific data if necessary
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up or log final results
        pass