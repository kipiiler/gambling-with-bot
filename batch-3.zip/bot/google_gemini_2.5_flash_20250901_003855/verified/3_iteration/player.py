from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.current_chips = 0
        self.big_blind_amount = 0
        self.is_big_blind = False
        self.is_small_blind = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.current_chips = starting_chips
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount * 2 # Assuming blind_amount is small blind
        self.is_big_blind = (self.id == big_blind_player_id)
        self.is_small_blind = (self.id == small_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        # In a real bot, you'd update specific hand info here
        # For this simple bot, we mostly rely on get_action's round_state

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.current_chips = remaining_chips
        my_current_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet_in_round
        
        # Determine current round
        poker_round_enum = None
        if round_state.round == 'Preflop':
            poker_round_enum = PokerRound.PREFLOP
        elif round_state.round == 'Flop':
            poker_round_enum = PokerRound.FLOP
        elif round_state.round == 'Turn':
            poker_round_enum = PokerRound.TURN
        elif round_state.round == 'River':
            poker_round_enum = PokerRound.RIVER

        # Simple Hand Strength Evaluation (Example: counting high cards, pairs)
        ranks = ['2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A']
        hole_ranks = [ranks.index(card[0]) for card in self.hole_cards]
        
        community_ranks = [ranks.index(card[0]) for card in round_state.community_cards]
        
        # Combine all visible cards for evaluation
        all_card_ranks = sorted(hole_ranks + community_ranks)

        num_players_active = len(round_state.current_player)

        # Basic Hand Strength Logic
        # Categorize hand strength, this is a very simplified example
        hand_strength = 0 # 0: weak, 1: medium, 2: strong

        # Check for pairs in hole cards
        if len(hole_ranks) == 2 and hole_ranks[0] == hole_ranks[1]:
            # Pocket pairs
            if hole_ranks[0] >= ranks.index('T'): # T, J, Q, K, A
                hand_strength = 2
            else:
                hand_strength = 1
        elif len(hole_ranks) == 2 and (hole_ranks[0] >= ranks.index('Q') or hole_ranks[1] >= ranks.index('Q')): # at least one high card
             hand_strength = max(hand_strength, 1)

        # Improve hand strength based on community cards
        if len(community_ranks) > 0:
            combined_cards_counts = {}
            for r in all_card_ranks:
                combined_cards_counts[r] = combined_cards_counts.get(r, 0) + 1

            for r, count in combined_cards_counts.items():
                if count >= 3: # Three of a kind or better
                    hand_strength = 2
                    break
                elif count == 2: # One pair
                    hand_strength = max(hand_strength, 1)
            
            # Very basic flush/straight draw check
            hole_suits = [card[1] for card in self.hole_cards]
            community_suits = [card[1] for card in round_state.community_cards]
            all_suits = hole_suits + community_suits
            
            suit_counts = {}
            for s in all_suits:
                suit_counts[s] = suit_counts.get(s, 0) + 1
            
            for s, count in suit_counts.items():
                if count >= 4: # Flush draw if pre-river, potential flush after river
                    hand_strength = max(hand_strength, 1) # Treat as medium strength to consider
                if count >= 5:
                    hand_strength = 2 # Strong flush

            # Very basic straight draw check
            unique_ranks_sorted = sorted(list(set(all_card_ranks)))
            if len(unique_ranks_sorted) >= 4:
                for i in range(len(unique_ranks_sorted) - 3):
                    if unique_ranks_sorted[i+3] - unique_ranks_sorted[i] <= 4:
                        hand_strength = max(hand_strength, 1) # Treat as medium strength to consider
                        break
            if len(unique_ranks_sorted) >= 5:
                for i in range(len(unique_ranks_sorted) - 4):
                    # Check for sequential ranks
                    is_straight = True
                    for j in range(4):
                        if unique_ranks_sorted[i+j+1] - unique_ranks_sorted[i+j] != 1:
                            is_straight = False
                            break
                    if is_straight:
                        hand_strength = 2 # Strong straight
                        break


        # Strategy based on hand strength and round
        current_pot = round_state.pot

        if amount_to_call >= remaining_chips: # Only can ALL_IN
            return PokerAction.ALL_IN, 0 # Go all-in
        
        if round_state.current_bet == 0: # Can check or bet
            if poker_round_enum == PokerRound.PREFLOP:
                if hand_strength == 2: # Strong hand
                    # Aggressive pre-flop with strong hands
                    if self.is_big_blind: # Already posted BB, can check if no raise
                        return PokerAction.CHECK, 0
                    else: # Open raise
                        raise_amount = max(self.big_blind_amount * 2, round_state.current_bet + round_state.min_raise)
                        return PokerAction.RAISE, min(round_state.max_raise, raise_amount)
                elif hand_strength == 1: # Medium hand
                    if self.is_big_blind:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CALL, 0 # Call the big blind
                else: # Weak hand
                    if self.is_big_blind:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.FOLD, 0 # Fold if not big blind
            else: # Post-flop, can check or bet
                if hand_strength == 2: # Strong hand, bet for value
                    bet_amount = int(current_pot * 0.75) # Bet 75% of pot
                    return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, bet_amount))
                elif hand_strength == 1: # Medium hand, check or small bet
                    return PokerAction.CHECK, 0
                else: # Weak hand, check
                    return PokerAction.CHECK, 0

        else: # Cannot check, must call, raise, or fold
            # Pot odds calculation (simplified)
            # Risk vs Reward
            # If current_bet is 100, pot is 200. You need to call 100 to win 200, so 2:1 odds
            # pot_odds = current_pot / (amount_to_call + 0.001) # Add small delta to prevent division by zero
            
            # Simple threshold for calling
            if amount_to_call > remaining_chips: # Cannot afford to call, implies All-in possibility
                return PokerAction.ALL_IN, 0 # Go all-in

            fold_threshold = self.big_blind_amount * 3 # Fold if call is too expensive
            
            if poker_round_enum == PokerRound.PREFLOP:
                if hand_strength == 2: # Strong hand
                    # Re-raise or call, depending on opponent action
                    # If current bet is significant, re-raise. Otherwise just call.
                    if amount_to_call < self.big_blind_amount * 2 and random.random() < 0.75: # Less aggressive re-raise
                        raise_amount = max(amount_to_call * 2, round_state.current_bet + round_state.min_raise)
                        return PokerAction.RAISE, min(round_state.max_raise, raise_amount)
                    return PokerAction.CALL, 0
                elif hand_strength == 1: # Medium hand
                    if amount_to_call <= fold_threshold:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Weak hand
                    return PokerAction.FOLD, 0

            elif poker_round_enum == PokerRound.FLOP:
                if hand_strength == 2: # Strong hand
                    # Value bet or raise
                    raise_amount = max(int(current_pot * 0.5), round_state.current_bet + round_state.min_raise)
                    return PokerAction.RAISE, min(round_state.max_raise, raise_amount)
                elif hand_strength == 1: # Medium hand
                    if amount_to_call <= current_pot * 0.2: # Call if not too expensive
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Weak hand
                    return PokerAction.FOLD, 0

            elif poker_round_enum == PokerRound.TURN:
                if hand_strength == 2: # Strong hand
                    raise_amount = max(int(current_pot * 0.75), round_state.current_bet + round_state.min_raise)
                    return PokerAction.RAISE, min(round_state.max_raise, raise_amount)
                elif hand_strength == 1:
                    if amount_to_call <= current_pot * 0.15:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

            elif poker_round_enum == PokerRound.RIVER:
                if hand_strength == 2: # Strong hand
                    raise_amount = max(int(current_pot * 0.75), round_state.current_bet + round_state.min_raise)
                    return PokerAction.RAISE, min(round_state.max_raise, raise_amount)
                elif hand_strength == 1:
                    if amount_to_call <= current_pot * 0.1:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Default fallback for any unhandled case (shouldn't happen with thorough logic)
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        # Reset hole cards for next round (though on_start will set them)
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

# Helper to rank cards for hand strength evaluation
# This is a very basic implementation, a real poker bot would use a robust hand evaluator
def get_card_rank(card_str: str) -> int:
    rank_char = card_str[0]
    if '2' <= rank_char <= '9':
        return int(rank_char)
    elif rank_char == 'T':
        return 10
    elif rank_char == 'J':
        return 11
    elif rank_char == 'Q':
        return 12
    elif rank_char == 'K':
        return 13
    elif rank_char == 'A':
        return 14
    return 0 # Should not happen

import random