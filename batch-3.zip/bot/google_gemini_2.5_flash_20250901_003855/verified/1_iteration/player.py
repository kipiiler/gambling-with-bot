from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        # player_hands will be ['??', '??'] as hole cards are not revealed at start
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # The hole cards are given to the bot at the start of each round, not on_start
        # Extract player_id from round_state.current_player if available to get our specific cards
        # However, the bot template doesn't explicitly pass hole cards this way.
        # Assuming we eventually get our hole cards through another mechanism or the bot is smart enough to know its cards
        # Based on typical competition setups, cards are either passed directly to get_action or a specific handler.
        # Since player_hands in on_start is ['??', '??'], we'll assume we get them when action is needed or via a dedicated method not shown here.
        # For this template, we'll assume self.hole_cards is set by the framework before get_action is called for this round.
        # This is a common point of confusion/assumption in these APIs, often a method like 'set_hole_cards' exists or get_action's state provides it.
        # Given the RoundStateClient definition, hole cards are not directly in it. So we rely on player_hands from 'on_start'
        # which needs to be clarified to contain *our* cards for the current hand.
        # Let's assume for now that 'player_hands' in 'on_start' actually means *this bot's* hole cards for the *first* hand.
        # And for subsequent hands, the framework internally updates self.hole_cards or it's passed differently.
        # Let's adjust based on the most common framework pattern: bot's own hole cards are implicitly managed or provided to get_action.
        # If on_start provides ['??', '??'], it means we don't know them yet.
        # Standard: hole cards are given at the start of *each* hand (round).
        # Since player_hands is a list and not tied to player ID in `on_start`, this is ambiguous.
        # Let's assume the framework somehow knows our hole cards and our bot needs to access them.
        # For simplicity, if current API doesn't provide it, we'll work with community cards only and make a weak assumption.
        # A more robust assumption: the framework implicitly makes 'self.hole_cards' available or passes them in `get_action`.
        # However, `get_action` only passes `round_state` and `remaining_chips`.
        # This means `on_round_start` is the best place to potentially receive `player_hands` for the current round.
        # Let's assume `player_hands` from `on_start` is dynamic and updated for each round.
        # The `on_start` method's `player_hands` parameter is misleading if it's not updated per round.
        # For a practical, functioning bot, we NEED our hole cards.
        # Let's add a `set_hole_cards` method or assume `on_round_start` gets them by extension.
        # Given the template, `on_start` is called *once* at game start. `on_round_start` is called *each round*.
        # The `player_hands` in `on_start` is likely for all players initially or just for the first hand.
        # Since `player_hands` is missing from `on_round_start` args, this is a major gap.
        # For now, I will add an instance variable and assume a separate internal mechanism sets `self.hole_cards` before `get_action`.
        # This is a common oversight in simplified competition APIs.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # This is where the core logic of your bot resides.
        # You need to decide what action to take based on the current round state.

        # Example implementation: A very simple, deterministic bot.
        # Always folds if the current bet is too high relative to remaining chips.
        # Otherwise, tries to call, check, or make a small raise.

        # How to get our initial hole cards? This is the most crucial part for poker logic.
        # The provided API doesn't seem to pass them explicitly in `get_action` or `on_round_start`.
        # Let's assume self.hole_cards is populated by the server infrastructure.
        # If not, this bot will only play based on community cards and guess.
        # For a functional bot, the hole cards *must* be known.
        # Given absence, this is a critical assumption. Let's explicitly define it:
        # Assuming the system provides self.hole_cards to the bot before this method call.
        # Example: self.hole_cards = ['Ad', 'Kd'] if you hold Ace-King suited diamonds.

        # --- Card Strength Calculation (Placeholder/Basic) ---
        # This part is highly simplified and needs robust poker hand evaluation.
        # For a full bot, you'd integrate a poker hand evaluator library or implement one.
        # 'Ah', 'Ks', '3d', '2c', '7h' -> ranks and suits
        # ranks = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        
        # This bot doesn't actually get its hole cards from the provided methods.
        # As a placeholder, we'll implement a very basic strategy based purely on current pot and bet,
        # making strong assumptions about the game state without knowing our hand.
        # This will make the bot play very passively or randomly without full info.

        # This is a significant limitation of the provided template: it doesn't show how the bot receives its hole cards per round.
        # For a contest bot, this would be clarified, or `player_hands` in `on_start` would be updated.
        # Given the template, I will make a bot that plays somewhat randomly or reacts to pot size,
        # as it cannot evaluate its hand properly without hole cards. This will not be a strong poker bot.

        # A very basic strategy without knowing hole cards:
        # 1. Be cautious if current_bet is high.
        # 2. Try to check if possible.
        # 3. Call if the cost is small relative to the pot.
        # 4. Potentially raise a small amount if acting first or pot is small.

        my_current_bet_in_round = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet_in_round
        
        # Determine if we can check
        can_check = amount_to_call == 0

        # Max acceptable call for our remaining chips
        # This simple bot will not call more than 20% of its remaining chips
        # unless it's a small blind relative bet or if it enables a check later.
        max_call_threshold = remaining_chips * 0.20
        
        # Aggression factor (higher means more likely to raise)
        aggression_factor = 0.05 # 5% chance to raise if possible and reasonable
        
        # Randomness for action selection
        r = random.random()

        # If current_bet is 0, we are first to act, or everyone has checked before us.
        if can_check:
            if r < aggression_factor * 2: # More likely to check or make a small raise if no bet
                if round_state.round == 'PREFLOP':
                    # In preflop, small raise if we're big blind or first to act after blinds
                    # This is highly speculative without knowing cards.
                    min_raise_amount = max(round_state.min_raise, self.blind_amount * 2) # Example small raise
                    if remaining_chips >= min_raise_amount:
                        return PokerAction.RAISE, min_raise_amount
                return PokerAction.CHECK, 0 # Default to check
            else:
                return PokerAction.CHECK, 0
        else: # Someone has bet, we need to call, raise, or fold.
            if amount_to_call >= remaining_chips: # If we can't afford to call (or can only go all-in)
                # If we must go all-in to call, only do so if the pot is very large or we are desperate
                # For this simple bot, we'll generally fold if it's effectively an all-in call
                # unless remaining chips is very low (e.g., less than blind_amount * 2) and pot is decent.
                # Or, if amount_to_call is close to 0 but not exactly 0 due to rounding or small chips.
                # Logic for all-in (often used to call small amounts we can't match precisely)
                if amount_to_call < self.blind_amount * 2 and remaining_chips > 0: # Small amount to call relative to blinds
                    return PokerAction.ALL_IN, 0 # Go all-in to call the small amount
                else:
                    return PokerAction.FOLD, 0 # Default to fold if forced all-in call
            
            if amount_to_call > max_call_threshold:
                # If the cost to call is too high, fold
                if r < 0.7: # High chance to fold if bet is too high for us without info
                    return PokerAction.FOLD, 0
                else: # Sometimes bluff/gamble and call anyway if feeling lucky or pot is big
                    return PokerAction.CALL, 0
            else:
                # Amount to call is within our threshold.
                aggressive_action_chance = 0.1 # 10% chance to raise, 90% chance to call
                if r < aggressive_action_chance and remaining_chips >= amount_to_call + round_state.min_raise :
                    # Try to raise
                    raise_amount = round_state.min_raise
                    current_raise_total = amount_to_call + raise_amount
                    
                    # Ensure raise is valid and doesn't exceed max_raise (effectively remaining_chips)
                    # The value returned is the TOTAL bet, so amount_to_call + raise_amount
                    # Or, better, just the additional amount you are raising on top of the call.
                    # The prompt states: "For RAISE: the amount raise combine with your current bet must be larger than the the current raise."
                    # This means we need to return the total amount we would put into the pot.
                    # So, if current_bet is 100, and our bet is 0, and we want to raise 100 on top of call, our total bet is 200.
                    # The `current_bet` in `RoundStateClient` is the amount needed to call *IF* you have no bet.
                    # If we have already put 'my_current_bet_in_round' chips, then amount_to_call is `current_bet - my_current_bet_in_round`.
                    # So, our new total bet would be `round_state.current_bet + raise_amount`
                    
                    # Correct raise calculation: new_total_bet should be >= current_bet + min_raise
                    # And <= my_current_bet_in_round + remaining_chips
                    # The value we return to `RAISE` action is the total amount (my_current_bet_in_round + actual_chips_to_add)
                    # It means, if `current_bet` is 100, and `min_raise` is 100, `total_bet` should be at least 200.
                    # Our current bet on table is `my_current_bet_in_round`.
                    # Chips already in pot for this round: `my_current_bet_in_round`.
                    # To meet `current_bet`: `amount_to_call`.
                    # New total on table: `round_state.current_bet` (to call) + `raise_amount`.
                    # Amount to put in: `round_state.current_bet + raise_amount - my_current_bet_in_round`.
                     
                    # A small raise: 2x current_bet is a common minimum raise in NLH (effectively 1x on top of call)
                    # The problem states: "minimum bet is 2x current call amount". This means the total bet must be 2x current_bet.
                    # If current_bet is 100, total bet must be >= 200.
                    # This implies if current_bet is 100, min_raise is also 100.
                    # round_state.min_raise correctly reflects the minimum amount *to raise on top of current_bet*.
                    # So the resulting bet (call + raise) should be `round_state.current_bet + round_state.min_raise`.
                    
                    raise_total_bet = round_state.current_bet + round_state.min_raise
                    
                    if raise_total_bet <= my_current_bet_in_round + remaining_chips:
                        return PokerAction.RAISE, raise_total_bet
                    else: # Can't afford to raise minimum, so just call or all-in to call
                        return PokerAction.CALL, 0 # Go with call if raise is not possible
                else:
                    # Default to call if not raising
                    return PokerAction.CALL, 0
        
        # Fallback in case none of the above conditions are met (should not happen with comprehensive logic)
        return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Reset any per-round state if necessary
        # For this simple bot, there's not much to reset besides what's managed internally
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        # Perform any cleanup or final reporting (not critical for bot functionality)
        pass