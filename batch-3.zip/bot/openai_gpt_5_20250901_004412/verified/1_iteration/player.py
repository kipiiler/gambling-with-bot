from typing import List, Tuple, Dict, Any, Optional
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


# ------------- Helpers for cards and evaluations ------------- #

RANK_ORDER = "23456789TJQKA"
RANK_TO_INT = {r: i for i, r in enumerate(RANK_ORDER, start=2)}  # 2..14
INT_TO_RANK = {v: k for k, v in RANK_TO_INT.items()}
SUITS = set(["h", "d", "c", "s"])


def parse_card(card: str) -> Tuple[int, str]:
    """Parse a card like 'Ah' into (rank_int, suit)."""
    try:
        if not card or len(card) < 2:
            return (0, "")
        rank = card[0].upper()
        suit = card[1].lower()
        return (RANK_TO_INT.get(rank, 0), suit if suit in SUITS else "")
    except Exception:
        # Fallback to avoid crashing
        return (0, "")


def chen_formula_score(c1: str, c2: str) -> float:
    """
    Approximate hand strength using Chen formula (simplified).
    Returns a score roughly between 0 and ~21. We'll map to 0..1 later.
    """
    # Rank base mapping
    base_map = {
        'A': 10.0, 'K': 8.0, 'Q': 7.0, 'J': 6.0, 'T': 5.0,
        '9': 4.5, '8': 4.0, '7': 3.5, '6': 3.0, '5': 2.5,
        '4': 2.0, '3': 1.5, '2': 1.0
    }

    if not c1 or not c2 or len(c1) < 2 or len(c2) < 2:
        return 0.0

    r1, s1 = c1[0].upper(), c1[1].lower()
    r2, s2 = c2[0].upper(), c2[1].lower()
    if r1 not in base_map or r2 not in base_map:
        return 0.0

    v1 = base_map[r1]
    v2 = base_map[r2]

    # Highest card base
    base = max(v1, v2)

    # Pair handling
    pair = (r1 == r2)

    score = base
    if pair:
        score = base * 2.0 + 1.0  # simplified Chen pair bonus

    # Suited bonus
    suited = (s1 == s2)
    if suited and not pair:
        score += 2.0

    # Gap penalties
    gap = abs(RANK_TO_INT[r1] - RANK_TO_INT[r2]) - 1
    if not pair:
        if gap <= 0:
            penalty = 0.0
        elif gap == 1:
            penalty = 1.0
        elif gap == 2:
            penalty = 2.0
        elif gap == 3:
            penalty = 4.0
        else:
            penalty = 5.0
        score -= penalty

        # Straight bonus for small connected hands
        high = max(RANK_TO_INT[r1], RANK_TO_INT[r2])
        if high < RANK_TO_INT['Q']:
            if gap == 0:
                score += 1.0
            elif gap == 1:
                score += 0.5
            elif gap == 2:
                score += 0.25

    # Clamp to min 0
    if score < 0:
        score = 0.0

    # Chen score maximum is about 21 for AA using our +1 pair rule
    return min(score, 21.0)


def chen_strength(c1: str, c2: str) -> float:
    """Return approximate preflop strength (0..1)."""
    score = chen_formula_score(c1, c2)
    # Normalize roughly by 21
    return max(0.0, min(score / 21.0, 1.0))


def get_to_call(round_state: RoundStateClient, my_id: Optional[int]) -> int:
    """Compute the amount we need to call on this action."""
    try:
        my_bet = 0
        if my_id is not None:
            my_bet = round_state.player_bets.get(str(my_id), 0) or 0
        current_bet = round_state.current_bet or 0
        to_call = max(0, current_bet - my_bet)
        return to_call
    except Exception:
        return 0


def count_suits(cards: List[str]) -> Dict[str, int]:
    d = {'h': 0, 'd': 0, 'c': 0, 's': 0}
    for c in cards:
        _, s = parse_card(c)
        if s in d:
            d[s] += 1
    return d


def ranks_counts(cards: List[str]) -> Dict[int, int]:
    cnt: Dict[int, int] = {}
    for c in cards:
        r, _ = parse_card(c)
        if r <= 0:
            continue
        cnt[r] = cnt.get(r, 0) + 1
    return cnt


def has_flush(cards: List[str]) -> Tuple[bool, str, List[int]]:
    """Return (has_flush, suit, ranks_sorted_desc)"""
    suit_counts = count_suits(cards)
    suit = max(suit_counts, key=lambda k: suit_counts[k])
    if suit_counts[suit] >= 5:
        ranks = [parse_card(c)[0] for c in cards if parse_card(c)[1] == suit]
        ranks.sort(reverse=True)
        return True, suit, ranks[:5]
    return False, "", []


def straight_high_rank(cards: List[str]) -> int:
    """Return high card rank of any straight (A can be low), else 0."""
    ranks_set = set()
    for c in cards:
        r, _ = parse_card(c)
        if r > 0:
            ranks_set.add(r)
    # Ace low
    if 14 in ranks_set:
        ranks_set.add(1)
    ranks_list = sorted(list(ranks_set))
    if not ranks_list:
        return 0
    # find any 5-consecutive sequence
    run = 1
    best_high = 0
    for i in range(1, len(ranks_list)):
        if ranks_list[i] == ranks_list[i - 1] + 1:
            run += 1
            if run >= 5:
                best_high = ranks_list[i]
        elif ranks_list[i] != ranks_list[i - 1]:
            run = 1
    return best_high


def has_straight(cards: List[str]) -> bool:
    return straight_high_rank(cards) > 0


def straight_draws(cards: List[str]) -> Tuple[bool, bool]:
    """
    Approximate OESD/gutshot existence from hole+board cards.
    Returns (has_oesd, has_gutshot)
    """
    ranks_set = set()
    for c in cards:
        r, _ = parse_card(c)
        if r > 0:
            ranks_set.add(r)
    # Ace low
    if 14 in ranks_set:
        ranks_set.add(1)
    rlist = sorted(ranks_set)
    if len(rlist) < 3:
        return False, False

    # Sliding windows to estimate draws
    has_oesd = False
    has_gut = False
    # Build all 4-length windows and check missing one to form length-5
    # We'll check differences pattern
    for start in range(min(rlist), max(rlist) - 2):
        seq = [start + i for i in range(4)]
        # Count how many from seq are in ranks_set
        present = sum(1 for x in seq if x in ranks_set)
        if present == 4:
            # This is already a 4-consecutive; if either end present -> OESD potential
            if (start - 1 in ranks_set) or (start + 4 in ranks_set):
                has_oesd = True
        elif present == 3:
            # 3 out of 4 suggests potential gutshot in a 5-card window
            has_gut = True
    return has_oesd, has_gut


def hand_category_strength(hole: List[str], board: List[str], street: str) -> Tuple[str, float, Dict[str, bool]]:
    """
    Heuristic hand strength categorization for postflop decisions.
    Returns (category_name, strength[0..1], details{draws})
    """
    cards = hole + board
    rc = ranks_counts(cards)
    board_rc = ranks_counts(board)
    hole_ranks = [parse_card(c)[0] for c in hole]
    board_ranks = [parse_card(c)[0] for c in board]
    hole_suits = [parse_card(c)[1] for c in hole]

    # Counts
    counts = sorted(rc.values(), reverse=True)
    board_counts = sorted(board_rc.values(), reverse=True)

    # Flush
    hasfl, flsuit, _ = has_flush(cards)
    board_hasfl, _, _ = has_flush(board)

    # Straight
    hasstr = has_straight(cards)
    board_hasstr = has_straight(board)

    # Pairs analysis
    my_pairs = sum(1 for r in hole_ranks if r in board_ranks)  # how many of my cards pair the board
    pair_in_hole = (hole_ranks[0] == hole_ranks[1])

    # Overpair check
    overpair = False
    if pair_in_hole and len(board_ranks) > 0:
        overpair = (hole_ranks[0] > max(board_ranks))

    # Top pair check
    top_pair = False
    second_pair = False
    if len(board_ranks) > 0:
        top_board = max(board_ranks)
        sorted_board = sorted(board_ranks, reverse=True)
        second_board = sorted_board[1] if len(sorted_board) > 1 else -1
        if hole_ranks[0] == top_board or hole_ranks[1] == top_board:
            top_pair = True
        if hole_ranks[0] == second_board or hole_ranks[1] == second_board:
            second_pair = True

    # Draws
    has_oesd, has_gut = straight_draws(cards)
    # Flush-draw (need at least 4 to a suit in hole+board and we hold that suit)
    suit_counts = count_suits(cards)
    fd = False
    for s in SUITS:
        if suit_counts[s] >= 4 and s in hole_suits:
            fd = True
            break

    # Category detection based on counts and patterns
    # Quads / Full House
    if 4 in counts:
        return ("quads", 0.99, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if 3 in counts and 2 in counts:
        return ("full_house", 0.95, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if hasfl and not board_hasfl:
        # Own flush that is not entirely on board
        # Roughly adjust based on whether we might have near-nut (having A/K in flush suit)
        strength = 0.86
        if 'A' in [hole[0][0].upper(), hole[1][0].upper()] or 'K' in [hole[0][0].upper(), hole[1][0].upper()]:
            strength = 0.9
        return ("flush", strength, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if hasstr and not board_hasstr:
        # Own straight not entirely on the board
        strength = 0.8
        return ("straight", strength, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if 3 in counts:
        # Trips or set
        strength = 0.72
        return ("trips", strength, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if (2 in counts and list(counts).count(2) >= 2):
        # Two pair (at least two distinct pairs)
        strength = 0.66
        return ("two_pair", strength, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if overpair:
        return ("overpair", 0.67, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if top_pair:
        # Kicker heuristic
        other = hole_ranks[0] if hole_ranks[1] in board_ranks else hole_ranks[1]
        if other >= RANK_TO_INT['A'] or other >= RANK_TO_INT['K']:
            return ("top_pair_top_kicker", 0.60, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
        else:
            return ("top_pair", 0.54, {"fd": fd, "oesd": has_oesd, "gut": has_gut})
    if second_pair:
        return ("second_pair", 0.44, {"fd": fd, "oesd": has_oesd, "gut": has_gut})

    # Draw-driven strength (only if not made-hand above)
    draws_boost = 0.0
    if street in ("Flop", "Turn"):
        if fd and has_oesd:
            draws_boost = 0.20
        elif fd:
            draws_boost = 0.15
        elif has_oesd:
            draws_boost = 0.12
        elif has_gut:
            draws_boost = 0.06

    # High card baseline depends a bit on hole ranks
    high = max(hole_ranks)
    if high >= RANK_TO_INT['A']:
        base = 0.28
    elif high >= RANK_TO_INT['K']:
        base = 0.25
    elif high >= RANK_TO_INT['Q']:
        base = 0.22
    else:
        base = 0.20

    strength = min(0.65, base + draws_boost)  # Cap for draw-only situations
    category = "draws" if draws_boost > 0 else "high_card"
    return (category, strength, {"fd": fd, "oesd": has_oesd, "gut": has_gut})


def clamp_raise(amount: int, min_raise: int, max_raise: int) -> Optional[int]:
    """
    Clamp raise amount to valid bounds. Return None if not possible.
    """
    if max_raise is None or min_raise is None:
        return None
    if max_raise <= 0:
        return None
    if min_raise <= 0:
        # Some engines may report 0; in that case set minimal to 1
        min_raise = 1
    if min_raise > max_raise:
        return None
    amount = int(amount)
    if amount < min_raise:
        amount = min_raise
    if amount > max_raise:
        amount = max_raise
    return amount


def choose_bet_amount_by_pot_fraction(pot: int, fraction: float, min_raise: int, max_raise: int) -> Optional[int]:
    """
    Decide a raise/bet amount based on a fraction of pot.
    """
    try:
        pot = int(pot or 0)
        frac_amt = int(max(1, round(pot * max(0.0, min(1.5, fraction)))))
        return clamp_raise(frac_amt, int(min_raise or 0), int(max_raise or 0))
    except Exception:
        return None


# ------------- The Player Bot ------------- #

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        # Hand state
        self.hole_cards: List[str] = []
        self.round_num: int = 0
        # Aggression memory
        self.was_preflop_raiser: bool = False
        self.was_last_street_aggressor: bool = False
        # Randomness for mixed strategies
        self.rng = random.Random(1337)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize for a new hand (assumption: this is called each new hand)
        try:
            self.starting_chips = starting_chips
            self.hole_cards = list(player_hands) if player_hands else []
            self.blind_amount = blind_amount
            self.big_blind_player_id = big_blind_player_id
            self.small_blind_player_id = small_blind_player_id
            self.all_players = list(all_players) if all_players else []
            self.was_preflop_raiser = False
            self.was_last_street_aggressor = False
        except Exception:
            # Fallback to keep running
            self.hole_cards = list(player_hands) if player_hands else []
            self.was_preflop_raiser = False
            self.was_last_street_aggressor = False

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset street aggressor at beginning of a betting round (Preflop/Flop/Turn/River)
        try:
            self.round_num = round_state.round_num
            # Reset street aggressor flag for new betting street
            self.was_last_street_aggressor = False
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            street = (round_state.round or "").capitalize()
            board = list(round_state.community_cards or [])
            pot = int(round_state.pot or 0)
            to_call = get_to_call(round_state, self.id)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)

            # Number of active players heuristic
            active_players = set()
            try:
                # Priority to current_player if provided
                if round_state.current_player:
                    for pid in round_state.current_player:
                        active_players.add(pid)
                # Add anyone who has a bet and hasn't folded
                for pid_str, act in (round_state.player_actions or {}).items():
                    if act != "Fold":
                        try:
                            active_players.add(int(pid_str))
                        except Exception:
                            pass
                if not active_players and round_state.player_bets:
                    for pid_str in round_state.player_bets.keys():
                        try:
                            active_players.add(int(pid_str))
                        except Exception:
                            pass
            except Exception:
                pass
            n_active = max(2, len(active_players)) if active_players else max(2, len(self.all_players)) if self.all_players else 2

            # Preflop strategy
            if street == "Preflop":
                return self._action_preflop(round_state, pot, to_call, min_raise, max_raise, remaining_chips, n_active)

            # Postflop strategy
            return self._action_postflop(round_state, pot, to_call, min_raise, max_raise, remaining_chips, n_active)

        except Exception:
            # Safe fallback
            # If we can check, do so; otherwise fold to avoid invalid action
            try:
                to_call = get_to_call(round_state, self.id)
                if to_call <= 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except Exception:
                return (PokerAction.FOLD, 0)

    def _action_preflop(self, round_state: RoundStateClient, pot: int, to_call: int,
                         min_raise: int, max_raise: int, remaining_chips: int, n_active: int) -> Tuple[PokerAction, int]:
        # Preflop strength using Chen
        c1, c2 = (self.hole_cards[0] if len(self.hole_cards) > 0 else ""), (self.hole_cards[1] if len(self.hole_cards) > 1 else "")
        strength = chen_strength(c1, c2)

        # Basic thresholds (tighter when more players)
        # Heads-up looser; multiway tighter
        base_open = 0.46 if n_active <= 3 else 0.52
        base_call = 0.50 if n_active <= 3 else 0.58
        base_3bet = 0.70 if n_active <= 3 else 0.75
        shove_thresh = 0.88  # AA/KK/AKs etc

        # If we can check (as BB with no raise), either check or make a raise with top range
        if to_call <= 0:
            # Open-raise logic when first to act or BB facing no raise
            if strength >= base_open:
                # Desired open sizing ~ 2.5-3x BB; fallback to pot fraction if blinds unknown
                desired = int(max(self.blind_amount * 2.5, pot * 0.6, min_raise))
                amt = clamp_raise(desired, min_raise, max_raise)
                if amt is not None and amt > 0:
                    self.was_preflop_raiser = True
                    self.was_last_street_aggressor = True
                    return (PokerAction.RAISE, amt)
            # Otherwise take a free check
            return (PokerAction.CHECK, 0)

        # Facing a bet/raise
        # If extremely strong and stacks small relative to pot, consider all-in
        if strength >= shove_thresh and max_raise > 0:
            # All-in with top 2%/5% hands
            return (PokerAction.ALL_IN, 0)

        # Compute equity-needed threshold using simple pot odds
        equity_needed = to_call / max(1.0, (pot + to_call))
        # Our "estimated equity" is proxied by strength preflop (not exact)
        # Add small gap for multiway (tighten)
        equity_pad = 0.06 if n_active >= 4 else 0.03
        if strength + 1e-9 >= equity_needed + equity_pad:
            # Call at minimum; sometimes 3-bet with stronger hands
            if strength >= base_3bet and min_raise < max_raise and max_raise > 0:
                # 3-bet sizing ~ 3x the to_call or ~pot-sizish
                desired = max(int(to_call * 3), int(pot * 0.75), min_raise)
                amt = clamp_raise(desired, min_raise, max_raise)
                if amt is not None and amt > 0:
                    self.was_preflop_raiser = True
                    self.was_last_street_aggressor = True
                    return (PokerAction.RAISE, amt)
            # Otherwise call
            return (PokerAction.CALL, 0)

        # Not enough equity: fold
        return (PokerAction.FOLD, 0)

    def _action_postflop(self, round_state: RoundStateClient, pot: int, to_call: int,
                         min_raise: int, max_raise: int, remaining_chips: int, n_active: int) -> Tuple[PokerAction, int]:
        street = (round_state.round or "").capitalize()
        board = list(round_state.community_cards or [])
        # Evaluate our hand heuristic
        category, strength, flags = hand_category_strength(self.hole_cards, board, street)
        fd = flags.get("fd", False)
        oesd = flags.get("oesd", False)
        gut = flags.get("gut", False)

        # Build some aggression logic
        # If we can check (no bet to us)
        if to_call <= 0:
            # Value betting
            if strength >= 0.62:
                # Strong made hand -> bet 60-80% pot
                fraction = 0.7 + (0.1 * self.rng.random())
                amt = choose_bet_amount_by_pot_fraction(pot, fraction, min_raise, max_raise)
                if amt is not None and amt > 0:
                    self.was_last_street_aggressor = True
                    return (PokerAction.RAISE, amt)
                else:
                    return (PokerAction.CHECK, 0)

            # Semi-bluff with decent draws on flop/turn
            if street in ("Flop", "Turn") and (fd or oesd or (gut and self.rng.random() < 0.4)):
                fraction = 0.5 + (0.15 * self.rng.random())  # 50-65%
                amt = choose_bet_amount_by_pot_fraction(pot, fraction, min_raise, max_raise)
                if amt is not None and amt > 0:
                    self.was_last_street_aggressor = True
                    return (PokerAction.RAISE, amt)

            # Occasional continuation-bet when we were aggressor preflop and heads-up/multiway small
            if street == "Flop" and self.was_preflop_raiser and n_active <= 3 and self.rng.random() < 0.35:
                if strength >= 0.35:
                    fraction = 0.4 + (0.15 * self.rng.random())
                    amt = choose_bet_amount_by_pot_fraction(pot, fraction, min_raise, max_raise)
                    if amt is not None and amt > 0:
                        self.was_last_street_aggressor = True
                        return (PokerAction.RAISE, amt)

            # Default: check
            return (PokerAction.CHECK, 0)

        # We face a bet
        # Consider all-in with very strong hands or low SPR
        if strength >= 0.88 and max_raise > 0:
            return (PokerAction.ALL_IN, 0)

        # Pot odds; if our strength approximates equity we can call
        equity_needed = to_call / max(1.0, (pot + to_call))
        # Multiway tighten a bit
        equity_pad = 0.04 if n_active >= 4 else 0.02

        # Prefer raising with strong value hands
        if strength >= (equity_needed + equity_pad + 0.12) and min_raise < max_raise and max_raise > 0:
            # Value raise sizing: around 2.5x to_call or ~60-80% pot
            desired = max(int(to_call * 2.5), int(pot * 0.7), min_raise)
            amt = clamp_raise(desired, min_raise, max_raise)
            if amt is not None and amt > 0:
                self.was_last_street_aggressor = True
                return (PokerAction.RAISE, amt)

        # With draws on flop/turn, call if priced in
        if street in ("Flop", "Turn"):
            draw_equity = 0.0
            # Rough draw equity estimates
            if fd and oesd:
                draw_equity = 0.36  # combo draws
            elif fd:
                draw_equity = 0.18
            elif oesd:
                draw_equity = 0.16
            elif gut:
                draw_equity = 0.08

            # If draw equity supports a call (plus small margin)
            if draw_equity > 0 and draw_equity >= equity_needed - 0.01:
                return (PokerAction.CALL, 0)

        # If made hand above mid strength, call
        if strength >= (equity_needed + equity_pad):
            return (PokerAction.CALL, 0)

        # Otherwise fold
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the hand (round of play). Reset per-hand state that shouldn't carry over. """
        try:
            # Prepare for the next hand
            self.hole_cards = []
            self.was_preflop_raiser = False
            self.was_last_street_aggressor = False
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent storage needed; could be used for logging or adaptive tuning
        # Keep it minimal to avoid exceptions and memory bloat
        return