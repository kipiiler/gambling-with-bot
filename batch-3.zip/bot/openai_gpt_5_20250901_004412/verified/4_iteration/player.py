from typing import List, Tuple, Dict, Any
import time
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Strategy/state variables
        self.starting_chips = 0
        self.bb_guess = 10  # default guess for big blind
        self.sb_guess = 5
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.players: List[int] = []
        self.rng = random.Random(int(time.time() * 1000) % 2**32)
        self.round_num = 0
        self.aggression_factor = 0.65  # base aggressiveness for betting when checked to
        self.open_raise_freq = 0.8  # frequency of open-raising when unopened
        self.defend_freq_small = 0.6  # calling frequency vs minbet
        self.defend_freq_large = 0.2  # calling frequency vs big bet
        self.threebet_freq_small = 0.12  # small frequency to 3-bet vs small open
        self.continuation_bet_fraction = 0.55  # bet size as a fraction of pot when betting
        self.postflop_aggression = 0.6  # frequency to stab postflop when checked to

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ):
        self.starting_chips = starting_chips
        # blind_amount is documented as blind amount. Interpret as big blind if >= 2.
        self.bb_guess = max(2, int(blind_amount))
        self.sb_guess = max(1, self.bb_guess // 2)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = list(all_players) if all_players else []
        # Seed RNG with player id for consistency (fallback to time if id not set yet)
        seed_val = self.id if self.id is not None else int(time.time() * 1000) % 2**32
        self.rng.seed(seed_val)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Try to refine blind guesses from preflop posted blinds if identifiable
        try:
            if round_state.round.lower() == 'preflop':
                bets = [v for v in (round_state.player_bets or {}).values() if v and v > 0]
                if bets:
                    # During initial preflop, two blinds are posted: min is SB, max is BB
                    min_bet = min(bets)
                    max_bet = max(bets)
                    # Heuristic: if spread isn't huge (i.e., no large raises yet), treat as blinds
                    if max_bet <= 5 * self.bb_guess:
                        self.sb_guess = max(1, min_bet)
                        self.bb_guess = max(2, max_bet)
        except Exception:
            # Do not let any exception propagate; keep previous guesses
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Safety defaults
        try:
            my_id_str = str(self.id) if self.id is not None else ""
            player_bets: Dict[str, int] = round_state.player_bets or {}
            self_bet = int(player_bets.get(my_id_str, 0))
            current_bet = int(round_state.current_bet or 0)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or remaining_chips or 0)
            pot = int(round_state.pot or 0)
            street = (round_state.round or '').lower()

            to_call = max(0, current_bet - self_bet)
            can_check = (to_call == 0)
            # Protect against division by zero
            eps = 1e-9

            # Helper functions
            def clamp(x: int, lo: int, hi: int) -> int:
                return max(lo, min(hi, x))

            def valid_raise_amount(amount: int) -> bool:
                # amount is the additional chips we put in this action
                # For a raise, we need our new total contribution > current_bet
                # and raise increment >= min_raise (if min_raise > 0).
                if amount <= 0:
                    return False
                # If we cannot cover the minimum raise due to stack, raising is invalid in this environment.
                if amount > max_raise:
                    return False
                new_total = self_bet + amount
                if new_total <= current_bet:
                    return False
                # If there is an existing bet, ensure raise size meets min_raise
                if current_bet > 0 and min_raise > 0:
                    required_increment = (new_total - current_bet)
                    if required_increment < min_raise:
                        return False
                # If no current bet (betting), ensure at least min_raise if provided
                if current_bet == 0 and min_raise > 0:
                    if (new_total - current_bet) < min_raise:
                        return False
                return True

            def raise_to_total(target_total_bet: int) -> Tuple[bool, int]:
                # Compute raise "amount" (additional chips to put in now)
                # amount = to_call + (target_total_bet - current_bet)
                inc = max(0, target_total_bet - current_bet)
                amount = to_call + inc
                if valid_raise_amount(amount):
                    return True, amount
                # Try to adjust to minimum valid raise if target too small
                min_target_total = current_bet + max(min_raise, 1)
                amount_min = to_call + (min_target_total - current_bet)
                if valid_raise_amount(amount_min):
                    return True, amount_min
                # If we cannot make a valid raise but can call, fall back to call
                if to_call > 0 and to_call <= max_raise:
                    return False, 0
                # If we can check, just check
                if to_call == 0:
                    return False, 0
                # Otherwise, if short, all-in if possible; else fold
                return False, -1  # signal to consider all-in/fold

            def bet_pot_fraction(frac: float) -> Tuple[bool, int]:
                # When there is no bet (can_check), we "bet" by raising to some size
                # Use pot as reference; if pot is 0 (e.g., preflop unopened), use 2.5bb heuristic
                if current_bet == 0:
                    if pot <= 0:
                        target = int(round(self.bb_guess * 2.5))
                    else:
                        target = int(max(min_raise, round(pot * frac)))
                    target = max(target, min_raise if min_raise > 0 else 1)
                    # target here is the new "current_bet" total; our new total contribution should be target
                    target_total_bet = target  # since current_bet == 0
                else:
                    # If there's an existing bet, betting pot fraction implies raising to current_bet + X
                    # We'll choose raise increment as a fraction of pot
                    inc = int(max(min_raise, round(pot * frac)))
                    target_total_bet = current_bet + inc
                return raise_to_total(target_total_bet)

            # Decide action by street
            if street == 'preflop':
                # Preflop strategy: raise first-in frequently; defend vs raises with thresholds
                if can_check:
                    # Likely BB facing check option (no raise). Mix between raise and check.
                    if self.rng.random() < self.open_raise_freq:
                        # Open raise size ~ 2.5bb
                        target_total = max(current_bet + max(min_raise, 1), int(round(self.bb_guess * 2.5)))
                        ok, amount = raise_to_total(target_total)
                        if ok:
                            return PokerAction.RAISE, amount
                        # Fallback to check if raise invalid
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Facing a raise
                    bb = max(2, self.bb_guess)
                    if to_call <= bb:
                        r = self.rng.random()
                        if r < self.defend_freq_small:
                            return PokerAction.CALL, 0
                        elif r < self.defend_freq_small + self.threebet_freq_small:
                            # 3-bet to ~3.5bb if possible
                            target_total = int(round(3.5 * bb))
                            ok, amount = raise_to_total(target_total)
                            if ok:
                                return PokerAction.RAISE, amount
                            # If we cannot raise, call if affordable, otherwise all-in if needed
                            if to_call <= max_raise:
                                return PokerAction.CALL, 0
                            else:
                                return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.FOLD, 0
                    elif to_call <= 3 * bb:
                        # Medium raise: tighter defend
                        r = self.rng.random()
                        if r < 0.30:
                            return PokerAction.CALL, 0
                        elif r < 0.40:
                            # Occasional 3-bet bluff to ~4.5-5bb
                            target_total = int(round(4.5 * bb))
                            ok, amount = raise_to_total(target_total)
                            if ok:
                                return PokerAction.RAISE, amount
                            if to_call <= max_raise:
                                return PokerAction.CALL, 0
                            return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.FOLD, 0
                    else:
                        # Large raise size, mostly fold unless short or priced in
                        # Pot odds check
                        pot_after_call = pot + to_call
                        call_ratio = to_call / (pot_after_call + eps)
                        if call_ratio <= 0.18 and to_call <= max_raise and self.rng.random() < 0.25:
                            return PokerAction.CALL, 0
                        # If too short to do anything else, and call not possible, shove
                        if to_call > max_raise and max_raise > 0 and self.rng.random() < 0.25:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0

            else:
                # Postflop streets: adopt a simple c-bet / stab strategy and pot-odds based calls
                if can_check:
                    # Consider a stab bet with some frequency
                    if self.rng.random() < self.postflop_aggression:
                        ok, amount = bet_pot_fraction(self.continuation_bet_fraction)
                        if ok and amount > 0:
                            return PokerAction.RAISE, amount
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Facing a bet: decide based on pot odds and bet size
                    pot_after_call = pot + to_call
                    call_ratio = to_call / (pot_after_call + eps)
                    # Small bets -> call or raise sometimes; large bets -> mostly fold
                    if call_ratio <= 0.22:
                        r = self.rng.random()
                        if r < 0.70:
                            return PokerAction.CALL, 0
                        elif r < 0.82:
                            # Semi-bluff raise to ~0.6 pot
                            ok, amount = bet_pot_fraction(0.6)
                            if ok and amount > 0:
                                return PokerAction.RAISE, amount
                            # if invalid, fall back to call if possible
                            if to_call <= max_raise:
                                return PokerAction.CALL, 0
                            return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.FOLD, 0
                    elif call_ratio <= 0.35:
                        # Medium sized bet: call sometimes, fold more
                        if self.rng.random() < 0.45 and to_call <= max_raise:
                            return PokerAction.CALL, 0
                        return PokerAction.FOLD, 0
                    else:
                        # Big bet: mostly fold; occasionally shove if very short and priced in
                        if to_call <= max_raise and self.rng.random() < 0.10:
                            return PokerAction.CALL, 0
                        if to_call > max_raise and max_raise > 0 and self.rng.random() < 0.10:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.FOLD, 0

        except Exception:
            # Any unexpected error: choose the safest legal action
            # If we can check, check; else fold
            try:
                my_id_str = str(self.id) if self.id is not None else ""
                player_bets = round_state.player_bets or {}
                self_bet = int(player_bets.get(my_id_str, 0))
                current_bet = int(round_state.current_bet or 0)
                to_call = max(0, current_bet - self_bet)
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0
            except Exception:
                # Ultimate fallback
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # We could adapt parameters slightly based on results to add mild learning
        try:
            # If we are losing chips steadily, slightly increase aggression to steal more
            delta = remaining_chips - self.starting_chips
            if delta < 0:
                self.open_raise_freq = clamp_float(self.open_raise_freq + 0.01, 0.5, 0.9)
                self.postflop_aggression = clamp_float(self.postflop_aggression + 0.01, 0.45, 0.85)
            else:
                self.open_raise_freq = clamp_float(self.open_raise_freq - 0.005, 0.5, 0.9)
                self.postflop_aggression = clamp_float(self.postflop_aggression - 0.005, 0.45, 0.85)
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset or adjust long-term tendencies slightly
        try:
            # If we did poorly overall, bump preflop defend a bit
            if player_score < 0:
                self.defend_freq_small = clamp_float(self.defend_freq_small + 0.02, 0.4, 0.8)
                self.aggression_factor = clamp_float(self.aggression_factor + 0.02, 0.4, 0.85)
            else:
                self.defend_freq_small = clamp_float(self.defend_freq_small - 0.01, 0.4, 0.8)
                self.aggression_factor = clamp_float(self.aggression_factor - 0.01, 0.4, 0.85)
        except Exception:
            pass


def clamp_float(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x