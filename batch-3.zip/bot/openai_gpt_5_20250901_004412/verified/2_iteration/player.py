from typing import List, Tuple, Dict, Any, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session level
        self.starting_chips: int = 0
        self.initial_blind_amount: int = 0
        self.players: List[int] = []
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None

        # Hand/round level
        self.round_num: int = -1
        self.current_street: str = ""
        self.hole_cards: List[str] = []  # not guaranteed to be provided, keep for compatibility
        self.last_player_bets_snapshot: Dict[str, int] = {}

        # RNG for mixed strategy
        self.rng = random.Random(1337)

        # Simple stats
        self.hands_played: int = 0
        self.total_profit: int = 0

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        # Initialize game/session info
        self.starting_chips = starting_chips
        self.initial_blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players[:] if all_players is not None else []

        # If hole cards are ever provided here by the engine, store them, otherwise ignore.
        self.hole_cards = player_hands[:] if player_hands else []

        # Reset round-level caches
        self.round_num = -1
        self.current_street = ""
        self.last_player_bets_snapshot = {}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand/round variables when round number changes
        if self.round_num != round_state.round_num:
            self.round_num = round_state.round_num
            self.hands_played += 1
            self.hole_cards = []  # usually engine would set hole cards elsewhere; keep empty if unknown
            self.last_player_bets_snapshot = {}

        self.current_street = round_state.round
        self.last_player_bets_snapshot = dict(round_state.player_bets) if round_state.player_bets else {}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player. Must always be valid per the provided RoundStateClient.
        This strategy is a mixed, position-agnostic baseline with safe bounds checking on all actions.
        """
        try:
            my_id_str = str(self.id)
            player_bets = round_state.player_bets or {}
            my_bet = max(0, int(player_bets.get(my_id_str, 0)))
            current_bet = max(0, int(round_state.current_bet))
            min_raise = max(0, int(round_state.min_raise))
            max_raise = max(0, int(round_state.max_raise))
            pot = max(0, int(round_state.pot))
            to_call = max(0, current_bet - my_bet)

            # Simple helper lambdas
            def can_check() -> bool:
                return to_call <= 0

            def can_call() -> bool:
                return to_call > 0 and remaining_chips >= to_call

            def can_raise() -> bool:
                return min_raise <= max_raise and remaining_chips > 0

            def choose_safe_raise_amount() -> int:
                """
                Compute a raise amount that should be valid given only min_raise, max_raise, and current_bet.
                Use conservative approach: raise to (current_bet + min_raise) or min_raise if current_bet == 0.
                Always clamp into [min_raise, max_raise].
                """
                if current_bet <= 0:
                    target = max(min_raise, min(max_raise, min_raise))
                else:
                    # Raise "to" current_bet + min_raise (conservative minimal valid raise in most engines)
                    target = current_bet + min_raise
                    if target < min_raise:
                        target = min_raise
                    if target > max_raise:
                        target = max_raise
                if target < min_raise or target > max_raise:
                    # Fallback: try min_raise or max_raise
                    target = max(min_raise, min(max_raise, min_raise))
                return max(min_raise, min(max_raise, target))

            # Estimate big blind for rough sizing logic (not required for validity)
            def estimate_bb() -> int:
                if self.initial_blind_amount > 0:
                    return int(self.initial_blind_amount)
                # Try deducing from preflop blinds
                bets = [v for v in (player_bets or {}).values() if v > 0]
                if len(bets) >= 2 and round_state.round.lower() == "preflop":
                    bets_sorted = sorted(bets)
                    return max(1, int(bets_sorted[-1]))
                # Fallback to min_raise (typical engines set min_raise to BB when current_bet==0)
                return max(1, min_raise if current_bet == 0 else min_raise)

            # Robustness: if we have no chips left
            if remaining_chips <= 0:
                if can_check():
                    return (PokerAction.CHECK, 0)
                else:
                    # Can't pay; fold to any bet (engine might handle auto-all-in/call, but be explicit)
                    return (PokerAction.FOLD, 0)

            street = (round_state.round or "").lower()
            num_players = max(2, len(player_bets) if player_bets else 2)
            bb = estimate_bb()

            # Mixed strategy parameters
            # Frequencies tuned cautiously for heads-up; multiway becomes tighter
            heads_up = num_players <= 2
            rnd = self.rng.random()

            # Preflop strategy (card-agnostic mixed)
            if street == "preflop":
                # If we can check (we're BB and SB limped to BB), consider an iso-raise
                if can_check():
                    # Iso-raise some of the time; otherwise check
                    iso_freq = 0.40 if heads_up else 0.20
                    if can_raise() and rnd < iso_freq:
                        amt = choose_safe_raise_amount()
                        if amt >= min_raise and amt <= max_raise:
                            return (PokerAction.RAISE, amt)
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet/raise preflop
                    call_pressure_bb = to_call / (bb + 1e-9)

                    # Aggression profile changes with size of the raise to call
                    if call_pressure_bb <= 1.0:
                        # Small raise to call: defend often
                        if can_call() and rnd < (0.70 if heads_up else 0.55):
                            return (PokerAction.CALL, 0)
                        elif can_raise() and rnd < (0.80 if heads_up else 0.60):
                            amt = choose_safe_raise_amount()
                            return (PokerAction.RAISE, amt)
                        else:
                            # If can't call (short) but can all-in and it's small, jam sometimes
                            if to_call >= remaining_chips and rnd < 0.25:
                                return (PokerAction.ALL_IN, 0)
                            return (PokerAction.FOLD, 0)
                    elif call_pressure_bb <= 3.0:
                        # Medium raise size: mix between call and fold, occasionally 3-bet
                        if can_call() and rnd < (0.50 if heads_up else 0.35):
                            return (PokerAction.CALL, 0)
                        elif can_raise() and rnd < (0.60 if heads_up else 0.40):
                            amt = choose_safe_raise_amount()
                            return (PokerAction.RAISE, amt)
                        else:
                            # If short-stacked vs medium raise, jam rarely
                            if to_call >= remaining_chips and rnd < 0.15:
                                return (PokerAction.ALL_IN, 0)
                            return (PokerAction.FOLD, 0)
                    else:
                        # Large raise: mostly fold, occasionally call if deep, very rare jam
                        if can_call() and rnd < 0.15:
                            return (PokerAction.CALL, 0)
                        elif to_call >= remaining_chips and rnd < 0.10:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)

            # Postflop strategy
            else:
                # If we can check, consider betting as a bluff/value mix at some frequency depending on street
                if can_check():
                    bet_freq = 0.60 if street == "flop" else (0.50 if street == "turn" else 0.40)
                    if can_raise() and rnd < bet_freq:
                        amt = choose_safe_raise_amount()
                        if amt >= min_raise and amt <= max_raise:
                            return (PokerAction.RAISE, amt)
                        # If we cannot form a valid raise, fallback to check
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet: decide using pot odds thresholds
                    # pot odds = to_call / (pot + to_call)
                    denom = pot + to_call + 1e-9
                    pot_odds = to_call / denom

                    # Thresholds reflect tendency to continue more on flop, less on river
                    if street == "flop":
                        call_threshold = 0.42
                        raise_freq_small_bet = 0.12
                    elif street == "turn":
                        call_threshold = 0.36
                        raise_freq_small_bet = 0.10
                    else:  # river
                        call_threshold = 0.30
                        raise_freq_small_bet = 0.08

                    # If the bet is very small relative to pot, call more, sometimes raise
                    bet_small = (to_call / (pot + 1e-9)) <= 0.33

                    # If we are very short and can't call, decide between jam/fold
                    if to_call > remaining_chips:
                        # If pot odds are decent and we're forced, jam some fraction of the time
                        if pot_odds <= (call_threshold + 0.05) and rnd < 0.60:
                            return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)

                    # Otherwise we can call; choose between call/raise/fold
                    if pot_odds <= call_threshold:
                        # Favor calling
                        if rnd < 0.85:
                            return (PokerAction.CALL, 0)
                        # Occasionally raise if bet is small
                        if bet_small and can_raise() and rnd < (0.85 + raise_freq_small_bet):
                            amt = choose_safe_raise_amount()
                            return (PokerAction.RAISE, amt)
                        return (PokerAction.CALL, 0)
                    else:
                        # Pot odds not great: mostly fold, sometimes bluff-raise very small bet
                        if bet_small and can_raise() and rnd < raise_freq_small_bet:
                            amt = choose_safe_raise_amount()
                            return (PokerAction.RAISE, amt)
                        # Occasionally peel
                        if rnd < 0.15:
                            if can_call():
                                return (PokerAction.CALL, 0)
                            elif to_call >= remaining_chips:
                                return (PokerAction.ALL_IN, 0)
                        return (PokerAction.FOLD, 0)

        except Exception:
            # Any unexpected error -> return a safe action to avoid auto-fold penalties
            # If it's free to check, do so; else fold
            try:
                my_bet = int(round_state.player_bets.get(str(self.id), 0))
                current_bet = int(round_state.current_bet)
                if current_bet - my_bet <= 0:
                    return (PokerAction.CHECK, 0)
            except Exception:
                pass
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Track profit simple metric: remaining_chips - starting_chips is not accurate per-hand,
        # but we keep cumulative for rough tracking; this does not affect decisions.
        if self.starting_chips > 0:
            self.total_profit = remaining_chips - self.starting_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset or adjust RNG seed between games to avoid being too predictable across matches
        # Use cumulative info to vary slightly
        seed_adjust = int(abs(self.total_profit)) + self.hands_played + (self.id or 0)
        self.rng.seed(1337 + seed_adjust)
        # No I/O or prints to keep it silent
        pass