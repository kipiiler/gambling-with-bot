from typing import List, Tuple, Dict
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "AKQJT98765432"
RANK_TO_VAL = {r: 14 - i if r != 'T' else 10 for i, r in enumerate("AKQJT98765432")}
RANK_TO_VAL.update({
    'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10,
    '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2
})


def card_rank(card: str) -> str:
    # card like 'Ah', 'Ks', '3d'
    return card[0].upper()


def card_suit(card: str) -> str:
    return card[1].lower()


def sorted_rank_chars(c1: str, c2: str) -> Tuple[str, str]:
    r1, r2 = card_rank(c1), card_rank(c2)
    # sort by rank order defined above (A high)
    idx1 = RANK_ORDER.index(r1)
    idx2 = RANK_ORDER.index(r2)
    if idx1 <= idx2:
        return r1, r2
    else:
        return r2, r1


def make_hand_label(c1: str, c2: str) -> str:
    r1, r2 = sorted_rank_chars(c1, c2)
    suited = card_suit(c1) == card_suit(c2)
    if r1 == r2:
        return f"{r1}{r2}"
    else:
        return f"{r1}{r2}{'s' if suited else 'o'}"


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.players: List[int] = []
        self.hole_cards: List[str] = []
        self.rng = random.Random(1337)
        self.last_round_num = -1
        self.position_history: Dict[int, str] = {}  # round_num -> position string
        self.debug = False  # set True to enable internal prints (should remain False in competition)

        # Preflop ranges (simple, conservative)
        self.premium_pairs = {"AA", "KK", "QQ", "JJ", "TT"}
        self.strong_pairs = {"99", "88", "77"}
        self.medium_pairs = {"66", "55", "44", "33", "22"}

        self.premium_others = {"AKs", "AQs", "AJs", "KQs", "AKo"}
        self.strong_others = {
            "AQo", "ATs", "KJs", "QJs", "JTs", "T9s", "98s", "KQo"
        }
        # Slightly looser call-range helpers (suited aces/connectors)
        self.medium_others = {
            "A9s", "A8s", "A7s", "A6s", "A5s", "A4s", "A3s", "A2s",
            "KTs", "QTs", "J9s", "T8s", "97s", "86s", "75s", "65s", "54s",
            "ATo", "KJo", "QJo"
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = list(player_hands or [])
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = list(all_players or [])

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards only if provided via external mechanism (some engines pass again)
        # We keep the cards from on_start for this "game".
        # Track position relative to blinds for heads-up or multiway:
        pos = "unknown"
        try:
            if self.id == self.big_blind_player_id:
                pos = "BB"
            elif self.id == self.small_blind_player_id:
                pos = "SB"
        except Exception:
            pos = "unknown"
        self.position_history[round_state.round_num] = pos

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Defensive parsing and defaults
        try:
            my_id_str = str(self.id)
            my_bet = int(round_state.player_bets.get(my_id_str, 0)) if round_state.player_bets else 0
            current_bet = int(round_state.current_bet)
            to_call = max(0, current_bet - my_bet)
            min_raise_inc = max(1, int(round_state.min_raise))  # ensure at least 1 to avoid zero-raise errors
            max_raise = int(round_state.max_raise)
            pot = int(round_state.pot)
        except Exception:
            # If state is malformed, be safe and fold (avoid invalid action penalties)
            return PokerAction.FOLD, 0

        stage = (round_state.round or "").lower()

        # Choose strategy based on stage
        if stage == "preflop":
            action, amount = self._act_preflop(to_call, min_raise_inc, max_raise, current_bet)
        else:
            action, amount = self._act_postflop(round_state, to_call, min_raise_inc, max_raise, current_bet, pot)

        # Final safety checks for validity
        action, amount = self._ensure_valid_action(action, amount, to_call, min_raise_inc, max_raise, current_bet)
        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-hand aggressiveness if needed; currently not tracking long-term stats
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game end hook; we could adjust randomness seed or logging if desired
        pass

    # ---------- Strategy Helpers ----------

    def _hand_category(self) -> str:
        # Returns one of: 'premium', 'strong', 'medium', 'weak'
        if len(self.hole_cards) < 2:
            return "weak"
        label = make_hand_label(self.hole_cards[0], self.hole_cards[1])
        # Pairs first
        if len(label) == 2:  # e.g., 'TT'
            if label in self.premium_pairs:
                return "premium"
            if label in self.strong_pairs:
                return "strong"
            if label in self.medium_pairs:
                return "medium"
            return "weak"
        # Suited/offsuit combos
        if label in self.premium_others:
            return "premium"
        if label in self.strong_others:
            return "strong"
        if label in self.medium_others:
            return "medium"
        return "weak"

    def _act_preflop(self, to_call: int, min_raise_inc: int, max_raise: int, current_bet: int) -> Tuple[PokerAction, int]:
        cat = self._hand_category()
        blind = max(1, int(self.blind_amount) if self.blind_amount else 10)

        # Conservative opening/defense for heads-up or multiway
        # Use simple sizing: opens to 3-4x blind when no raise; 3-bet to (call + 2-3x blind) when facing raise
        # If max_raise too low to raise, choose best alternative (CALL if cheap, else FOLD)

        # No raise yet (we can check or bet)
        if to_call == 0:
            if cat == "premium":
                target = max(current_bet + min_raise_inc, 4 * blind)
                amount = min(target, max_raise)
                if amount > 0 and amount > current_bet:
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CHECK, 0
            elif cat == "strong":
                target = max(current_bet + min_raise_inc, 3 * blind)
                amount = min(target, max_raise)
                if amount > 0 and amount > current_bet:
                    return PokerAction.RAISE, amount
                else:
                    return PokerAction.CHECK, 0
            elif cat == "medium":
                # Mix in a small open occasionally to avoid being too passive
                if self.rng.random() < 0.15:
                    target = max(current_bet + min_raise_inc, 3 * blind)
                    amount = min(target, max_raise)
                    if amount > 0 and amount > current_bet:
                        return PokerAction.RAISE, amount
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0

        # Facing a bet/raise preflop
        else:
            # Small raise sizes (<= 3x blind): defend wider
            if to_call <= 3 * blind:
                if cat == "premium":
                    # 3-bet to call + 3x blind
                    target = to_call + max(min_raise_inc, 3 * blind)
                    amount = min(target, max_raise)
                    if amount > to_call and amount > 0:
                        return PokerAction.RAISE, amount
                    else:
                        return PokerAction.CALL, 0
                elif cat == "strong":
                    return PokerAction.CALL, 0
                elif cat == "medium":
                    # Call when cheap; otherwise fold
                    if to_call <= 2 * blind:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

            # Medium raise sizes (<= 8x blind)
            elif to_call <= 8 * blind:
                if cat == "premium":
                    # Sometimes 3-bet small; otherwise call
                    if self.rng.random() < 0.4:
                        target = to_call + max(min_raise_inc, 2 * blind)
                        amount = min(target, max_raise)
                        if amount > to_call and amount > 0:
                            return PokerAction.RAISE, amount
                    return PokerAction.CALL, 0
                elif cat == "strong":
                    # Call occasionally if not too expensive
                    if to_call <= 4 * blind and self.rng.random() < 0.5:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

            # Huge raises: continue only with top range
            else:
                if cat == "premium":
                    # Prefer call, keep pot under control
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

    def _act_postflop(self, round_state: RoundStateClient, to_call: int, min_raise_inc: int,
                       max_raise: int, current_bet: int, pot: int) -> Tuple[PokerAction, int]:
        # Very conservative postflop.
        # If no bet: occasionally make a small stab; otherwise check.
        # If facing a bet: call small bets with decent showdown value; fold otherwise.
        # Showdown value heuristic: do we have a pair with board or an overcard on a low board, basic only.

        board = round_state.community_cards or []
        hc = self.hole_cards or []
        blind = max(1, int(self.blind_amount) if self.blind_amount else 10)

        def have_pair_or_better() -> bool:
            if len(hc) < 2:
                return False
            ranks = [card_rank(c) for c in board + hc]
            # Pairs with board or pocket pair
            if card_rank(hc[0]) == card_rank(hc[1]):
                return True
            if card_rank(hc[0]) in [card_rank(c) for c in board]:
                return True
            if card_rank(hc[1]) in [card_rank(c) for c in board]:
                return True
            return False

        made_hand = have_pair_or_better()

        if to_call == 0:
            # No bet to us: small stab if we have a made hand or sometimes as bluff
            if made_hand or self.rng.random() < 0.1:
                target = max(current_bet + min_raise_inc, max(blind, pot // 4))
                amount = min(target, max_raise)
                if amount > 0 and amount > current_bet:
                    return PokerAction.RAISE, amount
            return PokerAction.CHECK, 0
        else:
            # Facing a bet: call small bets if we have something, else fold
            if made_hand and to_call <= max(blind * 3, pot // 3 if pot > 0 else blind * 3):
                return PokerAction.CALL, 0
            else:
                # Occasionally float tiny bets
                if to_call <= blind and self.rng.random() < 0.1:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

    def _ensure_valid_action(self, action: PokerAction, amount: int, to_call: int,
                             min_raise_inc: int, max_raise: int, current_bet: int) -> Tuple[PokerAction, int]:
        # Ensure compliance with server's action validity rules

        # For any negative or None amount, fix to 0
        if amount is None or amount < 0:
            amount = 0

        if action == PokerAction.CHECK:
            # Can't check if there's a bet to call
            if to_call > 0:
                # Prefer calling small, else fold
                if to_call <= max(self.blind_amount, 10):
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0

        if action == PokerAction.CALL:
            # Call requires to_call >= 0; engine handles amount automatically
            if to_call == 0:
                # No need to call if nothing to call; convert to check
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CALL, 0

        if action == PokerAction.FOLD:
            return PokerAction.FOLD, 0

        if action == PokerAction.ALL_IN:
            # All-in is always valid from our side (engine will clamp)
            return PokerAction.ALL_IN, 0

        if action == PokerAction.RAISE:
            # The server expects: raise_amount + current_bet must be > current_raise (round_state.current_bet)
            # Minimum raise total should be: to_call + min_raise_inc
            min_total_raise = to_call + max(1, min_raise_inc)
            # Cap by max_raise
            valid_amount = min(max(amount, min_total_raise), max_raise)
            # If we can't raise validly, fallback
            if valid_amount <= to_call or valid_amount <= 0:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # If we intended to raise but cannot, call if affordable else fold
                    if to_call <= max(self.blind_amount, 10):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            return PokerAction.RAISE, valid_amount

        # Fallback safety
        if to_call == 0:
            return PokerAction.CHECK, 0
        else:
            return PokerAction.FOLD, 0