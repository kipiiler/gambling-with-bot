from typing import List, Tuple, Dict, Any, Optional
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Simple helper functions for card parsing and strength evaluation
RANK_MAP = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
    '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}
RANKS_REVERSE = {v: k for k, v in RANK_MAP.items()}

def card_rank(card: str) -> int:
    if not card or len(card) < 2:
        return 0
    return RANK_MAP.get(card[0].upper(), 0)

def card_suit(card: str) -> str:
    if not card or len(card) < 2:
        return ''
    return card[1].lower()

def is_suited(card1: str, card2: str) -> bool:
    return card_suit(card1) == card_suit(card2) and card_suit(card1) != ''

def gap(card1: str, card2: str) -> int:
    return abs(card_rank(card1) - card_rank(card2))

def normalize(x: float, min_v: float, max_v: float) -> float:
    denom = (max_v - min_v) if max_v != min_v else (1e-9)
    return max(0.0, min(1.0, (x - min_v) / denom))

def clamp(v: int, lo: int, hi: int) -> int:
    if hi < lo:
        return lo
    return max(lo, min(hi, v))

def safe_div(n: float, d: float, eps: float = 1e-9) -> float:
    return n / (d + eps)

def count_ranks(cards: List[str]) -> Dict[int, int]:
    cnt: Dict[int, int] = {}
    for c in cards:
        r = card_rank(c)
        if r > 0:
            cnt[r] = cnt.get(r, 0) + 1
    return cnt

def count_suits(cards: List[str]) -> Dict[str, int]:
    cnt: Dict[str, int] = {}
    for c in cards:
        s = card_suit(c)
        if s:
            cnt[s] = cnt.get(s, 0) + 1
    return cnt

def has_flush(cards: List[str]) -> bool:
    suit_counts = count_suits(cards)
    return any(v >= 5 for v in suit_counts.values())

def flush_draw(cards: List[str]) -> bool:
    suit_counts = count_suits(cards)
    return any(v == 4 for v in suit_counts.values())

def straight_max_len(cards: List[str]) -> int:
    """Return the maximal straight length present (number of consecutive ranks)."""
    ranks = set(card_rank(c) for c in cards if card_rank(c) > 0)
    # Handle wheel A-2-3-4-5: treat Ace also as 1
    if 14 in ranks:
        ranks.add(1)
    longest = 1
    for r in ranks:
        if (r - 1) not in ranks:
            # start of straight
            length = 1
            nr = r + 1
            while nr in ranks:
                length += 1
                nr += 1
            if length > longest:
                longest = length
    return longest

def has_straight(cards: List[str]) -> bool:
    return straight_max_len(cards) >= 5

def straight_draw(cards: List[str]) -> bool:
    # Heuristic: max sequence length 4 implies a straight draw (OESD or gutshot)
    return straight_max_len(cards) == 4

def pair_info(hole: List[str], board: List[str]) -> Dict[str, Any]:
    """Return info about pairs/trips/quads and categories like top pair, overpair, two pair."""
    all_cards = hole + board
    cnt = count_ranks(all_cards)
    board_cnt = count_ranks(board)
    hole_cnt = count_ranks(hole)
    info = {
        'has_pair': False,
        'has_two_pair': False,
        'has_trips': False,
        'has_quads': False,
        'overpair': False,
        'top_pair': False,
        'second_pair': False,
        'pocket_pair': False,
    }
    pocket_pair = len(hole) == 2 and card_rank(hole[0]) == card_rank(hole[1]) and card_rank(hole[0]) > 0
    info['pocket_pair'] = pocket_pair

    # trips/quads detection
    for r, v in cnt.items():
        if v == 4:
            info['has_quads'] = True
        if v == 3:
            info['has_trips'] = True

    # pairs detection
    pairs = [r for r, v in cnt.items() if v == 2]
    if len(pairs) >= 1:
        info['has_pair'] = True
    if len(pairs) >= 2 or (len(pairs) == 1 and info['has_trips']):
        info['has_two_pair'] = True

    # Overpair, top pair, second pair (on flop/turn/river)
    if board:
        board_ranks_sorted = sorted(set(card_rank(c) for c in board if card_rank(c) > 0), reverse=True)
        top_board = board_ranks_sorted[0] if board_ranks_sorted else 0
        second_board = board_ranks_sorted[1] if len(board_ranks_sorted) > 1 else 0
        # overpair: pocket pair higher than any board rank
        if pocket_pair and card_rank(hole[0]) > 0 and card_rank(hole[0]) > max(board_ranks_sorted or [0]):
            info['overpair'] = True
        # top/second pair: we pair board rank with our card
        our_ranks = [card_rank(c) for c in hole]
        # Determine if we form a pair with board
        for r in our_ranks:
            if r in board_cnt:
                if r == top_board:
                    info['top_pair'] = True
                elif r == second_board:
                    info['second_pair'] = True

    return info

def preflop_strength(hole: Optional[List[str]]) -> float:
    """Return a heuristic strength in [0,1] for preflop hand."""
    if not hole or len(hole) != 2:
        return 0.45  # Neutral when unknown

    c1, c2 = hole[0], hole[1]
    r1, r2 = card_rank(c1), card_rank(c2)
    if r1 == 0 or r2 == 0:
        return 0.45
    s = 0.0
    high = max(r1, r2)
    low = min(r1, r2)
    suited = is_suited(c1, c2)
    g = gap(c1, c2)

    # Pairs
    if r1 == r2:
        # Scale pairs
        pair_map = {
            14: 1.00, 13: 0.95, 12: 0.90, 11: 0.85, 10: 0.80,
             9: 0.75,  8: 0.70,  7: 0.65,  6: 0.60,  5: 0.56,
             4: 0.52,  3: 0.48,  2: 0.44
        }
        return pair_map.get(r1, 0.5)

    # Non-pairs
    s += normalize(high, 6, 14) * 0.5  # weight high card more
    s += normalize(low, 2, 12) * 0.2   # weight low card some
    if suited:
        s += 0.06
    if g == 0:
        s += 0.04  # same rank (already handled), but just in case, negligible
    elif g == 1:
        s += 0.04
    elif g == 2:
        s += 0.02
    elif g == 3:
        s += 0.01
    else:
        s -= 0.02

    # Broadways and Ax bonuses
    broadways = sum(1 for r in (r1, r2) if r >= 10)
    if broadways == 2:
        s += 0.04
    elif broadways == 1:
        s += 0.02
    if 14 in (r1, r2) and suited:
        s += 0.02

    return max(0.0, min(1.0, s))

def postflop_strength(hole: Optional[List[str]], board: List[str]) -> float:
    """Heuristic postflop strength estimation in [0,1]."""
    if not board:
        return preflop_strength(hole)
    if not hole or len(hole) != 2:
        # With no info on our hand, remain conservative
        # Slightly increase with more cards on board (variance down)
        base = 0.45 + 0.02 * min(len(board), 5)
        return max(0.0, min(1.0, base))

    all_cards = hole + board
    pi = pair_info(hole, board)
    made_flush = has_flush(all_cards)
    made_straight = has_straight(all_cards)
    fd = flush_draw(all_cards)
    sd = straight_draw(all_cards)

    # Rank-based top pair kicker quality
    ranks_hole = [card_rank(c) for c in hole]
    high_kicker = max(ranks_hole)
    good_kicker = high_kicker >= 12  # Q or better

    # Evaluate categories
    if pi['has_quads']:
        return 0.99
    # Full house if trips + pair
    ranks_cnt = count_ranks(all_cards)
    trips = [r for r, v in ranks_cnt.items() if v == 3]
    pairs = [r for r, v in ranks_cnt.items() if v == 2]
    if (len(trips) >= 2) or (len(trips) >= 1 and len(pairs) >= 1):
        return 0.95
    if made_flush:
        return 0.9
    if made_straight:
        return 0.85
    if pi['has_trips']:
        return 0.76
    if pi['has_two_pair']:
        return 0.71
    if pi['overpair']:
        return 0.70
    if pi['top_pair'] and good_kicker:
        return 0.61
    if pi['top_pair']:
        return 0.57
    if pi['second_pair']:
        return 0.51

    # Draw-based
    strong_draw = (fd and sd) or (fd and high_kicker >= 12) or (sd and high_kicker >= 12)
    if strong_draw:
        return 0.54
    if fd or sd:
        return 0.46

    # No made hand
    return 0.25

def estimate_equity(round_name: str, hole: Optional[List[str]], board: List[str]) -> float:
    round_lower = (round_name or '').lower()
    if round_lower in ('preflop', 'prefop', 'pre-flop', 'pre'):
        return preflop_strength(hole)
    else:
        return postflop_strength(hole, board)

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Game/session state
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.table_size: int = 0

        # Hand/round state
        self.current_hand: Optional[List[str]] = None
        self.last_round_num: Optional[int] = None

        # Simple opponent tracking (id -> stats)
        self.op_stats: Dict[int, Dict[str, float]] = {}

        # Track last actions to infer aggression
        self.last_aggressor_id: Optional[int] = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize session variables
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = list(all_players) if all_players else []
        self.table_size = len(self.all_players)

        # Set current hand if provided (some engines may call this per-hand)
        if isinstance(player_hands, list) and len(player_hands) >= 2:
            self.current_hand = player_hands[:2]
        else:
            self.current_hand = None

        # Initialize opponent stats
        self.op_stats = {pid: {'vpip': 0.0, 'pfr': 0.0, 'hands': 0.0, 'bets': 0.0, 'calls': 0.0, 'raises': 0.0} for pid in self.all_players}
        self.last_aggressor_id = None
        self.last_round_num = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Detect new hand by round number
        if self.last_round_num is None or round_state.round_num != self.last_round_num:
            # New hand; reset aggressor and possibly hand (if not provided via on_start)
            self.last_round_num = round_state.round_num
            self.last_aggressor_id = None
            # Some engines may embed hand info somewhere else; we keep current_hand if already set on on_start
            # If not set, leave as None and play conservatively
        # Update blind amount if identifiable via min_raise in preflop (fallback)
        if (round_state.round or '').lower() in ('preflop', 'pre-flop', 'pre'):
            if round_state.min_raise and round_state.min_raise > 0:
                # Often min_raise equals 2*big blind in some engines, but we keep previous known blind
                pass

    def _get_my_bet(self, round_state: RoundStateClient) -> int:
        key = str(self.id) if self.id is not None else None
        if key and isinstance(round_state.player_bets, dict):
            return int(round_state.player_bets.get(key, 0) or 0)
        return 0

    def _get_to_call(self, round_state: RoundStateClient) -> int:
        current_bet = int(round_state.current_bet or 0)
        my_bet = self._get_my_bet(round_state)
        to_call = max(0, current_bet - my_bet)
        return to_call

    def _active_player_count(self, round_state: RoundStateClient) -> int:
        # Try to infer active players: players who haven't folded
        actions = round_state.player_actions or {}
        folded_ids = {pid for pid, act in actions.items() if str(act).lower() == 'fold'}
        if self.all_players:
            return max(1, len([pid for pid in self.all_players if str(pid) not in folded_ids]))
        # Fallback
        if round_state.current_player:
            return max(1, len(round_state.current_player))
        return max(1, len(actions) or 2)

    def _can_check(self, round_state: RoundStateClient) -> bool:
        return self._get_to_call(round_state) == 0

    def _can_raise(self, round_state: RoundStateClient) -> bool:
        min_r = int(round_state.min_raise or 0)
        max_r = int(round_state.max_raise or 0)
        return max_r >= max(1, min_r)

    def _choose_bet_size(self, round_state: RoundStateClient, target: int) -> Optional[int]:
        """Choose a valid raise size close to target."""
        min_r = int(round_state.min_raise or 0)
        max_r = int(round_state.max_raise or 0)
        if max_r <= 0:
            return None
        if min_r <= 0:
            min_r = 1
        amount = clamp(int(target), min_r, max_r)
        return amount

    def _raise_pot_size(self, round_state: RoundStateClient, fraction: float = 0.66) -> Optional[int]:
        pot = int(round_state.pot or 0)
        to_call = self._get_to_call(round_state)
        target = int(max(1, fraction * (pot + to_call)))
        return self._choose_bet_size(round_state, target)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Compute basic quantities
            to_call = self._get_to_call(round_state)
            can_check = self._can_check(round_state)
            can_raise = self._can_raise(round_state)
            max_raise = int(round_state.max_raise or 0)
            min_raise = int(round_state.min_raise or 0)
            if min_raise <= 0:
                min_raise = 1
            if remaining_chips <= 0:
                # No chips left, forced check/fold
                if can_check:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Determine stage and estimate equity
            board = list(round_state.community_cards or [])
            stage = (round_state.round or '').lower()
            equity = estimate_equity(round_state.round, self.current_hand, board)

            # Adjust thresholds by number of opponents (tighter multiway)
            opponents = max(1, self._active_player_count(round_state) - 1)
            multi_factor = 0.0 if opponents <= 1 else min(0.10, 0.03 * opponents)

            # Pot odds
            pot = int(round_state.pot or 0)
            pot_odds = safe_div(to_call, pot + to_call)

            # Preflop logic
            if stage in ('preflop', 'pre-flop', 'pre', 'prefop'):
                s = preflop_strength(self.current_hand)
                # Open or limp
                if can_check and to_call == 0:
                    # Heads-up: open more; multiway: tighter
                    open_threshold = 0.58 + multi_factor
                    if s >= open_threshold and can_raise:
                        # Open size: around pot or min-raise if small
                        open_size = self._choose_bet_size(round_state, max(min_raise, int(self.blind_amount * 3) if self.blind_amount else min_raise))
                        if open_size is not None:
                            return (PokerAction.RAISE, open_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    # Occasional probing bet with medium strength
                    if s >= 0.52 + multi_factor and can_raise:
                        probe = self._choose_bet_size(round_state, min_raise)
                        if probe is not None:
                            return (PokerAction.RAISE, probe)
                    return (PokerAction.CHECK, 0)
                else:
                    # Facing a bet/raise
                    # Call with decent hands given pot odds; 3-bet with premiums
                    if s >= 0.82 and can_raise:
                        # 3-bet/Isolation raise
                        size = self._choose_bet_size(round_state, max(min_raise, int(pot * 0.6) + to_call))
                        if size is not None:
                            return (PokerAction.RAISE, size)
                        elif max_raise > 0:
                            return (PokerAction.ALL_IN, 0)
                    # Call if equity beats pot odds with margin
                    if s >= (pot_odds + 0.08 + multi_factor):
                        return (PokerAction.CALL, 0)
                    # Occasionally defend big blind cheap
                    if s >= 0.50 and to_call <= max(1, (self.blind_amount or 10)):
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)

            # Postflop logic
            strong_threshold = 0.75 + multi_factor  # Raise for value
            call_threshold = pot_odds + 0.05 + multi_factor
            semi_bluff_threshold = 0.50 + multi_factor

            if can_check and to_call == 0:
                # Decide to bet or check
                if equity >= strong_threshold and can_raise:
                    # Value bet around 2/3 pot
                    size = self._raise_pot_size(round_state, 0.66)
                    if size is not None:
                        return (PokerAction.RAISE, size)
                    else:
                        return (PokerAction.CHECK, 0)
                if equity >= semi_bluff_threshold and can_raise:
                    # Semi-bluff smaller sizing
                    size = self._raise_pot_size(round_state, 0.5)
                    if size is None:
                        size = self._choose_bet_size(round_state, min_raise)
                    if size is not None:
                        return (PokerAction.RAISE, size)
                return (PokerAction.CHECK, 0)
            else:
                # Facing a bet
                if equity >= strong_threshold and can_raise:
                    # Value raise
                    size = self._raise_pot_size(round_state, 0.75)
                    if size is not None:
                        return (PokerAction.RAISE, size)
                    elif max_raise > 0:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)

                # Call with sufficient equity vs pot odds
                if equity >= call_threshold:
                    return (PokerAction.CALL, 0)

                # Semi-bluff jam rarely if near-max_raise small (short stack)
                effective_stack = remaining_chips
                if equity >= semi_bluff_threshold and effective_stack <= max(1, int(1.0 * (pot + to_call))) and max_raise > 0:
                    return (PokerAction.ALL_IN, 0)

                return (PokerAction.FOLD, 0)

        except Exception:
            # Fallback safe action
            to_call = 0
            try:
                to_call = self._get_to_call(round_state)
            except Exception:
                to_call = 0
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            else:
                # If small to call, call; else fold
                if to_call <= max(1, (self.blind_amount or 10)):
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update opponent stats roughly based on actions taken in the round
        actions = round_state.player_actions or {}
        for pid_str, act in actions.items():
            try:
                pid = int(pid_str)
            except Exception:
                continue
            if pid not in self.op_stats:
                self.op_stats[pid] = {'vpip': 0.0, 'pfr': 0.0, 'hands': 0.0, 'bets': 0.0, 'calls': 0.0, 'raises': 0.0}
            stats = self.op_stats[pid]
            stats['hands'] += 1.0
            act_l = str(act).lower()
            # VPIP: voluntary put money in pot (call/raise)
            if act_l in ('call', 'raise', 'all_in'):
                stats['vpip'] += 1.0
            if act_l in ('raise',):
                stats['pfr'] += 1.0
            if act_l == 'call':
                stats['calls'] += 1.0
            if act_l == 'raise':
                stats['raises'] += 1.0
            if act_l in ('raise', 'all_in'):
                stats['bets'] += 1.0

        # Clear current hand to avoid leaking to next hand unless provided anew
        self.current_hand = None
        self.last_aggressor_id = None

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Nothing to persist; could adjust strategy parameters if desired
        pass