from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_count = 0
        self.fold_count = 0
        self.aggressive_threshold = 0.4
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        self.fold_count = 0
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength based on hole cards and community cards."""
        if not self.hole_cards:
            return 0.3
            
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._get_rank_value(card1[0]), self._get_rank_value(card2[0])
        suited = (card1[1] == card2[1])
        
        # Preflop evaluation
        if len(round_state.community_cards) == 0:
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                else:
                    return 0.65
            
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            
            # Ace combinations
            if high_rank == 14:
                if low_rank >= 11:  # AJ+
                    return 0.85 if suited else 0.80
                elif low_rank >= 9:  # A9-AT
                    return 0.70 if suited else 0.65
                else:
                    return 0.60 if suited else 0.55
            
            # King combinations
            if high_rank == 13:
                if low_rank >= 11:  # KJ+
                    return 0.75 if suited else 0.70
                elif low_rank >= 9:
                    return 0.65 if suited else 0.60
                else:
                    return 0.55 if suited else 0.50
            
            # Queen combinations
            if high_rank == 12:
                if low_rank >= 10:
                    return 0.70 if suited else 0.65
                else:
                    return 0.55 if suited else 0.50
            
            # Connected cards
            if abs(rank1 - rank2) == 1:
                return 0.60 if suited else 0.55
            elif abs(rank1 - rank2) == 2:
                return 0.55 if suited else 0.50
            
            # Default
            return 0.45 if suited else 0.40
        
        # Postflop - simplified evaluation
        else:
            # Count potential hands
            all_cards = self.hole_cards + round_state.community_cards
            
            # Check for pairs, trips, etc.
            ranks = [self._get_rank_value(card[0]) for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_count = max(rank_counts.values())
            
            # Check for flush potential
            suits = [card[1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit = max(suit_counts.values())
            
            # Evaluate strength
            if max_count == 4:
                return 0.98  # Four of a kind
            elif max_count == 3:
                if 2 in rank_counts.values():
                    return 0.95  # Full house
                else:
                    return 0.85  # Three of a kind
            elif max_suit >= 5:
                return 0.90  # Flush
            elif max_count == 2:
                pair_count = sum(1 for count in rank_counts.values() if count == 2)
                if pair_count >= 2:
                    return 0.70  # Two pair
                else:
                    # One pair - check if it's from hole cards
                    hole_ranks = [self._get_rank_value(card[0]) for card in self.hole_cards]
                    for hr in hole_ranks:
                        if rank_counts.get(hr, 0) >= 2:
                            if hr >= 12:  # High pair
                                return 0.75
                            elif hr >= 9:
                                return 0.65
                            else:
                                return 0.55
                    return 0.50  # Board pair
            
            # High card
            hole_ranks = [self._get_rank_value(card[0]) for card in self.hole_cards]
            if max(hole_ranks) >= 13:  # Ace or King high
                return 0.45
            return 0.35
    
    def _get_rank_value(self, rank: str) -> int:
        """Convert rank character to numerical value."""
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank, 0)
    
    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling."""
        my_id = str(self.id)
        my_current_bet = round_state.player_bets.get(my_id, 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 1.0
        
        total_pot = round_state.pot + call_amount
        if total_pot <= 0:
            return 0.5
            
        return call_amount / (total_pot + 0.001)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Get pot odds
        pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
        
        # Get current betting situation
        my_id = str(self.id)
        my_current_bet = round_state.player_bets.get(my_id, 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Calculate position factor (acting later is better)
        position_factor = 1.0
        if self.num_players > 2:
            # Estimate position based on number of players who have acted
            acted_players = len([p for p in round_state.player_actions.values() if p and p != 'None'])
            position_factor = 1.0 + (acted_players * 0.05)
        
        # Adjust hand strength based on position
        adjusted_strength = hand_strength * position_factor
        
        # Decision logic
        if call_amount <= 0:
            # No bet to call - we can check or bet
            if adjusted_strength > 0.7:
                # Strong hand - bet aggressively
                # Ensure we raise by at least min_raise amount
                if round_state.min_raise > 0 and remaining_chips >= round_state.min_raise:
                    bet_size = min(
                        max(round_state.min_raise, int(round_state.pot * 0.6)),
                        remaining_chips
                    )
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            elif adjusted_strength > 0.5 and round_state.pot > self.blind_amount * 4:
                # Medium hand with decent pot - small bet
                if round_state.min_raise > 0 and remaining_chips >= round_state.min_raise:
                    bet_size = min(
                        max(round_state.min_raise, int(round_state.pot * 0.3)),
                        remaining_chips
                    )
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # There's a bet to call
            if call_amount >= remaining_chips:
                # Would be all-in to call
                if adjusted_strength > 0.75:
                    return (PokerAction.ALL_IN, 0)
                elif adjusted_strength > 0.6 and pot_odds < 0.3:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            # Normal bet to call
            if adjusted_strength > 0.85:
                # Very strong hand - consider raising
                if remaining_chips > call_amount + round_state.min_raise:
                    raise_amount = min(
                        max(round_state.min_raise, int(round_state.pot * 0.7)),
                        remaining_chips - call_amount
                    )
                    # Make sure our total bet would be higher than current bet
                    if my_current_bet + call_amount + raise_amount > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif adjusted_strength > 0.65:
                # Good hand - usually call
                if pot_odds < 0.25 or round_state.pot > self.blind_amount * 10:
                    return (PokerAction.CALL, 0)
                elif pot_odds < 0.35:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif adjusted_strength > 0.5:
                # Medium hand - call if pot odds are good
                if pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
                elif pot_odds < 0.3 and round_state.round == 'Preflop':
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            elif adjusted_strength > 0.35:
                # Weak hand - only call with very good pot odds
                if pot_odds < 0.15:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Very weak hand - fold
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hole_cards = []