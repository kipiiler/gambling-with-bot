from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.current_game_num = 0
        self.fold_count = 0
        self.raise_count = 0
        self.opponent_aggression = {}
        self.pot_odds_threshold = 0.3
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.current_game_num += 1
        self.fold_count = 0
        self.raise_count = 0
        for player_id in all_players:
            if player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = 0.5

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Calculate pot odds
        call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_odds = call_amount / (round_state.pot + call_amount + 0.001)
        
        # Update opponent aggression based on their actions
        self._update_opponent_stats(round_state)
        
        # Decision logic based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(hand_strength, round_state, remaining_chips, pot_odds)
        else:
            return self._postflop_strategy(hand_strength, round_state, remaining_chips, pot_odds)

    def _preflop_strategy(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Premium hands - always raise or call
        if hand_strength > 0.85:
            if remaining_chips > round_state.current_bet * 3:
                raise_amount = min(round_state.current_bet * 2, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
            if call_amount > 0 and call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
        
        # Good hands - call or small raise
        elif hand_strength > 0.65:
            if call_amount <= remaining_chips * 0.15:
                if call_amount > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Medium hands - call small bets
        elif hand_strength > 0.45:
            if call_amount <= remaining_chips * 0.05:
                if call_amount > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands - fold to bets, check if free
        else:
            if call_amount > 0:
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def _postflop_strategy(self, hand_strength: float, round_state: RoundStateClient, remaining_chips: int, pot_odds: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Very strong hands - bet/raise aggressively
        if hand_strength > 0.9:
            if remaining_chips > round_state.pot:
                raise_amount = min(round_state.pot // 2, remaining_chips)
                if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                    return (PokerAction.RAISE, raise_amount)
            if call_amount > 0 and call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
            elif call_amount == 0:
                if remaining_chips > round_state.pot // 3:
                    raise_amount = min(round_state.pot // 3, remaining_chips)
                    if raise_amount >= round_state.min_raise and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        
        # Good hands - call or small raise
        elif hand_strength > 0.7:
            if pot_odds < 0.3 or call_amount <= remaining_chips * 0.2:
                if call_amount > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Drawing hands or medium strength
        elif hand_strength > 0.4:
            if pot_odds < 0.2 or call_amount <= remaining_chips * 0.1:
                if call_amount > 0:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Weak hands
        else:
            if call_amount > 0:
                if pot_odds < 0.1 and call_amount <= remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)

    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate relative hand strength (0-1)"""
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.5
        
        card1_rank = self._card_rank(self.hole_cards[0])
        card2_rank = self._card_rank(self.hole_cards[1])
        suited = self.hole_cards[0][-1] == self.hole_cards[1][-1]
        
        # Preflop hand strength
        if round_state.round == 'Preflop':
            # Pocket pairs
            if card1_rank == card2_rank:
                if card1_rank >= 12:  # AA, KK, QQ
                    return 0.95
                elif card1_rank >= 10:  # JJ, TT
                    return 0.85
                elif card1_rank >= 8:  # 99, 88
                    return 0.75
                else:
                    return 0.65
            
            # High cards
            high_rank = max(card1_rank, card2_rank)
            low_rank = min(card1_rank, card2_rank)
            
            if high_rank == 14:  # Ace high
                if low_rank >= 12:  # AK, AQ
                    return 0.85 if suited else 0.80
                elif low_rank >= 10:  # AJ, AT
                    return 0.70 if suited else 0.65
                else:
                    return 0.55 if suited else 0.50
            elif high_rank >= 12:  # King or Queen high
                if low_rank >= 10:
                    return 0.65 if suited else 0.60
                else:
                    return 0.45 if suited else 0.40
            else:
                if suited and abs(card1_rank - card2_rank) <= 2:
                    return 0.50
                return 0.35
        
        # Postflop - simplified hand evaluation
        else:
            community = round_state.community_cards
            all_cards = self.hole_cards + community
            
            # Check for pairs, trips, etc
            ranks = [self._card_rank(card) for card in all_cards]
            rank_counts = {}
            for rank in ranks:
                rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
            max_count = max(rank_counts.values())
            
            # Check for flush
            suits = [card[-1] for card in all_cards]
            suit_counts = {}
            for suit in suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            has_flush = max(suit_counts.values()) >= 5
            
            # Check for straight
            unique_ranks = sorted(set(ranks))
            has_straight = False
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i+4] - unique_ranks[i] == 4:
                    has_straight = True
                    break
            
            # Assign strength based on hand
            if has_flush and has_straight:
                return 0.98
            elif max_count == 4:
                return 0.97
            elif max_count == 3 and len([v for v in rank_counts.values() if v >= 2]) >= 2:
                return 0.95  # Full house
            elif has_flush:
                return 0.90
            elif has_straight:
                return 0.85
            elif max_count == 3:
                return 0.75
            elif len([v for v in rank_counts.values() if v == 2]) >= 2:
                return 0.60  # Two pair
            elif max_count == 2:
                # Check if we have pocket pair
                hole_ranks = [self._card_rank(card) for card in self.hole_cards]
                if hole_ranks[0] == hole_ranks[1]:
                    return 0.65
                return 0.50
            else:
                # High card
                hole_high = max(self._card_rank(self.hole_cards[0]), self._card_rank(self.hole_cards[1]))
                if hole_high >= 12:
                    return 0.40
                return 0.25

    def _card_rank(self, card: str) -> int:
        """Convert card rank to numerical value"""
        if not card or len(card) < 1:
            return 0
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            try:
                return int(rank)
            except:
                return 0

    def _update_opponent_stats(self, round_state: RoundStateClient):
        """Update opponent aggression statistics"""
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                player_id_int = int(player_id)
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression[player_id_int] = min(1.0, self.opponent_aggression.get(player_id_int, 0.5) + 0.05)
                elif action == 'Call':
                    self.opponent_aggression[player_id_int] = self.opponent_aggression.get(player_id_int, 0.5)
                elif action in ['Check', 'Fold']:
                    self.opponent_aggression[player_id_int] = max(0.0, self.opponent_aggression.get(player_id_int, 0.5) - 0.02)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass