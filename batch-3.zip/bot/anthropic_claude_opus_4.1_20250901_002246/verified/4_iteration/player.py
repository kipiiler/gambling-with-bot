from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.game_count = 0
        self.position = None  # 'sb', 'bb', or 'normal'
        self.opponent_aggression = {}  # Track opponent tendencies
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand_cards = player_hands
        self.game_count += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'sb'
        elif self.id == big_blind_player_id:
            self.position = 'bb'
        else:
            self.position = 'normal'
            
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0, 'checks': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
                elif 'Check' in action:
                    self.opponent_aggression[player_id]['checks'] += 1
        
        # Calculate pot odds
        pot = round_state.pot
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        pot_odds = call_amount / (pot + call_amount + 0.001) if call_amount > 0 else 0
        
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get opponent aggression factor
        aggression_factor = self._get_opponent_aggression_factor()
        
        # Decision making based on round
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, pot_odds)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, pot_odds, aggression_factor)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate the relative strength of our hand."""
        if not self.hand_cards or len(self.hand_cards) < 2:
            return 0.3
        
        card1, card2 = self.hand_cards[0], self.hand_cards[1]
        rank1, suit1 = card1[:-1], card1[-1]
        rank2, suit2 = card2[:-1], card2[-1]
        
        # Convert face cards to values
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Preflop hand strength calculation
        strength = 0.0
        
        # Pocket pairs
        if val1 == val2:
            strength = 0.65 + (val1 / 14) * 0.35
        else:
            # High cards
            high_card = max(val1, val2)
            low_card = min(val1, val2)
            
            # Base strength from high card
            strength = 0.2 + (high_card / 14) * 0.3
            
            # Adjust for kicker
            strength += (low_card / 14) * 0.15
            
            # Suited bonus
            if suit1 == suit2:
                strength += 0.1
            
            # Connectedness bonus
            gap = abs(val1 - val2)
            if gap == 1:
                strength += 0.08
            elif gap == 2:
                strength += 0.05
            elif gap == 3:
                strength += 0.02
        
        # Postflop adjustments
        if round_state.round != 'Preflop' and round_state.community_cards:
            strength = self._adjust_for_community_cards(strength, round_state.community_cards, val1, val2, suit1, suit2)
        
        return min(1.0, max(0.0, strength))
    
    def _adjust_for_community_cards(self, base_strength: float, community_cards: List[str], 
                                   val1: int, val2: int, suit1: str, suit2: str) -> float:
        """Adjust hand strength based on community cards."""
        if not community_cards:
            return base_strength
        
        # Parse community cards
        community_vals = []
        community_suits = []
        rank_values = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        for i in range(2, 10):
            rank_values[str(i)] = i
        
        for card in community_cards:
            rank, suit = card[:-1], card[-1]
            community_vals.append(rank_values.get(rank, 2))
            community_suits.append(suit)
        
        all_vals = [val1, val2] + community_vals
        all_suits = [suit1, suit2] + community_suits
        
        # Check for pairs, trips, etc.
        val_counts = {}
        for val in all_vals:
            val_counts[val] = val_counts.get(val, 0) + 1
        
        max_count = max(val_counts.values())
        
        # Adjust strength based on made hands
        if max_count >= 4:
            return 0.95  # Four of a kind
        elif max_count == 3:
            if 2 in val_counts.values():
                return 0.9  # Full house
            return 0.75  # Three of a kind
        elif max_count == 2:
            pairs = sum(1 for count in val_counts.values() if count == 2)
            if pairs >= 2:
                return 0.65  # Two pair
            return 0.55  # One pair
        
        # Check for flush potential
        suit_counts = {}
        for suit in all_suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        if max(suit_counts.values()) >= 5:
            return 0.85  # Flush
        elif max(suit_counts.values()) == 4:
            base_strength += 0.15  # Flush draw
        
        # Check for straight potential
        unique_vals = sorted(set(all_vals))
        if len(unique_vals) >= 5:
            for i in range(len(unique_vals) - 4):
                if unique_vals[i+4] - unique_vals[i] == 4:
                    return 0.8  # Straight
        
        return min(1.0, base_strength)
    
    def _get_opponent_aggression_factor(self) -> float:
        """Calculate how aggressive opponents have been."""
        total_aggressive = 0
        total_passive = 0
        
        for stats in self.opponent_aggression.values():
            total_aggressive += stats['raises']
            total_passive += stats['calls'] + stats['checks'] + stats['folds']
        
        if total_aggressive + total_passive == 0:
            return 0.5
        
        return total_aggressive / (total_aggressive + total_passive + 0.001)
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, 
                         hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Preflop strategy."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Premium hands - always raise or reraise
        if hand_strength > 0.85:
            if round_state.current_bet == 0:
                raise_amount = min(round_state.pot * 3, remaining_chips // 3)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif call_amount < remaining_chips * 0.3:
                raise_amount = min(round_state.current_bet * 3, remaining_chips // 2)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            if call_amount <= remaining_chips:
                return (PokerAction.CALL, 0)
        
        # Strong hands
        if hand_strength > 0.65:
            if round_state.current_bet == 0:
                raise_amount = min(round_state.pot * 2, remaining_chips // 4)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif call_amount < remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
        
        # Playable hands
        if hand_strength > 0.45:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < hand_strength and call_amount < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
        
        # Weak hands
        if round_state.current_bet == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int,
                          hand_strength: float, pot_odds: float, aggression_factor: float) -> Tuple[PokerAction, int]:
        """Postflop strategy."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        
        # Adjust strategy based on opponent aggression
        strength_threshold = hand_strength * (1.2 - aggression_factor * 0.4)
        
        # Very strong hands - bet/raise aggressively
        if strength_threshold > 0.8:
            if round_state.current_bet == 0:
                bet_amount = min(int(round_state.pot * 0.75), remaining_chips // 2)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            else:
                if call_amount < remaining_chips * 0.5:
                    raise_amount = min(round_state.current_bet * 2, remaining_chips)
                    if raise_amount > round_state.min_raise and raise_amount <= remaining_chips:
                        return (PokerAction.RAISE, raise_amount)
                if call_amount <= remaining_chips:
                    return (PokerAction.CALL, 0)
        
        # Good hands - bet for value or call
        if strength_threshold > 0.6:
            if round_state.current_bet == 0:
                bet_amount = min(int(round_state.pot * 0.5), remaining_chips // 3)
                if bet_amount >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < strength_threshold and call_amount < remaining_chips * 0.3:
                return (PokerAction.CALL, 0)
        
        # Marginal hands - check or fold
        if strength_threshold > 0.4:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < strength_threshold * 0.8 and call_amount < remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
        
        # Weak hands or bluff occasionally
        if round_state.current_bet == 0:
            # Occasional bluff
            if round_state.pot > 100 and aggression_factor < 0.3:
                bluff_amount = min(int(round_state.pot * 0.3), remaining_chips // 5)
                if bluff_amount >= round_state.min_raise and self.game_count % 5 == 0:
                    return (PokerAction.RAISE, bluff_amount)
            return (PokerAction.CHECK, 0)
        
        return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Learn from the game outcome
        if player_score > 0:
            # Won - our strategy worked
            pass
        else:
            # Lost - could adjust thresholds
            pass