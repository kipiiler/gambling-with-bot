from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.starting_chips = 0
        self.blind_amount = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called when the game starts."""
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current state information
        community_cards = round_state.community_cards
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        # Calculate hand strength
        hand_strength = self._evaluate_hand_strength(community_cards)
        
        # Determine position (early game vs late game)
        cards_shown = len(community_cards)
        
        # Make decision based on game state
        if to_call == 0:
            # Can check for free
            if cards_shown == 0:  # Preflop
                if hand_strength >= 0.6:
                    # Strong hand preflop, raise
                    raise_amount = min(pot // 2, remaining_chips)
                    if raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif cards_shown == 3:  # Flop
                if hand_strength >= 0.5:
                    raise_amount = min(pot // 3, remaining_chips)
                    if raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            else:  # Turn or River
                if hand_strength >= 0.4:
                    raise_amount = min(pot // 4, remaining_chips)
                    if raise_amount > current_bet:
                        return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
        else:
            # Need to call or fold
            pot_odds = to_call / (pot + to_call + 0.001)  # Avoid division by zero
            
            # Adjust threshold based on pot odds
            if cards_shown == 0:  # Preflop
                if hand_strength >= 0.5 or (pot_odds < 0.3 and hand_strength >= 0.3):
                    if to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            elif cards_shown == 3:  # Flop
                if hand_strength >= 0.4 or (pot_odds < 0.25 and hand_strength >= 0.25):
                    if to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:  # Turn or River
                if hand_strength >= 0.35 or (pot_odds < 0.2 and hand_strength >= 0.2):
                    if to_call >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
                
    def _evaluate_hand_strength(self, community_cards: List[str]) -> float:
        """Evaluate hand strength as a value between 0 and 1."""
        if not self.hole_cards:
            return 0.3
            
        # Convert cards to comparable format
        def card_value(card):
            rank = card[0]
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                          '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            return rank_values.get(rank, 0)
            
        def card_suit(card):
            return card[1] if len(card) > 1 else ''
            
        hole_values = [card_value(card) for card in self.hole_cards]
        hole_suits = [card_suit(card) for card in self.hole_cards]
        
        # Preflop hand strength
        if len(community_cards) == 0:
            max_card = max(hole_values)
            min_card = min(hole_values)
            suited = hole_suits[0] == hole_suits[1]
            
            # Pocket pairs
            if hole_values[0] == hole_values[1]:
                return 0.5 + (hole_values[0] / 14) * 0.5
                
            # High cards
            strength = (max_card + min_card) / 28
            if suited:
                strength += 0.1
            if abs(hole_values[0] - hole_values[1]) <= 2:  # Connected cards
                strength += 0.05
                
            return min(strength, 1.0)
            
        # Post-flop evaluation
        all_cards = self.hole_cards + community_cards
        all_values = [card_value(card) for card in all_cards]
        all_suits = [card_suit(card) for card in all_cards]
        
        # Count occurrences
        value_counts = {}
        for v in all_values:
            value_counts[v] = value_counts.get(v, 0) + 1
            
        suit_counts = {}
        for s in all_suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
            
        # Check for various hands
        max_count = max(value_counts.values())
        has_flush = max(suit_counts.values()) >= 5
        
        sorted_values = sorted(set(all_values))
        has_straight = False
        for i in range(len(sorted_values) - 4):
            if sorted_values[i+4] - sorted_values[i] == 4:
                has_straight = True
                break
                
        # Special case for A-2-3-4-5 straight
        if set([14, 2, 3, 4, 5]).issubset(set(all_values)):
            has_straight = True
            
        # Determine hand ranking
        if has_flush and has_straight:
            return 0.95
        elif max_count == 4:
            return 0.92
        elif 3 in value_counts.values() and 2 in value_counts.values():
            return 0.87
        elif has_flush:
            return 0.84
        elif has_straight:
            return 0.80
        elif max_count == 3:
            return 0.70
        elif list(value_counts.values()).count(2) >= 2:
            return 0.60
        elif max_count == 2:
            # One pair - adjust strength based on pair value
            for v, count in value_counts.items():
                if count == 2 and v in hole_values:
                    return 0.35 + (v / 14) * 0.2
            return 0.40
        else:
            # High card - use hole cards strength
            return max(hole_values) / 14 * 0.3
            
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass