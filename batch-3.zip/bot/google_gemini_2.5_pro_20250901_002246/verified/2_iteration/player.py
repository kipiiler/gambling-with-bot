import random
from collections import Counter
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Card ranks and suits for parsing and evaluation
RANKS = '23456789TJQKA'
SUITS = 'shdc'
CARD_RANK_MAP = {rank: i for i, rank in enumerate(RANKS)}

class SimplePlayer(Bot):
    """
    A poker bot that uses Monte Carlo simulation to estimate hand equity and make decisions.
    It plays a Tight-Aggressive (TAG) style, being selective with starting hands
    and betting aggressively with strong holdings post-flop.
    Iteration 2: Implemented Monte Carlo, improved pre-flop ranges, and more dynamic betting.
    """

    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.big_blind_amount: int = 0
        self.all_players: List[int] = []
        self.big_blind_player_id: int = 0
        self.small_blind_player_id: int = 0
        # The number of simulations to run for equity calculation
        self.num_simulations = 1000

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """Called once at the start of a game."""
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the start of each round."""
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass

    # --- Helper methods for card and hand evaluation ---

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """Parses a card string like 'Ah' into a (rank_index, suit) tuple."""
        rank = CARD_RANK_MAP[card_str[0]]
        suit = card_str[1]
        return (rank, suit)

    def _score_5_card_hand(self, cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        """Scores a 5-card hand, returning (hand_rank, tiebreaker_ranks)."""
        if not cards or len(cards) != 5:
            return -1, []
            
        ranks = sorted([r for r, s in cards], reverse=True)
        suits = [s for r, s in cards]

        is_flush = len(set(suits)) == 1
        
        is_wheel = ranks == [CARD_RANK_MAP['A'], CARD_RANK_MAP['5'], CARD_RANK_MAP['4'], CARD_RANK_MAP['3'], CARD_RANK_MAP['2']]
        if is_wheel:
            # For scoring, treat Ace as low in a 5-high straight
            straight_ranks = [CARD_RANK_MAP['5'], CARD_RANK_MAP['4'], CARD_RANK_MAP['3'], CARD_RANK_MAP['2'], CARD_RANK_MAP['A']]
            is_straight = True
        else:
            is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)
            straight_ranks = ranks

        rank_counts = Counter(ranks)
        sorted_by_count = sorted(rank_counts.keys(), key=lambda r: (-rank_counts[r], -r))
        
        tiebreaker_ranks = []
        for r in sorted_by_count:
            tiebreaker_ranks.extend([r] * rank_counts[r])

        if is_straight and is_flush: return (8, straight_ranks)
        if 4 in rank_counts.values(): return (7, tiebreaker_ranks)
        if sorted(rank_counts.values()) == [2, 3]: return (6, tiebreaker_ranks)
        if is_flush: return (5, ranks)
        if is_straight: return (4, straight_ranks)
        if 3 in rank_counts.values(): return (3, tiebreaker_ranks)
        if list(sorted(rank_counts.values())) == [1, 2, 2]: return (2, tiebreaker_ranks)
        if 2 in rank_counts.values(): return (1, tiebreaker_ranks)
        return (0, ranks)

    def _evaluate_7_cards(self, seven_cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        """Finds the best 5-card hand from a list of 7 cards."""
        best_score = (-1, [])
        for hand_combo in combinations(seven_cards, 5):
            score = self._score_5_card_hand(list(hand_combo))
            if score > best_score:
                best_score = score
        return best_score

    # --- Pre-flop and Post-flop Strategy ---

    def _get_preflop_strength(self) -> float:
        """Calculates a pre-flop hand strength score (0-100)."""
        card1_str, card2_str = self.hand
        rank1 = CARD_RANK_MAP[card1_str[0]]
        rank2 = CARD_RANK_MAP[card2_str[0]]
        suit1, suit2 = card1_str[1], card2_str[1]
        
        high_card_val = {'A': 10, 'K': 8, 'Q': 7, 'J': 6}.get(RANKS[max(rank1, rank2)], max(rank1, rank2) / 2 + 1)
        
        score = high_card_val
        
        if rank1 == rank2:
            score = max(5, high_card_val * 2)
        if suit1 == suit2:
            score += 2

        gap = abs(rank1 - rank2)
        if rank1 != rank2:
            if gap == 1: score -= 0
            elif gap == 2: score -= 1
            elif gap == 3: score -= 2
            elif gap == 4: score -= 4
            else: score -= 5
        
        if rank1 == rank2 or gap < 2:
            score = round(score + 1)

        return (score / 20) * 100

    def _calculate_equity(self, community_cards: List[str], num_opponents: int) -> float:
        """Estimates hand equity using Monte Carlo simulation."""
        my_cards_parsed = [self._parse_card(c) for c in self.hand]
        community_cards_parsed = [self._parse_card(c) for c in community_cards]
        
        deck = [self._parse_card(r + s) for r in RANKS for s in SUITS]
        
        known_cards = set(my_cards_parsed + community_cards_parsed)
        deck = [card for card in deck if card not in known_cards]
        
        wins = 0
        ties = 0

        for _ in range(self.num_simulations):
            sim_deck = random.sample(deck, k=len(deck))

            opponents_hands = [sim_deck[i*2:i*2+2] for i in range(num_opponents)]
            
            num_cards_to_deal = 5 - len(community_cards_parsed)
            board_runout = community_cards_parsed + sim_deck[num_opponents*2 : num_opponents*2 + num_cards_to_deal]
            
            my_best_hand = self._evaluate_7_cards(my_cards_parsed + board_runout)

            is_winner = True
            is_tie = False
            for opp_hand in opponents_hands:
                opp_best_hand = self._evaluate_7_cards(opp_hand + board_runout)
                if opp_best_hand > my_best_hand:
                    is_winner = False
                    break
                elif opp_best_hand == my_best_hand:
                    is_tie = True

            if is_winner:
                if is_tie: ties += 1
                else: wins += 1
        
        return (wins + ties / 2.0) / self.num_simulations

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Main decision-making function for the bot."""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0

        # --- PRE-FLOP LOGIC ---
        if round_state.round == 'Preflop':
            strength = self._get_preflop_strength()
            is_raised = round_state.current_bet > self.big_blind_amount
            
            raise_threshold, call_threshold = (85, 60) if is_raised else (75, 45)

            if strength >= raise_threshold:
                raise_amount = 3 * self.big_blind_amount if not is_raised else (round_state.pot + 2 * amount_to_call)
                
                final_amount = min(max(int(raise_amount), round_state.min_raise), round_state.max_raise)
                
                if final_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                if final_amount > 0 and final_amount >= round_state.min_raise: return PokerAction.RAISE, final_amount
                return PokerAction.CALL, 0
                
            elif strength >= call_threshold:
                if amount_to_call < remaining_chips * 0.2:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            
            else:
                if can_check and self.id == self.big_blind_player_id: return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        # --- POST-FLOP LOGIC ---
        else:
            active_opponents = len([pid for pid, bet in round_state.player_bets.items() if round_state.player_actions.get(str(pid)) != 'Fold' and int(pid) != self.id])
            if active_opponents == 0:
                return PokerAction.CHECK, 0

            equity = self._calculate_equity(round_state.community_cards, active_opponents)
            
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-6)

            # 1. Aggressive play with strong hands
            if equity > 0.75:
                if can_check: # Bet
                    bet_amount = int(round_state.pot * 0.7) # Bet 70% of pot
                    final_amount = min(max(bet_amount, round_state.min_raise), round_state.max_raise)
                    if final_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                    if final_amount > 0: return PokerAction.RAISE, final_amount
                else: # Raise
                    raise_amount = int(round_state.pot + 2 * amount_to_call) # Pot-sized raise
                    final_amount = min(max(raise_amount, round_state.min_raise), round_state.max_raise)
                    if final_amount >= remaining_chips: return PokerAction.ALL_IN, 0
                    if final_amount >= round_state.min_raise: return PokerAction.RAISE, final_amount
            
            # 2. Passive play with medium/drawing hands
            if can_check:
                return PokerAction.CHECK, 0
            
            if equity > pot_odds:
                if amount_to_call < remaining_chips * 0.4:
                    return PokerAction.CALL, 0
            
            return PokerAction.FOLD, 0