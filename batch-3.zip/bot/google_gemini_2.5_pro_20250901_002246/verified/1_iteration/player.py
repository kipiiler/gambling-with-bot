import collections
import itertools
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that implements a tight-aggressive (TAG) strategy.
    - Pre-flop: Uses a hand tier system to decide whether to raise, call, or fold.
    - Post-flop: Evaluates hand strength and draws to make value bets, semi-bluffs, or folds.
    - Bet Sizing: Uses pot-relative bet sizes.
    - Risk Management: Avoids over-committing with marginal hands and folds to heavy aggression when weak.
    """

    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.all_players_ids: List[int] = []
        self._preflop_tiers = self._create_preflop_tiers()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called at the start of a game/hand.
        Assumption: The framework provides the bot's hand for the current game through `player_hands`.
        """
        self.hand = player_hands
        self.all_players_ids = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each betting round (Preflop, Flop, Turn, River).
        No action needed here as logic is in get_action.
        """
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is where the bot decides on an action.
        """
        try:
            my_bet_in_round = round_state.player_bets.get(str(self.id), 0)
            call_cost = round_state.current_bet - my_bet_in_round
            
            if round_state.round == 'Preflop':
                return self._get_preflop_action(round_state, remaining_chips, call_cost)
            else:
                return self._get_postflop_action(round_state, remaining_chips, call_cost)
        except Exception:
            # Fallback to a safe action in case of any unexpected errors.
            return self._safe_check_or_fold(round_state)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of a hand. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the entire simulation. """
        pass

    # --- Strategy Helper Methods ---

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, call_cost: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take pre-flop. """
        hand_tier = self._get_preflop_strength(self.hand)
        
        # A simple way to check if there has been a raise before us
        is_raised = round_state.current_bet > round_state.min_raise
        
        # Premium hands (Tiers 1-2): Always be aggressive.
        if hand_tier <= 2:
            if not is_raised:
                bet_amount = round_state.min_raise * 3
                return self._get_bet_action(round_state, remaining_chips, bet_amount)
            else:
                bet_amount = round_state.current_bet * 3
                return self._get_bet_action(round_state, remaining_chips, bet_amount)

        # Strong playable hands (Tiers 3-4)
        elif hand_tier <= 4:
            if not is_raised:
                bet_amount = int(round_state.min_raise * 2.5)
                return self._get_bet_action(round_state, remaining_chips, bet_amount)
            else:
                if call_cost > 0 and call_cost < remaining_chips * 0.1:
                    return PokerAction.CALL, 0
                return self._safe_check_or_fold(round_state)
        
        # Speculative hands (Tiers 5-6)
        elif hand_tier <= 6:
            if call_cost == 0:
                return PokerAction.CALL, 0
            # Call small raises if the price is right
            elif call_cost > 0 and call_cost < remaining_chips * 0.05:
                return PokerAction.CALL, 0
            else:
                return self._safe_check_or_fold(round_state)

        # Trash hands (Tier 7+)
        else:
            return self._safe_check_or_fold(round_state)

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, call_cost: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take post-flop. """
        all_cards = self.hand + round_state.community_cards
        hand_score, _ = self._evaluate_hand(all_cards)
        hand_rank = hand_score[0]
        
        outs, is_strong_draw = self._calculate_draws(self.hand, round_state.community_cards)

        # 1. Monster Hand (Three of a kind or better)
        if hand_rank >= 4:
            bet_ratio = 0.75 if round_state.round == 'River' else 0.6
            bet_amount = int(round_state.pot * bet_ratio)
            return self._get_bet_action(round_state, remaining_chips, bet_amount)

        # 2. Strong Hand (Two Pair)
        if hand_rank == 3:
            bet_amount = int(round_state.pot * 0.5)
            return self._get_bet_action(round_state, remaining_chips, bet_amount)

        # 3. Medium Hand (Top Pair)
        if hand_rank == 2:
            community_ranks = [self._card_to_value(c)[0] for c in round_state.community_cards]
            if community_ranks and hand_score[1] >= max(community_ranks): # is_top_pair
                if call_cost == 0:
                    bet_amount = int(round_state.pot * 0.4)
                    return self._get_bet_action(round_state, remaining_chips, bet_amount)
                else:
                    if call_cost < remaining_chips * 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
            else: # Middle or bottom pair
                return self._safe_check_or_fold(round_state)

        # 4. Strong Drawing Hand (Flop/Turn only)
        if outs > 7 and round_state.round != 'River':
            pot_odds = call_cost / (round_state.pot + call_cost + 1e-9)
            equity = (outs * 4 if round_state.round == 'Flop' else outs * 2) / 100.0

            if call_cost == 0 and is_strong_draw: # Semi-bluff
                bet_amount = int(round_state.pot * 0.5)
                return self._get_bet_action(round_state, remaining_chips, bet_amount)
            if call_cost > 0 and equity > pot_odds and call_cost < remaining_chips * 0.3:
                return PokerAction.CALL, 0
        
        # 5. Nothing / Weak Draw - Check/Fold
        return self._safe_check_or_fold(round_state)

    # --- Core Action and Evaluation Helpers ---
    
    def _safe_check_or_fold(self, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        can_check = round_state.current_bet <= my_bet
        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    def _get_bet_action(self, round_state: RoundStateClient, remaining_chips: int, amount: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        
        if amount >= remaining_chips + my_bet:
            return PokerAction.ALL_IN, 0
            
        final_amount = max(amount, round_state.min_raise)
        final_amount = min(final_amount, remaining_chips + my_bet)

        if final_amount <= round_state.current_bet:
            # Cannot make a valid raise. Decide between all-in or call.
            # If we still have chips to call, call. Otherwise, it's an all-in call.
            return (PokerAction.ALL_IN, 0) if remaining_chips + my_bet <= round_state.current_bet else (PokerAction.CALL, 0)
        
        return PokerAction.RAISE, final_amount

    def _card_to_value(self, card: str) -> Tuple[int, str]:
        val_str, suit = card[:-1], card[-1]
        vals = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return (vals.get(val_str) or int(val_str), suit)

    def _evaluate_hand(self, cards: List[str]) -> Tuple[Tuple, List[Tuple]]:
        parsed_cards = [self._card_to_value(c) for c in cards]
        best_score = (-1,)
        best_hand = []
        for combo in itertools.combinations(parsed_cards, 5):
            score, hand = self._score_5_card_hand(list(combo))
            if score > best_score:
                best_score, best_hand = score, hand
        return best_score, best_hand

    def _score_5_card_hand(self, hand: List[Tuple[int, str]]) -> Tuple[Tuple, List[Tuple[int, str]]]:
        ranks = sorted([c[0] for c in hand], reverse=True)
        suits = [c[1] for c in hand]
        is_flush = len(set(suits)) == 1
        is_straight = (ranks[0] - ranks[4] == 4 and len(set(ranks)) == 5) or (ranks == [14, 5, 4, 3, 2])
        
        if is_straight and is_flush: return (9, ranks[0] if ranks != [14, 5, 4, 3, 2] else 5), hand
        
        rank_counts = collections.Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts.keys(), key=lambda k: (rank_counts[k], k), reverse=True)

        if counts[0] == 4: return (8, main_ranks[0], main_ranks[1]), hand
        if counts == [3, 2]: return (7, main_ranks[0], main_ranks[1]), hand
        if is_flush: return (6, tuple(ranks)), hand
        if is_straight: return (5, ranks[0] if ranks != [14, 5, 4, 3, 2] else 5), hand
        if counts[0] == 3: return (4, main_ranks[0], tuple(r for r in main_ranks if r != main_ranks[0])), hand
        if counts == [2, 2, 1]: return (3, main_ranks[0], main_ranks[1], main_ranks[2]), hand
        if counts[0] == 2: return (2, main_ranks[0], tuple(r for r in main_ranks if r != main_ranks[0])), hand

        return (1, tuple(ranks)), hand

    def _calculate_draws(self, hole_cards: List[str], community: List[str]) -> Tuple[int, bool]:
        all_cards = [self._card_to_value(c) for c in hole_cards + community]
        ranks = {c[0] for c in all_cards}
        suits = collections.Counter(c[1] for c in all_cards)
        
        flush_outs = 9 if any(s == 4 for s in suits.values()) else 0
        is_strong_flush = flush_outs > 0 and any(self._card_to_value(hc)[1] in suits for hc in hole_cards)

        straight_outs = 0
        test_ranks = list(sorted(ranks))
        for i in range(len(test_ranks) - 3):
            is_gap = False
            is_o_ended = False
            # Check for 4 in a 5-card window
            if test_ranks[i+3] - test_ranks[i] < 5: straight_outs = max(straight_outs, 4) # gutshot
            if test_ranks[i+3] - test_ranks[i] == 3: is_o_ended = True # open-ended
            
            if is_o_ended: straight_outs = max(straight_outs, 8)

        # Wheel draw check
        if {2, 3, 4, 5}.issubset(ranks): straight_outs = max(straight_outs, 4)
        if {14, 2, 3, 4}.issubset(ranks): straight_outs = max(straight_outs, 4)

        if flush_outs and straight_outs: return flush_outs + straight_outs - 1, True
        return max(flush_outs, straight_outs), is_strong_flush or (straight_outs > 4)

    def _get_preflop_strength(self, hand: List[str]) -> int:
        c1, c2 = self._card_to_value(hand[0]), self._card_to_value(hand[1])
        r1, r2 = sorted([c1[0], c2[0]], reverse=True)
        is_suited = c1[1] == c2[1]
        
        rank_map = {v: k for k, v in self._card_to_value('A23456789TJQKX').items() if k != 'X'}
        rank_map.update({10:'T', 11:'J', 12:'Q', 13:'K', 14:'A'})
        
        hand_str = f"{rank_map[r1]}{rank_map[r2]}"
        if r1 != r2: hand_str += 's' if is_suited else 'o'
        
        for tier, hands in self._preflop_tiers.items():
            if hand_str in hands:
                return tier
        return 8

    def _create_preflop_tiers(self) -> Dict[int, List[str]]:
        return {
            1: ['AA', 'KK', 'QQ', 'JJ', 'AKs'],
            2: ['TT', 'AQs', 'AJs', 'KQs', 'AKo'],
            3: ['99', 'JTs', 'QJs', 'KJs', 'ATs', 'AQo'],
            4: ['88', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'AJo', 'KQo'],
            5: ['77', '66', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 'A4s', 'A3s', 'A2s', 'K9s', 'KJo', 'QJo', 'JTo'],
            6: ['55', '44', '33', '22', '87s', '76s', '65s', '54s', 'ATo', 'KTo', 'QTo'],
            7: ['A9o', 'A8o', 'A7o', 'K9o', 'Q9s', 'T8s', '97s', '86s', '75s', '64s', 'J9o', 'T9o', '98o'],
            8: [], # All other hands
        }