import collections
import itertools
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    An improved poker bot that uses hand strength evaluation, potential analysis (outs),
    and basic strategic concepts like pot odds and position.
    """

    def __init__(self):
        super().__init__()
        # Game-level state
        self.player_order: List[int] = []
        self.initial_stack = 10000
        self.big_blind_amount = 0

        # Round-level state
        self.hole_cards: List[str] = []
        
        # Hand evaluation constants
        self.RANKS = '23456789TJQKA'
        self.HAND_STRENGTH = {
            "HIGH_CARD": 0,
            "ONE_PAIR": 1,
            "TWO_PAIR": 2,
            "THREE_OF_A_KIND": 3,
            "STRAIGHT": 4,
            "FLUSH": 5,
            "FULL_HOUSE": 6,
            "FOUR_OF_A_KIND": 7,
            "STRAIGHT_FLUSH": 8
        }


    # --- Helper methods for card and hand evaluation ---

    def _parse_cards(self, cards_str: List[str]) -> List[Tuple[int, str]]:
        """ 'As' -> (14, 's') """
        rank_map = {r: i for i, r in enumerate(self.RANKS, 2)}
        return [(rank_map[c[0]], c[1]) for c in cards_str]

    def _evaluate_5_cards(self, cards: List[Tuple[int, str]]):
        """ Evaluates a 5-card hand and returns a comparable tuple (strength, kickers...). """
        ranks = sorted([c[0] for c in cards], reverse=True)
        suits = [c[1] for c in cards]

        is_flush = len(set(suits)) == 1
        # Ace-low straight check
        is_straight = len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)
        if not is_straight and ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]

        if is_straight and is_flush:
            return (self.HAND_STRENGTH["STRAIGHT_FLUSH"], ranks[0])

        rank_counts = collections.Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        main_ranks = sorted(rank_counts.keys(), key=lambda r: (rank_counts[r], r), reverse=True)
        
        if counts[0] == 4:
            return (self.HAND_STRENGTH["FOUR_OF_A_KIND"], main_ranks[0], main_ranks[1])
        if counts == [3, 2]:
            return (self.HAND_STRENGTH["FULL_HOUSE"], main_ranks[0], main_ranks[1])
        if is_flush:
            return (self.HAND_STRENGTH["FLUSH"], *ranks)
        if is_straight:
            return (self.HAND_STRENGTH["STRAIGHT"], ranks[0])
        if counts[0] == 3:
            return (self.HAND_STRENGTH["THREE_OF_A_KIND"], main_ranks[0], *main_ranks[1:])
        if counts == [2, 2, 1]:
            return (self.HAND_STRENGTH["TWO_PAIR"], main_ranks[0], main_ranks[1], main_ranks[2])
        if counts[0] == 2:
            return (self.HAND_STRENGTH["ONE_PAIR"], main_ranks[0], *main_ranks[1:])
        
        return (self.HAND_STRENGTH["HIGH_CARD"], *ranks)

    def _get_best_hand(self, hole_cards_str: List[str], community_cards_str: List[str]):
        """ Finds the best 5-card hand from 2 hole cards and 5 community cards. """
        if not hole_cards_str:
            return (-1,)

        all_cards_str = hole_cards_str + community_cards_str
        if len(all_cards_str) < 5:
            # Not enough cards to make a 5-card hand, evaluate what we have
             return self._evaluate_5_cards(self._parse_cards(all_cards_str))
             
        all_cards = self._parse_cards(all_cards_str)
        
        best_rank = (-1,)
        for hand_combo in itertools.combinations(all_cards, 5):
            rank = self._evaluate_5_cards(list(hand_combo))
            if rank > best_rank:
                best_rank = rank
        return best_rank

    def _get_hand_potential(self, hole_cards_str: List[str], community_cards_str: List[str]):
        """ Calculates outs for straight and flush draws. """
        hole_cards = self._parse_cards(hole_cards_str)
        community_cards = self._parse_cards(community_cards_str)
        all_cards = hole_cards + community_cards
        
        # Flush outs
        suit_counts = collections.Counter(c[1] for c in all_cards)
        flush_outs = 0
        for suit, count in suit_counts.items():
            if count == 4:
                flush_outs = 13 - 4  # 9 outs
                break
        
        # Straight outs
        ranks = sorted(list(set(c[0] for c in all_cards)))
        straight_outs = 0
        
        # Open-ended straight draw
        for i in range(len(ranks) - 2):
            # Check for 4-in-a-row with gaps
            possible_straights = []
            for start_rank in range(ranks[0]-4, ranks[-1]+1):
                if start_rank <= 0 : continue
                end_rank = start_rank + 4
                
                present_cards = [r for r in ranks if start_rank <= r <= end_rank]
                if len(present_cards) == 4:
                    # Find the missing card
                    missing_rank = sum(range(start_rank, end_rank+1)) - sum(present_cards)
                    if not any(c[0] == missing_rank for c in all_cards): # not already on board
                      if start_rank > 1 and end_rank < 14: # Open ended
                          straight_outs = max(straight_outs, 8)
                      else: # Gutshot
                          straight_outs = max(straight_outs, 4)

        # Basic gutshot check
        if straight_outs == 0:
            for i in range(len(ranks) - 3):
                if ranks[i+3] - ranks[i] == 3 and len(set(ranks[i:i+4])) == 4: # 4 of 5 for a straight
                    straight_outs = max(straight_outs, 4)
                if ranks[i+3] - ranks[i] == 4 and len(set(ranks[i:i+4])) == 4: # e.g., 5 7 8 9
                    straight_outs = max(straight_outs, 4)

        # TODO: Avoid double counting straight flush outs. For now, sum is a decent heuristic.
        return flush_outs + straight_outs

    def _chen_score(self, hole_cards_str: List[str]):
        """ Calculates a pre-flop starting hand score based on the Chen Formula. """
        cards = self._parse_cards(hole_cards_str)
        c1, c2 = cards[0], cards[1]
        r1, r2 = sorted([c1[0], c2[0]], reverse=True)

        score = 0.0
        if r1 == 14: score = 10
        elif r1 == 13: score = 8
        elif r1 == 12: score = 7
        elif r1 == 11: score = 6
        else: score = r1 / 2.0
        
        if r1 == r2: # Pair
            score = max(5, score * 2)
        
        if c1[1] == c2[1]: # Suited
            score += 2
        
        gap = r1 - r2
        if gap == 1: pass
        elif gap == 2: score -= 1
        elif gap == 3: score -= 2
        elif gap == 4: score -= 4
        else: score -= 5
        
        if gap <= 1 and r1 < 12:
            score += 1
            
        return score

    # --- Bot Lifecycle Methods ---

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.initial_stack = starting_chips
        self.player_order = all_players
        # This hand is for the first round. self.player_hands from the framework is used for subsequent rounds.
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Assuming the framework updates self.player_hands before this call
        if hasattr(self, 'player_hands'):
            self.hole_cards = self.player_hands
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # --- 1. Information Gathering ---
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        can_check = call_amount == 0
        pot_size = round_state.pot
        epsilon = 1e-6
        pot_odds = call_amount / (pot_size + call_amount + epsilon) if call_amount > 0 else 0
        
        active_players = [p for p in round_state.player_bets if round_state.player_actions.get(p) != 'Fold']
        num_active_players = len(active_players)

        # --- 2. Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            score = self._chen_score(self.hole_cards)
            has_raised = round_state.current_bet > self.big_blind_amount
            
            # Heads-up logic is looser
            is_heads_up = num_active_players <= 2

            # Define thresholds
            raise_threshold = 9 if not is_heads_up else 7
            call_threshold = 6 if not is_heads_up else 4
            
            # Action logic
            if score >= raise_threshold:
                if not has_raised:
                    # Open raise
                    raise_amount = int(self.big_blind_amount * 2.5)
                else:
                    # 3-bet
                    raise_amount = int(round_state.current_bet * 3)
                
                raise_amount = max(round_state.min_raise, raise_amount)
                if raise_amount < round_state.max_raise:
                     return PokerAction.RAISE, min(raise_amount, round_state.max_raise)
                return PokerAction.ALL_IN, 0

            if score >= call_threshold and has_raised and call_amount < remaining_chips * 0.1:
                return PokerAction.CALL, 0
            
            if not has_raised and self.id in [self.small_blind_player_id, self.big_blind_player_id]:
                return PokerAction.CHECK, 0
            
            if can_check:
                return PokerAction.CHECK, 0
            
            # Check big blind option
            if self.id == self.big_blind_player_id and not has_raised:
                return PokerAction.CHECK, 0
            
            return PokerAction.FOLD, 0
            
        # --- 3. Post-flop Strategy ---
        hand_rank_tuple = self._get_best_hand(self.hole_cards, round_state.community_cards)
        hand_strength = hand_rank_tuple[0]

        outs = self._get_hand_potential(self.hole_cards, round_state.community_cards)
        equity = 0
        if round_state.round == 'Flop':
            equity = outs * 4 / 100.0
        elif round_state.round == 'Turn':
            equity = outs * 2 / 100.0

        # Hand classification
        hand_category = 'AIR'
        if hand_strength >= self.HAND_STRENGTH["FULL_HOUSE"]:
            hand_category = 'MONSTER'
        elif hand_strength >= self.HAND_STRENGTH["STRAIGHT"]:
            hand_category = 'VERY_STRONG'
        elif hand_strength >= self.HAND_STRENGTH["TWO_PAIR"]:
            hand_category = 'STRONG'
        elif hand_strength >= self.HAND_STRENGTH["ONE_PAIR"]:
            hand_category = 'MEDIUM'
        
        is_drawing = equity > 0.15 # ~>4 outs on turn, ~8 outs on flop

        # Board texture
        community = self._parse_cards(round_state.community_cards)
        board_suits = [c[1] for c in community]
        board_is_wet = len(set(board_suits)) <= 2 or len(community) >=3 and max(c[0] for c in community) - min(c[0] for c in community) < 5


        # --- Action Decision ---
        if can_check:
            if hand_category in ['MONSTER', 'VERY_STRONG']:
                bet = int(pot_size * 0.75) if board_is_wet else int(pot_size * 0.5)
            elif hand_category == 'STRONG':
                bet = int(pot_size * 0.5)
            elif is_drawing and hand_category == 'AIR': # Semi-bluff
                 bet = int(pot_size * 0.6)
            else: # Medium hands and air
                return PokerAction.CHECK, 0
            
            bet = max(self.big_blind_amount, bet) # Bet at least one BB
            if bet > 0 and remaining_chips > bet:
                return PokerAction.RAISE, min(bet, remaining_chips)
            return PokerAction.CHECK, 0

        else: # Facing a bet
            if hand_category == 'MONSTER':
                raise_amount = int(round_state.current_bet * 2.5 + pot_size)
                if raise_amount < round_state.max_raise:
                    return PokerAction.RAISE, min(raise_amount, round_state.max_raise)
                return PokerAction.ALL_IN, 0

            if hand_category == 'VERY_STRONG':
                if board_is_wet or round_state.round == 'River':
                    raise_amount = int(round_state.current_bet * 2.2)
                    if round_state.min_raise > 0 and raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, min(raise_amount, round_state.max_raise)
                return PokerAction.CALL, 0
            
            # Strong/Medium hands and draws decide based on pot odds
            if equity > pot_odds: # Drawing to a better hand
                if equity > 0.3 and num_active_players <= 2: # Strong draw, can semi-bluff raise
                    raise_amount = int(round_state.current_bet * 2)
                    if round_state.min_raise > 0 and raise_amount >= round_state.min_raise:
                        return PokerAction.RAISE, min(raise_amount, round_state.max_raise)
                return PokerAction.CALL, 0 # Just call
            
            if hand_category in ['STRONG', 'MEDIUM'] and equity <= pot_odds:
                # Call if bet is not too large
                if call_amount < pot_size * 0.5:
                    return PokerAction.CALL, 0

            return PokerAction.FOLD, 0
            

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass