import random
from typing import List, Tuple
from collections import Counter
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Helper functions for card/hand evaluation ---

CARD_RANKS = '23456789TJQKA'

def parse_card(card_str: str) -> tuple[int, str]:
    """Parses a card string like 'Kh' into (rank, suit) tuple, e.g., (13, 'h')."""
    if len(card_str) < 2:
        return 0, ''
    rank_str = card_str[:-1]
    suit = card_str[-1]
    rank = CARD_RANKS.find(rank_str) + 2
    return rank, suit

def score_hand(hand: list[tuple[int, str]]) -> tuple[int, list[int]]:
    """
    Scores a 5-card hand and returns a comparable tuple (hand_rank, tiebreaker_ranks).
    Higher hand_rank is better. Hand Ranks: 8=Straight Flush, 7=Quads, 6=Full House,
    5=Flush, 4=Straight, 3=Trips, 2=Two Pair, 1=Pair, 0=High Card.
    """
    if not hand or len(hand) != 5:
        return -1, []

    ranks = sorted([c[0] for c in hand], reverse=True)
    suits = {c[1] for c in hand}

    is_flush = len(suits) == 1
    is_straight = (len(set(ranks)) == 5 and (max(ranks) - min(ranks) == 4)) or \
                  (ranks == [14, 5, 4, 3, 2])
    
    score_ranks = [5, 4, 3, 2, 1] if ranks == [14, 5, 4, 3, 2] else ranks
    rank_counts = Counter(ranks)
    counts = sorted(rank_counts.values(), reverse=True)
    
    if is_straight and is_flush: return 8, score_ranks
    if counts[0] == 4:
        quad_rank = next(r for r, c in rank_counts.items() if c == 4)
        kicker = next(r for r, c in rank_counts.items() if c == 1)
        return 7, [quad_rank, kicker]
    if counts == [3, 2]:
        trip_rank = next(r for r, c in rank_counts.items() if c == 3)
        pair_rank = next(r for r, c in rank_counts.items() if c == 2)
        return 6, [trip_rank, pair_rank]
    if is_flush: return 5, ranks
    if is_straight: return 4, score_ranks
    if counts[0] == 3:
        trip_rank = next(r for r, c in rank_counts.items() if c == 3)
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return 3, [trip_rank] + kickers
    if counts == [2, 2, 1]:
        pair_ranks = sorted([r for r, c in rank_counts.items() if c == 2], reverse=True)
        kicker = next(r for r, c in rank_counts.items() if c == 1)
        return 2, pair_ranks + [kicker]
    if counts[0] == 2:
        pair_rank = next(r for r, c in rank_counts.items() if c == 2)
        kickers = sorted([r for r, c in rank_counts.items() if c == 1], reverse=True)
        return 1, [pair_rank] + kickers
    return 0, ranks

def evaluate_best_hand(hole_cards: list[str], community_cards: list[str]) -> tuple[int, list[int]]:
    """Evaluates the best 5-card hand from the given hole and community cards."""
    all_cards_str = hole_cards + community_cards
    if len(all_cards_str) < 5:
        parsed = [parse_card(c) for c in all_cards_str]
        # Pad with dummy cards to allow scoring
        parsed += [(0, '')] * (5 - len(parsed))
        return score_hand(parsed)

    all_cards = [parse_card(c) for c in all_cards_str]
    
    best_score = (-1, [])
    for hand_combo in combinations(all_cards, 5):
        score = score_hand(list(hand_combo))
        if score > best_score:
            best_score = score
            
    return best_score

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.num_players: int = 0
        self.big_blind_amount: int = 20

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.num_players = len(all_players)
        # Assume blind_amount is the small blind, a common convention.
        self.big_blind_amount = blind_amount * 2

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        can_check = round_state.current_bet == my_bet
        to_call = round_state.current_bet - my_bet

        if round_state.round == 'Preflop':
            card1, card2 = self.hand
            rank1, rank2 = sorted([parse_card(c)[0] for c in self.hand], reverse=True)
            is_suited = parse_card(card1)[1] == parse_card(card2)[1]
            is_pair = rank1 == rank2
            
            # Heads-up is looser
            is_headsup = self.num_players <= 2

            # Premium hands (raise)
            if (is_pair and rank1 >= (10 if is_headsup else 11)) or \
               (rank1 >= 13 and rank2 >= (11 if is_headsup else 12)): # TT+/JJ+, AK/AQ
                return self._get_raise_action(round_state, remaining_chips, multiplier=3)
            
            # Strong hands (raise)
            if (is_pair and rank1 >= 7) or \
               (is_suited and rank1 >= 10) or \
               (rank1 >= 11 and rank2 >= 10): # 77+, T+ suited, KJo+
                if to_call == 0:
                    return self._get_raise_action(round_state, remaining_chips, multiplier=2.5)
            
            # Speculative hands (call small raises)
            if is_pair or is_suited or (rank1 - rank2 <= 4): 
                if to_call > 0 and to_call <= self.big_blind_amount * (3 if is_headsup else 2):
                    return PokerAction.CALL, 0
                
            if can_check:
                return PokerAction.CHECK, 0
            
            return PokerAction.FOLD, 0
            
        # --- Post-flop Strategy ---
        hand_score = evaluate_best_hand(self.hand, round_state.community_cards)
        hand_rank = hand_score[0]
        outs = self._calculate_outs(self.hand, round_state.community_cards)

        # Tier 1: Monster hands (Trips or better)
        if hand_rank >= 3:
            if can_check:
                return self._get_raise_action(round_state, remaining_chips, pot_fraction=0.75)
            else:
                return self._get_raise_action(round_state, remaining_chips, multiplier=3)

        # Tier 2: Strong Made Hands (Two Pair)
        if hand_rank == 2:
            if can_check:
                return self._get_raise_action(round_state, remaining_chips, pot_fraction=0.6)
            else:
                if to_call > 0 and to_call < round_state.pot * 0.75:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Tier 3: Good Made Hands (Top Pair / Overpair)
        if hand_rank == 1:
            board_ranks = [parse_card(c)[0] for c in round_state.community_cards]
            my_pair_rank = hand_score[1][0]
            is_top_or_overpair = not board_ranks or my_pair_rank >= max(board_ranks)
            if is_top_or_overpair:
                if can_check:
                    return self._get_raise_action(round_state, remaining_chips, pot_fraction=0.5)
                elif to_call > 0 and to_call < round_state.pot * 0.5:
                    return PokerAction.CALL, 0
                else: return PokerAction.FOLD, 0

        # Tier 4: Strong Draws (8+ outs)
        if outs >= 8 and round_state.round != 'River':
            if can_check:
                return self._get_raise_action(round_state, remaining_chips, pot_fraction=0.6) # Semi-bluff
            else:
                pot_odds = to_call / (round_state.pot + to_call + 1e-9)
                equity = (outs * 4) / 100.0 if round_state.round == 'Flop' else (outs * 2) / 100.0
                if equity > pot_odds:
                    return PokerAction.CALL, 0
        
        # Tier 5: Weak hands / Weak draws / Trash
        if can_check:
            return PokerAction.CHECK, 0
        
        # Consider a bluff-catch for a very small bet
        if to_call > 0 and to_call <= self.big_blind_amount:
            # Only call with some potential (gutshot or a pair)
            if outs > 0 or hand_rank >= 1:
                return PokerAction.CALL, 0

        return PokerAction.FOLD, 0

    def _get_raise_action(self, round_state: RoundStateClient, remaining_chips: int, multiplier: float = 0, pot_fraction: float = 0) -> Tuple[PokerAction, int]:
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        if max_raise == 0: # Can't raise (e.g. opponent all-in for less)
            return (PokerAction.CALL, 0) if round_state.current_bet > round_state.player_bets.get(str(self.id), 0) else (PokerAction.CHECK, 0)
        
        raise_target = 0
        if pot_fraction > 0:
            raise_target = int(round_state.pot * pot_fraction)
        elif multiplier > 0:
            if round_state.round == "Preflop" and round_state.current_bet == self.big_blind_amount:
                raise_target = int(self.big_blind_amount * multiplier)
            else:
                # Re-raise: raise TO a multiple of the current total bet
                raise_target = int(round_state.current_bet * multiplier)
        
        final_amount = max(min_raise, min(raise_target, max_raise))
        
        if final_amount >= remaining_chips:
            return PokerAction.ALL_IN, 0
        
        return PokerAction.RAISE, int(final_amount)

    def _calculate_outs(self, hole_cards: list[str], community_cards: list[str]) -> int:
        if len(community_cards) >= 5: return 0
            
        all_cards = [parse_card(c) for c in hole_cards + community_cards]
        
        # Flush draw outs
        suits = [c[1] for c in all_cards]
        suit_counts = Counter(suits)
        flush_outs = 9 if 4 in suit_counts.values() else 0

        # Straight draw outs
        ranks = sorted(list(set(c[0] for c in all_cards)))
        if 14 in ranks: ranks.append(1) # Add ace as 1 for A-5 straights

        # OESD
        for i in range(len(ranks) - 3):
            is_consecutive_4 = ranks[i+3] - ranks[i] == 3 and len(set(ranks[i:i+4])) == 4
            if is_consecutive_4: return 8 # Found open-ended straight draw
        
        # Gutshot
        for i in range(len(ranks) - 3):
             # 4 cards in a 5-rank window like 4-5-7-8
            is_gutshot = ranks[i+3] - ranks[i] == 4 and len(set(ranks[i:i+4])) == 4
            if is_gutshot: return 4
            
        return max(flush_outs, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass