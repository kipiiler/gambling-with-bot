# player.py
from __future__ import annotations

import random
from typing import Dict, List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Try to import the treys hand-evaluation library.  It is pure Python
# and declared in requirements.txt.  If the import fails for any reason
# (e.g. package installation problem) we fall back to a very coarse
# strength heuristic so that the bot continues to run without crashing.
try:
    from treys import Card, Evaluator
    _TREYS_AVAILABLE = True
    _EVALUATOR = Evaluator()
except ImportError:                           # pragma: no cover
    _TREYS_AVAILABLE = False
    _EVALUATOR = None


# --------------------------------------------------------------------------- #
# Utility helpers                                                             #
# --------------------------------------------------------------------------- #
_RANK_ORDER = "23456789TJQKA"
_RANK_VALUE: Dict[str, int] = {r: i for i, r in enumerate(_RANK_ORDER, 2)}


def _card_str_to_treys(card: str) -> int:
    """
    Convert a single card in engine format (e.g. 'Ah', 'Td', '3s') to
    the integer encoding that treys uses.
    """
    # treys accepts the same 2-char string representation
    return Card.new(card)


def _hand_strength_with_treys(
    hole_cards: List[str],
    board: List[str],
) -> float:
    """
    Returns an approximate winning probability in the range [0, 1] using
    treys' 7-card evaluator (lower score is better, so we invert it).
    """
    hole = [_card_str_to_treys(c) for c in hole_cards]
    community = [_card_str_to_treys(c) for c in board]
    score = _EVALUATOR.evaluate(community, hole)
    # 1   is best, 7462 is worst
    return (7463 - score) / 7462.0


def _preflop_category(hole_cards: List[str]) -> str:
    """
    Very small pre-flop categorisation.  Returns one of:
        'premium', 'strong', 'medium', 'speculative', 'trash'
    """
    if len(hole_cards) != 2:
        return "trash"

    r1, s1 = hole_cards[0][0], hole_cards[0][1]
    r2, s2 = hole_cards[1][0], hole_cards[1][1]
    suited = s1 == s2
    ranks_sorted = "".join(sorted([r1, r2], key=lambda x: _RANK_VALUE[x], reverse=True))

    if ranks_sorted == "AA":
        return "premium"
    if ranks_sorted in ("KK", "QQ", "JJ"):
        return "premium"
    if suited and ranks_sorted in ("AK", "AQ", "AJ", "KQ"):
        return "strong"
    if ranks_sorted in ("AK", "AQ"):
        return "strong"
    if ranks_sorted in ("TT", "99", "88", "77"):
        return "medium"
    if suited and ranks_sorted in ("AT", "KJ", "QJ", "JT", "T9"):
        return "medium"
    if suited or abs(_RANK_VALUE[r1] - _RANK_VALUE[r2]) == 1:
        return "speculative"
    return "trash"


def _safe_div(num: float, denom: float, eps: float = 1e-9) -> float:
    return num / (denom + eps)


# --------------------------------------------------------------------------- #
# SimplePlayer implementation                                                 #
# --------------------------------------------------------------------------- #
class SimplePlayer(Bot):
    """
    A tight-aggressive No-Limit Hold'em bot that uses a mixture of
    simple pre-flop heuristics and post-flop hand evaluation via the
    'treys' library (when available).  The bot carefully validates every
    action to avoid illegal moves that would cause an automatic fold.
    """

    def __init__(self):
        super().__init__()

        # Static game information (set in `on_start`)
        self.starting_stack: int = 0
        self.big_blind_amount: int = 0

        # Dynamic per-hand information
        self.hole_cards: List[str] = []
        self.round_number: int = 0

        # Statistics (optional, could be used for future improvements)
        self.total_hands_played: int = 0
        self.win_loss: int = 0

        random.seed()

    # --------------------------------------------------------------------- #
    # Interface methods                                                     #
    # --------------------------------------------------------------------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        """
        Called once at the beginning of the match.
        """
        self.starting_stack = starting_chips
        self.big_blind_amount = blind_amount
        # Save our first hand if given
        if player_hands and isinstance(player_hands[0], str):
            self.hole_cards = player_hands
        else:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Engine calls this at the beginning of every hand.  We extract
        our two private cards if they are available.
        """
        self.round_number = round_state.round_num
        self.total_hands_played += 1

        # Attempt to fetch our hole cards from the round_state.
        if hasattr(round_state, "player_hands"):
            # player_hands is expected to be a dict {player_id: [c1, c2]}
            # Player IDs might be ints or str, so try both.
            ph = round_state.player_hands
            my_cards = (
                ph.get(self.id)
                or ph.get(str(self.id))
                or ph.get(int(self.id) if isinstance(self.id, str) else None)
            )
            if isinstance(my_cards, list) and len(my_cards) == 2:
                self.hole_cards = my_cards
            else:
                self.hole_cards = []
        # Fallback – if the engine still sends the cards through
        # `community_cards` when pre-flop, detect that pattern:
        elif round_state.community_cards == [] and len(self.hole_cards) != 2:
            self.hole_cards = []

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine.  Always returns a *legal* action.  The
        second element of the tuple is the size for RAISE (ignored for
        other actions).
        """
        # ---------------------------------------------------------------- #
        # Information extraction                                           #
        # ---------------------------------------------------------------- #
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(round_state.current_bet - my_bet, 0)

        pot_size = round_state.pot
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        can_check = to_call == 0
        stage = round_state.round  # "Preflop", "Flop", ...

        # ---------------------------------------------------------------- #
        # Hand strength estimation                                         #
        # ---------------------------------------------------------------- #
        if stage.lower() == "preflop":
            category = _preflop_category(self.hole_cards)
            # Translate category into an approximate strength number [0,1]
            category_strength = {
                "premium": 0.95,
                "strong": 0.80,
                "medium": 0.60,
                "speculative": 0.45,
                "trash": 0.20,
            }
            strength = category_strength.get(category, 0.20)
        else:
            # Post-flop strength using evaluator if available, otherwise
            # a crude heuristic based on number of community cards.
            if _TREYS_AVAILABLE and len(self.hole_cards) == 2:
                strength = _hand_strength_with_treys(
                    self.hole_cards, round_state.community_cards
                )
            else:
                # Crude fallback: later streets are more certain
                base = {"flop": 0.35, "turn": 0.45, "river": 0.55}
                strength = base.get(stage.lower(), 0.40)

        # ---------------------------------------------------------------- #
        # Decision logic                                                   #
        # ---------------------------------------------------------------- #
        # Pot odds comparison
        call_equity_needed = _safe_div(to_call, pot_size + to_call) if to_call else 0

        # 1. Pre-decision: if we can check and strength isn't amazing, just check.
        if can_check and strength < 0.75:
            return (PokerAction.CHECK, 0)

        # 2. Decide whether to fold/call/raise
        if to_call > 0:
            # Evaluate whether calling is profitable given strength
            if strength < call_equity_needed - 0.05:
                # Not enough equity – fold
                return (PokerAction.FOLD, 0)

            # We will at least call
            action_if_call_only = (PokerAction.CALL, 0)
        else:
            action_if_call_only = (PokerAction.CHECK, 0)

        # Decide on aggression based on strength
        if strength > 0.85:
            # Very strong – shove or large raise
            if remaining_chips <= max_raise * 1.2 or random.random() < 0.5:
                return (PokerAction.ALL_IN, 0)
            raise_amount = min(max_raise, max(min_raise, int(pot_size * 0.75 + to_call)))
            return (PokerAction.RAISE, raise_amount)

        if strength > 0.70:
            # Strong – make a solid raise
            raise_amount = max(min_raise, int(pot_size * 0.5 + to_call))
            raise_amount = min(raise_amount, max_raise)
            if raise_amount > to_call and raise_amount >= min_raise:
                return (PokerAction.RAISE, raise_amount)

        if strength > 0.45:
            # Medium strength – just call (or check)
            return action_if_call_only

        # Weak hand path
        if can_check:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Store simple results for later analysis.
        """
        # Detect win/loss
        if remaining_chips > self.starting_stack:
            self.win_loss += 1
        elif remaining_chips < self.starting_stack:
            self.win_loss -= 1
        # Reset hand specific data
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        """
        Final reporting hook – currently unused.
        """
        pass