# player.py
import random
import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

RANK_ORDER = "23456789TJQKA"
RANK_VALUE = {r: i for i, r in enumerate(RANK_ORDER, start=2)}
STRAIGHTS = [set(RANK_ORDER[i:i + 5]) for i in range(9)] + [set("A2345")]


def card_rank(card: str) -> str:
    return card[0]


def card_suit(card: str) -> str:
    return card[1]


def hand_rank_5(cards: List[str]) -> Tuple:
    """Return a sortable rank for 5-card hand."""
    ranks = sorted([RANK_VALUE[card_rank(c)] for c in cards], reverse=True)
    counts = {r: ranks.count(r) for r in set(ranks)}
    is_flush = len({card_suit(c) for c in cards}) == 1
    unique_ranks = ''.join(sorted({card_rank(c) for c in cards}, key=lambda x: RANK_VALUE[x], reverse=True))
    is_straight = set(unique_ranks) in STRAIGHTS
    # Ace-low straight adjustment
    if set(unique_ranks) == set("A5432"):
        straight_high = 5
    else:
        straight_high = max(ranks)

    # Build rank tuple
    if is_straight and is_flush:
        return (8, straight_high)  # Straight flush
    # Four of a kind
    if 4 in counts.values():
        four = max([r for r, c in counts.items() if c == 4])
        kicker = max([r for r in ranks if r != four])
        return (7, four, kicker)
    # Full house
    if sorted(counts.values()) == [2, 3]:
        three = max([r for r, c in counts.items() if c == 3])
        two = max([r for r, c in counts.items() if c == 2])
        return (6, three, two)
    # Flush
    if is_flush:
        return (5, ranks)
    # Straight
    if is_straight:
        return (4, straight_high)
    # Three of kind
    if 3 in counts.values():
        three = max([r for r, c in counts.items() if c == 3])
        kickers = sorted([r for r in ranks if r != three], reverse=True)[:2]
        return (3, three, kickers)
    # Two pair
    if list(counts.values()).count(2) == 2:
        pairs = sorted([r for r, c in counts.items() if c == 2], reverse=True)
        kicker = max([r for r in ranks if r not in pairs])
        return (2, pairs, kicker)
    # One pair
    if 2 in counts.values():
        pair = max([r for r, c in counts.items() if c == 2])
        kickers = sorted([r for r in ranks if r != pair], reverse=True)[:3]
        return (1, pair, kickers)
    # High card
    return (0, ranks)


def best_hand_rank(cards: List[str]) -> Tuple:
    """Return best 5-card hand rank from 7 or fewer cards."""
    best = (-1,)
    for combo in itertools.combinations(cards, 5):
        rank = hand_rank_5(list(combo))
        if rank > best:
            best = rank
    return best


def simulate_equity(hole: List[str], community: List[str], players: int, iterations: int = 300) -> float:
    """Monte Carlo equity estimation versus (players-1) random hands."""
    deck = [r + s for r in RANK_ORDER for s in "cdhs"]
    known = set(hole + community)
    deck = [c for c in deck if c not in known]
    wins = ties = 0
    for _ in range(iterations):
        random.shuffle(deck)
        opp_hands = [deck[i * 2:(i + 1) * 2] for i in range(players - 1)]
        remaining = deck[2 * (players - 1):]
        needed = 5 - len(community)
        board = community + remaining[:needed]
        our_rank = best_hand_rank(hole + board)
        opp_ranks = [best_hand_rank(h + board) for h in opp_hands]
        best_rank = max([our_rank] + opp_ranks)
        if our_rank == best_rank and opp_ranks.count(best_rank) == 0:
            wins += 1
        elif our_rank == best_rank:
            ties += 1
    total = iterations
    return (wins + ties / 2) / max(total, 1)


def preflop_strength(card1: str, card2: str) -> float:
    """Simple heuristic preflop strength (0-1)."""
    r1, r2 = card_rank(card1), card_rank(card2)
    s1, s2 = card_suit(card1), card_suit(card2)
    v1, v2 = RANK_VALUE[r1], RANK_VALUE[r2]
    pair = r1 == r2
    suited = s1 == s2
    gap = abs(RANK_ORDER.index(r1) - RANK_ORDER.index(r2)) - 1
    high_card = max(v1, v2)
    score = 0
    if pair:
        score = (v1 - 1) / 12  # 2..A -> 1..13
    else:
        score = (high_card - 2) / 12
        score -= gap * 0.05
        if suited:
            score += 0.1
    return max(0.0, min(1.0, score))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.hole_cards: List[str] = []
        self.total_players = 2

    # -------------------- CALLBACKS -------------------- #

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.total_players = len(all_players)
        self.hole_cards = player_hands or []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards if available in round_state
        try:
            self.hole_cards = round_state.player_hands.get(str(self.id), self.hole_cards)
        except AttributeError:
            pass  # Not provided; keep last known (heads-up simulation)

    # -------------------- MAIN DECISION -------------------- #

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            pot = round_state.pot
            call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            community = round_state.community_cards

            # Fallback: if somehow we lost track of our cards, fold safely
            if len(self.hole_cards) != 2:
                return PokerAction.FOLD, 0

            stage = round_state.round.lower()  # "preflop", "flop", "turn", "river"
            if stage == "preflop":
                win_prob = preflop_strength(*self.hole_cards)
            else:
                simulations = 300 if stage == "flop" else 500 if stage == "turn" else 700
                win_prob = simulate_equity(self.hole_cards, community, self.total_players, iterations=simulations)

            # Pot odds
            pot_odds = call_amount / (pot + call_amount + 1e-9) if call_amount > 0 else 0

            # Decision Logic
            # 1. If no bet to us
            if call_amount == 0:
                if win_prob > 0.65 and min_raise <= remaining_chips:  # value bet
                    raise_amount = max(min_raise, int(pot * 0.75))
                    raise_amount = min(raise_amount, max_raise)
                    # Occasionally slow-play very strong hands
                    if random.random() < 0.2:
                        return PokerAction.CHECK, 0
                    return PokerAction.RAISE, raise_amount
                else:
                    return PokerAction.CHECK, 0
            # 2. Faced with bet
            else:
                # Fold if hand doesn't meet pot odds with margin
                if win_prob < pot_odds + 0.05:
                    # If our stack is short, sometimes gamble
                    if remaining_chips < self.blind_amount * 10 and random.random() < 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

                # Call if marginally ahead
                if win_prob < 0.65 or min_raise > remaining_chips:
                    # Occasionally raise as bluff/semi-bluff (balanced)
                    if 0.55 < win_prob < 0.6 and random.random() < 0.15 and min_raise <= remaining_chips:
                        raise_amt = max(min_raise, int(pot * 0.5))
                        raise_amt = min(raise_amt, max_raise)
                        return PokerAction.RAISE, raise_amt
                    return PokerAction.CALL, 0

                # Strong hand -> raise / shove
                raise_amt = max(min_raise, int(pot * 1.0))
                if raise_amt >= remaining_chips:
                    return PokerAction.ALL_IN, 0
                raise_amt = min(raise_amt, max_raise)
                return PokerAction.RAISE, raise_amt
        except Exception:
            # In case of unexpected error, fold to avoid crash
            return PokerAction.FOLD, 0

    # -------------------- END OF ROUND / GAME -------------------- #

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []  # reset for next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: Dict, active_players_hands: Dict):
        pass