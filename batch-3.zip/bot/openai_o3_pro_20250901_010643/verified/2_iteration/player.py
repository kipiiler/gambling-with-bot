# player.py
from __future__ import annotations
import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- we depend on the pure-python ‘treys’ library for hand evaluation ----
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A very small-footprint No-Limit Texas Hold’em bot.

    Strategy synopsis
    -----------------
    1. Estimate the equity (win probability) of our hand against a table of
       random hands using Monte-Carlo simulations and the “treys” evaluator.
       The number of simulations adapts to the stage of the hand so that we
       stay well below the 30 s / move limit (< 50 ms in practice).

    2. Map the equity and the cost-to-continue into one of four simple actions
       (fold, check, call, or raise).  When we raise we do so for either the
       minimum allowed amount or — if our hand is very strong — for our entire
       stack (all-in).

    3. The thresholds are intentionally conservative to avoid costly mistakes
       while still capitalising on strong situations.
    """

    # --- configuration constants (tweak freely) --------------------------
    PREFLOP_ITERS = 300
    FLOP_ITERS = 500
    TURN_ITERS = 1000
    RIVER_ITERS = 1  # exact — no need to simulate

    # equity thresholds
    RAISE_EQUITY = 0.65
    CALL_EQUITY = 0.50
    CHEAP_CALL_EQUITY = 0.40
    MAX_CALL_FRACTION_OF_POT = 0.10  # “cheap” if ≤ 10 % of pot
    # ---------------------------------------------------------------------

    def __init__(self) -> None:
        super().__init__()
        # will be populated in on_start
        self.hole_cards: List[str] = []
        self.evaluator = Evaluator()
        # pocket card cache (avoid repeated conversions)
        self._card_int_cache: Dict[str, int] = {}

    # ---------------------------------------------------------------------
    # life-cycle callbacks required by the framework
    # ---------------------------------------------------------------------

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        """Called once when game commences."""
        # The framework provides our two hole cards as a list of strings such
        # as ['Ah', 'Ks']  (defensive fallback for other formats).
        self.hole_cards = (
            player_hands
            if isinstance(player_hands, list)
            else [player_hands[:2], player_hands[2:]]
        )

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Reset any round-specific state (none needed for this simple bot)."""
        pass

    # ------------------------------------------------------------------
    # main decision function
    # ------------------------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Core decision routine.  Must return (PokerAction, amount).
        The `amount` field is ignored for CHECK and CALL in the engine.
        """
        # --------------------------------------------------------------
        # helper values from the round-state
        # --------------------------------------------------------------
        my_bet_so_far = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet_so_far)
        pot = max(round_state.pot, 1)  # avoid div-by-zero later on

        # --------------------------------------------------------------
        # compute our win probability (equity)
        # --------------------------------------------------------------
        community_cards = round_state.community_cards
        equity = self._estimate_equity(self.hole_cards, community_cards, len(round_state.current_player))

        # --------------------------------------------------------------
        # choose an action based on equity and price we have to pay
        # --------------------------------------------------------------
        can_check = call_amount == 0
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)

        # high equity → raise / shove
        if equity >= self.RAISE_EQUITY and max_raise >= min_raise:
            # all-in if we are really crushing the table (turn/river or >80 %)
            if equity > 0.80 or round_state.round in ("Turn", "River"):
                return PokerAction.ALL_IN, 0
            # otherwise raise the minimum (pot-sweetener without huge variance)
            raise_amount = max(min_raise, int(pot / 2))
            raise_amount = min(raise_amount, max_raise)
            return PokerAction.RAISE, raise_amount

        # medium equity → call (if affordable) / check
        if equity >= self.CALL_EQUITY:
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.CALL, call_amount

        # marginal equity but very cheap price → speculative call
        cheap = call_amount <= self.MAX_CALL_FRACTION_OF_POT * pot
        if equity >= self.CHEAP_CALL_EQUITY and cheap and call_amount > 0:
            return PokerAction.CALL, call_amount

        # otherwise fold / check
        if can_check:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    # ------------------------------------------------------------------
    # end-of-round and end-of-game bookkeeping (not used)
    # ------------------------------------------------------------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass

    # ------------------------------------------------------------------
    # internal helpers
    # ------------------------------------------------------------------
    def _estimate_equity(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        num_players: int,
    ) -> float:
        """
        Monte-Carlo equity estimate of our hand versus (`num_players`-1) random
        opponents given current community cards.
        """
        # choose number of simulations based on the street for speed
        street = len(community_cards)
        if street == 0:
            iterations = self.PREFLOP_ITERS
        elif street == 3:
            iterations = self.FLOP_ITERS
        elif street == 4:
            iterations = self.TURN_ITERS
        else:  # river — deterministic
            iterations = self.RIVER_ITERS

        # convert cards to treys ints (cached for speed)
        used_cards_int = [self._to_card_int(c) for c in hole_cards + community_cards]

        if iterations == 1 and street == 5:
            # river — exact comparison without simulation
            our_rank = self.evaluator.evaluate(
                used_cards_int[:2], used_cards_int[2:]
            )
            wins = ties = 0
            deck = [c for c in Deck.GetFullDeck() if c not in used_cards_int]
            # iterate over every possible opponent hand (still fast at river)
            for i in range(len(deck)):
                for j in range(i + 1, len(deck)):
                    opp_hole = [deck[i], deck[j]]
                    opp_rank = self.evaluator.evaluate(
                        opp_hole, used_cards_int[2:]
                    )
                    if our_rank < opp_rank:
                        wins += 1
                    elif our_rank == opp_rank:
                        ties += 1
            total = wins + ties + (len(deck) * (len(deck) - 1) // 2 - wins - ties)
            # equity: win + 0.5 * tie
            return (wins + 0.5 * ties) / max(total, 1)

        wins = ties = 0
        deck_obj = Deck()
        for _ in range(iterations):
            deck_obj.shuffle()
            # remove used cards
            deck = [c for c in deck_obj.cards if c not in used_cards_int]
            # draw remainder of board
            cards_needed = 5 - len(community_cards)
            new_community = random.sample(deck, cards_needed)
            board_int = [self._to_card_int(c) for c in community_cards] + new_community

            # remove those from deck
            remaining_deck = [c for c in deck if c not in new_community]

            # draw opponents
            opp_hands = []
            for _ in range(num_players - 1):
                opp = random.sample(remaining_deck, 2)
                opp_hands.append(opp)
                remaining_deck = [c for c in remaining_deck if c not in opp]

            our_rank = self.evaluator.evaluate(
                [self._to_card_int(c) for c in hole_cards], board_int
            )

            best = True
            tie = False
            for opp in opp_hands:
                opp_rank = self.evaluator.evaluate(opp, board_int)
                if opp_rank < our_rank:
                    best = False
                    break
                if opp_rank == our_rank:
                    tie = True

            if best:
                if tie:
                    ties += 1
                else:
                    wins += 1

        total = iterations
        return (wins + 0.5 * ties) / max(total, 1)

    # ------------------------------------------------------------------
    def _to_card_int(self, card_str: str) -> int:
        """Convert 'Ah'-style string to treys integer (cached)."""
        if card_str not in self._card_int_cache:
            # treys expects upper-case rank + suit char
            formatted = card_str[0].upper() + card_str[1].lower()
            self._card_int_cache[card_str] = Card.new(formatted)
        return self._card_int_cache[card_str]