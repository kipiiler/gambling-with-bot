# player.py
from typing import List, Tuple, Dict
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from treys import Evaluator, Card, Deck


class SimplePlayer(Bot):
    """
    A reasonably strong, tight-aggressive NL Texas Hold’em bot built around
    1) Chen formula pre-flop hand strength
    2) Monte-Carlo equity estimation post-flop (treys library)
    3) Simple pot-odds / equity decision rule
    The design deliberately avoids deep computation so that it comfortably
    respects the 30 s / 100 MB limits while still beating trivial opponents.
    """

    # ----- constants & tuneables ------------------------------------------------
    PREFLOP_RAISE_FACTOR = 3          # open raise = 3× big blind (≈min_raise)
    PREFLOP_RERAISE_FACTOR = 3        # 3-bet size (× amount to call)
    POSTFLOP_BET_FRACTION = 0.6       # bet ~60 % of pot when value betting
    POSTFLOP_MIN_BET = 0.5            # minimum bet as pot fraction
    MONTE_CARLO_SAMPLES = 150         # equity simulations each decision
    AGGRESSION_THRESHOLD = 0.75       # equity to value-bet / shove
    CALL_MARGIN = 0.05                # equity – potOdds safety buffer
    STRONG_CHEN_THRESHOLD = 10        # open raise / 3-bet threshold
    MEDIUM_CHEN_THRESHOLD = 7         # limp / flat-call threshold
    VERY_STRONG_CHEN_THRESHOLD = 12   # shove / large 3-bet threshold
    # ---------------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self.evaluator = Evaluator()
        self.big_blind = 0
        self.small_blind = 0
        self.hole_cards: List[str] = []
        self.all_players: List[int] = []

    # ---- game-lifecycle methods ----------------------------------------------

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        """Called once at game start."""
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the beginning of a new hand."""
        # Try to extract our hole cards from round_state (implementation-agnostic)
        if hasattr(round_state, "hole_cards"):
            self.hole_cards = round_state.hole_cards
        elif hasattr(round_state, "player_hands"):
            self.hole_cards = round_state.player_hands.get(str(self.id), [])
        # Fallback to empty list if not provided yet
        if self.hole_cards is None:
            self.hole_cards = []

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """Core decision routine."""
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_bet)
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        pot = round_state.pot

        # -------- PRE-FLOP -----------------------------------------------------
        if round_state.round.lower() == "preflop":
            chen_score = self._chen_score(self.hole_cards)
            # If no bet in front of us
            if to_call == 0:
                if chen_score >= self.STRONG_CHEN_THRESHOLD:
                    # Open raise
                    raise_amount = max(
                        min_raise, int(self.PREFLOP_RAISE_FACTOR * self.big_blind)
                    )
                    raise_amount = min(raise_amount, max_raise)
                    if raise_amount >= min_raise:
                        return PokerAction.RAISE, raise_amount
                elif chen_score >= self.MEDIUM_CHEN_THRESHOLD:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            # There is a bet to us
            else:
                # Very strong hand – 3-bet / shove
                if chen_score >= self.VERY_STRONG_CHEN_THRESHOLD:
                    size = min(max_raise, to_call * self.PREFLOP_RERAISE_FACTOR)
                    if size >= min_raise:
                        return PokerAction.RAISE, size
                    return PokerAction.ALL_IN, 0
                # Strong – flat call
                if chen_score >= self.STRONG_CHEN_THRESHOLD:
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                # Mediocre – call small bets only
                if chen_score >= self.MEDIUM_CHEN_THRESHOLD and to_call <= (
                    4 * self.big_blind
                ):
                    if to_call >= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.CALL, 0
                # Otherwise fold
                return PokerAction.FOLD, 0

        # -------- POST-FLOP ----------------------------------------------------
        equity = self._estimate_equity(
            self.hole_cards,
            round_state.community_cards,
            len(round_state.current_player) - 1,
        )

        if to_call == 0:
            # We are first / action checked to us
            if equity >= self.AGGRESSION_THRESHOLD:
                # Value bet ~60 % pot
                bet = max(min_raise, int(max(pot * self.POSTFLOP_BET_FRACTION, min_raise)))
                bet = min(bet, max_raise)
                if bet >= min_raise:
                    return PokerAction.RAISE, bet
            return PokerAction.CHECK, 0

        # Someone bet – compare equity to pot odds
        pot_odds = to_call / (pot + to_call + 1e-6)
        if equity + self.CALL_MARGIN >= pot_odds:
            # Sometimes raise if very strong
            if equity >= self.AGGRESSION_THRESHOLD and max_raise > min_raise:
                raise_size = max(min_raise, int(pot * self.POSTFLOP_BET_FRACTION))
                raise_size = min(raise_size, max_raise)
                if raise_size >= min_raise:
                    return PokerAction.RAISE, raise_size
            # Otherwise call
            if to_call >= remaining_chips:
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Reset per-hand state."""
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[int, float],
        active_players_hands: Dict[int, List[str]],
    ):
        """No persistent learning – nothing to do."""
        pass

    # ---- helper methods -------------------------------------------------------

    @staticmethod
    def _to_treys(card: str) -> int:
        """Convert 'Ah' → treys integer code."""
        if len(card) != 2:
            raise ValueError(f"Invalid card string: {card}")
        rank, suit = card[0], card[1].lower()
        return Card.new(rank + suit)

    def _estimate_equity(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        opponents: int,
    ) -> float:
        """
        Monte-Carlo equity estimation versus `opponents` random hands.
        Returns win probability (ties count ½).
        """
        if len(hole_cards) != 2:
            return 0.0  # sanity fallback

        hero = [self._to_treys(c) for c in hole_cards]
        board = [self._to_treys(c) for c in community_cards]

        available_deck = Deck()
        # Remove known cards from deck
        for c in hero + board:
            available_deck.cards.remove(c)

        wins = ties = 0
        samples = self.MONTE_CARLO_SAMPLES
        for _ in range(samples):
            deck_copy = available_deck.cards[:]
            random.shuffle(deck_copy)

            opp_hands = []
            draw_idx = 0
            # Draw opponents' hole cards
            for _ in range(opponents):
                opp_hands.append([deck_copy[draw_idx], deck_copy[draw_idx + 1]])
                draw_idx += 2

            # Draw remaining community cards
            needed_board = 5 - len(board)
            sim_board = board + deck_copy[draw_idx : draw_idx + needed_board]

            hero_rank = self.evaluator.evaluate(sim_board, hero)
            opp_ranks = [
                self.evaluator.evaluate(sim_board, h) for h in opp_hands
            ]

            best_rank = min([hero_rank] + opp_ranks)
            # Lower rank is better
            if hero_rank == best_rank and opp_ranks.count(best_rank) == 0:
                wins += 1
            elif hero_rank == best_rank:
                ties += 1

        equity = (wins + ties * 0.5) / max(1, samples)
        return equity

    # -------- CHEN FORMULA -----------------------------------------------------

    @staticmethod
    def _chen_base_value(rank: str) -> float:
        mapping = {
            "A": 10,
            "K": 8,
            "Q": 7,
            "J": 6,
            "T": 5,
            "9": 4.5,
            "8": 4,
            "7": 3.5,
            "6": 3,
            "5": 2.5,
            "4": 2,
            "3": 1.5,
            "2": 1,
        }
        return mapping.get(rank.upper(), 0)

    def _chen_score(self, cards: List[str]) -> float:
        """Compute Chen formula score for 2-card pre-flop hand."""
        if len(cards) != 2:
            return 0
        ranks = [c[0].upper() for c in cards]
        suits_equal = cards[0][1] == cards[1][1]

        high = max(ranks, key=self._chen_base_value)
        low = min(ranks, key=self._chen_base_value)
        base = self._chen_base_value(high)

        # Pair
        if ranks[0] == ranks[1]:
            score = max(5, base * 2)
            return score

        # Suited bonus
        score = base
        if suits_equal:
            score += 2

        # Gap penalty
        order = "23456789TJQKA"
        gap = abs(order.index(high) - order.index(low)) - 1
        if gap == 0:
            score += 0
        elif gap == 1:
            score -= 1
        elif gap == 2:
            score -= 2
        elif gap == 3:
            score -= 4
        else:
            score -= 5

        # Straight bonus
        if gap <= 1 and base < 12:  # both cards <= Q
            score += 1

        return max(score, 0)