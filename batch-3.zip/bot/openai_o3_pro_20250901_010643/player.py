import random
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Optional dependency for quick hand evaluation ---------------
# The treys library is a pure-python port of the well-known deuces
# evaluator.  It is light-weight (~30 KB) and perfectly suited for
# quick equity simulations inside the 30-second per-move budget.
try:
    from treys import Card, Evaluator, Deck
except ImportError:
    # If the runner has not installed treys yet, fall back to a
    # dummy evaluator that returns random equity.  That way the bot
    # still runs instead of crashing (automatic fold).
    Card = None
    Evaluator = None
    Deck = None


class SimplePlayer(Bot):
    """
    A very small yet reasonably strong no-limit Hold’em bot.

    Core ideas
    1.  Every decision is driven by estimated win equity versus one
        random opponent.
    2.  Equity is approximated by Monte-Carlo simulation (post-flop)
        or by a quick pre-flop look-up using the Chen formula.
    3.  Compare equity to immediate pot-odds:
            equity  >  pot_odds + margin  => continue (call / raise)
            equity  <= pot_odds           => fold (if facing a bet)
        The margin is higher pre-flop to avoid over-valuing weak
        hands and shrinks post-flop.
    4.  If our equity is very high we apply pressure by raising to
        the minimum legal raise (or going all-in once stacks become
        shallow).

    NOTE:  The bot never violates the rule-set – every bet amount is
           cross-checked against min_raise / max_raise and our own
           stack, guaranteeing valid actions.
    """

    # ------------------------------------------------------------------
    #  “Public” interface required by the competition server
    # ------------------------------------------------------------------
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.evaluator = Evaluator() if Evaluator else None

        # Will be updated every round
        self.hole_cards: List[str] = []
        self.round_num = 0

    # ---------------- Game life-cycle ---------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # Try to grab our hole cards if provided
        self.hole_cards = self._extract_hole_cards(round_state)

    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        """
        Decide between FOLD / CHECK / CALL / RAISE / ALL_IN.
        """
        # 1. Gather basic round information ----------------------------
        pot = round_state.pot
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        can_check = call_amount == 0

        # 2. Estimate win equity ---------------------------------------
        equity = self._estimate_equity(
            self.hole_cards, round_state.community_cards, stage=round_state.round
        )

        # 3. Calculate pot-odds and required equity --------------------
        pot_odds = (
            call_amount / (pot + call_amount + 1e-9) if call_amount > 0 else 0
        )

        # Add a tiny margin to reduce variance especially pre-flop
        margin = 0.08 if round_state.round.lower() == "preflop" else 0.03
        need_equity = pot_odds + margin

        # 4. Decision tree ---------------------------------------------
        # a) If no bet to us yet
        if can_check:
            # Raise monster hands to build pot / gain fold equity
            if equity > 0.7 and min_raise > 0:
                raise_amount = max(min_raise, int(pot * 0.75))
                raise_amount = min(max_raise, raise_amount)
                # Should still be at least min_raise
                if raise_amount >= min_raise:
                    return PokerAction.RAISE, raise_amount
            # Otherwise just check
            return PokerAction.CHECK, 0

        # b) We face a bet
        if equity < need_equity:
            # Not enough equity – fold
            return PokerAction.FOLD, 0

        # We have the equity to continue – decide whether to call/raise
        if equity > 0.7 and max_raise > min_raise:
            # Very strong hand ⇒ put in a raise (pot or all-in if shallow)
            if remaining_chips < pot * 0.5:
                # Short stacked ⇒ shove
                return PokerAction.ALL_IN, 0
            else:
                raise_amount = max(min_raise, int(call_amount + pot * 0.5))
                raise_amount = min(max_raise, raise_amount)
                # Ensure legality
                if raise_amount >= min_raise:
                    return PokerAction.RAISE, raise_amount

        # Default: just call
        return PokerAction.CALL, call_amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round specific state
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # No persistent learning across games, but could add logging
        pass

    # ------------------------------------------------------------------
    #  Helpers
    # ------------------------------------------------------------------
    # --- Equity estimation --------------------------------------------
    def _estimate_equity(
        self, hole_cards: List[str], community_cards: List[str], stage: str
    ) -> float:
        """
        Returns approximate probability of winning versus exactly one
        random opponent.
        """
        # Safety: if we somehow lack hole cards assume junk equity
        if len(hole_cards) != 2:
            return 0.25  # average heads-up equity

        # Pre-flop: quick Chen formula approximation
        if stage.lower() == "preflop":
            chen = self._chen_score(hole_cards)
            # Map Chen (1-20) to equity (0.22-0.85) roughly
            return min(0.85, max(0.22, chen / 24))

        # Post-flop: Monte Carlo simulation with treys
        if not self.evaluator or Card is None:
            # Fallback simple heuristic by Chen + board texture penalty
            chen = self._chen_score(hole_cards)
            board_factor = 0.1 * len(community_cards) / 5
            return min(0.9, max(0.2, chen / 24 - board_factor))

        # Proper simulation
        try:
            h_cards = [Card.new(c) for c in hole_cards]
            b_cards = [Card.new(c) for c in community_cards]

            wins = 0
            ties = 0
            trials = 300  # well below 30-second budget

            for _ in range(trials):
                deck = Deck()
                # Remove our cards and revealed community
                for c in h_cards + b_cards:
                    deck.cards.remove(c)

                # Draw remaining community cards
                draw_needed = 5 - len(b_cards)
                sim_board = b_cards + deck.draw(draw_needed)

                # Draw opponent hole
                opp_cards = deck.draw(2)

                # Evaluate
                my_rank = self.evaluator.evaluate(sim_board, h_cards)
                opp_rank = self.evaluator.evaluate(sim_board, opp_cards)

                if my_rank < opp_rank:
                    wins += 1
                elif my_rank == opp_rank:
                    ties += 1

            equity = (wins + ties * 0.5) / trials
            # Clamp numeric stability
            return min(0.99, max(0.01, equity))
        except Exception:
            # Never crash during equity calcs
            return 0.4

    # --- Chen formula -------------------------------------------------
    def _chen_score(self, hole_cards: List[str]) -> float:
        """
        Returns the Chen formula score (1-20) for our pre-flop hand.
        Simpler implementation – sufficient for rough ordering.
        """
        if len(hole_cards) != 2:
            return 0

        # Rank mapping
        ranks = "23456789TJQKA"
        rank_value = {
            "A": 10,
            "K": 8,
            "Q": 7,
            "J": 6,
            "T": 5,
            "9": 4.5,
            "8": 4,
            "7": 3.5,
            "6": 3,
            "5": 2.5,
            "4": 2,
            "3": 1.5,
            "2": 1,
        }

        r1, s1 = hole_cards[0][0], hole_cards[0][1]
        r2, s2 = hole_cards[1][0], hole_cards[1][1]

        high_rank = r1 if ranks.index(r1) > ranks.index(r2) else r2
        low_rank = r2 if high_rank == r1 else r1

        # Base score
        score = rank_value[high_rank]

        # Pair check
        if r1 == r2:
            score = max(5, score * 2)
        else:
            # Suited bonus
            if s1 == s2:
                score += 2

            # Gap penalty
            gap = abs(ranks.index(r1) - ranks.index(r2)) - 1
            if gap == 0:
                score += 0
            elif gap == 1:
                score -= 1
            elif gap == 2:
                score -= 2
            elif gap == 3:
                score -= 4
            else:
                score -= 5

            # Straight bonus
            if gap <= 1 and ranks.index(low_rank) >= ranks.index("5") and r1 != r2:
                score += 1

        return max(1, score)

    # --- Utils --------------------------------------------------------
    def _extract_hole_cards(self, round_state: RoundStateClient) -> List[str]:
        """
        Try to find our hole cards in the round_state, supporting
        multiple possible attribute names for robustness.
        """
        candidate_attrs = ["player_hands", "playerHands", "hands"]
        for attr in candidate_attrs:
            if hasattr(round_state, attr):
                d: Dict[str, List[str]] = getattr(round_state, attr)
                if isinstance(d, dict):
                    hand = d.get(str(self.id)) or d.get(self.id)
                    if hand:
                        return hand
        # Not found – keep previous or empty
        return self.hole_cards