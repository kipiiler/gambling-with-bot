from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum
import random
import collections

class PokerHandRank(Enum):
    HIGH_CARD = 0
    ONE_PAIR = 1
    TWO_PAIR = 2
    THREE_OF_A_KIND = 3
    STRAIGHT = 4
    FLUSH = 5
    FULL_HOUSE = 6
    FOUR_OF_A_KIND = 7
    STRAIGHT_FLUSH = 8
    ROYAL_FLUSH = 9

CARD_RANKS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
CARD_SUITS = ['h', 'd', 'c', 's']

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.aggression_factor = 1.0
        self.vpip_count = 0
        self.hands_played = 0
        self.opp_tendencies = collections.defaultdict(lambda: {'vpip': 0, 'pfr': 0, 'af': 1.0, 'hands': 0})
        self.my_chips = 10000
        self.table_average = 10000

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_chips = starting_chips
        self.table_average = starting_chips * len(all_players)
        self.hole_cards = player_hands
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.blind_amount = blind_amount
        self.hands_played = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips
        self.hands_played += 1
        if self.hands_played > 0:
            for player_id in self.all_players:
                if player_id in self.opp_tendencies:
                    self.opp_tendencies[player_id]['hands'] += 1

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[PokerHandRank, List[int]]:
        all_cards = hole_cards + community_cards
        if not all_cards:
            return PokerHandRank.HIGH_CARD, []

        rank_counts = collections.defaultdict(int)
        suit_counts = collections.defaultdict(int)
        for card in all_cards:
            rank = CARD_RANKS[card[0]]
            suit = card[1]
            rank_counts[rank] += 1
            suit_counts[suit] += 1

        is_flush = any(count >= 5 for count in suit_counts.values())
        
        unique_ranks = sorted(rank_counts.keys(), reverse=True)
        rank_groups = sorted([(count, rank) for rank, count in rank_counts.items()], reverse=True)
        
        is_straight = False
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i+4] == 4:
                    is_straight = True
                    straight_high = unique_ranks[i]
                    break
            if not is_straight and 14 in unique_ranks and 2 in unique_ranks and 3 in unique_ranks and 4 in unique_ranks and 5 in unique_ranks:
                is_straight = True
                straight_high = 5

        hand_rank = PokerHandRank.HIGH_CARD
        tie_breaker = []
        
        if is_straight and is_flush:
            hand_rank = PokerHandRank.STRAIGHT_FLUSH
            tie_breaker = [straight_high]
            if straight_high == 14 and max(unique_ranks) == 14:
                hand_rank = PokerHandRank.ROYAL_FLUSH
        elif rank_groups[0][0] == 4:
            hand_rank = PokerHandRank.FOUR_OF_A_KIND
            tie_breaker = [rank_groups[0][1], rank_groups[1][1]]
        elif rank_groups[0][0] == 3 and rank_groups[1][0] >= 2:
            hand_rank = PokerHandRank.FULL_HOUSE
            tie_breaker = [rank_groups[0][1], rank_groups[1][1]]
        elif is_flush:
            hand_rank = PokerHandRank.FLUSH
            tie_breaker = sorted(unique_ranks, reverse=True)
        elif is_straight:
            hand_rank = PokerHandRank.STRAIGHT
            tie_breaker = [straight_high]
        elif rank_groups[0][0] == 3:
            hand_rank = PokerHandRank.THREE_OF_A_KIND
            kickers = [r for _, r in rank_groups[1:]]
            tie_breaker = [rank_groups[0][1]] + sorted(kickers, reverse=True)
        elif rank_groups[0][0] == 2 and rank_groups[1][0] == 2:
            hand_rank = PokerHandRank.TWO_PAIR
            pairs = sorted([r for _, r in rank_groups[:2]], reverse=True)
            kicker = rank_groups[2][1]
            tie_breaker = pairs + [kicker]
        elif rank_groups[0][0] == 2:
            hand_rank = PokerHandRank.ONE_PAIR
            pair_rank = rank_groups[0][1]
            kickers = sorted([r for _, r in rank_groups[1:]], reverse=True)
            tie_breaker = [pair_rank] + kickers
        else:
            hand_rank = PokerHandRank.HIGH_CARD
            tie_breaker = sorted(unique_ranks, reverse=True)

        return hand_rank, tie_breaker

    def _get_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.hole_cards:
            return 0.0
        
        community_cards = round_state.community_cards
        hand_rank, _ = self._evaluate_hand_strength(self.hole_cards, community_cards)
        
        rank_value = hand_rank.value / 9.0
        
        if not community_cards:
            rank = CARD_RANKS[self.hole_cards[0][0]]
            suit = self.hole_cards[0][1]
            rank2 = CARD_RANKS[self.hole_cards[1][0]]
            suit2 = self.hole_cards[1][1]
            
            if rank == rank2:
                rank_value += 0.3
            elif suit == suit2:
                rank_value += 0.1
            
            if rank >= 10 or rank2 >= 10:
                rank_value += 0.2
            
            gap = abs(rank - rank2) - 1
            rank_value -= min(gap * 0.05, 0.2)
            
            return min(max(rank_value, 0.0), 1.0)
        
        return min(max(rank_value, 0.0), 1.0)

    def _get_pot_odds(self, round_state: RoundStateClient) -> float:
        try:
            to_call = round_state.current_bet
            pot_size = round_state.pot
            if to_call <= 0 or pot_size <= 0:
                return 1.0
            return pot_size / (to_call + 1e-5)
        except:
            return 1.0

    def _calculate_bet_size(self, round_state: RoundStateClient, hand_strength: float) -> int:
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        if pot == 0:
            return min_raise
        
        base_bet = int(pot * hand_strength * 0.75)
        if hand_strength > 0.8:
            base_bet = int(pot * 1.2)
        elif hand_strength > 0.6:
            base_bet = int(pot * 0.8)
        
        bet_size = max(min_raise, min(base_bet, max_raise))
        return bet_size

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        if not self.hole_cards or len(self.hole_cards) != 2:
            return PokerAction.FOLD, 0

        hand_strength = self._get_hand_strength(round_state)
        pot_odds = self._get_pot_odds(round_state)
        
        current_bet_to_call = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        effective_stack = remaining_chips
        stack_ratio = effective_stack / (self.table_average + 1e-5)
        
        if stack_ratio < 0.2:
            if hand_strength > 0.4:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        
        action_decision = random.random()
        
        if current_bet_to_call == 0:
            if hand_strength > 0.7:
                if hand_strength > 0.9 and max_raise > min_raise:
                    bet_amount = self._calculate_bet_size(round_state, hand_strength)
                    return PokerAction.RAISE, bet_amount
                return PokerAction.CHECK, 0
            elif hand_strength > 0.4:
                if action_decision < 0.5:
                    return PokerAction.CHECK, 0
                elif max_raise > min_raise:
                    bet_amount = self._calculate_bet_size(round_state, hand_strength)
                    return PokerAction.RAISE, bet_amount
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            if hand_strength > 0.8:
                if action_decision < 0.7 and max_raise > min_raise:
                    bet_amount = self._calculate_bet_size(round_state, hand_strength)
                    return PokerAction.RAISE, bet_amount
                return PokerAction.CALL, 0
            elif hand_strength > 0.6:
                if pot_odds > 2.0:
                    return PokerAction.CALL, 0
                elif action_decision < 0.3 and max_raise > min_raise:
                    bet_amount = self._calculate_bet_size(round_state, hand_strength)
                    return PokerAction.RAISE, bet_amount
                else:
                    return PokerAction.FOLD, 0
            elif hand_strength > 0.3:
                if pot_odds > 3.0:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            else:
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips
        
        for player_id, action in round_state.player_actions.items():
            if player_id in self.opp_tendencies:
                if action in ['Call', 'Raise', 'All-in']:
                    self.opp_tendencies[player_id]['vpip'] += 1
                if action in ['Raise', 'All-in']:
                    self.opp_tendencies[player_id]['pfr'] += 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass