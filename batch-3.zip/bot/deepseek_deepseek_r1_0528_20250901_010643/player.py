from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.previous_actions = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.previous_actions = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.previous_actions = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Validate inputs
            if not isinstance(round_state, RoundStateClient) or not isinstance(remaining_chips, int):
                return PokerAction.FOLD, 0
            
            # Calculate current investment
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            to_call = current_bet - my_bet
            pot = round_state.pot
            
            # Estimate win probability
            win_prob = self.estimate_win_prob(self.hand, round_state.community_cards, 100)
            
            # Calculate pot odds
            pot_odds = to_call / (pot + to_call + 1e-8) if to_call > 0 else 0
            
            # Action selection logic
            if win_prob > 0.7:
                # Premium hand - aggressive
                if remaining_chips <= to_call:
                    return PokerAction.ALL_IN, 0
                raise_amount = max(round_state.min_raise, min(int(pot * 0.75), round_state.max_raise))
                return PokerAction.RAISE, raise_amount
            elif win_prob > 0.5:
                # Strong hand - value bet
                if to_call == 0:
                    bet_amount = max(round_state.min_raise, min(int(pot * 0.5), round_state.max_raise))
                    return PokerAction.RAISE, bet_amount
                if remaining_chips <= to_call:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            elif win_prob > pot_odds and win_prob > 0.3:
                # Pot odds justify call
                if remaining_chips <= to_call:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            else:
                # Weak hand or bad pot odds
                if to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
                
        except Exception as e:
            # Fallback to fold on any error
            return PokerAction.FOLD, 0

    def estimate_win_prob(self, hand: List[str], community_cards: List[str], num_samples: int) -> float:
        try:
            if not hand or len(hand) != 2 or not all(isinstance(card, str) for card in hand):
                return 0.0
                
            # Get unseen cards
            unseen = self._get_unseen_cards(hand, community_cards)
            if not unseen:
                return 0.0
                
            wins = 0
            n_opponents = max(1, len(self.all_players) - 1)
            
            for _ in range(num_samples):
                # Simulate remaining community cards
                sim_comm = community_cards.copy()
                needed_comm = 5 - len(community_cards)
                if needed_comm > 0:
                    sim_comm += random.sample(unseen, needed_comm)
                    new_unseen = [c for c in unseen if c not in sim_comm]
                else:
                    new_unseen = unseen.copy()
                    
                # Simulate opponent hands
                opp_hands = []
                for _ in range(n_opponents):
                    if len(new_unseen) < 2:
                        break
                    opp_hand = random.sample(new_unseen, 2)
                    opp_hands.append(opp_hand)
                    new_unseen = [c for c in new_unseen if c not in opp_hand]
                
                # Evaluate our hand
                our_hand_value = self.evaluate_hand(hand, sim_comm)
                
                # Evaluate opponents' hands
                opponent_best = -1
                for opp_hand in opp_hands:
                    opp_value = self.evaluate_hand(opp_hand, sim_comm)
                    if opp_value > opponent_best:
                        opponent_best = opp_value
                
                # Compare hand values
                if our_hand_value > opponent_best:
                    wins += 1
                elif our_hand_value == opponent_best:
                    wins += 0.5
                    
            return wins / num_samples
            
        except Exception:
            return 0.0

    def _get_unseen_cards(self, hand: List[str], community_cards: List[str]) -> List[str]:
        try:
            # Create full deck
            ranks = '23456789TJQKA'
            suits = 'shdc'
            deck = [r + s for r in ranks for s in suits]
            
            # Remove known cards
            known_cards = hand + community_cards
            for card in known_cards:
                if card in deck:
                    deck.remove(card)
            return deck
        except Exception:
            return []

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> int:
        if not hole_cards or len(hole_cards) != 2 or not community_cards:
            return 0
            
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0
            
        # Convert cards to numeric values
        rank_map = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, 'T':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        suits = {'s':0, 'h':1, 'd':2, 'c':3}
        
        try:
            # Parse cards
            cards = []
            for card in all_cards:
                if len(card) != 2:
                    continue
                rank, suit = card[0], card[1]
                if rank in rank_map and suit in suits:
                    cards.append((rank_map[rank], suits[suit]))
            
            if len(cards) < 5:
                return 0
                
            # Generate all 5-card combinations
            best_score = 0
            n = len(cards)
            for i in range(n):
                for j in range(i+1, n):
                    for k in range(j+1, n):
                        for l in range(k+1, n):
                            for m in range(l+1, n):
                                hand = [cards[i], cards[j], cards[k], cards[l], cards[m]]
                                score = self._score_hand(hand)
                                if score > best_score:
                                    best_score = score
            return best_score
        except Exception:
            return 0

    def _score_hand(self, hand: List[Tuple[int, int]]) -> int:
        ranks = [card[0] for card in hand]
        suits = [card[1] for card in hand]
        
        # Sort ranks descending
        ranks.sort(reverse=True)
        
        # Check for flush
        flush = all(s == suits[0] for s in suits)
        
        # Check for straight
        straight = True
        for i in range(1, 5):
            if ranks[i] != ranks[i-1] - 1:
                straight = False
                break
                
        # Special case for wheel straight (A-5)
        if not straight and sorted(ranks) == [2, 3, 4, 5, 14]:
            straight = True
            ranks = [5, 4, 3, 2, 1]  # Treat Ace as low
        
        # Evaluate hand type
        if straight and flush:
            return 8000000 + ranks[0] * 10000  # Royal/straight flush
            
        # Four of a kind
        if ranks[0] == ranks[3] or ranks[1] == ranks[4]:
            quad_rank = ranks[1] if ranks[1] == ranks[4] else ranks[0]
            kicker = ranks[4] if quad_rank != ranks[4] else ranks[0]
            return 7000000 + quad_rank * 10000 + kicker
            
        # Full house
        if (ranks[0] == ranks[2] and ranks[3] == ranks[4]) or (ranks[0] == ranks[1] and ranks[2] == ranks[4]):
            trips = ranks[2]
            pair = ranks[3] if trips != ranks[3] else ranks[0]
            return 6000000 + trips * 10000 + pair * 100
            
        # Flush
        if flush:
            return 5000000 + ranks[0] * 10000 + ranks[1] * 1000 + ranks[2] * 100 + ranks[3] * 10 + ranks[4]
            
        # Straight
        if straight:
            return 4000000 + ranks[0] * 10000
            
        # Three of a kind
        for i in range(3):
            if ranks[i] == ranks[i+2]:
                trips = ranks[i]
                kickers = [r for r in ranks if r != trips]
                return 3000000 + trips * 10000 + kickers[0] * 100 + kickers[1]
                
        # Two pair
        pairs = []
        kickers = []
        for i in range(4):
            if ranks[i] == ranks[i+1]:
                pairs.append(ranks[i])
                i += 1  # Skip next card
            else:
                kickers.append(ranks[i])
        if len(pairs) >= 2:
            pairs.sort(reverse=True)
            return 2000000 + pairs[0] * 10000 + pairs[1] * 100 + kickers[0]
            
        # One pair
        for i in range(4):
            if ranks[i] == ranks[i+1]:
                pair = ranks[i]
                kickers = [r for r in ranks if r != pair]
                return 1000000 + pair * 10000 + kickers[0] * 100 + kickers[1] * 10 + kickers[2]
                
        # High card
        return ranks[0] * 10000 + ranks[1] * 1000 + ranks[2] * 100 + ranks[3] * 10 + ranks[4]

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset for next hand
        self.hand = []
        self.previous_actions = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: Log final results
        pass