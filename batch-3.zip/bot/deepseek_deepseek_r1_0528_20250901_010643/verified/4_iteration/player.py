from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand = []
        self.big_blind_amount = 0
        self.relative_position = 0
        self.players_count = 0
        self.all_players = []
        self.prev_action = None
        self.aggression_factor = 1.0
        self.conservative_threshold = 0.65

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.all_players = all_players
        self.players_count = len(all_players)
        
        try:
            if small_blind_player_id in all_players:
                small_blind_index = all_players.index(small_blind_player_id)
                button_index = (small_blind_index - 1) % self.players_count
            else:
                button_index = 0
                
            my_index = all_players.index(self.id)
            self.relative_position = (my_index - button_index) % self.players_count
        except:
            self.relative_position = 0
        
        self.aggression_factor = 1.0 + (self.relative_position * 0.05)
        self.prev_action = None

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = max(0, current_bet - my_bet)
        stack = remaining_chips
        
        round_name = round_state.round
        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max_raise
        pot_size = round_state.pot
        possible_actions = []

        if any(str(pid) in round_state.player_actions for pid in self.all_players if pid != self.id):
            self.prev_action = None

        if stack == 0:
            return (PokerAction.ALL_IN, 0)

        if round_name == 'Preflop':
            chen_score = self._compute_chen_score()
            position_adjustment = 1.0 - (self.relative_position * 0.05)
            adjusted_score = chen_score * position_adjustment

            if not self.prev_action:
                possible_actions.append(PokerAction.FOLD)
                if amount_to_call <= 0:
                    possible_actions.append(PokerAction.CHECK)
                if amount_to_call > 0:
                    possible_actions.append(PokerAction.CALL)
                if stack > amount_to_call + min_raise_amount and min_raise_amount > 0:
                    possible_actions.append(PokerAction.RAISE)
                if stack > amount_to_call:
                    possible_actions.append(PokerAction.ALL_IN)
                
                self.prev_action = 'preflop_action'

                if adjusted_score > 12:
                    if PokerAction.ALL_IN in possible_actions:
                        return (PokerAction.ALL_IN, 0)
                    if PokerAction.RAISE in possible_actions:
                        raise_amt = min(max(min_raise_amount, self.big_blind_amount * 3), max_raise_amount)
                        if stack < raise_amt:
                            return (PokerAction.ALL_IN, 0)
                        return (PokerAction.RAISE, min(raise_amt, stack))
                    if PokerAction.CALL in possible_actions:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.CHECK, 0)
                
                elif adjusted_score > 10:
                    if PokerAction.RAISE in possible_actions:
                        raise_amt = min(min_raise_amount, max_raise_amount)
                        return (PokerAction.RAISE, min(raise_amt, stack))
                    if PokerAction.CALL in possible_actions:
                        return (PokerAction.CALL, 0)
                    if PokerAction.CHECK in possible_actions:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
                
                elif adjusted_score > 8 or (adjusted_score > 6 and self.aggression_factor > 1.0):
                    if PokerAction.CALL in possible_actions and amount_to_call <= 0.3 * stack:
                        return (PokerAction.CALL, 0)
                    if PokerAction.CHECK in possible_actions:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)
                
                else:
                    if PokerAction.CHECK in possible_actions:
                        return (PokerAction.CHECK, 0)
                    return (PokerAction.FOLD, 0)

            else:
                if adjusted_score > 10 and stack > amount_to_call:
                    if PokerAction.ALL_IN in possible_actions:
                        return (PokerAction.ALL_IN, 0)
                    if PokerAction.RAISE in possible_actions:
                        raise_amt = min(amount_to_call + min_raise_amount, stack)
                        return (PokerAction.RAISE, raise_amt)
                    return (PokerAction.CALL, 0)
                if adjusted_score > 8 and amount_to_call < stack * 0.25:
                    return (PokerAction.CALL, 0)
                if adjusted_score > 6 and amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
        
        else:  # Post-flop rounds
            if amount_to_call == 0:
                possible_actions.append(PokerAction.CHECK)
            else:
                possible_actions.append(PokerAction.FOLD)
                possible_actions.append(PokerAction.CALL)
                
            if min_raise_amount > 0 and stack > amount_to_call + min_raise_amount:
                possible_actions.append(PokerAction.RAISE)
            if stack > amount_to_call:
                possible_actions.append(PokerAction.ALL_IN)
            
            win_prob = self.estimate_win_prob(self.hand, round_state.community_cards, round_state.player_bets, 50)
            pot_odds = amount_to_call / (pot_size + amount_to_call + 1e-9) if amount_to_call > 0 else 0

            strong_hand = any(self.evaluate_hand(self.hand + round_state.community_cards) >= threshold 
                            for threshold in [self._hand_rank('Three of a kind'), self._hand_rank('Two pair')])

            if win_prob > pot_odds * self.conservative_threshold:
                if PokerAction.ALL_IN in possible_actions and win_prob > 0.7 and stack > 8 * self.big_blind_amount:
                    return (PokerAction.ALL_IN, 0)
                if PokerAction.RAISE in possible_actions and (strong_hand or win_prob > 0.4):
                    raise_amt = min(max(min_raise_amount, int(1.5 * min_raise_amount)), max_raise_amount)
                    return (PokerAction.RAISE, min(raise_amt, stack))
                return (PokerAction.CALL, 0)
            else:
                if PokerAction.CHECK in possible_actions:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _compute_chen_score(self) -> float:
        base_scores = {
            '2': 1, '3': 1.5, '4': 2, '5': 2.5, 
            '6': 3, '7': 3.5, '8': 4, '9': 4.5, 
            '10': 5, 'J': 6, 'Q': 7, 'K': 8, 'A': 10
        }
        orders = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
        
        card1, card2 = self.hand
        rank1, suit1 = card1[:-1], card1[-1]
        rank2, suit2 = card2[:-1], card2[-1]
        base1 = base_scores[rank1]
        base2 = base_scores[rank2]
        
        if rank1 == rank2:
            return max(5, base1 * 2)
        
        high_base = max(base1, base2)
        high_rank = rank1 if base1 > base2 else rank2
        low_rank = rank2 if base1 > base2 else rank1
        
        idx_high = orders.index(high_rank)
        idx_low = orders.index(low_rank)
        gap = idx_high - idx_low - 1
        
        penalty = 0
        if gap >= 4:
            penalty = 5
        elif gap == 3:
            penalty = 4
        elif gap == 2:
            penalty = 2
        elif gap == 1:
            penalty = 1
            
        suited_bonus = 2 if suit1 == suit2 else 0
        return high_base - penalty + suited_bonus

    def estimate_win_prob(self, my_hand: List[str], community: List[str], player_bets: dict, simulations: int) -> float:
        wins = 0
        visible = my_hand + community
        unseen = self._get_unseen_cards(visible, player_bets)
        active_players = self._count_active_players(player_bets)
        
        if len(community) >= 5: 
            return self._evaluate_strength(my_hand, community) / 9000.0
        
        for _ in range(simulations):
            sample_comm = list(community)
            deck = unseen.copy()
            random.shuffle(deck)
            
            while len(sample_comm) < 5:
                sample_comm.append(deck.pop())
                
            opp_hands = []
            remaining_deck = deck.copy()
            for _ in range(active_players - 1):
                opp_hand = [remaining_deck.pop(), remaining_deck.pop()]
                opp_hands.append(opp_hand)
                
            my_score = self._evaluate_hand_strength(my_hand + sample_comm)
            if all(my_score > self._evaluate_hand_strength(opp_hand + sample_comm) for opp_hand in opp_hands):
                wins += 1
                
        return wins / simulations if simulations > 0 else 0

    def _hand_rank(self, rank_name: str) -> int:
        ranks = {
            'High card': 0, 'One pair': 1, 'Two pair': 2, 
            'Three of a kind': 3, 'Straight': 4, 'Flush': 5, 
            'Full house': 6, 'Four of a kind': 7, 
            'Straight flush': 8, 'Royal flush': 9
        }
        return ranks.get(rank_name, 0)

    def _get_unseen_cards(self, visible: List[str], player_bets: dict) -> List[str]:
        deck = []
        suits = ['d', 'c', 'h', 's']
        ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
        
        for s in suits:
            for r in ranks:
                card = f"{r}{s}"
                if card not in visible:
                    for _, action in player_bets.items():
                        if 'Fold' in action and card in action:
                            continue
                    deck.append(card)
        return deck

    def _count_active_players(self, player_bets: dict) -> int:
        count = 0
        for pid, action in player_bets.items():
            if 'Fold' not in action:
                count += 1
        return max(count, 1)

    def evaluate_hand(self, cards: List[str]) -> int:
        return self._evaluate_hand_strength(cards)

    def _evaluate_hand_strength(self, cards: List[str]) -> int:
        ranks = {'2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '10':10, 'J':11, 'Q':12, 'K':13, 'A':14}
        suit_map = {'d':0, 'c':1, 'h':2, 's':3}
        
        value_cards = []
        suits = [0] * 4
        for card in cards:
            rank = card[:-1]
            suit = suit_map[card[-1]]
            value_cards.append((ranks[rank], suit))
            suits[suit] += 1
            
        value_cards.sort(reverse=True)
        num_cards = len(value_cards)
        high_cards = [c[0] for c in value_cards]
        unique_suits = set(s for _, s in value_cards)
        same_suit = len(unique_suits) < 2
        
        if same_suit and num_cards >=5:
            flush_cards = [c[0] for c in value_cards]
            flush_cards.sort(reverse=True)
            return self._compute_hand_value(flush_cards, same_suit)
        
        rank_list = sorted(value_cards, key=lambda x: (x[0], x[1]), reverse=True)
        return self._compute_hand_value([c[0] for c in rank_list], len(set(c[0] for c in value_cards)) < len(value_cards))
    
    def _compute_hand_value(self, ranks: List[int], suits: bool) -> int:
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        pairs = []
        triple = None
        quad = None
        for r, count in rank_counts.items():
            if count == 4:
                quad = r
            elif count == 3:
                triple = r
            elif count == 2:
                pairs.append(r)
                
        pairs.sort(reverse=True)
        kickers = list(set(ranks) - set(pairs))
        if triple is not None:
            kickers = list(set(kickers) - {triple})
        kickers.sort(reverse=True)
        
        if quad is not None:
            return 100000000 * quad
        if triple is not None and pairs:
            return 1000000 * triple + 10000 * pairs[0]
        if suits:  
            return 500000 + sum(r for i, r in enumerate(ranks[:5]))
        if triple is not None:
            return 100000 * triple + sum(kickers[:2])
        if pairs:
            pair_value = sum(p * (100 ** i) for i, p in enumerate(pairs[:2]))
            return pair_value + sum(kickers[:3])
        return max(ranks)

    def _hand_value_to_strength(self, value: int) -> float:
        if value > 100000000:
            return 1.0
        if value > 1000000:
            return 0.9 + min(0.09, value / 10000000.0)
        if value > 100000:
            return 0.8 + min(0.09, value / 1000000.0)
        if value > 500000:
            return 0.7 + min(0.09, value / 1000000.0)
        if value > 10000:
            return 0.6 + min(0.09, value / 100000.0)
        if value > 1000:
            return 0.4 + min(0.19, value / 10000.0)
        return min(0.4, value / 10000.0)