from abc import ABC, abstractmethod
from typing import List, Tuple, Dict, Any
import itertools

class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None
    
    def set_id(self, player_id: int) -> None:
        self.id = player_id

    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass

    @abstractmethod
    def on_round_start(self, round_state: Any, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def get_action(self, round_state: Any, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass

    @abstractmethod
    def on_end_round(self, round_state: Any, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def on_end_game(self, round_state: Any, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.bb_amount = 0
        self.hole_cards = []
        self.position_type = ''
        self.n_players = 0
        self.all_players = []
        self.preflop_position = 0
        self.rank_order = '23456789TJQKA'
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        self.bb_amount = blind_amount
        self.n_players = len(all_players)
        self.all_players = all_players
        
        bb_index = all_players.index(big_blind_player_id)
        utg_index = (bb_index + 1) % self.n_players
        my_index = all_players.index(self.id)
        
        self.preflop_position = (my_index - utg_index) % self.n_players
        
        early_bound = min(2, self.n_players)
        middle_bound = min(4, self.n_players)
        
        if self.preflop_position < early_bound:
            self.position_type = 'early'
        elif self.preflop_position < middle_bound:
            self.position_type = 'middle'
        else:
            self.position_type = 'late'
            
        player_index = all_players.index(self.id)
        self.hole_cards = [player_hands[2*player_index], player_hands[2*player_index+1]]
    
    def on_round_start(self, round_state: Any, remaining_chips: int) -> None:
        pass

    def _evaluate_hand(self, hand: List[str]) -> Tuple[int, ...]:
        ranks = sorted([self.rank_order.index(card[0]) for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        suit_counts = {s: suits.count(s) for s in set(suits)}
        flush = max(suit_counts.values()) >= 5 if suit_counts else False
        flush_suit = [s for s, count in suit_counts.items() if count >= 5][0] if flush else None
        flush_cards = [card for card in hand if card[1] == flush_suit] if flush else []
        flush_ranks = sorted([self.rank_order.index(card[0]) for card in flush_cards], reverse=True) if flush else []
        
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        counts = sorted(rank_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        
        # Check straight
        unique_ranks = sorted(set(ranks), reverse=True)
        straight_high = None
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight_high = unique_ranks[i]
                break
        if not straight_high and 12 in unique_ranks:  # Ace low straight
            low_ranks = set(unique_ranks)
            if all(r in low_ranks for r in [0, 1, 2, 3]):
                straight_high = 3
        
        # Straight flush
        if flush and straight_high is not None:
            straight_flush = False
            for i in range(len(flush_ranks) - 4):
                if flush_ranks[i] - flush_ranks[i+4] == 4:
                    straight_flush = True
                    straight_flush_high = flush_ranks[i]
                    break
            if not straight_flush and 12 in flush_ranks and all(r in flush_ranks for r in [0,1,2,3]):
                straight_flush_high = 3
                straight_flush = True
            if straight_flush:
                if straight_flush_high == 12:
                    return (9, 12)
                return (8, straight_flush_high)
        
        # Four of a kind
        if counts[0][1] == 4:
            return (7, counts[0][0], counts[1][0])
        
        # Full house
        if counts[0][1] == 3 and counts[1][1] >= 2:
            return (6, counts[0][0], counts[1][0])
        
        # Flush
        if flush:
            return (5, *flush_ranks[:5])
        
        # Straight
        if straight_high is not None:
            return (4, straight_high)
        
        # Three of a kind
        if counts[0][1] == 3:
            kickers = [r for r in unique_ranks if r != counts[0][0]][:2]
            return (3, counts[0][0], *kickers)
        
        # Two pair
        if counts[0][1] == 2 and counts[1][1] == 2:
            pairs = sorted([counts[0][0], counts[1][0]], reverse=True)
            kicker = [r for r in unique_ranks if r not in pairs][0]
            return (2, *pairs, kicker)
        
        # One pair
        if counts[0][1] == 2:
            kickers = [r for r in unique_ranks if r != counts[0][0]][:3]
            return (1, counts[0][0], *kickers)
        
        # High card
        return (0, *unique_ranks[:5])
    
    def hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        best_strength = ()
        for combo in itertools.combinations(all_cards, 5):
            strength = self._evaluate_hand(list(combo))
            if not best_strength or strength > best_strength:
                best_strength = strength
        return best_strength
    
    def get_action(self, round_state: Any, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        player_bets = round_state.player_bets
        our_bet = player_bets.get(str(self.id), 0)
        amount_to_call = current_bet - our_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        
        # Preflop strategy
        if round_state.round == 'Preflop':
            hand_str = ''
            card1, card2 = self.hole_cards
            r1, s1 = card1[0], card1[1]
            r2, s2 = card2[0], card2[1]
            idx1 = self.rank_order.index(r1)
            idx2 = self.rank_order.index(r2)
            
            if idx1 < idx2:
                r1, r2 = r2, r1
            if r1 == r2:
                hand_str = r1 + r2
            else:
                hand_str = r1 + r2 + ('s' if s1 == s2 else 'o')
            
            premium_hands = ['AA', 'KK', 'QQ', 'JJ', 'TT', 'AKs', 'AQs', 'AKo']
            good_hands = ['99', '88', '77', '66', '55', '44', '33', '22', 
                          'AJs', 'ATs', 'A9s', 'A8s', 'A7s', 'A6s', 'A5s', 
                          'A4s', 'A3s', 'A2s', 'KQs', 'KJs', 'KTs', 'QJs', 
                          'QTs', 'JTs', 'J9s', 'T9s', '98s', '87s', '76s', 
                          '65s', '54s', 'AQo', 'AJo', 'ATo', 'KQo']
            
            if hand_str in premium_hands:
                hand_group = 2
            elif hand_str in good_hands:
                hand_group = 1
            else:
                hand_group = 0
            
            # Big blind special case
            is_bb = self.id == round_state.current_player[0] and our_bet == self.bb_amount
            if hand_group == 0:
                if is_bb and amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
            
            if hand_group == 2:
                if current_bet <= self.bb_amount:
                    raise_amount = min(3 * self.bb_amount, max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    if amount_to_call <= 0.1 * remaining_chips:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
            
            if hand_group == 1:
                if amount_to_call == 0:
                    if self.position_type in ['late', 'middle']:
                        return (PokerAction.RAISE, min(3 * self.bb_amount, max_raise))
                    return (PokerAction.CHECK, 0)
                else:
                    if amount_to_call <= 0.05 * remaining_chips:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
        
        # Postflop strategy
        else:
            hand_value = self.hand_strength(self.hole_cards, round_state.community_cards)
            hand_rank = hand_value[0] if hand_value else 0
            
            # Strong hand (two pair or better)
            if hand_rank >= 2:
                if amount_to_call == 0:
                    bet_amount = min(pot // 2, max_raise)
                    if bet_amount > 0:
                        return (PokerAction.RAISE, bet_amount)
                    return (PokerAction.CHECK, 0)
                else:
                    pot_odds = amount_to_call / (pot + amount_to_call + 1e-5)
                    if pot_odds < 0.3:
                        return (PokerAction.CALL, 0)
                    elif hand_rank >= 5:  # Very strong hand
                        return (PokerAction.RAISE, min(amount_to_call * 2, max_raise))
                    return (PokerAction.FOLD, 0)
            
            # Medium hand (pair or draw)
            elif hand_rank == 1:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    pot_odds = amount_to_call / (pot + amount_to_call + 1e-5)
                    if pot_odds < 0.2:
                        return (PokerAction.CALL, 0)
                    return (PokerAction.FOLD, 0)
            
            # Weak hand
            else:
                if amount_to_call == 0:
                    return (PokerAction.CHECK, 0)
                return (PokerAction.FOLD, 0)
        
        # Default action
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: Any, remaining_chips: int) -> None:
        pass

    def on_end_game(self, round_state: Any, player_score: float, all_scores: dict, active_players_hands: dict) -> None:
        pass