import math
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum
from dataclasses import dataclass
import random

# Region: Enums and Classes from type definitions
class PokerAction(Enum):
    FOLD = 1
    CHECK = 2
    CALL = 3
    RAISE = 4
    ALL_IN = 5

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

@dataclass
class RoundStateClient:
    round_num: int
    round: str
    community_cards: List[str]
    pot: int
    current_player: List[int]
    current_bet: int
    min_raise: int
    max_raise: int
    player_bets: Dict[str, int]
    player_actions: Dict[str, str]
    side_pots: List[Dict[str, Any]] = None

    @classmethod
    def from_message(cls, message: Dict[str, Any]) -> 'RoundStateClient':
        return cls(
            round_num=message['round_num'],
            round=message['round'],
            community_cards=message['community_cards'],
            pot=message['pot'],
            current_player=message['current_player'],
            current_bet=message['current_bet'],
            min_raise=message['min_raise'],
            max_raise=message['max_raise'],
            player_bets=message['player_bets'],
            player_actions=message['player_actions'],
            side_pots=message.get('side_pots', [])
        )

class Bot(ABC):
    def __init__(self) -> None:
        self.id = None

    def set_id(self, player_id: int) -> None:
        self.id = player_id

    @abstractmethod
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None:
        pass

    @abstractmethod
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        pass

    @abstractmethod
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None:
        pass

    @abstractmethod
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: Dict, active_players_hands: Dict) -> None:
        pass
# EndRegion

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.players: List[int] = []
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.initial_dealer_index: int = None
        self.my_hole_cards: List[str] = []
        self.current_round: str = ""
        self.starting_chips: int = 0
        self.remaining_chips: int = 0
        self.blind_amount: int = 0

    def get_position_info(self, round_num: int) -> int:
        if not self.players:
            return 0
        current_dealer_index = (self.initial_dealer_index + round_num) % len(self.players)
        our_index = self.players.index(self.id)
        relative_pos = (our_index - current_dealer_index) % len(self.players)
        return relative_pos

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.remaining_chips = starting_chips
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.players = all_players
        self.my_hole_cards = player_hands
        self.blind_amount = blind_amount
        # Compute initial dealer index: to the left of the small blind
        try:
            small_blind_idx = self.players.index(small_blind_player_id)
            self.initial_dealer_index = (small_blind_idx - 1) % len(self.players)
        except:
            self.initial_dealer_index = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.current_round = round_state.round

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: Dict, active_players_hands: Dict):
        pass

    @staticmethod
    def get_hand_score(cards: List[str]) -> float:
        """Convert a hand of 5-7 cards to a score. Higher score means better hand."""
        return HandEvaluator.evaluate_hand(cards)

    def count_outs(self, my_cards: List[str], community: List[str]) -> int:
        # A simplified out counter that only counts flush and open-ended straight draws
        all_cards = community + my_cards
        suits = [card[1] for card in all_cards]
        ranks = [self.rank_to_value(card[0]) for card in all_cards]
        
        # Count flush outs: 13 of each suit total, we need 5 of same
        suit_count = {}
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        max_suit = max(suit_count.values())
        if max_suit >= 4:
            # We have 4 cards of same suit, so outs = 13 - max_suit (minus any that are already in the hand or seen)
            # Actually, since we don't know the opponent cards, we cannot compute exactly. Assume deck is 52 cards.
            # We have seen 5 community + 2 ours = 7 cards. And we have `max_suit` in common.
            return 13 - max_suit
        else:
            # Check straight draw
            distinct_ranks = sorted(set(ranks))
            return 0

    @staticmethod
    def rank_to_value(rank: str) -> int:
        order = "23456789TJQKA"
        return order.index(rank) if rank in order else 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.remaining_chips = remaining_chips
        player_id_str = str(self.id)

        # Current bet and my investment
        my_bet = round_state.player_bets.get(player_id_str, 0)
        to_call = round_state.current_bet - my_bet
        pot = round_state.pot

        # If to_call is negative, we clamp to 0 (shouldn't happen)
        if to_call < 0:
            to_call = 0

        # Position
        relative_pos = self.get_position_info(round_state.round_num)
        n_players = len(self.players)

        if self.current_round == 'Preflop':
            hand_type = self.classify_preflop_hand(self.my_hole_cards)
            group = self.preflop_hand_to_group(hand_type)

            # Check for big blind
            is_in_bb = self.id == self.big_blind_player_id

            # If we're the big blind and no one raised, we can check
            no_raises_yet = round_state.current_bet <= self.blind_amount * 2
            current_actions = round_state.player_actions

            if to_call == 0 and self.id not in current_actions:
                # First to act
                # Check if we are in the big blind: then we can check without doing anything
                if group == 0:
                    # Group 0: fold
                    return (PokerAction.FOLD, 0)
                elif group <= 3:
                    # Groups 1-3: raise
                    # Open raise: 3.5 big blind in any position
                    raise_amount = int(min(3.5 * self.blind_amount, round_state.max_raise))
                    raise_amount = max(raise_amount, round_state.min_raise)
                    return (PokerAction.RAISE, raise_amount)
                elif group == 4:
                    if relative_pos > 3 or is_in_bb:
                        # Fold early, call otherwise
                        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)
                else:
                    if relative_pos >= 5 and is_in_bb:
                        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # There is a bet to call or there was a previous action
                if to_call == 0:
                    # It's possible to check? In preflop, we might not have to call anything, but generally the BB and SB are already posted.
                    return (PokerAction.CHECK, 0)
                else:
                    # Someone else raised
                    if to_call <= 0.2 * self.starting_chips:  # Only call small raises
                        if group <= 4:
                            # Call
                            if to_call <= self.remaining_chips:
                                return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.ALL_IN, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        if group <= 1:
                            # Re-raise: 3x the raise amount or if 3x is too big, just all-in
                            base_raise = to_call * 3
                            if base_raise < self.remaining_chips:
                                return (PokerAction.RAISE, base_raise)
                            else:
                                return (PokerAction.ALL_IN, 0)
                        elif group <= 3:
                            if to_call <= 0.1 * self.starting_chips:
                                return (PokerAction.CALL, 0) if to_call <= self.remaining_chips else (PokerAction.ALL_IN, 0)
                            else:
                                return (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.FOLD, 0)

        else:  # Post-flop: Flop, Turn, River
            my_hand = self.my_hole_cards + list(round_state.community_cards)
            current_hand_value = HandEvaluator.evaluate_hand(my_hand)

            if round_state.community_cards:
                # Estimate our hand strength
                max_possible = 900000  # approx max of our scoring function (royal flush)
                normalized_strength = current_hand_value / max_possible

                # Pot_odds = amount to call / (pot after we call)
                if to_call == 0:
                    pot_odds = 0.0
                else:
                    total_pot = pot + to_call
                    pot_odds = to_call / total_pot

                # Define thresholds
                if normalized_strength > 0.7:
                    # Very strong: We are near the nuts -> bet big for value
                    if to_call > 0:
                        # If someone has bet, we should raise
                        if self.remaining_chips > round_state.min_raise:
                            raise_amt = min(int(0.5 * pot), round_state.max_raise)
                            raise_amt = max(raise_amt, round_state.min_raise)
                            return (PokerAction.RAISE, raise_amt)
                        else:
                            return (PokerAction.ALL_IN, 2)
                    else:
                        # We are first to act: bet
                        # We bet about half pot
                        bet_amt = min(int(0.5 * pot), round_state.max_raise)
                        bet_amt = max(bet_amt, round_state.min_raise)
                        return (PokerAction.RAISE, bet_amt)

                elif normalized_strength > 0.4:
                    # Medium strength: we can call if odds are good
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        # To call, we must not have too high pot odds
                        # If we have a draw, count outs and see
                        outs = self.count_outs(self.my_hole_cards, round_state.community_cards)
                        outs = min(outs, 15)  # cap at say 15 outs
                        turn_factor = 0.044 if round_state.round in ['Flop'] else 0.021
                        # We assume two cards to go on flop, one on turn
                        if round_state.round == 'Flop':
                            equity = outs * 0.088
                        elif round_state.round == 'Turn':
                            equity = outs * 0.044
                        else:
                            equity = 0  # on river, draws don't matter

                        equity_guess = max(equity, normalized_strength)

                        if pot_odds < equity_guess - 0.15:  # we need a margin
                            # Call
                            return (PokerAction.CALL, 0)
                        else:
                            # Fold
                            return (PokerAction.FOLD, 0)
                else:
                    # Weak hand: we fold or check
                    if to_call == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # No community cards? Should not be in postflop then, default to check/fold
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

    @staticmethod
    def preflop_hand_to_group(hand_type: str) -> int:
        # Group 1: AA, KK
        if hand_type in ('AA', 'KK'):
            return 1
        elif hand_type in ('QQ', 'JJ', 'AKs'):
            return 2
        elif hand_type in ('AKo', 'AQs','TT'):
            return 3
        elif hand_type in ('99', '88', 'AJs', 'ATs', 'KQs', 'AQo'):
            return 4
        elif hand_type in ('77', '66', 'A9s', 'A8s', 'KJs', 'KTs', 'QJs', 'JTs', 'T9s', 'AJo','KQo'):
            return 5
        else:
            return 6

    def classify_preflop_hand(self, hole_cards: List[str]) -> str:
        # Sort the hole cards by rank
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        val1 = "23456789TJQKA".index(rank1)
        val2 = "23456789TJQKA".index(rank2)
        if val1 < val2:
            rank1, rank2 = rank2, rank1
            suit1, suit2 = suit2, suit1
        suited = suit1 == suit2
        hole_str = ''
        if rank1 == rank2:
            return rank1 + rank2  # e.g., 'AA'
        else:
            hole_str = rank1 + rank2
            if suited:
                hole_str += 's'
            else:
                hole_str += 'o'
        return hole_str

class HandEvaluator:
    @staticmethod
    def evaluate_hand(cards: List[str]) -> float:
        """Evaluate a hand of 5-7 cards and return a score. The hand uses the best 5 cards.
           The score format: is a float that can be compared to rank hands. Higher is better.
           We use a base of 100 for high card, 200 for one pair, ... royal flush 900.
           Then we break down the kickers: [hand type, highest, ...] -> base**5 + base**4 * ... 
        """
        colors = [card[1] for card in cards]
        values = sorted([HandEvaluator.rank_to_value(card[0]) for card in cards], reverse=True)

        # Check for flush
        is_flush = False
        flush_suit = None
        for suit in ['h','d','c','s']:
            if colors.count(suit) >= 5:
                is_flush = True
                flush_suit = suit
                flush_cards = [HandEvaluator.rank_to_value(card[0]) for card in cards if card[1]==suit]
                flush_cards.sort(reverse=True)
                # Take the top 5 if more than 5
                if len(flush_cards) > 5:
                    flush_cards = flush_cards[:5]
                break

        # Check for straight (in sorted values)
        straight_high = None
        uniques = sorted(set(values), reverse=True)
        # Loop to see if we have 5 consecutive
        count = 1
        for i in range(1, len(uniques)):
            if uniques[i] == uniques[i-1] - 1:
                count += 1
                if count == 5:
                    straight_high = uniques[i-1] + 1  # because the high is i-1, so from i-1 to current
                    break
            else:
                if uniques[i] != uniques[i-1] - 2:   # check for gap
                    if i < len(uniques)-4:
                        # reset only if we don't have 5 consecutive left in the array
                        # we won't break early if we might still form one
                        count = 1
                else:
                    # gap of one? we don't do low straight from A? So skip
                    count = 1
        # Check for Ace-low straight:  A,5,4,3,2
        if uniques and uniques[0] == 12 and 0 in uniques and 1 in uniques and 2 in uniques and 3 in uniques:
            straight_high = 3   # 5 high straight (4,3,2,1,0) where 0 is the deuce

        # Group by same values: looking for 4 of a kind, full house, etc.
        value_counts = {}
        for v in values:
            value_counts[v] = value_counts.get(v,0) + 1
        groups = sorted(value_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        # groups: (value, frequency), sorted by frequency then rank.

        hand_type = None
        tie_breakers = None

        # Straight flush?
        if straight_high is not None and is_flush:
            # In the flush suit, we must have a straight
            # We know the flush cards - then check if in the flush_cards there is a straight
            num_flush = len(flush_cards)
            if num_flush < 5:
                hand_type = None
            else:
                # Check for straight in the flush_cards
                flush_cards_sorted = sorted(flush_cards, reverse=True)
                count = 1
                high_in_straight = None
                for i in range(1, len(flush_cards_sorted)):
                    if flush_cards_sorted[i] == flush_cards_sorted[i-1] - 1:
                        count += 1
                        if count == 5:
                            high_in_straight = flush_cards_sorted[i-1] + 1
                    elif flush_cards_sorted[i] < flush_cards_sorted[i-1] - 1:
                        count = 1
                if high_in_straight is not None:
                    hand_type = 8
                    tie_breakers = [high_in_straight]
                # Also check for A,5,4,3,2
                if not hand_type:
                    if flush_cards_sorted[0] == 12 and flush_cards_sorted[-4] == 3 and flush_cards_sorted[-1]==0:
                        if flush_cards_sorted[1:5] == [11,10,9,8]:
                            pass # not the low straight
                        else:
                            hand_type = 8
                            tie_breakers = [3]  # 5 high straight flush
            if hand_type == 8:
                # Royal flush?
                if tie_breakers[0] == 13:
                    hand_type = 9  # Actually, royal flush is a straight flush at 10,J,Q,K,A -> but we just set it to 9
                    tie_breakers = []

        if not hand_type:
            # Four of a kind?
            if groups[0][1] == 4:
                hand_type = 7
                quad_val = groups[0][0]
                # The kicker is the next best
                kicker = 0
                for val, cnt in groups:
                    if val != quad_val:
                        kicker = val
                        break
                tie_breakers = [quad_val, kicker]
            elif groups[0][1] == 3 and groups[1][1] >= 2:
                hand_type = 6
                trip_val = groups[0][0]
                pair_val = groups[1][0]
                tie_breakers = [trip_val, pair_val]
            elif is_flush:
                hand_type = 5
                tie_breakers = flush_cards[:5]
            elif straight_high is not None:
                hand_type = 4
                tie_breakers = [straight_high]
            elif groups[0][1] == 3:
                hand_type = 3
                trip_val = groups[0][0]
                # Kickers: the two next highest cards
                kickers = sorted([v for v, cnt in value_counts.items() if v != trip_val], reverse=True)[:2]
                tie_breakers = [trip_val] + kickers
            elif groups[0][1] == 2:
                if len(groups) >=2 and groups[1][1] == 2:
                    hand_type = 2
                    pair1 = groups[0][0]
                    pair2 = groups[1][0]
                    kicker_val = None
                    for v in groups[2:]:
                        if v[0] != pair1 and v[0] != pair2:
                            kicker_val = v[0]
                            break
                    tie_breakers = sorted([pair1, pair2], reverse=True) + [kicker_val] if kicker_val is not None else []
                else:
                    hand_type = 1
                    pair_val = groups[0][0]
                    kickers = sorted([v for v, cnt in groups if cnt == 1], reverse=True)[:3]
                    tie_breakers = [pair_val] + kickers
            else:
                hand_type = 0
                tie_breakers = sorted([v for v, cnt in groups if cnt ==1], reverse=True)[:5]

        # If we haven't set tie_breakers, use the entire hand in descending order as kickers?
        if tie_breakers is None:
            tie_breakers = sorted(values, reverse=True)[:5]

        # Build a number: base is 10000 for hand_type, then tie_breakers (each taking 2 digits? but values 0-12)
        # We allow 100 per tie_breaker
        # We do: hand_type at 1e6, tie_breakers[0] at 1e4, then tie_breakers[1] at 1e2, etc?
        # But we have up to 5 tie_breakers
        parts = [hand_type] + tie_breakers
        # Pad with zeros to 6 elements? [hand_type, t1, t2, t3, t4, t5]
        while len(parts) < 6:
            parts.append(0)
        # Score = h * 1000000 + t1 * 10000 + t2 * 1000 + t3 * 100 + t4 * 10 + t5
        score = parts[0] * 1000000
        for i in range(1,6):
            # parts[i] in [0,15] so * 10^(4,3,2,1,0) -> but 10^(5*2) = 10^10 might be too big?
            # Use base 20? But we don't need such big numbers
            score += parts[i] * (10 ** (4 - i + 1))
        # But let's use base 20 for the tie_breakers: each from 0 to 15 so base 16 actually?
        # We'll just create a number: hand_type * 1.0e8 + t1 * 1e6 + t2 * 1e4 + t3 * 1e2 + t4 * 1e0
        return score

    @staticmethod
    def rank_to_value(rank: str) -> int:
        order = "23456789TJQKA"
        return order.index(rank)