from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.player_hands = {}
        self.current_round = None
        self.equity_table = {}
        self.hand_strength_cache = {}
        self.positional_advantage = {}
        self.volatility_factor = 0.1
        self.aggression_factor = 1.2
        self.tightness_factor = 0.8

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): None for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_cache.clear()
        self.equity_table = self._initialize_equity_table()
        self.positional_advantage = {pid: self._assess_position(pid, all_players) for pid in all_players}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        self.aggression_factor = max(1.0, min(3.0, self.aggression_factor + random.uniform(-0.1, 0.1)))
        self.tightness_factor = max(0.5, min(1.0, self.tightness_factor + random.uniform(-0.05, 0.05)))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            player_id_str = str(self.id)
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            player_bet = round_state.player_bets.get(player_id_str, 0)

            hole_cards = self.player_hands.get(player_id_str, [])
            if not hole_cards:
                return PokerAction.FOLD, 0

            hand_strength = self._assess_hand_strength(hole_cards, community_cards)
            stage_multiplier = self._get_stage_multiplier(round_state.round)
            position_value = self.positional_advantage.get(self.id, 0.5)
            aggression = self.aggression_factor * (1 + position_value - self.tightness_factor)
            effective_power = hand_strength * stage_multiplier * aggression

            call_amount = current_bet - player_bet
            is_big_blind = self.id == self.big_blind_player_id
            is_small_blind = self.id == self.small_blind_player_id

            if current_bet == 0:
                if effective_power > 0.7:
                    raise_amount = min(max(int(pot * 0.75), min_raise), max_raise)
                    if raise_amount >= remaining_chips * 0.5 and effective_power > 0.9:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif effective_power > 0.4:
                    return PokerAction.CHECK, 0
                else:
                    if (is_big_blind or is_small_blind) and round_state.round == 'Preflop':
                        return PokerAction.CHECK, 0
                    return PokerAction.FOLD, 0

            if call_amount > remaining_chips:
                call_amount = remaining_chips

            if call_amount > 0:
                call_cost_ratio = call_amount / (pot + call_amount + 1e-9)
                if effective_power > call_cost_ratio + 0.2:
                    if effective_power > 0.8 and min_raise <= remaining_chips:
                        raise_amount = min(int(pot * (1.5 + random.uniform(0.1, 0.4))), max_raise)
                        if raise_amount >= remaining_chips * 0.7:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, raise_amount
                    elif effective_power > 0.5 or call_cost_ratio < 0.3:
                        if call_amount >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    if effective_power > 0.6 and random.random() < 0.2:
                        bluff_factor = (1 - effective_power) * position_value
                        if pot > self.blind_amount * 8 and bluff_factor > 0.3:
                            bluff_raise = min(int(pot * 0.6), max_raise)
                            if bluff_raise >= remaining_chips * 0.6:
                                return PokerAction.ALL_IN, 0
                            return PokerAction.RAISE, bluff_raise
                    return PokerAction.FOLD, 0

            if effective_power > 0.7:
                raise_amount = min(max(int(pot * 0.7), min_raise), max_raise)
                if raise_amount >= remaining_chips * 0.7:
                    return PokerAction.ALL_IN, 0
                return PokerAction.RAISE, raise_amount
            elif effective_power > 0.4:
                return PokerAction.CHECK, 0
            else:
                if round_state.round != 'Preflop' and random.random() < 0.1:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        except Exception as e:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        if remaining_chips <= 0:
            self.tightness_factor = min(1.0, self.tightness_factor + 0.1)
            self.aggression_factor = max(1.0, self.aggression_factor - 0.2)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.hand_strength_cache.clear()
        if hasattr(self, 'equity_table'):
            self.equity_table = {}

    def _initialize_equity_table(self) -> Dict[str, float]:
        preflop_equity = {
            'AA': 85.0, 'KK': 82.0, 'QQ': 79.5, 'JJ': 77.0,
            'TT': 74.5, '99': 72.0, '88': 69.5, '77': 67.0,
            '66': 64.5, '55': 62.0, '44': 59.5, '33': 57.0, '22': 54.5,
            'AKs': 67.0, 'AQs': 66.5, 'AJs': 66.0, 'ATs': 65.5,
            'A9s': 65.0, 'A8s': 64.5, 'A7s': 64.0, 'A6s': 63.5,
            'A5s': 63.0, 'A4s': 62.5, 'A3s': 62.0, 'A2s': 61.5,
            'AKo': 65.0, 'AQo': 64.5, 'AJo': 64.0, 'ATo': 63.5,
            'KQs': 64.0, 'QJs': 62.5, 'JTs': 61.0, 'T9s': 60.5,
            '98s': 59.0, '87s': 58.0, '76s': 57.0, '65s': 56.0,
        }
        return preflop_equity

    def _parse_card(self, card: str) -> Tuple[str, str]:
        if len(card) == 2:
            rank, suit = card[0], card[1]
        elif len(card) == 3:
            rank, suit = card[0:2], card[2]
        else:
            rank, suit = '2', 'h'
        return rank, suit

    def _card_rank_value(self, rank: str) -> int:
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8,
                    '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank, 2)

    def _hand_rank_category(self, hole_cards: List[str], community_cards: List[str]) -> int:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0

        ranks = [self._card_rank_value(self._parse_card(card)[0]) for card in all_cards]
        suits = [self._parse_card(card)[1] for card in all_cards]
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        is_flush = any(count >= 5 for count in suit_count.values())
        sorted_ranks = sorted(set(ranks), reverse=True)
        has_straight = False
        if len(sorted_ranks) >= 5:
            for i in range(len(sorted_ranks) - 4):
                if all(sorted_ranks[i + j] == sorted_ranks[i] - j for j in range(5)):
                    has_straight = True
                    break
            if 14 in sorted_ranks and {13,12,11,10}.issubset(set(sorted_ranks)):
                has_straight = True

        if is_flush and has_straight:
            return 9
        if 4 in rank_count.values():
            return 8
        if 3 in rank_count.values() and 2 in rank_count.values():
            return 7
        if is_flush:
            return 6
        if has_straight:
            return 5
        if 3 in rank_count.values():
            return 4
        if list(rank_count.values()).count(2) >= 2:
            return 3
        if 2 in rank_count.values():
            return 2
        return 1

    def _assess_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        cache_key = (tuple(sorted(hole_cards)), tuple(sorted(community_cards)))
        if cache_key in self.hand_strength_cache:
            return self.hand_strength_cache[cache_key]

        if len(community_cards) == 0:
            hole_str = ''.join(sorted([c[0] for c in hole_cards], reverse=True))
            suited = 's' if hole_cards[0][1] == hole_cards[1][1] else 'o'
            pair_str = hole_str[0] + hole_str[1] + suited
            if pair_str in self.equity_table:
                strength = self.equity_table[pair_str] / 100.0
            else:
                base = 0.4
                if hole_str[0] == hole_str[1]:
                    base += 0.1
                base += (self._card_rank_value(hole_str[0]) + self._card_rank_value(hole_str[1])) / 40.0
                base += 0.05 if suited == 's' else 0.0
                strength = min(base, 0.9)
        elif len(community_cards) < 5:
            category = self._hand_rank_category(hole_cards, community_cards)
            possible_improvements = 0
            if category < 7:
                possible_improvements += self._estimate_draw_potential(hole_cards, community_cards)
            strength = (category + possible_improvements) / 15.0
        else:
            category = self._hand_rank_category(hole_cards, community_cards)
            strength = category / 10.0

        strength = max(0.0, min(1.0, strength))
        self.hand_strength_cache[cache_key] = strength
        return strength

    def _estimate_draw_potential(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        ranks = [self._card_rank_value(self._parse_card(card)[0]) for card in all_cards]
        suits = [self._parse_card(card)[1] for card in all_cards]
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1

        flush_draw = max(suit_count.values()) == 4
        gutshot = 0
        open_ended = 0
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 1):
            if sorted_ranks[i+1] - sorted_ranks[i] == 1:
                gutshot += 1
            elif sorted_ranks[i+1] - sorted_ranks[i] == 2:
                open_ended += 1

        draw_score = 0
        if flush_draw:
            draw_score += 0.8
        if open_ended >= 2:
            draw_score += 0.7
        elif gutshot >= 2:
            draw_score += 0.4

        hole_ranks = [self._card_rank_value(self._parse_card(c)[0]) for c in hole_cards]
        if any(r in hole_ranks for r in [14, 13, 12, 11]):
            draw_score += 0.3

        return draw_score

    def _get_stage_multiplier(self, stage: str) -> float:
        return {
            'Preflop': 1.0,
            'Flop': 1.3,
            'Turn': 1.6,
            'River': 2.0
        }.get(stage, 1.0)

    def _assess_position(self, player_id: int, all_players: List[int]) -> float:
        try:
            idx = all_players.index(player_id)
            n = len(all_players)
            return (n - idx) / n
        except:
            return 0.5