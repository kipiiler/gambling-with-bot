from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.own_id = None
        self.starting_chips = 10000
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.previous_round_pot = 0
        self.positional_advantage = 0
        self.tight_aggressive_factor = 0.7
        self.hand_strength_thresholds = {
            'high_pair': 10,
            'medium_pair': 6,
            'low_pair': 2,
            'ace_high': 5,
            'suited_connectors': 4,
            'connected_cards': 3,
            'suited': 2,
            'others': 1
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.own_id = str(self.id)
        if self.own_id in player_hands:
            self.hole_cards = player_hands[self.own_id]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = []
        self.tight_aggressive_factor += 0.01  # Slight increase in aggression over time

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate preflop and postflop hand strength with basic heuristics."""
        if not hole_cards:
            return 0.0

        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        suits = [card[1] for card in hole_cards]
        ranks = [rank_map[card[0]] for card in hole_cards]
        rank_diff = abs(ranks[0] - ranks[1])

        is_suited = suits[0] == suits[1]
        is_connected = rank_diff == 1
        high_card = max(ranks)
        is_pair = ranks[0] == ranks[1]

        score = 0.0
        if is_pair:
            if high_card >= 10:
                score = self.hand_strength_thresholds['high_pair']
            elif high_card >= 6:
                score = self.hand_strength_thresholds['medium_pair']
            else:
                score = self.hand_strength_thresholds['low_pair']
        elif 14 in ranks:
            score += self.hand_strength_thresholds['ace_high']
            if is_suited or is_connected:
                score += 1
        else:
            if is_suited and is_connected:
                score = self.hand_strength_thresholds['suited_connectors']
            elif is_suited:
                score = self.hand_strength_thresholds['suited']
            elif is_connected:
                score = self.hand_strength_thresholds['connected_cards']
            else:
                score = self.hand_strength_thresholds['others']

        # Postflop logic
        if len(community_cards) > 0:
            combined_cards = hole_cards + community_cards
            board_ranks = [card[0] for card in community_cards]
            board_suits = [card[1] for card in community_cards]

            # Check for potential straights and flushes
            if len(set(board_suits)) == 1 and any(suit == board_suits[0] for suit in suits):
                score *= 2.5  # Strong flush draw or made flush

            # Check pairs with board
            board_rank_count = {}
            for r in board_ranks:
                board_rank_count[r] = board_rank_count.get(r, 0) + 1

            for r in [card[0] for card in hole_cards]:
                if r in board_rank_count:
                    if board_rank_count[r] == 1:
                        score += 5  # Pair with board
                    elif board_rank_count[r] >= 2:
                        score += 8  # Trips or full house

            # Overcards on board
            if all(rank_map[r] < high_card for r in board_ranks):
                score += 3

        return min(score / 10.0, 1.0)

    def calculate_pot_odds(self, call_amount: int, pot: int) -> float:
        """Calculate pot odds to determine if calling is profitable"""
        if call_amount == 0:
            return float('inf')
        return pot / (call_amount + 1e-9)

    def get_position_factor(self, round_state: RoundStateClient) -> float:
        """Determine position-based aggression factor"""
        active_players = round_state.current_player
        try:
            own_index = active_players.index(int(self.own_id))
            total_players = len(active_players)
            return own_index / (total_players + 1e-9)  # Later = better
        except:
            return 0.5

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            player_bet = round_state.player_bets.get(self.own_id, 0)
            to_call = max(0, current_bet - player_bet)
            pot = round_state.pot
            community_cards = round_state.community_cards
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            num_active_players = len(round_state.current_player)

            # Extract hole cards from player_hands if not saved
            if not self.hole_cards and hasattr(round_state, 'player_hands') and self.own_id in round_state.player_hands:
                self.hole_cards = round_state.player_hands[self.own_id]

            hand_strength = self.evaluate_hand_strength(self.hole_cards, community_cards)
            position_factor = self.get_position_factor(round_state)
            pot_odds = self.calculate_pot_odds(to_call, pot)

            # Decide base action
            if to_call == 0:
                # Can check
                if hand_strength > 0.3:
                    if hand_strength > 0.7 and random.random() < 0.7:
                        raise_amount = min(max_raise, int(pot * 0.75))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if random.random() < 0.2:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Must call or raise
                required_call_ratio = to_call / (pot + 1e-9)
                expected_value = hand_strength - required_call_ratio

                if expected_value > 0.1:
                    if hand_strength > 0.8 and pot > 50:
                        return (PokerAction.ALL_IN, remaining_chips)
                    elif hand_strength > 0.6 and random.random() < 0.6:
                        raise_amount = min(max_raise, max(min_raise, int(pot * 0.6)))
                        return (PokerAction.RAISE, raise_amount)
                    elif to_call <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.ALL_IN, remaining_chips)
                elif expected_value > -0.2 and to_call / remaining_chips < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)

        except Exception as e:
            # In case of any unexpected error, default to safe fold
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round data if needed
        self.previous_round_pot = round_state.pot

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optionally log final results
        pass