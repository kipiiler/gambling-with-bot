from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

# Helper functions for hand evaluation
def parse_card(card: str):
    """Convert card string to rank and suit"""
    if len(card) == 2:
        rank_str, suit = card[0], card[1]
    else:
        rank_str, suit = card[0:-1], card[-1]
    rank_dict = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    rank = rank_dict.get(rank_str, int(rank_str)) if rank_str in ['T','J','Q','K','A'] else int(rank_str)
    return rank, suit

def card_rank(card: str) -> int:
    """Returns numerical rank of a card (2=2, ..., A=14)"""
    r = card[0]
    if r == 'A': return 14
    if r == 'K': return 13
    if r == 'Q': return 12
    if r == 'J': return 11
    if r == 'T': return 10
    return int(r)

def evaluate_hand(hole_cards: List[str], community_cards: List[str]) -> int:
    """Evaluate the best 5-card hand strength (crude approximation for speed)"""
    all_cards = hole_cards + community_cards
    if len(all_cards) < 5:
        return 0
    
    # Parse all cards
    cards = [(card_rank(c), c[1]) for c in all_cards]
    ranks = sorted([c[0] for c in cards], reverse=True)
    suits = [c[1] for c in cards]
    
    # Count rank and suit frequencies
    rank_count = {}
    suit_count = {}
    for r, s in cards:
        rank_count[r] = rank_count.get(r, 0) + 1
        suit_count[s] = suit_count.get(s, 0) + 1

    # Check flush
    flush_suit = None
    for s, cnt in suit_count.items():
        if cnt >= 5:
            flush_suit = s
            break
    is_flush = flush_suit is not None

    # Check straight
    unique_ranks = sorted(set(ranks), reverse=True)
    if 14 in unique_ranks:
        unique_ranks.append(1)  # Aces can be low
        unique_ranks.sort(reverse=True)
    is_straight = False
    high_straight = 0
    for i in range(len(unique_ranks) - 4):
        if all(unique_ranks[i+j] == unique_ranks[i] - j for j in range(5)):
            is_straight = True
            high_straight = unique_ranks[i]
            break
    # Check for A-5-4-3-2 straight
    if set([14,5,4,3,2]).issubset(set(ranks)):
        is_straight = True
        high_straight = 5

    # Rank counts (for pairs, etc)
    count_rank = {}
    for r, cnt in rank_count.items():
        count_rank[cnt] = count_rank.get(cnt, []) + [r]
    for cnt in count_rank:
        count_rank[cnt].sort(reverse=True)

    # Hand scoring (very simplified)
    if is_straight and is_flush:
        if high_straight == 14:
            return 1000000  # Royal flush
        return 900000 + high_straight
    if 4 in count_rank:
        return 800000 + count_rank[4][0]
    if 3 in count_rank and 2 in count_rank:
        return 700000 + count_rank[3][0]*100 + count_rank[2][0]
    if is_flush:
        flush_ranks = sorted([r for r, s in cards if s == flush_suit], reverse=True)[:5]
        flush_score = 0
        for i, r in enumerate(flush_ranks):
            flush_score += r * (100 ** (4-i))
        return 600000 + flush_score
    if is_straight:
        return 500000 + high_straight
    if 3 in count_rank:
        kickers = sorted([r for r in ranks if r != count_rank[3][0]], reverse=True)[:2]
        return 400000 + count_rank[3][0]*10000 + kickers[0]*100 + kickers[1]
    if 2 in count_rank and len(count_rank[2]) >= 2:
        pairs = count_rank[2]
        kicker = max([r for r in ranks if r not in pairs], default=0)
        return 300000 + pairs[0]*1000 + pairs[1]*10 + kicker
    if 2 in count_rank:
        kickers = sorted([r for r in ranks if r != count_rank[2][0]], reverse=True)[:3]
        score = 200000 + count_rank[2][0]*10000
        for i, k in enumerate(kickers):
            score += k * (100 ** (2-i))
        return score
    # High card
    high_cards = ranks[:5]
    score = 100000
    for i, r in enumerate(high_cards):
        score += r * (100 ** (4-i))
    return score

def preflop_strength(hole_cards: List[str]) -> float:
    """Evaluate pre-flop hand strength (approximate)"""
    r1, r2 = card_rank(hole_cards[0]), card_rank(hole_cards[1])
    suited = hole_cards[0][1] == hole_cards[1][1]
    pair = r1 == r2
    gap = abs(r1 - r2)
    high_card = max(r1, r2)
    low_card = min(r1, r2)

    score = 0
    if pair:
        score += 70 + r1 * 2
    else:
        # Connectedness and high cards
        score += high_card * 1.5
        if suited:
            score += 5
        if gap == 0:
            score += 10
        elif gap == 1:
            score += 5
        elif gap == 2:
            score += 2
        elif gap == 3:
            score += 1
        # Bonus for connectors
        if gap <= 3 and high_card >= 10:
            score += 5

    # Gap penalty
    if gap > 3:
        score -= gap * 2

    # Broadways
    if low_card >= 10:
        score += 10

    return score / 100.0  # Normalize to approx 0-1.5

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_id = -1
        self.small_blind_id = -1
        self.all_players = []
        self.hole_cards = []
        self.player_hand_strength = {}  # Track hand strength estimates
        self.game_started = False
        self.position = None  # early/middle/late based on number of players

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players
        self.hole_cards = player_hands
        self.game_started = True
        self.player_hand_strength = {}
        
        # Estimate position: late if we act near the end
        if self.id is not None:
            active_count = len(all_players)
            if active_count <= 1:
                self.position = "late"
            else:
                turn_order = sorted(all_players)
                my_index = turn_order.index(self.id)
                if my_index >= 2 * active_count // 3:
                    self.position = "late"
                elif my_index >= active_count // 3:
                    self.position = "middle"
                else:
                    self.position = "early"

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset or update hand strength on new round
        if hasattr(round_state, 'player_hands') and round_state.player_hands:
            self.hole_cards = round_state.player_hands.get(str(self.id), [])
        # Clear previous round evaluations
        self.player_hand_strength = {}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # If not our turn
            if self.id not in round_state.current_player and round_state.current_player:
                return (PokerAction.FOLD, 0)

            # Extract our bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = max(0, round_state.current_bet - my_bet)
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            # Determine round
            is_preflop = round_state.round == 'Preflop'
            community_card_count = len(round_state.community_cards)

            # Position logic (recompute if needed)
            turn_order = sorted(self.all_players)
            my_index = turn_order.index(self.id) if self.id in turn_order else 0
            total_players = len(turn_order)
            in_position = (my_index == len(turn_order) - 1)  # Last to act

            # Evaluate hand strength
            hand_strength = 0.0
            if is_preflop:
                hand_strength = preflop_strength(self.hole_cards)
            else:
                if community_card_count >= 3:
                    hand_strength = evaluate_hand(self.hole_cards, round_state.community_cards) / 1000000.0
                # For Flop/Turn/River, hand strength is approx 0.0 to 1.5
                # But evaluation is crude

            # Estimate pot odds and implied odds
            pot_odds = 0.0
            if call_amount > 0 and round_state.pot > 0:
                pot_odds = call_amount / (round_state.pot + call_amount)

            # Default action
            action = PokerAction.FOLD
            raise_amount = 0

            # Get active players count (who haven't folded)
            active_players = [
                pid for pid in self.all_players
                if pid not in [p for p, act in round_state.player_actions.items() if act == "Fold"]
            ]
            num_active = len(active_players)

            # Stack-to-pot ratio
            spr = remaining_chips / (round_state.pot + 1)  # +1 to avoid div0

            # Aggression factor based on position and hand
            is_in_position = (my_index == max([i for i, pid in enumerate(turn_order) if pid in active_players]))
            aggression_multiplier = 1.2 if is_in_position else 0.8
            if self.position == "late":
                aggression_multiplier *= 1.3
            elif self.position == "early":
                aggression_multiplier *= 0.7

            # Decision logic
            if is_preflop:
                # Pre-flop ranges
                if hand_strength > 1.0:  # Premium (AA, KK, AKs, QQ)
                    if call_amount == 0:
                        action = PokerAction.RAISE
                        raise_amount = min(max(3 * self.blind_amount, min_raise), max_raise)
                    elif call_amount <= 3 * self.blind_amount or random.random() < 0.8:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.RAISE
                        raise_amount = min(call_amount * 2, max_raise)
                elif hand_strength > 0.7:  # Strong (JJ, AQ, TT, 99, etc)
                    if call_amount == 0:
                        action = PokerAction.RAISE
                        raise_amount = min(max(3 * self.blind_amount, min_raise), max_raise)
                    elif call_amount <= 4 * self.blind_amount:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                elif hand_strength > 0.5 or (hand_strength > 0.4 and self.position != "early"):  # Marginal
                    if call_amount == 0:
                        action = PokerAction.RAISE
                        raise_amount = min(max(3 * self.blind_amount, min_raise), max_raise)
                    elif call_amount <= 2 * self.blind_amount:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                elif hand_strength > 0.3 and self.position == "late" and random.random() < 0.3:
                    # Limp in late position with weak hands occasionally
                    if call_amount <= self.blind_amount * 2:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.FOLD
                else:
                    # Weak hand, fold unless BB and no raise
                    if self.id == self.big_blind_id and call_amount == 0:
                        action = PokerAction.CHECK
                    else:
                        action = PokerAction.FOLD

            else:
                # Post-flop play
                # Estimate win probability
                if community_card_count >= 3:
                    # On Flop, Turn, River
                    if hand_strength < 0.25:
                        win_prob = 0.1
                    elif hand_strength < 0.4:
                        win_prob = 0.2
                    elif hand_strength < 0.5:
                        win_prob = 0.3
                    elif hand_strength < 0.6:
                        win_prob = 0.4
                    elif hand_strength < 0.8:
                        win_prob = 0.6
                    elif hand_strength < 1.0:
                        win_prob = 0.8
                    else:
                        win_prob = 0.95
                else:
                    # No community cards yet (preflop already handled)
                    win_prob = hand_strength

                # Bluffing factor based on position and board texture
                board_ranks = [c[0] for c in round_state.community_cards] if round_state.community_cards else []
                board_suits = [c[1] for c in round_state.community_cards] if round_state.community_cards else []
                flush_draw = len(board_suits) >= 3 and max([board_suits.count(s) for s in set(board_suits)]) >= 2
                straight_draw = len(board_ranks) >= 3 and len(set(board_ranks)) >= 3

                # Bluff more in position
                bluff_threshold = 0.2
                if self.position == "late" and num_active == 2:
                    bluff_threshold = 0.15

                # Action matrix
                if call_amount == 0:
                    # We can check or bet
                    if win_prob > 0.6 or (win_prob > 0.4 and random.random() < 0.5):
                        # Value bet
                        bet_size = min(int(aggression_multiplier * round_state.pot * 0.7), max_raise)
                        bet_size = max(bet_size, min_raise)
                        action = PokerAction.RAISE
                        raise_amount = bet_size
                    elif win_prob > 0.3 and random.random() < bluff_threshold:
                        # Bluff bet
                        bet_size = min(int(round_state.pot * 0.5), max_raise)
                        bet_size = max(bet_size, min_raise)
                        action = PokerAction.RAISE
                        raise_amount = bet_size
                    else:
                        action = PokerAction.CHECK
                else:
                    # Facing a bet
                    effective_odds = min(1.0, pot_odds)
                    if win_prob > effective_odds + 0.1:
                        # Call or raise
                        if win_prob > 0.7 and spr > 1 and random.random() < 0.7:
                            # Raise for value
                            raise_size = min(int(round_state.pot * 0.8), max_raise)
                            raise_size = max(raise_size, call_amount * 2, min_raise)
                            action = PokerAction.RAISE
                            raise_amount = raise_size
                        else:
                            action = PokerAction.CALL
                    elif win_prob > effective_odds * 1.5 and remaining_chips > call_amount * 3:
                        # Call with draw
                        action = PokerAction.CALL
                    elif win_prob > 0.7 and call_amount < remaining_chips * 0.3:
                        # All-in with strong hand
                        if random.random() < 0.8:
                            action = PokerAction.ALL_IN
                        else:
                            action = PokerAction.CALL
                    else:
                        # Fold
                        action = PokerAction.FOLD

            # All-in logic if near short stack
            if remaining_chips <= self.blind_amount * 3:
                if is_preflop and hand_strength > 0.6:
                    action = PokerAction.ALL_IN
                elif not is_preflop and win_prob > 0.5:
                    action = PokerAction.ALL_IN
                elif call_amount > 0 and call_amount <= remaining_chips:
                    action = PokerAction.ALL_IN

            # Enforce game rules
            if action == PokerAction.RAISE:
                if raise_amount < min_raise:
                    raise_amount = min_raise
                if raise_amount > max_raise:
                    raise_amount = max_raise
                # Ensure raising results in higher bet
                if my_bet + raise_amount <= round_state.current_bet:
                    raise_amount = max(round_state.current_bet + 1 - my_bet, min_raise)
                if raise_amount > remaining_chips:
                    action = PokerAction.ALL_IN
            elif action == PokerAction.CALL:
                if call_amount == 0:
                    action = PokerAction.CHECK
                elif call_amount > remaining_chips:
                    action = PokerAction.ALL_IN
            elif action == PokerAction.ALL_IN:
                raise_amount = remaining_chips
            elif action == PokerAction.CHECK:
                if round_state.current_bet > my_bet:
                    # Can't check when facing bet
                    if call_amount <= remaining_chips:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.ALL_IN

            # Always return valid action and amount
            return (action, raise_amount if action == PokerAction.RAISE else 0)

        except Exception as e:
            # Safety fallback on error
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optionally track statistics
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, clean up
        self.game_started = False
        self.hole_cards = []
        self.player_hand_strength = {}