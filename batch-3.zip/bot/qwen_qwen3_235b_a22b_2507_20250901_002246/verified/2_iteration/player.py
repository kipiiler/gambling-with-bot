from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players = []
        self.hole_cards = []
        self.positional_advantage = False
        self.aggression_factor = 1.5  # Controls willingness to raise
        self.volatility_threshold = 0.1  # How often to bluff or deviate
        self.tightness_level = 0.3  # Threshold for hand strength to play

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_id = self.id
        if str(self.player_id) in player_hands:
            self.hole_cards = player_hands[str(self.player_id)]
        self.positional_advantage = self.is_in_position()

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards if available
        if hasattr(round_state, 'player_hands') and str(self.player_id) in round_state.player_hands:
            self.hole_cards = round_state.player_hands[str(self.player_id)]
        elif hasattr(round_state, 'community_cards') and len(round_state.community_cards) == 0:
            # Preflop, use initial hand if still valid
            pass
        self.positional_advantage = self.is_in_position()

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Extract current state
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        player_bets = round_state.player_bets
        current_player_ids = round_state.current_player

        # Determine round phase
        round_phase = round_state.round.lower()

        # Calculate effective stack to pot ratio
        stack_to_pot_ratio = (remaining_chips / (pot + 1)) if pot > 0 else float('inf')

        # Estimate hand strength
        hand_strength = self.estimate_hand_strength(community_cards)

        # Determine how many players are still active
        active_players = sum(1 for k, v in player_bets.items() if v >= 0)
        in_position = self.positional_advantage

        # Default action
        action = PokerAction.FOLD
        raise_amount = 0

        # Preflop strategy: Tight and aggressive with premium hands
        if 'preflop' in round_phase:
            if hand_strength > 0.75:
                if current_bet == 0:
                    action = PokerAction.RAISE
                    raise_amount = min(int(pot * 2), max(min_raise, remaining_chips // 20))
                    raise_amount = max(raise_amount, min_raise)
                else:
                    if current_bet <= self.blind_amount * 4:
                        action = PokerAction.CALL
                    else:
                        action = PokerAction.RAISE if hand_strength > 0.9 else PokerAction.CALL
                        if action == PokerAction.RAISE:
                            raise_amount = min(current_bet * 2, remaining_chips)
            elif hand_strength > 0.5 and random.random() > 0.7:  # Occasionally mix in middle pairs/connectors
                action = PokerAction.CALL if current_bet <= self.blind_amount * 4 else PokerAction.FOLD
            else:
                if current_bet == 0 or current_bet == self.blind_amount:
                    action = PokerAction.CALL
                elif hand_strength > 0.4 and stack_to_pot_ratio > 5:
                    action = PokerAction.CALL if random.random() > 0.8 else PokerAction.FOLD
                else:
                    action = PokerAction.FOLD

        # Post-flop strategy
        else:
            # Board texture awareness
            draw_potential = self.has_draw_potential(community_cards)
            made_hand = hand_strength > 0.65
            is_aggressive = random.random() < self.aggression_factor * 0.25

            if made_hand or draw_potential:
                if current_bet == 0:
                    action = PokerAction.RAISE
                    raise_amount = min(max(int(pot * 0.75), min_raise), max_raise)
                elif current_bet <= pot * 0.5:
                    if hand_strength > 0.8 or draw_potential:
                        if is_aggressive and stack_to_pot_ratio > 3:
                            action = PokerAction.RAISE
                            raise_amount = min(max(current_bet * 2, min_raise), max_raise)
                        else:
                            action = PokerAction.CALL
                    else:
                        action = PokerAction.CALL
                else:
                    if hand_strength > 0.9 or (draw_potential and random.random() > 0.3):
                        if stack_to_pot_ratio < 2:
                            action = PokerAction.ALL_IN if remaining_chips > 100 else PokerAction.CALL
                        else:
                            action = PokerAction.CALL if hand_strength > 0.7 else PokerAction.FOLD
                    else:
                        action = PokerAction.FOLD
            else:
                if current_bet == 0:
                    action = PokerAction.CHECK
                else:
                    # Bluff occasionally on scare boards
                    if (self.is_scare_board(community_cards) and random.random() < self.volatility_threshold
                            and stack_to_pot_ratio > 4):
                        action = PokerAction.RAISE
                        raise_amount = min(max(int(pot * 0.6), min_raise), max_raise)
                    else:
                        action = PokerAction.FOLD

        # Ensure valid action based on rules
        if action == PokerAction.RAISE:
            if raise_amount < min_raise:
                raise_amount = min_raise
            if raise_amount > max_raise:
                action = PokerAction.ALL_IN
            elif raise_amount <= 0:
                action = PokerAction.CALL

        if action == PokerAction.CHECK and current_bet > 0:
            action = PokerAction.CALL

        if action == PokerAction.CALL and current_bet == 0:
            action = PokerAction.CHECK

        if action == PokerAction.RAISE and (raise_amount < min_raise or raise_amount > max_raise):
            # Fallback logic
            if max_raise >= min_raise:
                raise_amount = min_raise
                action = PokerAction.RAISE
            else:
                action = PokerAction.CALL

        if remaining_chips <= 100 and action != PokerAction.ALL_IN:
            if hand_strength > 0.5 or random.random() < 0.2:  # Shove light with short stack
                action = PokerAction.ALL_IN
                raise_amount = remaining_chips

        # Final safety check
        if action in [PokerAction.RAISE] and (raise_amount < min_raise or raise_amount > max_raise):
            action = PokerAction.CALL

        return action, raise_amount if action == PokerAction.RAISE else 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Can be used for learning or adjusting strategy over time
        # For now, just track chip changes
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up if needed
        self.hole_cards = []

    def estimate_hand_strength(self, community_cards: List[str]) -> float:
        """ Estimate relative hand strength based on hole cards and board """
        if not self.hole_cards:
            return 0.0

        hole_ranks = [self.card_rank(card) for card in self.hole_cards]
        hole_suits = [card[-1] for card in self.hole_cards]
        board_ranks = [self.card_rank(card) for card in community_cards] if community_cards else []
        board_suits = [card[-1] for card in community_cards] if community_cards else []

        # Pairing
        paired = any(hr == br for hr in hole_ranks for br in board_ranks)
        hole_pair = hole_ranks[0] == hole_ranks[1]
        top_pair = any(hr == max(board_ranks) for hr in hole_ranks) if board_ranks else False

        # Flush draw
        all_suits = hole_suits + board_suits
        suit_count = {s: all_suits.count(s) for s in 'shdc'}
        flush_draw = max(suit_count.values()) >= 4
        made_flush = max(suit_count.values()) >= 5

        # Straight draw
        all_ranks = sorted(set(hole_ranks + board_ranks))
        straight_draw = self.has_straight_draw(all_ranks)
        made_straight = len(all_ranks) >= 5 and self.is_straight(all_ranks)

        # High cards
        high_card = max(hole_ranks)

        # Calculate base strength
        strength = 0.0
        if made_flush or made_straight:
            strength = 0.9
        elif flush_draw and straight_draw:
            strength = 0.7
        elif flush_draw or straight_draw:
            strength = 0.5
        elif paired:
            if top_pair:
                strength = 0.6
            elif hole_pair:
                strength = 0.55
            else:
                strength = 0.4
        elif hole_pair:
            strength = 0.5 if hole_ranks[0] >= 10 else 0.35
        elif len(set(hole_ranks)) == 2 and abs(hole_ranks[0] - hole_ranks[1]) == 1:
            strength = 0.3  # Connected cards
        elif high_card >= 12:  # High card T+
            strength = 0.25
        else:
            strength = 0.1

        # Position and aggression adjustment
        if self.positional_advantage:
            strength *= 1.1

        return min(strength, 1.0)

    def has_draw_potential(self, community_cards: List[str]) -> bool:
        """ Check if current hand has flush or straight draw potential """
        if not self.hole_cards or len(community_cards) < 3:
            return False

        hole_ranks = [self.card_rank(card) for card in self.hole_cards]
        hole_suits = [card[-1] for card in self.hole_cards]
        board_ranks = [self.card_rank(card) for card in community_cards]
        board_suits = [card[-1] for card in community_cards]

        # Flush draw: 4 cards of same suit
        for suit in 'shdc':
            total_suit = hole_suits.count(suit) + board_suits.count(suit)
            if total_suit >= 4:
                return True

        # Straight draw: 4 consecutive or with gap
        all_ranks = sorted(set(hole_ranks + board_ranks))
        return self.has_straight_draw(all_ranks)

    def has_straight_draw(self, ranks: List[int]) -> bool:
        """ Check if the ranks form an open-ended or gutshot straight draw """
        ranks = sorted(set(ranks))
        if len(ranks) < 2:
            return False
        for i in range(len(ranks)):
            for j in range(i + 1, len(ranks)):
                gap = ranks[j] - ranks[i]
                if gap == 4 and j - i == 3:
                    return True  # Open-ender
                if gap <= 4 and j - i >= 2:
                    # Gutshot possible
                    missing = 0
                    for r in range(ranks[i], ranks[j] + 1):
                        if r not in ranks:
                            missing += 1
                    if missing == 1:
                        return True
        return False

    def is_straight(self, ranks: List[int]) -> bool:
        """ Check if 5 consecutive ranks exist """
        ranks = sorted(set(ranks))
        for i in range(len(ranks) - 4):
            if all(ranks[i + j] == ranks[i] + j for j in range(5)):
                return True
        return False

    def is_scare_board(self, community_cards: List[str]) -> bool:
        """ Detect dangerous boards (flush/straight completed) """
        if len(community_cards) < 3:
            return False
        board_suits = [card[-1] for card in community_cards]
        suit_counts = {s: board_suits.count(s) for s in set(board_suits)}
        if max(suit_counts.values()) >= 3:
            return True
        board_ranks = [self.card_rank(card) for card in community_cards]
        return self.is_straight(board_ranks)

    def card_rank(self, card: str) -> int:
        """ Convert card string to numerical rank """
        if not card or len(card) < 2:
            return 0
        rank_char = card[:-1]
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map.get(rank_char, int(rank_char)) if rank_char in rank_map else int(rank_char)

    def is_in_position(self) -> bool:
        """ Simplified position estimation: act later than big blind if not BB """
        if self.player_id == self.big_blind_player_id:
            return False
        return True