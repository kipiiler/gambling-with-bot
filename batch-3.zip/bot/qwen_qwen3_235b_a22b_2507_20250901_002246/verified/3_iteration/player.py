from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.volatility_threshold = 0.3
        self.position_weight = 1.0
        self.hole_cards = []
        self.aggression_factor = 0.7

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize hole cards when game starts
        if str(self.id) in player_hands:
            self.hole_cards = player_hands[str(self.id)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round state if needed
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        community_cards = round_state.community_cards
        current_bet = round_state.current_bet
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        player_bets = round_state.player_bets

        # Get current player's bet
        my_bet = player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet

        # Default action
        action = PokerAction.FOLD
        amount = 0

        # If no bet to call, we can check
        if to_call == 0:
            action = PokerAction.CHECK
            return action, 0

        # Estimate hand strength (simplified)
        hand_strength = self.estimate_hand_strength(self.hole_cards, community_cards)

        # Use simple logic based on hand strength and board texture
        scare_factor = 1.0
        if len(community_cards) >= 3:
            scare_factor = self.get_scare_factor(community_cards)

        # Adjust desired bet size
        desired_bet = int(pot * hand_strength * scare_factor * self.aggression_factor)

        # Decision making
        call_affordable = to_call <= remaining_chips
        raise_affordable = min_raise <= remaining_chips

        # Always at least call with decent hands if affordable
        if hand_strength > 0.6 and call_affordable:
            if desired_bet > to_call and desired_bet <= remaining_chips and raise_affordable:
                action = PokerAction.RAISE
                amount = min(desired_bet, remaining_chips)
            else:
                action = PokerAction.CALL
                amount = 0
        elif hand_strength > 0.3 and call_affordable and to_call <= remaining_chips * 0.5:
            action = PokerAction.CALL
            amount = 0
        elif hand_strength > 0.8 and remaining_chips > 0:
            # Strong hand: go all-in if not already committed
            action = PokerAction.ALL_IN
            amount = 0
        else:
            action = PokerAction.FOLD
            amount = 0

        # Safety checks
        if action == PokerAction.RAISE:
            # Ensure raise amount is within bounds
            raise_amount = amount - my_bet  # total bet = current bet + raise
            if raise_amount < min_raise:
                # Not enough raise, default to call if affordable
                if to_call <= remaining_chips:
                    action = PokerAction.CALL
                    amount = 0
                else:
                    action = PokerAction.FOLD
            elif raise_amount > remaining_chips:
                # Can't raise that much, go all-in instead
                action = PokerAction.ALL_IN
                amount = 0
        elif action == PokerAction.CALL and to_call > remaining_chips:
            # Cannot afford to call
            action = PokerAction.ALL_IN if remaining_chips > 0 else PokerAction.FOLD
            amount = 0

        return action, amount

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up or update stats if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup
        pass

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """
        Simple hand strength estimation (placeholder logic).
        Returns a value between 0 and 1.
        """
        if not hole_cards:
            return 0.0

        ranks = '23456789TJQKA'
        suits = 'shcd'

        # Extract card info
        hole_ranks = [self.card_rank(card[0:-1]) for card in hole_cards]
        hole_suits = [card[-1].lower() for card in hole_cards]
        community_ranks = [self.card_rank(card[0:-1]) for card in community_cards]
        community_suits = [card[-1].lower() for card in community_cards]

        all_ranks = hole_ranks + community_ranks
        all_suits = hole_suits + community_suits

        # Check for pairs, high cards
        pair = any(all_ranks.count(r) >= 2 for r in set(all_ranks))
        high_pair = any(r >= 11 for r in set(all_ranks) if all_ranks.count(r) >= 2)  # J, Q, K, A pair
        over_pair = len(community_ranks) > 0 and any(h > max(community_ranks) for h in hole_ranks) and pair
        connected = abs(hole_ranks[0] - hole_ranks[1]) <= 1
        suited = hole_suits[0] == hole_suits[1]

        # Estimate strength based on pre-flop type and board
        strength = 0.2  # baseline

        # High cards
        if max(hole_ranks) >= 12:  # K or A
            strength += 0.15
            if hole_ranks[0] == hole_ranks[1]:
                strength = 0.8  # Pocket pair > K
            elif min(hole_ranks) >= 11:
                strength += 0.1  # AK, AQ, AJ, KQ
        elif max(hole_ranks) >= 11:  # Q
            strength += 0.1

        if pair:
            strength += 0.2
        if high_pair:
            strength += 0.2
        if over_pair:
            strength += 0.1
        if connected and suited:
            strength += 0.15
        elif connected or suited:
            strength += 0.05

        # Improve with community cards
        if len(community_cards) >= 3:
            # Check for made hands
            combined_ranks = hole_ranks + community_ranks
            combined_suits = hole_suits + community_suits

            # Count pairs, trips, etc.
            unique, counts = list(set(combined_ranks)), [combined_ranks.count(r) for r in set(combined_ranks)]
            pairs = sum(1 for c in counts if c == 2)
            trips = sum(1 for c in counts if c >= 3)
            quads = sum(1 for c in counts if c >= 4)

            # Check flush
            flush = any(combined_suits.count(s) >= 5 for s in set(combined_suits))

            # Check straight
            sorted_ranks = sorted(set(combined_ranks))
            straight = len(sorted_ranks) >= 5 and any(
                all(r in sorted_ranks for r in range(sorted_ranks[i], sorted_ranks[i] + 5))
                for i in range(len(sorted_ranks) - 4)
            )
            for i in range(len(sorted_ranks) - 4):
                seq = [sorted_ranks[i] + j for j in range(5)]
                if all(r in sorted_ranks for r in seq):
                    straight = True
                    break

            # Check straight flush
            straight_flush = False
            # This is a simplification
            for s in set(combined_suits):
                suited_cards = [r for r, cs in zip(combined_ranks, combined_suits) if cs == s]
                sorted_suited = sorted(set(suited_cards))
                if len(sorted_suited) >= 5:
                    for i in range(len(sorted_suited) - 4):
                        seq = [sorted_suited[i] + j for j in range(5)]
                        if all(r in sorted_suited for r in seq):
                            straight_flush = True
                            break
                    if straight_flush:
                        break

            # Assign strength based on hand
            if straight_flush:
                strength = 1.0
            elif quads:
                strength = 0.95
            elif trips and pairs:  # Full house
                strength = 0.9
            elif flush:
                strength = 0.8
            elif straight:
                strength = 0.7
            elif trips:
                strength = 0.6
            elif pairs >= 2:  # Two pair
                strength = 0.4
            elif pairs == 1:  # One pair
                strength = 0.3

        return min(strength, 1.0)

    def get_scare_factor(self, community_cards: List[str]) -> float:
        """
        Measures how connected or coordinated the board is.
        """
        if not community_cards:
            return 1.0
        ranks = [self.card_rank(card[0:-1]) for card in community_cards]
        suits = [card[-1].lower() for card in community_cards]

        # Check flush potential
        flush_danger = any(suits.count(s) >= 3 for s in set(suits))

        # Check straight potential
        sorted_ranks = sorted(set(ranks))
        connected_danger = False
        for i in range(len(sorted_ranks) - 2):
            gap = sorted_ranks[i+2] - sorted_ranks[i]
            if gap <= 4:  # Can complete straight in 2 cards
                connected_danger = True
                break

        score = 1.0
        if flush_danger:
            score *= 1.5
        if connected_danger:
            score *= 1.5

        return score

    def card_rank(self, rank_char: str) -> int:
        """Convert card rank character to numeric rank (2-14)."""
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        # Convert string like '10' or 'T'
        if rank_char in rank_map:
            return rank_map[rank_char]
        try:
            return int(rank_char)
        except ValueError:
            # Fallback for any unexpected input
            return 2  # worst card