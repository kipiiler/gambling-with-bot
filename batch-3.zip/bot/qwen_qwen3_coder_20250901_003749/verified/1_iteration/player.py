from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.my_position = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.aggression_factor = 1.0  # Adjust based on game state
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called when the game starts. """
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        if self.id == big_blind_player_id:
            self.is_big_blind = True
        else:
            self.is_big_blind = False
            
        if self.id == small_blind_player_id:
            self.is_small_blind = True
        else:
            self.is_small_blind = False
            
        # Determine our position relative to button (simplified)
        self.my_position = all_players.index(self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each round. """
        # Reset hand-specific variables if needed
        pass

    def evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """Evaluate the strength of our hand (simplified version)."""
        # This is a placeholder; in reality, you'd implement a full hand evaluator
        # For now, just return a random strength between 0 and 1, weighted by known cards
        all_cards = hand + community_cards
        if len(all_cards) == 2:  # Pre-flop
            # Basic pre-flop logic
            rank1 = hand[0][0]
            rank2 = hand[1][0]
            suit1 = hand[0][1]
            suit2 = hand[1][1]
            
            # Pocket pairs are strong
            if rank1 == rank2:
                return 0.7 + (['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(rank1) / 52)
            
            # High cards
            high_card_value = 0
            if rank1 in ['T','J','Q','K','A']:
                high_card_value += 0.1
            if rank2 in ['T','J','Q','K','A']:
                high_card_value += 0.1
                
            # Suited connectors
            suited_bonus = 0.1 if suit1 == suit2 else 0
            connector_bonus = 0.05 if abs(['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(rank1) - 
                                          ['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(rank2)) <= 2 else 0
            
            return min(0.9, 0.3 + high_card_value + suited_bonus + connector_bonus)
        elif len(all_cards) >= 5:
            # Post-flop: use a more sophisticated evaluation or lookup table
            # For simplicity, we'll still return a random value but biased towards better hands
            # In reality, this would be replaced with actual hand ranking code
            return random.uniform(0.4, 0.9)
        else:
            # Flop or turn
            return random.uniform(0.3, 0.7)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            current_bet = round_state.current_bet
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            
            # If we don't have chips, fold or check if possible
            if remaining_chips <= 0:
                if call_amount > 0:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CHECK, 0)
            
            # Evaluate our hand strength
            hand_strength = self.evaluate_hand_strength(self.my_hand, round_state.community_cards)
            
            # Preflop strategy
            if round_state.round == "Preflop":
                # Position-based adjustments
                # Early position = tighter, late position = looser
                position_adjustment = self.my_position / 6  # Normalize to 0-1
                
                # Big blind can check if no one has raised yet
                if self.is_big_blind and call_amount == 0:
                    if hand_strength > 0.5:
                        return (PokerAction.RAISE, min(max_raise, int(3 * min_raise)))
                    else:
                        return (PokerAction.CHECK, 0)
                
                # Adjust hand strength based on position
                adjusted_strength = hand_strength + position_adjustment * 0.1
                
                # Very strong hand pre-flop
                if adjusted_strength > 0.8:
                    raise_amount = min(max_raise, int(4 * min_raise))
                    return (PokerAction.RAISE, raise_amount)
                # Strong hand
                elif adjusted_strength > 0.6 and call_amount <= remaining_chips * 0.1:
                    if call_amount == 0:
                        return (PokerAction.RAISE, min(max_raise, int(3 * min_raise)))
                    else:
                        return (PokerAction.CALL, 0)
                # Marginal hand but in position or small call
                elif adjusted_strength > 0.4 and (position_adjustment > 0.5 or call_amount <= remaining_chips * 0.05):
                    if call_amount <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    elif call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Weak hand
                else:
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Post-flop strategy
            else:
                # Strong hand post-flop
                if hand_strength > 0.7:
                    if call_amount == 0:
                        return (PokerAction.RAISE, min(max_raise, int(0.5 * round_state.pot)))
                    elif call_amount <= remaining_chips * 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Medium strength hand
                elif hand_strength > 0.4:
                    if call_amount <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    elif call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Weak hand
                else:
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # If there's any error, default to folding to avoid timeouts
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Update any statistics or adjust strategy based on outcome
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        # Final analysis or logging
        pass