# player.py
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.total_players = 0
        self.my_player_id = None
        self.player_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_player_id = self.id
        self.player_count = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # This method is called at the start of each round
        pass

    def _evaluate_hand_strength(self) -> float:
        """Evaluate hand strength based on hole cards and community cards"""
        if not self.hole_cards:
            return 0.0
            
        # Basic hand evaluation logic
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        ranks = [card[0] for card in self.hole_cards]
        suits = [card[1] for card in self.hole_cards]
        
        # Check for pocket pair
        if ranks[0] == ranks[1]:
            rank_val = rank_values[ranks[0]]
            # Pocket pairs: higher value for higher pairs
            return min(0.9 + (rank_val / 100), 0.95)
        
        # High cards
        high_card_val = max(rank_values[ranks[0]], rank_values[ranks[1]]) / 14.0
        # Connected cards (straight potential)
        connected = abs(rank_values[ranks[0]] - rank_values[ranks[1]]) <= 4
        
        if connected:
            return min(0.4 + high_card_val * 0.3, 0.7)
        else:
            return min(0.3 + high_card_val * 0.2, 0.5)

    def _should_fold_weak_hand(self, round_state: RoundStateClient) -> bool:
        """Determine if we should fold based on hand strength"""
        if round_state.round == 'Preflop':
            strength = self._evaluate_hand_strength()
            # Fold weak hands pre-flop unless we have decent cards
            return strength < 0.3
        return False

    def _calculate_aggression_factor(self, round_state: RoundStateClient) -> float:
        """Calculate how aggressive to be based on position and hand strength"""
        # Base aggression on hand strength
        hand_strength = self._evaluate_hand_strength()
        
        # Increase aggression in later rounds
        round_multiplier = 1.0
        if round_state.round == 'Flop':
            round_multiplier = 1.2
        elif round_state.round == 'Turn':
            round_multiplier = 1.4
        elif round_state.round == 'River':
            round_multiplier = 1.6
            
        return hand_strength * round_multiplier

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update our hole cards if available
            if hasattr(round_state, 'player_hands') and round_state.player_hands and str(self.my_player_id) in round_state.player_hands:
                self.hole_cards = round_state.player_hands[str(self.my_player_id)]
            
            # If we should fold based on hand strength
            if self._should_fold_weak_hand(round_state):
                return (PokerAction.FOLD, 0)
            
            # Get current bet and our bet
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.my_player_id), 0)
            call_amount = current_bet - my_bet
            
            # Calculate aggression factor
            aggression = self._calculate_aggression_factor(round_state)
            
            # If we can check, do so with some probability based on hand strength
            if call_amount == 0:
                if aggression > 0.7 and round_state.min_raise > 0:
                    # Strong hand, raise aggressively
                    raise_amount = min(round_state.min_raise * 3, round_state.max_raise, remaining_chips)
                    if raise_amount > 0:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            
            # If there's a bet to call
            if call_amount > 0:
                # Decide based on hand strength whether to call, raise, or fold
                if aggression > 0.8:
                    # Very strong hand, raise
                    raise_amount = min(round_state.min_raise * 2, round_state.max_raise, remaining_chips)
                    if raise_amount > 0 and raise_amount <= round_state.max_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif aggression > 0.5:
                    # Decent hand, call
                    return (PokerAction.CALL, 0)
                else:
                    # Weak hand, fold
                    return (PokerAction.FOLD, 0)
            
            # Default action
            return (PokerAction.CHECK, 0)
            
        except Exception as e:
            # If any error occurs, fold to be safe
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # This method is called at the end of each round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # This method is called at the end of the game
        pass