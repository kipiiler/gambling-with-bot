from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_remaining_chips = 10000
        self.game_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_remaining_chips = starting_chips
        if self.id is not None and str(self.id) in player_hands:
            self.hole_cards = player_hands[str(self.id)]
        else:
            # Fallback in case id is not set yet
            for player_id, cards in player_hands.items():
                if int(player_id) == self.id:
                    self.hole_cards = cards
                    break

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        self.my_remaining_chips = remaining_chips
        
        # Get our current bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_current_bet
        
        # Basic strategy based on hand strength and round
        hand_strength = self.evaluate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Calculate pot odds
        pot_odds = amount_to_call / (round_state.pot + amount_to_call) if (round_state.pot + amount_to_call) > 0 else 0
        
        # Preflop strategy
        if round_state.round == 'Preflop':
            return self.preflop_strategy(hand_strength, amount_to_call, round_state)
        else:
            # Postflop strategy
            return self.postflop_strategy(hand_strength, amount_to_call, round_state, pot_odds)

    def preflop_strategy(self, hand_strength, amount_to_call, round_state):
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # All-in for very strong hands
        if hand_strength > 0.8:
            if amount_to_call > 0:
                return (PokerAction.RAISE, min(round_state.max_raise, int(self.my_remaining_chips * 0.8)))
            else:
                return (PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, int(self.my_remaining_chips * 0.4))))
        
        # Raise with decent hands
        elif hand_strength > 0.6:
            if amount_to_call > 0:
                if amount_to_call <= self.my_remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.RAISH, min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * 0.5))))
        
        # Call/check with marginal hands
        elif hand_strength > 0.4:
            if amount_to_call <= self.my_remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Fold weak hands
        else:
            if amount_to_call == 0:
                return (PokerAction.CHECK, 0)
            elif amount_to_call <= self.my_remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def postflop_strategy(self, hand_strength, amount_to_call, round_state, pot_odds):
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        
        # All-in for very strong hands
        if hand_strength > 0.85:
            if amount_to_call > 0:
                return (PokerAction.RAISE, min(round_state.max_raise, int(self.my_remaining_chips * 0.7)))
            else:
                return (PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * 0.7))))
        
        # Raise with strong hands
        elif hand_strength > 0.65:
            if amount_to_call > 0:
                if pot_odds < hand_strength:  # Good pot odds
                    if amount_to_call <= self.my_remaining_chips * 0.3:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * 0.5))))
        
        # Call with decent hands
        elif hand_strength > 0.4:
            if amount_to_call <= self.my_remaining_chips * 0.2:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Bluff occasionally
        elif hand_strength > 0.25 and round_state.round in ['Turn', 'River']:
            if amount_to_call == 0 and len(round_state.community_cards) >= 3:
                bluff_chance = 0.1
                if hash(str(self.hole_cards) + str(round_state.community_cards)) % 100 < bluff_chance * 100:
                    return (PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, int(round_state.pot * 0.3))))
        
        # Fold weak hands
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        elif amount_to_call <= self.my_remaining_chips * 0.05:
            return (PokerAction.CALL, 0)
        else:
            return (PokerAction.FOLD, 0)

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simple hand strength evaluation"""
        if len(hole_cards) < 2:
            return 0.0
            
        # Combine all cards
        all_cards = hole_cards + community_cards
        
        # Basic ranking logic
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        ranks = [card[0] for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        # Count rank frequencies
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        # Count suit frequencies
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush potential
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        flush_potential = max_suit_count >= 4  # 4+ cards of same suit
        
        # Check for straight potential
        numeric_ranks = sorted([rank_values[rank] for rank in ranks])
        unique_ranks = sorted(list(set(numeric_ranks)))
        straight_potential = len(unique_ranks) >= 4  # At least 4 unique ranks
        
        # Calculate base strength from hole cards
        hole_rank1 = rank_values.get(hole_cards[0][0], 0)
        hole_rank2 = rank_values.get(hole_cards[1][0], 0)
        hole_same_suit = hole_cards[0][1] == hole_cards[1][1]
        
        # Base strength (0.0 to 1.0)
        base_strength = (hole_rank1 + hole_rank2) / 28.0  # Normalize by max possible (14+14)
        
        # Pair bonus
        pair_bonus = 0.0
        for count in rank_counts.values():
            if count == 2:
                pair_bonus = 0.1
            elif count == 3:
                pair_bonus = 0.2
            elif count >= 4:
                pair_bonus = 0.3
                
        # Flush and straight potential bonuses
        potential_bonus = 0.0
        if flush_potential:
            potential_bonus += 0.1
        if straight_potential:
            potential_bonus += 0.1
        if hole_same_suit:
            potential_bonus += 0.05
            
        # High card bonus for A, K, Q, J
        high_card_bonus = 0.0
        for rank in [hole_cards[0][0], hole_cards[1][0]]:
            if rank in ['A', 'K', 'Q', 'J']:
                high_card_bonus += 0.05
                
        # Position bonus (later in the game, be more aggressive)
        position_bonus = len(community_cards) * 0.05
        
        total_strength = min(1.0, base_strength + pair_bonus + potential_bonus + high_card_bonus + position_bonus)
        return max(0.0, total_strength)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_remaining_chips = remaining_chips
        # Store round result for analysis if needed
        self.game_history.append({
            'round_num': round_state.round_num,
            'pot': round_state.pot,
            'community_cards': round_state.community_cards,
            'my_cards': self.hole_cards
        })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hole_cards = []
        self.game_history = []