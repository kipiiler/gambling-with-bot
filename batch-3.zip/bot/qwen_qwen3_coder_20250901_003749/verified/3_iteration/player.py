from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 10000
        self.my_chips = 10000
        self.big_blind = 0
        self.small_blind = 0
        self.all_players = []
        self.player_id = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_chips = starting_chips
        self.big_blind = big_blind_player_id
        self.small_blind = small_blind_player_id
        self.all_players = all_players
        self.player_id = self.id
        
        # player_hands is a list of strings like ['Ah', 'Ks']
        self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """A simple heuristic-based hand strength evaluator"""
        # In a real implementation, this would be much more sophisticated
        # For now, we'll use a simplified approach
        
        # Combine hole cards with community cards
        all_cards = hole_cards + community_cards
        
        # Convert to a simple representation
        ranks = []
        suits = []
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        for card in all_cards:
            if len(card) != 2:
                continue
            rank_char = card[0]
            suit_char = card[1]
            
            if rank_char in rank_map:
                ranks.append(rank_map[rank_char])
            else:
                ranks.append(0)
                
            suits.append(suit_char)
        
        # Simple heuristics
        strength = 0.0
        
        # Pair detection
        rank_counts = {}
        for rank in ranks:
            if rank in rank_counts:
                rank_counts[rank] += 1
            else:
                rank_counts[rank] = 1
        
        # Add value for pairs, three of a kind, etc.
        for count in rank_counts.values():
            if count == 2:
                strength += 0.2
            elif count == 3:
                strength += 0.5
            elif count == 4:
                strength += 0.9
                
        # High card value
        high_card = max(ranks) if ranks else 0
        strength += high_card / 20.0
        
        # Flush potential
        suit_counts = {}
        for suit in suits:
            if suit in suit_counts:
                suit_counts[suit] += 1
            else:
                suit_counts[suit] = 1
                
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        if max_suit_count >= 4:
            strength += 0.3
        elif max_suit_count == 3 and len(community_cards) <= 3:
            strength += 0.1
            
        # Straight potential
        unique_ranks = sorted(list(set(ranks)))
        consecutive = 0
        max_consecutive = 0
        
        for i in range(len(unique_ranks)-1):
            if unique_ranks[i+1] == unique_ranks[i] + 1:
                consecutive += 1
                max_consecutive = max(max_consecutive, consecutive)
            else:
                consecutive = 0
                
        if max_consecutive >= 4:
            strength += 0.4
        elif max_consecutive >= 3 and len(community_cards) <= 3:
            strength += 0.2
            
        # Normalize
        return min(strength, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update our chip count
            self.my_chips = remaining_chips
            
            # Get information about the current state
            community_cards = round_state.community_cards
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            
            # Calculate call amount
            call_amount = current_bet - my_current_bet
            
            # Evaluate hand strength
            hand_strength = self.evaluate_hand_strength(self.hole_cards, community_cards)
            
            # Position awareness
            is_preflop = len(community_cards) == 0
            
            # Adjust strategy based on position and hand strength
            if is_preflop:
                # Preflop strategy
                # Simplified: Play premium hands more aggressively
                high_cards = [card[0] for card in self.hole_cards]
                same_suit = self.hole_cards[0][1] == self.hole_cards[1][1]
                high_pair = high_cards[0] == high_cards[1] and high_cards[0] in ['A', 'K', 'Q', 'J']
                connectors = abs(ord(high_cards[0]) - ord(high_cards[1])) <= 2 if high_cards[0].isalpha() and high_cards[1].isalpha() else False
                
                # Decision making based on hand quality
                if high_pair or (high_cards[0] in ['A', 'K'] and high_cards[1] in ['A', 'K', 'Q']):
                    # Very strong hands
                    if call_amount == 0:
                        # We can check or bet
                        raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.1)))
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips * 0.05:
                        # Reasonable call
                        if random.random() < 0.8:
                            raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.15)))
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CALL, 0)
                    else:
                        # Large bet - still call with premium hands
                        if call_amount <= remaining_chips * 0.2:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                elif ('A' in high_cards) or same_suit or connectors:
                    # Decent hands
                    if call_amount == 0:
                        # We can check or bet
                        raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.05)))
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips * 0.03:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hands
                    if call_amount == 0:
                        # Check if possible
                        return (PokerAction.CHECK, 0)
                    elif call_amount <= remaining_chips * 0.01:
                        # Very small call
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Postflop strategy
                # Use hand strength evaluation
                if hand_strength > 0.8:
                    # Very strong hand
                    if call_amount == 0:
                        raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.15)))
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips * 0.1:
                        raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.2)))
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > 0.5:
                    # Moderate hand
                    if call_amount == 0:
                        raise_amount = min(max_raise, max(min_raise, int(remaining_chips * 0.07)))
                        return (PokerAction.RAISE, raise_amount)
                    elif call_amount <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                elif hand_strength > 0.3:
                    # Weak but playable hand
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    elif call_amount <= remaining_chips * 0.02:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Poor hand
                    if call_amount == 0:
                        return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # Fallback action in case of any errors
            try:
                call_amount = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount <= remaining_chips * 0.02:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_chips = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass