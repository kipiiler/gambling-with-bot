from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hands = []
        self.my_position = 0
        self.total_players = 0
        self.remaining_chips = 0
        self.current_round = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_hands = player_hands
        self.total_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.remaining_chips = remaining_chips
        self.current_round = round_state.round

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Get current bet and min raise
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Calculate our current bet in this round
        our_bet = 0
        if str(self.id) in round_state.player_bets:
            our_bet = round_state.player_bets[str(self.id)]
        
        # Calculate how much more we need to call
        call_amount = current_bet - our_bet
        
        # Calculate valid raise amount (must be at least min_raise more than current bet)
        raise_amount = current_bet + min_raise
        
        # Make sure we don't exceed our max raise
        if raise_amount > max_raise:
            raise_amount = max_raise
            
        # Ensure raise amount is valid
        if raise_amount <= current_bet and current_bet > 0:
            # If we can't raise, check if we can call
            if call_amount <= 0:
                return (PokerAction.CHECK, 0)
            elif call_amount >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CALL, 0)
        
        # If there's no current bet, we can check
        if current_bet == 0:
            return (PokerAction.CHECK, 0)
        
        # If there's a bet, decide whether to call, raise, or fold
        # Simple strategy based on remaining chips and current bet
        if call_amount <= remaining_chips * 0.1:
            # If the call is small relative to our stack, call
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount >= remaining_chips:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.CALL, 0)
        elif call_amount <= remaining_chips * 0.3:
            # If the call is moderate, sometimes raise
            if random.random() < 0.3:
                # Make sure raise amount is valid
                if raise_amount > remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, raise_amount)
            else:
                if call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
        else:
            # Expensive call, mostly fold unless we have a strong hand
            if random.random() < 0.2:  # 20% chance to call even expensive bets
                if call_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Default action if we get here
        if current_bet == 0:
            return (PokerAction.CHECK, 0)
        else:
            return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass