from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hand: List[str] = []
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int = -1
        self.small_blind_player_id: int = -1
        self.all_players: List[int] = []
        self.my_id: int = -1 # Store our own ID
        self.hand_strength_preflop_rank: dict = {}
        self._initialize_hand_strength_preflop_rank()

    def _initialize_hand_strength_preflop_rank(self):
        # A simplified mapping for pre-flop hand strength (adjust as needed)
        # Higher values for stronger hands
        self.hand_strength_preflop_rank = {
            # Premium pairs
            "AA": 100, "KK": 98, "QQ": 96, "JJ": 94, "TT": 92,
            # Broadways suited
            "AKs": 90, "AQs": 88, "AJs": 86, "ATs": 84, "KQs": 82, "KJs": 80, "QTs": 78,
            # High pairs
            "99": 76, "88": 74, "77": 72,
            # Broadways offsuit
            "AKo": 70, "AQo": 68, "AJo": 66, "KQo": 64, "KJo": 62, "QJo": 60,
            # Suited connectors
            "JTs": 58, "T9s": 56, "98s": 54, "87s": 52, "76s": 50, "65s": 48,
            # Small/medium pairs
            "66": 46, "55": 44, "44": 42, "33": 40, "22": 38,
            # Other decent suited/offsuit hands (adjust as desired)
            "A9s": 35, "A8s": 34, "A7s": 33, "A6s": 32, "A5s": 31, "A4s": 30, "A3s": 29, "A2s": 28,
            "K9s": 27, "Q9s": 26, "J9s": 25, "T8s": 24, "97s": 23, "86s": 22, "75s": 21, "64s": 20,
            "KTo": 18, "QTo": 17, "JTo": 16,
            "A9o": 15, "A8o": 14, "A7o": 13, "A6o": 12, "A5o": 11, "A4o": 10, "A3o": 9, "A2o": 8,
            # Trash hands (will have low or default value)
        }

    def _get_hand_rank_key(self, cards: List[str]) -> str:
        if not cards or len(cards) != 2:
            return ""
        
        c1_rank = cards[0][0]
        c1_suit = cards[0][1]
        c2_rank = cards[1][0]
        c2_suit = cards[1][1]

        # Convert 10 to T for ranking
        c1_rank = 'T' if c1_rank == '1' else c1_rank
        c2_rank = 'T' if c2_rank == '1' else c2_rank

        rank_order = "23456789TJQKA"
        
        # Ensure higher ranked card comes first
        if rank_order.index(c1_rank) < rank_order.index(c2_rank):
            c1_rank, c2_rank = c2_rank, c1_rank

        if c1_suit == c2_suit:
            return f"{c1_rank}{c2_rank}s"
        elif c1_rank == c2_rank: # A pair
            return f"{c1_rank}{c2_rank}"
        else: # Offsuit
            return f"{c1_rank}{c2_rank}o"

    def _get_preflop_strength(self) -> int:
        hand_key = self._get_hand_rank_key(self.player_hand)
        return self.hand_strength_preflop_rank.get(hand_key, 5) # Default low strength for unranked hands

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hand = player_hands # This is only populated at the start for illustration, individual round hands passed via on_round_start
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.my_id = self.id # Store our assigned ID

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update player_hand based on the round_state. It is implicitly passed to the player via private state.
        # The player's hand is not part of RoundStateClient for security/privacy.
        # We assume the framework passes the hand information to the bot internally,
        # or it is reset/updated elsewhere. For this template, we acknowledge it's not in RoundStateClient.
        # We will assume `player_hands` from `on_start` is the initial dealt hand for the first round,
        # and subsequent hands are handled by the framework without explicit `player_hands` in `round_state`.
        # However, for a real bot, the hand would need to be passed in a method like on_round_start if not already
        # persisted. Given the error feedback, the `player_hands` attribute does not exist on RoundStateClient.
        # This implies `self.player_hand` needs to be updated directly from the game's internal state.
        # Since the template doesn't provide a way to get the hand in on_round_start explicitly,
        # we'll rely on it being set via a different internal mechanism or passed to `get_action`
        # if the framework permits. For submission, we must adhere to the provided signatures.
        pass # No action needed here based on the error.

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        my_current_bet_in_round = round_state.player_bets.get(str(self.my_id), 0)
        
        # Calculate amount to call
        amount_to_call = current_bet - my_current_bet_in_round

        # Basic Pre-flop Strategy
        if round_state.round == PokerRound.PREFLOP.name:
            preflop_strength = self._get_preflop_strength()
            
            # Number of active players is approximated by checking how many players still have chips
            # and who haven't folded yet in the current betting round (e.g., in player_bets with > 0 bet).
            # A more robust way might be to track active players.
            active_players_count = len([p_id for p_id, bet in round_state.player_bets.items() if bet > 0 or p_id == str(self.my_id)]) # Simplified active count

            # Adjust strategy based on position and active players
            # Small blind / Big blind position logic based on player IDs
            is_dealer_or_early = self.my_id != self.big_blind_player_id and self.my_id != self.small_blind_player_id
            is_big_blind = self.my_id == self.big_blind_player_id
            is_small_blind = self.my_id == self.small_blind_player_id

            # Aggressive play for strong hands
            if preflop_strength >= 90: # AA, KK, AKs
                if current_bet == 0: # No one has bet yet (we are first to act or big blind)
                    raise_amount = max(self.blind_amount * 3, round_state.min_raise)
                    return PokerAction.RAISE, raise_amount
                elif amount_to_call > 0 and amount_to_call < remaining_chips / 2: # Someone raised, it's not an all-in
                    raise_amount = max(current_bet * 2, round_state.min_raise)
                    if raise_amount + my_current_bet_in_round >= remaining_chips: # If raise is effectively an all-in
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount
                elif amount_to_call > 0 and amount_to_call >= remaining_chips / 2: # Facing a large bet
                    return PokerAction.ALL_IN, 0 # Go all-in with premium hands
            
            # Medium hands, play cautiously or call/small raise
            elif preflop_strength >= 70: # QQ, JJ, AKo, AQs, etc.
                if current_bet == 0: # No one bet (limp or small raise)
                    if is_dealer_or_early:
                        return PokerAction.CALL, 0 # Limp
                    else: # Blind position
                        raise_amount = max(self.blind_amount * 2, round_state.min_raise)
                        return PokerAction.RAISE, raise_amount
                elif amount_to_call <= self.blind_amount * 2 and amount_to_call < remaining_chips: # Call small raises
                    return PokerAction.CALL, 0
                elif amount_to_call >= remaining_chips: # Facing all-in, or very large bet
                    return PokerAction.FOLD, 0 # Fold unless very strong
                else:
                    return PokerAction.FOLD, 0 # Fold to significant raises

            # Weak hands, fold unless cheap call from big blind or isolated
            else:
                if current_bet == 0: # Open limp with weak hands
                    if is_dealer_or_early:
                        return PokerAction.FOLD, 0
                    else: # Blind check or call
                        return PokerAction.CHECK, 0 if round_state.current_bet == 0 else PokerAction.CALL, 0
                elif is_big_blind and amount_to_call == 0: # Big blind can check if no raise
                    return PokerAction.CHECK, 0
                elif amount_to_call <= self.blind_amount and amount_to_call < remaining_chips/10: # Call small amount if cheap
                     return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop Strategy (Flop, Turn, River) - More advanced logic would involve hand evaluators
        # and equity calculations against ranges. For now, a simplified strategy.

        # If we need to call
        if amount_to_call > 0:
            if amount_to_call >= remaining_chips: # Means forced all-in
                return PokerAction.ALL_IN, 0
            
            # In later streets, if facing a bet, evaluate pot odds vs. estimated hand strength
            # For simplicity, if pot is large and bet is small, call. Otherwise fold.
            if round_state.pot > 0:
                pot_odds = amount_to_call / (round_state.pot + amount_to_call + 0.0001) # Add small delta for div by zero
                # If pot odds are very good (e.g., less than 25% of pot) or small bet:
                if pot_odds < 0.25 and amount_to_call < remaining_chips / 4: # Relatively small bet
                    return PokerAction.CALL, 0
                elif amount_to_call >= remaining_chips / 2: # Large bet or all-in facing
                    # For now, fold to large bets post-flop unless specified otherwise by stronger logic
                    return PokerAction.FOLD, 0
                else: # Default if unsure, fold.
                    return PokerAction.FOLD, 0
            else: # Pot is 0, someone opened. If not too large, call.
                if amount_to_call < remaining_chips / 3:
                     return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        else: # No bet to call, action is Check or Bet/Raise
            # If current_bet is 0, we can check.
            if current_bet == 0:
                return PokerAction.CHECK, 0
            else: # If current_bet > 0, it means someone else bet, but our my_current_bet_in_round matches it (we already called)
                # This should not happen: if my_current_bet_in_round matches current_bet, amount_to_call would be 0, allowing CHECK.
                # If it's zero and we are here, it means we ARE the current bettor potentially.
                # Re-evaluate
                # If we are here, it means `amount_to_call` was 0.
                # And `current_bet` implies it's not 0 IF someone else made a bet.
                # This implies either we are the last player to act, or current_bet is 0.
                # If current_bet is not 0, and amount_to_call is 0, it means we already matched current_bet.
                # In such case, we must check if our turn for an action or it is closing action.
                # This means it's our turn to CHECK, unless it's a raise.
                return PokerAction.CHECK, 0

        # Fallback to an action (should not be reached if logic covers all cases)
        return PokerAction.FOLD, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset player_hand or prepare for next round
        self.player_hand = [] # Hand is reset after each round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass