from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from enum import Enum

class PokerRound(Enum):
    PREFLOP = 0
    FLOP = 1
    TURN = 2
    RIVER = 3

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.my_id = None
        self.starting_chips = 0
        self.blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.my_id = next(iter(all_players)) # Assuming my_id will be one of the player IDs

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = round_state.player_hands[str(self.my_id)] if hasattr(round_state, 'player_hands') and str(self.my_id) in round_state.player_hands else []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_call = round_state.current_bet - round_state.player_bets.get(str(self.my_id), 0)
        
        # Simple hand strength evaluation (Pre-flop)
        hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

        # Basic strategy based on hand strength and round
        # Pre-flop
        if round_state.round == PokerRound.PREFLOP.name:
            if hand_strength >= 3:  # Strong hands (e.g., AA, KK, QQ, AKs, AKo, JJ)
                if remaining_chips > round_state.max_raise * 0.5 and remaining_chips > self.blind_amount * 4: # Aggressive raise
                    bet_amount = min(remaining_chips, max(round_state.min_raise, current_bet_to_call + self.blind_amount * 3))
                    return PokerAction.RAISE, bet_amount
                elif current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, current_bet_to_call
            elif hand_strength == 2:  # Medium hands (e.g., TT, 99, 88, AQ, AJ)
                if current_bet_to_call < self.blind_amount * 2: # Call small bets, raise cautiously
                    if remaining_chips > round_state.min_raise and remaining_chips > self.blind_amount * 2:
                        bet_amount = min(remaining_chips, max(round_state.min_raise, current_bet_to_call + self.blind_amount * 2))
                        return PokerAction.RAISE, bet_amount
                    elif current_bet_to_call == 0:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.CALL, current_bet_to_call
                elif current_bet_to_call >= self.blind_amount * 2.5: # Consider folding on larger bets
                    return PokerAction.FOLD, 0
                else: # Call medium bets
                    return PokerAction.CALL, current_bet_to_call
            else:  # Weak hands
                if current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                elif current_bet_to_call <= self.blind_amount: # Call only if minimal cost
                    return PokerAction.CALL, current_bet_to_call
                else:
                    return PokerAction.FOLD, 0
        
        # Post-flop (Flop, Turn, River)
        else:
            # Re-evaluate hand strength with community cards
            combined_cards = self.hole_cards + round_state.community_cards
            post_flop_hand_strength = self._evaluate_hand_strength(self.hole_cards, round_state.community_cards)

            if post_flop_hand_strength >= 3: # Strong hands (e.g., two pair, trips, straight, flush, full house)
                if remaining_chips > 0 and round_state.max_raise > 0: # Aggressive betting
                    bet_amount = min(remaining_chips, max(round_state.min_raise, int(remaining_chips * 0.75)))
                    if current_bet_to_call > 0 and bet_amount < current_bet_to_call: # Ensure raise is at least current_bet
                        bet_amount = max(bet_amount, current_bet_to_call + self.blind_amount)
                    
                    # Ensure bet_amount is valid
                    bet_amount = max(bet_amount, round_state.min_raise)
                    bet_amount = min(bet_amount, round_state.max_raise)
                    
                    if remaining_chips >= current_bet_to_call + bet_amount:
                        return PokerAction.RAISE, bet_amount
                    elif remaining_chips >= current_bet_to_call:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
                elif current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.CALL, current_bet_to_call
            elif post_flop_hand_strength == 2: # Medium hands (e.g., top pair, good kicker, strong draws)
                if current_bet_to_call * 2 < self.blind_amount * 5 and remaining_chips > current_bet_to_call: # Call medium bets, small raises if no bet
                    if current_bet_to_call == 0:
                        bet_amount = min(remaining_chips, self.blind_amount * 2)
                        return PokerAction.RAISE, bet_amount
                    else:
                        if remaining_chips >= current_bet_to_call:
                            return PokerAction.CALL, current_bet_to_call
                        else:
                            return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0 # Too expensive
            else: # Weak hands
                if current_bet_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Default fallback (should not be reached often)
        if current_bet_to_call == 0:
            return PokerAction.CHECK, 0
        elif remaining_chips >= current_bet_to_call:
            return PokerAction.CALL, current_bet_to_call
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """
        Evaluates the strength of a poker hand from 0 (very weak) to 4 (very strong).
        This is a simplified evaluation.
        0: Very weak (e.g., 7-2 offsuit)
        1: Weak (e.g., unsuited low cards, small pairs below 7s)
        2: Medium (e.g., suited connectors, medium pairs 7s-Js, A-x suited)
        3: Strong (e.g., high pairs TT-KK, AK, AQ suited)
        4: Very Strong (e.g., AA, KK, QQ, AKs)

        Post-flop:
        0: High card, no pair
        1: One pair (low kicker or small pair)
        2: One pair (good kicker or medium pair), strong draw (flush/straight draw with high cards)
        3: Two pair, Three of a kind, nut flush/straight draw
        4: Straight, Flush, Full House, Four of a kind, Straight Flush, Royal Flush
        """
        if not hole_cards:
            return 0

        # Helper to get rank and suit
        def get_rank_suit(card):
            if len(card) == 2:
                return card[0], card[1]
            else: # Ten is 'T'
                return card[0], card[1] # Should be 'T', 'd' for example. Or this needs to be '10', 'd' for real. Assuming T is 10
        
        def card_rank_to_int(rank):
            if rank.isdigit():
                return int(rank)
            elif rank == 'T':
                return 10
            elif rank == 'J':
                return 11
            elif rank == 'Q':
                return 12
            elif rank == 'K':
                return 13
            elif rank == 'A':
                return 14
            return 0 # Should not happen

        # Combine cards for evaluation
        player_cards = hole_cards + community_cards
        
        # Extract ranks and suits
        ranks = sorted([card_rank_to_int(get_rank_suit(card)[0]) for card in player_cards], reverse=True)
        suits = [get_rank_suit(card)[1] for card in player_cards]

        # Count frequencies
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1

        num_community_cards = len(community_cards)

        # --- Evaluate Post-flop hands (more complex evaluation, up to 7 cards) ---
        if num_community_cards > 0:
            # Check for Four of a Kind
            if 4 in rank_counts.values():
                return 4
            
            # Check for Full House
            has_three_of_a_kind = False
            has_pair = False
            for count in rank_counts.values():
                if count >= 3:
                    has_three_of_a_kind = True
                if count >= 2:
                    has_pair = True
            if has_three_of_a_kind and len([c for c in rank_counts.values() if c >= 2]) >= 2 : # at least one 3-of-a-kind and another pair
                 return 4

            # Check for Flush
            for suit, count in suit_counts.items():
                if count >= 5:
                    return 4 # Strong flush

            # Check for Straight
            # Create a set of unique ranks for straight checking
            unique_ranks = sorted(list(set(ranks)))
            if len(unique_ranks) >= 5:
                for i in range(len(unique_ranks) - 4):
                    # Check for sequential ranks
                    is_straight = True
                    for j in range(4):
                        if unique_ranks[i+j] + 1 != unique_ranks[i+j+1]:
                            is_straight = False
                            break
                    if is_straight:
                        return 4 # Strong straight
            # Special case for A-5 straight (A,2,3,4,5)
            if all(r in unique_ranks for r in [14, 2, 3, 4, 5]): # Ace needs to be treated as 1
                return 4


            # Check for Three of a Kind
            if 3 in rank_counts.values():
                return 3
            
            # Check for Two Pair or One Pair
            pairs = [rank for rank, count in rank_counts.items() if count >= 2]
            if len(pairs) >= 2:
                return 3 # Two pair
            elif len(pairs) == 1:
                # Assess one pair strength based on rank and kicker
                pair_rank = pairs[0]
                if pair_rank >= 10: # Tens or better pair (J, Q, K, A)
                    return 2.5 # Medium to strong
                else:
                    return 1.5 # Weak to medium
            
            # High card evaluation
            if ranks:
                high_card_rank = ranks[0]
                if high_card_rank >= 14: # Ace high
                    return 1
                elif high_card_rank >= 10: # T, J, Q, K high
                    return 0.5
            return 0 # No significant hand

        # --- Evaluate Pre-flop hands (2 hole cards) ---
        else:
            rank1, rank2 = card_rank_to_int(get_rank_suit(hole_cards[0])[0]), card_rank_to_int(get_rank_suit(hole_cards[1])[0])
            suit1, suit2 = get_rank_suit(hole_cards[0])[1], get_rank_suit(hole_cards[1])[1]
            
            is_suited = (suit1 == suit2)
            is_paired = (rank1 == rank2)
            
            # Paired hands
            if is_paired:
                if rank1 >= 13: # AA, KK
                    return 4
                elif rank1 >= 11: # QQ, JJ
                    return 3
                elif rank1 >= 7: # TT, 99, 88, 77
                    return 2
                else: # 66, 55, 44, 33, 22
                    return 1
            
            # Suited connectors/gappers
            if is_suited:
                if max(rank1, rank2) >= 12 and min(rank1, rank2) >= 10: # AKs, AQs
                    return 3
                elif max(rank1, rank2) >= 10 and abs(rank1 - rank2) <= 2: # Suited Broadway (KQ, KJ, JT, QJ, QT), high suited connectors
                    return 2.5
                elif max(rank1, rank2) >= 7 and abs(rank1 - rank2) <= 3: # Suited connectors/gappers
                    return 2
                elif max(rank1, rank2) >= 12 and min(rank1, rank2) <= 9: # Suited Ace with low kicker
                    return 1.5
                else: # Other suited cards
                    return 0.8
            
            # Offsuit Broadway/High cards
            if max(rank1, rank2) >= 12 and min(rank1, rank2) >= 10: # AKo, AQo, KJo, QJo
                return 2.5
            elif max(rank1, rank2) >= 10 and min(rank1, rank2) >= 7: # ATo, KTo
                return 2
            elif max(rank1, rank2) >= 10: # Any other T+ high card
                return 1.5
            
            # Other hands
            if max(rank1, rank2) >= 7 and abs(rank1 - rank2) <= 3: # Medium connectors/gappers
                return 0.5

            return 0 # Very weak hand