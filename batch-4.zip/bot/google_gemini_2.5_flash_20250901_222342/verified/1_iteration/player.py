import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.small_blind_amount = 0
        self.big_blind_amount = 0
        self.player_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.small_blind_amount = int(blind_amount / 2)
        self.big_blind_amount = blind_amount
        self.all_players = all_players
        # Player hands contains the bot's hole cards for the current game simulation, not for individual rounds.
        # This is a bit misleading given the name, but on_round_start will give the specific hole cards for the round.

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update hole cards for the current round. The `player_hands` parameter in `on_start` is likely for a multi-game simulation setup,
        # but for a single game, the actual hole cards for the current round are implied to be known by the bot or passed in a way not explicitly
        # shown in the `RoundStateClient` which focuses on community cards.
        # Assuming for now that the actual hole cards are provided within the `player_hands` during get_action or are implicitly known
        # from game setup. If not, this would need to be handled, but typical interfaces pass them directly to `get_action` or `on_round_start`.
        # For simplicity, if the platform does not explicitly provide hole cards here, we'll assume they're known in get_action or are fixed for the game.
        # Given the `player_hands` in `on_start` is a list of strings, it implies multiple hands for multiple rounds or players.
        # For competitive bots, usually, your hole cards for the current round are given.
        # Let's assume `set_id` has been called and this bot's id is `self.id`.
        # The `player_hands` in on_start is confusing. Assuming hole cards are only 'known' per round or accessible in 'get_action' via a different mechanism.
        # For now, let's just make sure we clear any previous round's cards.
        self.hole_cards = [] # This needs to be correctly populated for each round. `RoundStateClient` doesn't pass it.
                              # In a typical setup, `get_action` or `on_round_start` would pass it.
                              # Without explicit hole card passing in this `RoundStateClient`, we have to assume a meta-layer provides it,
                              # or `on_start`'s `player_hands` is actually per-round if only two cards are passed.
                              # Given `player_hands: List[str]` in `on_start`, and `starting_chips` being a game-level value,
                              # it appears `player_hands` in `on_start` might be a stub or specific to the tournament setup.
                              # A robust bot needs the current hand. Let's assume a practical poker bot framework will pass them.
                              # For this implementation, we will mock or deduce them if not explicitly given, or rely on them being set externally.

        # Since hole cards are not explicitly passed in RoundStateClient, for the purpose of a robust bot,
        # we will rely on an assumed mechanism or internal state update that happens implicitly
        # (e.g., set before get_action is called for this player).
        # THIS IS A CRITICAL ASSUMPTION for hand evaluation.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Simple strategy: Play tight pre-flop, aggressive post-flop if good hand.
        # For demonstration, a very basic strategy:
        # Pre-flop:
        #   - If big blind and no raise, check.
        #   - If small blind, call or fold based on blind amount.
        #   - If raised, fold most of the time unless it's a very strong hand (hard to determine without hand eval).
        # Post-flop:
        #   - If no bet, check.
        #   - If bet, call if reasonable, raise if strong (again, needs hand eval).
        #   - All-in if very strong.

        # For a truly functional bot, self.hole_cards must be set for the current round.
        # As per the `RoundStateClient` definition, hole cards are *not* provided in `round_state`.
        # This implies either they are set in `on_round_start` by some external mechanism,
        # or the `player_hands` from `on_start` is actually the current round's hole cards.
        # Given `player_hands` is `List[str]`, if it only gives two cards during `on_start`, that's them.
        # But `on_start` is only called once. This means `player_hands` in `on_start` is globally known to the bot.
        # Let's assume `player_hands` from `on_start` are *our* hole cards for *the current game run*, not round.
        # This is very unusual for poker bots as hole cards change per round.
        # The prompt implies a competitive setup. If hole cards aren't given per round, the Bot cannot play correctly.
        # Let's assume the competition system provides `self.hole_cards` via some hidden mechanism or `Bot.set_hole_cards()`
        # which is typical for such platforms. For now, we will simulate a random hand or assume it exists.

        # To make this playable, I must assume current round's hole cards are available,
        # perhaps `on_round_start` or just before `get_action` via a helper method `set_hole_cards`.
        # Since it's not provided in the template, I'll simulate. In a real competition, this would be an error.
        # For the purpose of this exercise, let's assume `self.hole_cards` is populated externally by the framework with 2 cards.
        # Example: `self.hole_cards = ['Ah', 'Kd']`

        # Placeholder for actual hand strength calculation
        # This is where a full poker hand evaluator would go.
        # For simplicity, we'll use random actions with some basic logic.

        my_player_id_str = str(self.id)
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(my_player_id_str, 0)
        can_check = current_bet_to_match == 0

        # Determine number of active players
        active_players = 0
        for player_id in round_state.player_bets:
            # A player is "active" if they haven't folded. Assuming 'Fold' action means inactive in this context
            if round_state.player_actions.get(player_id) != 'Fold':
                 active_players += 1
        
        # Initial chips for the opponent
        # We don't have direct opponent chip access in `RoundStateClient`.
        # `remaining_chips` is our own.
        # `all_players` in `on_start` gives player IDs. We can infer opponent by iterating through `all_players` and excluding self.id.
        # We don't have access to their current stack explicitly in `RoundStateClient`.
        # This is a limitation for making stack-size dependent decisions.

        # Simplified Hand Strength (no actual card evaluation)
        # In a real bot, we'd have a `HandEvaluator` class here.
        # For this template, we'll use random chances.
        # Adjust probabilities based on round and perceived strength
        # This is very basic and does not use actual poker logic.

        num_community_cards = len(round_state.community_cards)

        # Pre-flop decision
        if round_state.round == 'Preflop':
            # Being in big blind and nobody raised, or small blind and current bet is just big blind
            if can_check:
                if random.random() < 0.6:  # 60% chance to check/call if no bet
                    return PokerAction.CHECK, 0
                else: # 40% chance to raise if no bet
                    amount = min(remaining_chips, self.big_blind_amount * 2) # Raise just big blind amount
                    if round_state.min_raise > 0:
                        amount = max(amount, round_state.min_raise)
                    amount = max(amount, round_state.current_bet + self.big_blind_amount * 2) # Ensure it's a valid raise
                    if amount > remaining_chips:
                        return PokerAction.ALL_IN, 0
                    elif amount > round_state.max_raise: # Cap at max_raise
                        amount = round_state.max_raise
                    if amount >= round_state.min_raise and amount <= remaining_chips:
                        return PokerAction.RAISE, amount
                    else: # Fallback to check/call if raise invalid
                        return PokerAction.CHECK, 0
            else: # If there's a bet to match
                if remaining_chips <= current_bet_to_match: # Not enough to call, go all-in or fold
                    if random.random() < 0.3: # 30% chance to go all-in
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Can afford to call
                    if current_bet_to_match > remaining_chips / 3 and random.random() < 0.7:
                        # High bet relative to stack, higher chance to fold
                        return PokerAction.FOLD, 0
                    elif random.random() < 0.6: # 60% chance to call
                        return PokerAction.CALL, 0
                    elif random.random() < 0.8: # 20% chance to raise (if strength)
                        raise_amount = current_bet_to_match + random.randint(1, 3) * self.big_blind_amount # Small to medium raise
                        raise_amount = max(raise_amount, round_state.current_bet + round_state.min_raise)
                        raise_amount = min(raise_amount, remaining_chips)
                        if raise_amount > round_state.max_raise:
                            raise_amount = round_state.max_raise

                        if raise_amount >= round_state.current_bet + round_state.min_raise and raise_amount <= remaining_chips:
                            return PokerAction.RAISE, raise_amount
                        else: # If raise is invalid, fallback to call or fold
                            return PokerAction.CALL, 0
                    else: # 20% chance to fold
                        return PokerAction.FOLD, 0

        # Post-flop (Flop, Turn, River) decision
        else: # Flop, Turn, River
             # Much more aggressive post-flop since community cards are out.
            if can_check:
                if random.random() < 0.5: # 50% chance to check
                    return PokerAction.CHECK, 0
                else: # 50% chance to bet
                    bet_amount = int(round_state.pot * (0.3 + 0.4 * random.random())) # Bet 30-70% of pot
                    bet_amount = max(bet_amount, self.big_blind_amount) # Minimum bet is big blind
                    bet_amount = min(bet_amount, remaining_chips)
                    if bet_amount > round_state.max_raise: # Cap at max_raise
                        bet_amount = round_state.max_raise
                    
                    if bet_amount >= round_state.min_raise and bet_amount <= remaining_chips:
                        return PokerAction.RAISE, bet_amount # Using RAISE for a "bet" when current_bet is 0
                    elif bet_amount > 0 and bet_amount < round_state.min_raise: # If bet is too low, but we want to bet something
                         return PokerAction.RAISE, round_state.min_raise if round_state.min_raise <= remaining_chips else remaining_chips
                    else: # Fallback to check if no valid bet
                        return PokerAction.CHECK, 0
            else: # If there's a bet to match
                if remaining_chips <= current_bet_to_match + 0.0001: # Use small delta for float comparison safety
                    # Not enough to call, must go all-in or fold
                    if random.random() < 0.4: # 40% chance to go all-in
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Can afford to call
                    if current_bet_to_match > remaining_chips / 2 and random.random() < 0.6:
                        # High bet relative to stack, higher chance to fold
                        return PokerAction.FOLD, 0
                    elif random.random() < 0.5: # 50% chance to call
                        return PokerAction.CALL, 0
                    elif random.random() < 0.8: # 30% chance to raise (if perceived strength or bluff)
                        raise_amount = current_bet_to_match + int(round_state.pot * (0.2 + 0.5 * random.random())) # Raise pot-sized
                        raise_amount = max(raise_amount, round_state.current_bet + round_state.min_raise)
                        raise_amount = min(raise_amount, remaining_chips)

                        if raise_amount > round_state.max_raise:
                            raise_amount = round_state.max_raise

                        if raise_amount >= round_state.current_bet + round_state.min_raise and raise_amount <= remaining_chips:
                            return PokerAction.RAISE, raise_amount
                        else: # If raise is invalid, fallback to call or fold.
                             if remaining_chips >= current_bet_to_match:
                                 return PokerAction.CALL, 0
                             else:
                                 return PokerAction.FOLD, 0
                    else: # 20% chance to fold
                        return PokerAction.FOLD, 0

        # Fallback in case none of the above conditions are met (should not happen with comprehensive logic)
        # Always prefer to fold if unsure, to avoid invalid actions.
        if current_bet_to_match == 0:
            return PokerAction.CHECK, 0
        elif remaining_chips >= current_bet_to_match:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0


    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.hole_cards = [] # Clear hole cards for next round consistency
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass