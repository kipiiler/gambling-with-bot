from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_hand: List[str] = []
        self.big_blind = 0
        self.small_blind = 0
        self.starting_chips = 0
        self.player_id = -1 # Will be set by set_id

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.player_hand = player_hands
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.starting_chips = starting_chips

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.player_hand = round_state.player_hands.get(str(self.id), []) # Access own hand
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = current_bet_to_match - my_current_bet

        # Basic hand strength evaluation (simplified)
        # Higher card ranks, pairs, suited cards are stronger
        # Rank mapping (assuming A, K, Q, J, T, 9, 8, 7, 6, 5, 4, 3, 2)
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

        card1_rank = rank_map[self.player_hand[0][0]]
        card2_rank = rank_map[self.player_hand[1][0]]
        card1_suit = self.player_hand[0][1]
        card2_suit = self.player_hand[1][1]

        is_pair = card1_rank == card2_rank
        is_suited = card1_suit == card2_suit
        
        # Determine aggressiveness based on hand strength and round
        hand_strength = 0

        # Pre-flop strategy
        if round_state.round == 'Preflop':
            # Premium pairs (AA, KK, QQ, JJ, TT)
            if is_pair and card1_rank >= 10: # T+
                hand_strength = 3 # Strong
            # High suited connectors (AKs, AQs, KQs, QJs)
            elif is_suited and (card1_rank >= 12 or card2_rank >= 12) and (abs(card1_rank - card2_rank) <= 1): # AQ+, KQ+, QJ+
                hand_strength = 2.5 # Moderately strong
            # High cards (AK, AQ, AJ, KQ, KJ)
            elif (card1_rank >= 12 and card2_rank >= 10) or (card2_rank >= 12 and card1_rank >= 10): # AJ+
                hand_strength = 2 # Medium
            # Medium pairs (99, 88, 77)
            elif is_pair and card1_rank >= 7:
                hand_strength = 1.5 # Medium
            # Suited connectors (e.g., 87s, 98s)
            elif is_suited and abs(card1_rank - card2_rank) == 1 and card1_rank >= 7:
                hand_strength = 1 # Speculative
            else:
                hand_strength = 0 # Weak

            if hand_strength >= 2.5: # Premium hands
                if amount_to_call == 0: # If there's no bet, raise
                    return PokerAction.RAISE, min(round_state.max_raise, self.big_blind * 4) # Aggressive raise
                elif amount_to_call < remaining_chips / 5: # If bet is small, re-raise or call
                    return PokerAction.RAISE, min(round_state.max_raise, max(round_state.min_raise, current_bet_to_match * 2))
                else: # Otherwise, call or go all-in if confident
                    return PokerAction.CALL, 0 if amount_to_call <= remaining_chips else PokerAction.ALL_IN, 0

            elif hand_strength >= 1.5: # Medium strength hands
                if amount_to_call == 0:
                    return PokerAction.RAISE, min(round_state.max_raise, self.big_blind * 2) # Standard raise
                elif amount_to_call <= self.big_blind * 3: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0 # Fold to large bets

            elif hand_strength >= 1: # Speculative hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                elif amount_to_call <= self.big_blind: # Call small bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            else: # Weak hands
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

        # Post-flop strategy (Flop, Turn, River)
        # This part requires evaluating actual poker hands and draws, which is complex.
        # For simplicity, we'll use a very basic heuristic.
        # This section will likely be the primary area for improvement in future iterations.

        # Heuristic for post-flop: Check/Call small bets, Fold to large bets
        # This is a very passive and exploitable strategy but avoids major losses
        # when hand strength calculation is missing.

        # Check if we can check
        if current_bet_to_match == my_current_bet:
            return PokerAction.CHECK, 0
        
        # If not, evaluate call/fold
        if amount_to_call > 0:
            if amount_to_call >= remaining_chips: # If opponent forces us all-in
                # Only call if we have something good (e.g., made pair, good draw)
                # For now, being cautious.
                if is_pair or (is_suited and card1_rank >= 10) or (abs(card1_rank - card2_rank) == 1 and card1_rank >= 10):
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Simple threshold for calling post-flop
            # You would replace this with actual hand evaluation
            if amount_to_call <= self.big_blind * 2: # Call small bets
                return PokerAction.CALL, 0
            else: # Fold to larger bets
                return PokerAction.FOLD, 0

        return PokerAction.FOLD, 0 # Default to fold if no other action is determined

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass