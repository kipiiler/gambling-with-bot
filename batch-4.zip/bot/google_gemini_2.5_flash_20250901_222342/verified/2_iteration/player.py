import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.hand_strength = 0 # 0-100, 100 being strongest
        self.starting_chips = 0
        self.current_blind_amount = 0
        self.is_it_my_turn = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.current_blind_amount = blind_amount
        self.all_players = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Re-evaluate logic for hole cards and hand strength based on provided player_hands.
        # This setup assumes player_hands is dynamic and will update with hole cards.
        # In a real game, this is usually set once at the start of a hand.
        # Will mock hole_cards for now.
        # This should capture player's own cards passed during a game event, not from global player_hands directly.
        # The bot api doesn't expose player_hands with hole cards other than on_start, so we assume
        # context for current hole cards will be handled externally or derived from other messages.
        # For this iteration, we'll use a placeholder for hand_strength that becomes more dynamic later.
        self.is_it_my_turn = str(self.id) in [str(p_id) for p_id in round_state.current_player]

        # Simplified hand strength: random for now, will improve in future iterations
        # The error logs showed 'RAISE, amount: 0' and 'CHECK' when not allowed.
        # We need to enforce proper action logic.
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet_to_match = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        min_raise_amount = round_state.min_raise
        max_raise_amount = round_state.max_raise
        
        # Determine actual hand strength based on phase and cards
        # Placeholder: This needs to be replaced with actual poker hand evaluation logic.
        # For now, let's make it slightly more strategic than random but still simple.
        # We'll use a hardcoded value that pretends to be a hand strength.
        # In a real bot, you'd evaluate self.hole_cards + round_state.community_cards.
        if not hasattr(self, 'temp_hand_strength'): # Initialize for the hand
            self.temp_hand_strength = random.randint(0, 100)

        # The bot made invalid raise actions (amount 0 or less than min_raise).
        # Fix: Ensure raise amount is always valid.

        if self.temp_hand_strength > 70:  # Strong hand
            if current_bet_to_match == 0:
                # If no bet, check, or raise aggressively
                if remaining_chips >= min_raise_amount:
                    # Raise by a strong amount, e.g., 2 times blind or min_raise
                    raise_to = max(min_raise_amount, 2 * self.current_blind_amount)
                    raise_to = min(raise_to, remaining_chips - current_bet_to_match)
                    if raise_to + current_bet_to_match > round_state.max_raise:
                        raise_to = round_state.max_raise - current_bet_to_match
                    if raise_to <= 0 and remaining_chips > 0: # Ensure raise is positive
                        # If calculated raise is 0 or less, which means min_raise_amount itself is 0,
                        # due to small stack, then go all in if we still want to be aggressive, otherwise check
                        if remaining_chips >= current_bet_to_match and current_bet_to_match > 0:
                            return PokerAction.CALL, 0
                        return PokerAction.CHECK, 0 if current_bet_to_match == 0 else max(min_raise_amount,remaining_chips)
                    if raise_to <= 0 and current_bet_to_match == 0: # If we wanted to raise but couldn't, and can check
                        return PokerAction.CHECK, 0
                    if raise_to + current_bet_to_match < min_raise_amount: # ensure min raise
                        raise_to = min_raise_amount - current_bet_to_match
                        raise_to = max(0, raise_to) # don't bet negative
                    
                    if raise_to > 0 and raise_to <= remaining_chips:
                        return PokerAction.RAISE, current_bet_to_match + raise_to
                    elif current_bet_to_match == 0:
                        return PokerAction.CHECK, 0
                    else: # If we can't raise but have to act, call or all-in
                        if current_bet_to_match <= remaining_chips:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0 # Go all-in if cannot call full bet
                else: # Cannot raise, check or call if possible
                    if current_bet_to_match == 0:
                        return PokerAction.CHECK, 0
                    else:
                        if current_bet_to_match <= remaining_chips:
                            return PokerAction.CALL, 0
                        else: # If cannot call, go all-in
                            return PokerAction.ALL_IN, 0

            else: # There's a bet, raise or call
                # Aggressive play: re-raise or call
                if remaining_chips >= (current_bet_to_match + min_raise_amount):
                    raise_to = max(min_raise_amount, 2 * current_bet_to_match)
                    raise_to = min(raise_to, remaining_chips)
                    if raise_to + current_bet_to_match > round_state.max_raise:
                        raise_to = round_state.max_raise - current_bet_to_match
                    if raise_to <= 0 and remaining_chips > 0: # If calculated raise is 0 or less, due to small stack or strange min_raise
                        if remaining_chips >= current_bet_to_match:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0 # Go all-in if cannot call full bet
                    
                    actual_raise_amount = current_bet_to_match + raise_to
                    if actual_raise_amount > round_state.max_raise:
                        actual_raise_amount = round_state.max_raise
                    
                    # Ensure actual_raise_amount is at least current_bet + min_raise for a valid raise.
                    # Or at least match current_bet_to_match if only calling is possible.
                    if raise_to > 0 and (actual_raise_amount >= round_state.current_bet + round_state.min_raise or 
                                       actual_raise_amount >= round_state.current_bet + 1): # +1 to make it a raise
                        return PokerAction.RAISE, actual_raise_amount
                    elif current_bet_to_match <= remaining_chips:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.ALL_IN, 0

                elif current_bet_to_match <= remaining_chips: # Cannot raise, just call
                    return PokerAction.CALL, 0
                else: # Cannot call, go all-in or fold
                    return PokerAction.ALL_IN, 0 # Prefer all-in over fold with strong hand


        elif 50 <= self.temp_hand_strength <= 70:  # Medium hand
            if current_bet_to_match == 0:
                # Check if no bet, otherwise call or fold based on bet size
                return PokerAction.CHECK, 0
            else:
                # Call small bets, fold large bets
                if current_bet_to_match <= remaining_chips:
                     # Calculate risk vs reward. If pot too big, fold.
                    if current_bet_to_match < self.current_blind_amount * 3 or (remaining_chips - current_bet_to_match) < remaining_chips * 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else: # Cannot call, so fold
                    return PokerAction.FOLD, 0

        else:  # Weak hand (self.temp_hand_strength < 50)
            if current_bet_to_match == 0:
                return PokerAction.CHECK, 0
            else:
                # Always fold if there's a bet and hand is weak
                return PokerAction.FOLD, 0
                
        # Fallback for unexpected scenarios, should ideally not be reached.
        # This prevents returning an invalid action and crashing.
        if current_bet_to_match == 0:
            return PokerAction.CHECK, 0
        elif current_bet_to_match <= remaining_chips:
            return PokerAction.CALL, 0
        else:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset any per-hand state here if necessary
        self.hand_strength = 0
        if hasattr(self, 'temp_hand_strength'):
            del self.temp_hand_strength # Reset hand strength for next round

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Clean up or log at the end of the game
        pass