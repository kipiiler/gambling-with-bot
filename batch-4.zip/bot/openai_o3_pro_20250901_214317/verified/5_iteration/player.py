# player.py
from typing import List, Tuple, Dict
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# external pure-python hand evaluator
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A reasonably strong baseline bot for No-Limit Texas Hold’em.
    It combines a pre-flop push / fold chart with a simple post-flop
    Monte-Carlo equity calculation (using the pure-python `treys`
    library) and basic pot-odds reasoning.
    """

    # --- constants  --------------------------------------------------------
    PREFLOP_RAISE = 4           # big-blind multiples for default raise
    MONTE_CARLO_ITERS = 400     # equity simulation iterations
    RAISE_EPSILON = 0.15        # winProb – potOdds margin needed to raise
    ALLIN_THRESHOLD = 0.85      # go all-in if winProb exceeds this

    # quick ordering for rank comparison
    RANK_ORDER = "23456789TJQKA"

    # tiered starting-hand table (pairs, suited, off-suit)
    TIER_1_PAIRS = {"AA", "KK", "QQ", "JJ"}
    TIER_2_PAIRS = {"TT", "99", "88"}
    TIER_3_PAIRS = {"77", "66", "55"}

    # premium suited / off-suit
    SUITED_PREMIUM = {"AK", "AQ", "AJ", "KQ"}
    OFF_PREMIUM = {"AK", "AQ"}

    # --- life-cycle hooks --------------------------------------------------
    def __init__(self) -> None:
        super().__init__()

        # updated every round
        self.hole_cards: List[str] = []          # e.g. ['Ah', 'Kd']
        self.blind_amount: int = 0
        self.starting_chips: int = 0

        # bookkeeping
        self.round_counter: int = 0
        self.evaluator = Evaluator()

    # ----------------------------------------------------------------------
    #  API mandatory callbacks
    # ----------------------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount

        # we receive our first two hole cards here (start of hand 0)
        # the spec says `player_hands` is a list of strings for us
        if player_hands:
            self.hole_cards = player_hands

    # ----------------------------------------------------------------------
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_counter += 1

        # many servers include player_hands in the state message;
        # if present, grab it.  Otherwise keep what we had.
        if hasattr(round_state, "player_hands"):
            self.hole_cards = getattr(round_state, "player_hands", self.hole_cards)

    # ----------------------------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:

        # 1. gather basic numeric facts
        my_id = str(self.id)
        my_bet = round_state.player_bets.get(my_id, 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = max(1, round_state.pot)  # avoid /0

        can_check = to_call == 0

        # 2. estimate strength
        win_prob = self.estimate_win_probability(
            self.hole_cards,
            round_state.community_cards,
            max(1, len(round_state.current_player) - 1),
        )

        # 3. pot-odds decision logic
        call_odds = to_call / (pot + to_call) if to_call > 0 else 0
        margin = win_prob - call_odds

        # 4. choose action ---------------------------------------------------
        # 4.1 consider folding
        if not can_check and win_prob < 0.2:
            return PokerAction.FOLD, 0

        # 4.2 default is to call / check
        chosen_action = PokerAction.CALL if not can_check else PokerAction.CHECK
        chosen_amount = 0

        # 4.3 consider raising / all-in
        if margin > self.RAISE_EPSILON:
            if win_prob > self.ALLIN_THRESHOLD or (
                remaining_chips < pot and win_prob > 0.7
            ):
                return PokerAction.ALL_IN, 0

            # compute raise value
            min_raise = round_state.min_raise
            desired = max(
                min_raise,
                self.blind_amount * self.PREFLOP_RAISE,
            )

            # never exceed our stack or table max
            desired = min(desired, round_state.max_raise)

            if desired > to_call:  # still a legitimate raise
                chosen_action = PokerAction.RAISE
                chosen_amount = desired

        # 4.4 if we’re checking, no amount; for call amount handled by server
        return chosen_action, chosen_amount

    # ----------------------------------------------------------------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # nothing fancy yet – could store history
        pass

    # ----------------------------------------------------------------------
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # final statistics print (disabled to keep stdout clean)
        pass

    # ----------------------------------------------------------------------
    #  Helper methods
    # ----------------------------------------------------------------------
    # fast pre-flop heuristic
    # ----------------------------------------------------------------------
    def preflop_strength(self, hole_cards: List[str]) -> float:
        """
        Returns an approximate winning probability in the 0-1 range
        based on a simple starting-hand chart.
        """
        if len(hole_cards) != 2:
            return 0.0

        ranks = "".join(sorted([c[0] for c in hole_cards], key=self.RANK_ORDER.index, reverse=True))
        suited = hole_cards[0][1] == hole_cards[1][1]

        # pairs
        if hole_cards[0][0] == hole_cards[1][0]:
            pair = ranks
            if pair in self.TIER_1_PAIRS:
                return 0.8
            if pair in self.TIER_2_PAIRS:
                return 0.7
            if pair in self.TIER_3_PAIRS:
                return 0.62
            return 0.55  # small pairs

        # suited / off-suit connectors
        if suited and ranks in self.SUITED_PREMIUM:
            return 0.65
        if not suited and ranks in self.OFF_PREMIUM:
            return 0.6

        # broadway cards both ≥ Ten
        if all(r in "TJQKA" for r in ranks):
            return 0.57

        # suited one-gappers / wheel aces
        if suited and ("A" in ranks or "K" in ranks):
            return 0.52

        # otherwise mediocre
        return 0.4

    # ----------------------------------------------------------------------
    def estimate_win_probability(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        villains: int,
        iterations: int = None,
    ) -> float:
        """
        Simple Monte-Carlo equity calculator using treys.
        """
        if iterations is None:
            iterations = self.MONTE_CARLO_ITERS

        # pre-flop shortcut to save CPU
        if not community_cards:
            return self.preflop_strength(hole_cards)

        try:
            hero = [Card.new(c) for c in hole_cards]
        except Exception:
            return 0.5  # in doubt, neutral equity

        board_cards = [Card.new(c) for c in community_cards]

        known_cards_set = set(hero + board_cards)

        wins = 0
        ties = 0

        evaluator = self.evaluator

        # build a fresh deck without known cards
        full_deck = [c for c in Deck.GetFullDeck() if c not in known_cards_set]
        for _ in range(iterations):
            random.shuffle(full_deck)
            # draw remaining community
            samples_needed = 5 - len(board_cards)
            drawn = full_deck[: samples_needed + 2 * villains]
            opp_hole_start = samples_needed
            board_sample = drawn[:samples_needed]
            board = board_cards + board_sample

            # hero hand strength
            hero_rank = evaluator.evaluate(board, hero)

            # compare with each villain
            hero_best = True
            tie = False
            idx = opp_hole_start
            for v in range(villains):
                opp = [drawn[idx], drawn[idx + 1]]
                idx += 2
                opp_rank = evaluator.evaluate(board, opp)
                if opp_rank < hero_rank:
                    hero_best = False
                    break
                if opp_rank == hero_rank:
                    tie = True

            if hero_best:
                wins += 1
            elif tie:
                ties += 1

        denom = iterations + 1e-9
        return (wins + ties * 0.5) / denom


# end SimplePlayer