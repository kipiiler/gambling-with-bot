# player.py
from __future__ import annotations

import random
from typing import List, Tuple, Optional

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# We use the pure-python “treys” package for hand evaluation
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A relatively small but fully-functional No-Limit Texas Hold’em bot.

    Main ideas
    -----------
    1.  Pre-flop – Chen formula:
        • Translates our two private cards into a Chen score (1-20).
        • The score is normalised (divided by 20) and interpreted as an
          approximate win-probability against a random hand.
        • Depending on this “strength” the bot folds, calls / checks, or raises.

    2.  Post-flop – Monte-Carlo equity:
        • Uses treys’ fast evaluator to estimate our equity with 150 random
          simulations versus ONE opponent (heads-up approximation).
        • Compares equity with immediate pot-odds to decide on folding /
          calling / betting.
        • A value bet or semi-bluff is sized at ~75 % of the pot, but always
          inside the allowed raise bounds.

    3.  Safety:
        • All returned actions are validated against the game state to prevent
          invalid moves (which would force an automatic fold).
        • Every public interface method is wrapped in try / except – if
          something unexpected happens we fall back to a safe FOLD.  This makes
          sure our bot never crashes and forfeits chips through an exception.
    """

    # --------------------------------------------------------------------- #
    #  Lifecyle callbacks                                                   #
    # --------------------------------------------------------------------- #
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.evaluator: Evaluator = Evaluator()
        self.random = random.Random()
        self.random.seed()  # System time seed

        # Will be refreshed every round
        self.hole_cards: List[str] = []

    # ---------------- Game start ----------------------------------------- #
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2  # Game provides the SB amount
        # The first list of hole cards sometimes arrives here
        self.hole_cards = player_hands or []

    # ---------------- Round start ---------------------------------------- #
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Attempt to refresh our current hole cards from the round state
        cards = self._extract_private_cards(round_state)
        if cards:
            self.hole_cards = cards

    # ---------------- Our turn ------------------------------------------- #
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        try:
            # We ALWAYS make sure to know our hand; otherwise fold
            if not self.hole_cards:
                return PokerAction.FOLD, 0

            stage = round_state.round.lower()  # 'preflop' / 'flop' / 'turn' / 'river'
            to_call = max(0, round_state.current_bet)
            min_raise = round_state.min_raise
            max_raise = min(round_state.max_raise, remaining_chips)

            if stage == "preflop":
                strength = self._chen_strength(self.hole_cards)
                return self._preflop_decision(
                    strength, to_call, min_raise, max_raise, round_state
                )
            else:  # Post-flop streets
                win_prob = self._estimate_equity(self.hole_cards, round_state)
                return self._postflop_decision(
                    win_prob, to_call, min_raise, max_raise, round_state
                )

        except Exception:
            # Fallback: Never crash – simply fold
            return PokerAction.FOLD, 0

    # ---------------- Round end ------------------------------------------ #
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear hand – new cards every round
        self.hole_cards = []

    # ---------------- Game end ------------------------------------------- #
    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # Nothing persistent to store for now

    # --------------------------------------------------------------------- #
    #  Decision helpers                                                     #
    # --------------------------------------------------------------------- #
    # ----- Pre-flop ------------------------------------------------------- #
    def _preflop_decision(
        self,
        strength: float,
        to_call: int,
        min_raise: int,
        max_raise: int,
        state: RoundStateClient,
    ) -> Tuple[PokerAction, int]:
        """
        Very simple chart based on normalised Chen strength.
        strength ≈ win-probability vs random hand (0-1).
        """

        # 1.   MONSTER hand – raise big (pot-sized or all-in if very strong)
        if strength >= 0.85:
            raise_amt = max(min_raise, int(state.pot * 0.75))
            raise_amt = min(raise_amt, max_raise)
            return PokerAction.RAISE, raise_amt

        # 2.   STRONG hand – raise standard
        if strength >= 0.7:
            raise_amt = max(min_raise, int(state.pot * 0.5))
            raise_amt = min(raise_amt, max_raise)
            # If calling is cheaper than our desired raise and there was a big
            # open, we simply call
            if to_call and raise_amt < to_call * 2:
                return (
                    PokerAction.CALL if to_call <= max_raise else PokerAction.FOLD,
                    0,
                )
            return PokerAction.RAISE, raise_amt

        # 3.   MEDIOCRE hand – limp / call small
        if strength >= 0.55:
            if to_call == 0:
                return PokerAction.CHECK, 0
            return (PokerAction.CALL, 0) if to_call <= state.pot * 0.25 else (PokerAction.FOLD, 0)

        # 4.   WEAK hand – fold unless we can check
        return (PokerAction.CHECK, 0) if to_call == 0 else (PokerAction.FOLD, 0)

    # ----- Post-flop ------------------------------------------------------ #
    def _postflop_decision(
        self,
        win_prob: float,
        to_call: int,
        min_raise: int,
        max_raise: int,
        state: RoundStateClient,
    ) -> Tuple[PokerAction, int]:
        """
        Simple pot-odds comparison:
        If equity>pot-odds (+margin) => continue, else fold.
        With very strong equity (>0.7) we value-bet.
        """

        if to_call == 0:
            # We are not facing a bet
            if win_prob > 0.7 and max_raise >= min_raise:
                bet = max(min_raise, int(state.pot * 0.75))
                bet = min(bet, max_raise)
                return PokerAction.RAISE, bet
            return PokerAction.CHECK, 0

        # We are facing a bet
        pot_odds = to_call / max(state.pot + to_call, 1)  # Avoid /0

        # Decide
        if win_prob > pot_odds + 0.05:
            # Call is profitable
            if win_prob > 0.75 and max_raise >= min_raise:
                # Value-raise for even stronger hands
                bet = max(min_raise, int(state.pot * 0.65))
                bet = min(bet, max_raise)
                if bet > to_call * 2:  # Only raise if it is a real raise
                    return PokerAction.RAISE, bet
            return PokerAction.CALL, 0

        # Otherwise fold
        return PokerAction.FOLD, 0

    # --------------------------------------------------------------------- #
    #  Strength evaluation                                                  #
    # --------------------------------------------------------------------- #
    # ----- Chen formula --------------------------------------------------- #
    _RANK_ORDER = "23456789TJQKA"
    _CHEN_BASE = {
        "A": 10,
        "K": 8,
        "Q": 7,
        "J": 6,
        "T": 5,
        "9": 4.5,
        "8": 4,
        "7": 3.5,
        "6": 3,
        "5": 2.5,
        "4": 2,
        "3": 1.5,
        "2": 1,
    }

    def _chen_strength(self, cards: List[str]) -> float:
        """Returns normalised Chen score (≈ 0-1)."""
        if len(cards) != 2:
            return 0.0

        r1, s1 = cards[0][0], cards[0][1]
        r2, s2 = cards[1][0], cards[1][1]

        # Base points
        high, low = (r1, r2) if self._RANK_ORDER.index(r1) > self._RANK_ORDER.index(r2) else (r2, r1)
        score = self._CHEN_BASE[high]

        # Pair rule
        if r1 == r2:
            score *= 2
            if score < 5:
                score = 5
        else:
            # Suited bonus
            if s1 == s2:
                score += 2

            # Gap penalty
            gap = abs(self._RANK_ORDER.index(r1) - self._RANK_ORDER.index(r2)) - 1
            if gap == 0:
                pass
            elif gap == 1:
                score -= 1
            elif gap == 2:
                score -= 2
            elif gap == 3:
                score -= 4
            else:
                score -= 5

            # Straight bonus
            high_value = self._RANK_ORDER.index(high) >= self._RANK_ORDER.index("8")  # Both ≥ 8
            if gap <= 2 and high_value:
                score += 1

        score = max(score, 0)
        return min(score / 20.0, 1.0)

    # ----- Monte-Carlo equity -------------------------------------------- #
    def _estimate_equity(self, hole_cards: List[str], state: RoundStateClient, iters: int = 150) -> float:
        """
        Heads-up equity estimate with simple Monte-Carlo simulation.
        Runs `iters` random rollouts with treys evaluator.
        """
        if not hole_cards or len(hole_cards) != 2:
            return 0.0

        board = [Card.new(c) for c in state.community_cards]
        our_hand = [Card.new(c) for c in hole_cards]

        # Quick exits
        if len(board) == 5:
            # Fully determined – no need for MC
            opp_unknown = []
            score_hero = self.evaluator.evaluate(board, our_hand)
            # Generate MANY possible villain hands to average
            wins = ties = 0
            deck_full = Deck()
            used = set(board + our_hand)
            for c in used:
                deck_full.cards.remove(c)
            all_remaining = deck_full.cards
            # sample 100 random opponent hands
            for _ in range(100):
                opp_hand = self.random.sample(all_remaining, 2)
                score_villain = self.evaluator.evaluate(board, opp_hand)
                if score_hero < score_villain:
                    wins += 1
                elif score_hero == score_villain:
                    ties += 1
            return (wins + 0.5 * ties) / 100.0

        # Otherwise MC on remaining deck
        wins = ties = 0
        for _ in range(iters):
            deck = Deck()
            # remove known cards
            known = set(board + our_hand)
            for c in known:
                deck.cards.remove(c)

            opp_hand = deck.draw(2)
            needed_cards = 5 - len(board)
            sim_board = board + deck.draw(needed_cards)

            score_hero = self.evaluator.evaluate(sim_board, our_hand)
            score_opp = self.evaluator.evaluate(sim_board, opp_hand)

            if score_hero < score_opp:
                wins += 1
            elif score_hero == score_opp:
                ties += 1

        return (wins + 0.5 * ties) / float(iters)

    # --------------------------------------------------------------------- #
    #  Utilities                                                            #
    # --------------------------------------------------------------------- #
    def _extract_private_cards(self, state: RoundStateClient) -> Optional[List[str]]:
        """
        Tries several plausible attribute names to find our private cards in the
        provided RoundStateClient.  Returns None if not available.
        """
        possible_fields = ["player_hands", "playerHands", "hole_cards", "hand", "hands"]
        for field in possible_fields:
            if hasattr(state, field):
                container = getattr(state, field)
                if isinstance(container, dict):
                    # Keys may be int or str
                    for key in (self.id, str(self.id)):
                        if key in container:
                            return container[key]
                elif isinstance(container, list) and len(container) == 2:
                    # Direct list of two cards – assume it is ours
                    return container
        return None