# player.py
import random
from typing import List, Tuple, Dict, Any

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# We use the pure-python hand evaluator from the treys library
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A very small, self–contained no-limit Texas Hold’em bot.

    High-level idea
    ----------------
    1.  Pre-flop – play a fixed “sensible” starting-hand chart.
    2.  Post-flop – estimate our winning probability with Monte-Carlo
        simulation (treys Evaluator) and compare it with pot odds.
    3.  Always respect the game-engine constraints – never produce an
        illegal action.  Fallback is FOLD.
    """

    # --- static helpers -------------------------------------------------- #

    _evaluator = Evaluator()               # one global hand evaluator
    _rank_char = '23456789TJQKA'
    _rank_val: Dict[str, int] = {c: i for i, c in enumerate(_rank_char, 2)}

    # --- lifecycle hooks ------------------------------------------------- #

    def __init__(self):
        super().__init__()

        # game-wide static information
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.all_player_ids: List[int] = []

        # round-scoped dynamic information
        self.hole_cards: List[str] = []     # e.g. ['Ah', 'Kd']
        self.round_num: int = 0

    # -------------------------------------------------------------------- #

    # noinspection PyMethodMayBeStatic
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2
        self.small_blind = blind_amount
        self.all_player_ids = all_players
        # our initial cards for round zero (if provided)
        if player_hands:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_num = round_state.round_num
        # The game engine usually sends us our fresh hole cards in the
        # round-state – try to extract them; if not present, we keep the
        # previous value (defensive coding).
        self.hole_cards = self._extract_hole_cards(round_state) or self.hole_cards

    # -------------------------------------------------------------------- #

    # main decision point ------------------------------------------------- #
    def get_action(
        self,
        round_state: RoundStateClient,
        remaining_chips: int,
    ) -> Tuple[PokerAction, int]:

        try:
            # ------------------------------------------------------------- #
            to_call = max(
                0,
                round_state.current_bet
                - round_state.player_bets.get(str(self.id), 0),
            )
            can_check = to_call == 0
            pot_size = round_state.pot
            min_raise = round_state.min_raise

            # ------------------------------------------------------------- #
            # 1. If we do not know our cards for whatever reason – fold.
            if len(self.hole_cards) != 2:
                return PokerAction.FOLD, 0

            # 2. Decide based on betting round
            if round_state.round.lower() == 'preflop':
                action, amount = self._preflop_decision(
                    to_call, can_check, min_raise, remaining_chips
                )
            else:
                action, amount = self._postflop_decision(
                    round_state,
                    to_call,
                    can_check,
                    pot_size,
                    min_raise,
                    remaining_chips,
                )

            # Finally, double-check that the chosen action is legal;
            # otherwise downgrade to a safe alternative.
            action, amount = self._ensure_legal(
                action,
                amount,
                to_call,
                can_check,
                min_raise,
                remaining_chips,
            )
            return action, amount
        except Exception:
            # Any unexpected error → safe fold
            return PokerAction.FOLD, 0

    # -------------------------------------------------------------------- #

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clear hole cards – we receive fresh ones on the next hand
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        # No persistent storage required for this simple bot
        pass

    # ==================================================================== #
    # --------------------------- helpers -------------------------------- #
    # ==================================================================== #

    # ----------  pre-flop  ------------------------------------------------ #
    def _preflop_decision(
        self,
        to_call: int,
        can_check: bool,
        min_raise: int,
        stack: int,
    ) -> Tuple[PokerAction, int]:

        strength = self._preflop_strength(self.hole_cards)

        # Mapping strength → action
        if strength == 3:  # absolute premium
            if to_call > 0:
                # shove for max pressure if we still cover the table
                if stack > 0:
                    return PokerAction.ALL_IN, 0
            else:
                # no bet yet – put in a 4× raise (or our whole stack if short)
                raise_amount = min(stack, min_raise * 4)
                if raise_amount >= min_raise and raise_amount < stack:
                    return PokerAction.RAISE, raise_amount
                return PokerAction.ALL_IN, 0

        if strength == 2:  # good but not nuts
            # Call small raises; fold vs huge ones
            if to_call <= self.big_blind * 3:
                if to_call == 0:
                    # open-raise small
                    raise_amount = min(stack, max(min_raise, self.big_blind * 3))
                    if raise_amount < stack:
                        return PokerAction.RAISE, raise_amount
                    return PokerAction.ALL_IN, 0
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0

        if strength == 1:  # speculative
            if to_call <= self.big_blind:    # set-mine cheaply
                return PokerAction.CALL, 0
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Weak trash
        if can_check:
            return PokerAction.CHECK, 0
        return PokerAction.FOLD, 0

    # ----------  post-flop  --------------------------------------------- #
    def _postflop_decision(
        self,
        round_state: RoundStateClient,
        to_call: int,
        can_check: bool,
        pot_size: int,
        min_raise: int,
        stack: int,
    ) -> Tuple[PokerAction, int]:

        win_prob = self._estimate_win_probability(
            self.hole_cards,
            round_state.community_cards,
            max(1, len(round_state.current_player) - 1),
        )

        pot_odds_den = pot_size + to_call
        pot_odds = to_call / (pot_odds_den + 1e-9) if pot_odds_den > 0 else 0.0

        # Simple policy
        margin = 0.15
        if to_call == 0:
            # No bet to us – decide whether to value-bet
            if win_prob > 0.7:
                raise_amount = min(stack, max(min_raise, int(pot_size * 0.75)))
                if raise_amount < min_raise or raise_amount >= stack:
                    return PokerAction.CHECK, 0
                return PokerAction.RAISE, raise_amount
            return PokerAction.CHECK, 0

        # Facing a bet
        if win_prob >= pot_odds + margin:
            # we are well ahead → aggressive
            if win_prob > 0.85 or (stack < pot_size and win_prob > 0.75):
                return PokerAction.ALL_IN, 0
            return PokerAction.CALL, 0

        if win_prob >= pot_odds:
            return PokerAction.CALL, 0

        # otherwise fold
        return PokerAction.FOLD, 0

    # ----------  strength helpers --------------------------------------- #

    @classmethod
    def _preflop_strength(cls, cards: List[str]) -> int:
        """
        Very small lookup table:
        3 = premium / monster
        2 = strong
        1 = playable
        0 = trash
        """
        if len(cards) != 2:
            return 0

        r1, s1 = cards[0][0], cards[0][1]
        r2, s2 = cards[1][0], cards[1][1]
        paired = r1 == r2
        suited = s1 == s2
        high1 = cls._rank_val[r1]
        high2 = cls._rank_val[r2]
        high_max = max(high1, high2)
        high_min = min(high1, high2)

        # Premium
        if paired and high_max >= cls._rank_val['J']:
            return 3
        if {r1, r2} == {'A', 'K'} and suited:
            return 3

        # Strong
        if paired and high_max >= cls._rank_val['T']:
            return 2
        if {r1, r2} == {'A', 'Q'} and suited:
            return 2
        if {r1, r2} == {'A', 'J'} and suited:
            return 2
        if {r1, r2} == {'K', 'Q'} and suited:
            return 2
        if {r1, r2} == {'A', 'K'}:
            return 2

        # Playable
        if paired and high_max >= cls._rank_val['7']:
            return 1
        # suited connectors 98s+
        if suited and high_max - high_min == 1 and high_max >= cls._rank_val['9']:
            return 1
        # any ace suited
        if suited and ('A' in {r1, r2}):
            return 1

        return 0

    # ----------  Monte-Carlo win-probability ----------------------------- #
    def _estimate_win_probability(
        self,
        hole_cards: List[str],
        community_cards: List[str],
        num_opponents: int,
        samples: int = 200,
    ) -> float:
        """
        Monte-Carlo estimate using treys.  Pure python → safe for the judge.
        """
        if samples <= 0 or num_opponents <= 0:
            return 0.0

        known_ints = [Card.new(c) for c in (*hole_cards, *community_cards)]

        wins = ties = 0
        for _ in range(samples):
            deck = Deck()
            # Remove known cards
            for c in known_ints:
                if c in deck.cards:
                    deck.cards.remove(c)

            # Complete the community
            remaining_community = deck.draw(5 - len(community_cards))
            board_ints = [Card.new(c) for c in community_cards] + remaining_community

            # Opponents’ hands
            opp_hands = []
            for _ in range(num_opponents):
                opp_hands.append(deck.draw(2))

            # Our rank
            our_rank = SimplePlayer._evaluator.evaluate(
                board_ints, [Card.new(hole_cards[0]), Card.new(hole_cards[1])]
            )

            # Compare with every opponent
            best = True
            tie = False
            for opp in opp_hands:
                opp_rank = SimplePlayer._evaluator.evaluate(board_ints, opp)
                if opp_rank < our_rank:
                    best = False
                    break
                if opp_rank == our_rank:
                    tie = True
            if best:
                wins += 1
            elif tie:
                ties += 1

        total = wins + ties + 1e-9
        return (wins + ties * 0.5) / total

    # ----------  legal-action failsafe ---------------------------------- #
    @staticmethod
    def _ensure_legal(
        action: PokerAction,
        amount: int,
        to_call: int,
        can_check: bool,
        min_raise: int,
        stack: int,
    ) -> Tuple[PokerAction, int]:
        """
        Validate the tuple before returning it to the engine –
        downgrade to safest allowed alternative on any mismatch.
        """
        if action == PokerAction.FOLD:
            return PokerAction.FOLD, 0

        if action == PokerAction.CHECK:
            if can_check:
                return PokerAction.CHECK, 0
            # Not allowed – fall back
            return PokerAction.FOLD, 0

        if action == PokerAction.CALL:
            if to_call == 0 and can_check:
                return PokerAction.CHECK, 0
            if to_call <= stack:
                return PokerAction.CALL, 0
            # cannot afford – go all-in as call surrogate
            return PokerAction.ALL_IN, 0

        if action == PokerAction.RAISE:
            # amount must be sensible
            min_total = to_call + min_raise
            if amount < min_total:
                amount = min_total
            if amount >= stack:
                # converts into all-in
                return PokerAction.ALL_IN, 0
            if amount <= 0:
                return PokerAction.FOLD, 0
            return PokerAction.RAISE, amount

        if action == PokerAction.ALL_IN:
            if stack > 0:
                return PokerAction.ALL_IN, 0
            # no chips left – just check/fold
            if can_check:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Unknown / malformed – fold
        return PokerAction.FOLD, 0

    # ----------  misc ---------------------------------------------------- #
    @staticmethod
    def _extract_hole_cards(state: RoundStateClient) -> List[str]:
        """
        Tries several likely attribute names that game-servers often use
        for “my cards”.  All defensive so we never crash on missing data.
        """
        candidates: List[Any] = []
        # 1) explicit dict mapping
        ph = getattr(state, 'player_hands', None)
        if isinstance(ph, dict):
            my = ph.get(str(getattr(state, 'player_id', '')), [])
            if my:
                candidates = my
        # 2) direct attribute
        hc = getattr(state, 'hole_cards', None)
        if isinstance(hc, list) and len(hc) == 2:
            candidates = hc
        return candidates if len(candidates) == 2 else []