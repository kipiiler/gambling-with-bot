# player.py
from __future__ import annotations

import random
import time
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Hand evaluator (pure-python, very fast)
from treys import Card, Evaluator, Deck


class SimplePlayer(Bot):
    """
    A reasonably strong, yet lightweight no-limit Texas Hold’em bot.
    Strategy overview
    -----------------
    1.  Monte-Carlo equity estimation (<= 250 simulations) with treys.
    2.  Pot-odds comparison to decide Fold / Call / Raise / All-in.
    3.  Simple pre-flop raise chart for additional aggressiveness.
    The implementation respects every rule/edge-case required by the
    competition framework.
    """

    # --- Constructor --------------------------------------------------------------------
    def __init__(self) -> None:
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: int | None = None
        self.small_blind_player_id: int | None = None
        self.all_players: List[int] = []

        # Updated every hand
        self.hole_cards: List[str] = []
        self.round_start_time: float = 0.0
        self.evaluator = Evaluator()

    # --- Helper conversion --------------------------------------------------------------
    @staticmethod
    def _str_to_card(card_str: str) -> int:
        """Convert 'Ah'-style strings to treys integer representation."""
        return Card.new(card_str)

    # --- Game / hand lifecycle ----------------------------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        # Store our first hole cards (if provided at game start)
        self.hole_cards = player_hands or []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """Update hole cards if present in the round_state message."""
        self.round_start_time = time.time()

        # Many servers include hole cards inside round_state; try to capture them.
        possible_keys = ["player_hands", "hole_cards", "hands"]
        found = None
        for key in possible_keys:
            if hasattr(round_state, key):
                found = getattr(round_state, key)
                break
        if found:
            # The mapping might use str(id) or int(id) keys – try both
            self.hole_cards = (
                found.get(str(self.id)) or found.get(self.id) or self.hole_cards
            )

    # --- Monte-Carlo equity estimator ---------------------------------------------------
    def _estimate_win_prob(
        self, community_cards: List[str], opponents: int, iterations: int = 200
    ) -> float:
        """
        Return our probability of winning/tie given current board & number
        of active opponents using Monte-Carlo simulation.
        """
        if not self.hole_cards:
            return 0.0  # should never happen, but be safe

        board_ints = [self._str_to_card(c) for c in community_cards]
        hole_ints = [self._str_to_card(c) for c in self.hole_cards]

        evaluator = self.evaluator
        wins = ties = 0
        remaining = iterations

        # Build a fresh deck once to reuse & improve speed
        full_deck = Deck()
        known_cards = set(board_ints + hole_ints)
        for c in known_cards:
            full_deck.cards.remove(c)

        while remaining:
            # Clone remaining cards for this iteration (cheap list slice)
            deck_cards = full_deck.cards[:]
            random.shuffle(deck_cards)
            draw_index = 0

            # Complete community cards
            board = board_ints[:]
            need_board = 5 - len(board)
            if need_board > 0:
                board += deck_cards[draw_index : draw_index + need_board]
                draw_index += need_board

            # Opponents’ hole cards
            opp_hole = []
            for _ in range(opponents):
                opp_hole.append(
                    [deck_cards[draw_index], deck_cards[draw_index + 1]]
                )
                draw_index += 2

            our_rank = evaluator.evaluate(board, hole_ints)
            best = our_rank
            ties_here = 1  # count ourselves
            winner = 0  # 0 -> us, >0 means opponent index

            for i, pair in enumerate(opp_hole, 1):
                rank = evaluator.evaluate(board, pair)
                if rank < best:
                    best = rank
                    winner = i
                    ties_here = 1
                elif rank == best:
                    ties_here += 1

            if winner == 0:
                # We’re (joint) best
                if ties_here == 1:
                    wins += 1
                else:
                    # partial credit for split pot
                    wins += 1 / ties_here
            remaining -= 1

        return (wins + ties) / iterations if iterations else 0.0

    # --- Pre-flop strength heuristic ----------------------------------------------------
    @staticmethod
    def _preflop_strength(card1: str, card2: str) -> float:
        """
        Very small starting-hand strength map (0-1). Pairs & big-suited connectors
        get higher values. Good enough for quick decision making.
        """
        rank_order = "23456789TJQKA"
        r1, s1 = card1[0], card1[1]
        r2, s2 = card2[0], card2[1]

        same_suit = s1 == s2
        pair = r1 == r2
        gap = abs(rank_order.index(r1) - rank_order.index(r2))

        # Base
        strength = (rank_order.index(r1) + rank_order.index(r2)) / 24.0

        # Bonus for pair
        if pair:
            strength += 0.35
        # Bonus for suited
        if same_suit:
            strength += 0.08
        # Penalty for big gap
        if gap > 3:
            strength -= 0.1 * (gap - 3)

        return max(0.0, min(1.0, strength))

    # --- Decision engine ---------------------------------------------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:
        # Helpful local variables
        my_bet = round_state.player_bets.get(str(self.id), 0) or round_state.player_bets.get(self.id, 0)
        call_amount = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        can_check = round_state.current_bet == 0

        # Number of opponents still in the hand
        players_still_in = len(round_state.current_player)
        opponents = max(0, players_still_in - 1)

        # Estimate win probability
        if round_state.round.lower() == "preflop":
            if len(self.hole_cards) == 2:
                win_prob = self._preflop_strength(self.hole_cards[0], self.hole_cards[1])
            else:
                win_prob = 0.5
        else:
            # Use MC only post-flop where board cards exist
            remaining_iter = 150 if round_state.round.lower() == "flop" else 250
            win_prob = self._estimate_win_prob(
                round_state.community_cards, opponents, iterations=remaining_iter
            )

        # Pot odds
        pot_odds = call_amount / (pot + call_amount + 1e-9) if call_amount else 0.0

        # --- Action selection -----------------------------------------------------------
        # 1. No bet to us (we can check)
        if can_check:
            # Opportunity bet / raise for value
            if win_prob > 0.6 and min_raise <= remaining_chips:
                raise_amt = max(min_raise, int(pot * win_prob))
                raise_amt = min(raise_amt, max_raise, remaining_chips)
                # If raise amount is legal and changes the bet size, do it
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
            return PokerAction.CHECK, 0

        # 2. Someone bet – decide Fold / Call / Raise / All-in
        # If we are short-stacked such that call is all-in
        if call_amount >= remaining_chips:
            if win_prob > 0.45:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0

        # Profitable call?
        if win_prob >= pot_odds + 0.05:
            # Consider aggressive raise when we are far ahead
            if win_prob - pot_odds > 0.25 and min_raise <= remaining_chips:
                raise_amt = max(min_raise, int(call_amount * 2 + pot * 0.5))
                raise_amt = min(raise_amt, max_raise, remaining_chips)
                if raise_amt >= min_raise:
                    return PokerAction.RAISE, raise_amt
            return PokerAction.CALL, 0

        # Otherwise, fold
        return PokerAction.FOLD, 0

    # --- End-round / end-game hooks -----------------------------------------------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hole cards – new hand incoming
        self.hole_cards = []

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: Dict[int, float],
        active_players_hands: Dict[int, List[str]],
    ):
        # Nothing special – could log results if needed.
        pass