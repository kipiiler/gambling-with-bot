# player.py
from typing import List, Tuple, Dict, Optional
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# external pure-python hand evaluator -----------------------------
try:
    from treys import Card, Evaluator, Deck   # fast, pure-python, MIT licence
except ModuleNotFoundError:                   # failsafe – very weak fallback
    Card = None
    Evaluator = None
    Deck = None


class SimplePlayer(Bot):
    """
    A very small, self-contained no-limit Texas Hold'em bot that
    1) plays a reasonable pre-flop starting-hand chart,
    2) performs lightweight Monte-Carlo simulations post-flop (if treys is
       available) to estimate equity,
    3) always returns legal actions and never raises exceptions.
    It is purposely kept simple to remain comfortably within the 30-second /
    100 MB limits while still being competitive against baseline opponents.
    """

    # ---------- initialisation ------------------------------------------------
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.hole_cards: Optional[List[str]] = None
        self.evaluator = Evaluator() if Evaluator else None
        # random seed so that every bot of ours plays slightly differently
        random.seed()

    # ---------- callback helpers ---------------------------------------------
    def _retrieve_hole_cards(self, round_state: RoundStateClient) -> None:
        """
        Attempt to fetch our current two hole cards from the round_state.
        If not available, leave previous value untouched.
        The server implementation may provide them in a variety of ways;
        try a few reasonable guesses but always stay robust.
        """
        possible_attrs = ("player_hands", "hole_cards", "hole_card")
        for attr in possible_attrs:
            if hasattr(round_state, attr):
                hands = getattr(round_state, attr)
                if hands is None:
                    continue
                # hands might be dict keyed by str(player_id) or int
                for key in (self.id, str(self.id)):
                    if key in hands:
                        hand = hands[key]
                        if isinstance(hand, list) and len(hand) == 2:
                            self.hole_cards = hand
                        elif isinstance(hand, str) and len(hand) == 4:
                            # e.g. "AhKd"
                            self.hole_cards = [hand[:2], hand[2:]]
                        return  # stop after first successful fetch

    # ---------- required Bot interface ---------------------------------------
    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int],
    ):
        self.starting_chips = starting_chips
        self.big_blind = blind_amount * 2  # conventionally big blind = 2×SB
        self.small_blind = blind_amount
        # the engine *may* give us our first hand here
        if player_hands and len(player_hands) == 2:
            self.hole_cards = player_hands

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # cards change every hand – always try to refresh
        self._retrieve_hole_cards(round_state)

    # ------------------------- MAIN DECISION METHOD --------------------------
    def get_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:

        # defensive coding: never crash
        try:
            return self._safe_action(round_state, remaining_chips)
        except Exception:
            # on ANY unexpected problem just fold – better than crashing
            return (PokerAction.FOLD, 0)

    # ----------------------- round end / game end ----------------------------
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # clear hand reference – new cards next round
        self.hole_cards = None

    def on_end_game(
        self,
        round_state: RoundStateClient,
        player_score: float,
        all_scores: dict,
        active_players_hands: dict,
    ):
        pass  # no persistent learning yet

    # ========================================================================
    # -------------------- INTERNAL STRATEGY IMPLEMENTATION -------------------
    # ========================================================================
    # ------ pre-flop starting hand chart (very coarse, yet solid) ------------
    _premium_pairs = {"AA", "KK", "QQ", "JJ"}
    _premium_suited = {"AKs", "AQs", "AJs", "KQs"}
    _premium_off = {"AKo", "AQo"}

    _medium_pairs = {"TT", "99", "88", "77"}
    _medium_suited = {"ATs", "KJs", "QJs", "JTs", "T9s"}
    _medium_off = {"KQo", "AJo", "KJo", "QJo"}

    # helper: convert two card strings -> canonical name, e.g. "Ah", "Kd" -> "AKo"
    @staticmethod
    def _canonical(hand: List[str]) -> str:
        ranks = "23456789TJQKA"
        if len(hand) != 2:
            return ""
        r1, s1 = hand[0][0], hand[0][1]
        r2, s2 = hand[1][0], hand[1][1]
        # order by rank value descending
        if ranks.index(r1) < ranks.index(r2):
            r1, r2, s1, s2 = r2, r1, s2, s1
        suited = "s" if s1 == s2 else "o"
        if r1 == r2:
            return f"{r1}{r2}"
        return f"{r1}{r2}{suited}"

    # ------------------------------------------------------------------------
    def _safe_action(
        self, round_state: RoundStateClient, remaining_chips: int
    ) -> Tuple[PokerAction, int]:

        # ensure we know our own current bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise

        stage = (round_state.round or "").lower()  # 'preflop', 'flop', ...
        # make sure we have the newest hole cards
        self._retrieve_hole_cards(round_state)

        if stage == "preflop":
            return self._preflop_decision(
                to_call, min_raise, max_raise, remaining_chips, my_bet
            )
        else:
            return self._postflop_decision(
                round_state,
                to_call,
                min_raise,
                max_raise,
                remaining_chips,
                my_bet,
            )

    # -------------------------- PRE-FLOP LOGIC ------------------------------
    def _preflop_decision(
        self,
        to_call: int,
        min_raise: int,
        max_raise: int,
        remaining_chips: int,
        my_bet: int,
    ) -> Tuple[PokerAction, int]:

        # if we don't know our hand -> super conservative
        if not self.hole_cards or len(self.hole_cards) != 2:
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            return (PokerAction.FOLD, 0)

        hand_name = self._canonical(self.hole_cards)

        # premium hands: raise / re-raise aggressively
        if (
            hand_name in self._premium_pairs
            or hand_name in self._premium_suited
            or hand_name in self._premium_off
        ):
            # raise to 5× BB or shove if short-stacked
            target = min(remaining_chips, max(4 * self.big_blind, to_call + min_raise))
            raise_amt = max(min_raise, target - my_bet)
            if raise_amt >= min_raise and raise_amt <= max_raise:
                return (PokerAction.RAISE, raise_amt)
            # otherwise just call
            return (PokerAction.CALL, 0)

        # medium hands: open if no one has raised yet, otherwise call small bets
        if (
            hand_name in self._medium_pairs
            or hand_name in self._medium_suited
            or hand_name in self._medium_off
        ):
            if to_call == 0:
                # open raise 3× BB
                target = min(remaining_chips, max(3 * self.big_blind, min_raise))
                raise_amt = max(min_raise, target - my_bet)
                if raise_amt >= min_raise and raise_amt <= max_raise:
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            else:
                # call as long as it's not an over-sized raise (>6× BB)
                if to_call <= 6 * self.big_blind:
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)

        # everything else: fold unless we can check
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    # ------------------------- POST-FLOP LOGIC -------------------------------
    def _postflop_decision(
        self,
        round_state: RoundStateClient,
        to_call: int,
        min_raise: int,
        max_raise: int,
        remaining_chips: int,
        my_bet: int,
    ) -> Tuple[PokerAction, int]:

        # if evaluator unavailable OR we don't know cards, play fit-or-fold
        if not (self.evaluator and self.hole_cards):
            if to_call == 0:
                return (PokerAction.CHECK, 0)
            # call small bets up to 15% of our stack, otherwise fold
            if to_call <= 0.15 * remaining_chips:
                return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)

        # Monte-Carlo win-rate estimation
        win_prob = self._estimate_equity(
            self.hole_cards, round_state.community_cards, iterations=250
        )

        pot_size = round_state.pot
        # basic utility metric: expected value of calling
        pot_after_call = pot_size + to_call
        ev_call = win_prob * pot_after_call - to_call

        # aggressive line with very high equity
        if win_prob > 0.75:
            # raise big or shove (but keep it reasonable)
            target = min(remaining_chips, pot_size + int(0.75 * remaining_chips))
            raise_amt = max(min_raise, target - my_bet)
            if raise_amt >= min_raise and raise_amt <= max_raise:
                return (PokerAction.RAISE, raise_amt)
            return (PokerAction.ALL_IN, 0)

        # positive expected value -> call
        if ev_call > 0 and to_call <= remaining_chips:
            if to_call == 0:
                # maybe probe bet ½ pot
                raise_amt = max(min_raise, int(0.5 * pot_size))
                if raise_amt >= min_raise and raise_amt <= max_raise:
                    return (PokerAction.RAISE, raise_amt)
                return (PokerAction.CHECK, 0)
            return (PokerAction.CALL, 0)

        # marginal draws: call very small bets
        if win_prob > 0.25 and to_call <= 0.05 * remaining_chips:
            return (PokerAction.CALL, 0)

        # otherwise fold/check
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        return (PokerAction.FOLD, 0)

    # -------------------- Monte-Carlo equity estimator -----------------------
    def _estimate_equity(
        self, hole_cards: List[str], community_cards: List[str], iterations: int = 200
    ) -> float:
        """
        Returns an approximate probability of our hand winning against
        one random opponent (can be tuned). Uses treys fast evaluator.
        """
        if not self.evaluator:
            return 0.0  # fallback
        try:
            deck = Deck()
            # remove seen cards from deck
            remove_cards = [Card.new(c) for c in hole_cards + community_cards]
            for c in remove_cards:
                deck.cards.remove(c)

            wins = 0
            for _ in range(iterations):
                deck.shuffle()
                opp_hand = deck.draw(2)
                board_needed = 5 - len(community_cards)
                board_drawn = deck.draw(board_needed)
                full_board = [Card.new(c) for c in community_cards] + board_drawn

                our_rank = self.evaluator.evaluate(
                    full_board, [Card.new(c) for c in hole_cards]
                )
                opp_rank = self.evaluator.evaluate(full_board, opp_hand)

                if our_rank < opp_rank:
                    wins += 1
                elif our_rank == opp_rank:
                    wins += 0.5  # split pot

                # return drawn cards
                deck.cards.extend(opp_hand + board_drawn)

            return wins / float(iterations + 1e-9)
        except Exception:
            # any unexpected evaluator failure – fall back to conservative behaviour
            return 0.0