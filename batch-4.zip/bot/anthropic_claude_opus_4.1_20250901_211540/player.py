from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.position = None
        self.blind_amount = 10
        self.game_count = 0
        self.total_hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.blind_amount = blind_amount
        self.game_count += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'SB'
        elif self.id == big_blind_player_id:
            self.position = 'BB'
        else:
            self.position = 'OTHER'
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.total_hands_played += 1
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get basic info
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, current_bet - my_bet)
        
        # Calculate pot odds
        if to_call > 0:
            pot_odds = to_call / (pot + to_call + 0.001)
        else:
            pot_odds = 0
            
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Determine action based on round
        if round_state.round.lower() == 'preflop':
            return self._preflop_action(hand_strength, to_call, pot, remaining_chips, round_state)
        else:
            return self._postflop_action(hand_strength, to_call, pot, pot_odds, remaining_chips, round_state)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0-1 scale)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Preflop hand strength
        if round_state.round.lower() == 'preflop':
            # Pocket pairs
            if rank1 == rank2:
                if rank1 >= 12:  # QQ+
                    return 0.95
                elif rank1 >= 10:  # TT-JJ
                    return 0.85
                elif rank1 >= 8:  # 88-99
                    return 0.75
                elif rank1 >= 5:  # 55-77
                    return 0.65
                else:  # 22-44
                    return 0.55
            
            # High cards
            high_rank = max(rank1, rank2)
            low_rank = min(rank1, rank2)
            suited = (suit1 == suit2)
            gap = high_rank - low_rank
            
            # Ace high
            if high_rank == 14:
                if low_rank >= 11:  # AJ+
                    return 0.85 if suited else 0.80
                elif low_rank >= 9:  # A9-AT
                    return 0.70 if suited else 0.65
                else:
                    return 0.60 if suited else 0.50
            
            # King high
            if high_rank == 13:
                if low_rank >= 11:  # KJ+
                    return 0.75 if suited else 0.70
                elif low_rank >= 9:  # K9-KT
                    return 0.65 if suited else 0.55
                else:
                    return 0.50 if suited else 0.40
            
            # Connected cards
            if gap <= 1:
                if high_rank >= 10:
                    return 0.70 if suited else 0.65
                elif high_rank >= 7:
                    return 0.60 if suited else 0.55
                else:
                    return 0.50 if suited else 0.45
            
            # Suited connectors
            if suited and gap <= 2:
                return 0.55
            
            # Default
            return 0.35
        
        # Postflop - simplified evaluation
        community = round_state.community_cards
        if not community:
            return 0.5
            
        # Check for pairs, flushes, straights (simplified)
        all_cards = self.hole_cards + community
        ranks = [self._parse_card(card)[0] for card in all_cards]
        suits = [self._parse_card(card)[1] for card in all_cards]
        
        # Count matches
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        max_count = max(rank_counts.values())
        
        # Evaluate based on made hands
        if max_count >= 4:
            return 0.98  # Four of a kind
        elif max_count == 3 and len([c for c in rank_counts.values() if c >= 2]) >= 2:
            return 0.92  # Full house
        elif max_count == 3:
            return 0.75  # Three of a kind
        elif len([c for c in rank_counts.values() if c == 2]) >= 2:
            return 0.65  # Two pair
        elif max_count == 2:
            # Check if we have top pair
            my_ranks = [self._parse_card(card)[0] for card in self.hole_cards]
            if any(r in my_ranks for r in [max(ranks)]):
                return 0.60  # Top pair
            return 0.50  # Pair
        
        # High card
        my_high = max([self._parse_card(card)[0] for card in self.hole_cards])
        if my_high == 14:
            return 0.45
        elif my_high >= 12:
            return 0.40
        return 0.30
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit"""
        if len(card) < 2:
            return (2, 's')
        
        rank_char = card[0]
        suit = card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_char, 2)
        return (rank, suit)
    
    def _preflop_action(self, hand_strength: float, to_call: int, pot: int, remaining_chips: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        # If we can check, consider our options
        if to_call == 0:
            if hand_strength >= 0.75:
                # Raise with strong hands
                raise_amount = min(pot * 3, remaining_chips // 2)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            elif hand_strength >= 0.55:
                # Raise smaller with medium hands
                raise_amount = min(pot * 2, remaining_chips // 3)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        call_percentage = to_call / (remaining_chips + 0.001)
        
        # Premium hands - reraise
        if hand_strength >= 0.85:
            if call_percentage < 0.5:
                raise_amount = min(to_call * 3, remaining_chips)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        
        # Good hands - call if reasonable
        if hand_strength >= 0.65:
            if call_percentage < 0.2:
                return (PokerAction.CALL, 0)
            elif call_percentage < 0.4 and hand_strength >= 0.75:
                return (PokerAction.CALL, 0)
        
        # Decent hands - call small bets
        if hand_strength >= 0.50:
            if call_percentage < 0.1:
                return (PokerAction.CALL, 0)
        
        # Fold weak hands
        return (PokerAction.FOLD, 0)
    
    def _postflop_action(self, hand_strength: float, to_call: int, pot: int, pot_odds: float, remaining_chips: int, round_state: RoundStateClient) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        # If we can check
        if to_call == 0:
            if hand_strength >= 0.75:
                # Bet/raise with strong hands
                bet_amount = min(int(pot * 0.75), remaining_chips // 2)
                if bet_amount > round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            elif hand_strength >= 0.60:
                # Bet smaller with medium hands
                bet_amount = min(int(pot * 0.5), remaining_chips // 3)
                if bet_amount > round_state.min_raise:
                    return (PokerAction.RAISE, bet_amount)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        call_percentage = to_call / (remaining_chips + 0.001)
        
        # Very strong hands - raise
        if hand_strength >= 0.85:
            if call_percentage < 0.4:
                raise_amount = min(to_call * 2 + pot // 2, remaining_chips)
                if raise_amount > round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        
        # Good hands - call if pot odds are good
        if hand_strength >= 0.60:
            # Calculate implied odds
            if pot_odds < hand_strength * 0.8:  # Good pot odds
                return (PokerAction.CALL, 0)
            elif call_percentage < 0.15:  # Small bet
                return (PokerAction.CALL, 0)
        
        # Medium hands - call small bets
        if hand_strength >= 0.45:
            if pot_odds < 0.25 and call_percentage < 0.1:
                return (PokerAction.CALL, 0)
        
        # Drawing hands
        if hand_strength >= 0.35:
            if pot_odds < 0.2 and call_percentage < 0.05:
                return (PokerAction.CALL, 0)
        
        # Fold weak hands
        return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass