from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_count = 0
        self.opponent_aggression = {}
        self.position = None
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.hand_count += 1
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 'SB'
        elif self.id == big_blind_player_id:
            self.position = 'BB'
        else:
            self.position = 'BTN'
            
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id and player_id not in self.opponent_aggression:
                self.opponent_aggression[player_id] = {'raises': 0, 'calls': 0, 'folds': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def calculate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Calculate relative hand strength (0-1 scale)"""
        if not hole_cards or len(hole_cards) < 2:
            return 0.0
            
        # Parse cards
        def card_value(card):
            if not card or len(card) < 2:
                return 0
            rank = card[0]
            rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                          '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            return rank_values.get(rank, 0)
        
        def is_suited(cards):
            if len(cards) < 2 or not cards[0] or not cards[1]:
                return False
            return len(cards[0]) > 1 and len(cards[1]) > 1 and cards[0][1] == cards[1][1]
        
        h1_val = card_value(hole_cards[0])
        h2_val = card_value(hole_cards[1])
        
        # Pre-flop strength calculation
        if not community_cards:
            base_strength = 0.0
            
            # Pocket pairs
            if h1_val == h2_val:
                base_strength = 0.5 + (h1_val / 14.0) * 0.4
                if h1_val >= 10:  # High pairs
                    base_strength += 0.15
            else:
                high_card = max(h1_val, h2_val)
                low_card = min(h1_val, h2_val)
                
                # High cards
                if high_card == 14:  # Ace
                    base_strength = 0.35 + (low_card / 14.0) * 0.2
                    if low_card >= 10:  # Broadway cards
                        base_strength += 0.15
                elif high_card == 13:  # King
                    base_strength = 0.30 + (low_card / 14.0) * 0.15
                    if low_card >= 10:
                        base_strength += 0.10
                else:
                    base_strength = 0.15 + (high_card / 14.0) * 0.2 + (low_card / 14.0) * 0.1
                
                # Suited bonus
                if is_suited(hole_cards):
                    base_strength += 0.08
                
                # Connectivity bonus
                gap = high_card - low_card
                if gap == 1:
                    base_strength += 0.06
                elif gap == 2:
                    base_strength += 0.04
                elif gap == 3:
                    base_strength += 0.02
            
            return min(base_strength, 0.95)
        
        # Post-flop evaluation
        all_cards = hole_cards + community_cards
        all_values = [card_value(c) for c in all_cards if c]
        all_suits = [c[1] if c and len(c) > 1 else '' for c in all_cards]
        
        # Count occurrences
        value_counts = {}
        for v in all_values:
            value_counts[v] = value_counts.get(v, 0) + 1
        
        suit_counts = {}
        for s in all_suits:
            if s:
                suit_counts[s] = suit_counts.get(s, 0) + 1
        
        # Check for hands
        pairs = [v for v, c in value_counts.items() if c == 2]
        trips = [v for v, c in value_counts.items() if c == 3]
        quads = [v for v, c in value_counts.items() if c == 4]
        
        # Flush check
        flush_suit = None
        for suit, count in suit_counts.items():
            if count >= 5:
                flush_suit = suit
                break
        
        # Straight check
        unique_values = sorted(set(all_values))
        is_straight = False
        straight_high = 0
        
        # Check for ace-low straight
        if 14 in unique_values and 2 in unique_values:
            low_straight = [14, 2, 3, 4, 5]
            if all(v in unique_values for v in low_straight[1:]):
                is_straight = True
                straight_high = 5
        
        # Check regular straights
        if not is_straight:
            for i in range(len(unique_values) - 4):
                if unique_values[i+4] - unique_values[i] == 4:
                    is_straight = True
                    straight_high = unique_values[i+4]
                    break
        
        # Calculate hand strength
        if quads:
            return 0.95
        elif trips and pairs:  # Full house
            return 0.90
        elif flush_suit:
            return 0.85
        elif is_straight:
            return 0.80
        elif trips:
            trip_value = max(trips)
            return 0.70 + (trip_value / 14.0) * 0.08
        elif len(pairs) >= 2:  # Two pair
            high_pair = max(pairs)
            return 0.60 + (high_pair / 14.0) * 0.08
        elif pairs:  # One pair
            pair_value = max(pairs)
            # Check if we have the pair
            our_pair = pair_value in [h1_val, h2_val]
            if our_pair:
                return 0.45 + (pair_value / 14.0) * 0.12
            else:
                return 0.35 + (pair_value / 14.0) * 0.08
        else:  # High card
            high = max(h1_val, h2_val)
            return 0.15 + (high / 14.0) * 0.20
    
    def calculate_pot_odds(self, pot: int, call_amount: int) -> float:
        """Calculate pot odds"""
        if call_amount <= 0:
            return 1.0
        total_pot = pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Get current situation
        pot = round_state.pot
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = min(round_state.max_raise, remaining_chips)
        
        # Calculate hand strength
        hand_strength = self.calculate_hand_strength(self.hole_cards, round_state.community_cards)
        
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_aggression:
                if 'Raise' in action or 'All' in action:
                    self.opponent_aggression[player_id]['raises'] += 1
                elif 'Call' in action:
                    self.opponent_aggression[player_id]['calls'] += 1
                elif 'Fold' in action:
                    self.opponent_aggression[player_id]['folds'] += 1
        
        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(pot, call_amount)
        
        # Adjust strategy based on round
        round_multiplier = 1.0
        if round_state.round == 'Preflop':
            round_multiplier = 1.2  # More aggressive preflop
        elif round_state.round == 'Flop':
            round_multiplier = 1.0
        elif round_state.round == 'Turn':
            round_multiplier = 0.95
        else:  # River
            round_multiplier = 0.9
        
        # Position-based adjustment
        position_bonus = 0
        if self.position == 'BTN':
            position_bonus = 0.05
        elif self.position == 'SB':
            position_bonus = -0.05
        
        adjusted_strength = hand_strength * round_multiplier + position_bonus
        
        # Decision making
        if call_amount == 0:  # Can check
            if adjusted_strength > 0.65:
                # Strong hand - bet/raise
                bet_size = int(pot * 0.75)
                if bet_size >= min_raise and bet_size <= max_raise:
                    return (PokerAction.RAISE, bet_size)
                elif max_raise > 0:
                    return (PokerAction.RAISE, min_raise)
            elif adjusted_strength > 0.35:
                # Medium hand - sometimes bet
                if random.random() < 0.3:
                    bet_size = int(pot * 0.5)
                    if bet_size >= min_raise and bet_size <= max_raise:
                        return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        
        else:  # Need to call, raise, or fold
            # Calculate if call is profitable
            required_equity = pot_odds
            
            if adjusted_strength > required_equity + 0.15:
                # Strong hand - consider raising
                if adjusted_strength > 0.75 and max_raise > min_raise:
                    # Very strong - raise big
                    raise_size = int(pot * 0.8 + call_amount)
                    if raise_size <= max_raise and raise_size >= min_raise:
                        return (PokerAction.RAISE, raise_size)
                    elif max_raise >= min_raise:
                        return (PokerAction.RAISE, max_raise)
                elif adjusted_strength > 0.60 and max_raise > min_raise:
                    # Good hand - moderate raise
                    raise_size = int(pot * 0.5 + call_amount)
                    if raise_size <= max_raise and raise_size >= min_raise:
                        return (PokerAction.RAISE, raise_size)
                
                # Call if can't raise or don't want to
                if call_amount <= remaining_chips:
                    if call_amount == remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            elif adjusted_strength > required_equity - 0.05:
                # Marginal call
                if call_amount <= remaining_chips:
                    if call_amount == remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    # Sometimes bluff raise
                    if random.random() < 0.1 and max_raise >= min_raise:
                        return (PokerAction.RAISE, min_raise)
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            
            else:
                # Weak hand - usually fold, sometimes bluff
                if random.random() < 0.05 and max_raise >= min_raise and call_amount < pot * 0.3:
                    # Occasional bluff
                    return (PokerAction.RAISE, min_raise)
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        self.hole_cards = []