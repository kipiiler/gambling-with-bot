from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.num_players = 0
        self.position = 0
        self.is_small_blind = False
        self.is_big_blind = False
        self.blind_amount = 0
        self.starting_chips = 0
        self.hand_count = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, 
                  big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.num_players = len(all_players)
        self.blind_amount = blind_amount
        self.starting_chips = starting_chips
        self.is_small_blind = (self.id == small_blind_player_id)
        self.is_big_blind = (self.id == big_blind_player_id)
        self.hand_count += 1
        
        # Determine position (0 = early, 1 = middle, 2 = late)
        if self.num_players == 2:
            self.position = 2 if self.is_small_blind else 0
        else:
            player_index = all_players.index(self.id) if self.id in all_players else 0
            self.position = min(2, player_index * 3 // self.num_players)
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        # Get current betting state
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_bet
        pot_size = round_state.pot
        
        # Calculate hand strength based on round and cards
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Get pot odds
        if call_amount > 0 and pot_size > 0:
            pot_odds = call_amount / (pot_size + call_amount + 0.001)
        else:
            pot_odds = 0
        
        # Decision making based on hand strength and pot odds
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength, call_amount)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength, call_amount, pot_odds)
    
    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength (0.0 to 1.0)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
        
        # Parse hole cards
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # Preflop hand strength
        strength = 0.0
        
        # Pocket pairs
        if rank1 == rank2:
            strength = 0.5 + (rank1 / 14) * 0.3  # Higher pairs are stronger
            if rank1 >= 10:  # TT+
                strength = 0.8 + (rank1 - 10) / 40
        # Suited cards
        elif suit1 == suit2:
            strength = 0.3 + max(rank1, rank2) / 28
            if abs(rank1 - rank2) <= 2:  # Connected suited
                strength += 0.1
        # High cards
        else:
            high_card = max(rank1, rank2)
            low_card = min(rank1, rank2)
            strength = 0.2 + high_card / 28
            if high_card >= 11 and low_card >= 9:  # Broadway cards
                strength = 0.5
            elif abs(rank1 - rank2) == 1:  # Connected
                strength += 0.05
        
        # Adjust for position
        if self.position == 2:  # Late position
            strength += 0.1
        elif self.position == 0:  # Early position
            strength -= 0.05
        
        # Postflop adjustments
        if round_state.round != 'Preflop' and round_state.community_cards:
            community_strength = self._evaluate_community_cards(round_state.community_cards)
            strength = (strength + community_strength) / 2
        
        return min(1.0, max(0.0, strength))
    
    def _evaluate_community_cards(self, community_cards: List[str]) -> float:
        """Evaluate strength with community cards"""
        if not community_cards:
            return 0.5
        
        all_cards = self.hole_cards + community_cards
        
        # Check for pairs, flushes, straights (simplified)
        ranks = [self._parse_card(card)[0] for card in all_cards]
        suits = [self._parse_card(card)[1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        # Check for pairs, trips, etc.
        max_count = max(rank_counts.values())
        if max_count >= 4:
            return 0.95  # Four of a kind
        elif max_count == 3:
            if len([c for c in rank_counts.values() if c >= 2]) >= 2:
                return 0.85  # Full house
            return 0.65  # Three of a kind
        elif max_count == 2:
            pairs = [r for r, c in rank_counts.items() if c == 2]
            if len(pairs) >= 2:
                return 0.55  # Two pair
            elif pairs and max(pairs) >= 11:
                return 0.5  # High pair
            else:
                return 0.4  # Low pair
        
        # Check for flush draw
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        if max(suit_counts.values()) >= 4:
            return 0.6  # Flush draw
        
        return 0.3  # High card
    
    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string to rank and suit"""
        if not card or len(card) < 2:
            return (2, 's')
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                    '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map.get(card[0], 2)
        suit = card[1] if len(card) > 1 else 's'
        return (rank, suit)
    
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, 
                          hand_strength: float, call_amount: int) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        my_bet = round_state.player_bets.get(str(self.id), 0)
        
        # If we can check, consider checking with medium hands
        if call_amount == 0:
            if hand_strength > 0.7:
                # Strong hand - raise
                raise_amount = min(3 * self.blind_amount, remaining_chips // 3)
                if raise_amount > round_state.current_bet:
                    return (PokerAction.RAISE, raise_amount)
            elif hand_strength > 0.4:
                # Medium hand - sometimes raise, sometimes check
                if self.position == 2:  # Late position
                    raise_amount = min(2 * self.blind_amount, remaining_chips // 4)
                    if raise_amount > round_state.current_bet:
                        return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if hand_strength > 0.75:
            # Very strong hand - raise or call
            if remaining_chips > call_amount * 3:
                raise_amount = min(round_state.current_bet * 2, remaining_chips // 2)
                if raise_amount > round_state.current_bet + round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        elif hand_strength > 0.5:
            # Good hand - call if pot odds are reasonable
            if call_amount <= remaining_chips // 10 or call_amount <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.35 and self.is_big_blind and call_amount <= self.blind_amount:
            # Defend big blind with decent hands
            return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int,
                          hand_strength: float, call_amount: int, pot_odds: float) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        # If we can check
        if call_amount == 0:
            if hand_strength > 0.7:
                # Strong hand - bet for value
                bet_size = min(round_state.pot // 2, remaining_chips // 3)
                if bet_size > round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            elif hand_strength > 0.5 and self.position == 2:
                # Medium hand in position - sometimes bet
                bet_size = min(round_state.pot // 3, remaining_chips // 4)
                if bet_size > round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        
        # Facing a bet
        if hand_strength > 0.8:
            # Very strong hand - raise for value
            if remaining_chips > call_amount * 2:
                raise_amount = min(round_state.current_bet + round_state.pot // 2, remaining_chips // 2)
                if raise_amount > round_state.current_bet + round_state.min_raise:
                    return (PokerAction.RAISE, raise_amount)
            return (PokerAction.CALL, 0)
        elif hand_strength > 0.6:
            # Good hand - call if pot odds are favorable
            if pot_odds < hand_strength - 0.1:
                return (PokerAction.CALL, 0)
        elif hand_strength > 0.4:
            # Drawing hand - call if pot odds are good
            if pot_odds < 0.25 and call_amount < remaining_chips // 5:
                return (PokerAction.CALL, 0)
        
        return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of each round."""
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, 
                     all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Reset for next game
        self.hole_cards = []