from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.hand_strength_cache = {}
        self.opponent_stats = {}
        self.hands_played = 0
        self.position = 0
        self.num_players = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.num_players = len(all_players)
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[str(player_id)] = {
                    'vpip': 0,  # Voluntarily put money in pot
                    'pfr': 0,   # Pre-flop raise
                    'agg': 0,   # Aggression factor
                    'hands': 0,
                    'folds': 0,
                    'raises': 0,
                    'calls': 0
                }
        
        # Determine position
        if self.id == small_blind_player_id:
            self.position = 0
        elif self.id == big_blind_player_id:
            self.position = 1
        else:
            self.position = all_players.index(self.id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        self.hand_strength_cache = {}
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Calculate pot odds
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        
        # Get position-aware strategy
        return self._get_strategy_action(round_state, remaining_chips, hand_strength, pot_odds)
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                if action == 'Fold':
                    stats['folds'] += 1
                elif action == 'Raise' or action == 'All-in':
                    stats['raises'] += 1
                elif action == 'Call':
                    stats['calls'] += 1
                    
    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        # Simple hand strength estimation based on cards and round
        if round_state.round == 'Preflop':
            return self._preflop_strength()
        else:
            return self._postflop_strength(round_state.community_cards)
    
    def _preflop_strength(self) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, rank2 = self._card_rank(card1), self._card_rank(card2)
        suited = card1[-1] == card2[-1]
        
        # Premium hands
        if (rank1 >= 12 and rank2 >= 12):  # AA, KK, QQ, AK
            return 0.95
        elif (rank1 >= 11 and rank2 >= 11):  # JJ, AQ, AJ
            return 0.85
        elif (rank1 >= 10 and rank2 >= 10):  # TT, KQ
            return 0.75
        elif (rank1 >= 9 and rank2 >= 9):  # 99, QJ, KJ
            return 0.65
        elif suited and abs(rank1 - rank2) <= 1:  # Suited connectors
            return 0.60
        elif rank1 >= 8 or rank2 >= 8:  # Medium pairs and Ax
            return 0.50
        else:
            return 0.35
    
    def _postflop_strength(self, community_cards: List[str]) -> float:
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.3
            
        all_cards = self.hole_cards + community_cards
        
        # Check for made hands
        ranks = [self._card_rank(card) for card in all_cards]
        suits = [card[-1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for pairs, trips, etc.
        max_count = max(rank_counts.values()) if rank_counts else 0
        
        # Flush check
        has_flush = any(count >= 5 for count in suit_counts.values())
        flush_draw = any(count == 4 for count in suit_counts.values())
        
        # Straight check (simplified)
        sorted_ranks = sorted(set(ranks))
        has_straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                has_straight = True
                break
        
        if has_flush and has_straight:
            return 1.0
        elif max_count == 4:
            return 0.98
        elif max_count == 3 and len(rank_counts) <= 3:
            return 0.95
        elif has_flush:
            return 0.93
        elif has_straight:
            return 0.90
        elif max_count == 3:
            return 0.85
        elif max_count == 2:
            pairs = sum(1 for count in rank_counts.values() if count == 2)
            if pairs >= 2:
                return 0.75
            else:
                return 0.60
        elif flush_draw:
            return 0.50
        else:
            return 0.35
    
    def _card_rank(self, card: str) -> int:
        if len(card) < 2:
            return 0
        rank = card[:-1]
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, 
                      '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(rank, 0)
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        if round_state.current_bet == 0:
            return 1.0
            
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 1.0
        if call_amount >= remaining_chips:
            call_amount = remaining_chips
            
        total_pot = round_state.pot + call_amount
        return call_amount / (total_pot + 0.001)
    
    def _get_strategy_action(self, round_state: RoundStateClient, remaining_chips: int, 
                            hand_strength: float, pot_odds: float) -> Tuple[PokerAction, int]:
        
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        # Stack size considerations
        stack_to_pot_ratio = remaining_chips / (round_state.pot + 0.001)
        is_short_stack = remaining_chips < self.starting_chips * 0.3
        
        # Adjust aggression based on position and stack size
        position_multiplier = 1.0 + (self.position / (self.num_players + 0.001)) * 0.3
        
        # Decision logic
        if call_amount <= 0:  # Can check
            if hand_strength > 0.75:
                # Strong hand - raise for value
                if stack_to_pot_ratio > 2:
                    raise_amount = int(round_state.pot * 0.75)
                else:
                    raise_amount = int(round_state.pot * 0.5)
                    
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif remaining_chips > round_state.pot * 1.5:
                    return (PokerAction.RAISE, round_state.min_raise)
                else:
                    return (PokerAction.CHECK, 0)
            elif hand_strength > 0.55:
                # Medium hand - sometimes bet
                if random.random() < 0.4 * position_multiplier:
                    bet_size = int(round_state.pot * 0.5)
                    if bet_size >= round_state.min_raise and bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:  # Need to call, raise, or fold
            # Calculate expected value
            win_probability = hand_strength * (1.0 + position_multiplier * 0.1)
            
            # Adjust for opponent tendencies if we have data
            active_opponents = len([p for p in round_state.current_player if p != self.id])
            if active_opponents > 0:
                win_probability = win_probability ** (active_opponents * 0.8)
            
            ev_call = win_probability - pot_odds
            
            if is_short_stack and hand_strength > 0.65:
                # Short stack - more willing to go all-in with decent hands
                return (PokerAction.ALL_IN, 0)
            
            if ev_call > 0.15 and hand_strength > 0.8:
                # Very strong hand - raise
                if round_state.round == 'River':
                    # Value bet on river
                    raise_amount = int(round_state.pot * 0.75)
                else:
                    raise_amount = int(round_state.current_bet * 2.5)
                
                if raise_amount >= round_state.min_raise and raise_amount <= remaining_chips:
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount < remaining_chips:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.ALL_IN, 0)
                    
            elif ev_call > 0.05 or (pot_odds < 0.3 and hand_strength > 0.5):
                # Positive EV or good pot odds - call
                if call_amount < remaining_chips:
                    return (PokerAction.CALL, 0)
                elif hand_strength > 0.7:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                # Negative EV - fold
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Could track additional statistics here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hand_strength_cache = {}
        self.hands_played = 0