from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.starting_chips = 0
        self.blind_amount = 0
        self.game_count = 0
        self.opponent_fold_rate = {}
        self.opponent_aggression = {}
        self.last_round_actions = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.game_count += 1
        
        # Initialize opponent tracking
        for player_id in all_players:
            if player_id != self.id:
                if player_id not in self.opponent_fold_rate:
                    self.opponent_fold_rate[player_id] = 0.5
                    self.opponent_aggression[player_id] = 0.5
                    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.last_round_actions = {}
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        
        # Track opponent actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                self.last_round_actions[player_id] = action
                
        # Calculate pot odds
        pot = round_state.pot
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot_odds = to_call / (pot + to_call + 0.001)
        
        # Calculate hand strength
        hand_strength = self._calculate_hand_strength(round_state)
        
        # Position awareness
        is_last_to_act = self._is_last_to_act(round_state)
        position_bonus = 0.1 if is_last_to_act else 0
        
        # Adjust strategy based on stack size
        stack_to_pot_ratio = remaining_chips / (pot + 0.001)
        
        # Decision making with more aggression
        if round_state.round == 'Preflop':
            return self._preflop_strategy(round_state, remaining_chips, hand_strength + position_bonus)
        else:
            return self._postflop_strategy(round_state, remaining_chips, hand_strength + position_bonus, pot_odds, stack_to_pot_ratio)
            
    def _preflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        
        # Premium hands - always raise/reraise
        if hand_strength > 0.85:
            if round_state.current_bet == 0:
                raise_amount = min(int(pot * 3), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.3:
                raise_amount = min(int(to_call * 3 + pot * 0.5), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
                
        # Strong hands - raise or call
        elif hand_strength > 0.65:
            if round_state.current_bet == 0:
                raise_amount = min(int(pot * 2.5), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif to_call < remaining_chips * 0.25:
                if random.random() < 0.4:  # Sometimes reraise
                    raise_amount = min(int(to_call * 2.5), remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Playable hands
        elif hand_strength > 0.45:
            if round_state.current_bet == 0:
                if random.random() < 0.3:  # Sometimes raise as bluff
                    raise_amount = min(int(pot * 2), remaining_chips)
                    return (PokerAction.RAISE, raise_amount)
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount * 2:
                return (PokerAction.CALL, 0)
            elif to_call < remaining_chips * 0.15:
                if random.random() < 0.2:  # Occasionally call
                    return (PokerAction.CALL, 0)
                return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands - fold or check
        else:
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif to_call <= self.blind_amount and random.random() < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def _postflop_strategy(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, pot_odds: float, spr: float) -> Tuple[PokerAction, int]:
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = max(0, round_state.current_bet - my_bet)
        pot = round_state.pot
        
        # Adjust aggression based on board texture
        board_danger = self._evaluate_board_danger(round_state.community_cards)
        adjusted_strength = hand_strength - board_danger * 0.1
        
        # Very strong hands - maximize value
        if adjusted_strength > 0.8:
            if round_state.current_bet == 0:
                bet_amount = min(int(pot * 0.75), remaining_chips)
                return (PokerAction.RAISE, bet_amount)
            elif to_call < remaining_chips * 0.5:
                raise_amount = min(int(to_call * 2 + pot * 0.5), remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            else:
                return (PokerAction.ALL_IN, 0)
                
        # Strong hands
        elif adjusted_strength > 0.6:
            if round_state.current_bet == 0:
                if random.random() < 0.7:
                    bet_amount = min(int(pot * 0.6), remaining_chips)
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < adjusted_strength - 0.1:
                if to_call < remaining_chips * 0.3:
                    if random.random() < 0.3:
                        raise_amount = min(int(to_call * 2), remaining_chips)
                        return (PokerAction.RAISE, raise_amount)
                    return (PokerAction.CALL, 0)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Medium hands
        elif adjusted_strength > 0.4:
            if round_state.current_bet == 0:
                if random.random() < 0.25:  # Bluff occasionally
                    bet_amount = min(int(pot * 0.5), remaining_chips)
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            elif pot_odds < adjusted_strength:
                if to_call < remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
            return (PokerAction.FOLD, 0)
            
        # Weak hands - bluff or fold
        else:
            if round_state.current_bet == 0:
                if random.random() < 0.15:  # Pure bluff
                    bet_amount = min(int(pot * 0.4), remaining_chips)
                    return (PokerAction.RAISE, bet_amount)
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
                
    def _calculate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Calculate hand strength based on hole cards and community cards."""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.5
            
        card1 = self.hole_cards[0]
        card2 = self.hole_cards[1]
        
        rank1 = self._card_rank(card1)
        rank2 = self._card_rank(card2)
        suited = card1[1] == card2[1]
        
        if round_state.round == 'Preflop':
            # Preflop hand strength calculation
            strength = 0.0
            
            # Pocket pairs
            if rank1 == rank2:
                strength = 0.5 + (rank1 / 14) * 0.4
                if rank1 >= 12:  # QQ+
                    strength = 0.9
                elif rank1 >= 10:  # TT-JJ
                    strength = 0.75
                elif rank1 >= 8:  # 88-99
                    strength = 0.65
                    
            # High cards
            else:
                high_rank = max(rank1, rank2)
                low_rank = min(rank1, rank2)
                gap = high_rank - low_rank
                
                # Ace high
                if high_rank == 14:
                    if low_rank >= 10:  # AK, AQ, AJ, AT
                        strength = 0.7 + (low_rank / 14) * 0.1
                    else:
                        strength = 0.45 + (low_rank / 14) * 0.05
                        
                # King high
                elif high_rank == 13:
                    if low_rank >= 10:
                        strength = 0.6
                    else:
                        strength = 0.4 + (low_rank / 14) * 0.05
                        
                # Other high cards
                elif high_rank >= 10:
                    strength = 0.35 + (high_rank / 14) * 0.1
                    
                # Connectors
                if gap == 1:
                    strength += 0.05
                elif gap == 2:
                    strength += 0.03
                    
                # Suited bonus
                if suited:
                    strength += 0.08
                    
            return min(1.0, strength)
            
        else:
            # Postflop hand evaluation
            return self._evaluate_postflop_hand(self.hole_cards, round_state.community_cards)
            
    def _evaluate_postflop_hand(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength postflop."""
        all_cards = hole_cards + community_cards
        
        # Check for made hands
        ranks = [self._card_rank(card) for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for pairs, sets, etc.
        max_count = max(rank_counts.values())
        
        # Four of a kind
        if max_count == 4:
            return 0.95
            
        # Full house or three of a kind
        if max_count == 3:
            if len([count for count in rank_counts.values() if count >= 2]) >= 2:
                return 0.9  # Full house
            return 0.7  # Three of a kind
            
        # Flush
        if max(suit_counts.values()) >= 5:
            return 0.85
            
        # Straight
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                return 0.75
                
        # Two pair
        pairs = [rank for rank, count in rank_counts.items() if count == 2]
        if len(pairs) >= 2:
            return 0.6
            
        # One pair
        if len(pairs) == 1:
            pair_rank = pairs[0]
            return 0.4 + (pair_rank / 14) * 0.15
            
        # High card
        high_card = max(self._card_rank(card) for card in hole_cards)
        return 0.2 + (high_card / 14) * 0.15
        
    def _card_rank(self, card: str) -> int:
        """Convert card rank to numerical value."""
        rank = card[0]
        if rank == 'A':
            return 14
        elif rank == 'K':
            return 13
        elif rank == 'Q':
            return 12
        elif rank == 'J':
            return 11
        elif rank == 'T':
            return 10
        else:
            return int(rank)
            
    def _is_last_to_act(self, round_state: RoundStateClient) -> bool:
        """Check if we're last to act."""
        active_players = len([p for p in round_state.player_actions.values() if p != 'Fold'])
        return active_players <= 1
        
    def _evaluate_board_danger(self, community_cards: List[str]) -> float:
        """Evaluate how dangerous the board is."""
        if not community_cards:
            return 0.0
            
        danger = 0.0
        
        # Check for flush draws
        suits = [card[1] for card in community_cards]
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        if max(suit_counts.values()) >= 3:
            danger += 0.3
            
        # Check for straight draws
        ranks = sorted([self._card_rank(card) for card in community_cards])
        for i in range(len(ranks) - 2):
            if ranks[i+2] - ranks[i] <= 4:
                danger += 0.2
                break
                
        # Paired board
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        if max(rank_counts.values()) >= 2:
            danger += 0.2
            
        return min(1.0, danger)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        # Update opponent statistics
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                player_id_int = int(player_id)
                if action == 'Fold':
                    self.opponent_fold_rate[player_id_int] = self.opponent_fold_rate.get(player_id_int, 0.5) * 0.9 + 0.1
                elif action in ['Raise', 'All-in']:
                    self.opponent_aggression[player_id_int] = self.opponent_aggression.get(player_id_int, 0.5) * 0.9 + 0.1
                    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        pass