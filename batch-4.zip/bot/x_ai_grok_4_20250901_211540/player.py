from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from collections import Counter
from itertools import combinations

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.big_blind = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        my_id_str = str(self.id)
        my_bet = round_state.player_bets.get(my_id_str, 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = amount_to_call == 0
        pot = round_state.pot

        if remaining_chips <= 0:
            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        if len(round_state.community_cards) == 0:
            strength = self.get_preflop_strength()
        else:
            best_score = self.get_best_hand(round_state.community_cards)
            strength = self.get_strength_from_score(best_score)

        pot_odds = amount_to_call / (pot + amount_to_call + 1e-6) if amount_to_call > 0 else 0.0

        # Adjust thresholds based on number of active players
        num_active = len(round_state.current_player)
        strong_threshold = 0.7 - (num_active - 2) * 0.05
        medium_threshold = 0.3 - (num_active - 2) * 0.05

        if strength > strong_threshold:
            if amount_to_call > remaining_chips:
                return (PokerAction.FOLD, 0)
            desired_raise_to = 3 * round_state.current_bet if round_state.current_bet > 0 else 3 * self.big_blind
            raise_by = desired_raise_to - my_bet
            raise_by = max(raise_by, round_state.min_raise)
            raise_by = min(raise_by, round_state.max_raise)
            if raise_by <= remaining_chips:
                return (PokerAction.RAISE, raise_by)
            elif remaining_chips >= round_state.min_raise:
                return (PokerAction.ALL_IN, 0)
            elif can_check:
                return (PokerAction.CHECK, 0)
            elif amount_to_call <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        elif strength > medium_threshold and (can_check or pot_odds < 0.3):
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                if amount_to_call <= remaining_chips:
                    return (PokerAction.CALL, 0)
                elif remaining_chips > 0 and strength > pot_odds:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.FOLD, 0)
        else:
            if can_check:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass

    def rank_value(self, r: str) -> int:
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return ranks.get(r, 0)

    def parse_cards(self, cards: List[str]) -> List[Tuple[int, str]]:
        return [(self.rank_value(c[0]), c[1]) for c in cards if len(c) == 2]

    def get_hand_type(self, cards: List[Tuple[int, str]]) -> Tuple[int, List[int]]:
        if len(cards) != 5:
            return (0, [])
        sorted_cards = sorted(cards, key=lambda x: x[0], reverse=True)
        ranks = [c[0] for c in sorted_cards]
        suits = [c[1] for c in sorted_cards]
        is_flush = all(s == suits[0] for s in suits)
        is_straight = all(ranks[i] - 1 == ranks[i + 1] for i in range(4))
        if set(ranks) == {14, 5, 4, 3, 2}:
            is_straight = True
            ranks = [5, 4, 3, 2, 1]
        if is_straight and is_flush:
            return (8, [ranks[0]])  # straight flush
        if is_flush:
            return (5, ranks)  # flush
        if is_straight:
            return (4, [ranks[0]])  # straight
        rank_count = Counter(ranks)
        counts = list(rank_count.values())
        if 4 in counts:
            quad_rank = next(r for r, c in rank_count.items() if c == 4)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return (7, [quad_rank, kicker])  # four of a kind
        if 3 in counts and 2 in counts:
            three_rank = next(r for r, c in rank_count.items() if c == 3)
            pair_rank = next(r for r, c in rank_count.items() if c == 2)
            return (6, [three_rank, pair_rank])  # full house
        if 3 in counts:
            three_rank = next(r for r, c in rank_count.items() if c == 3)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return (3, [three_rank] + kickers)  # three of a kind
        if counts.count(2) == 2:
            pair_ranks = sorted([r for r, c in rank_count.items() if c == 2], reverse=True)
            kicker = next(r for r, c in rank_count.items() if c == 1)
            return (2, pair_ranks + [kicker])  # two pair
        if 2 in counts:
            pair_rank = next(r for r, c in rank_count.items() if c == 2)
            kickers = sorted([r for r, c in rank_count.items() if c == 1], reverse=True)
            return (1, [pair_rank] + kickers)  # pair
        return (0, ranks)  # high card

    def get_best_hand(self, community: List[str]) -> Tuple[int, List[int]]:
        all_parsed = self.parse_cards(self.hole_cards + community)
        n = len(all_parsed)
        if n < 5:
            ranks = sorted([c[0] for c in all_parsed], reverse=True)
            return (0, ranks)
        best = (0, [])
        for comb in combinations(all_parsed, 5):
            score = self.get_hand_type(list(comb))
            if score > best:
                best = score
        return best

    def get_strength_from_score(self, score: Tuple[int, List[int]]) -> float:
        hand_type = score[0]
        return hand_type / 8.0

    def get_preflop_strength(self) -> float:
        if not self.hole_cards or len(self.hole_cards) != 2:
            return 0.0
        card1, card2 = self.hole_cards
        r1 = self.rank_value(card1[0])
        r2 = self.rank_value(card2[0])
        if r1 < r2:
            r1, r2 = r2, r1
        suited = card1[1] == card2[1]
        if r1 == r2:
            return 0.8 + (r1 / 14.0) * 0.2  # pairs
        elif suited:
            if r1 == 14:
                return 0.6 + (r2 / 14.0) * 0.1
            elif abs(r1 - r2) <= 2 and r1 >= 10:
                return 0.55
            else:
                return 0.4
        else:
            if r1 >= 12 and r2 >= 10:
                return 0.5
            else:
                return 0.2