from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.opponent_aggression = 0.5  # Track opponent aggression
        self.game_count = 0
        self.hands_played = 0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.game_count += 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_chips = remaining_chips
        self.hands_played += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Get hand strength
            hand_strength = self._evaluate_hand_strength()
            
            # Get position info
            is_big_blind = str(self.id) == str(self.big_blind_player)
            is_small_blind = str(self.id) == str(self.small_blind_player)
            
            # Calculate pot odds and bet sizing
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            pot_size = round_state.pot
            
            # Update opponent aggression tracking
            self._update_opponent_aggression(round_state)
            
            # Strategy based on street and hand strength
            if round_state.round == "Preflop":
                return self._preflop_strategy(round_state, hand_strength, call_amount, remaining_chips)
            else:
                return self._postflop_strategy(round_state, hand_strength, call_amount, pot_size, remaining_chips)
                
        except Exception as e:
            # Emergency fallback - always return valid action
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if len(self.hole_cards) != 2:
            return 0.3
            
        card1, card2 = self.hole_cards
        
        # Parse cards
        rank1, suit1 = self._parse_card(card1)
        rank2, suit2 = self._parse_card(card2)
        
        # High pairs
        if rank1 == rank2:
            if rank1 >= 10:  # JJ, QQ, KK, AA
                return 0.9
            elif rank1 >= 7:  # 77-TT
                return 0.7
            else:  # 22-66
                return 0.5
                
        # Suited connectors and high cards
        is_suited = suit1 == suit2
        is_connector = abs(rank1 - rank2) == 1
        high_card = max(rank1, rank2)
        
        # High cards (A, K, Q)
        if high_card >= 12:  # Ace or King
            if min(rank1, rank2) >= 10:  # AK, AQ, AJ, KQ, KJ
                return 0.8 if is_suited else 0.6
            elif min(rank1, rank2) >= 7:  # A7+, K7+
                return 0.6 if is_suited else 0.4
            else:
                return 0.4 if is_suited else 0.2
                
        # Suited connectors
        if is_suited and is_connector and min(rank1, rank2) >= 5:
            return 0.6
            
        # Other suited cards
        if is_suited and high_card >= 9:
            return 0.4
            
        # Broadway cards
        if min(rank1, rank2) >= 9:
            return 0.3
            
        return 0.1

    def _parse_card(self, card: str) -> Tuple[int, str]:
        """Parse card string into rank and suit"""
        if len(card) != 2:
            return (2, 'h')  # Default fallback
            
        rank_str, suit = card[0], card[1]
        
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                   '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        rank = rank_map.get(rank_str, 2)
        return (rank, suit)

    def _preflop_strategy(self, round_state: RoundStateClient, hand_strength: float, 
                         call_amount: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Preflop strategy"""
        
        # Premium hands - always play aggressively
        if hand_strength >= 0.8:
            if call_amount == 0:
                # Bet for value
                bet_size = max(round_state.min_raise, self.blind_amount * 3)
                if bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 3:
                # Raise for value
                raise_size = max(round_state.min_raise, call_amount * 3)
                total_bet = round_state.player_bets.get(str(self.id), 0) + raise_size
                if total_bet <= remaining_chips:
                    return (PokerAction.RAISE, raise_size)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.CALL, 0)
                
        # Strong hands
        elif hand_strength >= 0.6:
            if call_amount == 0:
                if self.opponent_aggression > 0.6:
                    return (PokerAction.CHECK, 0)  # Trap aggressive opponent
                else:
                    bet_size = max(round_state.min_raise, self.blind_amount * 2)
                    if bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips // 4:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Marginal hands
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= self.blind_amount and call_amount <= remaining_chips // 8:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _postflop_strategy(self, round_state: RoundStateClient, hand_strength: float, 
                          call_amount: int, pot_size: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Postflop strategy"""
        
        # Calculate pot odds
        if call_amount > 0 and pot_size > 0:
            pot_odds = call_amount / (pot_size + call_amount + 0.001)  # Add small epsilon
        else:
            pot_odds = 0
            
        # Very strong hands - bet for value
        if hand_strength >= 0.8:
            if call_amount == 0:
                bet_size = max(round_state.min_raise, pot_size // 2)
                if bet_size <= remaining_chips:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CALL, 0)
                
        # Strong hands
        elif hand_strength >= 0.6:
            if call_amount == 0:
                if round_state.round == "River":
                    bet_size = max(round_state.min_raise, pot_size // 3)
                    if bet_size <= remaining_chips:
                        return (PokerAction.RAISE, bet_size)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.CHECK, 0)
            elif pot_odds < 0.3:  # Good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Drawing hands
        elif hand_strength >= 0.4:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.25:  # Very good pot odds
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _update_opponent_aggression(self, round_state: RoundStateClient):
        """Track opponent aggression level"""
        # Look for opponent's actions
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id):
                if action in ['Raise', 'All-in']:
                    self.opponent_aggression = min(1.0, self.opponent_aggression + 0.1)
                elif action in ['Check', 'Call']:
                    self.opponent_aggression = max(0.0, self.opponent_aggression - 0.05)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # Learn from results
        if player_score > 0:
            self.opponent_aggression = max(0.0, self.opponent_aggression - 0.1)
        else:
            self.opponent_aggression = min(1.0, self.opponent_aggression + 0.05)