from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.position = 0
        self.opponents = []
        self.big_blind = 0
        self.game_history = []
        self.opponent_tendencies = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.big_blind = blind_amount * 2
        self.opponents = [p for p in all_players if p != self.id]
        self.position = 1 if self.id == small_blind_player_id else (2 if self.id == big_blind_player_id else 0)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(round_state)
            
            # Get pot odds and position info
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            position_advantage = self._get_position_advantage(round_state)
            
            # Determine aggression level based on multiple factors
            aggression = self._calculate_aggression(hand_strength, pot_odds, position_advantage, round_state, remaining_chips)
            
            # Choose action based on aggression and game state
            return self._choose_action(round_state, remaining_chips, aggression, hand_strength)
            
        except Exception:
            # Safe fallback
            if round_state.current_bet == 0:
                return (PokerAction.CHECK, 0)
            elif round_state.current_bet <= remaining_chips:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0.0 (worst) to 1.0 (best)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        card1, card2 = self.hole_cards[0], self.hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        high_card, low_card = max(val1, val2), min(val1, val2)
        
        # Base preflop hand strength
        strength = 0.0
        
        # Pocket pairs
        if val1 == val2:
            if val1 >= 10:  # TT+
                strength = 0.85 + (val1 - 10) * 0.03
            elif val1 >= 7:  # 77-99
                strength = 0.65 + (val1 - 7) * 0.06
            else:  # 22-66
                strength = 0.45 + (val1 - 2) * 0.04
        else:
            # Non-pairs
            suited_bonus = 0.05 if suit1 == suit2 else 0.0
            
            # High cards
            if high_card >= 13:  # A or K high
                if low_card >= 10:
                    strength = 0.75 + suited_bonus
                elif low_card >= 7:
                    strength = 0.55 + suited_bonus
                else:
                    strength = 0.35 + suited_bonus
            elif high_card >= 11:  # Q or J high
                if low_card >= 9:
                    strength = 0.6 + suited_bonus
                elif low_card >= 7:
                    strength = 0.45 + suited_bonus
                else:
                    strength = 0.25 + suited_bonus
            elif high_card >= 9:  # T or 9 high
                if low_card >= 8:
                    strength = 0.4 + suited_bonus
                else:
                    strength = 0.2 + suited_bonus
            else:
                strength = 0.15 + suited_bonus
            
            # Straight potential
            if abs(val1 - val2) <= 4 and min(val1, val2) >= 5:
                strength += 0.05
                
        # Post-flop adjustments
        if round_state.community_cards:
            strength = self._adjust_for_board(strength, round_state.community_cards)
            
        return min(1.0, max(0.0, strength))

    def _adjust_for_board(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        if not community_cards or len(self.hole_cards) < 2:
            return base_strength
            
        # Simple board texture analysis
        all_cards = self.hole_cards + community_cards
        hand_strength = self._get_best_hand_rank(all_cards)
        
        # Convert hand rank to strength value
        if hand_strength >= 8:  # Straight or better
            return 0.95
        elif hand_strength == 7:  # Three of a kind
            return 0.85
        elif hand_strength == 6:  # Two pair
            return 0.75
        elif hand_strength == 5:  # One pair
            return 0.55
        else:  # High card
            return max(0.25, base_strength * 0.8)

    def _get_best_hand_rank(self, cards: List[str]) -> int:
        """Get best 5-card hand rank from available cards"""
        if len(cards) < 5:
            return 0
            
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        ranks = [rank_values.get(card[0], 2) for card in cards]
        suits = [card[1] for card in cards]
        
        rank_counts = {}
        suit_counts = {}
        
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
            
        # Check for flush
        has_flush = any(count >= 5 for count in suit_counts.values())
        
        # Check for straight
        unique_ranks = sorted(set(ranks))
        has_straight = False
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                has_straight = True
                break
                
        # Hand rankings
        counts = sorted(rank_counts.values(), reverse=True)
        
        if has_straight and has_flush:
            return 9  # Straight flush
        elif counts[0] == 4:
            return 8  # Four of a kind
        elif counts[0] == 3 and counts[1] == 2:
            return 7  # Full house
        elif has_flush:
            return 6  # Flush
        elif has_straight:
            return 5  # Straight
        elif counts[0] == 3:
            return 4  # Three of a kind
        elif counts[0] == 2 and counts[1] == 2:
            return 3  # Two pair
        elif counts[0] == 2:
            return 2  # One pair
        else:
            return 1  # High card

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        if call_amount == 0:
            return float('inf')
        total_pot = round_state.pot + call_amount
        return total_pot / (call_amount + 0.001)  # Avoid division by zero

    def _get_position_advantage(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage"""
        active_players = len(round_state.current_player)
        if active_players <= 2:
            return 0.5  # Heads up
        # Better position = higher value
        return 0.3 if self.position == 1 else (0.7 if self.position == 0 else 0.5)

    def _calculate_aggression(self, hand_strength: float, pot_odds: float, position: float, 
                            round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate overall aggression level"""
        base_aggression = hand_strength
        
        # Adjust for pot odds
        if pot_odds > 3.0:
            base_aggression += 0.1
        elif pot_odds < 2.0:
            base_aggression -= 0.1
            
        # Adjust for position
        base_aggression += (position - 0.5) * 0.2
        
        # Adjust for betting round
        if round_state.round == 'Preflop':
            base_aggression *= 1.1  # Be more aggressive preflop
        elif round_state.round == 'River':
            base_aggression *= 1.2  # Be more decisive on river
            
        # Stack size considerations
        stack_ratio = remaining_chips / 10000.0
        if stack_ratio < 0.2:  # Short stack - be more aggressive
            base_aggression += 0.15
        elif stack_ratio > 0.8:  # Deep stack - can afford to be selective
            base_aggression -= 0.05
            
        return max(0.0, min(1.0, base_aggression))

    def _choose_action(self, round_state: RoundStateClient, remaining_chips: int, 
                      aggression: float, hand_strength: float) -> Tuple[PokerAction, int]:
        """Choose action based on calculated aggression and game state"""
        
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # If no bet to call
        if call_amount == 0:
            if aggression > 0.6:
                # Bet for value or bluff
                bet_size = max(round_state.min_raise, int(round_state.pot * 0.7))
                bet_size = min(bet_size, round_state.max_raise, remaining_chips)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
            return (PokerAction.CHECK, 0)
        
        # There's a bet to call
        if call_amount >= remaining_chips:
            # All-in decision
            if aggression > 0.7:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        # Normal betting decision
        if aggression > 0.8:
            # Strong hand - raise
            raise_size = max(round_state.min_raise, call_amount * 3)
            raise_size = min(raise_size, round_state.max_raise, remaining_chips)
            if raise_size >= round_state.min_raise:
                return (PokerAction.RAISE, raise_size)
            else:
                return (PokerAction.CALL, 0)
        elif aggression > 0.4:
            # Decent hand - call
            return (PokerAction.CALL, 0)
        else:
            # Weak hand - fold
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Update opponent modeling for future games
        for player_id, hands in active_players_hands.items():
            if player_id != str(self.id):
                if player_id not in self.opponent_tendencies:
                    self.opponent_tendencies[player_id] = {'tight': 0, 'aggressive': 0, 'bluffs': 0}