from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.all_players = []
        self.opponent_stats = {}
        self.hand_history = []
        self.position_factor = 1.0
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.all_players = all_players
        
        # Initialize opponent stats
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_stats[player_id] = {
                    'hands_played': 0,
                    'aggressive_actions': 0,
                    'total_actions': 0,
                    'fold_to_aggression': 0,
                    'faced_aggression': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Calculate position factor (later position is better)
        current_players = round_state.current_player
        if len(current_players) > 1:
            my_position = current_players.index(self.id) if self.id in current_players else 0
            self.position_factor = 1 + (my_position / max(1, len(current_players) - 1)) * 0.3

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update opponent stats
        self._update_opponent_stats(round_state)
        
        # Get hand strength
        hand_strength = self._evaluate_hand_strength(round_state)
        
        # Calculate pot odds and position advantages
        pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
        aggressive_factor = self._calculate_aggression_factor(round_state)
        
        # Determine action based on multiple factors
        action, amount = self._decide_action(
            round_state, remaining_chips, hand_strength, 
            pot_odds, aggressive_factor
        )
        
        return action, amount

    def _evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        if not self.player_hands or len(self.player_hands) < 2:
            return 0.1
            
        hole_cards = self.player_hands[:2]
        community_cards = round_state.community_cards
        
        # Pre-flop hand evaluation
        if round_state.round == 'Preflop':
            return self._preflop_hand_strength(hole_cards)
        
        # Post-flop hand evaluation
        return self._postflop_hand_strength(hole_cards, community_cards)
    
    def _preflop_hand_strength(self, hole_cards: List[str]) -> float:
        if len(hole_cards) < 2:
            return 0.1
            
        card1, card2 = hole_cards[0], hole_cards[1]
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 2), rank_values.get(rank2, 2)
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Base strength from high card
        strength = high_card / 14.0
        
        # Pair bonus
        if val1 == val2:
            strength += 0.3 + (val1 / 14.0) * 0.4
        
        # Suited bonus
        if suit1 == suit2:
            strength += 0.1
        
        # Connected cards bonus
        if abs(val1 - val2) <= 1 and val1 != val2:
            strength += 0.05
        elif abs(val1 - val2) <= 4:
            strength += 0.025
        
        # Premium hands
        if (val1 >= 11 and val2 >= 11) or (val1 == 14 and val2 >= 10):
            strength += 0.2
            
        return min(strength * self.position_factor, 1.0)
    
    def _postflop_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        all_cards = hole_cards + community_cards
        if len(all_cards) < 5:
            return 0.3
            
        # Simple hand evaluation
        ranks = [self._card_rank(card) for card in all_cards]
        suits = [card[1] for card in all_cards]
        
        rank_counts = {}
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
        
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        
        # Check for various hands
        if self._is_straight_flush(all_cards):
            return 0.95
        elif max(rank_counts.values()) >= 4:  # Four of a kind
            return 0.9
        elif max(rank_counts.values()) >= 3 and len([v for v in rank_counts.values() if v >= 2]) >= 2:  # Full house
            return 0.85
        elif max(suit_counts.values()) >= 5:  # Flush
            return 0.75
        elif self._is_straight(ranks):  # Straight
            return 0.7
        elif max(rank_counts.values()) >= 3:  # Three of a kind
            return 0.6
        elif len([v for v in rank_counts.values() if v >= 2]) >= 2:  # Two pair
            return 0.45
        elif max(rank_counts.values()) >= 2:  # One pair
            return 0.3
        else:  # High card
            return max(ranks) / 14.0 * 0.25
    
    def _card_rank(self, card: str) -> int:
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_values.get(card[0], 2)
    
    def _is_straight_flush(self, cards: List[str]) -> bool:
        suits = {}
        for card in cards:
            suit = card[1]
            if suit not in suits:
                suits[suit] = []
            suits[suit].append(self._card_rank(card))
        
        for suit_cards in suits.values():
            if len(suit_cards) >= 5 and self._is_straight(suit_cards):
                return True
        return False
    
    def _is_straight(self, ranks: List[int]) -> bool:
        unique_ranks = sorted(set(ranks))
        if len(unique_ranks) < 5:
            return False
            
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i+4] - unique_ranks[i] == 4:
                return True
                
        # Check for A-2-3-4-5 straight
        if set([14, 2, 3, 4, 5]).issubset(set(unique_ranks)):
            return True
            
        return False
    
    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        pot_size = round_state.pot
        
        if call_amount == 0:
            return 1.0
        if call_amount >= remaining_chips:
            return pot_size / max(1, remaining_chips)
            
        return pot_size / max(1, call_amount)
    
    def _calculate_aggression_factor(self, round_state: RoundStateClient) -> float:
        aggressive_opponents = 0
        total_opponents = 0
        
        for player_id in round_state.current_player:
            if player_id != self.id and str(player_id) in self.opponent_stats:
                total_opponents += 1
                stats = self.opponent_stats[str(player_id)]
                if stats['total_actions'] > 0:
                    aggression_rate = stats['aggressive_actions'] / max(1, stats['total_actions'])
                    if aggression_rate > 0.3:
                        aggressive_opponents += 1
        
        return aggressive_opponents / max(1, total_opponents)
    
    def _decide_action(self, round_state: RoundStateClient, remaining_chips: int, 
                      hand_strength: float, pot_odds: float, aggressive_factor: float) -> Tuple[PokerAction, int]:
        
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # Adjust thresholds based on factors
        fold_threshold = 0.2 + aggressive_factor * 0.1
        call_threshold = 0.3 + aggressive_factor * 0.05
        raise_threshold = 0.6 - self.position_factor * 0.1
        
        # Stack considerations
        stack_ratio = remaining_chips / max(1, self.starting_chips)
        if stack_ratio < 0.3:  # Short stack - more aggressive
            raise_threshold -= 0.1
            fold_threshold -= 0.05
        elif stack_ratio > 2:  # Big stack - more selective
            raise_threshold += 0.1
            fold_threshold += 0.05
        
        # No bet to call - check or bet
        if call_amount == 0:
            if hand_strength > raise_threshold:
                # Value bet
                bet_size = min(int(round_state.pot * 0.6), remaining_chips)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
            return PokerAction.CHECK, 0
        
        # There's a bet to call
        if hand_strength < fold_threshold or (pot_odds < 2 and hand_strength < call_threshold):
            return PokerAction.FOLD, 0
        
        if call_amount >= remaining_chips:
            if hand_strength > call_threshold:
                return PokerAction.ALL_IN, 0
            else:
                return PokerAction.FOLD, 0
        
        # Strong hand - consider raising
        if hand_strength > raise_threshold and pot_odds > 1.5:
            raise_size = min(
                max(round_state.min_raise, int(round_state.pot * 0.8)),
                remaining_chips
            )
            if raise_size <= remaining_chips and raise_size >= round_state.min_raise:
                return PokerAction.RAISE, raise_size
        
        # All-in with very strong hands
        if hand_strength > 0.85:
            return PokerAction.ALL_IN, 0
        
        # Default to call if we have a decent hand
        if hand_strength > call_threshold and pot_odds > 1.2:
            return PokerAction.CALL, 0
        
        return PokerAction.FOLD, 0
    
    def _update_opponent_stats(self, round_state: RoundStateClient):
        for player_id, action in round_state.player_actions.items():
            if player_id != str(self.id) and player_id in self.opponent_stats:
                stats = self.opponent_stats[player_id]
                stats['total_actions'] += 1
                
                if action in ['Raise', 'All-in']:
                    stats['aggressive_actions'] += 1
                elif action == 'Fold':
                    stats['fold_to_aggression'] += 1
                    stats['faced_aggression'] += 1

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store hand result for learning
        if len(self.player_hands) >= 2:
            self.hand_history.append({
                'hand': self.player_hands[:2],
                'result': remaining_chips - getattr(self, 'chips_start_round', remaining_chips),
                'round': round_state.round
            })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended - could implement learning here
        pass