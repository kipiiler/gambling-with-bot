from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.hole_cards = []
        self.position = 0
        self.num_players = 0
        self.blind_amount = 0
        self.big_blind_player = None
        self.small_blind_player = None
        self.all_players = []
        self.hand_history = []
        self.aggressive_factor = 1.2

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player = big_blind_player_id
        self.small_blind_player = small_blind_player_id
        self.all_players = all_players
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Calculate hand strength
        hand_strength = self.evaluate_hand_strength(round_state)
        
        # Calculate position factor (later position is better)
        position_factor = self.calculate_position_factor(round_state)
        
        # Calculate pot odds if there's a bet to call
        pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
        
        # Determine action based on hand strength, position, and pot odds
        return self.decide_action(round_state, remaining_chips, hand_strength, position_factor, pot_odds)

    def evaluate_hand_strength(self, round_state: RoundStateClient) -> float:
        """Evaluate hand strength from 0 (worst) to 1 (best)"""
        if not self.hole_cards or len(self.hole_cards) < 2:
            return 0.1
            
        card1 = self.hole_cards[0]
        card2 = self.hole_cards[1]
        
        # Parse cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Convert rank to numerical value for comparison
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1 = rank_values.get(rank1, 2)
        val2 = rank_values.get(rank2, 2)
        
        # Base strength calculation
        high_card = max(val1, val2)
        low_card = min(val1, val2)
        
        # Premium hands
        if (val1 == val2 and val1 >= 10) or (val1 == 14 and val2 >= 12) or (val1 >= 12 and val2 == 14):
            base_strength = 0.9  # AA, KK, QQ, JJ, TT, AK, AQ
        elif val1 == val2 and val1 >= 7:
            base_strength = 0.8  # 77-99
        elif (val1 == 14 and val2 >= 10) or (val1 >= 10 and val2 == 14):
            base_strength = 0.75  # AJ, AT, KQ
        elif val1 == val2:
            base_strength = 0.6  # Other pairs
        elif suit1 == suit2 and abs(val1 - val2) <= 4:
            base_strength = 0.5  # Suited connectors
        elif high_card >= 12:
            base_strength = 0.4  # High cards
        else:
            base_strength = 0.2  # Weak hands
            
        # Adjust based on community cards if available
        if round_state.community_cards:
            base_strength = self.adjust_for_board(base_strength, round_state.community_cards)
            
        return min(1.0, max(0.0, base_strength))

    def adjust_for_board(self, base_strength: float, community_cards: List[str]) -> float:
        """Adjust hand strength based on community cards"""
        if not community_cards:
            return base_strength
            
        # Simple board texture analysis
        board_adjustment = 0.0
        
        # Check for potential draws and made hands
        ranks = [card[0] for card in community_cards]
        suits = [card[1] for card in community_cards]
        
        # Flush potential
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        max_suit_count = max(suit_counts.values()) if suit_counts else 0
        
        # Straight potential - simplified
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        board_ranks = sorted([rank_values.get(rank, 2) for rank in ranks])
        
        # Check if we have pairs with board
        hole_ranks = [self.hole_cards[0][0], self.hole_cards[1][0]]
        hole_suits = [self.hole_cards[0][1], self.hole_cards[1][1]]
        
        # Pair with board
        for rank in ranks:
            if rank in hole_ranks:
                board_adjustment += 0.2
                
        # Flush draw
        for suit in hole_suits:
            if suit in suits and suit_counts.get(suit, 0) >= 2:
                board_adjustment += 0.1
                
        return min(1.0, base_strength + board_adjustment)

    def calculate_position_factor(self, round_state: RoundStateClient) -> float:
        """Calculate position advantage factor"""
        if not round_state.current_player or not self.all_players:
            return 0.5
            
        # Later position is better in poker
        try:
            my_position = round_state.current_player.index(self.id) if self.id in round_state.current_player else 0
            total_players = len(round_state.current_player)
            return my_position / max(1, total_players - 1) if total_players > 1 else 0.5
        except:
            return 0.5

    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds for calling"""
        if round_state.current_bet == 0:
            return 1.0  # No bet to call
            
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = round_state.current_bet - my_current_bet
        
        if call_amount <= 0:
            return 1.0
            
        pot_size = round_state.pot
        return pot_size / (pot_size + call_amount + 0.01)  # Add small epsilon to avoid division by zero

    def decide_action(self, round_state: RoundStateClient, remaining_chips: int, hand_strength: float, position_factor: float, pot_odds: float) -> Tuple[PokerAction, int]:
        """Decide on action based on various factors"""
        
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = max(0, round_state.current_bet - my_current_bet)
        
        # Aggressive factor based on position and hand strength
        aggression = hand_strength * (1 + position_factor * 0.5) * self.aggressive_factor
        
        # Very strong hands - be aggressive
        if hand_strength >= 0.85:
            if call_amount == 0:
                # Bet for value
                bet_size = min(round_state.pot // 2, round_state.max_raise)
                if bet_size >= round_state.min_raise:
                    return (PokerAction.RAISE, bet_size)
                else:
                    return (PokerAction.CHECK, 0)
            else:
                # Consider raising or calling
                if call_amount < remaining_chips * 0.3 and round_state.max_raise >= round_state.min_raise:
                    raise_size = min(call_amount * 2 + round_state.current_bet, round_state.max_raise)
                    if raise_size >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_size)
                return (PokerAction.CALL, 0)
                
        # Strong hands
        elif hand_strength >= 0.7:
            if call_amount == 0:
                if position_factor > 0.6:  # Good position
                    bet_size = min(round_state.pot // 3, round_state.max_raise)
                    if bet_size >= round_state.min_raise:
                        return (PokerAction.RAISE, bet_size)
                return (PokerAction.CHECK, 0)
            else:
                if call_amount <= remaining_chips * 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Medium hands
        elif hand_strength >= 0.5:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Use pot odds
                if pot_odds > 0.3 and call_amount <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Weak hands
        else:
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                # Fold weak hands when facing a bet
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Track performance for learning
        delta = remaining_chips - self.starting_chips
        self.hand_history.append({
            'hole_cards': self.hole_cards.copy(),
            'community_cards': round_state.community_cards.copy(),
            'delta': delta,
            'round': round_state.round
        })
        
        # Adjust aggression based on recent performance
        if len(self.hand_history) >= 5:
            recent_deltas = [h['delta'] for h in self.hand_history[-5:]]
            avg_recent = sum(recent_deltas) / len(recent_deltas)
            
            if avg_recent < -20:  # Losing too much
                self.aggressive_factor = max(0.8, self.aggressive_factor * 0.95)
            elif avg_recent > 10:  # Winning
                self.aggressive_factor = min(1.5, self.aggressive_factor * 1.02)

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Reset for next game
        self.hole_cards = []
        self.hand_history = []
        self.aggressive_factor = 1.2