from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.hands_played = 0
        self.opponent_tendencies = {}
        self.last_action_was_aggressive = False

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.all_players = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        for player_id in all_players:
            if player_id != self.id:
                self.opponent_tendencies[player_id] = {
                    'aggression': 0.5,
                    'fold_frequency': 0.3,
                    'actions_seen': 0
                }

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hands_played += 1
        self.last_action_was_aggressive = False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get current player cards if available
            hole_cards = getattr(self, 'current_hole_cards', [])
            
            # Calculate hand strength
            hand_strength = self._evaluate_hand_strength(hole_cards, round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(round_state, remaining_chips)
            
            # Determine position
            position_strength = self._get_position_strength(round_state)
            
            # Update opponent tendencies
            self._update_opponent_tendencies(round_state)
            
            # Calculate aggression factor based on multiple factors
            aggression_factor = self._calculate_aggression_factor(
                hand_strength, position_strength, round_state, remaining_chips
            )
            
            # Determine action based on comprehensive strategy
            action, amount = self._determine_action(
                round_state, remaining_chips, hand_strength, 
                pot_odds, aggression_factor, position_strength
            )
            
            # Track if we're being aggressive
            if action in [PokerAction.RAISE, PokerAction.ALL_IN]:
                self.last_action_was_aggressive = True
            
            return action, amount
            
        except Exception as e:
            # Safe fallback - call if possible, otherwise fold
            if round_state.current_bet == 0:
                return PokerAction.CHECK, 0
            elif round_state.current_bet <= remaining_chips:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0.0 to 1.0"""
        if not hole_cards:
            return 0.5  # Neutral if we don't know our cards
        
        all_cards = hole_cards + community_cards
        
        # Pre-flop hand strength
        if not community_cards:
            return self._preflop_hand_strength(hole_cards)
        
        # Post-flop hand evaluation
        return self._postflop_hand_strength(all_cards)

    def _preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """Evaluate pre-flop hand strength"""
        if len(hole_cards) != 2:
            return 0.3
        
        card1, card2 = hole_cards
        rank1, suit1 = card1[0], card1[1]
        rank2, suit2 = card2[0], card2[1]
        
        # Card rank values
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        val1, val2 = rank_values.get(rank1, 7), rank_values.get(rank2, 7)
        max_val, min_val = max(val1, val2), min(val1, val2)
        
        # Base strength from high cards
        strength = (max_val + min_val) / 28.0
        
        # Bonuses
        if val1 == val2:  # Pocket pair
            strength += 0.3 + (max_val - 2) * 0.02
        elif suit1 == suit2:  # Suited
            strength += 0.1
        
        # Connectivity bonus
        if abs(val1 - val2) <= 4:
            strength += 0.05
        
        # Premium hands
        if max_val >= 13:  # A or K
            strength += 0.1
        if max_val == 14 and min_val >= 10:  # A-T+
            strength += 0.15
        
        return min(strength, 1.0)

    def _postflop_hand_strength(self, all_cards: List[str]) -> float:
        """Evaluate post-flop hand strength"""
        if len(all_cards) < 5:
            return 0.4
        
        hand_type = self._get_hand_type(all_cards)
        
        # Hand type strengths
        type_strengths = {
            'high_card': 0.1,
            'pair': 0.25,
            'two_pair': 0.45,
            'three_kind': 0.65,
            'straight': 0.75,
            'flush': 0.8,
            'full_house': 0.9,
            'four_kind': 0.95,
            'straight_flush': 0.99,
            'royal_flush': 1.0
        }
        
        return type_strengths.get(hand_type, 0.3)

    def _get_hand_type(self, cards: List[str]) -> str:
        """Determine the best hand type from given cards"""
        if len(cards) < 5:
            return 'high_card'
        
        # Extract ranks and suits
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        values = sorted([rank_values.get(r, 7) for r in ranks], reverse=True)
        
        # Count occurrences
        value_counts = {}
        for value in values:
            value_counts[value] = value_counts.get(value, 0) + 1
        
        counts = sorted(value_counts.values(), reverse=True)
        
        # Check for flush
        suit_counts = {}
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        is_flush = max(suit_counts.values()) >= 5
        
        # Check for straight
        unique_values = sorted(set(values), reverse=True)
        is_straight = False
        for i in range(len(unique_values) - 4):
            if unique_values[i] - unique_values[i+4] == 4:
                is_straight = True
                break
        
        # Determine hand type
        if is_straight and is_flush:
            if unique_values[0] == 14 and unique_values[1] == 13:  # A-K high
                return 'royal_flush'
            return 'straight_flush'
        elif counts[0] == 4:
            return 'four_kind'
        elif counts[0] == 3 and counts[1] == 2:
            return 'full_house'
        elif is_flush:
            return 'flush'
        elif is_straight:
            return 'straight'
        elif counts[0] == 3:
            return 'three_kind'
        elif counts[0] == 2 and counts[1] == 2:
            return 'two_pair'
        elif counts[0] == 2:
            return 'pair'
        else:
            return 'high_card'

    def _calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds"""
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        if call_amount <= 0:
            return float('inf')
        
        total_pot = round_state.pot + call_amount
        return total_pot / (call_amount + 0.001)  # Avoid division by zero

    def _get_position_strength(self, round_state: RoundStateClient) -> float:
        """Calculate position strength (0.0 to 1.0)"""
        if len(round_state.current_player) <= 1:
            return 0.5
        
        # In heads-up, dealer (small blind) acts first pre-flop, last post-flop
        if round_state.round == 'Preflop':
            return 0.3 if self.id == self.small_blind_player_id else 0.7
        else:
            return 0.7 if self.id == self.small_blind_player_id else 0.3

    def _update_opponent_tendencies(self, round_state: RoundStateClient):
        """Update opponent behavior tracking"""
        for player_id_str, action in round_state.player_actions.items():
            try:
                player_id = int(player_id_str)
                if player_id != self.id and player_id in self.opponent_tendencies:
                    self.opponent_tendencies[player_id]['actions_seen'] += 1
                    
                    if action in ['Raise', 'All-in']:
                        self.opponent_tendencies[player_id]['aggression'] = min(1.0, 
                            self.opponent_tendencies[player_id]['aggression'] + 0.1)
                    elif action == 'Fold':
                        self.opponent_tendencies[player_id]['fold_frequency'] = min(1.0,
                            self.opponent_tendencies[player_id]['fold_frequency'] + 0.05)
            except (ValueError, KeyError):
                continue

    def _calculate_aggression_factor(self, hand_strength: float, position_strength: float, 
                                   round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate how aggressive we should be"""
        base_aggression = hand_strength * 0.6 + position_strength * 0.2
        
        # Adjust for stack size
        stack_ratio = remaining_chips / max(1, self.starting_chips)
        if stack_ratio < 0.3:  # Short stack - more aggressive
            base_aggression += 0.2
        elif stack_ratio > 2.0:  # Big stack - can afford to be aggressive
            base_aggression += 0.1
        
        # Adjust for betting round
        if round_state.round == 'Preflop':
            base_aggression *= 0.8  # Slightly less aggressive pre-flop
        elif round_state.round in ['Turn', 'River']:
            base_aggression *= 1.2  # More aggressive on later streets
        
        # Adjust for pot size
        pot_ratio = round_state.pot / max(1, self.blind_amount * 4)
        if pot_ratio > 10:  # Big pot
            base_aggression += 0.1
        
        return min(1.0, base_aggression)

    def _determine_action(self, round_state: RoundStateClient, remaining_chips: int, 
                         hand_strength: float, pot_odds: float, aggression_factor: float,
                         position_strength: float) -> Tuple[PokerAction, int]:
        """Determine the best action based on all factors"""
        
        call_amount = max(0, round_state.current_bet - round_state.player_bets.get(str(self.id), 0))
        
        # If we can't afford to call, fold
        if call_amount > remaining_chips:
            return PokerAction.FOLD, 0
        
        # No bet to us - check or bet
        if call_amount == 0:
            if aggression_factor > 0.6 and hand_strength > 0.4:
                # Aggressive bet
                bet_size = self._calculate_bet_size(round_state, remaining_chips, aggression_factor)
                if bet_size >= round_state.min_raise:
                    return PokerAction.RAISE, bet_size
            return PokerAction.CHECK, 0
        
        # Facing a bet - decide whether to fold, call, or raise
        
        # Strong hands - usually raise or call
        if hand_strength > 0.7:
            if aggression_factor > 0.5 and remaining_chips > call_amount * 3:
                raise_size = self._calculate_raise_size(round_state, remaining_chips, aggression_factor)
                if raise_size >= round_state.min_raise:
                    return PokerAction.RAISE, raise_size
            return PokerAction.CALL, 0
        
        # Medium hands - consider pot odds and position
        elif hand_strength > 0.4:
            # Good pot odds or good position
            if pot_odds > 3.0 or (position_strength > 0.6 and aggression_factor > 0.5):
                if aggression_factor > 0.7 and remaining_chips > call_amount * 4:
                    raise_size = self._calculate_raise_size(round_state, remaining_chips, aggression_factor * 0.8)
                    if raise_size >= round_state.min_raise:
                        return PokerAction.RAISE, raise_size
                return PokerAction.CALL, 0
            elif pot_odds > 2.0:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0
        
        # Weak hands - mostly fold, sometimes bluff
        else:
            # Bluff in good position with high aggression
            if (position_strength > 0.6 and aggression_factor > 0.8 and 
                call_amount < remaining_chips * 0.1 and round_state.round != 'River'):
                if remaining_chips > call_amount * 5:
                    bluff_size = self._calculate_bluff_size(round_state, remaining_chips)
                    if bluff_size >= round_state.min_raise:
                        return PokerAction.RAISE, bluff_size
                return PokerAction.CALL, 0
            # Good pot odds for drawing
            elif pot_odds > 4.0 and call_amount < remaining_chips * 0.05:
                return PokerAction.CALL, 0
            else:
                return PokerAction.FOLD, 0

    def _calculate_bet_size(self, round_state: RoundStateClient, remaining_chips: int, 
                           aggression_factor: float) -> int:
        """Calculate bet size for when we're betting into an unraised pot"""
        pot_size = round_state.pot
        
        # Base bet: 50-80% of pot depending on aggression
        bet_ratio = 0.5 + (aggression_factor * 0.3)
        bet_size = int(pot_size * bet_ratio)
        
        # Ensure minimum raise
        bet_size = max(bet_size, round_state.min_raise)
        
        # Don't bet more than we have
        bet_size = min(bet_size, remaining_chips)
        
        return bet_size

    def _calculate_raise_size(self, round_state: RoundStateClient, remaining_chips: int, 
                             aggression_factor: float) -> int:
        """Calculate raise size"""
        pot_size = round_state.pot
        current_bet = round_state.current_bet
        
        # Aggressive raise: 2-4x the current bet or 60-100% of pot
        if aggression_factor > 0.7:
            raise_size = max(current_bet * 3, int(pot_size * 0.8))
        else:
            raise_size = max(current_bet * 2, int(pot_size * 0.6))
        
        # Ensure minimum raise
        min_total_bet = current_bet + round_state.min_raise
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        min_raise_amount = min_total_bet - my_current_bet
        
        raise_size = max(raise_size, min_raise_amount)
        
        # Don't raise more than we have
        raise_size = min(raise_size, remaining_chips)
        
        return raise_size

    def _calculate_bluff_size(self, round_state: RoundStateClient, remaining_chips: int) -> int:
        """Calculate bluff size"""
        pot_size = round_state.pot
        
        # Bluff size: 60-80% of pot
        bluff_size = int(pot_size * 0.7)
        
        # Ensure minimum raise
        current_bet = round_state.current_bet
        min_total_bet = current_bet + round_state.min_raise
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        min_raise_amount = min_total_bet - my_current_bet
        
        bluff_size = max(bluff_size, min_raise_amount)
        
        # Limit bluff size to reasonable portion of stack
        max_bluff = int(remaining_chips * 0.3)
        bluff_size = min(bluff_size, max_bluff)
        
        return bluff_size

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass