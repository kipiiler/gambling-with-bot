from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_strength_cache = {}
        self.player_tightness = {}
        self.agg_count = {}
        self.our_bet = 0
        self.round_id = None

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        for p in all_players:
            self.player_tightness[p] = {'hands': 0, 'vpip': 0}
            self.agg_count[p] = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.our_bet = 0
        self.round_id = round_state.round_num

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            our_id = str(self.id)
            if our_id not in round_state.player_bets:
                return PokerAction.FOLD, 0
            
            our_bet_current = round_state.player_bets.get(our_id, 0)
            current_bet = round_state.current_bet
            need_to_call = max(0, current_bet - our_bet_current)
            
            if round_state.round == 'Preflop':
                return self._preflop_action(round_state, remaining_chips, need_to_call)
            else:
                return self._postflop_action(round_state, remaining_chips, need_to_call)
        except:
            return PokerAction.FOLD, 0

    def _preflop_action(self, round_state, remaining_chips, need_to_call):
        our_id = str(self.id)
        hole_cards = round_state.player_hands.get(our_id, [])
        if len(hole_cards) < 2:
            return PokerAction.FOLD, 0
            
        card_ranks = [c[0] for c in hole_cards]
        card_suits = [c[1] for c in hole_cards]
        
        strength = 0
        
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        r1 = rank_values[card_ranks[0]]
        r2 = rank_values[card_ranks[1]]
        suited = card_suits[0] == card_suits[1]
        
        strength = max(r1, r2) * 1.5 + min(r1, r2) * 1.0
        if suited:
            strength += 2.0
            
        if r1 == r2:
            strength += 8.0
            
        pot_odds = need_to_call / (round_state.pot + need_to_call + 0.001)
        
        if strength >= 28:
            if remaining_chips > need_to_call:
                if need_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, int(round_state.pot * 0.75))
                else:
                    return PokerAction.RAISE, min(remaining_chips, max(need_to_call * 2, int(round_state.pot * 0.5)))
            else:
                return PokerAction.ALL_IN, 0
        elif strength >= 20 and need_to_call <= remaining_chips * 0.08:
            if need_to_call == 0 and random.random() < 0.3:
                return PokerAction.RAISE, min(remaining_chips, int(round_state.pot * 0.5))
            return PokerAction.CALL, 0
        elif strength >= 15 and need_to_call <= remaining_chips * 0.05:
            return PokerAction.CALL, 0
        else:
            if need_to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def _postflop_action(self, round_state, remaining_chips, need_to_call):
        our_id = str(self.id)
        our_hand = self._evaluate_hand(round_state)
        
        if not our_hand:
            if need_to_call == 0:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.FOLD, 0
                
        pot_odds = need_to_call / (round_state.pot + need_to_call + 0.001)
        
        if our_hand >= 8:
            if need_to_call == 0:
                return PokerAction.RAISE, min(remaining_chips, int(round_state.pot * 0.8))
            else:
                return PokerAction.RAISE, min(remaining_chips, max(need_to_call * 2.5, int(round_state.pot * 0.7)))
        elif our_hand >= 6:
            if need_to_call <= remaining_chips * 0.15:
                if random.random() < 0.7:
                    return PokerAction.CALL, 0
                elif need_to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, int(round_state.pot * 0.4))
                else:
                    return PokerAction.CALL, 0
            elif need_to_call > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        elif our_hand >= 4:
            if need_to_call / (remaining_chips + 0.001) <= 0.08:
                return PokerAction.CALL, 0
            else:
                if need_to_call == 0:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0
        else:
            if need_to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

    def _evaluate_hand(self, round_state):
        our_id = str(self.id)
        if our_id not in round_state.player_hands:
            return 0
            
        hole_cards = round_state.player_hands[our_id]
        if len(hole_cards) < 2:
            return 0
            
        all_cards = hole_cards + round_state.community_cards
        if len(all_cards) < 5:
            return 0
            
        return self._get_strength(all_cards)

    def _get_strength(self, cards):
        if len(cards) < 5:
            return 0
            
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        ranks = []
        suits = []
        for card in cards:
            ranks.append(rank_values[card[0]])
            suits.append(card[1])
            
        ranks_sorted = sorted(ranks, reverse=True)
        suit_counts = {}
        rank_counts = {}
        
        for suit in suits:
            suit_counts[suit] = suit_counts.get(suit, 0) + 1
        for rank in ranks:
            rank_counts[rank] = rank_counts.get(rank, 0) + 1
            
        flush_suit = None
        for suit, count in suit_counts.items():
            if count >= 5:
                flush_suit = suit
                break
                
        straight_high = 0
        unique_ranks = sorted(list(set(ranks)), reverse=True)
        for i in range(len(unique_ranks) - 4):
            if unique_ranks[i] - unique_ranks[i+4] == 4:
                straight_high = unique_ranks[i]
                break
        if set([14, 5, 4, 3, 2]).issubset(set(ranks)):
            straight_high = 5
            
        best_score = 1
        
        if flush_suit and straight_high > 0:
            best_score = 8 if straight_high == 14 else 9
        elif 4 in rank_counts.values():
            best_score = 8
        elif sorted(rank_counts.values()) == [2, 3]:
            best_score = 7
        elif flush_suit:
            best_score = 6
        elif straight_high > 0:
            best_score = 5
        elif 3 in rank_counts.values():
            best_score = 4
        elif list(rank_counts.values()).count(2) >= 2:
            best_score = 3
        elif 2 in rank_counts.values():
            best_score = 2
            
        return best_score * 10 + max(ranks_sorted)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass