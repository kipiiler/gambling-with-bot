from typing import List, Tuple
import random
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.starting_chips = 0
        self.hole_cards = []
        self.prev_rounds = []
        self.player_actions = {}
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_id = self.id
        self.hole_cards = player_hands
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        pass
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        community_cards = round_state.community_cards
        
        try:
            if not self.hole_cards or len(self.hole_cards) < 2:
                if round_state.current_bet > 0:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.CHECK, 0
            
            card_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
            
            h1 = self.hole_cards[0]
            h2 = self.hole_cards[1]
            
            v1 = card_values[h1[0]]
            v2 = card_values[h2[0]]
            s1 = h1[1]
            s2 = h2[1]
            
            is_pair = v1 == v2
            is_suited = s1 == s2
            high_card = max(v1, v2)
            low_card = min(v1, v2)
            gap = abs(v1 - v2)
            
            strength = 0
            
            if is_pair:
                if high_card >= 12: strength = 9
                elif high_card >= 10: strength = 8
                elif high_card >= 8: strength = 7
                elif high_card >= 6: strength = 6
                else: strength = 5
            elif is_suited:
                if high_card >= 12 and low_card >= 10: strength = 8
                elif high_card >= 11 and low_card >= 9: strength = 7
                elif high_card >= 10 and gap <= 2: strength = 6
                elif gap == 1 and low_card >= 6: strength = 5
                elif gap <= 2: strength = 4
                else: strength = 3
            else:
                if high_card >= 12 and low_card >= 10: strength = 7
                elif high_card >= 11 and low_card >= 9: strength = 6
                elif gap == 1 and low_card >= 8: strength = 5
                elif gap == 2 and low_card >= 9: strength = 4
                elif high_card >= 11: strength = 3
                else: strength = 2
            
            if len(community_cards) > 0:
                all_cards = []
                hole_vals = [v1, v2]
                
                for card in community_cards:
                    rank = card[0]
                    val = card_values[rank]
                    all_cards.append(val)
                
                all_values = hole_vals + all_cards
                value_counts = {}
                
                for val in all_values:
                    value_counts[val] = value_counts.get(val, 0) + 1
                
                board_flushes = False
                board_suits = [card[1] for card in community_cards]
                for suit in set(board_suits):
                    if board_suits.count(suit) >= 3:
                        board_flushes = True
                
                if is_suited and not board_flushes:
                    h_suits = [s1, s2]
                    if h_suits.count(s1) > board_suits.count(s1) + 2:
                        strength += 1
                
                pairs = [v for v, count in value_counts.items() if count >= 2]
                if len(pairs) > 0:
                    strength += 3
                
                trips = [v for v, count in value_counts.items() if count >= 3]
                if len(trips) > 0:
                    strength += 5
                
                quads = [v for v, count in value_counts.items() if count >= 4]
                if len(quads) > 0:
                    strength += 10
                
                if len(all_cards) >= 3:
                    straight_possibles = []
                    for i in range(2, 15):
                        if i in all_values:
                            count = 0
                            low = max(2, i - 4)
                            for j in range(i-4, i+1):
                                if j in all_values:
                                    count += 1
                            if count >= 3:
                                straight_possibles.append(i)
                    
                    if straight_possibles:
                        strength += 2
                
                max_pairs = max([0] + [all_values.count(v) for v in hole_vals])
                board_pairs = sum(1 for v in all_cards if v in hole_vals)
                
                if max_pairs >= 2:
                    strength += 6
                elif board_pairs > 0:
                    strength += 4
            
            if len(community_cards) == 3:
                strength += 0.5
            elif len(community_cards) == 4:
                strength += 1
            elif len(community_cards) == 5:
                strength += 1.5
            
            total_pot = round_state.pot
            to_call = round_state.current_bet - (round_state.player_bets.get(str(self.player_id), 0))
            
            pot_odds = 0
            if total_pot + to_call > 0:
                pot_odds = to_call / (total_pot + to_call)
            
            if remaining_chips > 0:
                if strength >= 8:
                    if round_state.current_bet > 0:
                        min_raise = round_state.min_raise
                        max_raise = round_state.max_raise
                        
                        if max_raise <= 0:
                            return PokerAction.CALL, 0
                        
                        raise_amount = min(max(min_raise + total_pot//4, min_raise), max_raise)
                        if raise_amount <= max_raise and raise_amount > to_call:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.CALL, 0
                    else:
                        min_raise = round_state.min_raise
                        max_raise = round_state.max_raise
                        
                        if max_raise <= 0:
                            return PokerAction.CHECK, 0
                        
                        bet_amount = min(max(min_raise + total_pot//4, min_raise), max_raise)
                        if bet_amount <= max_raise:
                            return PokerAction.RAISE, bet_amount
                        else:
                            return PokerAction.CHECK, 0
                
                elif strength >= 6:
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    elif pot_odds < 0.3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                
                elif strength >= 4:
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    elif pot_odds < 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                
                else:
                    if to_call == 0:
                        return PokerAction.CHECK, 0
                    elif to_call <= min(100, remaining_chips // 20):
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:
                return PokerAction.CALL, 0
                
        except:
            if round_state.current_bet > 0:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        self.prev_rounds.append(round_state.round)
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass