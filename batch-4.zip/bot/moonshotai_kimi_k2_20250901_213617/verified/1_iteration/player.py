from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_count = 0
        self.opp_tightness = {}  # {player_id: [vpip_count, hand_count]}
        self.opp_aggression = {}  # {player_id: [aggressive_actions, total_actions]}
        self.position = 0
        self.big_blind = 0
        self.my_cards = []
        self.pot_odds_history = []
        self.showdown_wins = 0
        self.showdown_losses = 0
        self.blind_amount = 0
        
    def card_rank(self, card):
        """Get numerical rank of card"""
        rank_map = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7,
                   '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        return rank_map[card[0]]
    
    def card_suit(self, card):
        """Get suit of card"""
        return card[1]
    
    def evaluate_hand_strength(self, my_cards, board_cards):
        """Evaluate hand strength using basic rules"""
        all_cards = my_cards + board_cards
        ranks = []
        suits = []
        
        for card in all_cards:
            ranks.append(self.card_rank(card))
            suits.append(self.card_suit(card))
        
        # Count occurrences
        rank_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        
        # Count suits
        suit_counts = {}
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1
            
        # Check flush
        flush_suit = None
        for suit, count in suit_counts.items():
            if count >= 5:
                flush_suit = suit
                break
        
        # Sort ranks
        sorted_ranks = sorted(ranks, reverse=True)
        
        # Check straight/royal flush
        unique_ranks = sorted(list(set(sorted_ranks)), reverse=True)
        straight_high = 0
        if len(unique_ranks) >= 5:
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i] - unique_ranks[i + 4] == 4:
                    straight_high = unique_ranks[i]
                    break
            if unique_ranks[:4] == [14, 5, 4, 3, 2]:
                straight_high = 5
        
        # Hand strength calculation
        score = 0
        
        # High card
        if not any(count >= 2 for count in rank_counts.values()):
            score = max(ranks)
        # Pair
        elif any(count == 2 for count in rank_counts.values()):
            pair_rank = max(r for r, count in rank_counts.items() if count == 2)
            score = 100 + pair_rank
            # Two pair
            pairs = sorted([r for r, count in rank_counts.items() if count == 2], reverse=True)
            if len(pairs) >= 2:
                score = 200 + pairs[0] * 14 + pairs[1]
        # Three of a kind
        elif any(count == 3 for count in rank_counts.values()):
            trips_rank = max(r for r, count in rank_counts.items() if count == 3)
            score = 300 + trips_rank
        # Straight
        elif straight_high > 0:
            score = 400 + straight_high
        # Flush
        elif flush_suit:
            flush_ranks = [r for r, s in zip(ranks, suits) if s == flush_suit]
            score = 500 + max(flush_ranks)
            if straight_high > 0:
                # Straight flush
                score = 800 + straight_high
        # Full house
        elif any(count == 3 for count in rank_counts.values()) and any(count >= 2 for count in rank_counts.values()):
            trips_rank = max(r for r, count in rank_counts.items() if count == 3)
            pair_rank = max(r for r, count in rank_counts.items() if count >= 2 and r != trips_rank)
            score = 600 + trips_rank * 14 + pair_rank
        # Four of a kind
        elif any(count == 4 for count in rank_counts.values()):
            quads_rank = max(r for r, count in rank_counts.items() if count == 4)
            score = 700 + quads_rank
        
        return score
    
    def opening_range(self, cards):
        """Check if cards are in opening range"""
        ranks = sorted([self.card_rank(card) for card in cards], reverse=True)
        suited = self.card_suit(cards[0]) == self.card_suit(cards[1])
        
        # Premium pairs
        if ranks[0] == ranks[1] and ranks[0] >= 8:
            return True
        # AK, AQ suited
        if ranks[0] >= 12 and ranks[1] >= 10 and suited:
            return True
        # AK, AQ offsuit
        if ranks[0] == 14 and ranks[1] >= 11:
            return True
        # Mid pairs
        if ranks[0] == ranks[1] and ranks[0] >= 5:
            return True
        # Suited connectors
        if suited and 2 <= (ranks[0] - ranks[1]) <= 5 and ranks[0] >= 9:
            return True
        
        return False
    
    def get_pot_odds(self, round_state: RoundStateClient, remaining_chips: int):
        """Calculate pot odds for calling"""
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        if to_call <= 0:
            return 0.0
        return to_call / (round_state.pot + to_call + 1e-6)
    
    def get_position_factor(self, remaining_players, my_id):
        """Calculate position factor for hand selection"""
        position = (my_id - remaining_players[0]) % len(remaining_players)
        return 1.0 - (position / max(len(remaining_players), 6))
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_count = len(all_players)
        self.big_blind = big_blind_player_id
        self.blind_amount = blind_amount
        
        # Initialize tracking
        for player_id in all_players:
            self.opp_tightness[str(player_id)] = {'vpip': 0, 'hands': 0}
            self.opp_aggression[str(player_id)] = {'aggressive': 0, 'total': 0}
    
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            # Track opponent actions and update tightness
            for player_id, action in round_state.player_actions.items():
                if player_id != str(self.id):
                    self.opp_tightness[player_id]['hands'] += 1
                    if action and action in ['Call', 'Raise', 'All_in']:
                        self.opp_tightness[player_id]['vpip'] += 1
                    
                    self.opp_aggression[player_id]['total'] += 1
                    if action and action in ['Raise', 'All_in']:
                        self.opp_aggression[player_id]['aggressive'] += 1
    
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        pot_size = round_state.pot
        big_blind = self.blind_amount
        
        # Early game tight play
        if round_state.round_num < 50:
            if round_state.round == 'Preflop':
                hand_strength = self.evaluate_hand_strength(self.my_cards, [])
                
                # Strong starting hands
                if hand_strength >= 200:
                    if to_call == 0:
                        if random.random() < 0.3:
                            raise_amount = min(big_blind * 3, remaining_chips)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        if to_call <= big_blind * 2 and hand_strength >= 300:
                            return (PokerAction.CALL, 0)
                        elif hand_strength >= 500:
                            raise_amount = min(max(big_blind * 4, int(pot_size * 0.6)), remaining_chips)
                            return (PokerAction.RAISE, raise_amount)
                        elif to_call <= big_blind and hand_strength >= 200:
                            return (PokerAction.CALL, 0)
                        
                # Medium hands from position
                elif hand_strength >= 100 and self.get_position_factor(round_state.current_player, self.id) > 0.5:
                    if to_call <= big_blind and len([a for a in round_state.player_actions.values() if a in ['Raise', 'All_in']]) == 0:
                        return (PokerAction.CALL, 0)
                
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                elif to_call <= big_blind and random.random() < 0.2:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
        
        # Aggressive mid-game play
        if round_state.round in ['Flop', 'Turn', 'River']:
            my_bet = round_state.player_bets.get(str(self.id), 0)
            pot_after_my_call = pot_size + to_call
            pot_odds = self.get_pot_odds(round_state, remaining_chips)
            
            # Evaluate hand strength with board
            board_strength = self.evaluate_hand_strength(self.my_cards, round_state.community_cards)
            best_poss_strength = self.evaluate_hand_strength(self.my_cards, [])
            
            # Calculate draw potential
            has_strength = board_strength > best_poss_strength
            
            # Continuation bet
            if round_state.round == 'Flop' and to_call == 0 and not has_strength:
                if random.random() < 0.4:
                    bet_size = min(big_blind * 2, int(pot_size * 0.4), remaining_chips)
                    return (PokerAction.RAISE, bet_size)
            
            # Value betting
            if has_strength and board_strength > 400:
                if to_call == 0:
                    bet_size = min(int(pot_size * 0.7), remaining_chips)
                    return (PokerAction.RAISE, bet_size)
                elif to_call < int(pot_size * 0.2):
                    return (PokerAction.CALL, 0)
                elif to_call < pot_odds * pot_after_my_call and board_strength > 500:
                    return (PokerAction.CALL, 0)
            
            # Bluffing in good spots
            opponent_count = len(round_state.current_player) - 1
            tight_opponents = [pid for pid in self.opp_tightness 
                             if self.opp_tightness[pid]['hands'] > 0 
                             and self.opp_tightness[pid]['vpip'] / max(self.opp_tightness[pid]['hands'], 1) < 0.2]
            
            if len(tight_opponents) >= opponent_count * 0.5 and to_call == 0 and not has_strength:
                if random.random() < 0.1:
                    bet_size = min(int(pot_size * 0.35), remaining_chips)
                    return (PokerAction.RAISE, bet_size)
        
        # Late game all-in conditions
        if remaining_chips < self.starting_chips * 0.1:
            if round_state.round == 'Preflop':
                hand_strength = self.evaluate_hand_strength(self.my_cards, [])
                if hand_strength >= 100:
                    return (PokerAction.ALL_IN, 0)
        
        # Default action
        if to_call == 0:
            return (PokerAction.CHECK, 0)
        elif to_call > remaining_chips * 0.5:
            if round_state.community_cards:
                board_strength = self.evaluate_hand_strength(self.my_cards, round_state.community_cards)
                if board_strength < 400:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
        elif to_call <= remaining_chips * 0.1:
            return (PokerAction.CALL, 0)
        else:
            # Random call fold to balance strategy
            if random.random() < 0.3:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
    
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        pass
    
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Update strategy based on results
        if str(self.id) in active_players_hands:
            self.my_cards = active_players_hands[str(self.id)]