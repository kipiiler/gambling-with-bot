from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import itertools

# Map card ranks to numeric values
RANK_TO_VALUE = {
    '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.position = None
        self.hand_strength = 0
        self.preflop_aggression = 0.0
        self.flop_aggression = 0.0
        self.turn_aggression = 0.0
        self.river_aggression = 0.0
        self.opponent_aggression = {}
        self.opponent_fold_rate = {}
        self.player_stack = {}
        self.hand_count = 0
        self.vpip = 0
        self.pfr = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_stack = {player: starting_chips for player in all_players}
        self.hand_count = 0
        self.vpip = 0
        self.pfr = 0
        
        # Parse player hands into individual cards
        self.parsed_hands = []
        for hand_str in player_hands:
            if len(hand_str) == 4:
                self.parsed_hands.append([hand_str[0:2], hand_str[2:4]])
            elif len(hand_str) == 5 and hand_str[2] == ' ':
                self.parsed_hands.append([hand_str[0:2], hand_str[3:5]])
            else:
                parts = hand_str.split()
                if len(parts) >= 2:
                    self.parsed_hands.append(parts[0:2])
                else:
                    self.parsed_hands.append([hand_str[0:2], hand_str[2:4]])

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.player_stack[self.id] = remaining_chips
        self.hand_count += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot = round_state.pot
        community_cards = round_state.community_cards
        round_stage = round_state.round
        active_players = round_state.current_player

        # Get my current hand
        player_index = self.all_players.index(self.id)
        my_hand = self.parsed_hands[player_index]

        # Calculate hand strength
        try:
            self.calculate_hand_strength(my_hand, community_cards, active_players)
        except Exception as e:
            # Fallback to random strength if evaluation fails
            self.hand_strength = random.uniform(0.2, 0.8)

        # Position awareness
        current_players = round_state.current_player
        my_index = current_players.index(self.id)
        num_players = len(current_players)
        position_factor = (num_players - my_index) / num_players

        # Adjust aggression based on stage
        aggression = 0.0
        if round_stage == 'Preflop':
            aggression = 0.4 + position_factor * 0.3
        elif round_stage == 'Flop':
            aggression = 0.5 + position_factor * 0.2
        elif round_stage == 'Turn':
            aggression = 0.6 + position_factor * 0.2
        elif round_stage == 'River':
            aggression = 0.7 + position_factor * 0.1

        # If no bet present
        if current_bet == 0:
            if self.hand_strength > 0.7 + aggression:
                raise_amount = max(min_raise, int(pot * 0.6))
                raise_amount = min(raise_amount, max_raise)
                if raise_amount >= remaining_chips:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.RAISE, raise_amount)
            elif self.hand_strength > 0.4:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.CHECK, 0)
        else:
            # Handle existing bet
            pot_odds = current_bet / (pot + current_bet + 1e-8)
            strength_advantage = self.hand_strength - pot_odds
            
            if strength_advantage > 0.2:
                if self.hand_strength > 0.8 or strength_advantage > 0.3:
                    raise_amount = max(min_raise, int(current_bet * 2.5), int(pot * 0.5))
                    raise_amount = min(raise_amount, max_raise)
                    if raise_amount >= remaining_chips:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.RAISE, raise_amount)
                else:
                    if remaining_chips <= current_bet:
                        return (PokerAction.ALL_IN, 0)
                    else:
                        return (PokerAction.CALL, 0)
            elif strength_advantage > 0:
                if remaining_chips <= current_bet:
                    return (PokerAction.ALL_IN, 0)
                else:
                    return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def calculate_hand_strength(self, my_hand: List[str], community_cards: List[str], active_players: List[int]):
        num_opponents = len(active_players) - 1
        if num_opponents == 0:
            self.hand_strength = 1.0
            return
            
        if len(community_cards) == 0:
            n_simulations = 80
        elif len(community_cards) <= 3:
            n_simulations = 100
        else:
            n_simulations = 120
            
        self.hand_strength = self.estimate_win_probability(
            my_hand, community_cards, len(active_players), n_simulations
        )

    @staticmethod
    def create_deck():
        ranks = ['2','3','4','5','6','7','8','9','T','J','Q','K','A']
        suits = ['h','d','c','s']
        return [r + s for s in suits for r in ranks]

    @staticmethod
    def get_hand_value(five_cards):
        values = []
        suits = []
        for card in five_cards:
            rank = card[0]
            values.append(RANK_TO_VALUE[rank])
            suits.append(card[1])
        values.sort(reverse=True)
        
        # Check for straight and flush
        flush = len(set(suits)) == 1
        straight = True
        for i in range(1, 5):
            if values[i] != values[i-1] - 1:
                straight = False
                break
        if not straight and values == [14,5,4,3,2]:
            straight = True
            values = [5,4,3,2,1]

        # Check hand types
        value_counts = {}
        for v in values:
            value_counts[v] = value_counts.get(v, 0) + 1
        sorted_counts = sorted(value_counts.items(), key=lambda x: (x[1], x[0]), reverse=True)
        count_vals = [item[0] for item in sorted_counts]
        count_freq = [item[1] for item in sorted_counts]

        if straight and flush:
            return (8, values[0], 0, 0, 0, 0)
        elif count_freq[0] == 4:
            return (7, count_vals[0], count_vals[1], 0, 0, 0)
        elif count_freq[0] == 3 and count_freq[1] == 2:
            return (6, count_vals[0], count_vals[1], 0, 0, 0)
        elif flush:
            return (5, *values, 0)[:6]
        elif straight:
            return (4, values[0], 0, 0, 0, 0)
        elif count_freq[0] == 3:
            return (3, count_vals[0], count_vals[1], count_vals[2], 0, 0)
        elif count_freq[0] == 2 and count_freq[1] == 2:
            return (2, count_vals[0], count_vals[1], count_vals[2], 0, 0)
        elif count_freq[0] == 2:
            kickers = [v for v in values if v != count_vals[0]]
            return (1, count_vals[0], *kickers[:3], 0)[:6]
        else:
            return (0, *values, 0)[:6]

    @staticmethod
    def evaluate_hand(seven_cards):
        best_value = None
        for combo in itertools.combinations(seven_cards, 5):
            hand_value = SimplePlayer.get_hand_value(combo)
            if best_value is None or hand_value > best_value:
                best_value = hand_value
        return best_value

    @staticmethod
    def estimate_win_probability(my_hand, community_cards, num_players, n_simulations):
        num_opponents = num_players - 1
        if num_opponents <= 0:
            return 1.0
            
        wins = 0.0
        deck = SimplePlayer.create_deck()
        
        # Remove known cards
        known_cards = my_hand + community_cards
        for card in known_cards:
            if card in deck:
                deck.remove(card)
                
        for _ in range(n_simulations):
            sim_deck = deck.copy()
            random.shuffle(sim_deck)
            
            # Complete community cards
            comm_needed = 5 - len(community_cards)
            full_community = community_cards + [sim_deck.pop() for _ in range(comm_needed)]
            
            # Deal opponents' hands
            opp_hands = []
            for _ in range(num_opponents):
                opp_hands.append([sim_deck.pop(), sim_deck.pop()])
                
            # Evaluate our hand
            our_value = SimplePlayer.evaluate_hand(my_hand + full_community)
            
            # Evaluate opponents' hands
            best_opp = None
            for hand in opp_hands:
                hand_value = SimplePlayer.evaluate_hand(hand + full_community)
                if best_opp is None or hand_value > best_opp:
                    best_opp = hand_value
                    
            # Compare hands
            if our_value > best_opp:
                wins += 1.0
            elif our_value == best_opp:
                wins += 0.5
                
        return wins / n_simulations

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        player_actions = round_state.player_actions
        for player_id, action in player_actions.items():
            if player_id == self.id:
                continue
            if action in ['Raise', 'AllIn']:
                self.opponent_aggression[player_id] = self.opponent_aggression.get(player_id, 0) + 1
            if action == 'Fold':
                self.opponent_fold_rate[player_id] = self.opponent_fold_rate.get(player_id, 0) + 1

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        self.opponent_aggression = {}
        self.opponent_fold_rate = {}