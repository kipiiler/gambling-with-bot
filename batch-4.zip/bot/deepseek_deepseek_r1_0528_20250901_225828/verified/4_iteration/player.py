from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import itertools

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.initial_hand = []
        self.big_blind = 0
        self.small_blind = 0
        self.players = []
        self.position = 0
        self.player_sorted_positions = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.initial_hand = player_hands  # Store hands for position reference
        self.big_blind = blind_amount
        self.small_blind = blind_amount // 2
        self.players = all_players
        self.set_position(big_blind_player_id, small_blind_player_id, all_players)

    def set_position(self, big_blind_id, small_blind_id, all_players):
        """Determine position relative to blinds for position-based strategy"""
        player_count = len(all_players)
        # Button to SB to BB to UTG positions
        try:
            bb_index = all_players.index(big_blind_id)
            sb_index = all_players.index(small_blind_id)
            button_index = (sb_index - 1) % player_count
            
            self.player_sorted_positions = []
            current = (button_index + 1) % player_count
            for i in range(player_count):
                self.player_sorted_positions.append(all_players[current])
                current = (current + 1) % player_count
            
            self.position = self.player_sorted_positions.index(self.id)
        except:
            self.position = 0
            self.player_sorted_positions = all_players

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset hand- and round-specific tracking variables here
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            player_id_str = str(self.id)
            
            # Current commitment to pot
            current_commitment = round_state.player_bets.get(player_id_str, 0)
            to_call = round_state.current_bet - current_commitment
            
            # Find pot odds delta to avoid division by zero
            pot_odds = to_call / (round_state.pot + to_call + 1e-8) if to_call > 0 else 0
            
            # Position-adjusted hand strength calculation (0-1 scale)
            hand_strength = self.calculate_hand_strength(
                self.initial_hand, 
                round_state.community_cards, 
                self.position,
                round_state.round
            )
            
            # Action decision tree
            return self.action_decision(
                round_state, 
                remaining_chips, 
                to_call, 
                pot_odds, 
                hand_strength
            )
        except:
            # Safety fallback to fold on any error
            return PokerAction.FOLD, 0

    def action_decision(self, round_state, remaining, to_call, pot_odds, strength):
        player_id_str = str(self.id)
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        position_ratio = self.position / len(self.player_sorted_positions)  # 0=early, 1=late
        
        # Determine aggression factor: more aggressive with strong hands and in late position
        aggression = min(strength * (0.7 + position_ratio * 0.5), 0.95)
        
        # Pre-flop strategy
        if round_state.round == 'Preflop':
            hand_category = self.classify_hand(self.initial_hand)
            
            # Premium hands (top 5%)
            if hand_category >= 4:  
                if to_call == 0:
                    # Open with strong raise from any position
                    raise_amt = min(max(min_raise, 5 * self.big_blind), max_raise)
                    return PokerAction.RAISE, raise_amt
                else:
                    # Reraise against aggression with premium hands
                    return PokerAction.RAISE, min(max(min_raise, to_call * 2), max_raise)
            
            # Strong hands (next 15%)
            elif hand_category == 3 and position_ratio > 0.3:
                if to_call == 0:
                    # Raise with strong hands in position
                    raise_amt = min(max(min_raise, 3 * self.big_blind), max_raise)
                    return PokerAction.RAISE, raise_amt
                elif pot_odds < 0.25:  # Call small raises
                    return PokerAction.CALL, 0
            
            # Speculative hands (suited connectors, small pairs)
            elif hand_category == 2 and position_ratio > 0.6 and to_call == 0:
                return PokerAction.CALL, 0
            
            # Default to fold
            return PokerAction.FOLD, 0
            
        # Post-flop strategy
        else:
            # With very strong hands (top 10%), aggressive play
            if strength > 0.8:
                if to_call == 0:
                    # Bet for value: 50-100% of pot
                    bet_amt = min(max(min_raise, round_state.pot // 2), max_raise)
                    return PokerAction.RAISE, bet_amt
                else:
                    # Raise against bets with strong hands
                    return PokerAction.RAISE, min(max(min_raise, to_call * 2), max_raise)
            
            # With medium strength or fast-playing strong hands
            elif strength > 0.5:
                if to_call == 0:
                    # Check or small bet for pot control
                    return PokerAction.CHECK, 0
                elif pot_odds < 0.3:  # Call reasonable bets
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
            
            # Draw continuation
            elif strength > 0.25:
                # Calculate drawing odds - convert to percentage
                odds = self.calculate_draw_odds(self.initial_hand, round_state.community_cards)
                
                if to_call == 0 and aggression > 0.6:
                    # Semi-bluff with draws if in position
                    return PokerAction.RAISE, min_raise
                elif odds > pot_odds:  # Positive expected value
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0
                    
            # Weak hands: tighten up
            else:
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    return PokerAction.FOLD, 0

    def classify_hand(self, hand) -> int:
        """Rate hand strength from 0 (weak) to 4 (premium)"""
        cards = hand if hand else [None, None]
        if not cards[0] or not cards[1]:
            return 0
            
        ranks = [c[0] for c in hand]
        suits = [c[1] for c in hand]
        high_cards = any(r in ranks for r in ['A','K','Q'])
        paired = ranks[0] == ranks[1]
        suited = suits[0] == suits[1]
        
        # Premium combinations
        if paired and ranks[0] in ['A','K','Q']:
            return 4
        if not paired and 'A' in ranks and 'K' in ranks:
            return 4 if suited else 3
        if paired and ranks[0] in ['J','T'] and suited:
            return 3
        if not paired and 'A' in ranks and 'Q' in ranks and suited:
            return 3
        if not paired and 'A' in ranks and 'J' in ranks and suited:
            return 2
        if paired and ranks[0] in ['T','9','8']:
            return 2
        if suited and 'K' in ranks and 'Q' in ranks:
            return 2
        if high_cards:
            return 1
        return 0

    def calculate_draw_odds(self, hand, board) -> float:
        """Estimate odds for completing a draw"""
        if not board or len(board) < 3:
            return 0.0
            
        suit_counts = {}
        all_cards = hand + board
        for card in all_cards:
            suit = card[1]
            suit_counts[suit] = suit_counts.get(suit, 0) + 1

        flush_draw = any(count == 4 for count in suit_counts.values())
        
        outs = 0
        complete_cards = 5 - len(board)  # Cards to come
        
        # Flush draw calculation
        if flush_draw:
            suit_needed = [s for s, count in suit_counts.items() if count == 4][0]
            outs = 13 - 4  # Remaining cards of needed suit
        
        return outs / (46 - complete_cards + 1e-8)  # Probability of hitting

    def calculate_hand_strength(self, hand, board, position, round_name) -> float:
        """Calculate relative hand strength (0-1) with position weighting"""
        if not hand:
            return 0.0
            
        all_cards = hand + board
        if len(all_cards) < 5:
            return self.classify_hand(hand) / 4 * 0.4  # Scale down pre-flop evaluation
            
        # Quaternary scoring system: hand rank + high cards
        base_score = 0
        ranks = []
        rank_mapping = {'2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,
                        'T':10,'J':11,'Q':12,'K':13,'A':14}
        
        for card in all_cards:
            if len(card) != 2: 
                continue
            ranks.append(rank_mapping.get(card[0], 2))
        ranks.sort(reverse=True)

        # Score most significant with highest ranked card
        for i, rank in enumerate(ranks[:5]):
            base_score += rank * (15 ** (4-i))  # Quindesimal system
            
        # Position bonus (0-20% strength boost)
        position_bonus = (position / 6) * 0.2
        
        # Round weighting - value hands earlier
        round_weights = {'Preflop': 0.1, 'Flop': 0.3, 'Turn': 0.7, 'River': 1.0}
        return min((base_score / (15**5 * 5)) * round_weights.get(round_name, 1.0) + position_bonus, 1.0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Learning/updating strategy based on round outcome can be added here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final game processing - save statistics or adjust strategy
        pass