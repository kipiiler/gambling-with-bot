from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.player_hands = []
        self.blind_amount = 0
        self.big_blind_player_id = 0
        self.small_blind_player_id = 0
        self.all_players = []
        self.round_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.round_count = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.round_count += 1

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Basic strategy: play tight, aggressive
        # Only play premium hands aggressively, fold everything else
        
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        
        # Preflop strategy
        if round_state.round == 'Preflop':
            # Premium hands: AA, KK, QQ, JJ, AK
            hand = self.player_hands
            if len(hand) < 2:
                return (PokerAction.FOLD, 0)
            
            card1, card2 = hand[0], hand[1]
            rank1, suit1 = card1[0], card1[1]
            rank2, suit2 = card2[0], card2[1]
            
            # Check if pocket pair
            is_pair = rank1 == rank2
            is_high_pair = is_pair and rank1 in ['A', 'K', 'Q', 'J']
            
            # Check if high cards
            is_high_cards = (rank1 in ['A', 'K', 'Q']) and (rank2 in ['A', 'K', 'Q'])
            
            # Play premium hands aggressively
            if is_high_pair or is_high_cards:
                if to_call > 0:
                    # Raise aggressively
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.1)))
                    return (PokerAction.RAISE, raise_amount)
                else:
                    # No need to call, check or raise
                    return (PokerAction.CHECK, 0)
            else:
                # Fold everything else
                if to_call > 0:
                    return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.CHECK, 0)
        
        # Post-flop strategy
        else:
            # Simplified: if we have a decent hand, play; otherwise fold
            # This is a placeholder - in reality, you'd evaluate your hand strength
            
            # For now, if there's a bet, call small bets, fold big ones
            if to_call > 0:
                # If the bet is small relative to our stack, call
                if to_call <= remaining_chips * 0.1:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            else:
                return (PokerAction.CHECK, 0)
        
        # Default fallback
        if to_call > 0:
            return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No action needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No action needed
        pass