from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.hand_history = []
        self.position = 0
        self.is_big_blind = False
        self.is_small_blind = False
        self.num_players = 0
        self.player_count = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_count = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.num_players = len(round_state.current_player)

    def evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        # Simplified hand strength evaluator
        # In a real implementation, this would be more complex
        high_card_value = 0
        for card in hole_cards:
            rank = card[0]
            if rank == 'A':
                high_card_value = max(high_card_value, 14)
            elif rank == 'K':
                high_card_value = max(high_card_value, 13)
            elif rank == 'Q':
                high_card_value = max(high_card_value, 12)
            elif rank == 'J':
                high_card_value = max(high_card_value, 11)
            elif rank.isdigit():
                high_card_value = max(high_card_value, int(rank))
        return high_card_value / 14.0

    def calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        if call_amount <= 0:
            return 1.0
        total_cost = call_amount
        total_pot = pot_size + total_cost
        return total_cost / (total_pot + 1e-8)  # Add small epsilon to prevent division by zero

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        hole_cards = []
        # Try to get hole cards from player_hands if available, but since it's not in RoundStateClient, we'll proceed with general strategy
        current_bet = round_state.current_bet
        my_current_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_current_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        pot_size = round_state.pot
        round_name = round_state.round.lower()
        community_cards = round_state.community_cards

        # Calculate pot odds
        pot_odds = self.calculate_pot_odds(call_amount, pot_size)

        # Estimate hand strength (simplified)
        hand_strength = self.evaluate_hand_strength(hole_cards, community_cards)

        # Position awareness would require more information, but we can infer from player order
        # We'll use a basic strategy based on round and hand strength
        aggressive_factor = 0.6 + (self.player_count - self.num_players) * 0.1  # More aggressive when fewer players

        # Preflop strategy
        if round_name == "preflop":
            # Basic preflop hand classification
            # This is overly simplified and would be enhanced in a real bot
            high_card_1 = hole_cards[0][0] if hole_cards else '2'
            high_card_2 = hole_cards[1][0] if len(hole_cards) > 1 else '2'
            
            # A very simple proxy: if we have pocket pairs or high cards
            is_pair = high_card_1 == high_card_2
            is_high_card = high_card_1 in ['A', 'K', 'Q', 'J'] or high_card_2 in ['A', 'K', 'Q', 'J']

            if is_pair or is_high_card:
                if call_amount == 0:
                    if min_raise <= remaining_chips:
                        return (PokerAction.RAISE, min(min_raise * 3, max_raise))
                    else:
                        return (PokerAction.ALL_IN, 0)
                elif pot_odds < 0.33:
                    if min_raise <= remaining_chips:
                        return (PokerAction.RAISE, min(min_raise * 3, max_raise))
                    else:
                        return (PokerAction.ALL_IN, 0)
                else:
                    if call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Weak hand
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif pot_odds < 0.2:
                    if call_amount <= remaining_chips:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Post-flop strategy
        else:
            # Combine hand strength with pot odds
            if hand_strength > pot_odds * aggressive_factor:
                if call_amount == 0:
                    # We can check or bet
                    if hand_strength > 0.7:
                        bet_size = min(max_raise, max(100, int(pot_size * 0.75)))
                        if bet_size > 0:
                            return (PokerAction.RAISE, bet_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)
                else:
                    if hand_strength > 0.8:
                        # Very strong hand, raise aggressively
                        if min_raise <= remaining_chips:
                            return (PokerAction.RAISE, min(min_raise * 3, max_raise))
                        else:
                            return (PokerAction.ALL_IN, 0)
                    elif pot_odds < 0.3:
                        # Good pot odds, call
                        if call_amount <= remaining_chips:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Default to fold on uncertain or weak hands
                        return (PokerAction.FOLD, 0)
            else:
                # Hand likely not good enough
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

        # Default action if no condition is met
        if call_amount == 0:
            return (PokerAction.CHECK, 0)
        elif call_amount > remaining_chips:
            return (PokerAction.FOLD, 0)
        else:
            return (PokerAction.CALL, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: track round results for learning
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: track game statistics for future improvements
        pass