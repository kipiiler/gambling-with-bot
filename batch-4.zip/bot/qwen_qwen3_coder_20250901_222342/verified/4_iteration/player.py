import random
from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.my_position = 0  # 0 = button, 1 = small blind, 2 = big blind
        self.total_players = 0
        self.aggression_factor = 0.5  # How often to bluff/raise
        self.tightness_factor = 0.6   # How good hands to play
        self.opponent_tight = True     # Assume opponent is tight initially

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.total_players = len(all_players)
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Determine our position
        if self.id == small_blind_player_id:
            self.my_position = 1
        elif self.id == big_blind_player_id:
            self.my_position = 2
        else:
            self.my_position = 0  # Button or other position
            
        # Reset per-round variables if needed
        pass

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate hand strength from 0 (worst) to 1 (best)"""
        if not hole_cards:
            return 0.0
            
        # Simple hand ranking based on card values and potential
        ranks = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        card_ranks = [card[0] for card in hole_cards]
        card_suits = [card[1] for card in hole_cards]
        
        # Add community cards if available
        if community_cards:
            card_ranks.extend([card[0] for card in community_cards])
            card_suits.extend([card[1] for card in community_cards])
        
        # Basic hand evaluation
        rank_values = [ranks[r] if r in ranks else 0 for r in card_ranks]
        
        # High card strength (aces and kings are strong)
        high_card_strength = sum(1 for r in rank_values if r >= 13) / len(rank_values) if rank_values else 0
        
        # Pair strength
        pair_strength = 0
        unique_ranks = list(set(rank_values))
        if len(unique_ranks) < len(rank_values):
            pair_strength = 0.3  # Some strength for pairs
            
        # Flush potential
        flush_strength = 0
        if len(card_suits) >= 5:
            suit_counts = {}
            for suit in card_suits:
                suit_counts[suit] = suit_counts.get(suit, 0) + 1
            max_suit_count = max(suit_counts.values()) if suit_counts else 0
            if max_suit_count >= 5:
                flush_strength = 0.8
            elif max_suit_count >= 4:
                flush_strength = 0.4
            elif max_suit_count >= 3:
                flush_strength = 0.2
        
        # Straight potential
        straight_strength = 0
        if len(rank_values) >= 5:
            sorted_ranks = sorted(set(rank_values))
            if len(sorted_ranks) >= 5:
                # Check for straight
                consecutive = 0
                for i in range(len(sorted_ranks)-1):
                    if sorted_ranks[i+1] == sorted_ranks[i] + 1:
                        consecutive += 1
                    else:
                        consecutive = 0
                    if consecutive >= 4:
                        straight_strength = 0.7
                        break
                        
        # Combine strengths with weights
        total_strength = (high_card_strength * 0.3 + 
                         pair_strength * 0.3 + 
                         flush_strength * 0.2 + 
                         straight_strength * 0.2)
                         
        return min(total_strength, 1.0)

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine action before the flop"""
        hole_cards = self.hole_cards
        
        if not hole_cards:
            return (PokerAction.FOLD, 0)
            
        # Extract card ranks and suits
        rank1, suit1 = hole_cards[0][0], hole_cards[0][1]
        rank2, suit2 = hole_cards[1][0], hole_cards[1][1]
        
        # Position-based strategy
        is_button = self.my_position == 0
        is_small_blind = self.my_position == 1
        is_big_blind = self.my_position == 2
        
        # Hand strength categories
        premium_hands = ['AA', 'KK', 'QQ', 'JJ', 'AK']
        strong_hands = ['TT', '99', '88', '77', 'AQ', 'AJ', 'AT', 'KQ']
        playable_hands = ['66', '55', '44', '33', '22', 'A9', 'A8', 'A7', 'A6', 'A5', 'A4', 'A3', 'A2', 'KJ', 'KT', 'K9', 'QJ', 'QT', 'JT']
        
        # Create hand string for comparison
        hand_string = ""
        if rank1 == rank2:  # Pocket pair
            hand_string = rank1 + rank2
        elif rank1 > rank2:
            hand_string = rank1 + rank2
        else:
            hand_string = rank2 + rank1
            
        # Add suited indicator
        if suit1 == suit2 and rank1 != rank2:
            hand_string += 's'
            
        # Determine action based on hand strength and position
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Check if we can raise
        can_raise = max_raise >= min_raise
        
        # Premium hands - always play
        if hand_string in premium_hands or (rank1 in ['A', 'K'] and rank2 in ['A', 'K']):
            if current_bet == 0 and can_raise:
                # Raise aggressively
                raise_amount = min(3 * min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.1:
                # Call reasonable bet
                return (PokerAction.CALL, 0)
            else:
                # Re-raise or call big bets with premium hands
                if call_amount <= remaining_chips * 0.3:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
                    
        # Strong hands
        elif hand_string in strong_hands or (rank1 in ['A', 'K'] and rank2 in ['Q', 'J', 'T']):
            if current_bet == 0 and can_raise:
                # Raise moderately
                raise_amount = min(2 * min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.15:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Playable hands
        elif hand_string in playable_hands or (rank1 in ['A'] and rank2 in ['9', '8', '7', '6', '5', '4', '3', '2']):
            if current_bet == 0 and can_raise and (is_button or is_small_blind):
                # Try to steal blinds in position
                raise_amount = min(min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.1:
                # Call small bets with playable hands
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Marginal hands - only play in position or with no bet
        else:
            if current_bet == 0 and can_raise and is_button:
                # Try to steal blinds with any two cards from button
                raise_amount = min(min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.05:
                # Call very small bets
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Determine action after the flop"""
        hole_cards = self.hole_cards
        community_cards = round_state.community_cards
        
        if not hole_cards:
            return (PokerAction.FOLD, 0)
            
        # Evaluate hand strength
        hand_strength = self._evaluate_hand_strength(hole_cards, community_cards)
        
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        call_amount = current_bet - my_bet
        min_raise = round_state.min_raise
        max_raise = round_state.max_raise
        
        # Check if we can raise
        can_raise = max_raise >= min_raise
        
        # Position-based strategy
        is_button = self.my_position == 0
        is_small_blind = self.my_position == 1
        is_big_blind = self.my_position == 2
        
        # Determine pot odds
        pot_size = round_state.pot
        pot_odds = call_amount / (pot_size + call_amount) if (pot_size + call_amount) > 0 else 0
        
        # Strong hand strategy
        if hand_strength > 0.7:
            if current_bet == 0 and can_raise:
                # Strong hand, bet for value
                raise_amount = min(2 * min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.25:
                # Call reasonable bets with strong hands
                return (PokerAction.CALL, 0)
            else:
                # All-in with very strong hands
                return (PokerAction.ALL_IN, 0)
                
        # Medium strength hand
        elif hand_strength > 0.4:
            if current_bet == 0 and can_raise and (is_button or is_small_blind):
                # Bet for value or protection
                raise_amount = min(min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount <= remaining_chips * 0.15:
                # Call small to medium bets
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        # Weak hand
        else:
            if current_bet == 0 and can_raise and is_button:
                # Try to bluff in position
                raise_amount = min(min_raise, max_raise, remaining_chips)
                return (PokerAction.RAISE, raise_amount)
            elif call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif pot_odds < 0.2 and call_amount <= remaining_chips * 0.1:
                # Call small bets with drawing hands
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Parse hole cards from player_hands if available
            if hasattr(round_state, 'player_hands') and round_state.player_hands:
                self.hole_cards = round_state.player_hands.get(str(self.id), [])
            
            # Determine which round we're in
            if round_state.round == 'Preflop':
                return self._get_preflop_action(round_state, remaining_chips)
            else:
                return self._get_postflop_action(round_state, remaining_chips)
                
        except Exception as e:
            # Fallback to safe play
            current_bet = round_state.current_bet
            my_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = current_bet - my_bet
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount <= remaining_chips * 0.1:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Could track opponent behavior here for future improvements
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game is over, could analyze results for future improvements
        pass