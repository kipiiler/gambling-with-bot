from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from type.poker_round import PokerRound
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.my_hand = []
        self.all_players = []
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.blind_amount = 10
        self.position = 0  # 0 = early, 1 = middle, 2 = late
        self.player_count = 0
        self.hand_history = []

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.my_hand = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.player_count = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Determine position (simplified for heads-up)
        if self.player_count == 2:
            if self.id == self.big_blind_player_id:
                self.position = 0  # Out of position
            else:
                self.position = 2  # In position
        else:
            # For multi-way, determine approximate position
            active_players = len(round_state.current_player)
            if active_players <= 3:
                self.position = 2  # Late position
            elif active_players <= 3:
                self.position = 1  # Middle position
            else:
                self.position = 0  # Early position

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Evaluate the strength of our hand (0.0 to 1.0)"""
        if not hole_cards:
            return 0.0
            
        # Simplified hand evaluation
        rank_values = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, 
                      '9': 9, 'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        
        # Extract ranks and suits
        hole_ranks = [card[0] for card in hole_cards]
        hole_suits = [card[1] for card in hole_cards]
        
        # High card values
        high_card1 = rank_values[hole_ranks[0]]
        high_card2 = rank_values[hole_ranks[1]]
        
        # Pair bonus
        pair_bonus = 0
        if hole_ranks[0] == hole_ranks[1]:
            pair_bonus = 0.2 + (high_card1 / 14) * 0.3
            
        # High card bonus
        high_card_value = max(high_card1, high_card2) / 14
        secondary_card_value = min(high_card1, high_card2) / 28  # Weight less
        
        # Suited bonus
        suited_bonus = 0.1 if hole_suits[0] == hole_suits[1] else 0
        
        # Connector bonus (consecutive cards)
        connector_bonus = 0
        rank_diff = abs(high_card1 - high_card2)
        if rank_diff == 1:  # Connected
            connector_bonus = 0.05
        elif rank_diff == 2:  # One gap
            connector_bonus = 0.03
        elif rank_diff == 3:  # Two gaps
            connector_bonus = 0.01
            
        # Community cards factor
        community_factor = min(len(community_cards) * 0.1, 0.3)
        
        # Base strength calculation
        strength = (high_card_value * 0.5 + secondary_card_value * 0.3 + 
                   pair_bonus * 0.7 + suited_bonus * 0.2 + connector_bonus * 0.1 + 
                   community_factor)
        
        # Cap at 1.0
        return min(strength, 1.0)

    def _calculate_pot_odds(self, call_amount: int, pot_size: int) -> float:
        """Calculate pot odds - the ratio of call amount to potential winnings"""
        if call_amount <= 0:
            return 1.0
        return call_amount / (pot_size + call_amount)

    def _is_aggressive_opponent(self, player_id: str, round_state: RoundStateClient) -> bool:
        """Determine if opponent is playing aggressively"""
        if not hasattr(round_state, 'player_actions') or not round_state.player_actions:
            return False
            
        aggressive_actions = 0
        total_actions = 0
        
        # This is a simplified check - in reality we'd track over multiple hands
        return False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Get the amount we need to call
            my_current_bet = round_state.player_bets.get(str(self.id), 0)
            call_amount = round_state.current_bet - my_current_bet
            
            # Evaluate our hand strength
            hand_strength = self._evaluate_hand_strength(self.my_hand, round_state.community_cards)
            
            # Calculate pot odds
            pot_odds = self._calculate_pot_odds(call_amount, round_state.pot)
            
            # Determine round
            round_name = round_state.round.lower()
            if round_name == 'preflop':
                poker_round = PokerRound.PREFLOP
            elif round_name == 'flop':
                poker_round = PokerRound.FLOP
            elif round_name == 'turn':
                poker_round = PokerRound.TURN
            else:  # river
                poker_round = PokerRound.RIVER
            
            # Position-based strategy modifier
            position_modifier = 1.0
            if self.position == 2:  # Late position
                position_modifier = 1.2
            elif self.position == 0:  # Early position
                position_modifier = 0.8
                
            # Stack size considerations
            stack_ratio = remaining_chips / self.starting_chips if self.starting_chips > 0 else 1
            
            # Adjust hand strength based on game state
            adjusted_strength = hand_strength
            
            # Preflop strategy
            if poker_round == PokerRound.PREFLOP:
                # Premium hands
                if hand_strength > 0.7:
                    if call_amount == 0:
                        raise_amount = min(max(round_state.min_raise, int(remaining_chips * 0.03)), round_state.max_raise)
                        return (PokerAction.RAISE, raise_amount)
                    elif hand_strength > pot_odds * position_modifier:
                        if call_amount < remaining_chips * 0.1:
                            return (PokerAction.CALL, 0)
                        elif call_amount < remaining_chips * 0.3:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Speculative hands in late position
                elif hand_strength > 0.4 and self.position >= 1:
                    if call_amount == 0:
                        return (PokerAction.CALL, 0)  # Limp in
                    elif pot_odds < 0.33:  # Getting good price
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Weak hands
                else:
                    if call_amount == 0:
                        # We can steal blinds in late position
                        if self.position == 2 and len(round_state.current_player) <= 3:
                            raise_amount = min(max(round_state.min_raise, int(remaining_chips * 0.02)), round_state.max_raise)
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            
            # Post-flop strategy
            else:
                # Strong hands
                if hand_strength > 0.7:
                    if call_amount == 0:
                        raise_amount = min(max(round_state.min_raise, int(round_state.pot * 0.75)), round_state.max_raise)
                        return (PokerAction.RAISE, raise_amount)
                    elif hand_strength > pot_odds * 1.5:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Medium strength hands
                elif hand_strength > 0.4:
                    if call_amount == 0:
                        # Continuation bet with position
                        if self.position == 2:
                            raise_amount = min(max(round_state.min_raise, int(round_state.pot * 0.5)), round_state.max_raise)
                            return (PokerAction.RAISE, raise_amount)
                        else:
                            return (PokerAction.CHECK, 0)
                    elif hand_strength > pot_odds:
                        # Call if getting the right price
                        if call_amount < remaining_chips * 0.2:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                # Weak hands
                else:
                    if call_amount == 0:
                        # Bluff in late position sometimes
                        if self.position == 2 and len(round_state.current_player) <= 2:
                            if hand_strength > 0.2 and round_state.pot < 100:  # Small pot
                                raise_amount = min(max(round_state.min_raise, int(round_state.pot * 0.5)), round_state.max_raise)
                                return (PokerAction.RAISE, raise_amount)
                            else:
                                return (PokerAction.CHECK, 0)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        # Fold weak hands when facing bets
                        return (PokerAction.FOLD, 0)
                        
            # Fallback actions - should never reach here but just in case
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            elif call_amount < remaining_chips * 0.05:
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)
                
        except Exception as e:
            # If any error occurs, play safe
            try:
                my_current_bet = round_state.player_bets.get(str(self.id), 0)
                call_amount = round_state.current_bet - my_current_bet
                
                if call_amount == 0:
                    return (PokerAction.CHECK, 0)
                elif call_amount < remaining_chips * 0.05:
                    return (PokerAction.CALL, 0)
                else:
                    return (PokerAction.FOLD, 0)
            except:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Store hand result for future analysis if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, could store final statistics
        pass