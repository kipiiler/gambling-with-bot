from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_cards = []
        self.starting_chips = 0
        self.player_id = None
        self.all_player_ids = []
        
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.hand_cards = player_hands
        self.player_id = None  # Will be set by the game server
        self.all_player_ids = all_players
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # This method was causing the error - it was referencing undefined variables
        # We just need to implement it properly without referencing undefined variables
        pass
        
    def _evaluate_hand_strength(self, hand: List[str], community_cards: List[str]) -> float:
        """Evaluate the strength of our hand (simplified)"""
        # Very basic hand evaluation - in a real implementation, this would be much more sophisticated
        if not community_cards:
            # Preflop - just evaluate hole cards
            rank1 = hand[0][0]
            rank2 = hand[1][0]
            
            # Pocket pairs are strong
            if rank1 == rank2:
                return 0.7 + (['2','3','4','5','6','7','8','9','T','J','Q','K','A'].index(rank1) / 15.0) * 0.3
            
            # High cards
            high_card_value = 0
            if rank1 in ['T','J','Q','K','A'] or rank2 in ['T','J','Q','K','A']:
                high_card_value += 0.2
            if rank1 == 'A' or rank2 == 'A':
                high_card_value += 0.1
                
            return 0.3 + high_card_value
        
        # Post-flop - very basic evaluation
        return 0.5  # Default to middle strength
        
    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """Returns the action for the player."""
        try:
            # Get our current bet
            our_bet = round_state.player_bets.get(str(self.id), 0)
            
            # Calculate how much we need to call
            call_amount = round_state.current_bet - our_bet
            
            # Evaluate hand strength
            hand_strength = self._evaluate_hand_strength(self.hand_cards, round_state.community_cards)
            
            # Simple strategy based on hand strength and position
            if round_state.round == 'Preflop':
                # Preflop strategy
                if hand_strength > 0.8:
                    # Strong hand - raise aggressively
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.3)))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > 0.6:
                    # Medium hand - call or small raise
                    if call_amount <= remaining_chips * 0.1:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand - fold or call small amounts
                    if call_amount <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
            else:
                # Post-flop strategy
                if hand_strength > 0.7:
                    # Strong hand - raise
                    raise_amount = min(round_state.max_raise, max(round_state.min_raise, int(remaining_chips * 0.2)))
                    if raise_amount >= round_state.min_raise:
                        return (PokerAction.RAISE, raise_amount)
                    else:
                        return (PokerAction.CALL, 0)
                elif hand_strength > 0.4:
                    # Medium hand - call
                    if call_amount <= remaining_chips * 0.15:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                else:
                    # Weak hand - fold unless cheap to call
                    if call_amount <= remaining_chips * 0.05:
                        return (PokerAction.CALL, 0)
                    else:
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # If any error occurs, fold as a safe default
            return (PokerAction.FOLD, 0)
        
    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """Called at the end of the round."""
        # We can track information about the round here if needed
        pass
        
    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """Called at the end of the game."""
        # We can analyze the game results here if needed
        pass