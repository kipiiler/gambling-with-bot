from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_id = None
        self.small_blind_id = None
        self.all_players = []
        self.player_hands = {}
        self.hand_strength = 0.0
        self.positional_advantage = 0.0
        self.current_round = None
        self.volatility_factor = 1.0
        self.fold_threshold = 0.3
        self.call_threshold = 0.5
        self.raise_threshold = 0.7
        self.all_in_threshold = 0.9
        self.tight_aggressive = True  # Use tighter ranges with aggressive betting when strong
        self.equity_boost = 1.0  # Modify based on board texture and position

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): None for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_id = big_blind_player_id
        self.small_blind_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength = 0.0
        self.volatility_factor = 1.0
        self.equity_boost = 1.0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round
        my_hand = self.player_hands.get(str(self.id), [])
        if isinstance(my_hand, str):
            my_hand = [my_hand]
        community_cards = round_state.community_cards

        # Update hand strength estimation
        self.hand_strength = self.estimate_hand_strength(my_hand, community_cards)
        self.volatility_factor = self.calculate_board_volatility(community_cards)
        self.equity_boost = self.determine_equity_boost(my_hand, community_cards, round_state)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            pot_odds = self.calculate_pot_odds(round_state, remaining_chips)
            effective_hand_strength = self.hand_strength * self.equity_boost
            aggression_factor = self.calculate_aggression_factor(round_state, effective_hand_strength, pot_odds)
            num_players_in_pot = sum(1 for pid in round_state.player_bets if round_state.player_bets[pid] > 0)

            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            my_current_bet = round_state.player_bets.get(str(self.id), 0)

            # If no bet, default to check or bet
            if current_bet == 0:
                if aggression_factor > 0.7 and remaining_chips > 0:
                    bet_amount = min(int(self.starting_chips * 0.05), remaining_chips)
                    bet_amount = max(min_raise, bet_amount)
                    return PokerAction.RAISE, bet_amount
                return PokerAction.CHECK, 0

            # Calculate amount needed to call
            to_call = current_bet - my_current_bet
            if to_call <= 0:
                return PokerAction.CHECK, 0

            # Fold if too weak
            if effective_hand_strength < self.fold_threshold:
                return PokerAction.FOLD, 0

            # Call if marginal
            if effective_hand_strength < self.call_threshold:
                if to_call <= remaining_chips:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0

            # Raise if strong
            if effective_hand_strength >= self.raise_threshold:
                if to_call >= remaining_chips * 0.5 and effective_hand_strength < self.all_in_threshold:
                    return PokerAction.CALL, 0  # Avoid over-committing without nuts
                if min_raise <= max_raise and min_raise > 0:
                    raise_amount = min(
                        max(
                            int((current_bet + to_call) * (1 + aggression_factor)),
                            min_raise
                        ),
                        max_raise
                    )
                    if raise_amount >= remaining_chips * 0.8 and effective_hand_strength >= self.all_in_threshold:
                        return PokerAction.ALL_IN, 0
                    return PokerAction.RAISE, raise_amount

            # Default to call if unsure
            if to_call <= remaining_chips:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0
        except Exception as e:
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Optional: Track win/loss patterns or adjust strategy
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Optional: Final cleanup or metrics logging
        pass

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate the strength of your hand using basic heuristics and probabilities."""
        if not hole_cards:
            return 0.0
        combined = hole_cards + community_cards
        hand_len = len(combined)

        # Immediate evaluation
        if hand_len >= 5:
            hand_value = self.evaluate_hand(combined)
            max_value = 9  # Max hand value (straight flush)
            return hand_value / max_value if max_value > 0 else 0.0

        # Pre-flop hand strength using known preflop rankings
        if hand_len == 2:
            return self.preflop_hand_strength(hole_cards)

        # Post-flop: estimate outs and chances of improvement
        return self.postflop_draw_strength(hole_cards, community_cards)

    def preflop_hand_strength(self, hole_cards: List[str]) -> float:
        """Use approximate Sklansky hand groups or Chen formula equivalents."""
        ranks = [self.card_rank(card) for card in hole_cards]
        suits = [card[-1] for card in hole_cards]

        # Pair?
        if ranks[0] == ranks[1]:
            return 0.5 + (ranks[0] / 13) * 0.45  # Stronger pairs get higher score

        # Suited?
        suited = suits[0] == suits[1]
        high_card = max(ranks)
        low_card = min(ranks)
        gap = high_card - low_card

        base = high_card / 13 * 0.4
        if suited:
            base += 0.1
        if gap <= 1:
            base += (1 - gap) * 0.15  # Connected cards are better

        # Apply gap penalties
        if gap == 1:
            pass
        elif gap == 2:
            base -= 0.05
        elif gap == 3:
            base -= 0.1
        else:
            base -= 0.25

        # Premium non-pairs
        if high_card == 14 and low_card >= 10:  # AK, AQ, AJ
            base += 0.1

        return max(0.05, min(base, 0.9))

    def postflop_draw_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate current strength and draw potential."""
        outs = 0
        rank_count = {}
        suit_count = {}

        all_cards = hole_cards + community_cards
        for card in all_cards:
            r = self.card_rank(card)
            s = card[-1]
            rank_count[r] = rank_count.get(r, 0) + 1
            suit_count[s] = suit_count.get(s, 0) + 1

        my_ranks = [self.card_rank(c) for c in hole_cards]
        my_suits = [c[-1] for c in hole_cards]

        # Count overcards
        community_ranks = [self.card_rank(c) for c in community_cards]
        max_community = max(community_ranks) if community_ranks else 0
        has_overpair = my_ranks[0] == my_ranks[1] and my_ranks[0] > max_community

        # Check for draws
        for suit, count in suit_count.items():
            my_suit_holds = sum(1 for s in my_suits if s == suit)
            if count + my_suit_holds == 4:  # 4 to a flush
                outs += 9
            elif count + my_suit_holds == 3:
                outs += 3

        # Straight draws
        ranks_set = set(self.card_rank(c) for c in all_cards)
        for r in ranks_set:
            straights = 0
            for i in range(1, 5):
                if (r + i) in ranks_set:
                    straights += 1
            if straights >= 3:
                outs += 8  # Open-ended
            elif straights >= 2:
                outs += 4  # Gutshot with connectors

        # Pocket pair to set
        if my_ranks[0] == my_ranks[1] and my_ranks[0] not in rank_count:
            outs += 2

        # Projected equity approximation
        equity_from_outs = min(outs * 0.02, 0.3)
        pair_equity = 0.2 if any(rank_count.get(r, 0) >= 2 for r in my_ranks) else 0.1
        overpair_bonus = 0.2 if has_overpair else 0.0

        return min(0.95, 0.05 + equity_from_outs + pair_equity + overpair_bonus)

    def evaluate_hand(self, cards: List[str]) -> int:
        """Simple hand evaluator returning strength value."""
        # This is not full ranking, but a simplified power index
        ranks = sorted([self.card_rank(c) for c in cards], reverse=True)
        suits = [c[-1] for c in cards]

        from collections import Counter
        rcount = Counter(ranks)
        scount = Counter(suits)

        # Check flush
        is_flush = any(scount[s] >= 5 for s in scount)
        # Check straight
        sorted_ranks = sorted(set(ranks), reverse=True)
        straights = 0
        for r in sorted_ranks:
            if all((r - i) in set(ranks) for i in range(5)):
                straights = r
                break

        # Hand scoring
        if straights and is_flush:
            return 9  # Straight flush
        if 4 in rcount.values():
            return 8  # Four of a kind
        if 3 in rcount.values() and 2 in rcount.values():
            return 7  # Full house
        if is_flush:
            return 6  # Flush
        if straights:
            return 5  # Straight
        if 3 in rcount.values():
            return 4  # Three of a kind
        if list(rcount.values()).count(2) >= 2:
            return 3  # Two pair
        if 2 in rcount.values():
            return 2  # One pair
        return 1  # High card

    def calculate_board_volatility(self, community_cards: List[str]) -> float:
        """Determine how dangerous or draw-heavy the board is."""
        if len(community_cards) < 3:
            return 0.0
        suit_count = {}
        ranks = [self.card_rank(c) for c in community_cards]
        for card in community_cards:
            suit = card[-1]
            suit_count[suit] = suit_count.get(suit, 0) + 1

        flush_potential = max(suit_count.values()) >= 3
        connectedness = 0
        sorted_ranks = sorted(set(ranks))
        for i in range(len(sorted_ranks) - 1):
            if sorted_ranks[i+1] - sorted_ranks[i] <= 2:
                connectedness += 1

        draws = 0
        if flush_potential:
            draws += 1
        if connectedness >= 2:
            draws += 1

        return 0.5 + (draws * 0.25)

    def determine_equity_boost(self, hole_cards: List[str], community_cards: List[str], round_state: RoundStateClient) -> float:
        """Adjust equity based on position, history, and game context."""
        # Position: late is better
        is_late_position = self.is_late_position(round_state)
        position_bonus = 0.2 if is_late_position else 0.0

        # Opponent aggressiveness (proxy via actions)
        num_checks = sum(1 for act in round_state.player_actions.values() if act == 'Check')
        num_bets = sum(1 for act in round_state.player_actions.values() if act in ['Raise', 'Bet'])

        tight_game = num_bets < num_checks and len(community_cards) > 0
        game_tightness_bonus = -0.1 if tight_game else 0.0

        # Adjust for stack depth
        stack_pressure = 0.0
        if round_state.max_raise < self.starting_chips * 0.3:
            stack_pressure = -0.2  # Short stack reduces flexibility

        return max(0.6, 1.0 + position_bonus + game_tightness_bonus + stack_pressure)

    def is_late_position(self, round_state: RoundStateClient) -> bool:
        """Determine if current player is in late position."""
        player_ids = list(round_state.player_bets.keys())
        try:
            my_index = player_ids.index(str(self.id))
            # Late if in last 30% of active players
            return my_index >= len(player_ids) * 0.7
        except ValueError:
            return False

    def calculate_pot_odds(self, round_state: RoundStateClient, remaining_chips: int) -> float:
        """Calculate pot odds (call cost / total pot after call)."""
        current_bet = round_state.current_bet
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = current_bet - my_bet
        if to_call <= 0:
            return 1.0
        pot_after_call = round_state.pot + to_call
        return to_call / (pot_after_call + 1e-8)  # Avoid division by zero

    def calculate_aggression_factor(self, round_state: RoundStateClient, hand_strength: float, pot_odds: float) -> float:
        """Determine how aggressively to bet based on strength and odds."""
        aggression = 0.0
        if hand_strength > 0.8:
            aggression = 0.7 + random.uniform(0, 0.3)  # Near optimal
        elif hand_strength > 0.6:
            aggression = 0.4 + random.uniform(0, 0.3)
        elif hand_strength > 0.4:
            aggression = 0.1 + random.uniform(0, 0.2)
        else:
            aggression = 0.0

        # Adjust based on pot odds
        if pot_odds > 0.3:  # Expensive to call
            aggression *= 0.5

        # Reduce bluffs under pressure
        num_opponents = len([pid for pid in round_state.player_bets if round_state.player_bets[pid] > 0 and pid != str(self.id)])
        if num_opponents > 1:
            aggression *= 0.8

        return aggression

    def card_rank(self, card: str) -> int:
        """Convert card rank to numeric value (Ace = 14, King = 13, ... Two = 2)."""
        rank_char = card[0]
        if rank_char == 'A':
            return 14
        elif rank_char == 'K':
            return 13
        elif rank_char == 'Q':
            return 12
        elif rank_char == 'J':
            return 11
        elif rank_char == 'T':
            return 10
        else:
            return int(rank_char)