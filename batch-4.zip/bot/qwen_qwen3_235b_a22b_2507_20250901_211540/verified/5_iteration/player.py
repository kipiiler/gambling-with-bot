from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 10000
        self.player_hands = []
        self.big_blind_amount = 10
        self.small_blind_player_id = None
        self.big_blind_player_id = None
        self.all_players = []
        self.current_round = 0
        self.our_position = None  # 0: small blind, 1: big blind
        self.hand_strength_eval = None
        self.tight_aggressive = True  # conservative early, more aggressive with position
        self.strong_hands = ['AA', 'KK', 'QQ', 'AKs', 'AKo', 'JJ', 'AQs', 'AQo']
        self.medium_hands = ['TT', '99', '88', '77', '66', '55', 'ATs', 'AJs', 'AQ', 'KQs', 'KJs', 'QJs']

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.big_blind_amount = blind_amount
        self.small_blind_player_id = small_blind_player_id
        self.big_blind_player_id = big_blind_player_id
        self.all_players = all_players
        if self.id == self.small_blind_player_id:
            self.our_position = 0
        elif self.id == self.big_blind_player_id:
            self.our_position = 1

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round = round_state.round_num
        # Reset hand strength on new round
        if round_state.round == 'Preflop':
            self.hand_strength_eval = self.evaluate_preflop_hand(self.player_hands[0]) if self.player_hands else None
        else:
            self.hand_strength_eval = None  # Will assess post-flop

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Safety check
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            our_player_id = str(self.id)
            our_current_bet = round_state.player_bets.get(our_player_id, 0)

            # Determine how much is needed to call
            to_call_amount = current_bet - our_current_bet

            # If there is no bet to call, check or bet
            if to_call_amount == 0:
                # We can check
                if self.can_raise(round_state):
                    # Consider betting based on hand strength
                    action, amount = self.decide_action(round_state, pot, community_cards, to_call_amount, current_bet, remaining_chips)
                    if action == PokerAction.RAISE:
                        # Ensure raise is valid
                        min_valid_raise = max(min_raise, current_bet + min_raise)
                        if amount < min_valid_raise:
                            amount = min_valid_raise
                        if amount > remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, amount
                    else:
                        return PokerAction.CHECK, 0
                else:
                    return PokerAction.CHECK, 0
            else:
                # We must respond to a bet
                if to_call_amount >= remaining_chips:
                    # We can only call by going all-in, or fold
                    # Decide based on hand strength
                    if self.is_strong_hand(round_state, community_cards):
                        return PokerAction.ALL_IN, 0
                    else:
                        # Only fold if hand is really weak
                        if not self.is_marginal_hand(round_state, community_cards):
                            return PokerAction.FOLD, 0
                        else:
                            return PokerAction.ALL_IN, 0
                else:
                    # We can call, raise, or fold
                    action, amount = self.decide_action(round_state, pot, community_cards, to_call_amount, current_bet, remaining_chips)
                    if action == PokerAction.CALL:
                        return PokerAction.CALL, 0
                    elif action == PokerAction.RAISE:
                        # Ensure raise is valid
                        min_valid_raise = max(min_raise, current_bet + min_raise)
                        if amount < min_valid_raise:
                            amount = min_valid_raise
                        if amount > remaining_chips:
                            return PokerAction.ALL_IN, 0
                        return PokerAction.RAISE, amount
                    elif action == PokerAction.ALL_IN:
                        return PokerAction.ALL_IN, 0
                    else:
                        return PokerAction.CALL, 0
        except Exception as e:
            # Fallback safe action
            return PokerAction.CALL, 0

    def can_raise(self, round_state: RoundStateClient) -> bool:
        # Check if raising is allowed (not capped, etc.)
        # In typical NLHE, raising is allowed unless action has been capped
        # Since we can't know cap status, assume we can raise unless min_raise is 0
        return round_state.min_raise > 0

    def decide_action(self, round_state: RoundStateClient, pot: int, community_cards: List[str], to_call: int, current_bet: int, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Preflop logic
        if round_state.round == 'Preflop':
            hand_strength = self.hand_strength_eval
            if hand_strength in ['high', 'medium']:
                # Strong or medium hand
                if to_call == 0:
                    # Open with raise
                    return PokerAction.RAISE, min(remaining_chips, int(pot * 3))
                else:
                    # Facing bet
                    if to_call <= remaining_chips * 0.1:
                        return PokerAction.CALL, 0
                    else:
                        # Don't overpay, but consider all-in for premium
                        if hand_strength == 'high' and self.evaluate_preflop_hand_rank(self.player_hands[0]) in self.strong_hands:
                            return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.CALL, 0
            else:
                # Weak hand
                if to_call > 0:
                    return PokerAction.FOLD, 0
                else:
                    # Check
                    return PokerAction.CHECK, 0

        # Post-flop logic
        else:
            current_hand = self.evaluate_hand(self.player_hands[0], community_cards)
            hand_rank = current_hand['rank']
            hand_name = current_hand['name']

            if hand_rank >= 8:  # Straight flush or Royal flush
                if to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, pot)
                else:
                    return PokerAction.ALL_IN, 0
            elif hand_rank >= 7:  # Quads or full house
                if to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, pot // 2)
                else:
                    return PokerAction.ALL_IN, 0
            elif hand_rank >= 6:  # Flush
                if to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, pot // 3)
                else:
                    if to_call <= pot // 2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif hand_rank >= 5:  # Straight
                if to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, pot // 4)
                else:
                    if to_call <= pot // 3:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif hand_rank >= 4:  # Trips
                if to_call == 0:
                    return PokerAction.RAISE, min(remaining_chips, pot // 5)
                else:
                    if to_call <= pot // 4:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            elif hand_rank >= 2:  # One pair or better but not strong
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    if to_call <= pot // 10:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
            else:  # High card
                if self.has_draw(community_cards, self.player_hands[0]):
                    # Stay in if flush or straight draw
                    if to_call <= pot // 10:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

    def has_draw(self, community_cards: List[str], hole_cards: str) -> bool:
        # Simple check for 4 to a flush or straight draw
        if len(community_cards) < 3:
            return False

        cards = [hole_cards[:2], hole_cards[2:]] + community_cards
        # Count suits
        suits = [card[-1] for card in cards]
        for suit in set(suits):
            if suits.count(suit) >= 4:
                return True  # Flush draw

        # Check straight draw (simplified)
        ranks = []
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        for card in cards:
            r = card[0]
            if r in rank_map:
                ranks.append(rank_map[r])
            else:
                ranks.append(int(r))
        ranks = list(set(ranks))
        ranks.sort()
        for i in range(len(ranks) - 3):
            if ranks[i+3] - ranks[i] <= 4:
                return True  # Open-ended or gutshot possible
        return False

    def evaluate_hand(self, hole_cards: str, community_cards: List[str]) -> dict:
        # Combine hole cards and community cards
        hole = [hole_cards[0:2], hole_cards[2:4]]
        all_cards = hole + community_cards
        # Convert to (rank, suit)
        card_tuples = []
        rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        for card in all_cards:
            r = card[0]
            s = card[1]
            if r in rank_map:
                rank = rank_map[r]
            else:
                rank = int(r)
            card_tuples.append((rank, s))

        # Get best 5-card hand
        from itertools import combinations
        best_rank = 0
        best_name = "High card"
        best_hand = None

        for combo in combinations(card_tuples, 5):
            rank, name = self.evaluate_5_card_hand(list(combo))
            if rank > best_rank:
                best_rank = rank
                best_name = name
                best_hand = combo

        return {'rank': best_rank, 'name': best_name, 'hand': best_hand}

    def evaluate_5_card_hand(self, cards):
        # Sort by rank
        cards.sort(key=lambda x: x[0], reverse=True)
        ranks = [card[0] for card in cards]
        suits = [card[1] for card in cards]

        # Check flush
        is_flush = len(set(suits)) == 1

        # Check straight
        is_straight = False
        if len(set(ranks)) == 5 and max(ranks) - min(ranks) == 4:
            is_straight = True
        # Special case: A-5 straight
        if set(ranks) == {14, 5, 4, 3, 2}:
            is_straight = True
            # Move ace to low
            ranks = [5, 4, 3, 2, 1]

        # Royal flush
        if is_straight and is_flush and ranks[0] == 14:
            return 9, "Royal flush"

        # Straight flush
        if is_straight and is_flush:
            return 8, "Straight flush"

        # Four of a kind
        for r in set(ranks):
            if ranks.count(r) == 4:
                return 7, "Four of a kind"

        # Full house
        counts = {}
        for r in ranks:
            counts[r] = counts.get(r, 0) + 1
        if 3 in counts.values() and 2 in counts.values():
            return 6, "Full house"

        # Flush
        if is_flush:
            return 5, "Flush"

        # Straight
        if is_straight:
            return 4, "Straight"

        # Three of a kind
        if 3 in counts.values():
            return 3, "Three of a kind"

        # Two pair
        pairs = [r for r in counts if counts[r] == 2]
        if len(pairs) == 2:
            return 2, "Two pair"

        # One pair
        if len(pairs) == 1:
            return 1, "One pair"

        return 0, "High card"

    def is_strong_hand(self, round_state: RoundStateClient, community_cards: List[str]) -> bool:
        if round_state.round == 'Preflop':
            return self.evaluate_preflop_hand(self.player_hands[0]) in ['high']
        else:
            evaluation = self.evaluate_hand(self.player_hands[0], community_cards)
            return evaluation['rank'] >= 4  # Trips or better

    def is_marginal_hand(self, round_state: RoundStateClient, community_cards: List[str]) -> bool:
        if round_state.round == 'Preflop':
            return self.evaluate_preflop_hand(self.player_hands[0]) in ['medium']
        else:
            evaluation = self.evaluate_hand(self.player_hands[0], community_cards)
            return evaluation['rank'] >= 2  # One pair or better

    def evaluate_preflop_hand(self, hole_cards: str) -> str:
        # Simple evaluation based on common starting hand rankings
        rank1 = hole_cards[0]
        rank2 = hole_cards[2]
        suit1 = hole_cards[1]
        suit2 = hole_cards[3]

        if rank1 == rank2:
            # Pocket pair
            if rank1 in 'AKQJT9':
                return 'high'
            elif rank1 in '876':
                return 'medium'
            else:
                return 'low'

        suited = suit1 == suit2
        high_cards = [rank for rank in [rank1, rank2] if rank in 'AKQJT']
        if len(high_cards) == 2:
            # Two high cards
            if suited:
                return 'high'
            else:
                if rank1 == 'A' or rank2 == 'A':
                    return 'medium'
                elif set([rank1, rank2]) == {'K', 'Q'}:
                    return 'medium'
                else:
                    return 'low'
        elif len(high_cards) == 1:
            # One high card
            if suited:
                if rank1 == 'A' or rank2 == 'A':
                    return 'medium'
                else:
                    return 'low'
            else:
                if rank1 == 'A' or rank2 == 'A':
                    return 'medium'
                else:
                    return 'low'
        else:
            return 'low'

    def evaluate_preflop_hand_rank(self, hole_cards: str) -> str:
        rank1 = hole_cards[0]
        rank2 = hole_cards[2]
        suit1 = hole_cards[1]
        suit2 = hole_cards[3]
        pair = rank1 == rank2
        suited = suit1 == suit2
        combo = ''.join(sorted([rank1, rank2], reverse=True))
        if pair:
            return combo + combo[-1]
        elif suited:
            return combo + 's'
        else:
            return combo + 'o'

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Cleanup if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended
        pass