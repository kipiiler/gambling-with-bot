from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = []
        self.hand_strength_cache = {}
        self.position = None  # 0: early, 1: middle, 2: late (dealer)
        self.previous_bet = 0
        self.acted_this_round = False

    def card_rank_value(self, card: str) -> int:
        """Convert card rank to numerical value (2-14)"""
        rank = card[0]
        if rank == 'T': return 10
        if rank == 'J': return 11
        if rank == 'Q': return 12
        if rank == 'K': return 13
        if rank == 'A': return 14
        return int(rank)

    def card_suit(self, card: str) -> str:
        """Extract suit from card string"""
        return card[-1]

    def evaluate_hole_cards(self, hole_cards: List[str]) -> float:
        """Evaluate hole card strength using a simplified version of Chen Formula"""
        if len(hole_cards) != 2:
            return 0.0
        
        c1, c2 = hole_cards
        r1, r2 = self.card_rank_value(c1), self.card_rank_value(c2)
        s1, s2 = self.card_suit(c1), self.card_suit(c2)
        
        # Sort by value descending
        if r1 < r2:
            r1, r2 = r2, r1
        
        score = 0.0
        
        # High card value
        score += r1 / 2.0
        if r1 >= 10:
            score += 0.5
        
        # Pairs
        if r1 == r2:
            score = max(3.0, score * 2)
            if r1 == 14: score = 10.0
            elif r1 == 13: score = 8.0
            elif r1 == 12: score = 7.0
            elif r1 == 11: score = 6.0
        
        # Gap between cards
        gap = r1 - r2
        if gap == 0:
            gap_penalty = 0
        elif gap == 1:
            gap_penalty = 1
        elif gap == 2:
            gap_penalty = 2
        elif gap == 3:
            gap_penalty = 4
        else:
            gap_penalty = 5
        
        score -= gap_penalty
        
        # Straights bonus for small gaps
        if gap <= 4 and r2 >= 10:  # Connected high cards
            score += 1
        if gap <= 3 and r2 >= 8 and r1 <= 13:  # Good connectors
            score += 1
        
        # Suited bonus
        if s1 == s2:
            score += 2.0
            if gap <= 3:
                score += 0.5
        
        # Adjust for AK
        if r1 == 14 and r2 == 13:
            score += 1.0
        
        # Clamp score between 0 and 10
        return max(0.0, min(10.0, score))

    def count_outs(self, hole_cards: List[str], community_cards: List[str]) -> int:
        """Count number of outs that can improve the hand"""
        if len(community_cards) == 0:
            return 0
        
        all_cards = hole_cards + community_cards
        ranks = [self.card_rank_value(card) for card in all_cards]
        suits = [self.card_suit(card) for card in all_cards]
        
        rank_count = {}
        suit_count = {}
        for r in ranks:
            rank_count[r] = rank_count.get(r, 0) + 1
        for s in suits:
            suit_count[s] = suit_count.get(s, 0) + 1
        
        outs = 0
        
        # Count potential outs for flush
        for suit, count in suit_count.items():
            if count >= 4:
                outs += (13 - count)  # Can complete flush
        
        # Count potential outs for straight
        unique_ranks = sorted(set(ranks))
        for i in range(14, 0, -1):
            if i in unique_ranks:
                continue
            # Check if adding this rank completes a straight
            extended = unique_ranks + [i]
            extended_sorted = sorted(extended)
            consecutive = 1
            max_consecutive = 1
            for j in range(1, len(extended_sorted)):
                if extended_sorted[j] == extended_sorted[j-1] + 1:
                    consecutive += 1
                else:
                    max_consecutive = max(max_consecutive, consecutive)
                    consecutive = 1
            max_consecutive = max(max_consecutive, consecutive)
            if max_consecutive >= 4:  # One card away from straight
                outs += 4  # Approximately 4 outs for straight
        
        # Overcards and pairs
        if len(hole_cards) == 2:
            for card in hole_cards:
                r = self.card_rank_value(card)
                if rank_count.get(r, 0) == 1:  # Unpaired card
                    # 3 outs to pair it
                    outs += 3
        
        return outs

    def estimate_win_probability(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate probability of winning based on current information"""
        if len(hole_cards) != 2:
            return 0.0
        
        n_community = len(community_cards)
        
        if n_community == 0:  # Pre-flop
            return self.evaluate_hole_cards(hole_cards) / 10.0
        
        # Use faster heuristics on later streets
        if n_community >= 3:
            # Check current hand strength
            hole_ranks = [self.card_rank_value(c) for c in hole_cards]
            hole_suits = [self.card_suit(c) for c in hole_cards]
            comm_ranks = [self.card_rank_value(c) for c in community_cards]
            comm_suits = [self.card_suit(c) for c in community_cards]
            
            all_ranks = hole_ranks + comm_ranks
            all_suits = hole_suits + comm_suits
            
            rank_count = {}
            suit_count = {}
            for r in all_ranks:
                rank_count[r] = rank_count.get(r, 0) + 1
            for s in all_suits:
                suit_count[s] = suit_count.get(s, 0) + 1
            
            # Check for strong hands
            has_pair = any(cnt >= 2 for cnt in rank_count.values())
            has_two_pair = sum(1 for cnt in rank_count.values() if cnt >= 2) >= 2
            has_three = any(cnt >= 3 for cnt in rank_count.values())
            has_straight_flush = False
            has_flush = any(cnt >= 5 for cnt in suit_count.values())
            has_straight = False
            
            # Check straight
            unique_ranks = sorted(set(all_ranks))
            consecutive = 1
            max_consecutive = 1
            for i in range(1, len(unique_ranks)):
                if unique_ranks[i] == unique_ranks[i-1] + 1:
                    consecutive += 1
                else:
                    max_consecutive = max(max_consecutive, consecutive)
                    consecutive = 1
            max_consecutive = max(max_consecutive, consecutive)
            if max_consecutive >= 5:
                has_straight = True
            
            # Check straight flush
            if has_flush:
                for suit in suit_count:
                    if suit_count[suit] >= 5:
                        suited_cards = [r for r, s in zip(all_ranks, all_suits) if s == suit]
                        suited_ranks = sorted(set(suited_cards))
                        consecutive = 1
                        max_consec = 1
                        for i in range(1, len(suited_ranks)):
                            if suited_ranks[i] == suited_ranks[i-1] + 1:
                                consecutive += 1
                            else:
                                max_consec = max(max_consec, consecutive)
                                consecutive = 1
                        max_consec = max(max_consec, consecutive)
                        if max_consec >= 5:
                            has_straight_flush = True
                            break
            
            # Hand strength
            if has_straight_flush:
                return 0.95
            elif has_straight and has_flush:
                return 0.90
            elif any(cnt >= 4 for cnt in rank_count.values()):  # Four of a kind
                return 0.85
            elif (has_three and has_pair) or sum(1 for cnt in rank_count.values() if cnt >= 3) >= 2:
                return 0.80  # Full house
            elif has_flush:
                return 0.70
            elif has_straight:
                return 0.65
            elif has_three:
                return 0.60
            elif has_two_pair:
                return 0.55
            elif has_pair:
                # Check if pair is high
                paired_ranks = [r for r, cnt in rank_count.items() if cnt >= 2]
                max_paired = max(paired_ranks) if paired_ranks else 0
                if max_paired >= 13:  # Aces or Kings
                    return 0.50
                elif max_paired >= 11:  # Queens or Jacks
                    return 0.45
                else:
                    return 0.40
            else:
                # High card
                max_card = max(all_ranks)
                if max_card == 14:  # Ace
                    return 0.35
                elif max_card >= 13:  # King or better
                    return 0.30
                else:
                    return 0.25
        
        # For flop and turn, estimate based on outs
        n_known = 2 + len(community_cards)
        n_unknown = 52 - n_known
        
        outs = max(0, self.count_outs(hole_cards, community_cards))
        
        # Approximate probability using rule of 4 and 2
        if n_community == 3:  # Turn: 2 cards to come
            hand_strength = self.evaluate_hole_cards(hole_cards) / 10.0
            improvement_prob = min(1.0, outs * 4 / 100)
            return hand_strength * (1 - improvement_prob) + improvement_prob
        elif n_community == 4:  # River: 1 card to come
            hand_strength = self.evaluate_hole_cards(hole_cards) / 10.0
            improvement_prob = min(1.0, outs * 2 / 100)
            return hand_strength * (1 - improvement_prob) + improvement_prob
        
        return 0.1

    def get_position(self, round_state: RoundStateClient, player_id: int) -> int:
        """Determine position: 0=early, 1=middle, 2=late (button)"""
        active_players = [pid for pid in round_state.player_bets.keys() if pid != str(player_id)]
        if not active_players:
            return 2  # Default to late if no others
        
        # Higher player ID doesn't necessarily mean later position
        # Use the fact that dealer is usually the one who acts last pre-flop
        # Simple approximation: if ID is high relative to others, might be late
        all_ids = [int(pid) for pid in round_state.player_bets.keys()] + [player_id]
        sorted_ids = sorted(all_ids)
        pos_idx = sorted_ids.index(player_id)
        
        if pos_idx >= len(sorted_ids) * 2 // 3:
            return 2  # Late
        elif pos_idx >= len(sorted_ids) // 3:
            return 1  # Middle
        else:
            return 0  # Early

    def calculate_bet_size(self, win_prob: float, round_state: RoundStateClient, remaining_chips: int) -> int:
        """Calculate appropriate bet size based on win probability and context"""
        n_players = len(round_state.player_bets)
        pot_size = round_state.pot
        min_raise = round_state.min_raise
        max_raise = min(remaining_chips, round_state.max_raise)
        current_bet = round_state.current_bet

        # Base bet as fraction of pot
        if win_prob > 0.8:
            # Strong hand, value bet
            bet = int(pot_size * (0.75 + random.uniform(0, 0.25)))
        elif win_prob > 0.6:
            # Good hand
            bet = int(pot_size * (0.5 + random.uniform(0, 0.25)))
        elif win_prob > 0.4:
            # Marginal hand, small bet or check
            bet = int(pot_size * (0.3 + random.uniform(0, 0.2)))
        else:
            # Weak hand, usually shouldn't bet
            bet = 0

        # Ensure valid raise amount
        if bet > 0:
            # Must be at least min_raise above current bet
            min_valid_raise = current_bet + max(min_raise, 1)
            if bet < min_valid_raise:
                bet = min_valid_raise
            if bet > max_raise:
                bet = max_raise
        
        return max(0, bet)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = player_hands
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_cache = {}
        self.previous_bet = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.acted_this_round = False
        # Reset any round-specific state
        pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            player_id_str = str(self.id)
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = min(remaining_chips, round_state.max_raise)
            pot_size = round_state.pot
            n_players = len(round_state.player_bets)
            hole_cards = self.player_hands if hasattr(self, 'player_hands') else []

            # Safety check
            if not hole_cards:
                return (PokerAction.FOLD, 0)

            # Get position
            self.position = self.get_position(round_state, self.id)
            
            # Determine current round
            is_preflop = round_state.round == 'Preflop'
            is_flop = round_state.round == 'Flop'
            is_turn = round_state.round == 'Turn'
            is_river = round_state.round == 'River'

            # Estimate win probability
            win_prob = self.estimate_win_probability(hole_cards, round_state.community_cards)
            
            # Adjust for position and aggression
            pos_factor = 1.0 + (self.position * 0.1)  # Slight position advantage
            win_prob = min(1.0, win_prob * pos_factor)
            
            # Count active players who haven't folded
            active_players = sum(1 for action in round_state.player_actions.values() if action != 'Fold')
            if active_players <= 1:
                # Heads-up or only one left
                pass

            # Amount needed to call
            my_current_bet = round_state.player_bets.get(player_id_str, 0)
            to_call = current_bet - my_current_bet

            # Decision logic
            if to_call == 0:
                # Can check
                if is_preflop:
                    # Pre-flop strategy
                    hole_strength = self.evaluate_hole_cards(hole_cards)
                    if hole_strength >= 7.0 or (hole_strength >= 5.0 and self.position >= 1):
                        # Raise with strong or decent cards in position
                        bet_size = self.calculate_bet_size(win_prob, round_state, remaining_chips)
                        if bet_size > to_call and bet_size <= max_raise and bet_size >= current_bet + max(min_raise, 1):
                            return (PokerAction.RAISE, bet_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    elif hole_strength >= 4.0:
                        # Check or call with marginal hands
                        return (PokerAction.CHECK, 0)
                    else:
                        # Fold weak hands out of position, otherwise check
                        if self.position == 0:  # Early position
                            return (PokerAction.FOLD, 0)
                        else:
                            return (PokerAction.CHECK, 0)
                else:
                    # Post-flop: can check
                    if win_prob > 0.4:
                        # Bet for value or semi-bluff
                        bet_size = self.calculate_bet_size(win_prob, round_state, remaining_chips)
                        if bet_size > current_bet and bet_size <= max_raise:
                            return (PokerAction.RAISE, bet_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    elif win_prob > 0.2 and random.random() < 0.3:
                        # Occasional bluff, especially on scare boards
                        bet_size = int(pot_size * 0.7)
                        min_valid = current_bet + max(min_raise, 1)
                        if bet_size >= min_valid and bet_size <= max_raise:
                            return (PokerAction.RAISE, bet_size)
                        else:
                            return (PokerAction.CHECK, 0)
                    else:
                        return (PokerAction.CHECK, 0)
            else:
                # Need to call or raise
                pot_odds = to_call / (pot_size + to_call) if (pot_size + to_call) > 0 else 0.0
                
                if win_prob > pot_odds * 1.5:
                    # Expected value positive, consider raising
                    if win_prob > 0.7:
                        # Strong hand, raise for value
                        bet_size = self.calculate_bet_size(win_prob, round_state, remaining_chips)
                        if bet_size > to_call and bet_size <= max_raise and bet_size >= current_bet + max(min_raise, 1):
                            return (PokerAction.RAISE, bet_size)
                        elif remaining_chips > 0 and to_call <= remaining_chips:
                            if to_call >= remaining_chips * 0.6:
                                return (PokerAction.ALL_IN, 0)
                            else:
                                return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    elif win_prob > 0.4:
                        # Medium strength, usually call
                        if to_call <= remaining_chips:
                            if to_call < remaining_chips * 0.4:  # Not too expensive
                                return (PokerAction.CALL, 0)
                            elif win_prob > pot_odds * 2 and random.random() < 0.4:
                                # Occasionally raise as semi-bluff
                                bet_size = int(pot_size * 0.6)
                                min_valid = current_bet + max(min_raise, 1)
                                if bet_size >= min_valid and bet_size <= max_raise:
                                    return (PokerAction.RAISE, bet_size)
                                else:
                                    return (PokerAction.CALL, 0)
                            else:
                                return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Weak hand
                        if to_call <= remaining_chips * 0.1 and random.random() < win_prob + 0.1:
                            # Small price to see next card
                            return (PokerAction.CALL, 0)
                        elif win_prob > 0.2 and random.random() < 0.1 and to_call <= remaining_chips * 0.3:
                            # Occasional bluff call
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                else:
                    # Negative expected value
                    if is_preflop:
                        # Tighten up pre-flop
                        hole_strength = self.evaluate_hole_cards(hole_cards)
                        position_call_factor = 1.0 + (self.position * 0.2)
                        if hole_strength * position_call_factor > 6.0 and to_call <= remaining_chips:
                            return (PokerAction.CALL, 0)
                        else:
                            return (PokerAction.FOLD, 0)
                    else:
                        # Post-flop: consider implied odds and draw potential
                        if win_prob > 0.25 and random.random() < 0.2:
                            # Occasional call with drawing hands
                            if to_call <= remaining_chips:
                                return (PokerAction.CALL, 0)
                        # All-in check
                        if remaining_chips <= to_call:
                            # Going all-in anyway
                            if win_prob > 0.3:
                                return (PokerAction.ALL_IN, 0)
                        return (PokerAction.FOLD, 0)
                        
        except Exception as e:
            # Safety fallback on any error
            return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up round-specific data
        self.acted_this_round = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Game ended, prepare for next game if needed
        self.hand_strength_cache = {}