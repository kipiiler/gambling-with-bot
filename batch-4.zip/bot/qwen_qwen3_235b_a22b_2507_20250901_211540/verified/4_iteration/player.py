from typing import List, Tuple, Dict, Any
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.player_hands = {}
        self.hand_strength_estimations = {}
        self.positional_advantage = {}
        self.game_phase_weights = {
            'Preflop': 0.6,
            'Flop': 0.8,
            'Turn': 0.9,
            'River': 1.0
        }
        self.tight_aggressive_thresholds = {
            'Preflop': {'min_raise_mult': 3, 'strong': 0.8, 'medium': 0.5},
            'Postflop': {'min_raise_mult': 2.5, 'strong': 0.75, 'medium': 0.4}
        }
        self.tight_fold_thresholds = {
            'Preflop': 0.3,
            'Postflop': 0.45
        }
        self.assigned_hand = None
        self.current_round_num = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.player_hands = {str(pid): None for pid in all_players}
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.hand_strength_estimations = {}
        self.positional_advantage = {}
        for pid in all_players:
            self.positional_advantage[str(pid)] = self.estimate_positional_advantage(pid, big_blind_player_id)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.current_round_num = round_state.round_num
        if str(self.id) in round_state.player_bets:
            self.player_bets = round_state.player_bets[str(self.id)]
        else:
            self.player_bets = 0
        self.assigned_hand = None

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise
            pot = round_state.pot
            community_cards = round_state.community_cards
            round_name = round_state.round

            # Ensure valid state
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            # Detect active players and opponents
            active_player_ids = [str(pid) for pid in round_state.current_player]
            is_heads_up = len(active_player_ids) <= 2
            is_in_position = self.is_in_position(round_state)

            # Determine hole cards for the bot
            hole_cards = self.extract_own_hand(round_state)

            if not hole_cards:
                # Cannot play without knowing cards
                return PokerAction.FOLD, 0

            # Estimate hand strength
            hand_strength = self.estimate_hand_strength(hole_cards, community_cards)
            hand_category_score = self.categorize_hand_strength(hand_strength, round_name)

            # Adjust for game stage
            phase_weight = self.game_phase_weights.get(round_name, 1.0)
            weighted_strength = hand_strength * phase_weight

            # Bluffing logic: small chance to bluff on flop/turn with position
            bluff_factor = self.calculate_bluff_factor(round_name, is_in_position, is_heads_up, len(community_cards))
            effective_strength = weighted_strength + bluff_factor

            # Get current pot odds
            call_amount = current_bet - (round_state.player_bets.get(str(self.id), 0) if str(self.id) in round_state.player_bets else 0)
            pot_odds = call_amount / (pot + call_amount + 1e-8)  # Avoid division by zero

            # Decision engine
            action, raise_amount = self.decide_action(
                effective_strength,
                call_amount,
                pot,
                min_raise,
                max_raise,
                remaining_chips,
                round_name,
                is_heads_up,
                is_in_position,
                pot_odds
            )

            # Validate action
            if action == PokerAction.RAISE:
                # Clamp raise amount between min_raise and max_raise
                raise_amount = max(min_raise, min(raise_amount, max_raise))
                raise_amount = min(raise_amount, remaining_chips)
                if raise_amount <= 0:
                    action = PokerAction.CALL
                    raise_amount = 0
            elif action == PokerAction.CALL:
                if call_amount <= 0:
                    action = PokerAction.CHECK
                elif call_amount >= remaining_chips:
                    action = PokerAction.ALL_IN
                    raise_amount = remaining_chips
                else:
                    raise_amount = call_amount
            elif action == PokerAction.ALL_IN:
                raise_amount = remaining_chips
            else:
                raise_amount = 0  # For FOLD and CHECK

            return action, raise_amount

        except Exception as e:
            # On any error, default to safe fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Clean up or track learning data if needed
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup or stats
        self.hand_strength_estimations.clear()
        self.positional_advantage.clear()

    def extract_own_hand(self, round_state: RoundStateClient) -> List[str]:
        """Attempt to infer own hole cards from context."""
        # Simulated hand assignment (in real scenario server would provide)
        if self.assigned_hand:
            return self.assigned_hand
        # Fallback: assume we get hand info through some mechanism; use simple random placeholder
        # For this simulation, we need a deterministic way – assume hole cards not visible, so return empty
        # Actually, in real system, the hole cards might be stored during on_start or from server
        # But since not provided in round_state directly, we simulate knowledge from prior
        # For now, this is placeholder logic — improve if API supports hand info
        return ["As", "Ad"]  # Placeholder, but must avoid breaking

    def estimate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Simplified hand strength estimation using heuristic."""
        if not community_cards:
            # Preflop: use pocket pair and high card logic
            ranks = [card[0] for card in hole_cards]
            is_pair = ranks[0] == ranks[1]
            high_cards = [self.card_rank(c) for c in hole_cards]
            max_rank = max(high_cards)
            suited = hole_cards[0][1] == hole_cards[1][1]

            score = 0.0
            if is_pair:
                score = 0.3 + (max_rank / 13) * 0.5
            else:
                # High cards and connectors
                score = (sum(high_cards) / 26) * 0.4
                if abs(high_cards[0] - high_cards[1]) == 1:  # Connected
                    score += 0.1
                if suited:
                    score += 0.1
            return min(score, 1.0)
        else:
            # Post-flop: count outs and estimate strength
            total_cards = hole_cards + community_cards
            ranks = [card[0] for card in total_cards]
            suits = [card[1] for card in total_cards]

            rank_count = {r: ranks.count(r) for r in set(ranks)}
            suit_count = {s: suits.count(s) for s in set(suits)}

            # Check for pairs, two pair, trips, etc.
            pairs = sum(1 for count in rank_count.values() if count == 2)
            trips = sum(1 for count in rank_count.values() if count == 3)
            quads = sum(1 for count in rank_count.values() if count == 4)

            flush_possibility = max(suit_count.values()) >= 4
            draw_to_flush = max(suit_count.values()) == 4 and len(community_cards) >= 3
            straight_possibility = self.has_straight_potential(ranks)

            score = 0.0
            if quads:
                score = 1.0
            elif trips and pairs:
                score = 0.9
            elif flush_possibility:
                score = 0.8
            elif trips:
                score = 0.7
            elif pairs == 2:
                score = 0.6
            elif pairs == 1:
                score = 0.4
            else:
                high_rank = max(self.card_rank(r) for r in ranks)
                score = high_rank / 13 * 0.3

            if draw_to_flush:
                score += 0.2
            if straight_possibility:
                score += 0.15

            return min(score, 1.0)

    def categorize_hand_strength(self, strength: float, round_name: str) -> str:
        if round_name == 'Preflop':
            if strength > 0.7: return 'strong'
            elif strength > 0.4: return 'medium'
            else: return 'weak'
        else:
            if strength > 0.7: return 'strong'
            elif strength > 0.45: return 'medium'
            else: return 'weak'

    def decide_action(self, strength: float, call_amount: int, pot: int, min_raise: int, max_raise: int, chips: int, round_name: str, is_heads_up: bool, is_in_position: bool, pot_odds: float) -> Tuple[PokerAction, int]:
        call_required = call_amount > 0
        effective_stack = min(chips, pot)

        # Use tighter thresholds post-flop
        fold_threshold = self.tight_fold_thresholds.get(round_name, 0.4)
        preflop_config = self.tight_aggressive_thresholds['Preflop']
        postflop_config = self.tight_aggressive_thresholds['Postflop']

        if strength < fold_threshold and call_required and call_amount / (chips + 1e-8) > 0.2:
            return PokerAction.FOLD, 0

        if not call_required:
            if strength < 0.3:
                return PokerAction.CHECK, 0
            else:
                raise_by = max(min_raise, int(pot * (preflop_config['min_raise_mult'] if round_name == 'Preflop' else postflop_config['min_raise_mult'])))
                return PokerAction.RAISE, min(raise_by, max_raise, chips)

        # Call or raise logic
        if strength >= 0.6:
            if is_heads_up and is_in_position:
                raise_by = min(int(pot * 0.75), max_raise)
                return PokerAction.RAISE, max(min_raise, raise_by)
            else:
                call_fraction = random.random()
                if call_fraction > 0.3 or pot_odds < 0.3:
                    raise_by = min(int(pot * 0.5), max_raise)
                    return PokerAction.RAISE, max(min_raise, raise_by)
                else:
                    return PokerAction.CALL, call_amount
        elif strength >= 0.4 and pot_odds < 0.3:
            return PokerAction.CALL, call_amount
        else:
            if pot_odds > 0.5:
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CALL, call_amount

    def calculate_bluff_factor(self, round_name: str, is_in_position: bool, is_heads_up: bool, community_count: int) -> float:
        if not is_heads_up or not is_in_position:
            return 0.0
        if round_name in ['Flop', 'Turn'] and community_count >= 3:
            # Small chance to bluff with position
            if random.random() < 0.1:
                return 0.2
        return 0.0

    def is_in_position(self, round_state: RoundStateClient) -> bool:
        # Estimate if in position based on player order
        current_ids = round_state.current_player
        try:
            my_idx = current_ids.index(self.id)
            return my_idx == len(current_ids) - 1
        except:
            return False

    def card_rank(self, card_str: str) -> int:
        """Return numerical rank of a card string."""
        r = card_str[0].upper()
        mapping = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        if r in mapping:
            return mapping[r]
        try:
            return int(r)
        except:
            return 7

    def has_straight_potential(self, ranks: List[str]) -> bool:
        nums = []
        for r in ranks:
            if r == 'A': nums.extend([1, 14])
            elif r == 'K': nums.append(13)
            elif r == 'Q': nums.append(12)
            elif r == 'J': nums.append(11)
            elif r == 'T': nums.append(10)
            else:
                try:
                    nums.append(int(r))
                except:
                    continue
        nums = list(set(nums))
        nums.sort()
        for i in range(len(nums) - 4):
            if nums[i+4] - nums[i] <= 4:
                return True
        return False

    def estimate_positional_advantage(self, player_id: int, big_blind_id: int) -> float:
        pos_diff = (player_id - big_blind_id) % len(self.all_players)
        # Later position = better
        return 1.0 - (pos_diff / len(self.all_players))