from typing import List, Tuple, Dict, Set
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
import random
import re
import math

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id = None
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = -1
        self.small_blind_player_id = -1
        self.all_players = []
        self.hand_strength_estimate = 0.0
        self.position_importance = 0
        self.is_close_to_showdown = False
        self.current_round = ""
        self.player_hole_cards = []
        self.stack_history = []
        self.total_opponents = 0
        self.ideal_raise_multiplier = 3.0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players
        self.total_opponents = len(all_players) - 1
        self.stack_history = [starting_chips]

        # Capture own hole cards from player_hands if self.id is known
        # Note: In actual environment, player_hands may be indexed by player ID
        # Assuming this bot receives its own two cards somewhere
        if self.id is not None and str(self.id) in player_hands:
            self.player_hole_cards = player_hands[str(self.id)]

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.stack_history.append(remaining_chips)
        self.current_round = round_state.round
        self.is_close_to_showdown = round_state.round in ['Turn', 'River']

    def _parse_card(self, card: str):
        """Returns rank as int (2-14) and suit"""
        if len(card) == 2:
            r, s = card[0], card[1]
        elif len(card) == 3:  # e.g., '10h'
            r, s = card[:2], card[2]
        else:
            return 0, ''
        rank_map = {'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = rank_map.get(r, int(r) if r.isdigit() else 0)
        return rank, s

    def _hand_rank_power(self, cards: List[str]) -> float:
        """Simple heuristic to evaluate hand strength from given cards (hole + community)"""
        if not cards:
            return 0.0

        ranks = []
        suits = []
        for card in cards:
            r, s = self._parse_card(card)
            if r > 0:
                ranks.append(r)
                suits.append(s)

        rank_counts = {}
        suit_counts = {}
        for r in ranks:
            rank_counts[r] = rank_counts.get(r, 0) + 1
        for s in suits:
            suit_counts[s] = suit_counts.get(s, 0) + 1

        max_rank_count = max(rank_counts.values()) if rank_counts else 0
        max_suit_count = max(suit_counts.values()) if suit_counts else 0

        # Sort ranks for straights
        sorted_ranks = sorted(set(ranks))
        # Handle A-5 straight
        if 14 in sorted_ranks and 2 in sorted_ranks and 3 in sorted_ranks and 4 in sorted_ranks and 5 in sorted_ranks:
            sorted_ranks = [1] + sorted_ranks  # Treat A as 1

        has_straight = False
        for i in range(len(sorted_ranks) - 4):
            if sorted_ranks[i+4] - sorted_ranks[i] == 4:
                has_straight = True
                break

        # Assign hand strength score between 0 and 1
        score = 0.0

        # High card baseline
        top_rank = max(ranks) if ranks else 2
        score = (top_rank - 2) / 50  # up to ~0.25 for Ace

        if max_rank_count == 2:
            pairs = sum(1 for c in rank_counts.values() if c == 2)
            score = 0.15 + 0.10 * pairs  # 0.15 for one pair, 0.25 for two pair
        if max_rank_count == 3:
            score = 0.35
        if max_suit_count >= 5:
            score = 0.45
        if has_straight:
            score = 0.50
        if max_rank_count == 3 and 2 in rank_counts.values():
            score = 0.60  # Full house
        if max_rank_count == 4:
            score = 0.75
        if has_straight and max_suit_count >= 5:
            score = 0.90
        if has_straight and max_suit_count >= 5 and top_rank == 14:
            score = 1.00

        return min(score, 1.0)

    def _evaluate_hole_card_strength(self, hole_cards: List[str]) -> float:
        """Evaluate pre-flop strength of two hole cards"""
        if len(hole_cards) != 2:
            return 0.05

        c1, c2 = hole_cards
        r1, s1 = self._parse_card(c1)
        r2, s2 = self._parse_card(c2)

        score = 0.0

        # High pairs
        if r1 == r2:
            score += 0.3 + (r1 - 2) * 0.03  # 22 = 0.3, AA ~ 0.66
        # High cards
        if r1 >= 11 or r2 >= 11:  # J, Q, K, A
            score += 0.05
            if r1 == r2:  # Matched high cards
                score += 0.1

        # Connected cards
        if abs(r1 - r2) == 1:
            score += 0.05
        if abs(r1 - r2) == 2:
            score += 0.03

        # Suited
        if s1 == s2:
            score += 0.05

        # Big cards
        if r1 >= 10 and r2 >= 10:
            score += 0.05

        # Pocket Aces, Kings, Queens, Jacks get bonus
        if r1 == r2 and r1 >= 11:
            score += 0.05

        return min(score, 0.8)

    def _estimate_winning_probability(self, hole_cards: List[str], community_cards: List[str]) -> float:
        """Estimate probability of winning based on current board and cards"""
        if not hole_cards:
            return 0.05

        all_known_cards = hole_cards + community_cards
        hand_strength = self._hand_rank_power(all_known_cards)

        if len(community_cards) == 0:  # Pre-flop
            return self._evaluate_hole_card_strength(hole_cards)
        elif len(community_cards) < 5:
            # Interpolate between hole strength and current hand strength
            base = hand_strength
            hole_strength = self._evaluate_hole_card_strength(hole_cards)
            # Weight based on how developed the board is
            board_factor = len(community_cards) / 5
            return hole_strength * (1 - board_factor) + base * board_factor
        else:
            return hand_strength

    def _get_position_score(self, player_ids: List[int], current_player_id: int) -> float:
        """Estimate positional advantage: later is better"""
        if current_player_id not in player_ids:
            return 0.5  # default
        pos = player_ids.index(current_player_id)
        return pos / max(len(player_ids) - 1, 1)

    def _adjust_for_stack_size(self, remaining_chips: int, avg_pot: float) -> float:
        """Adjust aggression based on stack depth"""
        if avg_pot <= 0:
            avg_pot = 10.0
        effective_stack = remaining_chips / avg_pot if avg_pot > 0 else 100
        # Normalize to 0-1: 10bb = 0.1, 100bb = 1.0
        return min(effective_stack / 100, 1.0)

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Update current player tracking
            if self.id is None:
                # Try to find out our ID from player_bets (assume first key is ours? Or should be assigned before)
                # But per specification, id should be set externally via set_id. We rely on that.
                # If not set, assume we cannot act properly
                return PokerAction.FOLD, 0

            current_player_list = round_state.current_player
            pot = max(round_state.pot, 1)
            current_bet = round_state.current_bet
            min_raise = round_state.min_raise
            max_raise = round_state.max_raise

            # Extract our hole cards from state? If not available elsewhere
            # This bot assumes on_start gave us our cards, or they are tracked
            hole_cards = self.player_hole_cards
            community_cards = round_state.community_cards

            # Estimate winning probability
            win_prob = self._estimate_winning_probability(hole_cards, community_cards)
            position_score = self._get_position_score(current_player_list, self.id)
            stack_factor = self._adjust_for_stack_size(remaining_chips, pot)
            aggression_factor = win_prob * (0.5 + position_score) * (0.5 + stack_factor)

            # Current bet relative to pot
            call_amount = current_bet - round_state.player_bets.get(str(self.id), 0)
            pot_odds = call_amount / (pot + call_amount + 1e-8)

            # Decision logic
            if round_state.round == 'Preflop':
                # Tighter preflop range
                if win_prob < 0.15:
                    if call_amount > 0:
                        if aggression_factor > 0.6 or random.random() < 0.05:
                            return PokerAction.RAISE, min(int(pot), max_raise)
                        elif call_amount <= self.blind_amount * 2:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.FOLD, 0
                    else:
                        if win_prob > 0.25:
                            return PokerAction.RAISE, min(int(3 * self.blind_amount), max_raise)
                        else:
                            return PokerAction.CHECK, 0
                else:
                    if call_amount == 0:
                        return PokerAction.RAISE, min(int(3 * self.blind_amount), max_raise)
                    elif pot_odds < win_prob and call_amount <= remaining_chips * 0.1:
                        return PokerAction.CALL, 0
                    elif aggression_factor > 0.4:
                        raise_amount = min(int(pot), max_raise)
                        if raise_amount >= min_raise:
                            return PokerAction.RAISE, raise_amount
                        else:
                            return PokerAction.CALL, 0
                    else:
                        return PokerAction.CALL, 0
            else:
                # Post-flop: use more aggressive line if strong hand
                if win_prob > 0.7:
                    if aggression_factor > 0.5:
                        # Go for value
                        raise_amount = min(int(0.75 * pot), max_raise)
                        if raise_amount < min_raise:
                            raise_amount = min(max_raise, min_raise)
                        if raise_amount <= max_raise and raise_amount >= min_raise:
                            return PokerAction.RAISE, raise_amount
                        else:
                            # If can't raise validly, go all-in or call
                            if max_raise >= min_raise:
                                return PokerAction.RAISE, max_raise
                            else:
                                return PokerAction.CALL, 0
                    else:
                        return PokerAction.CALL, 0
                elif win_prob > 0.4:
                    # Drawing or medium strength
                    if pot_odds <= win_prob and call_amount <= remaining_chips * 0.2:
                        if aggression_factor > 0.5 and random.random() < 0.3:
                            raise_amount = min(int(0.5 * pot), max_raise)
                            if raise_amount >= min_raise:
                                return PokerAction.RAISE, raise_amount
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                elif win_prob > 0.2:
                    # Weak hand, maybe fold or bluff occasionally
                    if aggression_factor > 0.7 and pot < remaining_chips and random.random() < 0.1:
                        # Semi-bluff
                        raise_amount = min(int(0.75 * pot), max_raise)
                        if raise_amount >= min_raise:
                            return PokerAction.RAISE, raise_amount
                    if call_amount == 0:
                        return PokerAction.CHECK, 0
                    elif pot_odds < 0.2:
                        return PokerAction.CALL, 0
                    else:
                        return PokerAction.FOLD, 0
                else:
                    if call_amount == 0:
                        return PokerAction.CHECK, 0
                    else:
                        return PokerAction.FOLD, 0

            # Default action fallback
            if call_amount == 0:
                return PokerAction.CHECK, 0
            elif call_amount >= remaining_chips:
                return PokerAction.ALL_IN, 0
            else:
                if pot_odds < win_prob:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

        except Exception as e:
            # On any error, avoid exception; fold gracefully
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update internal state at end of round
        self.stack_history.append(remaining_chips)
        # Optionally reset per-round state
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Final cleanup if needed
        pass

    def set_id(self, player_id: int) -> None:
        """ Override to capture player ID """
        self.id = player_id
        super().set_id(player_id)