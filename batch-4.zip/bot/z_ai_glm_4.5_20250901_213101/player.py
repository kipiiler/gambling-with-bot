from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient
from itertools import combinations
from collections import Counter
import random

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hole_cards = []
        self.blind_amount = 0
        self.big_blind_id = None
        self.small_blind_id = None
        self.posizione_count = {}
        self.hand_history = []
        self.opponent_actions = {}
        self.rank_map = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10, '9': 9, '8': 8, '7': 7, '6': 6, '5': 5, '4': 4, '3': 3, '2': 2}
        self.rev_rank_map = {v: k for k, v in self.rank_map.items()}
        
    def set_id(self, player_id: int) -> None:
        self.id = str(player_id)
        
    def _evaluate_5_card_hand(self, cards):
        suits = set()
        ranks = []
        for card in cards:
            rank_char = card[0]
            suit = card[1]
            ranks.append(self.rank_map[rank_char])
            suits.add(suit)
        
        suits_count = len(suits)
        is_flush = suits_count == 1
        
        ranks.sort(reverse=True)
        distinct_ranks = set(ranks)
        is_straight = False
        if len(distinct_ranks) == 5:
            if ranks[0] - ranks[4] == 4:
                is_straight = True
            elif ranks[0] == 14 and ranks[1] == 5 and ranks[2] == 4 and ranks[3] == 3 and ranks[4] == 2:
                is_straight = True
                ranks = [5, 4, 3, 2, 1]
        
        if is_flush and is_straight:
            return (8, ranks[0])
        
        count = Counter(ranks)
        most_common = count.most_common()
        
        if most_common[0][1] == 4:
            four_rank = most_common[0][0]
            kicker = [r for r in ranks if r != four_rank][0]
            return (7, four_rank, kicker)
        
        if most_common[0][1] == 3 and most_common[1][1] == 2:
            three_rank = most_common[0][0]
            two_rank = most_common[1][0]
            return (6, three_rank, two_rank)
        
        if is_flush:
            return (5, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])
        
        if is_straight:
            return (4, ranks[0])
        
        if most_common[0][1] == 3:
            three_rank = most_common[0][0]
            kickers = sorted([r for r in ranks if r != three_rank], reverse=True)
            return (3, three_rank, kickers[0], kickers[1])
        
        if most_common[0][1] == 2 and most_common[1][1] == 2:
            two1 = most_common[0][0]
            two2 = most_common[1][0]
            if two1 < two2:
                two1, two2 = two2, two1
            kicker = [r for r in ranks if r != two1 and r != two2][0]
            return (2, two1, two2, kicker)
        
        if most_common[0][1] == 2:
            pair_rank = most_common[0][0]
            kickers = sorted([r for r in ranks if r != pair_rank], reverse=True)
            return (1, pair_rank, kickers[0], kickers[1], kickers[2])
        
        return (0, ranks[0], ranks[1], ranks[2], ranks[3], ranks[4])
    
    def evaluate_hand(self, all_cards):
        best_hand = (0, 0, 0, 0, 0, 0)
        for combo in combinations(all_cards, 5):
            hand_value = self._evaluate_5_card_hand(list(combo))
            if hand_value > best_hand:
                best_hand = hand_value
        return best_hand
    
    def preflop_strength(self, hole_cards):
        r1 = self.rank_map[hole_cards[0][0]]
        r2 = self.rank_map[hole_cards[1][0]]
        suited = 1 if hole_cards[0][1] == hole_cards[1][1] else 0
        
        if hole_cards[0][0] == hole_cards[1][0]:
            return (r1 * 2) + 15
        else:
            if r1 < r2:
                r1, r2 = r2, r1
            return (r1 + r2) + suited
    
    def get_position(self, round_state):
        current_players = round_state.current_player
        if self.id not in current_players:
            return 0
        my_idx = current_players.index(self.id)
        num_players = len(current_players)
        
        if num_players <= 2:
            return 1 if my_idx == 0 else 0
        
        if my_idx == 0:
            return num_players - 1
        elif my_idx == num_players - 1:
            return 1
        else:
            return 2
    
    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hole_cards = player_hands
        self.blind_amount = blind_amount
        self.big_blind_id = str(big_blind_player_id)
        self.small_blind_id = str(small_blind_player_id)
        self.posizione_count = {}
        self.hand_history = []
        self.opponent_actions = {}
        for player in all_players:
            self.opponent_actions[str(player)] = {'fold': 0, 'call': 0, 'raise': 0, 'check': 0}

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'Preflop':
            self.opponent_actions = {}
            for player in round_state.current_player:
                self.opponent_actions[player] = {'fold': 0, 'call': 0, 'raise': 0, 'check': 0}

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        current_bet = round_state.current_bet
        our_bet = round_state.player_bets.get(self.id, 0)
        call_amount = current_bet - our_bet
        
        if call_amount > remaining_chips:
            if random.random() < 0.7:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)
        
        position = self.get_position(round_state)
        
        if round_state.round == 'Preflop':
            strength = self.preflop_strength(self.hole_cards)
            effective_stack = remaining_chips / self.blind_amount
            pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
            
            if strength >= 28:
                raise_amount = min(4 * self.blind_amount + call_amount, remaining_chips)
                raise_amount = max(raise_amount, round_state.min_raise)
                raise_amount = min(raise_amount, round_state.max_raise)
                return (PokerAction.RAISE, raise_amount)
            elif strength >= 22:
                if position <= 2 and call_amount == 0:
                    raise_amount = min(3 * self.blind_amount, remaining_chips)
                    raise_amount = max(raise_amount, round_state.min_raise)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                elif call_amount <= 3 * self.blind_amount and pot_odds < 0.25:
                    return (PokerAction.CALL, 0)
            else:
                if strength >= 18 and position == 1 and call_amount <= self.blind_amount:
                    return (PokerAction.CALL, 0)
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)
        else:
            all_cards = self.hole_cards + round_state.community_cards
            hand_rank = self.evaluate_hand(all_cards)[0]
            pot_odds = call_amount / (round_state.pot + call_amount) if (round_state.pot + call_amount) > 0 else 0
            
            if hand_rank >= 6:
                if random.random() < 0.8:
                    raise_amount = min(int(round_state.pot * 0.8) + call_amount, remaining_chips)
                    raise_amount = max(raise_amount, round_state.min_raise)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                else:
                    return (PokerAction.ALL_IN, 0)
            elif hand_rank >= 4:
                if call_amount == 0 and position >= 2:
                    raise_amount = min(int(round_state.pot * 0.5) + call_amount, remaining_chips)
                    raise_amount = max(raise_amount, round_state.min_raise)
                    raise_amount = min(raise_amount, round_state.max_raise)
                    return (PokerAction.RAISE, raise_amount)
                elif pot_odds < 0.3:
                    return (PokerAction.CALL, 0)
            elif hand_rank >= 2:
                if call_amount <= int(round_state.pot * 0.3) and pot_odds < 0.2:
                    return (PokerAction.CALL, 0)
            else:
                if call_amount == 0 and position >= 2:
                    return (PokerAction.CHECK, 0)
            
            if call_amount == 0:
                return (PokerAction.CHECK, 0)
            else:
                return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        if round_state.round == 'River':
            self.hand_history.append({
                'community_cards': round_state.community_cards,
                'pot': round_state.pot,
                'player_bets': round_state.player_bets,
                'remaining_chips': remaining_chips
            })

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        for player_id, actions in round_state.player_actions.items():
            if player_id != self.id and player_id in self.opponent_actions:
                for action in actions.split(','):
                    action = action.strip()
                    if action in ['Fold', 'Call', 'Raise', 'Check']:
                        action_key = action.lower()
                        if action_key in self.opponent_actions[player_id]:
                            self.opponent_actions[player_id][action_key] += 1