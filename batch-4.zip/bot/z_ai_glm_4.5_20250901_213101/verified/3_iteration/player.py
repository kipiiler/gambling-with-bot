from typing import List, Tuple
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.player_id_str = None  # Store player ID as string for lookup
        self.my_current_bet = 0    # Track current bet amount

    def set_id(self, player_id: int) -> None:
        super().set_id(player_id)
        self.player_id_str = str(player_id)

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # No specific initialization needed beyond ID setting
        pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset current bet tracker at start of each round
        self.my_current_bet = 0

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Update current bet from player_bets dictionary
        self.my_current_bet = round_state.player_bets.get(self.player_id_str, 0)
        
        # Calculate amount needed to call
        amount_to_call = round_state.current_bet - self.my_current_calling the big blind amount

        # If no bet to face, check
        if amount_to_call == 0:
            return (PokerAction.CHECK, 0)
        
        # Never call or raise - always fold when facing a bet
        return (PokerAction.FOLD, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No action needed at end of round
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No action needed at end of game
        pass