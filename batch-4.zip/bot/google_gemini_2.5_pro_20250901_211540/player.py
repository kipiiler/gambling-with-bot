import collections
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Helper Functions for Card and Hand Evaluation ---

def parse_card(card_str: str) -> Tuple[int, str]:
    """Parses a card string like 'Ah' into (rank, suit) tuple, e.g., (14, 'h')."""
    if not card_str:
        return 0, ''
    rank_map = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
    rank_str = card_str[:-1]
    suit = card_str[-1]
    rank = int(rank_map.get(rank_str, rank_str))
    return rank, suit

def get_hand_rank(hand: List[Tuple[int, str]]) -> Tuple:
    """
    Evaluates a 5-card hand and returns a tuple for ranking.
    The tuple format is (rank_score, ...kickers). Higher rank_score is better.
    Rank scores: 9:RoyalFlush, 8:StraightFlush, 7:Quads, 6:FullHouse, 5:Flush
                 4:Straight, 3:Trips, 2:TwoPair, 1:Pair, 0:HighCard
    """
    if len(hand) != 5:
        return (0,)

    ranks = sorted([card[0] for card in hand], reverse=True)
    suits = [card[1] for card in hand]

    is_flush = len(set(suits)) == 1
    # Check for wheel straight (A-2-3-4-5) which gets sorted as (14, 5, 4, 3, 2)
    is_straight = (len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4)) or (ranks == [14, 5, 4, 3, 2])

    if is_straight and is_flush:
        return (8, ranks[1] if ranks[0] == 14 and ranks[1] == 5 else ranks[0])  # Handle wheel and regular straight flush

    rank_counts = collections.Counter(ranks)
    sorted_counts = sorted(rank_counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
    
    if sorted_counts[0][1] == 4:
        return (7, sorted_counts[0][0], sorted_counts[1][0])

    if sorted_counts[0][1] == 3 and sorted_counts[1][1] == 2:
        return (6, sorted_counts[0][0], sorted_counts[1][0])

    if is_flush:
        return (5, *ranks)

    if is_straight:
        return (4, ranks[1] if ranks[0] == 14 and ranks[1] == 5 else ranks[0])

    if sorted_counts[0][1] == 3:
        kickers = [r[0] for r in sorted_counts[1:]]
        return (3, sorted_counts[0][0], *kickers)

    if sorted_counts[0][1] == 2 and sorted_counts[1][1] == 2:
        pairs = sorted([sorted_counts[0][0], sorted_counts[1][0]], reverse=True)
        kicker = sorted_counts[2][0]
        return (2, *pairs, kicker)

    if sorted_counts[0][1] == 2:
        kickers = [r[0] for r in sorted_counts[1:]]
        return (1, sorted_counts[0][0], *kickers)
    
    return (0, *ranks)


class SimplePlayer(Bot):
    def __init__(self):
        """ Initializes the player. """
        super().__init__()
        self.hole_cards: List[str] = []
        self.big_blind_amount = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called at the start of each hand. """
        self.hole_cards = player_hands
        self.big_blind_amount = blind_amount

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each betting round. """
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of each betting round. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of a hand. """
        pass

    def _get_preflop_hand_strength(self, hole_cards: List[str]) -> int:
        """
        Categorizes pre-flop hand into a strength tier (1 is best, 6 is worst).
        """
        cards = sorted([parse_card(c) for c in hole_cards], key=lambda x: x[0], reverse=True)
        r1, r2 = cards[0][0], cards[1][0]
        is_suited = cards[0][1] == cards[1][1]
        
        if r1 == r2 and r1 >= 12: return 1  # AA, KK, QQ
        if r1 == 14 and r2 == 13 and is_suited: return 1 # AKs
        
        if r1 == r2 and r1 >= 10: return 2  # JJ, TT
        if r1 == 14 and (r2 >= 11 or (r2 == 10 and is_suited)): return 2  # AQs, AJs, ATs, AKo
        
        if r1 == r2 and r1 >= 8: return 3 # 99, 88
        if is_suited and r1 >= 11 and r2 >= 10: return 3 # KQs, QJs, JTs
        if r1 == 14 and not is_suited and r2 >= 11: return 3 # AQo, AJo
            
        if r1 == r2: return 4 # 77-22
        if is_suited and r1 == 14: return 4 # A9s-A2s
        if is_suited and abs(r1 - r2) <= 2: return 4 # Suited connectors/gappers
        
        if r1 >= 10 or r2 >= 10: return 5 # Any broadway card

        return 6 # Trash

    def _evaluate_best_hand(self, hole_cards_str: List[str], community_cards_str: List[str]) -> Tuple:
        """
        Finds the best 5-card hand from hole cards and community cards.
        """
        hole_cards = [parse_card(c) for c in hole_cards_str]
        community_cards = [parse_card(c) for c in community_cards_str]
        all_cards = hole_cards + community_cards

        if len(all_cards) < 5:
            return (0, *sorted([c[0] for c in hole_cards], reverse=True))
        
        best_rank = (-1,)
        for hand_combination in combinations(all_cards, 5):
            current_rank = get_hand_rank(list(hand_combination))
            if current_rank > best_rank:
                best_rank = current_rank
        return best_rank

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Main decision-making function. """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        amount_to_call = round_state.current_bet - my_bet
        can_check = (amount_to_call == 0)

        # --- Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            strength = self._get_preflop_hand_strength(self.hole_cards)
            
            # Tiers 1-2: Premium hands - Aggressive play
            if strength <= 2:
                # Raise to 3x Big Blind if opening, or 3x the current bet if re-raising
                desired_raise = max(self.big_blind_amount * 3, round_state.current_bet * 3)
                raise_amount = int(min(round_state.max_raise, max(round_state.min_raise, desired_raise)))
                
                if raise_amount > amount_to_call and raise_amount > 0:
                    return (PokerAction.ALL_IN, 0) if raise_amount >= remaining_chips else (PokerAction.RAISE, raise_amount)
                return (PokerAction.ALL_IN, 0) if amount_to_call >= remaining_chips else (PokerAction.CALL, 0)

            # Tiers 3-4: Playable hands - Cautious entry
            elif strength <= 4:
                # Call small raises, fold to big ones. Open-limp or check.
                if amount_to_call == 0:
                    return PokerAction.CHECK, 0
                if amount_to_call < remaining_chips * 0.1: # Call if it's less than 10% of our stack
                    return (PokerAction.ALL_IN, 0) if amount_to_call >= remaining_chips else (PokerAction.CALL, 0)
                return PokerAction.FOLD, 0
            
            # Tiers 5-6: Weak hands - Fold unless very cheap
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                # Fold to any raise unless we are the big blind and it's a single raise
                if amount_to_call <= self.big_blind_amount:
                     return (PokerAction.ALL_IN, 0) if amount_to_call >= remaining_chips else (PokerAction.CALL, 0)
                return PokerAction.FOLD, 0

        # --- Post-flop Strategy ---
        else:
            hand_rank = self._evaluate_best_hand(self.hole_cards, round_state.community_cards)
            rank_score = hand_rank[0]

            # Two Pair or better: Value bet/raise
            if rank_score >= 2:
                # Bet/Raise about 2/3 of the pot
                if can_check: # We can lead out with a bet
                    bet_amount = int(round_state.pot * 0.66)
                    bet_amount = int(min(round_state.max_raise, max(round_state.min_raise, bet_amount)))
                    if bet_amount > 0:
                         return (PokerAction.ALL_IN, 0) if bet_amount >= remaining_chips else (PokerAction.RAISE, bet_amount)
                    return PokerAction.CHECK, 0
                else: # Someone bet into us, we raise
                    desired_raise = int(round_state.pot * 0.66) + amount_to_call
                    raise_amount = int(min(round_state.max_raise, max(round_state.min_raise, desired_raise)))
                    if raise_amount > amount_to_call and raise_amount > 0:
                         return (PokerAction.ALL_IN, 0) if raise_amount >= remaining_chips else (PokerAction.RAISE, raise_amount)
                    return (PokerAction.ALL_IN, 0) if amount_to_call >= remaining_chips else (PokerAction.CALL, 0)

            # One Pair: Pot control
            elif rank_score == 1:
                if can_check:
                    return PokerAction.CHECK, 0
                # Call if bet is less than half the pot, otherwise fold
                if amount_to_call < (round_state.pot * 0.5):
                    return (PokerAction.ALL_IN, 0) if amount_to_call >= remaining_chips else (PokerAction.CALL, 0)
                return PokerAction.FOLD, 0
            
            # High Card / Bust: Check/Fold
            else:
                if can_check:
                    return PokerAction.CHECK, 0
                return PokerAction.FOLD, 0

        # Failsafe default action
        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)