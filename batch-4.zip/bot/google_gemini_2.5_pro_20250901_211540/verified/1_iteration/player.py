import collections
import itertools
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# Note: The PokerRound enum is not used in this implementation, but is available.
# from type.poker_round import PokerRound

class SimplePlayer(Bot):
    """
    A poker bot that plays a tight-aggressive (TAG) strategy.
    - Pre-flop: Uses a starting hand chart to decide whether to raise, call, or fold.
    - Post-flop: Evaluates hand strength (made hands and draws) and uses pot odds to make decisions.
    - Bet Sizing: Uses standard bet sizes (e.g., 3x BB pre-flop, 50-75% of pot post-flop).
    - It does not engage in complex bluffs or opponent modeling, aiming for solid, fundamental poker.
    """

    def __init__(self):
        """ Initializes the player, sets up card rank mapping. """
        super().__init__()
        self.hand: List[str] = []
        self.initial_stack: int = 0
        self.big_blind_amount: int = 0
        self.num_players: int = 0
        
        # Card rank mapping for evaluation
        self.ranks_str = '23456789TJQKA'
        self.rank_map = {rank: i for i, rank in enumerate(self.ranks_str, 2)}

    # --------------------------------- #
    # --- State Management Methods --- #
    # --------------------------------- #

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """ Called once at the start of a game. Stores initial state. """
        self.hand = player_hands
        self.initial_stack = starting_chips
        self.big_blind_amount = blind_amount
        self.num_players = len(all_players)

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the start of each new hand. """
        # We can reset any round-specific state here if needed in future versions.
        pass

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of a hand. Can be used for opponent modeling. """
        # In this version, we don't do any post-hand analysis.
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the very end of the game. """
        # Can be used for logging or final analysis.
        pass

    # --------------------------------- #
    # --- Core Action Logic --- #
    # --------------------------------- #

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        It is called whenever it is our turn to act.
        """
        # --- 1. Get Game State Information ---
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        
        # --- Safety Check: If we must bet more than we have, we are all-in ---
        if to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0

        # --- 2. Pre-flop Strategy ---
        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, to_call)

        # --- 3. Post-flop Strategy ---
        else:
            return self._get_postflop_action(round_state, remaining_chips, to_call)

    # --------------------------------- #
    # --- Pre-flop Decision Logic --- #
    # --------------------------------- #

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take before the flop. """
        strength = self._get_preflop_strength(self.hand)

        # Tier 1 (Premium: AA, KK, QQ, JJ, AK): Always raise or re-raise.
        if strength == 1:
            if to_call > 0:  # Re-raise
                raise_amount = to_call + round_state.pot
            else:  # Open raise
                raise_amount = self.big_blind_amount * 3
            final_amount = self._get_validated_raise_amount(raise_amount, remaining_chips, round_state, to_call)
            return PokerAction.RAISE, final_amount

        # Tier 2 (Very Strong: TT, 99, AQs, AJs, KQs): Raise if unopened, call otherwise.
        if strength == 2:
            if to_call > 0:
                if to_call < remaining_chips * 0.15: # Call raises up to 15% of stack
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else: # Open raise
                raise_amount = int(self.big_blind_amount * 2.5)
                final_amount = self._get_validated_raise_amount(raise_amount, remaining_chips, round_state, to_call)
                return PokerAction.RAISE, final_amount

        # Tier 3 (Good Playable: Mid pairs, suited connectors, good aces): Call small raises.
        if strength == 3:
            if to_call > self.big_blind_amount * 3 and self.big_blind_amount > 0: # Fold to large raises
                return PokerAction.FOLD, 0
            elif to_call > 0: # Call small-medium raises
                return PokerAction.CALL, 0
            else: # Limp or check
                return PokerAction.CALL, 0

        # Tier 4 (Speculative: Suited cards, some connectors): Play only if very cheap.
        if strength == 4:
            if to_call <= self.big_blind_amount and self.big_blind_amount > 0:
                return PokerAction.CALL, 0
            elif to_call == 0:
                return PokerAction.CHECK, 0
            return PokerAction.FOLD, 0

        # Tier 5 (Trash): Fold unless we are in the Big Blind and can check.
        if to_call > 0:
            return PokerAction.FOLD, 0
        return PokerAction.CHECK, 0

    # --------------------------------- #
    # --- Post-flop Decision Logic --- #
    # --------------------------------- #

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int) -> Tuple[PokerAction, int]:
        """ Determines the action to take on the flop, turn, or river. """
        pot = round_state.pot

        # 1. Evaluate Hand Strength and Potential
        hand_score, _ = self._get_best_hand(self.hand, round_state.community_cards)
        
        outs = 0
        if round_state.round != 'River':
            outs = self._calculate_outs(self.hand, round_state.community_cards)

        win_prob = self._calculate_win_prob(outs, round_state.round)

        # 2. Calculate Pot Odds
        pot_odds = 0.0
        if (pot + to_call) > 0:
            pot_odds = to_call / (pot + to_call)

        # 3. Decision Making
        
        # Monster Hand (Set or better)
        if hand_score >= 3:
            if to_call > 0: # Facing a bet
                if to_call > remaining_chips * 0.4:
                    return PokerAction.ALL_IN, 0
                raise_amount = to_call * 2.5 + pot
                final_amount = self._get_validated_raise_amount(raise_amount, remaining_chips, round_state, to_call)
                return PokerAction.RAISE, final_amount
            else: # Bet for value
                bet_amount = int(pot * 0.75)
                final_amount = self._get_validated_raise_amount(bet_amount, remaining_chips, round_state, to_call)
                return PokerAction.RAISE, final_amount
        
        # Strong Hand (Two Pair or Top Pair) or Good Draw (combo/flush draw)
        is_top_pair = self._is_top_pair(self.hand, round_state.community_cards, hand_score)
        if hand_score == 2 or is_top_pair or outs >= 8:
            equity = win_prob if outs >= 8 else 0.7 if is_top_pair else 0.8
            if to_call > 0: # Facing a bet
                if equity > pot_odds:
                     return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else: # Bet for value or as a semi-bluff
                bet_amount = int(pot * 0.6)
                final_amount = self._get_validated_raise_amount(bet_amount, remaining_chips, round_state, to_call)
                return PokerAction.RAISE, final_amount
        
        # Marginal Hand (Middle/Bottom Pair) or Weak Draw (gutshot)
        if hand_score == 1 or (4 <= outs < 8):
            if to_call > 0:
                if win_prob > pot_odds:
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            else:
                return PokerAction.CHECK, 0
        
        # Air / No Hand
        if to_call > 0:
            return PokerAction.FOLD, 0
        return PokerAction.CHECK, 0

    # --------------------------------- #
    # --- Hand Evaluation Helpers --- #
    # --------------------------------- #

    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """ Parses a card string like 'Th' into a tuple (10, 'h'). """
        return (self.rank_map[card_str[0]], card_str[1])

    def _get_preflop_strength(self, hole_cards: List[str]) -> int:
        """ Assigns a tier (1-5, 1 is best) to a pre-flop hand. """
        cards = [self._parse_card(c) for c in hole_cards]
        r1, r2 = sorted([c[0] for c in cards], reverse=True)
        is_suited = cards[0][1] == cards[1][1]
        
        if r1 == r2 and r1 >= self.rank_map['J']: return 1
        if r1 == 14 and r2 == 13: return 1
        if r1 == r2 and r1 >= self.rank_map['9']: return 2
        if is_suited and r1 == 14 and r2 >= self.rank_map['J']: return 2
        if is_suited and r1 == 13 and r2 == 12: return 2
        if r1 == r2: return 3
        if is_suited and (r1 == 14 or r1 - r2 < 2): return 3
        if not is_suited and r1 == 14 and r2 >= self.rank_map['Q']: return 3
        if is_suited: return 4
        if r1 - r2 < 5: return 4
        return 5

    def _get_best_hand(self, hole_cards_str: List[str], community_cards_str: List[str]) -> Tuple[int, tuple]:
        """ Finds the best 5-card hand from available cards. """
        all_cards_str = hole_cards_str + community_cards_str
        if len(all_cards_str) < 5:
            my_cards = [self._parse_card(c) for c in hole_cards_str]
            is_pair = my_cards[0][0] == my_cards[1][0]
            ranks = tuple(sorted([c[0] for c in my_cards], reverse=True))
            return (1, ranks) if is_pair else (0, ranks)

        all_cards = [self._parse_card(c) for c in all_cards_str]
        best_score = (-1,)
        for combo in itertools.combinations(all_cards, 5):
            score = self._evaluate_5_card_hand(list(combo))
            if score > best_score:
                best_score = score
        return best_score

    def _evaluate_5_card_hand(self, cards: List[Tuple[int, str]]) -> Tuple[int, tuple]:
        """ Helper to evaluate a single 5-card hand. """
        ranks = sorted([c[0] for c in cards], reverse=True)
        suits = {c[1] for c in cards}
        
        is_flush = len(suits) == 1
        is_straight = (len(set(ranks)) == 5 and ranks[0] - ranks[4] == 4) or (ranks == [14, 5, 4, 3, 2])

        if is_straight and is_flush: return (9,) if ranks[0] == 14 else (8, tuple(ranks))
        
        counts = collections.Counter(ranks)
        vals = sorted(counts.values(), reverse=True)
        rank_order = tuple(sorted(counts, key=lambda r: (counts[r], r), reverse=True))

        if vals[0] == 4: return (7, rank_order)
        if vals == [3, 2]: return (6, rank_order)
        if is_flush: return (5, tuple(ranks))
        if is_straight: return (4, (5,4,3,2,1)) if ranks == [14, 5, 4, 3, 2] else (4, tuple(ranks))
        if vals[0] == 3: return (3, rank_order)
        if vals == [2, 2, 1]: return (2, rank_order)
        if vals[0] == 2: return (1, rank_order)
        return (0, tuple(ranks))
    
    def _is_top_pair(self, hand_str, community_str, hand_score):
        """ Checks if the player's pair is the top pair on the board. """
        if hand_score != 1 or not community_str: return False
        
        hand = [self._parse_card(c)[0] for c in hand_str]
        community_ranks = [self._parse_card(c)[0] for c in community_str]
        
        all_ranks = hand + community_ranks
        counts = collections.Counter(all_ranks)
        pair_ranks = [r for r, c in counts.items() if c == 2]
        if not pair_ranks: return False
        
        my_pair_rank = pair_ranks[0]
        if my_pair_rank not in hand: return False
        return my_pair_rank > max(community_ranks)

    # --------------------------------- #
    # --- Probability Helpers --- #
    # --------------------------------- #
    
    def _calculate_outs(self, hole_cards_str: List[str], community_cards_str: List[str]) -> int:
        """ Calculates the number of 'outs' for straight and flush draws. """
        all_cards = [self._parse_card(c) for c in hole_cards_str + community_cards_str]
        
        suits = [c[1] for c in all_cards]
        suit_counts = collections.Counter(suits)
        flush_outs = 9 if 4 in suit_counts.values() else 0

        ranks = {c[0] for c in all_cards}
        straight_outs_set = set()
        for i in range(1, 11):
            window = set(range(i, i+5)) if i > 1 else {2,3,4,5,14}
            missing = window - ranks
            if len(missing) == 1:
                straight_outs_set.add(list(missing)[0])

        return flush_outs + len(straight_outs_set)

    def _calculate_win_prob(self, outs: int, current_round: str) -> float:
        """ Approximates win probability using the Rule of 2 and 4. """
        if current_round == 'Flop': return (outs * 4) / 100.0
        if current_round == 'Turn': return (outs * 2) / 100.0
        return 0.0

    # --------------------------------- #
    # --- Action Validation Helper --- #
    # --------------------------------- #

    def _get_validated_raise_amount(self, desired_amount: int, remaining_chips: int, rs: RoundStateClient, to_call: int) -> int:
        """ Ensures a raise amount is within the legal and practical limits. """
        my_current_bet = rs.player_bets.get(str(self.id), 0)
        
        # The amount returned for RAISE is a *total bet*, not the raise-on-top amount.
        min_total_bet = rs.min_raise
        max_total_bet = remaining_chips + my_current_bet

        validated_amount = int(max(min_total_bet, min(desired_amount + my_current_bet, max_total_bet)))
        
        # If the only valid raise is all-in, go all-in
        if validated_amount >= max_total_bet:
            return max_total_bet
        
        return validated_amount