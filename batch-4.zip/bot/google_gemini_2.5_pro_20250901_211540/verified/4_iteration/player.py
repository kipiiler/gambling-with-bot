import random
from itertools import combinations
from typing import List, Tuple

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

class SimplePlayer(Bot):
    """
    A poker bot that plays a solid, fundamental-based No-Limit Texas Hold'em strategy.
    - Pre-flop: Uses a tiered hand-ranking system to make decisions based on hand strength and position.
    - Post-flop: Evaluates made hands and draws to calculate a strength score, then acts based on that score and pot odds.
    - Bet Sizing: Uses standard bet sizes relative to the pot.
    - Risk Management: Plays conservatively to preserve chips, avoiding overly risky plays with marginal hands.
    """

    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.all_player_ids: List[int] = []
        self.big_blind_amount: int = 0
        self.big_blind_player_id: int = 0

        self.ranks_str = 'AKQJT98765432'
        self.suits = 'shdc'
        # This will be populated by _create_preflop_rankings
        self.preflop_hand_rankings = self._create_preflop_rankings()

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.all_player_ids = all_players
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.hand = round_state.player_hands.get(str(self.id))

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        Returns the action for the player based on the current game state.
        """
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)
        can_check = amount_to_call == 0

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, remaining_chips, amount_to_call, can_check)
        else:
            return self._get_postflop_action(round_state, remaining_chips, amount_to_call, can_check)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. Can be used for opponent modeling. """
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    # --- Pre-flop Logic ---

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        hand_rank_tier = self._get_hand_rank_tier(self.hand)

        num_players_in_hand = sum(1 for bet in round_state.player_bets.values() if bet > 0)
        is_open_opportunity = round_state.current_bet == self.big_blind_amount

        # Opening strategy
        if is_open_opportunity:
            # Looser raises from later positions
            is_late_position = self._is_late_position(round_state)
            raise_tier_threshold = 5 if is_late_position else 3

            if hand_rank_tier <= raise_tier_threshold:
                raise_amount = int(self.big_blind_amount * 2.5)
                return self._get_validated_raise_action(raise_amount, round_state, remaining_chips)
            
            # Limping with some speculative hands if cheap
            if hand_rank_tier <= 6 and amount_to_call <= self.big_blind_amount:
                return PokerAction.CALL, 0

            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

        # Responding to a raise
        else:
            # 3-bet with premium hands
            if hand_rank_tier <= 2: # AA, KK, QQ, JJ, AKs
                # Raise 3x the current bet
                raise_amount = round_state.current_bet * 3
                return self._get_validated_raise_action(raise_amount, round_state, remaining_chips)
            
            # Call with strong-to-decent hands if the price is right
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)
            if hand_rank_tier <= 5 and pot_odds < 0.2: # Call with top ~20% of hands for a small price
                return PokerAction.CALL, 0

            return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    # --- Post-flop Logic ---

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, amount_to_call: int, can_check: bool) -> Tuple[PokerAction, int]:
        made_hand_rank, _ = self._find_best_hand(self.hand + round_state.community_cards)
        draw_outs = self._get_draw_outs(self.hand, round_state.community_cards)

        unseen_cards = 52 - len(self.hand) - len(round_state.community_cards)
        draw_equity = draw_outs / (unseen_cards + 1e-9) if unseen_cards > 0 else 0
        
        # Simplified win probability estimation
        made_hand_win_prob = {
            9: 1.0, 8: 1.0, 7: 0.98, 6: 0.95, # RoyalFlush -> Full House
            5: 0.90, 4: 0.85, 3: 0.75,       # Flush, Straight, Trips
            2: 0.65, 1: 0.55, 0: 0.20        # TwoPair, Pair, HighCard
        }.get(made_hand_rank, 0)

        # Combined equity approximation
        equity = made_hand_win_prob + (1 - made_hand_win_prob) * draw_equity

        pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9) if amount_to_call > 0 else 0

        # Action based on equity
        if equity > 0.85: # Monster hand
            bet_amount = int(round_state.pot * 0.75)
            return self._get_validated_raise_action(bet_amount, round_state, remaining_chips, is_bet=can_check)
        
        if equity > 0.6: # Strong hand, value bet
            if can_check:
                bet_amount = int(round_state.pot * 0.5)
                return self._get_validated_raise_action(bet_amount, round_state, remaining_chips, is_bet=True)
            else: # Facing a bet
                if equity > pot_odds:
                    return PokerAction.CALL, 0
        
        if equity > 0.4 and draw_outs > 0: # Good draw or decent made hand
            if can_check:
                return PokerAction.CHECK, 0
            else: # Facing a bet
                if equity > pot_odds: # Profitable to call and chase draw
                    return PokerAction.CALL, 0
        
        # Low equity, play passively or fold
        return (PokerAction.CHECK, 0) if can_check else (PokerAction.FOLD, 0)

    # --- Hand Evaluation Helpers ---

    def _find_best_hand(self, all_cards: List[str]) -> Tuple[int, List[int]]:
        """ Finds the best 5-card hand from a list of 7 or fewer cards. """
        if len(all_cards) < 5:
            return -1, []
        
        best_rank = -1
        best_kickers = [99] * 5

        for hand_combo in combinations(all_cards, 5):
            rank, kickers = self._rank_5_card_hand(list(hand_combo))
            if rank > best_rank:
                best_rank = rank
                best_kickers = kickers
            elif rank == best_rank:
                if kickers < best_kickers: # Lower kicker values are better
                    best_kickers = kickers
        return best_rank, best_kickers

    def _rank_5_card_hand(self, hand: List[str]) -> Tuple[int, List[int]]:
        """ Ranks a 5-card hand and returns its rank and sorted kickers for tie-breaking. """
        ranks_indices = sorted([self.ranks_str.index(c[0]) for c in hand])
        suits = [c[1] for c in hand]
        
        is_flush = len(set(suits)) == 1
        is_straight = (len(set(ranks_indices)) == 5 and (ranks_indices[4] - ranks_indices[0] == 4)) or (ranks_indices == [0, 9, 10, 11, 12]) # Ace-low
        
        if is_straight and is_flush:
            return (9, ranks_indices) if ranks_indices[0] == 0 else (8, ranks_indices) # Royal/Straight Flush
        
        rank_counts = {r: ranks_indices.count(r) for r in set(ranks_indices)}
        counts = sorted(rank_counts.values(), reverse=True)
        
        if counts[0] == 4: return 7, self._sort_ranks_by_count(rank_counts) # 4-of-a-Kind
        if counts == [3, 2]: return 6, self._sort_ranks_by_count(rank_counts) # Full House
        if is_flush: return 5, ranks_indices # Flush
        if is_straight:
            # Ace-low straights should use A as low for tiebreak [A,5,4,3,2] -> [5,4,3,2,A]
            return (4, [9, 10, 11, 12, 0]) if ranks_indices == [0, 9, 10, 11, 12] else (4, ranks_indices)
        if counts[0] == 3: return 3, self._sort_ranks_by_count(rank_counts) # 3-of-a-Kind
        if counts == [2, 2, 1]: return 2, self._sort_ranks_by_count(rank_counts) # Two Pair
        if counts == [2, 1, 1, 1]: return 1, self._sort_ranks_by_count(rank_counts) # One Pair
        
        return 0, ranks_indices # High Card

    def _get_draw_outs(self, my_cards: List[str], community_cards: List[str]) -> int:
        """ Calculates number of outs for flush and straight draws. """
        all_cards = my_cards + community_cards
        
        # Flush outs
        suits_on_board = [c[1] for c in all_cards]
        suit_counts = {s: suits_on_board.count(s) for s in self.suits}
        flush_outs = 0
        for s in self.suits:
            if suit_counts[s] == 4:
                flush_outs = 9 # 13 cards of a suit - 4 on board
                break

        # Straight outs
        ranks_on_board_idx = list(set([self.ranks_str.index(c[0]) for c in all_cards]))
        straight_outs = 0
        
        # Check all possible next cards
        potential_cards = [r + s for r in self.ranks_str for s in self.suits]
        current_card_set = set(all_cards)
        
        for card in potential_cards:
            if card in current_card_set:
                continue
            
            temp_hand = all_cards + [card]
            rank, _ = self._find_best_hand(temp_hand)
            # Check if this card completed a straight (and wasn't already a straight)
            original_rank, _ = self._find_best_hand(all_cards)
            if rank == 4 and original_rank < 4:
                straight_outs += 1
        
        # Avoid double-counting straight-flush outs (simplified)
        return flush_outs + straight_outs

    # --- Pre-flop Hand Ranking Helpers ---
    
    def _create_preflop_rankings(self) -> dict:
        """ Creates a dictionary mapping normalized hand strings to a rank tier. """
        # Using a standard tier list. Lower tier is better.
        groups = [
            ['AA', 'KK'], # Tier 1
            ['QQ', 'JJ', 'AKs'], # Tier 2
            ['TT', 'AQs', 'AJs', 'KQs', 'AKo'], # Tier 3
            ['99', 'ATs', 'KJs', 'QJs', 'JTs', 'AQo'], # Tier 4
            ['88', 'A9s', 'A8s', 'KTs', 'QTs', 'J9s', 'T9s', '98s', 'AJo', 'KQo'], # Tier 5
            ['77', 'A7s-A2s', 'K9s', 'Q9s', 'T8s', '97s', '87s', '76s', '65s', 'ATo', 'KJo'], # Tier 6
            ['66', '55', 'K8s-K2s', 'Q8s', 'J8s', '86s', '75s', '54s', 'QJo', 'JTo', 'T9o'], # Tier 7
            ['44', '33', '22', 'Q7s-Q2s', 'J7s', 'T7s', 'A9o', 'KTo', 'QTo', 'J9o', '87o'] # Tier 8
        ]
        
        rankings = {}
        tier = 1
        for group in groups:
            for hand_range in group:
                expanded_hands = self._expand_range(hand_range)
                for hand in expanded_hands:
                    key = self._normalize_hand_key(hand)
                    if key not in rankings:
                        rankings[key] = tier
            tier += 1
        return rankings

    def _expand_range(self, range_str: str) -> List[str]:
        """ Expands hand ranges like 'A9s-A2s' into ['A9s', 'A8s', ...]. """
        if '-' not in range_str:
            return [range_str]

        start_hand, end_hand = range_str.split('-')
        r1 = start_hand[0]
        suit_type = start_hand[2] if len(start_hand) > 2 else None
        
        idx_start = self.ranks_str.index(start_hand[1])
        idx_end = self.ranks_str.index(end_hand[1])

        if idx_start > idx_end: # Ensure loop is from high rank to low
             idx_start, idx_end = idx_end, idx_start

        hands = []
        for i in range(idx_start, idx_end + 1):
            r2 = self.ranks_str[i]
            if r1 != r2:
                hands.append(f"{r1}{r2}{suit_type}")
        return hands

    def _get_hand_rank_tier(self, my_cards: List[str]) -> int:
        """ Gets the pre-calculated rank tier for the player's hand. """
        if not my_cards or len(my_cards) != 2: return 99 # Invalid hand
        key = self._normalize_hand_key(f"{my_cards[0][0]}{my_cards[1][0]}{'s' if my_cards[0][1] == my_cards[1][1] and my_cards[0][0] != my_cards[1][0] else '' if my_cards[0][0] == my_cards[1][0] else 'o'}")
        return self.preflop_hand_rankings.get(key, 99)

    def _normalize_hand_key(self, hand_str: str) -> str:
        """ Normalizes hand strings like 'AKs' or 'KJo' to a consistent key like 'AK' or 'KQ'. """
        if len(hand_str) == 2: # Pocket pair, e.g., 'AA'
            return hand_str
        
        r1, r2 = hand_str[0], hand_str[1]
        s = hand_str[2] if len(hand_str) > 2 else ''

        idx1, idx2 = self.ranks_str.index(r1), self.ranks_str.index(r2)
        
        # For lookup, order by rank (AK, not KA), and differentiate suited vs off-suit
        # Off-suit key: 'King Queen' -> 'QK' (lower rank first)
        # Suited key: 'King Queen' -> 'KQ' (higher rank first)
        if s == 's':
            return f"{r1}{r2}" if idx1 < idx2 else f"{r2}{r1}"
        else: # Paired or off-suit
            return f"{r2}{r1}" if idx1 < idx2 else f"{r1}{r2}"


    # --- General Helpers ---
    def _is_late_position(self, round_state: RoundStateClient):
        """ Crudely determines if the player is in a late position. """
        if not self.all_player_ids or self.big_blind_player_id not in self.all_player_ids:
            return False
        
        num_players = len(self.all_player_ids)
        my_idx = self.all_player_ids.index(self.id)
        bb_idx = self.all_player_ids.index(self.big_blind_player_id)
        
        # Position relative to the big blind. 0 is UTG.
        relative_pos = (my_idx - bb_idx - 1 + num_players) % num_players
        
        # In a 6-handed game, 2 players after UTG are late (CO, BTN)
        return relative_pos > num_players / 2

    def _get_validated_raise_action(self, amount: int, round_state: RoundStateClient, remaining_chips: int, is_bet: bool=False) -> Tuple[PokerAction, int]:
        """ Ensures a raise/bet action is valid and returns the appropriate action tuple. """
        if amount >= remaining_chips:
            return PokerAction.ALL_IN, 0

        if is_bet: # This is an opening bet, not a raise
            valid_amount = min(remaining_chips, max(self.big_blind_amount, amount))
            return PokerAction.RAISE, valid_amount

        # This is a raise over a previous bet
        valid_amount = min(round_state.max_raise, max(round_state.min_raise, amount))
        return PokerAction.RAISE, valid_amount

    def _sort_ranks_by_count(self, rank_counts: dict) -> List[int]:
        """ Sorts ranks based on their frequency, then value, for tie-breaking. """
        # E.g., for two pair KK, QQ, 5 => sort to put pairs first
        sorted_by_count = sorted(rank_counts.items(), key=lambda item: (-item[1], item[0]))
        result_ranks = []
        for rank, count in sorted_by_count:
            result_ranks.extend([rank] * count)
        return result_ranks