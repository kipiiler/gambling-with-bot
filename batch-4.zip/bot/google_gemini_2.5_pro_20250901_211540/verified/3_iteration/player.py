import collections
import itertools
from typing import List, Tuple, Dict

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

# --- Helper Classes and Functions ---

class PokerHandEvaluator:
    """
    Evaluates a 7-card poker hand and returns its rank and a score for tie-breaking.
    Ranks: 9 (Royal Flush) -> 0 (High Card).
    """
    def __init__(self):
        self.card_rank_map = self._create_card_rank_map()
        self.hand_rank_hierarchy = {
            9: "Royal Flush", 8: "Straight Flush", 7: "Four of a Kind", 6: "Full House",
            5: "Flush", 4: "Straight", 3: "Three of a Kind", 2: "Two Pair",
            1: "One Pair", 0: "High Card"
        }

    def _create_card_rank_map(self):
        ranks = '23456789TJQKA'
        return {rank: i for i, rank in enumerate(ranks, 2)}

    def evaluate_hand(self, hole_cards: List[str], community_cards: List[str]) -> Tuple[int, List[int]]:
        all_cards = hole_cards + community_cards
        if not all_cards:
            return 0, []

        all_card_combinations = itertools.combinations(all_cards, 5)
        best_rank = -1
        best_score = []

        for hand_tuple in all_card_combinations:
            hand = list(hand_tuple)
            ranks = sorted([self.card_rank_map[r[:-1]] for r in hand], reverse=True)
            suits = [s[-1] for s in hand]
            
            is_flush = len(set(suits)) == 1
            # Python's a-b != 1 does not work for straights with Ace
            is_straight = self._is_straight(ranks)

            if is_straight and is_flush:
                if ranks[0] == 14 and ranks[4] == 10: # Ace-high straight flush
                    rank, score = 9, ranks # Royal Flush
                else:
                    rank, score = 8, ranks # Straight Flush
            elif is_flush:
                rank, score = 5, ranks # Flush
            elif is_straight:
                rank, score = 4, ranks # Straight
            else:
                rank, score = self._evaluate_pairs(ranks)

            if rank > best_rank:
                best_rank = rank
                best_score = score
            elif rank == best_rank:
                # Tie-breaking
                for i in range(len(score)):
                    if score[i] > best_score[i]:
                        best_score = score
                        break
                    if score[i] < best_score[i]:
                        break
        return best_rank, best_score

    def _is_straight(self, ranks: List[int]) -> bool:
        # Check for regular straight
        if len(set(ranks)) == 5 and (ranks[0] - ranks[4] == 4):
            return True
        # Check for wheel (A, 2, 3, 4, 5)
        if ranks == [14, 5, 4, 3, 2]:
            return True
        return False

    def _evaluate_pairs(self, ranks: List[int]) -> Tuple[int, List[int]]:
        counts = collections.Counter(ranks)
        
        # Sort ranks by count desc, then rank desc
        sorted_ranks = sorted(counts.keys(), key=lambda r: (counts[r], r), reverse=True)
        
        if counts[sorted_ranks[0]] == 4:
            # Four of a Kind
            score = sorted_ranks
            return 7, score
        if counts[sorted_ranks[0]] == 3 and counts[sorted_ranks[1]] == 2:
            # Full House
            score = sorted_ranks
            return 6, score
        if counts[sorted_ranks[0]] == 3:
            # Three of a Kind
            score = sorted_ranks
            return 3, score
        if counts[sorted_ranks[0]] == 2 and counts[sorted_ranks[1]] == 2:
            # Two Pair
            score = sorted_ranks
            return 2, score
        if counts[sorted_ranks[0]] == 2:
            # One Pair
            score = sorted_ranks
            return 1, score
        # High Card
        return 0, sorted_ranks

# Main Bot Class
class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.hand_evaluator = PokerHandEvaluator()
        self.preflop_hand_rankings = self._create_preflop_rankings()
        
        # State reset each round
        self.my_hand: List[str] = []
        self.was_preflop_aggressor = False
        self.num_active_players = 0
        self.big_blind_amount = 10

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        self.my_hand = player_hands
        self.big_blind_amount = blind_amount
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        self.my_hand = round_state.player_hands.get(str(self.id), self.my_hand)
        active_players_count = len([bet for bet in round_state.player_bets.values() if bet != -1])
        self.num_active_players = active_players_count if active_players_count > 0 else len(round_state.player_bets)
        if round_state.round == "Preflop":
            self.was_preflop_aggressor = False

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Basic state calculation
        legal_actions = self._get_legal_actions(round_state, remaining_chips)
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)

        if round_state.round == 'Preflop':
            return self._get_preflop_action(round_state, legal_actions, amount_to_call)
        else:
            return self._get_postflop_action(round_state, remaining_chips, legal_actions, amount_to_call)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset round-specific state
        self.was_preflop_aggressor = False

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        pass # No complex learning implemented for now

    # --- Pre-flop Strategy ---

    def _get_preflop_action(self, round_state: RoundStateClient, legal_actions: Dict, amount_to_call: int) -> Tuple[PokerAction, int]:
        hand_strength = self._get_preflop_hand_strength(self.my_hand)

        # Adjust strategy based on number of players
        if self.num_active_players >= 6: # Full table
            raise_threshold, call_threshold = 0.85, 0.70 # Play tight (top 15% raise, 15-30% call)
        elif self.num_active_players >= 3: # Shorthanded
            raise_threshold, call_threshold = 0.75, 0.55 # Play medium (top 25% raise, 25-50% call)
        else: # Heads-up
            raise_threshold, call_threshold = 0.50, 0.0 # Play loose (top 50% raise, any other playable hand call)

        # Action logic
        can_raise = PokerAction.RAISE in legal_actions
        
        if amount_to_call == 0: # No bet yet, we can check or raise
            if hand_strength >= raise_threshold and can_raise:
                raise_amount = self._calculate_raise_amount(round_state, 3 * self.big_blind_amount)
                self.was_preflop_aggressor = True
                return legal_actions.get(PokerAction.RAISE, (PokerAction.CALL, 0))(raise_amount)
            elif hand_strength >= call_threshold:
                 return legal_actions[PokerAction.CALL]
            else:
                 return legal_actions.get(PokerAction.CHECK, legal_actions[PokerAction.FOLD])
        else: # Facing a bet or raise
            # Only play strong hands against a raise
            premium_threshold = 0.90 # Top 10%
            if hand_strength >= premium_threshold and can_raise:
                # 3-bet
                three_bet_size = 3 * round_state.current_bet
                raise_amount = self._calculate_raise_amount(round_state, three_bet_size)
                self.was_preflop_aggressor = True
                return legal_actions.get(PokerAction.RAISE, (PokerAction.CALL, 0))(raise_amount)

            # Call if the price is right with a decent hand
            pot_odds = amount_to_call / (round_state.pot + amount_to_call + 1e-9)
            if hand_strength >= call_threshold and pot_odds < 0.2: # Call small bets
                return legal_actions[PokerAction.CALL]
        
        if amount_to_call > 0 and amount_to_call < self.big_blind_amount and self.id == round_state.big_blind_player_id:
            # If in BB and it's a cheap call, check our option.
            return legal_actions[PokerAction.CALL]
            
        return legal_actions[PokerAction.FOLD]
    
    # --- Post-flop Strategy ---

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, legal_actions: Dict, amount_to_call: int) -> Tuple[PokerAction, int]:
        hand_rank, _ = self.hand_evaluator.evaluate_hand(self.my_hand, round_state.community_cards)
        outs, is_strong_draw = self._count_outs(self.my_hand, round_state.community_cards)

        pot = round_state.pot
        pot_odds = amount_to_call / (pot + amount_to_call + 1e-9) if amount_to_call > 0 else 0

        # Equity approximation (Rule of 2 and 4)
        equity = 0
        if round_state.round == 'Flop':
            equity = outs * 4 / 100.0
        elif round_state.round == 'Turn':
            equity = outs * 2 / 100.0
            
        is_made_hand = hand_rank >= 1 # At least a pair
        is_strong_made_hand = hand_rank >= 3 # Three of a kind or better
        is_monster_hand = hand_rank >= 6 # Full house or better

        # Facing a bet
        if amount_to_call > 0:
            if is_monster_hand:
                raise_amount = self._calculate_raise_amount(round_state, pot + 2 * amount_to_call)
                return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.ALL_IN])(raise_amount)
            if is_strong_made_hand:
                return legal_actions[PokerAction.CALL]
            if is_made_hand: # One or Two Pair
                if pot_odds < 0.35: # call if getting good price
                    return legal_actions[PokerAction.CALL]
            if equity > pot_odds: # Call with draws if odds are good
                return legal_actions[PokerAction.CALL]
            return legal_actions[PokerAction.FOLD]
        
        # Not facing a bet (we can check or bet)
        else:
            # Continuation Bet: If we were preflop aggressor and it's checked to us
            if self.was_preflop_aggressor and self.num_active_players <= 3 and round_state.round == 'Flop':
                bet_amount = self._calculate_raise_amount(round_state, pot * 0.5)
                return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.CHECK])(bet_amount)

            if is_monster_hand: # Slow play a bit on flop, bet hard on turn/river
                if round_state.round == 'Flop':
                    return legal_actions[PokerAction.CHECK]
                else:
                    bet_amount = self._calculate_raise_amount(round_state, pot * 0.8)
                    return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.CHECK])(bet_amount)

            if is_strong_made_hand: # Value bet
                bet_amount = self._calculate_raise_amount(round_state, pot * 0.7)
                return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.CHECK])(bet_amount)

            if is_made_hand: # Value bet smaller
                bet_amount = self._calculate_raise_amount(round_state, pot * 0.5)
                return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.CHECK])(bet_amount)

            if is_strong_draw: # Semi-bluff
                bet_amount = self._calculate_raise_amount(round_state, pot * 0.6)
                return legal_actions.get(PokerAction.RAISE, legal_actions[PokerAction.CHECK])(bet_amount)

            return legal_actions[PokerAction.CHECK]

    # --- Helper Methods ---

    def _get_legal_actions(self, round_state: RoundStateClient, remaining_chips: int) -> Dict:
        """Determines the set of legal actions for the current turn."""
        actions = {}
        amount_to_call = round_state.current_bet - round_state.player_bets.get(str(self.id), 0)

        # ALL_IN is always an option
        actions[PokerAction.ALL_IN] = lambda _: (PokerAction.ALL_IN, 0)

        if amount_to_call == 0:
            actions[PokerAction.CHECK] = lambda _: (PokerAction.CHECK, 0)
        
        if amount_to_call > 0:
            # Can only call if we have enough chips
            if remaining_chips > amount_to_call:
                actions[PokerAction.CALL] = lambda _: (PokerAction.CALL, 0)
            actions[PokerAction.FOLD] = lambda _: (PokerAction.FOLD, 0)

        # Can only raise if we have more chips than the call amount
        if remaining_chips > amount_to_call and round_state.min_raise is not None and remaining_chips >= round_state.min_raise:
            actions[PokerAction.RAISE] = lambda amount: (PokerAction.RAISE, amount)

        # If call costs all chips, it is an all-in
        if PokerAction.CALL in actions and amount_to_call >= remaining_chips:
            actions[PokerAction.CALL] = actions[PokerAction.ALL_IN]
            
        # Default to fold if no other action is possible
        if not actions:
            actions[PokerAction.FOLD] = lambda _: (PokerAction.FOLD, 0)
            
        return actions

    def _get_preflop_hand_strength(self, hand: List[str]) -> float:
        """Returns a normalized strength (0-1) for a 2-card preflop hand."""
        if not hand or len(hand) != 2:
            return 0.0
        
        ranks = sorted([self.hand_evaluator.card_rank_map[c[:-1]] for c in hand], reverse=True)
        suits = [c[-1] for c in hand]
        
        r1, r2 = ranks[0], ranks[1]
        rank_str_map = {v: k for k, v in self.hand_evaluator.card_rank_map.items()}
        
        key = f"{rank_str_map[r1]}{rank_str_map[r2]}"
        if suits[0] == suits[1]:
            key += 's'
        elif r1 != r2:
            key += 'o'
            
        # Handle cases like AKs vs KAs
        if key not in self.preflop_hand_rankings:
            key = f"{rank_str_map[r2]}{rank_str_map[r1]}"
            if suits[0] == suits[1]:
                key += 's'
            elif r1 != r2:
                key += 'o'

        rank = self.preflop_hand_rankings.get(key, 169)
        return 1.0 - (rank -1) / 168.0

    def _calculate_raise_amount(self, round_state: RoundStateClient, desired_amount: int) -> int:
        """Calculates a valid raise amount, clamped to min/max."""
        min_raise = round_state.min_raise if round_state.min_raise is not None else 2 * self.big_blind_amount
        max_raise = round_state.max_raise if round_state.max_raise is not None else float('inf')
        
        return int(max(min_raise, min(max_raise, desired_amount)))

    def _count_outs(self, my_hand: List[str], community_cards: List[str]) -> Tuple[int, bool]:
        """Counts outs for straight and flush draws."""
        all_cards = my_hand + community_cards
        ranks = sorted([self.hand_evaluator.card_rank_map[c[:-1]] for c in all_cards], reverse=True)
        suits = [c[-1] for c in all_cards]
        
        # Flush draw
        suit_counts = collections.Counter(suits)
        flush_outs = 0
        if any(c == 4 for c in suit_counts.values()):
            flush_outs = 9

        # Straight draw
        unique_ranks = sorted(list(set(ranks)))
        straight_outs = 0
        
        if len(unique_ranks) >= 4:
            for i in range(len(unique_ranks) - 3):
                # Open-ended straight draw
                sub_seq = unique_ranks[i:i+4]
                if sub_seq[-1] - sub_seq[0] == 3:
                     # Check if it's not part of an existing straight
                    if len(all_cards) == 5 and self._is_straight_on_board(community_cards):
                        continue
                    
                    is_oesd = True
                    # Avoid Ace-low OESD count (e.g. A,2,3,4 on board gives only one out: 5)
                    if sub_seq[0] == 2 and 14 in unique_ranks: # A,2,3,4
                         straight_outs = max(straight_outs, 4)
                         is_oesd = False
                    
                    if is_oesd:
                        straight_outs = max(straight_outs, 8)

                # Gutshot draw
                if i < len(unique_ranks) - 2 and unique_ranks[i+2] - unique_ranks[i] == 3 and unique_ranks[i+1]-unique_ranks[i] == 1: # e.g., 4,5,7
                    straight_outs = max(straight_outs, 4)
                if i < len(unique_ranks) - 2 and unique_ranks[i+2] - unique_ranks[i] == 4 and unique_ranks[i+1]-unique_ranks[i] == 2: # e.g., 4,6,8
                    straight_outs = max(straight_outs, 4)

        total_outs = flush_outs + straight_outs
        # Be careful of double counting for straight flushes
        is_strong_draw = total_outs >= 8
        return total_outs, is_strong_draw
    
    def _is_straight_on_board(self, board):
        if len(board) < 5: return False
        ranks = sorted([self.hand_evaluator.card_rank_map[r[:-1]] for r in board], reverse=True)
        return self.hand_evaluator._is_straight(ranks)

    def _create_preflop_rankings(self) -> Dict:
        """Creates a ranking of all 169 unique preflop hands."""
        ranks = 'AKQJT98765432'
        suited_hands = [f"{r1}{r2}s" for i, r1 in enumerate(ranks) for r2 in ranks[i + 1:]]
        offsuit_hands = [f"{r1}{r2}o" for i, r1 in enumerate(ranks) for r2 in ranks[i + 1:]]
        pair_hands = [f"{r}{r}" for r in ranks]

        # Sklansky-Malmuth hand groups, simplified
        group1 = "AA KK QQ JJ AKs".split()
        group2 = "AQs AJs KQs TT AKo".split()
        group3 = "ATs KJs QJs JTs AQo 99".split()
        group4 = "A9s-A2s KTs QTs J9s T9s 98s AJo KQo 88".split()
        group5 = "87s 77 66 55 K9s Q9s J8s T8s ATo KJo QJo".split()
        
        def expand_range(hand_range):
            hands = set()
            for hand in hand_range:
                if '-' in hand:
                    base, end_rank = hand.split('-')
                    start_rank_char, other_char, s_o = base[0], base[1], base[2:]
                    start_idx = ranks.index(start_rank_char)
                    other_idx = ranks.index(other_char)
                    end_idx = ranks.index(end_rank)
                    for r_idx in range(other_idx, end_idx + 1):
                        hands.add(f"{start_rank_char}{ranks[r_idx]}{s_o}")
                else:
                    hands.add(hand)
            return list(hands)

        # Combine all hands into a list, ordered by strength
        hand_order = []
        hand_order.extend(group1)
        hand_order.extend(group2)
        hand_order.extend(group3)
        hand_order.extend(expand_range(group4))
        hand_order.extend(expand_range(group5))
        
        # Add remaining hands to fill out the 169
        all_hands_set = set(suited_hands + offsuit_hands + pair_hands)
        ordered_set = set(hand_order)
        remaining = sorted(list(all_hands_set - ordered_set)) # Sort for consistency
        hand_order.extend(remaining)

        return {hand: i + 1 for i, hand in enumerate(hand_order)}