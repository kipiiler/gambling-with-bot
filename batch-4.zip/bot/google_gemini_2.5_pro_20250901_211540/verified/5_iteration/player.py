import itertools
import random
from collections import Counter
from typing import List, Tuple

# Make sure to use the imports from the game engine, not these stubs
try:
    from bot import Bot
    from type.poker_action import PokerAction
    from type.round_state import RoundStateClient
except ImportError:
    # These are stubs for local testing and should not be part of the final submission.
    # The game server will provide the actual classes.
    from enum import Enum
    from dataclasses import dataclass
    from typing import Dict, Any
    from abc import ABC, abstractmethod

    class PokerAction(Enum):
        FOLD = 1
        CHECK = 2
        CALL = 3
        RAISE = 4
        ALL_IN = 5

    @dataclass
    class RoundStateClient:
        round_num: int
        round: str
        community_cards: List[str]
        pot: int
        current_player: List[int]
        current_bet: int
        min_raise: int
        max_raise: int
        player_bets: Dict[str, int]
        player_actions: Dict[str, str]
        side_pots: list = None

    class Bot(ABC):
        def __init__(self) -> None:
            self.id = None
        def set_id(self, player_id: int) -> None:
            self.id = player_id
        @abstractmethod
        def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]) -> None: pass
        @abstractmethod
        def on_round_start(self, round_state: RoundStateClient, remaining_chips: int) -> None: pass
        @abstractmethod
        def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]: pass
        @abstractmethod
        def on_end_round(self, round_state: RoundStateClient, remaining_chips: int) -> None: pass
        @abstractmethod
        def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict) -> None: pass


class SimplePlayer(Bot):
    """
    A poker bot that implements a strategy based on pre-flop hand strength,
    post-flop hand evaluation, and simple betting logic.
    """
    def __init__(self):
        super().__init__()
        self.hand: List[str] = []
        self.stack: int = 0
        self.big_blind_amount: int = 0
        self.num_players: int = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        """
        Called once at the start of each hand. This is where the bot receives its hole cards.
        """
        self.stack = starting_chips
        self.hand = player_hands
        self.big_blind_amount = blind_amount
        self.num_players = len(all_players)
        
    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        """
        Called at the start of each betting round (Pre-flop, Flop, Turn, River).
        The primary purpose here is to update our chip count.
        The error from the previous iteration was trying to access hand here, which is incorrect.
        """
        self.stack = remaining_chips

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """
        This is the main decision-making function of the bot.
        """
        my_bet = round_state.player_bets.get(str(self.id), 0)
        to_call = round_state.current_bet - my_bet
        active_players = len(round_state.player_bets)

        # Pre-flop strategy
        if round_state.round == 'Preflop' or not round_state.community_cards:
            return self._get_preflop_action(round_state, remaining_chips, to_call, active_players)
        
        # Post-flop strategy
        else:
            return self._get_postflop_action(round_state, remaining_chips, to_call, active_players)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        self.stack = remaining_chips

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        """ Called at the end of the game. """
        pass

    # ------------------- Helper Functions -------------------

    def _get_preflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, active_players: int):
        strength = self._get_preflop_strength()

        # Premium hands (AA, KK, QQ, AKs, JJ)
        if strength >= 90:
            # If there's a raise, re-raise
            if to_call > self.big_blind_amount:
                raise_amount = 3 * round_state.current_bet
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)
            # Otherwise, open with a raise
            else:
                raise_amount = 3 * self.big_blind_amount
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)

        # Strong hands (TT, AQs, AJs, KQs, AKo)
        elif strength >= 78:
            if to_call > self.big_blind_amount * 4: # Fold to very large 3-bets/4-bets
                return PokerAction.FOLD, 0
            if to_call > self.big_blind_amount: # Call a standard raise
                return self._make_call_decision(to_call, remaining_chips)
            else: # Open raise
                raise_amount = 2.5 * self.big_blind_amount
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)
        
        # Good playable hands
        elif strength >= 50:
            if to_call > 0:
                # Call only if the bet is small relative to stack
                if to_call < remaining_chips * 0.05:
                    return self._make_call_decision(to_call, remaining_chips)
                else: # Fold to larger bets
                     return PokerAction.FOLD, 0
            else: # Limp or check
                return PokerAction.CHECK, 0

        # Weak/Speculative hands
        else:
            # Check for free if possible (e.g., from BB)
            if to_call == 0:
                return PokerAction.CHECK, 0
            # Call a single blind, but fold to any raise
            if to_call <= self.big_blind_amount and round_state.current_bet == self.big_blind_amount:
                return self._make_call_decision(to_call, remaining_chips)
            # Otherwise, fold
            return PokerAction.FOLD, 0

    def _get_postflop_action(self, round_state: RoundStateClient, remaining_chips: int, to_call: int, active_players: int):
        hand_value = self._evaluate_hand_strength(self.hand, round_state.community_cards)
        hand_rank = hand_value[0]

        # Strong made hands (Two Pair or better)
        if hand_rank >= 2:
            bet_fraction = 0.75 if hand_rank >= 3 else 0.5 # Bet larger with stronger hands
            if to_call == 0: # We can bet
                raise_amount = round_state.pot * bet_fraction
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)
            else: # Facing a bet, we should raise
                raise_amount = round_state.pot + 2 * to_call
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)

        # Decent made hands (One Pair)
        elif hand_rank == 1:
            if to_call == 0: # Bet for value/protection if checked to
                raise_amount = round_state.pot * 0.4
                return self._make_raise_decision(raise_amount, remaining_chips, round_state, to_call)
            else: # Facing a bet, play cautiously
                pot_odds = to_call / (round_state.pot + to_call + 1e-6)
                if pot_odds < 0.33: # Call if getting good odds
                    return self._make_call_decision(to_call, remaining_chips)
                else:
                    return PokerAction.FOLD, 0
        
        # Weak hands / Draws (High Card)
        else:
            # Check/fold strategy
            if to_call == 0:
                return PokerAction.CHECK, 0
            else:
                # Simple bot folds if it missed the flop
                return PokerAction.FOLD, 0
    
    def _make_call_decision(self, to_call, remaining_chips):
        if to_call >= remaining_chips:
            return PokerAction.ALL_IN, 0
        return PokerAction.CALL, 0

    def _make_raise_decision(self, raise_amount, remaining_chips, round_state, to_call):
        # All-in if raise is more than our stack
        if raise_amount >= remaining_chips - to_call:
            return PokerAction.ALL_IN, 0
        
        # Cap raise amount at our max possible raise
        raise_amount = min(raise_amount, round_state.max_raise)

        # If we can't make the minimum raise, just call or go-all in if call is all-in
        if raise_amount < round_state.min_raise:
            if to_call > 0:
                return self._make_call_decision(to_call, remaining_chips)
            else: # Cannot min-raise and no one bet, so just check
                return PokerAction.CHECK, 0
        
        return PokerAction.RAISE, int(raise_amount)

    def _get_preflop_strength(self) -> int:
        """ Calculates a score for the starting hand. """
        card1, card2 = self._parse_card(self.hand[0]), self._parse_card(self.hand[1])
        rank1, suit1 = card1
        rank2, suit2 = card2

        val_map = {14: 'A', 13: 'K', 12: 'Q', 11: 'J', 10: 'T', 9: '9', 8: '8', 7: '7', 6: '6', 5: '5', 4: '4', 3: '3', 2: '2'}
        
        r1_str, r2_str = val_map[max(rank1, rank2)], val_map[min(rank1, rank2)]
        
        if r1_str == r2_str:
            hand_str = r1_str + r2_str
        else:
            hand_str = r1_str + r2_str + ('s' if suit1 == suit2 else 'o')

        strength_map = {
            'AA': 100, 'KK': 98, 'QQ': 95, 'AKs': 93, 'JJ': 90,
            'AKo': 88, 'TT': 85, 'AQs': 82, 'AJs': 80, 'KQs': 78,
            '99': 75, 'AQo': 73, 'ATs': 70, 'KJs': 68, 'QJs': 66, 'JTs': 64,
            '88': 62, 'AJo': 60, 'KTs': 58, 'ATo': 56, 'KQo': 54, 'QTs': 53,
            'T9s': 50, '98s': 48, '87s': 46, '76s': 44, '65s': 42, '77': 40
        }
        return strength_map.get(hand_str, 0)
    
    def _parse_card(self, card_str: str) -> Tuple[int, str]:
        """ Parses a card string like 'Ah' into (rank, suit). """
        rank_str = card_str[:-1]
        suit = card_str[-1]
        ranks = {'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}
        rank = ranks.get(rank_str) or int(rank_str)
        return rank, suit

    def _evaluate_hand_strength(self, hole_cards: List[str], community_cards: List[str]) -> tuple:
        """
        Evaluates the best 5-card hand from 7 cards (2 hole + 5 community).
        Returns a tuple representing hand rank for comparison, e.g., (8, 14) for Royal Flush.
        """
        all_cards_str = hole_cards + community_cards
        all_cards = [self._parse_card(c) for c in all_cards_str]
        
        best_hand_value = (0,)

        for hand_5 in itertools.combinations(all_cards, 5):
            current_hand_value = self._get_5_card_value(list(hand_5))
            if current_hand_value > best_hand_value:
                best_hand_value = current_hand_value
        
        return best_hand_value

    def _get_5_card_value(self, hand: List[Tuple[int, str]]) -> tuple:
        """ Calculates the value of a 5-card hand. """
        ranks = sorted([card[0] for card in hand], reverse=True)
        suits = [card[1] for card in hand]
        
        is_flush = len(set(suits)) == 1
        # Check for A-5 low straight
        is_straight = (max(ranks) - min(ranks) == 4 and len(set(ranks)) == 5) or (ranks == [14, 5, 4, 3, 2])
        
        rank_counts = Counter(ranks)
        counts = sorted(rank_counts.values(), reverse=True)
        rank_order = sorted(rank_counts, key=lambda r: (rank_counts[r], r), reverse=True)

        if is_straight and is_flush:
            high_card = ranks[1] if ranks == [14, 5, 4, 3, 2] else ranks[0]
            return (8, high_card)  # Straight Flush (Royal Flush is just a type of SF)
        
        if counts[0] == 4:
            return (7, rank_order[0], rank_order[1])  # Four of a Kind
        
        if counts == [3, 2]:
            return (6, rank_order[0], rank_order[1])  # Full House
        
        if is_flush:
            return (5, tuple(ranks))
        
        if is_straight:
            high_card = ranks[1] if ranks == [14, 5, 4, 3, 2] else ranks[0]
            return (4, high_card)
        
        if counts[0] == 3:
            return (3, rank_order[0], tuple(rank_order[1:]))  # Three of a Kind
        
        if counts == [2, 2, 1]:
            return (2, rank_order[0], rank_order[1], rank_order[2])  # Two Pair
        
        if counts[0] == 2:
            return (1, rank_order[0], tuple(rank_order[1:]))  # One Pair
            
        return (0, tuple(ranks))  # High Card