from typing import List, Tuple, Dict
from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
              'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}

def parse_card(card: str):
    """Parses a card like 'Ah' into (rank_value, suit_char)."""
    if not card or len(card) < 2:
        return 0, ''
    rank_char = card[0].upper()
    suit_char = card[1].lower()
    return RANK_ORDER.get(rank_char, 0), suit_char

def get_ranks_suits(cards: List[str]):
    ranks = []
    suits = []
    for c in cards:
        r, s = parse_card(c)
        if r > 0 and s:
            ranks.append(r)
            suits.append(s)
    return ranks, suits

def preflop_category(hole: List[str]) -> str:
    """Return a simple category for preflop strength."""
    if len(hole) < 2:
        return 'trash'
    r1, s1 = parse_card(hole[0])
    r2, s2 = parse_card(hole[1])
    if r1 < r2:
        r1, r2 = r2, r1
        s1, s2 = s2, s1
    suited = (s1 == s2)
    pair = (r1 == r2)
    gap = r1 - r2

    # Premium hands
    if pair and r1 >= RANK_ORDER['T']:
        return 'premium'
    if (r1 == RANK_ORDER['A'] and r2 == RANK_ORDER['K']) and (suited or not suited):
        return 'premium'
    if suited and ((r1 == RANK_ORDER['A'] and r2 >= RANK_ORDER['J']) or (r1 == RANK_ORDER['K'] and r2 == RANK_ORDER['Q'])):
        return 'premium'

    # Strong hands
    if pair and r1 >= RANK_ORDER['7']:
        return 'strong'
    if (r1 == RANK_ORDER['A'] and r2 >= RANK_ORDER['Q']):
        return 'strong'
    if suited and ((r1 == RANK_ORDER['Q'] and r2 >= RANK_ORDER['J']) or (r1 == RANK_ORDER['J'] and r2 == RANK_ORDER['T'])):
        return 'strong'
    if not suited and (r1 >= RANK_ORDER['K'] and r2 >= RANK_ORDER['Q']):
        return 'strong'

    # Speculative suited connectors/gappers
    if suited and gap <= 2 and r1 >= RANK_ORDER['8']:
        return 'speculative'

    return 'trash'

def evaluate_postflop(hole: List[str], community: List[str]) -> Dict[str, bool]:
    """Basic postflop evaluation: returns flags about made hands and draws."""
    res = {
        'quads': False,
        'full_house': False,
        'flush': False,
        'straight': False,
        'trips': False,
        'two_pair': False,
        'overpair': False,
        'top_pair': False,
        'pair': False,
        'flush_draw': False
    }
    if len(hole) < 2:
        return res

    all_cards = hole + community
    ranks, suits = get_ranks_suits(all_cards)
    hole_ranks, hole_suits = get_ranks_suits(hole)
    comm_ranks, comm_suits = get_ranks_suits(community)

    rank_counts: Dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1
    suit_counts: Dict[str, int] = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1

    # Made hands by rank counts involving at least one hole card where appropriate
    # Trips/Quads/Full house detection
    for r, cnt in rank_counts.items():
        if cnt >= 4 and (hole_ranks.count(r) >= 1):
            res['quads'] = True
        if cnt == 3 and (hole_ranks.count(r) >= 1):
            res['trips'] = True
    # Full house: have trips and a pair (could be on board). Ensure trips uses at least one hole if possible
    has_trips_any = any(c == 3 for c in rank_counts.values())
    has_pair_any = any(c >= 2 for c in rank_counts.values())
    if has_trips_any and has_pair_any:
        # Roughly consider it as full house if our hole contributes to trips or pair
        hole_contrib = False
        for r, c in rank_counts.items():
            if c >= 3 and (r in hole_ranks):
                hole_contrib = True
                break
        if not hole_contrib:
            # maybe pair part is ours
            for r, c in rank_counts.items():
                if c >= 2 and (r in hole_ranks):
                    hole_contrib = True
                    break
        if hole_contrib:
            res['full_house'] = True

    # Two pair or pair detection
    # Pair if at least one of our hole ranks appears among community or we have pocket pair
    pocket_pair = (len(hole_ranks) == 2 and hole_ranks[0] == hole_ranks[1])
    res['pair'] = pocket_pair or any(r in comm_ranks for r in hole_ranks)
    # Two pair if both hole cards pair different board ranks, or one pairs and the board is paired (approx)
    first_pairs = (hole_ranks[0] in comm_ranks)
    second_pairs = (hole_ranks[1] in comm_ranks)
    board_paired = False
    comm_rank_counts: Dict[int, int] = {}
    for r in comm_ranks:
        comm_rank_counts[r] = comm_rank_counts.get(r, 0) + 1
    board_paired = any(c >= 2 for c in comm_rank_counts.values())
    if (first_pairs and second_pairs and hole_ranks[0] != hole_ranks[1]) or (pocket_pair and board_paired):
        res['two_pair'] = True

    # Overpair and top pair
    if pocket_pair and len(comm_ranks) > 0:
        if max(comm_ranks) < hole_ranks[0]:
            res['overpair'] = True
    if len(comm_ranks) > 0:
        if (max(comm_ranks) in hole_ranks):
            res['top_pair'] = True

    # Flush made or draw
    for s, cnt in suit_counts.items():
        if cnt >= 5 and s in hole_suits:
            res['flush'] = True
        if cnt == 4 and s in hole_suits:
            # Consider 4 to a flush including at least one of our hole cards
            res['flush_draw'] = True

    # Straight detection (approx): check any 5-consecutive ranks present among all cards,
    # and ensure at least one hole card rank is part of the straight ranks.
    unique_ranks = sorted(set(ranks))
    # Handle wheel straight by mapping Ace as 1 also
    unique_with_wheel = set(unique_ranks)
    if RANK_ORDER['A'] in unique_with_wheel:
        unique_with_wheel.add(1)
    ordered = sorted(unique_with_wheel)
    def has_straight_and_uses_hole(ordered_ranks, hole_rs):
        n = len(ordered_ranks)
        for i in range(n - 4):
            window = ordered_ranks[i:i+5]
            # map back 1 to 14 for matching with hole cards
            window_set = set([14 if x == 1 else x for x in window])
            if len(window) == 5 and window[-1] - window[0] == 4:
                # uses at least one hole rank
                if any(hr in window_set for hr in hole_rs):
                    return True
        return False
    if has_straight_and_uses_hole(ordered, hole_ranks):
        res['straight'] = True

    return res

class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.players_count = 0
        self.round_num = 0
        self.position = 'unknown'  # 'sb', 'bb', or 'unknown'
        self.stats = {
            'hands_played': 0,
            'hands_won': 0,
            'total_delta': 0
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        try:
            self.starting_chips = starting_chips
            self.hole_cards = list(player_hands) if player_hands else []
            self.blind_amount = int(blind_amount) if blind_amount is not None else 0
            self.big_blind_player_id = big_blind_player_id
            self.small_blind_player_id = small_blind_player_id
            self.all_players = all_players or []
            self.players_count = len(self.all_players)
            if self.id is not None:
                if self.id == self.small_blind_player_id:
                    self.position = 'sb'
                elif self.id == self.big_blind_player_id:
                    self.position = 'bb'
                else:
                    self.position = 'unknown'
        except Exception:
            # Failsafe: keep defaults to prevent crashes
            pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        try:
            self.round_num = round_state.round_num
        except Exception:
            pass

    def _safe_needed_to_call(self, round_state: RoundStateClient) -> int:
        try:
            my_bet = round_state.player_bets.get(str(self.id), 0) if round_state.player_bets else 0
            return max(0, int(round_state.current_bet) - int(my_bet))
        except Exception:
            return 0

    def _can_check(self, round_state: RoundStateClient) -> bool:
        return self._safe_needed_to_call(round_state) == 0

    def _pot_odds(self, round_state: RoundStateClient, needed: int) -> float:
        try:
            pot = int(round_state.pot)
        except Exception:
            pot = 0
        denom = pot + needed + 1e-9
        return float(needed) / float(denom)

    def _short_stack(self, remaining_chips: int) -> bool:
        # Consider short stacked if <= 25 big blinds
        bb = max(1, self.blind_amount)
        return remaining_chips <= 25 * bb

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            needed = self._safe_needed_to_call(round_state)
            can_check = self._can_check(round_state)
            pot_odds = self._pot_odds(round_state, needed)
            stage = (round_state.round or '').lower()

            # Never submit invalid raise; prefer safe actions only
            # Strategy: Tight-aggressive without explicit raises (use all-in for very strong cases)

            # If nothing to call, default to check
            if can_check:
                # Consider betting? To avoid invalid raise amounts and complexity,
                # we keep it simple and check when allowed.
                return PokerAction.CHECK, 0

            # There is a bet to us
            if stage == 'preflop':
                cat = preflop_category(self.hole_cards)
                bb = max(1, self.blind_amount)
                # Opponent sizing seems large in logs (~10x BB). Be tight vs big opens.
                if cat == 'premium':
                    # If short stacked and premium, consider jam; otherwise call within reason
                    if self._short_stack(remaining_chips) and needed <= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    # Call if the ask is not ridiculous relative to stack
                    if needed <= min(20 * bb, remaining_chips // 5):  # up to 20BB or 20% stack
                        return PokerAction.CALL, 0
                    # If ask is very high but we are premium, still call if pot odds are great
                    if pot_odds <= 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                elif cat == 'strong':
                    if needed <= 10 * bb and pot_odds <= 0.33:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                elif cat == 'speculative':
                    # Speculative hands only continue with very good pot odds and small ask
                    if needed <= 5 * bb and pot_odds <= 0.25:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0
                else:
                    return PokerAction.FOLD, 0

            else:
                # Postflop (flop/turn/river)
                eval_flags = evaluate_postflop(self.hole_cards, round_state.community_cards or [])
                strong_made = eval_flags['quads'] or eval_flags['full_house'] or eval_flags['flush'] or eval_flags['straight'] or eval_flags['trips'] or eval_flags['two_pair']
                medium_made = eval_flags['overpair'] or eval_flags['top_pair']
                draw = eval_flags['flush_draw']  # Keeping it simple; not evaluating straight draws here

                # Strong made hands: prefer to continue; sometimes jam if short-stacked
                if strong_made:
                    if self._short_stack(remaining_chips) and needed <= remaining_chips:
                        return PokerAction.ALL_IN, 0
                    # Call most bets; fold only to absurdly large overbets relative to stack
                    if pot_odds <= 0.6 or needed <= remaining_chips // 3:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

                # Medium made hands: call reasonable bets based on pot odds
                if medium_made:
                    # Call up to about 1/2 pot odds
                    if pot_odds <= 0.4:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

                # Draws: call if pot odds are favorable
                if draw:
                    # Roughly need <= 40% pot odds for flush draw across two streets (approx, conservative)
                    if pot_odds <= 0.4:
                        return PokerAction.CALL, 0
                    return PokerAction.FOLD, 0

                # Otherwise weak hand -> fold to bets
                return PokerAction.FOLD, 0

        except Exception:
            # Failsafe to avoid auto-fold due to exception: just fold
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        try:
            self.stats['hands_played'] += 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        try:
            # Track simple stats
            self.stats['total_delta'] += float(player_score or 0.0)
            # Reset per-hand states
            self.hole_cards = []
            self.position = 'unknown'
        except Exception:
            pass