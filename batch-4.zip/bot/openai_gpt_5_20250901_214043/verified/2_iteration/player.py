from typing import List, Tuple, Dict, Any
from collections import Counter
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_TO_VAL = {
    '2': 2, '3': 3, '4': 4, '5': 5,
    '6': 6, '7': 7, '8': 8, '9': 9,
    'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14
}


def safe_div(a: float, b: float, eps: float = 1e-9) -> float:
    return a / (b + eps)


def parse_card(card: str) -> Tuple[int, str]:
    # card example: 'Ah', 'Td', '9s'
    # Defensive parsing
    if not isinstance(card, str) or len(card) < 2:
        return 0, 'x'
    r = card[0].upper()
    s = card[1].lower() if len(card) > 1 else 'x'
    return RANK_TO_VAL.get(r, 0), s


def hand_to_vals(h: List[str]) -> Tuple[List[int], List[str]]:
    ranks = []
    suits = []
    for c in h:
        rv, sv = parse_card(c)
        if rv > 0:
            ranks.append(rv)
            suits.append(sv)
    return ranks, suits


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips = 0
        self.blind_amount = 0  # assumed big blind
        self.big_blind_player_id = None
        self.small_blind_player_id = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []  # two cards for current hand
        self.hand_count = 0
        self.rng = random.Random(1337)
        self.current_round_name = ''
        self.round_num = 0

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int,
                 big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Treat on_start as "hand start" (engine provides our hole cards here)
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount if isinstance(blind_amount, int) and blind_amount > 0 else max(self.blind_amount, 1)
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players if isinstance(all_players, list) else self.all_players
        self.hole_cards = player_hands[:2] if isinstance(player_hands, list) else []
        self.hand_count += 1
        # Reset round tracking
        self.current_round_name = 'Preflop'
        self.round_num = 0

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Update current round name and round num
        try:
            self.current_round_name = round_state.round
            self.round_num = round_state.round_num
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        try:
            # Basic state
            my_id_str = str(self.id) if self.id is not None else None
            my_bet = 0
            if my_id_str and isinstance(round_state.player_bets, dict):
                my_bet = int(round_state.player_bets.get(my_id_str, 0) or 0)
            current_bet = int(round_state.current_bet or 0)
            pot = int(round_state.pot or 0)
            call_cost = max(current_bet - my_bet, 0)
            min_raise = int(round_state.min_raise if round_state.min_raise is not None else 0)
            max_raise = int(round_state.max_raise if round_state.max_raise is not None else 0)
            community_cards = round_state.community_cards or []
            round_name = (round_state.round or 'Preflop').lower()

            # Number of active (not folded) players
            num_players_in_hand = self._estimate_active_players(round_state)

            # Compute preflop score
            preflop_score = self._preflop_strength(self.hole_cards, num_players_in_hand)

            # Compute postflop score
            postflop = self._postflop_features(self.hole_cards, community_cards)
            postflop_score = postflop['score']

            # Choose thresholds based on heads-up vs multiway
            heads_up = (num_players_in_hand <= 2)
            if heads_up:
                open_threshold = 0.45
                call_slack = 0.03
                three_bet_threshold = 0.68
                bluff_freq = 0.15
            else:
                open_threshold = 0.58
                call_slack = 0.06
                three_bet_threshold = 0.73
                bluff_freq = 0.08

            # Compute pot odds
            pot_odds = safe_div(call_cost, pot + call_cost)

            # Safe fallback decisions
            if call_cost <= 0:
                # Options: CHECK or RAISE (bet)
                if round_name == 'preflop':
                    # Open or over-limp spot (BB may check)
                    if preflop_score >= open_threshold:
                        # Raise sizing: 2-3x min_raise
                        mult = 2 if preflop_score < (three_bet_threshold + 0.07) else 3
                        return self._attempt_raise(min_raise, max_raise, mult)
                    else:
                        return PokerAction.CHECK, 0
                else:
                    # Postflop: c-bet logic
                    strong_val = postflop_score >= 0.85
                    good_val = postflop_score >= 0.62
                    drawy = postflop['flush_draw'] or postflop['oesd']
                    ace_high_bluff = (not good_val and not drawy and postflop['ace_high'] and heads_up and postflop['board_dry'])

                    if strong_val:
                        # Value bet bigger
                        mult = 3
                        return self._attempt_raise(min_raise, max_raise, mult)
                    elif good_val or drawy or ace_high_bluff:
                        # C-bet small to medium
                        mult = 2
                        return self._attempt_raise(min_raise, max_raise, mult)
                    else:
                        return PokerAction.CHECK, 0
            else:
                # Facing a bet/raise
                # Evaluate strength to continue
                if round_name == 'preflop':
                    equity = preflop_score
                    # 3-bet or call decisions
                    if equity >= (three_bet_threshold + (0.02 if not heads_up else 0.0)):
                        # Strong: raise if possible, else all-in if very strong
                        if min_raise > 0 and max_raise >= min_raise:
                            mult = 2 if equity < 0.80 else 3
                            act = self._attempt_raise(min_raise, max_raise, mult, allow_allin=True, strong=True)
                            if act[0] == PokerAction.RAISE or act[0] == PokerAction.ALL_IN:
                                return act
                        # If can't raise, consider call or all-in if short
                        if call_cost >= remaining_chips:
                            return PokerAction.ALL_IN, 0
                        else:
                            return PokerAction.CALL, 0
                    else:
                        # Decide to call based on pot odds
                        if equity >= (pot_odds + call_slack):
                            if call_cost >= remaining_chips:
                                # If we like the hand enough to continue but can't cover, jam or fold based on strength
                                if equity >= 0.62:
                                    return PokerAction.ALL_IN, 0
                                else:
                                    return PokerAction.FOLD, 0
                            return PokerAction.CALL, 0
                        else:
                            # Occasional bluff 3-bet with suited connectors or Ax suited if heads-up and cheap
                            if heads_up and equity >= (open_threshold - 0.05) and self.rng.random() < bluff_freq:
                                if min_raise > 0 and max_raise >= min_raise and (call_cost < max(self.blind_amount * 6, 3 * min_raise)):
                                    return self._attempt_raise(min_raise, max_raise, 2)
                            return PokerAction.FOLD, 0
                else:
                    # Postflop
                    equity = postflop_score
                    strong_value = equity >= 0.85
                    good_made = equity >= 0.62
                    drawy = postflop['flush_draw'] or postflop['oesd']
                    combo_draw = (postflop['flush_draw'] and postflop['oesd'])

                    # Semi-bluff or value raise
                    if strong_value or (combo_draw and heads_up) or (good_made and self.rng.random() < 0.2 and heads_up):
                        if min_raise > 0 and max_raise >= min_raise:
                            mult = 3 if strong_value else 2
                            return self._attempt_raise(min_raise, max_raise, mult, allow_allin=True, strong=strong_value)
                        else:
                            # Can't raise, decide call vs all-in
                            if call_cost >= remaining_chips:
                                if strong_value or combo_draw:
                                    return PokerAction.ALL_IN, 0
                                else:
                                    # If we can't cover and are marginal, fold
                                    return PokerAction.FOLD, 0
                            else:
                                return PokerAction.CALL, 0

                    # Call with decent equity vs pot odds
                    margin = 0.02 if drawy else 0.04
                    if equity >= (pot_odds + margin):
                        if call_cost >= remaining_chips:
                            # Forced all-in call decision
                            if equity >= 0.58:
                                return PokerAction.ALL_IN, 0
                            else:
                                return PokerAction.FOLD, 0
                        return PokerAction.CALL, 0

                    # Occasional float/bluff raise in heads-up on dry boards with Ace-high
                    if heads_up and postflop['board_dry'] and postflop['ace_high'] and self.rng.random() < 0.08 and min_raise > 0 and max_raise >= min_raise:
                        return self._attempt_raise(min_raise, max_raise, 2)

                    # Otherwise fold
                    return PokerAction.FOLD, 0

        except Exception:
            # Any unexpected issue: choose a safe action to avoid auto-fold by invalid action
            # If we can check, do so; else fold if it's expensive; else call cheap bets
            try:
                my_id_str = str(self.id) if self.id is not None else None
                my_bet = 0
                if my_id_str:
                    my_bet = int(round_state.player_bets.get(my_id_str, 0) or 0)
                call_cost = max(int(round_state.current_bet or 0) - my_bet, 0)
                if call_cost <= 0:
                    return PokerAction.CHECK, 0
                if call_cost <= max(2 * (self.blind_amount or 10), 20):
                    return PokerAction.CALL, 0
                return PokerAction.FOLD, 0
            except Exception:
                return PokerAction.CHECK, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # No-op; could add learning or logging hooks here
        pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No-op; placeholder for end-game analysis if needed
        pass

    # ---------------- Helper methods ----------------

    def _estimate_active_players(self, round_state: RoundStateClient) -> int:
        try:
            actions: Dict[str, str] = round_state.player_actions or {}
            # Consider those not marked 'Fold'
            not_fold = 0
            # If actions empty, fallback to all_players length
            if not actions:
                if round_state.current_player:
                    return max(len(round_state.current_player), 2)
                return max(len(self.all_players), 2) if self.all_players else 2
            for _, act in actions.items():
                if str(act).lower() != 'fold':
                    not_fold += 1
            return max(not_fold, 2)
        except Exception:
            return max(len(self.all_players), 2) if self.all_players else 2

    def _attempt_raise(self, min_raise: int, max_raise: int, multiple: int, allow_allin: bool = True, strong: bool = False) -> Tuple[PokerAction, int]:
        # Ensure valid raise amount
        try:
            if min_raise <= 0 and max_raise > 0:
                # Fallback to small raise if protocol allows; else all-in if strong
                if allow_allin and strong:
                    return PokerAction.ALL_IN, 0
                # If cannot raise properly, just CHECK or CALL should be made by caller before
                # Here, return a conservative ALL_IN only if strong else CHECK
                if allow_allin and (strong or self.rng.random() < 0.05):
                    return PokerAction.ALL_IN, 0
                return PokerAction.CHECK, 0
            if max_raise < min_raise:
                # Can't raise, maybe all-in is allowed
                if allow_allin and strong:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CHECK, 0
            amount = min(max(min_raise * max(1, multiple), min_raise), max_raise)
            if amount < min_raise:
                if allow_allin and strong:
                    return PokerAction.ALL_IN, 0
                return PokerAction.CHECK, 0
            return PokerAction.RAISE, int(amount)
        except Exception:
            # Fallback safe
            return PokerAction.CHECK, 0

    def _preflop_strength(self, hole_cards: List[str], num_players_in_hand: int) -> float:
        # Rough heuristic score between 0.2 and 0.95
        if not hole_cards or len(hole_cards) < 2:
            return 0.3
        ranks, suits = hand_to_vals(hole_cards)
        if len(ranks) < 2:
            return 0.3
        r1, r2 = sorted(ranks, reverse=True)
        s1, s2 = suits[0], suits[1]
        suited = (s1 == s2)
        pair = (r1 == r2)
        gap = abs(r1 - r2) - 1  # 0 for connectors

        # Base score from highest card
        base = 0.30 + (r1 - 6) * 0.025  # 6->0.30, A(14)->0.50
        base = max(0.25, min(0.55, base))

        score = base

        if pair:
            # Pairs: scale strongly with rank
            score = 0.55 + (r1 - 2) * 0.03  # 22 ~ 0.61, AA ~ 0.97
        else:
            # Non-pair adjustments
            if suited:
                score += 0.03
            # Connectivity
            if gap <= 0:
                score += 0.02
            elif gap == 1:
                score += 0.01
            elif gap >= 3:
                score -= 0.02

            # Ace-x bonuses
            if r1 == 14:
                if r2 >= 10:
                    score += 0.05
                elif suited:
                    score += 0.04
                else:
                    score += 0.02

            # High card bonus
            if r1 >= 10:
                score += (r1 - 10) * 0.01  # T..A -> +0..+0.04

            # Low-card penalty
            if r1 <= 9 and r2 <= 7:
                score -= 0.04

        # Multiway tightening
        if num_players_in_hand >= 4:
            score -= 0.03
        if num_players_in_hand >= 6:
            score -= 0.02

        # Clamp
        return max(0.20, min(0.95, score))

    def _postflop_features(self, hole_cards: List[str], board: List[str]) -> Dict[str, Any]:
        # Evaluate simple hand category and draw strength -> score 0..1
        result = {
            'score': 0.3,
            'flush_draw': False,
            'oesd': False,
            'gutshot': False,
            'ace_high': False,
            'board_dry': True
        }
        if not hole_cards or len(hole_cards) < 2:
            return result

        h_ranks, h_suits = hand_to_vals(hole_cards)
        b_ranks, b_suits = hand_to_vals(board)
        all_ranks = h_ranks + b_ranks
        all_suits = h_suits + b_suits

        # Ace high flag
        result['ace_high'] = (max(h_ranks) == 14 and len(b_ranks) > 0)

        # Board dryness (simple heuristic)
        board_suit_counter = Counter(b_suits)
        max_suit_board = max(board_suit_counter.values()) if board_suit_counter else 0
        uniq_board_ranks = sorted(set(b_ranks))
        connected_run = 0
        last = None
        for r in uniq_board_ranks:
            if last is None or r == last + 1:
                connected_run += 1
            else:
                connected_run = 1
            last = r
        board_dry = (max_suit_board <= 2 and connected_run <= 2)
        result['board_dry'] = board_dry

        # Combined counters
        rank_counter = Counter(all_ranks)
        suit_counter = Counter(all_suits)

        max_same = max(rank_counter.values()) if rank_counter else 0
        pair_count = sum(1 for v in rank_counter.values() if v == 2)

        # Flush and flush draw
        has_flush = any(v >= 5 for v in suit_counter.values())
        # Flush draw: exactly 4 of a suit and at least one of our hole cards contributes
        flush_draw = False
        for s, v in suit_counter.items():
            if v == 4 and s in h_suits:
                # Ensure at least one of hole cards is of suit s
                if h_suits.count(s) >= 1:
                    flush_draw = True
        result['flush_draw'] = flush_draw

        # Straight detection
        def has_straight(vals: List[int]) -> bool:
            vset = set(vals)
            if 14 in vset:
                vset.add(1)  # Ace low
            seq = sorted(vset)
            run = 1
            for i in range(1, len(seq)):
                if seq[i] == seq[i-1] + 1:
                    run += 1
                    if run >= 5:
                        return True
                elif seq[i] != seq[i-1]:
                    run = 1
            return False

        straight = has_straight(all_ranks)

        # Straight draw detection (unique ranks)
        def straight_draw_flags(hr: List[int], br: List[int]) -> Tuple[bool, bool]:
            # OESD if any 4-card open-ended sequence among combined ranks and at least one hole rank within sequence
            # Gutshot if any 4-card broken sequence (inside) with at least one hole rank within the 4
            all_set = set(hr + br)
            if 14 in all_set:
                all_set = all_set | {1}
            uniq = sorted(all_set)
            oesd = False
            gut = False
            # Check 5-length windows from 1..14 (Ace low 1..5)
            for low in range(1, 11):
                window = {low, low+1, low+2, low+3, low+4}
                present = window & set(uniq)
                if len(present) == 4:
                    # Determine which rank is missing
                    missing = list(window - present)
                    if len(missing) == 1:
                        miss = missing[0]
                        # open-ended if missing is one of the ends
                        if miss == low or miss == low+4:
                            # check hole participation
                            if any((r in window) or (r == 14 and 1 in window) for r in hr):
                                oesd = True
                        else:
                            if any((r in window) or (r == 14 and 1 in window) for r in hr):
                                gut = True
                if oesd and gut:
                    break
            return oesd, gut

        oesd, gut = straight_draw_flags(h_ranks, b_ranks)
        result['oesd'] = oesd
        result['gutshot'] = gut

        # Determine made hand categories
        has_quads = (max_same >= 4)
        has_trips = (max_same == 3)
        has_full = False
        if has_trips:
            # full house if trips + any pair beyond those trips
            counts = sorted(rank_counter.values(), reverse=True)
            if len(counts) >= 2 and counts[1] >= 2:
                has_full = True
        has_two_pair = (pair_count >= 2)
        has_one_pair = (pair_count == 1)

        # Overpair, top pair, second pair detection
        overpair = False
        top_pair = False
        second_pair = False
        if len(b_ranks) >= 1:
            top_board = max(b_ranks)
            second_board = sorted(set(b_ranks))[-2] if len(set(b_ranks)) >= 2 else None
            # pocket pair overpair if we hold pair and it's greater than top board rank
            if h_ranks[0] == h_ranks[1] and h_ranks[0] > top_board:
                overpair = True
            # top pair if one of our hole ranks matches top board rank
            if top_board in h_ranks:
                top_pair = True
            # second pair if match second board rank
            if second_board is not None and second_board in h_ranks and not top_pair:
                second_pair = True

        # Assign a score
        # Hierarchy by strength
        if has_quads:
            score = 0.99
        elif has_full:
            score = 0.95
        elif has_flush:
            score = 0.90
        elif straight:
            score = 0.85
        elif has_trips:
            score = 0.75
        elif has_two_pair:
            score = 0.70
        elif overpair:
            score = 0.68
        elif top_pair:
            # Top pair kicker consideration
            kicker = max([r for r in h_ranks if r not in set(b_ranks)] + [min(h_ranks)])
            score = 0.66 if kicker >= 12 else 0.62
        elif second_pair:
            score = 0.55
        elif has_one_pair:
            score = 0.50
        else:
            # No made hand; draws adjustments
            if oesd and result['flush_draw']:
                score = 0.64
            elif result['flush_draw']:
                score = 0.58
            elif oesd:
                score = 0.56
            elif gut:
                score = 0.52
            else:
                score = 0.30 if result['ace_high'] else 0.22

        # Board scary reductions if we don't match
        # If board is very coordinated (3 to flush or 3-straight) and we don't have decent hand, reduce
        max_suit = max(suit_counter.values()) if suit_counter else 0
        if max_suit >= 4 and score < 0.70:
            score -= 0.03
        # Four to straight on board
        if self._four_to_straight_on_board(b_ranks) and score < 0.70:
            score -= 0.03

        score = max(0.20, min(0.98, score))
        result['score'] = score
        return result

    def _four_to_straight_on_board(self, b_ranks: List[int]) -> bool:
        if len(b_ranks) < 4:
            return False
        vset = set(b_ranks)
        if 14 in vset:
            vset = vset | {1}
        uniq = sorted(vset)
        # Check 5-length windows for 4 present on board alone
        for low in range(1, 11):
            window = {low, low+1, low+2, low+3, low+4}
            if len(window & set(uniq)) >= 4:
                return True
        return False