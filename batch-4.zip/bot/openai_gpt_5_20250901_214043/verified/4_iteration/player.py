from typing import List, Tuple, Dict, Any, Optional
import random
import math

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient

RANK_ORDER = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9,
              'T': 10, 'J': 11, 'Q': 12, 'K': 13, 'A': 14}


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.big_blind: int = 0
        self.small_blind: int = 0
        self.players: List[int] = []
        self.hole_cards: List[str] = []  # e.g., ['Ah', 'Kd']
        self.round_number: int = 0
        self.random = random.Random(42)
        self.table_stats: Dict[str, Any] = {
            'hands_played': 0,
            'aggression': 0,
            'last_result': 0.0,
        }

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Called when a hand/game starts (engine-specific). Store basic info and current hole cards if provided.
        try:
            self.starting_chips = starting_chips
            self.players = all_players or []
            # Assume blind_amount is the big blind if provided; fallback compute SB.
            self.big_blind = max(1, int(blind_amount)) if blind_amount else max(1, self.big_blind)
            self.small_blind = max(1, self.big_blind // 2)
            # Player hole cards for this hand
            if player_hands and len(player_hands) >= 2:
                self.hole_cards = player_hands[:2]
            else:
                # Keep previous if engine does not refresh here
                if not self.hole_cards:
                    self.hole_cards = []
        except Exception:
            # Fallback safe state
            if not self.big_blind:
                self.big_blind = 10
                self.small_blind = 5
            if not isinstance(self.hole_cards, list):
                self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round/hand state if round number changed
        try:
            self.round_number = round_state.round_num
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        # Main decision function. Always return a valid action.
        try:
            # Defensive defaults
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            my_id_str = str(self.id) if self.id is not None else None
            my_bet = 0
            if my_id_str and round_state.player_bets and my_id_str in round_state.player_bets:
                my_bet = int(round_state.player_bets.get(my_id_str, 0) or 0)

            current_bet = int(round_state.current_bet or 0)
            to_call = max(0, current_bet - my_bet)
            min_raise = int(round_state.min_raise or 0)
            max_raise = int(round_state.max_raise or 0)
            pot = int(round_state.pot or 0)
            community = list(round_state.community_cards or [])
            street = (round_state.round or "Preflop").lower()

            num_active_players = max(2, len(round_state.current_player or self.players or []))

            # If we don't know our cards (engine didn't pass), play super-tight
            if not self.hole_cards or len(self.hole_cards) < 2:
                # With unknown hand info, avoid spew: only check/fold; call only if free
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # If extremely cheap (<= small blind) and heads-up, sometimes peel
                    if num_active_players <= 2 and to_call <= max(1, self.small_blind):
                        if remaining_chips > to_call:
                            return PokerAction.CALL, 0
                        else:
                            return PokerAction.ALL_IN, 0
                    return PokerAction.FOLD, 0

            # Compute evaluations
            ranks_hole = [self._rank_value(c) for c in self.hole_cards]
            suits_hole = [self._suit(c) for c in self.hole_cards]

            # Preflop strength and postflop evaluation
            preflop_strength = self._preflop_strength(self.hole_cards, num_active_players)

            made_eval = self._made_hand_eval(self.hole_cards, community)
            draw_eval = self._draw_eval(self.hole_cards, community)

            # Adjust strength by number of opponents (multiway requires stronger hands)
            multiway_adjust = max(0, num_active_players - 2) * 0.03
            # Base postflop strength estimate
            postflop_strength = max(made_eval['strength'], draw_eval['draw_strength'])
            postflop_strength = max(0.0, min(1.0, postflop_strength - multiway_adjust))

            # Street-specific strategy
            if street == 'preflop':
                action, amount = self._decide_preflop_action(
                    to_call, pot, min_raise, max_raise, remaining_chips,
                    preflop_strength, num_active_players
                )
                return action, amount
            else:
                action, amount = self._decide_postflop_action(
                    to_call, pot, min_raise, max_raise, remaining_chips,
                    postflop_strength, made_eval, draw_eval, street, num_active_players
                )
                return action, amount

        except Exception:
            # On any unexpected error, return a safe action
            # Prefer check if possible, otherwise fold to avoid invalid move
            try:
                my_id_str = str(self.id) if self.id is not None else None
                my_bet = 0
                if my_id_str and round_state.player_bets and my_id_str in round_state.player_bets:
                    my_bet = int(round_state.player_bets.get(my_id_str, 0) or 0)
                if int(round_state.current_bet or 0) <= my_bet:
                    return PokerAction.CHECK, 0
            except Exception:
                pass
            return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        # Update simple stats
        try:
            self.table_stats['hands_played'] += 1
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # Track last result
        try:
            self.table_stats['last_result'] = float(player_score)
        except Exception:
            self.table_stats['last_result'] = 0.0

    # =========================
    # Helper Methods
    # =========================

    def _rank_value(self, card: str) -> int:
        if not card or len(card) < 2:
            return 0
        return RANK_ORDER.get(card[0].upper(), 0)

    def _suit(self, card: str) -> str:
        if not card or len(card) < 2:
            return ''
        return card[1].lower()

    def _card_counts(self, cards: List[str]) -> Tuple[Dict[int, int], Dict[str, int]]:
        ranks: Dict[int, int] = {}
        suits: Dict[str, int] = {}
        for c in cards:
            rv = self._rank_value(c)
            sv = self._suit(c)
            if rv:
                ranks[rv] = ranks.get(rv, 0) + 1
            if sv:
                suits[sv] = suits.get(sv, 0) + 1
        return ranks, suits

    def _has_flush(self, cards: List[str]) -> bool:
        _, suits = self._card_counts(cards)
        return max(suits.values()) >= 5 if suits else False

    def _flush_draw(self, cards: List[str]) -> bool:
        _, suits = self._card_counts(cards)
        return max(suits.values()) == 4 if suits else False

    def _has_straight(self, cards: List[str]) -> bool:
        ranks = set(self._rank_value(c) for c in cards if self._rank_value(c) > 0)
        if not ranks:
            return False
        # Ace can be low
        if 14 in ranks:
            ranks.add(1)
        seq = sorted(ranks)
        count = 1
        best = 1
        for i in range(1, len(seq)):
            if seq[i] == seq[i - 1] + 1:
                count += 1
            elif seq[i] == seq[i - 1]:
                continue
            else:
                best = max(best, count)
                count = 1
        best = max(best, count)
        return best >= 5

    def _straight_draws(self, cards: List[str]) -> Tuple[bool, bool]:
        # Returns (OESD, Gutshot) approximations
        ranks = set(self._rank_value(c) for c in cards if self._rank_value(c) > 0)
        if not ranks:
            return False, False
        if 14 in ranks:
            ranks = set(list(ranks) + [1])
        seq = sorted(ranks)
        # OESD: any 4 consecutive ranks present
        oesd = False
        gutshot = False
        # Map for quick membership
        rset = set(seq)
        # Check for 4-consecutive
        for start in range(1, 11):  # windows 1..10
            window = [start, start + 1, start + 2, start + 3, start + 4]
            present = [v for v in window if v in rset]
            if len(present) >= 4:
                # If exactly 4 and they are consecutive, it's OESD; if 4 but not fully consecutive, call gutshot.
                if all((start + i) in rset for i in range(4)) or all((start + i) in rset for i in range(1, 5)):
                    oesd = True
                else:
                    gutshot = True
            if len(present) == 5:
                # already a straight; draw flags irrelevant but mark oesd True
                oesd = True
        return oesd, gutshot and not oesd

    def _made_hand_eval(self, hole: List[str], board: List[str]) -> Dict[str, Any]:
        cards = list(hole) + list(board)
        rank_counts, suit_counts = self._card_counts(cards)
        rank_counts_board, _ = self._card_counts(board)
        ranks_hole = [self._rank_value(c) for c in hole]
        ranks_board_sorted = sorted(rank_counts_board.keys(), reverse=True)

        # Categories
        counts = sorted(rank_counts.values(), reverse=True)  # e.g., [3,2,1,1]
        is_quads = 4 in counts
        is_trips = 3 in counts
        pair_counts = sum(1 for v in rank_counts.values() if v >= 2)
        is_full_house = (3 in counts and pair_counts >= 2) or counts[:2] == [3, 3]
        is_two_pair = pair_counts >= 2 and not is_full_house
        is_one_pair = pair_counts >= 1 and not (is_two_pair or is_trips or is_full_house)

        has_flush = self._has_flush(cards)
        has_straight = self._has_straight(cards)

        # Determine if pair uses our hole cards and strength of pair
        top_board = ranks_board_sorted[0] if ranks_board_sorted else 0
        second_board = ranks_board_sorted[1] if len(ranks_board_sorted) > 1 else 0

        hole_pair = ranks_hole[0] == ranks_hole[1]
        overpair = hole_pair and (top_board and min(ranks_hole) > top_board)
        top_pair = any((r in rank_counts_board and r == top_board) for r in ranks_hole) and not hole_pair
        second_pair = any((r in rank_counts_board and r == second_board) for r in ranks_hole) and not top_pair and not hole_pair

        # Strength mapping
        strength = 0.2
        category = 'high_card'
        if is_quads:
            strength = 0.99
            category = 'quads'
        elif is_full_house:
            strength = 0.97
            category = 'full_house'
        elif has_flush:
            strength = 0.92
            category = 'flush'
        elif has_straight:
            strength = 0.9
            category = 'straight'
        elif is_trips:
            strength = 0.83
            category = 'trips'
        elif overpair:
            strength = 0.80
            category = 'overpair'
        elif is_two_pair:
            strength = 0.78
            category = 'two_pair'
        elif top_pair:
            kicker = max(r for r in ranks_hole if r != top_board) if len(set(ranks_hole)) == 2 else max(ranks_hole)
            strength = 0.70 if kicker >= 10 else 0.64
            category = 'top_pair'
        elif second_pair:
            strength = 0.58
            category = 'second_pair'
        elif is_one_pair:
            strength = 0.52
            category = 'pair'
        else:
            category = 'high_card'
            strength = 0.20

        return {
            'strength': strength,
            'category': category,
            'overpair': overpair,
            'top_pair': top_pair,
            'second_pair': second_pair,
            'has_flush': has_flush,
            'has_straight': has_straight,
        }

    def _draw_eval(self, hole: List[str], board: List[str]) -> Dict[str, Any]:
        cards = list(hole) + list(board)
        flush_draw = self._flush_draw(cards)
        oesd, gutshot = self._straight_draws(cards)

        outs = 0
        if flush_draw:
            outs += 9
        if oesd:
            outs += 8
        elif gutshot:
            outs += 4

        # Approximate equity using Rule of 2 and 4
        # Determine street by number of community cards
        n_board = len(board)
        if n_board <= 3:
            # Flop -> two cards to come
            equity = min(0.95, outs * 0.04)
        elif n_board == 4:
            # Turn -> one card to come
            equity = min(0.95, outs * 0.02)
        else:
            equity = 0.0

        draw_strength = max(0.0, min(1.0, equity))
        # Slight bump if we also have overcards (two overcards to board) on flop
        if n_board == 3:
            board_max = max((self._rank_value(c) for c in board), default=0)
            hole_ranks = [self._rank_value(c) for c in hole]
            if min(hole_ranks) > board_max:
                draw_strength = min(1.0, draw_strength + 0.06)

        return {
            'flush_draw': flush_draw,
            'oesd': oesd,
            'gutshot': gutshot and not oesd,
            'outs': outs,
            'draw_strength': draw_strength
        }

    def _preflop_strength(self, hole: List[str], num_players: int) -> float:
        # Coarse preflop strength estimator
        r1, r2 = self._rank_value(hole[0]), self._rank_value(hole[1])
        s1, s2 = self._suit(hole[0]), self._suit(hole[1])
        high, low = max(r1, r2), min(r1, r2)
        suited = (s1 == s2)
        gap = abs(r1 - r2) - 1

        # Base for pairs
        if r1 == r2:
            pair_rank = r1
            # Map pair rank to strength
            pair_strength_map = {
                14: 0.98, 13: 0.96, 12: 0.94, 11: 0.92, 10: 0.88,
                9: 0.85, 8: 0.82, 7: 0.78, 6: 0.74, 5: 0.70, 4: 0.66, 3: 0.62, 2: 0.58
            }
            base = pair_strength_map.get(pair_rank, 0.60)
        else:
            # High-card combos
            base = (high + low) / 30.0  # approx in [0.13..0.93]
            if suited:
                base += 0.03
            # Connectivity bonus
            if gap <= 0:
                base += 0.04
            elif gap == 1:
                base += 0.03
            elif gap == 2:
                base += 0.02
            elif gap == 3:
                base += 0.01

            # Penalty if low cards
            if high < 11:
                base -= 0.04

        # Multiway tighten
        base -= max(0, num_players - 2) * 0.02
        return max(0.0, min(1.0, base))

    def _safe_raise_amount(self, min_raise: int, max_raise: int, target: int) -> Optional[int]:
        # Returns a valid raise amount clamped to [min_raise, max_raise] or None if not raisable
        if max_raise is None or min_raise is None:
            return None
        if max_raise < max(1, min_raise):
            return None
        amt = int(max(min_raise, min(max_raise, max(1, target))))
        if amt < max(1, min_raise):
            return None
        return amt

    def _decide_preflop_action(self, to_call: int, pot: int, min_raise: int, max_raise: int,
                               remaining_chips: int, strength: float, num_players: int) -> Tuple[PokerAction, int]:
        # Conservative heads-up/multiway preflop strategy
        eps = 1e-9
        # Basic thresholds
        open_raise_thresh = 0.62 if num_players <= 3 else 0.68
        call_thresh = 0.50 if num_players <= 3 else 0.55
        three_bet_thresh = 0.78 if num_players <= 3 else 0.82

        # If nothing to call, decide to raise or check
        if to_call <= 0:
            if strength >= open_raise_thresh:
                # Aim ~2.5bb open; if min_raise enforces size, just use min_raise
                target = int(max(self.big_blind * 2, pot * 0.6))
                amt = self._safe_raise_amount(min_raise, max_raise, target)
                if amt is not None and amt > 0:
                    return PokerAction.RAISE, amt
                else:
                    return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Facing a raise/limp
            # If all-in required to continue
            if to_call >= remaining_chips:
                # Only call off light if very strong
                if strength >= three_bet_thresh:
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

            # Compute pot odds
            pot_odds = to_call / (pot + to_call + eps)

            # Strong hands: 3-bet
            if strength >= three_bet_thresh:
                target = int(max(self.big_blind * 4, pot * 0.7))
                amt = self._safe_raise_amount(min_raise, max_raise, target)
                if amt is not None and amt > 0:
                    return PokerAction.RAISE, amt
                # If cannot raise, call
                return PokerAction.CALL, 0

            # Medium hands: call if priced in
            if strength >= call_thresh and pot_odds <= 0.30:
                return PokerAction.CALL, 0

            # Speculative suited connectors/pairs can call small raises
            speculative = strength >= 0.46 and to_call <= max(self.big_blind * 1, int(pot * 0.15))
            if speculative:
                return PokerAction.CALL, 0

            return PokerAction.FOLD, 0

    def _decide_postflop_action(self, to_call: int, pot: int, min_raise: int, max_raise: int, remaining_chips: int,
                                strength: float, made: Dict[str, Any], draw: Dict[str, Any],
                                street: str, num_players: int) -> Tuple[PokerAction, int]:
        eps = 1e-9
        strong_made = strength >= 0.80 or made['category'] in ('quads', 'full_house', 'flush', 'straight', 'trips', 'overpair', 'two_pair')
        medium_made = made['category'] in ('top_pair', 'second_pair') or strength >= 0.60
        good_draw = draw['flush_draw'] or draw['oesd']
        weak_draw = draw['gutshot']

        # Aggression sizes
        value_size = int(max(self.big_blind, pot * 0.6))
        bluff_size = int(max(self.big_blind, pot * 0.5))
        protect_size = int(max(self.big_blind, pot * 0.4))

        # Nothing to call -> we can bet
        if to_call <= 0:
            if strong_made:
                target = value_size
                amt = self._safe_raise_amount(min_raise, max_raise, target)
                if amt is not None and amt > 0:
                    return PokerAction.RAISE, amt
                else:
                    return PokerAction.CHECK, 0
            elif medium_made:
                target = protect_size
                amt = self._safe_raise_amount(min_raise, max_raise, target)
                if amt is not None and amt > 0 and self.random.random() < 0.9:
                    return PokerAction.RAISE, amt
                else:
                    return PokerAction.CHECK, 0
            elif good_draw:
                # Semi-bluff sometimes
                if self.random.random() < 0.5:
                    target = bluff_size
                    amt = self._safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None and amt > 0:
                        return PokerAction.RAISE, amt
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0
        else:
            # Facing a bet
            if to_call >= remaining_chips:
                # Commit only with strong made or strong draw
                if strong_made or (good_draw and strength >= 0.45):
                    return PokerAction.ALL_IN, 0
                else:
                    return PokerAction.FOLD, 0

            # Pot odds for call decisions
            pot_odds = to_call / (pot + to_call + eps)

            # Made hand logic
            if strong_made:
                # Mostly raise for value unless bet is huge
                if to_call <= pot * 0.7:
                    target = value_size
                    amt = self._safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None and amt > 0:
                        return PokerAction.RAISE, amt
                # Otherwise call to control pot
                return PokerAction.CALL, 0

            # Medium made hands
            if medium_made:
                # Call reasonable bets, fold to very large bets especially multiway
                max_call_frac = 0.35 if num_players <= 2 else 0.25
                if to_call <= pot * max_call_frac:
                    return PokerAction.CALL, 0
                else:
                    return PokerAction.FOLD, 0

            # Draw logic
            if good_draw or weak_draw:
                equity = draw['draw_strength']
                # Slight bump on flop
                if street == 'flop':
                    equity = min(1.0, equity + 0.02)
                # Call if priced in
                if equity > pot_odds * 1.05:
                    return PokerAction.CALL, 0
                # Semi-bluff raise sometimes with good draw and fold equity likely (heads-up)
                if good_draw and num_players <= 2 and to_call <= pot * 0.35 and self.random.random() < 0.4:
                    target = bluff_size
                    amt = self._safe_raise_amount(min_raise, max_raise, target)
                    if amt is not None and amt > 0:
                        return PokerAction.RAISE, amt
                return PokerAction.FOLD, 0

            # High-card / nothing: mostly fold, occasionally float tiny bets heads-up
            if num_players <= 2 and to_call <= max(self.big_blind, int(pot * 0.10)) and self.random.random() < 0.15:
                return PokerAction.CALL, 0
            return PokerAction.FOLD, 0