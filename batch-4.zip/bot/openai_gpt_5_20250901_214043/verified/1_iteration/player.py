import random
from typing import List, Tuple, Dict, Any, Optional
from itertools import combinations

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


RANK_ORDER = "23456789TJQKA"
RANK_TO_VAL = {r: i + 2 for i, r in enumerate(RANK_ORDER)}
VAL_TO_RANK = {v: r for r, v in RANK_TO_VAL.items()}
SUITS = ['h', 'd', 'c', 's']


def card_to_rank_suit(card: str) -> Tuple[int, str]:
    """Convert card string like 'Ah' to (14, 'h')."""
    if not card or len(card) < 2:
        return 0, ''
    r = card[0].upper()
    s = card[1].lower()
    return RANK_TO_VAL.get(r, 0), s


def is_straight(vals: List[int]) -> Optional[int]:
    """
    Check if list of 5 ranks is a straight.
    Returns the high card value of the straight if true, otherwise None.
    Handles wheel straight (A-2-3-4-5).
    """
    v = sorted(set(vals))
    if len(v) < 5:
        return None
    # For 5 cards we can check directly
    if len(v) == 5 and max(v) - min(v) == 4:
        return max(v)
    # Wheel straight check if Ace present treat as 1
    if 14 in v:
        vv = [1 if x == 14 else x for x in v]
        vv = sorted(set(vv))
        if len(vv) >= 5 and max(vv) - min(vv) == 4 and len(vv) == 5:
            return 5
    return None


def evaluate_5card_hand(cards: List[str]) -> Tuple[int, List[int]]:
    """
    Evaluate a 5-card hand and return (category, tiebreakers) where larger tuple is better.
    Categories:
        8: Straight flush
        7: Four of a kind
        6: Full house
        5: Flush
        4: Straight
        3: Three of a kind
        2: Two pair
        1: One pair
        0: High card
    """
    vals = []
    suits = []
    for c in cards:
        v, s = card_to_rank_suit(c)
        vals.append(v)
        suits.append(s)

    vals_sorted = sorted(vals, reverse=True)
    val_counts: Dict[int, int] = {}
    suit_counts: Dict[str, int] = {}
    for v in vals:
        val_counts[v] = val_counts.get(v, 0) + 1
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1

    # Flush
    flush_suit = None
    for s, cnt in suit_counts.items():
        if cnt >= 5:
            flush_suit = s
            break

    # Straight detection
    uniq_vals = sorted(set(vals))
    # Special case: Ace low straight
    straight_high = None
    # Check regular straight
    if len(uniq_vals) >= 5:
        for combo in combinations(uniq_vals, 5):
            if max(combo) - min(combo) == 4 and len(set(combo)) == 5:
                straight_high = max(combo)
        # Wheel straight
        if straight_high is None and 14 in uniq_vals:
            low_vals = [1 if x == 14 else x for x in uniq_vals]
            for combo in combinations(sorted(set(low_vals)), 5):
                if max(combo) - min(combo) == 4 and len(set(combo)) == 5:
                    straight_high = 5

    # Straight flush
    if flush_suit is not None:
        flush_vals = sorted([card_to_rank_suit(c)[0] for c in cards if card_to_rank_suit(c)[1] == flush_suit])
        flush_unique = sorted(set(flush_vals))
        sf_high = None
        if len(flush_unique) >= 5:
            for combo in combinations(flush_unique, 5):
                if max(combo) - min(combo) == 4 and len(set(combo)) == 5:
                    sf_high = max(combo)
            # Wheel straight flush
            if sf_high is None and 14 in flush_unique:
                low_vals = [1 if x == 14 else x for x in flush_unique]
                for combo in combinations(sorted(set(low_vals)), 5):
                    if max(combo) - min(combo) == 4 and len(set(combo)) == 5:
                        sf_high = 5
        if sf_high is not None:
            return 8, [sf_high]

    # Four of a kind
    fours = [v for v, c in val_counts.items() if c == 4]
    if fours:
        four = max(fours)
        kickers = sorted([v for v in vals if v != four], reverse=True)
        return 7, [four] + kickers[:1]

    # Full house
    trips = sorted([v for v, c in val_counts.items() if c == 3], reverse=True)
    pairs = sorted([v for v, c in val_counts.items() if c == 2], reverse=True)
    if trips:
        # Could also use second trip as pair
        best_trip = trips[0]
        remaining_trips = trips[1:]
        best_pair = pairs[0] if pairs else (remaining_trips[0] if remaining_trips else None)
        if best_pair is not None:
            return 6, [best_trip, best_pair]

    # Flush
    if flush_suit is not None:
        flush_cards = sorted([card_to_rank_suit(c)[0] for c in cards if card_to_rank_suit(c)[1] == flush_suit], reverse=True)
        return 5, flush_cards[:5]

    # Straight
    if straight_high is not None:
        return 4, [straight_high]

    # Three of a kind
    if trips:
        t = trips[0]
        kickers = sorted([v for v in vals if v != t], reverse=True)
        return 3, [t] + kickers[:2]

    # Two pair
    if len(pairs) >= 2:
        top2 = pairs[:2]
        kicker = max([v for v in vals if v not in top2])
        return 2, top2 + [kicker]

    # One pair
    if len(pairs) == 1:
        p = pairs[0]
        kickers = sorted([v for v in vals if v != p], reverse=True)
        return 1, [p] + kickers[:3]

    # High card
    return 0, sorted(vals, reverse=True)[:5]


def evaluate_7card_best(cards: List[str]) -> Tuple[int, List[int]]:
    """Evaluate best 5-card hand out of up to 7 cards."""
    best = (-1, [])
    for combo in combinations(cards, 5):
        v = evaluate_5card_hand(list(combo))
        if v > best:
            best = v
    return best


def hand_category_label(cat: int) -> str:
    return ["HighCard", "Pair", "TwoPair", "Trips", "Straight", "Flush", "FullHouse", "Quads", "StraightFlush"][cat] if 0 <= cat <= 8 else "Unknown"


def make_deck(exclude: List[str]) -> List[str]:
    deck = []
    excl_set = set(exclude)
    for r in RANK_ORDER:
        for s in SUITS:
            c = r + s
            if c not in excl_set:
                deck.append(c)
    return deck


def preflop_strength_rank(hole: List[str]) -> float:
    """Quick heuristic strength [0,1] for preflop starting hand."""
    if not hole or len(hole) != 2:
        return 0.0
    r1, s1 = card_to_rank_suit(hole[0])
    r2, s2 = card_to_rank_suit(hole[1])
    suited = s1 == s2
    ranks = sorted([r1, r2], reverse=True)
    high, low = ranks[0], ranks[1]
    pair = r1 == r2
    gap = high - low

    # Base strength
    strength = 0.0

    if pair:
        # Pairs from 22 to AA
        strength = (r1 - 1) / 13.0  # 2->1/13 ... A->13/13
    else:
        # High card contribution
        strength = (high - 2) / 12.0 * 0.6 + (low - 2) / 12.0 * 0.2
        # Suited bonus
        if suited:
            strength += 0.08
        # Connectivity bonus
        if gap == 1:
            strength += 0.08
        elif gap == 2:
            strength += 0.04
        elif gap == 0:  # shouldn't happen in else
            strength += 0.1

    # Specific premium hand boosts
    if pair and r1 >= 12:  # QQ+
        strength = max(strength, 0.95)
    if set([r1, r2]) == set([14, 13]):  # AK
        strength = max(strength, 0.88 if suited else 0.82)
    if set([r1, r2]) == set([14, 12]):  # AQ
        strength = max(strength, 0.82 if suited else 0.75)

    # Clamp
    return max(0.0, min(1.0, strength))


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        self.starting_chips: int = 0
        self.blind_amount: int = 0
        self.big_blind_player_id: Optional[int] = None
        self.small_blind_player_id: Optional[int] = None
        self.all_players: List[int] = []
        self.hole_cards: List[str] = []
        self.current_round_num: int = -1
        self.rng = random.Random()
        self.last_round_seen: int = -1

    def on_start(self, starting_chips: int, player_hands: List[str], blind_amount: int, big_blind_player_id: int, small_blind_player_id: int, all_players: List[int]):
        # Initialize game/session state
        self.starting_chips = starting_chips
        self.blind_amount = blind_amount
        self.big_blind_player_id = big_blind_player_id
        self.small_blind_player_id = small_blind_player_id
        self.all_players = all_players[:] if all_players else []
        # Attempt to set hole cards if provided
        try:
            if player_hands and isinstance(player_hands, list) and len(player_hands) >= 2:
                self.hole_cards = player_hands[:2]
        except Exception:
            self.hole_cards = []

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Reset per-round variables. Try to infer/update hole cards if round_state carries them.
        self.current_round_num = round_state.round_num
        # Clear out hole cards to avoid stale data, unless new ones provided via non-standard fields
        new_hole: Optional[List[str]] = None
        # Some engines may attach private cards in round_state extras; try common names safely
        for attr in ['player_hands', 'hole_cards', 'hand', 'private_cards']:
            if hasattr(round_state, attr):
                val = getattr(round_state, attr)
                if isinstance(val, list) and len(val) >= 2 and isinstance(val[0], str):
                    new_hole = val[:2]
                    break
        if new_hole:
            self.hole_cards = new_hole
        else:
            # If we cannot retrieve new hole cards, keep existing only if they look valid and round didn't advance
            # otherwise clear
            if round_state.round == 'Preflop':
                # At preflop, if we don't know our cards, set empty to play safe
                if not self.hole_cards or len(self.hole_cards) != 2:
                    self.hole_cards = []

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Basic derived info
            my_id_str = str(self.id)
            my_bet = round_state.player_bets.get(my_id_str, 0) if round_state.player_bets else 0
            current_bet = round_state.current_bet or 0
            to_call = max(0, current_bet - my_bet)
            pot = round_state.pot or 0
            community = round_state.community_cards or []
            opponents_count = max(0, (len(round_state.current_player) if round_state.current_player else 0) - 1)
            stage = round_state.round  # 'Preflop', 'Flop', 'Turn', 'River'

            # Safety checks
            if remaining_chips <= 0:
                return (PokerAction.CHECK if to_call == 0 else PokerAction.FOLD, 0)

            # If we don't know our hole cards, be conservative
            if not self.hole_cards or len(self.hole_cards) != 2:
                # Without hole cards info, do not risk chips.
                if to_call == 0:
                    return (PokerAction.CHECK, 0)
                else:
                    return (PokerAction.FOLD, 0)

            # Decide based on stage
            if stage == 'Preflop':
                return self._decide_preflop_action(to_call, pot, remaining_chips, opponents_count)
            else:
                return self._decide_postflop_action(to_call, pot, remaining_chips, opponents_count, community)
        except Exception:
            # Fail-safe: never throw; be conservative
            # If can't act, avoid invalid actions
            return (PokerAction.CHECK, 0)

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        # Clear hole cards by default; new ones should arrive next round
        self.hole_cards = []

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No persistent resources to close
        pass

    # ================= Helper Decision Logic ===================

    def _decide_preflop_action(self, to_call: int, pot: int, remaining_chips: int, opponents_count: int) -> Tuple[PokerAction, int]:
        eps = 1e-9
        strength = preflop_strength_rank(self.hole_cards)

        # If facing all-in or effectively all-in call
        if to_call >= remaining_chips:
            # Compute approximate equity by simulation
            equity = self._estimate_equity(self.hole_cards, [], opponents_count, trials=220)
            # Pot odds for all-in call
            pot_odds = (to_call + eps) / (pot + to_call + eps)
            if equity + 0.02 >= pot_odds:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)

        # No bet to call: check. Rarely shove with top premium.
        if to_call == 0:
            # Only shove rare with top 1-2% hands to gain value/pressure
            if strength >= 0.95 and remaining_chips < max(30 * max(1, self.blind_amount), pot * 3):
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CHECK, 0)

        # There is a bet to call
        # Quick thresholds based on strength and pot odds via quick simulation only if hand is borderline
        pot_odds = (to_call + eps) / (pot + to_call + eps)

        # Strong hands: be willing to go with it
        if strength >= 0.90:
            # Prefer all-in if short or pot already significant
            if remaining_chips <= 8 * to_call or pot > 6 * to_call:
                return (PokerAction.ALL_IN, 0)
            else:
                # Safe call if deep
                return (PokerAction.CALL, 0)

        # Medium strength: call if odds allow; otherwise fold
        if strength >= 0.62:
            # Do a light equity sim to refine decision
            equity = self._estimate_equity(self.hole_cards, [], opponents_count, trials=140)
            if equity >= pot_odds - 0.03:
                # Avoid bloating pot too much pre if multi-way
                if equity - pot_odds > 0.25 and (remaining_chips <= 10 * to_call or opponents_count <= 1):
                    return (PokerAction.ALL_IN, 0)
                return (PokerAction.CALL, 0)
            else:
                return (PokerAction.FOLD, 0)

        # Weak: mostly fold; occasionally defend if cheap and multi-way
        cheap = to_call <= max(self.blind_amount, pot // max(4, (opponents_count + 2))) if self.blind_amount else to_call <= max(50, pot // max(4, (opponents_count + 2)))
        if cheap and strength >= 0.50:
            return (PokerAction.CALL, 0)
        return (PokerAction.FOLD, 0)

    def _decide_postflop_action(self, to_call: int, pot: int, remaining_chips: int, opponents_count: int, community: List[str]) -> Tuple[PokerAction, int]:
        eps = 1e-9
        # Estimate equity via Monte Carlo against random opponent ranges
        trials = 180 if len(community) <= 3 else 120
        equity = self._estimate_equity(self.hole_cards, community, opponents_count, trials=trials)

        # Effective nuts detection by made hand category
        cat, tb = evaluate_7card_best(self.hole_cards + community)
        made_label = hand_category_label(cat)

        # If to call greater than or equal to stack, decide to go all-in or fold
        if to_call >= remaining_chips:
            pot_odds = (to_call + eps) / (pot + to_call + eps)
            if equity + 0.01 >= pot_odds:
                return (PokerAction.ALL_IN, 0)
            else:
                return (PokerAction.FOLD, 0)

        # No bet to call: check or shove for value with strong hands
        if to_call == 0:
            # Shove only with strong value and reasonable SPR
            strong_made = (cat >= 5) or (cat == 4 and tb and tb[0] >= 10) or (cat == 3 and tb and tb[0] >= 12)  # Flush+, or Straight T-high+, or Trips J+
            if strong_made and (remaining_chips <= 3 * max(1, pot) or equity >= 0.80):
                return (PokerAction.ALL_IN, 0)
            # Otherwise check back
            return (PokerAction.CHECK, 0)

        # There is a bet to call
        pot_odds = (to_call + eps) / (pot + to_call + eps)

        # If equity worse than odds by margin -> fold
        if equity + 0.02 < pot_odds:
            return (PokerAction.FOLD, 0)

        # If very strong, prefer jamming in many cases
        if equity >= 0.75 or cat >= 5:
            if remaining_chips <= 6 * to_call or pot >= 6 * to_call:
                return (PokerAction.ALL_IN, 0)
            # otherwise, calling keeps ranges wider and avoids invalid raise semantics
            return (PokerAction.CALL, 0)

        # For decent draws or medium-strength hands, call if odds acceptable
        if equity >= pot_odds:
            # Semi-bluff shove occasionally if short stacked to gain fold equity
            if remaining_chips <= 5 * to_call and equity - pot_odds >= 0.10:
                return (PokerAction.ALL_IN, 0)
            return (PokerAction.CALL, 0)

        # Default conservative
        return (PokerAction.FOLD, 0)

    # ================= Equity Estimation ===================

    def _estimate_equity(self, hole: List[str], board: List[str], opponents_count: int, trials: int = 150) -> float:
        """
        Monte Carlo estimation of winning equity against opponents_count random opponents.
        Returns value in [0,1].
        """
        if not hole or len(hole) != 2:
            return 0.0
        known = hole[:] + (board[:] if board else [])
        # Remove any invalid cards
        known = [c for c in known if isinstance(c, str) and len(c) >= 2]
        deck = make_deck(known)
        if len(deck) < 2 * max(1, opponents_count) + max(0, 5 - len(board)):
            # Not enough cards - fallback conservative
            return 0.0

        wins = 0.0
        total = 0
        board_len = len(board) if board else 0
        draw_board_count = max(0, 5 - board_len)
        for _ in range(max(1, trials)):
            # Sample remaining board
            draw = self.rng.sample(deck, draw_board_count + 2 * opponents_count)
            board_add = draw[:draw_board_count]
            idx = draw_board_count
            opp_hands = []
            for _op in range(opponents_count):
                opp_hands.append([draw[idx], draw[idx + 1]])
                idx += 2

            full_board = (board if board else []) + board_add

            # Evaluate our best hand
            my_best = evaluate_7card_best(hole + full_board)

            # Evaluate opponents
            opp_scores = []
            for oh in opp_hands:
                opp_scores.append(evaluate_7card_best(oh + full_board))

            # Determine winners
            all_scores = [my_best] + opp_scores
            max_score = max(all_scores)
            winners = [i for i, sc in enumerate(all_scores) if sc == max_score]
            if 0 in winners:
                wins += 1.0 / len(winners)  # split pot share
            total += 1

        if total <= 0:
            return 0.0
        return max(0.0, min(1.0, wins / (total + 1e-9)))