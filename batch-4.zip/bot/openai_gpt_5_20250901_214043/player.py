from typing import List, Tuple, Optional, Dict
import random

from bot import Bot
from type.poker_action import PokerAction
from type.round_state import RoundStateClient


class SimplePlayer(Bot):
    def __init__(self):
        super().__init__()
        # Static/game-level
        self.starting_chips: int = 0
        self.big_blind: int = 10
        self.small_blind: int = 5
        self.players: List[int] = []
        self.bb_player: Optional[int] = None
        self.sb_player: Optional[int] = None

        # Hand-level
        self.hole_cards: Optional[List[str]] = None
        self.round_num: int = 0
        self.was_preflop_raiser: bool = False
        self.was_aggressor_prev_street: bool = False
        self.random_seed_base: int = random.randint(1, 1_000_000)

        # Tracking basic outcomes
        self.hands_played: int = 0
        self.hands_won: int = 0

    def on_start(
        self,
        starting_chips: int,
        player_hands: List[str],
        blind_amount: int,
        big_blind_player_id: int,
        small_blind_player_id: int,
        all_players: List[int]
    ):
        # This method may be called at the start of the game or at the start of each new hand
        try:
            self.starting_chips = starting_chips
            # Assume blind_amount is big blind if only one amount is given
            self.big_blind = max(int(blind_amount), 1)
            self.small_blind = max(self.big_blind // 2, 1)
            self.players = list(all_players) if all_players else self.players
            self.bb_player = big_blind_player_id
            self.sb_player = small_blind_player_id

            # Many client frameworks pass our two hole cards here
            if isinstance(player_hands, list) and len(player_hands) >= 2:
                self.hole_cards = [str(player_hands[0]), str(player_hands[1])]
            else:
                self.hole_cards = None

            # Reset per-hand flags
            self.was_preflop_raiser = False
            self.was_aggressor_prev_street = False
            self.hands_played += 1
        except Exception:
            # Fail-safe: if anything goes wrong, keep defaults to avoid exceptions
            pass

    def on_round_start(self, round_state: RoundStateClient, remaining_chips: int):
        # Called at the start of each betting street (Preflop, Flop, Turn, River)
        try:
            self.round_num = getattr(round_state, "round_num", self.round_num)
            # If the environment passes private cards differently, try to capture them
            # (Duck-typing for compatibility; ignore if not present)
            # No change if not available.
            # Reset aggressor status entering preflop
            stage = str(getattr(round_state, "round", "Preflop")).lower()
            if stage == "preflop":
                self.was_preflop_raiser = False
                self.was_aggressor_prev_street = False
        except Exception:
            pass

    def get_action(self, round_state: RoundStateClient, remaining_chips: int) -> Tuple[PokerAction, int]:
        """ Returns the action for the player. """
        try:
            # Basic derived info
            stage = str(getattr(round_state, "round", "Preflop")).lower()
            pot = int(getattr(round_state, "pot", 0))
            min_raise = int(getattr(round_state, "min_raise", 0) or 0)
            max_raise = int(getattr(round_state, "max_raise", remaining_chips) or remaining_chips)
            player_bets: Dict[str, int] = getattr(round_state, "player_bets", {}) or {}
            current_bet = int(getattr(round_state, "current_bet", 0) or 0)

            my_bet = int(player_bets.get(str(self.id), 0) or 0)
            to_call = max(current_bet - my_bet, 0)
            can_check = (to_call == 0)

            # Defensive guards
            if remaining_chips <= 0:
                return PokerAction.FOLD, 0

            # Evaluate strength (use real hole cards if available, else pseudo-random strength per hand)
            strength = self._estimate_hand_strength(stage)

            # Heads-up or multi-way light adjustment
            n_players = max(len(getattr(round_state, "current_player", []) or self.players), 2)
            multiway_tighten = 0.05 * max(n_players - 2, 0)  # tighten threshold slightly in multi-way pots

            # Strategy selection
            if stage == "preflop":
                return self._act_preflop(round_state, remaining_chips, to_call, can_check, strength - multiway_tighten)
            elif stage in ("flop", "turn", "river"):
                return self._act_postflop(round_state, remaining_chips, to_call, can_check, strength - multiway_tighten)
            else:
                # Unknown stage: play safe
                return PokerAction.CHECK, 0 if can_check else (PokerAction.FOLD, 0)
        except Exception:
            # Any unexpected issue: choose the safest legal action
            try:
                current_bet = int(getattr(round_state, "current_bet", 0) or 0)
                player_bets: Dict[str, int] = getattr(round_state, "player_bets", {}) or {}
                my_bet = int(player_bets.get(str(self.id), 0) or 0)
                to_call = max(current_bet - my_bet, 0)
                if to_call == 0:
                    return PokerAction.CHECK, 0
                else:
                    # Avoid costly errors
                    return PokerAction.FOLD, 0
            except Exception:
                # Absolute fallback
                return PokerAction.FOLD, 0

    def on_end_round(self, round_state: RoundStateClient, remaining_chips: int):
        """ Called at the end of the round. """
        try:
            # Reset hand-specific data
            self.hole_cards = None
            self.was_preflop_raiser = False
            self.was_aggressor_prev_street = False
        except Exception:
            pass

    def on_end_game(self, round_state: RoundStateClient, player_score: float, all_scores: dict, active_players_hands: dict):
        # No external resources to release. Keep minimal.
        pass

    # -----------------------
    # Helper methods
    # -----------------------
    def _estimate_hand_strength(self, stage: str) -> float:
        """Return a 0..1 hand strength estimate.
        If we know our hole cards, compute a quick heuristic preflop strength.
        Postflop, use the same base but smooth slightly.
        If we don't know our cards, use a deterministic pseudo-random per-hand strength.
        """
        rng = random.Random(self.random_seed_base + (self.round_num or 0) * 997 + (self.id or 0) * 13)
        if self.hole_cards and len(self.hole_cards) >= 2:
            s = self._preflop_strength(self.hole_cards[0], self.hole_cards[1])
        else:
            # Pseudo-random strength as fallback
            s = rng.random() * 0.9 + 0.05  # avoid exact 0 or 1

        # Postflop smoothing (we don't see board strength here; keep conservative)
        if stage in ("flop", "turn", "river"):
            s = 0.5 * s + 0.25  # pull towards mediocre to reduce spew when uncertain

        return max(0.0, min(1.0, s))

    @staticmethod
    def _rank_value(card: str) -> int:
        rank = card[0].upper()
        mapping = {'A': 14, 'K': 13, 'Q': 12, 'J': 11, 'T': 10}
        if rank in mapping:
            return mapping[rank]
        try:
            v = int(rank)
            if 2 <= v <= 9:
                return v
        except Exception:
            pass
        return 2

    def _preflop_strength(self, c1: str, c2: str) -> float:
        """Fast heuristic preflop strength 0..1."""
        r1 = self._rank_value(c1)
        r2 = self._rank_value(c2)
        s1 = c1[1].lower() if len(c1) >= 2 else 'x'
        s2 = c2[1].lower() if len(c2) >= 2 else 'y'
        high, low = max(r1, r2), min(r1, r2)
        suited = (s1 == s2)

        if r1 == r2:  # Pair
            base = 0.6 + (high - 2) / 12.0 * 0.4  # 22->0.6, AA->1.0
        else:
            # High card contribution
            base = max(0.0, (high - 6) / 8.0) * 0.4  # 7..14 -> 0..0.4
            base += max(0.0, (low - 2) / 12.0) * 0.2  # 2..14 -> 0..0.2
            if suited:
                base += 0.08
            gap = abs(r1 - r2) - 1
            if gap <= 0:
                base += 0.05
            elif gap == 1:
                base += 0.03
            elif gap >= 3:
                base -= 0.05
            if high >= 10 and low >= 10:
                base += 0.1
        return max(0.0, min(1.0, base))

    def _act_preflop(self, round_state: RoundStateClient, stack: int, to_call: int, can_check: bool, strength: float) -> Tuple[PokerAction, int]:
        """Preflop strategy with safe actions and bounds."""
        bb = max(self.big_blind, 1)
        pot = int(getattr(round_state, "pot", 0))
        min_raise = int(getattr(round_state, "min_raise", 0) or 1)
        max_raise = int(getattr(round_state, "max_raise", stack) or stack)
        player_bets: Dict[str, int] = getattr(round_state, "player_bets", {}) or {}
        current_bet = int(getattr(round_state, "current_bet", 0) or 0)
        my_bet = int(player_bets.get(str(self.id), 0) or 0)

        # Short-stack shoves: if very short and not facing massive raise, shove good hands
        if stack <= 15 * bb and strength >= 0.70:
            self.was_preflop_raiser = True
            self.was_aggressor_prev_street = True
            return PokerAction.ALL_IN, 0

        # Open or limp
        if to_call == 0:
            # Mixed strategy: strong open-raise, medium check, weak check/fold later
            # Open size: about 2.5x bb (clamped by min_raise)
            open_to = max(int(2.5 * bb), min_raise)
            # If min_raise looks like delta, then sending delta=open_to is fine when current_bet==0
            if strength >= 0.78:
                action = self._attempt_raise_to(round_state, my_bet, open_to)
                if action is not None:
                    self.was_preflop_raiser = True
                    self.was_aggressor_prev_street = True
                    return action
                # Fallback to check if raise not possible
                return PokerAction.CHECK, 0
            elif strength >= 0.50:
                return PokerAction.CHECK, 0
            else:
                return PokerAction.CHECK, 0

        # Facing a raise
        # Determine affordability and thresholds
        # Use pot odds style: call if strength > pot_odds + margin
        margin = 0.15
        pot_for_odds = pot + 1e-9
        pot_odds = to_call / (pot_for_odds + to_call + 1e-9)
        call_threshold = min(0.95, pot_odds + margin)

        # Very strong: occasional 3-bet
        if strength >= 0.88 and to_call <= 3 * bb and stack > 25 * bb:
            # 3-bet sizing: current_bet + 2*to_call (raise-to), or at least some multiple of bb
            target_to = current_bet + max(to_call * 2, int(3.0 * bb))
            action = self._attempt_raise_to(round_state, my_bet, target_to)
            if action is not None:
                self.was_preflop_raiser = True
                self.was_aggressor_prev_street = True
                return action
            # If cannot raise, consider calling
            if to_call < stack:
                if strength >= call_threshold:
                    return PokerAction.CALL, 0
            # Otherwise fold
            return PokerAction.FOLD, 0

        # Strong hands: call reasonable raises; fold to big ones
        if strength >= call_threshold and to_call <= min(stack, int(4.5 * bb)):
            return PokerAction.CALL, 0

        # If the raise is tiny (min-raise), we can defend with medium+ strength
        if to_call <= max(bb, min_raise) and strength >= 0.60:
            return PokerAction.CALL, 0

        # Otherwise fold; if we're priced in extremely with micro to_call we might still call
        cheap_defend_limit = max(bb, min_raise)
        if to_call <= cheap_defend_limit and strength >= 0.52:
            return PokerAction.CALL, 0

        return PokerAction.FOLD, 0

    def _act_postflop(self, round_state: RoundStateClient, stack: int, to_call: int, can_check: bool, strength: float) -> Tuple[PokerAction, int]:
        """Postflop simplified strategy: cautious with occasional c-bets and value bets."""
        bb = max(self.big_blind, 1)
        pot = int(getattr(round_state, "pot", 0))
        min_raise = int(getattr(round_state, "min_raise", 0) or 1)
        max_raise = int(getattr(round_state, "max_raise", stack) or stack)
        player_bets: Dict[str, int] = getattr(round_state, "player_bets", {}) or {}
        current_bet = int(getattr(round_state, "current_bet", 0) or 0)
        my_bet = int(player_bets.get(str(self.id), 0) or 0)

        rng = random.Random(self.random_seed_base + (self.round_num or 0) * 37 + (self.id or 0) * 101)

        # If we can check, decide to c-bet or probe bet
        if to_call == 0:
            # As aggressor, c-bet small with moderate-high frequency
            if self.was_aggressor_prev_street or self.was_preflop_raiser:
                # Bet ~33-40% pot
                bet_fraction = 0.33 + 0.07 * rng.random()
                desire_bet = max(min_raise, int(pot * bet_fraction))
                # Stronger "strength" => higher chance to bet
                bet_prob = min(0.85, max(0.25, 0.4 + (strength - 0.5)))
                if rng.random() < bet_prob and desire_bet >= min_raise:
                    action = self._attempt_raise_to(round_state, my_bet, desire_bet)
                    if action is not None:
                        self.was_aggressor_prev_street = True
                        return action
                # Otherwise check
                self.was_aggressor_prev_street = False
                return PokerAction.CHECK, 0
            else:
                # Not aggressor: probe very occasionally if strength appears high
                if strength >= 0.80 and pot > 0 and rng.random() < 0.35:
                    desire_bet = max(min_raise, int(0.4 * pot))
                    action = self._attempt_raise_to(round_state, my_bet, desire_bet)
                    if action is not None:
                        self.was_aggressor_prev_street = True
                        return action
                # Default check
                self.was_aggressor_prev_street = False
                return PokerAction.CHECK, 0

        # Facing a bet
        # Pot odds threshold
        pot_for_odds = pot + 1e-9
        pot_odds = to_call / (pot_for_odds + to_call + 1e-9)
        # Margin stricter on later streets
        stage = str(getattr(round_state, "round", "flop")).lower()
        if stage == "flop":
            margin = 0.10
        elif stage == "turn":
            margin = 0.15
        else:  # river
            margin = 0.20

        call_threshold = min(0.98, pot_odds + margin)

        # Strong hands call more; very strong hands can raise small
        if strength >= max(0.75, call_threshold + 0.1):
            # Occasionally raise for value, else call
            if rng.random() < 0.25 and max_raise >= min_raise:
                # Value raise: about 2.5x the bet size if possible
                raise_to = current_bet + max(min_raise, int(1.5 * (current_bet - my_bet + to_call)))
                action = self._attempt_raise_to(round_state, my_bet, raise_to)
                if action is not None:
                    self.was_aggressor_prev_street = True
                    return action
            # Else call if affordable
            if to_call < stack:
                return PokerAction.CALL, 0
            else:
                # If cannot cover, decide between fold or shove
                if rng.random() < 0.5:
                    return PokerAction.ALL_IN, 0
                return PokerAction.FOLD, 0

        # Marginal: call small bets, fold to large
        if strength >= call_threshold and to_call <= min(stack, int(0.25 * (pot + 1))):
            return PokerAction.CALL, 0

        # Otherwise fold; if priced in heavily with tiny bet, still call sometimes
        cheap = int(0.12 * (pot + 1))
        if to_call <= max(cheap, self.big_blind) and strength >= (call_threshold - 0.05):
            return PokerAction.CALL, 0

        return PokerAction.FOLD, 0

    def _attempt_raise_to(self, round_state: RoundStateClient, my_bet: int, target_total: int) -> Optional[Tuple[PokerAction, int]]:
        """Try to raise so that my total chips committed this street equals target_total (best effort).
        Returns (PokerAction.RAISE, raise_delta) if valid; otherwise None.
        The engine's contract suggests the numeric argument for RAISE is the amount to add now.
        """
        min_raise = int(getattr(round_state, "min_raise", 0) or 1)
        max_raise = int(getattr(round_state, "max_raise", 0) or 0)
        current_bet = int(getattr(round_state, "current_bet", 0) or 0)

        # Desired delta to put in now
        delta = max(target_total - my_bet, 0)

        # Ensure the raise is legal: we must exceed current_bet
        if my_bet + delta <= current_bet:
            delta = (current_bet - my_bet) + max(min_raise, 1)

        # Clamp to legal bounds
        delta = max(delta, max(min_raise, 1))
        if max_raise <= 0:
            return None
        if delta > max_raise:
            # If we want to exceed max raise, likely better to all-in via ALL_IN action elsewhere.
            return None

        # Final safety check
        if my_bet + delta <= current_bet:
            return None

        return PokerAction.RAISE, int(delta)